import LQuadrantHpOptimizedUnequalNestedShortBfiveDeltaTwoPrunedArithmeticDefs
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace LRegionArithmetic

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n083_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_0 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n083_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_3050 a b) ∨ (fact_9fdb227ae99d_3052 a b) ∨ (fact_9fdb227ae99d_3562 a b) ∨ (fact_9fdb227ae99d_4700 a b) ∨ (fact_9fdb227ae99d_3290 a b) ∨ (fact_9fdb227ae99d_3056 a b) ∨ (fact_9fdb227ae99d_3058 a b) ∨ (fact_9fdb227ae99d_3113 a b) ∨ (fact_9fdb227ae99d_3116 a b)))
    (h1 : (a ≥ b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n083_o0 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1604 a b jx jy))
    (h1 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h10 : (a ≥ (5 : Int)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n083_o1 (a b jx jy : Int)
    (h0 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h1 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - a))))
    (h4 : (fact_9fdb227ae99d_1609 a b jx jy))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - a))))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (fact_9fdb227ae99d_2923 a b jy))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n083_o2 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - b))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_9fdb227ae99d_1613 a b jx jy))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n083_o3 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h6 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h8 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h9 : (fact_9fdb227ae99d_1616 a b jx jy))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n083_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1617 a b jx jy))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - a))))
    (h3 : (fact_9fdb227ae99d_2922 a b jy))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h9 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - a))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n083_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h7 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h8 : (fact_9fdb227ae99d_1612 a b jx jy))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n083_o6 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_1608 a b jx jy))
    (h3 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : (b = (5 : Int)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n083_o7 (a b jx jy : Int)
    (h0 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h1 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - b))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (fact_9fdb227ae99d_1605 a b jx jy))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : ((jy - b) ≥ (0 : Int)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n084_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (fact_9fdb227ae99d_0 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n084_empty (a b : Int)
    (h0 : (a ≥ b))
    (h1 : ((fact_9fdb227ae99d_3050 a b) ∨ (fact_9fdb227ae99d_3052 a b) ∨ (fact_9fdb227ae99d_3562 a b) ∨ (fact_9fdb227ae99d_4700 a b) ∨ (fact_9fdb227ae99d_3290 a b) ∨ (fact_9fdb227ae99d_3056 a b) ∨ (fact_9fdb227ae99d_3058 a b) ∨ (fact_9fdb227ae99d_3113 a b) ∨ (fact_9fdb227ae99d_3343 a b)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n084_o0 (a b jx jy : Int)
    (h0 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_1604 a b jx jy))
    (h3 : (b = (5 : Int)))
    (h4 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n084_o1 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - a))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (fact_9fdb227ae99d_2923 a b jy))
    (h8 : (fact_9fdb227ae99d_1609 a b jx jy))
    (h9 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n084_o2 (a b jx jy : Int)
    (h0 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - b))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_1613 a b jx jy))
    (h4 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n084_o3 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h2 : (fact_9fdb227ae99d_1616 a b jx jy))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n084_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - a))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : (fact_9fdb227ae99d_2922 a b jy))
    (h7 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - a))))
    (h8 : (b = (5 : Int)))
    (h9 : (fact_9fdb227ae99d_1617 a b jx jy))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n084_o5 (a b jx jy : Int)
    (h0 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (fact_9fdb227ae99d_1612 a b jx jy))
    (h4 : (((jx + (0 : Int)) < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < (jx - a)) ∨ (jy < ((1 : Int) + a)) ∨ (((1 : Int) + a) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n084_o6 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1608 a b jx jy))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h3 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : (b = (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n084_o7 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b = (5 : Int)))
    (h2 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - b))))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (fact_9fdb227ae99d_1605 a b jx jy))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n085_run_four (a b : Int)
    (h0 : (¬ ((-2 : Int) ≥ ((-1 : Int) + ((-1 : Int) * b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n085_run_short (a b : Int)
    (h0 : (¬ (((-2 : Int) - ((-1 : Int) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n085_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n085_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5683 a b) ∨ (fact_9fdb227ae99d_5696 a b) ∨ (fact_9fdb227ae99d_6364 a b) ∨ (fact_9fdb227ae99d_6960 a b) ∨ (fact_9fdb227ae99d_6103 a b) ∨ (fact_9fdb227ae99d_5711 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((4 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_5760 a b) ∨ (fact_9fdb227ae99d_6978 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n085_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3411 a b) ∨ (fact_9fdb227ae99d_3429 a b) ∨ (fact_9fdb227ae99d_4504 a b) ∨ (fact_9fdb227ae99d_5588 a b) ∨ (fact_9fdb227ae99d_4128 a b) ∨ (fact_9fdb227ae99d_3457 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((-2 : Int) + (1 : Int))) ∧ (((-2 : Int) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ ((-2 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((-2 : Int) + (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_3507 a b) ∨ (fact_9fdb227ae99d_5722 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n085_run_tall (a b : Int)
    (h0 : (¬ ((((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7666 a b) ∨ (fact_9fdb227ae99d_7399 a b))) ∨ (((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) + (2 : Int))) ∧ (fact_9fdb227ae99d_7666 a b) ∧ (fact_9fdb227ae99d_7399 a b)) ∨ ((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) + (4 : Int))) ∨ (((-2 : Int) = (((-1 : Int) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_9fdb227ae99d_7666 a b) ∧ (fact_9fdb227ae99d_7399 a b) ∧ (((fact_9fdb227ae99d_6013 a b) ∨ (fact_9fdb227ae99d_6051 a b) ∨ (fact_9fdb227ae99d_6813 a b) ∨ (fact_9fdb227ae99d_7025 a b) ∨ (fact_9fdb227ae99d_6630 a b) ∨ (fact_9fdb227ae99d_6110 a b) ∨ (fact_9fdb227ae99d_6123 a b) ∨ (fact_9fdb227ae99d_6224 a b) ∨ (fact_9fdb227ae99d_7072 a b)) ∨ ((fact_9fdb227ae99d_4061 a b) ∨ (fact_9fdb227ae99d_4089 a b) ∨ (fact_9fdb227ae99d_5295 a b) ∨ (fact_9fdb227ae99d_5910 a b) ∨ (fact_9fdb227ae99d_4993 a b) ∨ (fact_9fdb227ae99d_4135 a b) ∨ (fact_9fdb227ae99d_4152 a b) ∨ (fact_9fdb227ae99d_4221 a b) ∨ (fact_9fdb227ae99d_6143 a b)))) ∨ ((fact_9fdb227ae99d_7666 a b) ∧ (fact_9fdb227ae99d_7399 a b) ∧ ((fact_9fdb227ae99d_6013 a b) ∨ (fact_9fdb227ae99d_6051 a b) ∨ (fact_9fdb227ae99d_6813 a b) ∨ (fact_9fdb227ae99d_7025 a b) ∨ (fact_9fdb227ae99d_6630 a b) ∨ (fact_9fdb227ae99d_6110 a b) ∨ (fact_9fdb227ae99d_6123 a b) ∨ (fact_9fdb227ae99d_6224 a b) ∨ (fact_9fdb227ae99d_7072 a b)) ∧ ((fact_9fdb227ae99d_4061 a b) ∨ (fact_9fdb227ae99d_4089 a b) ∨ (fact_9fdb227ae99d_5295 a b) ∨ (fact_9fdb227ae99d_5910 a b) ∨ (fact_9fdb227ae99d_4993 a b) ∨ (fact_9fdb227ae99d_4135 a b) ∨ (fact_9fdb227ae99d_4152 a b) ∨ (fact_9fdb227ae99d_4221 a b) ∨ (fact_9fdb227ae99d_6143 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n085_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((-1 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((-2 : Int) ≥ run_x))
    (h5 : ((fact_9fdb227ae99d_2365 a b run_x) ∨ (fact_9fdb227ae99d_2382 a b run_x) ∨ (fact_9fdb227ae99d_3038 a b run_x) ∨ (fact_9fdb227ae99d_3479 a b run_x) ∨ (fact_9fdb227ae99d_2945 a b run_x) ∨ (fact_9fdb227ae99d_2400 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_2464 a b run_x) ∨ (fact_9fdb227ae99d_3606 a b run_x)))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n085_run_floor (a b run_x : Int)
    (h0 : (((-1 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h1 : ((-2 : Int) ≥ run_x))
    (h2 : (¬ ((fact_9fdb227ae99d_3177 a b run_x) ∨ (fact_9fdb227ae99d_3187 a b run_x) ∨ (fact_9fdb227ae99d_3729 a b run_x) ∨ (fact_9fdb227ae99d_5194 a b run_x) ∨ (fact_9fdb227ae99d_3552 a b run_x) ∨ (fact_9fdb227ae99d_3199 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_3220 a b run_x) ∨ (fact_9fdb227ae99d_5350 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n086_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (fact_9fdb227ae99d_0 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n086_empty (a b : Int)
    (h0 : (a ≥ b))
    (h1 : ((fact_9fdb227ae99d_3050 a b) ∨ (fact_9fdb227ae99d_3052 a b) ∨ (fact_9fdb227ae99d_3562 a b) ∨ (fact_9fdb227ae99d_4700 a b) ∨ (fact_9fdb227ae99d_3290 a b) ∨ (fact_9fdb227ae99d_3056 a b) ∨ (fact_9fdb227ae99d_3058 a b) ∨ (fact_9fdb227ae99d_3341 a b)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n086_o0 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (b = (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_1604 a b jx jy))
    (h5 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n086_o1 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1609 a b jx jy))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (fact_9fdb227ae99d_2923 a b jy))
    (h7 : (b = (5 : Int)))
    (h8 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - a))))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n086_o2 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - b))))
    (h3 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : (b = (5 : Int)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (fact_9fdb227ae99d_3037 a b))
    (h7 : (((jx + (0 : Int)) < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < (jx - a)) ∨ (jy < ((1 : Int) + a)) ∨ (((1 : Int) + a) < jy)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (fact_9fdb227ae99d_1613 a b jx jy))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n086_o3 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (fact_9fdb227ae99d_1616 a b jx jy))
    (h6 : (b = (5 : Int)))
    (h7 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h8 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h9 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n086_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((jx + (0 : Int)) < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < (jx - b)) ∨ (jy < ((1 : Int) + a)) ∨ (((1 : Int) + a) < jy)))
    (h3 : (fact_9fdb227ae99d_1617 a b jx jy))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - a))))
    (h7 : (fact_9fdb227ae99d_2922 a b jy))
    (h8 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - a))))
    (h9 : (b = (5 : Int)))
    (h10 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n086_o5 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : (((jx + (0 : Int)) < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < (jx - a)) ∨ (jy < ((1 : Int) + a)) ∨ (((1 : Int) + a) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h9 : (fact_9fdb227ae99d_1612 a b jx jy))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n086_o6 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_1608 a b jx jy))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n086_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (fact_9fdb227ae99d_1605 a b jx jy))
    (h2 : (b = (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - b))))
    (h6 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n087_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((-1 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((0 : Int) ≥ (0 : Int)) ∧ ((-1 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((0 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n087_empty (a b : Int)
    (h0 : (((-1 : Int) > ((1 : Int) + b + a)) ∨ ((-1 : Int) < ((1 : Int) + b + a)) ∨ (((0 : Int) + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < ((0 : Int) - (0 : Int)))))
    (h1 : ((fact_9fdb227ae99d_2857 a b) ∨ (fact_9fdb227ae99d_2859 a b) ∨ (fact_9fdb227ae99d_3257 a b) ∨ (fact_9fdb227ae99d_4158 a b) ∨ (fact_9fdb227ae99d_3089 a b) ∨ (fact_9fdb227ae99d_2862 a b) ∨ ((((-1 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((-1 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (4 : Int)) ∧ ((0 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_2950 a b)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n087_o0 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n087_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (fact_9fdb227ae99d_2923 a b jy))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n087_o2 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_2924 a b jy))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n087_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((jx + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jx - b)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h7 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n087_o4 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_2922 a b jy))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n087_o5 (a b jx jy : Int)
    (h0 : ((jx < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h1 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h2 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h8 : (b = (5 : Int)))
    (h9 : (fact_9fdb227ae99d_107 a b))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n087_o6 (a b jx jy : Int)
    (h0 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h3 : (b = (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n087_o7 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_2925 a b jy))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n088_point (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (¬ (((-2 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n088_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((fact_9fdb227ae99d_2863 a b) ∨ (fact_9fdb227ae99d_2865 a b) ∨ (fact_9fdb227ae99d_3259 a b) ∨ (fact_9fdb227ae99d_4166 a b) ∨ (fact_9fdb227ae99d_3098 a b) ∨ (fact_9fdb227ae99d_2867 a b) ∨ ((((-2 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (4 : Int)) ∧ ((1 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_2955 a b)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((0 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((0 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + a)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int)))))
    (h5 : (b = (5 : Int)))
    (h6 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + b))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n088_o0 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ (((jx = ((-2 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n088_o1 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_7276 a b jx jy))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_2923 a b jy))
    (h4 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n088_o2 (a b jx jy : Int)
    (h0 : (¬ ((((-2 : Int) = jx) ∧ (jy = ((1 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h1 : (fact_9fdb227ae99d_2924 a b jy))
    (h2 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b = (5 : Int)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n088_o3 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (¬ ((((-2 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n088_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_2922 a b jy))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b = (5 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (¬ ((((-2 : Int) = jx) ∧ (jy = ((1 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n088_o5 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h3 : (¬ ((((-2 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n088_o6 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (¬ (((jx = ((-2 : Int) + ((-1 : Int) * b))) ∧ ((1 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h7 : (((jx + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jx - (0 : Int))) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h8 : (((jx + b) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h9 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n088_o7 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_2925 a b jy))
    (h1 : (b = (5 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (fact_9fdb227ae99d_7277 a b jx jy))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n089_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ (((-2 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n089_empty (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((fact_9fdb227ae99d_2864 a b) ∨ (fact_9fdb227ae99d_2866 a b) ∨ (fact_9fdb227ae99d_3260 a b) ∨ (fact_9fdb227ae99d_4167 a b) ∨ (fact_9fdb227ae99d_3099 a b) ∨ (fact_9fdb227ae99d_2868 a b) ∨ ((((-2 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (4 : Int)) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_2956 a b) ∨ (fact_9fdb227ae99d_4394 a b)))
    (h2 : (((0 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((0 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + a)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n089_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h5 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : ((jx < ((-2 : Int) + ((-1 : Int) * a))) ∨ (((-2 : Int) + ((-1 : Int) * a)) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n089_o1 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n089_o2 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((-2 : Int) + ((-1 : Int) * a))) ∨ (((-2 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h1 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (¬ ((((-2 : Int) = jx) ∧ (jy = ((2 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n089_o3 (a b jx jy : Int)
    (h0 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h1 : (b = (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n089_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h4 : (b = (5 : Int)))
    (h5 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((jx + (0 : Int)) < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < (jx - b)) ∨ (jy < ((2 : Int) + a)) ∨ (((2 : Int) + a) < jy)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n089_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h2 : (b = (5 : Int)))
    (h3 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h4 : (((jx + (0 : Int)) < ((-2 : Int) + ((-1 : Int) * a))) ∨ (((-2 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n089_o6 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h2 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (¬ (((jx = ((-2 : Int) + ((-1 : Int) * b))) ∧ ((2 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h7 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n089_o7 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n090_run_four (a b : Int)
    (h0 : (¬ ((2 : Int) ≤ ((-1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n090_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((-1 : Int) + a) - (2 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n090_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n090_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_5689 a b) ∨ (fact_9fdb227ae99d_5702 a b) ∨ (fact_9fdb227ae99d_6370 a b) ∨ (fact_9fdb227ae99d_6966 a b) ∨ (fact_9fdb227ae99d_6105 a b) ∨ (fact_9fdb227ae99d_5713 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((4 : Int) ≥ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_5758 a b) ∨ (fact_9fdb227ae99d_6977 a b) ∨ (fact_9fdb227ae99d_6261 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n090_run_right (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ ((fact_9fdb227ae99d_6311 a b) ∨ (fact_9fdb227ae99d_6312 a b) ∨ (fact_9fdb227ae99d_6882 a b) ∨ (fact_9fdb227ae99d_7057 a b) ∨ (fact_9fdb227ae99d_6749 a b) ∨ (fact_9fdb227ae99d_6313 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ (((4 : Int) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((4 : Int) ≥ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_6325 a b) ∨ (fact_9fdb227ae99d_7119 a b) ∨ (fact_9fdb227ae99d_6779 a b))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n090_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (¬ (((((2 : Int) + (3 : Int)) ≤ ((-1 : Int) + a)) ∧ ((fact_9fdb227ae99d_7779 a b) ∨ (fact_9fdb227ae99d_7857 a b))) ∨ ((((2 : Int) + (2 : Int)) ≤ ((-1 : Int) + a)) ∧ (fact_9fdb227ae99d_7779 a b) ∧ (fact_9fdb227ae99d_7857 a b)) ∨ (((2 : Int) + (4 : Int)) ≤ ((-1 : Int) + a)) ∨ ((((-1 : Int) + a) = ((2 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7779 a b) ∧ (fact_9fdb227ae99d_7857 a b) ∧ (((fact_9fdb227ae99d_6004 a b) ∨ (fact_9fdb227ae99d_6042 a b) ∨ (fact_9fdb227ae99d_6804 a b) ∨ (fact_9fdb227ae99d_7016 a b) ∨ (fact_9fdb227ae99d_6628 a b) ∨ (fact_9fdb227ae99d_6106 a b) ∨ (fact_9fdb227ae99d_6121 a b) ∨ (fact_9fdb227ae99d_6191 a b) ∨ (fact_9fdb227ae99d_7062 a b) ∨ (fact_9fdb227ae99d_6689 a b)) ∨ ((fact_9fdb227ae99d_6741 a b) ∨ (fact_9fdb227ae99d_6745 a b) ∨ (fact_9fdb227ae99d_6995 a b) ∨ (fact_9fdb227ae99d_7154 a b) ∨ (fact_9fdb227ae99d_6934 a b) ∨ (fact_9fdb227ae99d_6750 a b) ∨ (fact_9fdb227ae99d_6754 a b) ∨ (fact_9fdb227ae99d_6769 a b) ∨ (fact_9fdb227ae99d_7164 a b) ∨ (fact_9fdb227ae99d_6969 a b)))) ∨ ((fact_9fdb227ae99d_7779 a b) ∧ (fact_9fdb227ae99d_7857 a b) ∧ ((fact_9fdb227ae99d_6004 a b) ∨ (fact_9fdb227ae99d_6042 a b) ∨ (fact_9fdb227ae99d_6804 a b) ∨ (fact_9fdb227ae99d_7016 a b) ∨ (fact_9fdb227ae99d_6628 a b) ∨ (fact_9fdb227ae99d_6106 a b) ∨ (fact_9fdb227ae99d_6121 a b) ∨ (fact_9fdb227ae99d_6191 a b) ∨ (fact_9fdb227ae99d_7062 a b) ∨ (fact_9fdb227ae99d_6689 a b)) ∧ ((fact_9fdb227ae99d_6741 a b) ∨ (fact_9fdb227ae99d_6745 a b) ∨ (fact_9fdb227ae99d_6995 a b) ∨ (fact_9fdb227ae99d_7154 a b) ∨ (fact_9fdb227ae99d_6934 a b) ∨ (fact_9fdb227ae99d_6750 a b) ∨ (fact_9fdb227ae99d_6754 a b) ∨ (fact_9fdb227ae99d_6769 a b) ∨ (fact_9fdb227ae99d_7164 a b) ∨ (fact_9fdb227ae99d_6969 a b))))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n090_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (run_x ≤ ((-1 : Int) + a)))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((fact_9fdb227ae99d_3627 a b run_x) ∨ (fact_9fdb227ae99d_3636 a b run_x) ∨ (fact_9fdb227ae99d_5035 a b run_x) ∨ (fact_9fdb227ae99d_5788 a b run_x) ∨ (fact_9fdb227ae99d_4491 a b run_x) ∨ (fact_9fdb227ae99d_3655 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((4 : Int) ≥ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_3680 a b run_x) ∨ (fact_9fdb227ae99d_5820 a b run_x) ∨ (fact_9fdb227ae99d_4522 a b run_x)))
    (h5 : ((((3 : Int) + a) < ((-2 : Int) + ((-1 : Int) * a))) ∨ (((-2 : Int) + ((-1 : Int) * a)) < ((3 : Int) - (0 : Int))) ∨ ((2 : Int) < ((1 : Int) - (0 : Int))) ∨ ((2 : Int) > ((1 : Int) + b))))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((2 : Int) ≤ run_x))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n090_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5410 a b run_x) ∨ (fact_9fdb227ae99d_5413 a b run_x) ∨ (fact_9fdb227ae99d_5988 a b run_x) ∨ (fact_9fdb227ae99d_6841 a b run_x) ∨ (fact_9fdb227ae99d_5805 a b run_x) ∨ (fact_9fdb227ae99d_5427 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((4 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_5482 a b run_x) ∨ (fact_9fdb227ae99d_6897 a b run_x) ∨ (fact_9fdb227ae99d_5812 a b run_x))))
    (h1 : (run_x ≤ ((-1 : Int) + a)))
    (h2 : ((((2 : Int) + ((2 : Int) * b)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < ((2 : Int) + ((2 : Int) * b))) ∨ ((2 : Int) > ((1 : Int) + a)) ∨ ((2 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((2 : Int) ≤ run_x))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n091_run_four (a b : Int)
    (h0 : (¬ ((-2 : Int) ≥ ((-1 : Int) + ((-1 : Int) * b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n091_run_short (a b : Int)
    (h0 : (¬ (((-2 : Int) - ((-1 : Int) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n091_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n091_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5684 a b) ∨ (fact_9fdb227ae99d_5697 a b) ∨ (fact_9fdb227ae99d_6365 a b) ∨ (fact_9fdb227ae99d_6961 a b) ∨ (fact_9fdb227ae99d_6104 a b) ∨ (fact_9fdb227ae99d_5712 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((4 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_5756 a b) ∨ (fact_9fdb227ae99d_6976 a b) ∨ (fact_9fdb227ae99d_6979 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n091_run_right (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3412 a b) ∨ (fact_9fdb227ae99d_3430 a b) ∨ (fact_9fdb227ae99d_4505 a b) ∨ (fact_9fdb227ae99d_5589 a b) ∨ (fact_9fdb227ae99d_4129 a b) ∨ (fact_9fdb227ae99d_3458 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((-2 : Int) + (1 : Int))) ∧ (((-2 : Int) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ ((-2 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((-2 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_3496 a b) ∨ (fact_9fdb227ae99d_5717 a b) ∨ (fact_9fdb227ae99d_5723 a b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n091_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ ((((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7805 a b) ∨ (fact_9fdb227ae99d_7555 a b))) ∨ (((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) + (2 : Int))) ∧ (fact_9fdb227ae99d_7805 a b) ∧ (fact_9fdb227ae99d_7555 a b)) ∨ ((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) + (4 : Int))) ∨ (((-2 : Int) = (((-1 : Int) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_9fdb227ae99d_7805 a b) ∧ (fact_9fdb227ae99d_7555 a b) ∧ (((fact_9fdb227ae99d_6015 a b) ∨ (fact_9fdb227ae99d_6053 a b) ∨ (fact_9fdb227ae99d_6815 a b) ∨ (fact_9fdb227ae99d_7027 a b) ∨ (fact_9fdb227ae99d_6632 a b) ∨ (fact_9fdb227ae99d_6112 a b) ∨ (fact_9fdb227ae99d_6125 a b) ∨ (fact_9fdb227ae99d_6201 a b) ∨ (fact_9fdb227ae99d_7068 a b) ∨ (fact_9fdb227ae99d_7074 a b)) ∨ ((fact_9fdb227ae99d_4063 a b) ∨ (fact_9fdb227ae99d_4091 a b) ∨ (fact_9fdb227ae99d_5297 a b) ∨ (fact_9fdb227ae99d_5912 a b) ∨ (fact_9fdb227ae99d_4995 a b) ∨ (fact_9fdb227ae99d_4137 a b) ∨ (fact_9fdb227ae99d_4154 a b) ∨ (fact_9fdb227ae99d_4202 a b) ∨ (fact_9fdb227ae99d_6133 a b) ∨ (fact_9fdb227ae99d_6145 a b)))) ∨ ((fact_9fdb227ae99d_7805 a b) ∧ (fact_9fdb227ae99d_7555 a b) ∧ ((fact_9fdb227ae99d_6015 a b) ∨ (fact_9fdb227ae99d_6053 a b) ∨ (fact_9fdb227ae99d_6815 a b) ∨ (fact_9fdb227ae99d_7027 a b) ∨ (fact_9fdb227ae99d_6632 a b) ∨ (fact_9fdb227ae99d_6112 a b) ∨ (fact_9fdb227ae99d_6125 a b) ∨ (fact_9fdb227ae99d_6201 a b) ∨ (fact_9fdb227ae99d_7068 a b) ∨ (fact_9fdb227ae99d_7074 a b)) ∧ ((fact_9fdb227ae99d_4063 a b) ∨ (fact_9fdb227ae99d_4091 a b) ∨ (fact_9fdb227ae99d_5297 a b) ∨ (fact_9fdb227ae99d_5912 a b) ∨ (fact_9fdb227ae99d_4995 a b) ∨ (fact_9fdb227ae99d_4137 a b) ∨ (fact_9fdb227ae99d_4154 a b) ∨ (fact_9fdb227ae99d_4202 a b) ∨ (fact_9fdb227ae99d_6133 a b) ∨ (fact_9fdb227ae99d_6145 a b))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n091_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((-1 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((-2 : Int) ≥ run_x))
    (h6 : ((fact_9fdb227ae99d_2366 a b run_x) ∨ (fact_9fdb227ae99d_2383 a b run_x) ∨ (fact_9fdb227ae99d_3039 a b run_x) ∨ (fact_9fdb227ae99d_3480 a b run_x) ∨ (fact_9fdb227ae99d_2946 a b run_x) ∨ (fact_9fdb227ae99d_2401 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_2461 a b run_x) ∨ (fact_9fdb227ae99d_3604 a b run_x) ∨ (fact_9fdb227ae99d_3607 a b run_x)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n091_run_floor (a b run_x : Int)
    (h0 : ((-2 : Int) ≥ run_x))
    (h1 : (((-1 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h2 : (¬ ((fact_9fdb227ae99d_3178 a b run_x) ∨ (fact_9fdb227ae99d_3188 a b run_x) ∨ (fact_9fdb227ae99d_3730 a b run_x) ∨ (fact_9fdb227ae99d_5195 a b run_x) ∨ (fact_9fdb227ae99d_3553 a b run_x) ∨ (fact_9fdb227ae99d_3200 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_3214 a b run_x) ∨ (fact_9fdb227ae99d_5348 a b run_x) ∨ (fact_9fdb227ae99d_5351 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n092_run_four (a b : Int)
    (h0 : (¬ ((1 : Int) ≤ b)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n092_run_short (a b : Int)
    (h0 : (¬ ((b - (1 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n092_run_nonnegative (a b : Int)
    (h0 : (¬ ((1 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n092_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3581 a b) ∨ (fact_9fdb227ae99d_3585 a b) ∨ (fact_9fdb227ae99d_4718 a b) ∨ (fact_9fdb227ae99d_5748 a b) ∨ (fact_9fdb227ae99d_4385 a b) ∨ (fact_9fdb227ae99d_3592 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (-(3 : Int))) ∧ ((-(3 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ (-(3 : Int))) ∧ ((4 : Int) ≥ (-(3 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_3621 a b) ∨ (fact_9fdb227ae99d_4453 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n092_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3156 a b) ∨ (fact_9fdb227ae99d_3160 a b) ∨ (fact_9fdb227ae99d_3670 a b) ∨ (fact_9fdb227ae99d_5107 a b) ∨ (fact_9fdb227ae99d_3456 a b) ∨ (fact_9fdb227ae99d_3164 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (-(3 : Int))) ∧ ((-(3 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (b + (1 : Int))) ∧ ((3 : Int) ≥ (b + (1 : Int)))) ∨ (((4 : Int) ≤ (-(3 : Int))) ∧ ((4 : Int) ≥ (-(3 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_3165 a b) ∨ (fact_9fdb227ae99d_3525 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n092_run_tall (a b : Int)
    (h0 : (¬ (((((1 : Int) + (3 : Int)) ≤ b) ∧ ((fact_9fdb227ae99d_7403 a b) ∨ (fact_9fdb227ae99d_7337 a b))) ∨ ((((1 : Int) + (2 : Int)) ≤ b) ∧ (fact_9fdb227ae99d_7403 a b) ∧ (fact_9fdb227ae99d_7337 a b)) ∨ (((1 : Int) + (4 : Int)) ≤ b) ∨ ((b = ((1 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7403 a b) ∧ (fact_9fdb227ae99d_7337 a b) ∧ (((fact_9fdb227ae99d_4341 a b) ∨ (fact_9fdb227ae99d_4358 a b) ∨ (fact_9fdb227ae99d_5451 a b) ∨ (fact_9fdb227ae99d_6174 a b) ∨ (fact_9fdb227ae99d_5144 a b) ∨ (fact_9fdb227ae99d_4386 a b) ∨ (fact_9fdb227ae99d_4391 a b) ∨ (fact_9fdb227ae99d_4417 a b) ∨ (fact_9fdb227ae99d_5214 a b)) ∨ ((fact_9fdb227ae99d_3418 a b) ∨ (fact_9fdb227ae99d_3436 a b) ∨ (fact_9fdb227ae99d_4511 a b) ∨ (fact_9fdb227ae99d_5595 a b) ∨ (fact_9fdb227ae99d_4130 a b) ∨ (fact_9fdb227ae99d_3459 a b) ∨ (fact_9fdb227ae99d_3464 a b) ∨ (fact_9fdb227ae99d_3500 a b) ∨ (fact_9fdb227ae99d_4254 a b)))) ∨ ((fact_9fdb227ae99d_7403 a b) ∧ (fact_9fdb227ae99d_7337 a b) ∧ ((fact_9fdb227ae99d_4341 a b) ∨ (fact_9fdb227ae99d_4358 a b) ∨ (fact_9fdb227ae99d_5451 a b) ∨ (fact_9fdb227ae99d_6174 a b) ∨ (fact_9fdb227ae99d_5144 a b) ∨ (fact_9fdb227ae99d_4386 a b) ∨ (fact_9fdb227ae99d_4391 a b) ∨ (fact_9fdb227ae99d_4417 a b) ∨ (fact_9fdb227ae99d_5214 a b)) ∧ ((fact_9fdb227ae99d_3418 a b) ∨ (fact_9fdb227ae99d_3436 a b) ∨ (fact_9fdb227ae99d_4511 a b) ∨ (fact_9fdb227ae99d_5595 a b) ∨ (fact_9fdb227ae99d_4130 a b) ∨ (fact_9fdb227ae99d_3459 a b) ∨ (fact_9fdb227ae99d_3464 a b) ∨ (fact_9fdb227ae99d_3500 a b) ∨ (fact_9fdb227ae99d_4254 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n092_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + b))))
    (h2 : (run_x ≤ b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((1 : Int) ≤ run_x))
    (h6 : (b = (5 : Int)))
    (h7 : ((fact_9fdb227ae99d_2587 a b run_x) ∨ (fact_9fdb227ae99d_2592 a b run_x) ∨ (fact_9fdb227ae99d_3153 a b run_x) ∨ (fact_9fdb227ae99d_3673 a b run_x) ∨ (fact_9fdb227ae99d_3034 a b run_x) ∨ (fact_9fdb227ae99d_2634 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ (-(3 : Int))) ∧ ((-(3 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ (-(3 : Int))) ∧ ((4 : Int) ≥ (-(3 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_2693 a b run_x) ∨ (fact_9fdb227ae99d_3043 a b run_x)))
    (h8 : (((-2 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-2 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (((1 : Int) + b) - b)) ∨ ((1 : Int) > (((1 : Int) + b) + (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n092_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3320 a b run_x) ∨ (fact_9fdb227ae99d_3324 a b run_x) ∨ (fact_9fdb227ae99d_4335 a b run_x) ∨ (fact_9fdb227ae99d_5469 a b run_x) ∨ (fact_9fdb227ae99d_3719 a b run_x) ∨ (fact_9fdb227ae99d_3329 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ (-((3 : Int) - (1 : Int)))) ∧ ((-((3 : Int) - (1 : Int))) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ (-((3 : Int) - (1 : Int)))) ∧ ((4 : Int) ≥ (-((3 : Int) - (1 : Int)))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_3352 a b run_x) ∨ (fact_9fdb227ae99d_3743 a b run_x))))
    (h1 : (run_x ≤ b))
    (h2 : ((1 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n093_run_four (a b : Int)
    (h0 : (¬ (((1 : Int) + b) ≤ ((1 : Int) + a))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n093_run_short (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((2 : Int) + ((2 : Int) * b)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < ((2 : Int) + ((2 : Int) * b))) ∨ ((2 : Int) > ((1 : Int) + a)) ∨ ((2 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (¬ ((((1 : Int) + a) - ((1 : Int) + b)) < b)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n093_run_nonnegative (a b : Int)
    (h0 : (¬ (((1 : Int) + b) ≥ (0 : Int))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n093_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_4161 a b) ∨ (fact_9fdb227ae99d_4163 a b) ∨ (fact_9fdb227ae99d_5344 a b) ∨ (fact_9fdb227ae99d_5959 a b) ∨ (fact_9fdb227ae99d_5030 a b) ∨ (fact_9fdb227ae99d_4165 a b) ∨ ((((-1 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((-1 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (((1 : Int) + b) - (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + b) - (1 : Int)))) ∨ (((4 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + b) - (1 : Int))) ∧ ((((1 : Int) + b) - (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_4313 a b) ∨ ((((-1 : Int) ≥ ((-2 : Int) - b)) ∧ ((-1 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + b) - (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + b) - (1 : Int)))) ∨ (((-2 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-2 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + b) - (1 : Int))) ∧ ((((1 : Int) + b) - (1 : Int)) ≤ ((1 : Int) + a)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n093_run_right (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_4160 a b) ∨ (fact_9fdb227ae99d_4162 a b) ∨ (fact_9fdb227ae99d_5343 a b) ∨ (fact_9fdb227ae99d_5958 a b) ∨ (fact_9fdb227ae99d_5029 a b) ∨ (fact_9fdb227ae99d_4164 a b) ∨ ((((-1 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((-1 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((4 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_4312 a b) ∨ ((((-1 : Int) ≥ ((-2 : Int) - b)) ∧ ((-1 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-2 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-2 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)))))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n093_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (¬ ((((((1 : Int) + b) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_9fdb227ae99d_7439 a b) ∨ (fact_9fdb227ae99d_7438 a b))) ∨ (((((1 : Int) + b) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ (fact_9fdb227ae99d_7439 a b) ∧ (fact_9fdb227ae99d_7438 a b)) ∨ ((((1 : Int) + b) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = (((1 : Int) + b) + (1 : Int))) ∧ (fact_9fdb227ae99d_7439 a b) ∧ (fact_9fdb227ae99d_7438 a b) ∧ (((fact_9fdb227ae99d_4958 a b) ∨ (fact_9fdb227ae99d_4975 a b) ∨ (fact_9fdb227ae99d_5739 a b) ∨ (fact_9fdb227ae99d_6485 a b) ∨ (fact_9fdb227ae99d_5523 a b) ∨ (fact_9fdb227ae99d_5003 a b) ∨ (fact_9fdb227ae99d_5021 a b) ∨ (fact_9fdb227ae99d_5050 a b) ∨ (fact_9fdb227ae99d_5066 a b)) ∨ ((fact_9fdb227ae99d_4957 a b) ∨ (fact_9fdb227ae99d_4974 a b) ∨ (fact_9fdb227ae99d_5738 a b) ∨ (fact_9fdb227ae99d_6484 a b) ∨ (fact_9fdb227ae99d_5522 a b) ∨ (fact_9fdb227ae99d_5002 a b) ∨ (fact_9fdb227ae99d_5020 a b) ∨ (fact_9fdb227ae99d_5049 a b) ∨ (fact_9fdb227ae99d_5065 a b)))) ∨ ((fact_9fdb227ae99d_7439 a b) ∧ (fact_9fdb227ae99d_7438 a b) ∧ ((fact_9fdb227ae99d_4958 a b) ∨ (fact_9fdb227ae99d_4975 a b) ∨ (fact_9fdb227ae99d_5739 a b) ∨ (fact_9fdb227ae99d_6485 a b) ∨ (fact_9fdb227ae99d_5523 a b) ∨ (fact_9fdb227ae99d_5003 a b) ∨ (fact_9fdb227ae99d_5021 a b) ∨ (fact_9fdb227ae99d_5050 a b) ∨ (fact_9fdb227ae99d_5066 a b)) ∧ ((fact_9fdb227ae99d_4957 a b) ∨ (fact_9fdb227ae99d_4974 a b) ∨ (fact_9fdb227ae99d_5738 a b) ∨ (fact_9fdb227ae99d_6484 a b) ∨ (fact_9fdb227ae99d_5522 a b) ∨ (fact_9fdb227ae99d_5002 a b) ∨ (fact_9fdb227ae99d_5020 a b) ∨ (fact_9fdb227ae99d_5049 a b) ∨ (fact_9fdb227ae99d_5065 a b))))))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n093_run_empty (a b run_x : Int)
    (h0 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + b))))
    (h1 : (((1 : Int) + b) ≤ run_x))
    (h2 : (run_x ≤ ((1 : Int) + a)))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((fact_9fdb227ae99d_2500 a b run_x) ∨ (fact_9fdb227ae99d_2501 a b run_x) ∨ (fact_9fdb227ae99d_3084 a b run_x) ∨ (fact_9fdb227ae99d_3594 a b run_x) ∨ (fact_9fdb227ae99d_3010 a b run_x) ∨ (fact_9fdb227ae99d_2502 a b run_x) ∨ ((((-1 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((-1 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_2569 a b run_x) ∨ ((((-1 : Int) ≥ ((-2 : Int) - b)) ∧ ((-1 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-2 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a))))))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n093_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3254 a b run_x) ∨ (fact_9fdb227ae99d_3255 a b run_x) ∨ (fact_9fdb227ae99d_3877 a b run_x) ∨ (fact_9fdb227ae99d_5319 a b run_x) ∨ (fact_9fdb227ae99d_3591 a b run_x) ∨ (fact_9fdb227ae99d_3256 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ ((-1 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((-1 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_3267 a b run_x) ∨ (((((-2 : Int) - b) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ ((-1 : Int) - (1 : Int))) ∧ ((-2 : Int) ≥ ((-1 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (run_x ≤ ((1 : Int) + a)))
    (h4 : (((1 : Int) + b) ≤ run_x))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n094_run_four (a b : Int)
    (h0 : (¬ (((1 : Int) + b) ≤ ((1 : Int) + a))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n094_run_short (a b : Int)
    (h0 : ((((2 : Int) + ((2 : Int) * b)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < ((2 : Int) + ((2 : Int) * b))) ∨ ((2 : Int) > ((1 : Int) + a)) ∨ ((2 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ ((((1 : Int) + a) - ((1 : Int) + b)) < b)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n094_run_nonnegative (a b : Int)
    (h0 : (¬ (((1 : Int) + b) ≥ (0 : Int))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n094_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_4161 a b) ∨ (fact_9fdb227ae99d_4163 a b) ∨ (fact_9fdb227ae99d_5344 a b) ∨ (fact_9fdb227ae99d_5959 a b) ∨ (fact_9fdb227ae99d_5030 a b) ∨ (fact_9fdb227ae99d_4165 a b) ∨ ((((-1 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((-1 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (((1 : Int) + b) - (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + b) - (1 : Int)))) ∨ (((4 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + b) - (1 : Int))) ∧ ((((1 : Int) + b) - (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_4313 a b) ∨ ((((-1 : Int) ≥ ((-2 : Int) - b)) ∧ ((-1 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (((1 : Int) + b) - (1 : Int))) ∧ ((((1 : Int) + b) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-2 : Int)) ∧ ((((1 : Int) + a) - a) ≤ (((1 : Int) + b) - (1 : Int))) ∧ ((((1 : Int) + b) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n094_run_right (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_4160 a b) ∨ (fact_9fdb227ae99d_4162 a b) ∨ (fact_9fdb227ae99d_5343 a b) ∨ (fact_9fdb227ae99d_5958 a b) ∨ (fact_9fdb227ae99d_5029 a b) ∨ (fact_9fdb227ae99d_4164 a b) ∨ ((((-1 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((-1 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((4 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_4312 a b) ∨ ((((-1 : Int) ≥ ((-2 : Int) - b)) ∧ ((-1 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-2 : Int)) ∧ ((((1 : Int) + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n094_run_tall (a b : Int)
    (h0 : (a ≥ b))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (¬ ((((((1 : Int) + b) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_9fdb227ae99d_7450 a b) ∨ (fact_9fdb227ae99d_7448 a b))) ∨ (((((1 : Int) + b) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ (fact_9fdb227ae99d_7450 a b) ∧ (fact_9fdb227ae99d_7448 a b)) ∨ ((((1 : Int) + b) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = (((1 : Int) + b) + (1 : Int))) ∧ (fact_9fdb227ae99d_7450 a b) ∧ (fact_9fdb227ae99d_7448 a b) ∧ (((fact_9fdb227ae99d_4958 a b) ∨ (fact_9fdb227ae99d_4975 a b) ∨ (fact_9fdb227ae99d_5739 a b) ∨ (fact_9fdb227ae99d_6485 a b) ∨ (fact_9fdb227ae99d_5523 a b) ∨ (fact_9fdb227ae99d_5003 a b) ∨ (fact_9fdb227ae99d_5021 a b) ∨ (fact_9fdb227ae99d_5050 a b) ∨ (fact_9fdb227ae99d_5555 a b)) ∨ ((fact_9fdb227ae99d_4957 a b) ∨ (fact_9fdb227ae99d_4974 a b) ∨ (fact_9fdb227ae99d_5738 a b) ∨ (fact_9fdb227ae99d_6484 a b) ∨ (fact_9fdb227ae99d_5522 a b) ∨ (fact_9fdb227ae99d_5002 a b) ∨ (fact_9fdb227ae99d_5020 a b) ∨ (fact_9fdb227ae99d_5049 a b) ∨ (fact_9fdb227ae99d_5554 a b)))) ∨ ((fact_9fdb227ae99d_7450 a b) ∧ (fact_9fdb227ae99d_7448 a b) ∧ ((fact_9fdb227ae99d_4958 a b) ∨ (fact_9fdb227ae99d_4975 a b) ∨ (fact_9fdb227ae99d_5739 a b) ∨ (fact_9fdb227ae99d_6485 a b) ∨ (fact_9fdb227ae99d_5523 a b) ∨ (fact_9fdb227ae99d_5003 a b) ∨ (fact_9fdb227ae99d_5021 a b) ∨ (fact_9fdb227ae99d_5050 a b) ∨ (fact_9fdb227ae99d_5555 a b)) ∧ ((fact_9fdb227ae99d_4957 a b) ∨ (fact_9fdb227ae99d_4974 a b) ∨ (fact_9fdb227ae99d_5738 a b) ∨ (fact_9fdb227ae99d_6484 a b) ∨ (fact_9fdb227ae99d_5522 a b) ∨ (fact_9fdb227ae99d_5002 a b) ∨ (fact_9fdb227ae99d_5020 a b) ∨ (fact_9fdb227ae99d_5049 a b) ∨ (fact_9fdb227ae99d_5554 a b))))))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n094_run_empty (a b run_x : Int)
    (h0 : (((1 : Int) + b) ≤ run_x))
    (h1 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + b))))
    (h2 : (run_x ≤ ((1 : Int) + a)))
    (h3 : ((fact_9fdb227ae99d_2500 a b run_x) ∨ (fact_9fdb227ae99d_2501 a b run_x) ∨ (fact_9fdb227ae99d_3084 a b run_x) ∨ (fact_9fdb227ae99d_3594 a b run_x) ∨ (fact_9fdb227ae99d_3010 a b run_x) ∨ (fact_9fdb227ae99d_2502 a b run_x) ∨ ((((-1 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((-1 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_2569 a b run_x) ∨ ((((-1 : Int) ≥ ((-2 : Int) - b)) ∧ ((-1 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-2 : Int)) ∧ ((((1 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + a) + (0 : Int)))))))
    (h4 : (b = (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n094_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3254 a b run_x) ∨ (fact_9fdb227ae99d_3255 a b run_x) ∨ (fact_9fdb227ae99d_3877 a b run_x) ∨ (fact_9fdb227ae99d_5319 a b run_x) ∨ (fact_9fdb227ae99d_3591 a b run_x) ∨ (fact_9fdb227ae99d_3256 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ ((-1 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((-1 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_3267 a b run_x) ∨ (((((-2 : Int) - b) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ ((-1 : Int) - (1 : Int))) ∧ ((-2 : Int) ≥ ((-1 : Int) - (1 : Int))) ∧ ((((1 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + a) + (0 : Int))))))))
    (h1 : (b = (5 : Int)))
    (h2 : (((1 : Int) + b) ≤ run_x))
    (h3 : (run_x ≤ ((1 : Int) + a)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n095_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_29 a b))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n095_empty (a b : Int)
    (h0 : (a ≥ b))
    (h1 : ((fact_9fdb227ae99d_3086 a b) ∨ (fact_9fdb227ae99d_3087 a b) ∨ (fact_9fdb227ae99d_3593 a b) ∨ (fact_9fdb227ae99d_5028 a b) ∨ (fact_9fdb227ae99d_3331 a b) ∨ ((((-1 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((-1 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((1 : Int) + b)) ∧ ((2 : Int) ≥ ((1 : Int) + b))) ∨ (((3 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((1 : Int) + b)) ∧ (((1 : Int) + b) ≤ ((2 : Int) + b)))) ∨ ((((-1 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((-1 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((1 : Int) + b)) ∧ ((3 : Int) ≥ ((1 : Int) + b))) ∨ (((4 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((1 : Int) + b)) ∧ (((1 : Int) + b) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_3125 a b) ∨ (fact_9fdb227ae99d_3127 a b)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n095_o0 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h6 : (fact_9fdb227ae99d_1974 a b jx jy))
    (h7 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h8 : (b = (5 : Int)))
    (h9 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n095_o1 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1977 a b jx jy))
    (h1 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - a))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b = (5 : Int)))
    (h5 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n095_o2 (a b jx jy : Int)
    (h0 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - b))))
    (h1 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - b))))
    (h2 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (fact_9fdb227ae99d_1979 a b jx jy))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (fact_9fdb227ae99d_107 a b))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n095_o3 (a b jx jy : Int)
    (h0 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h1 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h7 : (b = (5 : Int)))
    (h8 : (fact_9fdb227ae99d_1980 a b jx jy))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n095_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (fact_9fdb227ae99d_1981 a b jx jy))
    (h5 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - a))))
    (h6 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n095_o5 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h7 : (fact_9fdb227ae99d_1978 a b jx jy))
    (h8 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n095_o6 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_1976 a b jx jy))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h6 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n095_o7 (a b jx jy : Int)
    (h0 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - b))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_1975 a b jx jy))
    (h4 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h8 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h9 : ((jy - b) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n096_run_four (a b : Int)
    (h0 : (¬ ((-2 : Int) ≥ ((-1 : Int) + ((-1 : Int) * b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n096_run_short (a b : Int)
    (h0 : (¬ (((-2 : Int) - ((-1 : Int) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n096_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n096_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_5683 a b) ∨ (fact_9fdb227ae99d_5696 a b) ∨ (fact_9fdb227ae99d_6364 a b) ∨ (fact_9fdb227ae99d_6960 a b) ∨ (fact_9fdb227ae99d_6103 a b) ∨ (fact_9fdb227ae99d_5711 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((4 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_5755 a b) ∨ (fact_9fdb227ae99d_6978 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n096_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3411 a b) ∨ (fact_9fdb227ae99d_3429 a b) ∨ (fact_9fdb227ae99d_4504 a b) ∨ (fact_9fdb227ae99d_5588 a b) ∨ (fact_9fdb227ae99d_4128 a b) ∨ (fact_9fdb227ae99d_3457 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((-2 : Int) + (1 : Int))) ∧ (((-2 : Int) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ ((-2 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((-2 : Int) + (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_3495 a b) ∨ (fact_9fdb227ae99d_5722 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n096_run_tall (a b : Int)
    (h0 : (¬ ((((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7665 a b) ∨ (fact_9fdb227ae99d_7398 a b))) ∨ (((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) + (2 : Int))) ∧ (fact_9fdb227ae99d_7665 a b) ∧ (fact_9fdb227ae99d_7398 a b)) ∨ ((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) + (4 : Int))) ∨ (((-2 : Int) = (((-1 : Int) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_9fdb227ae99d_7665 a b) ∧ (fact_9fdb227ae99d_7398 a b) ∧ (((fact_9fdb227ae99d_6013 a b) ∨ (fact_9fdb227ae99d_6051 a b) ∨ (fact_9fdb227ae99d_6813 a b) ∨ (fact_9fdb227ae99d_7025 a b) ∨ (fact_9fdb227ae99d_6630 a b) ∨ (fact_9fdb227ae99d_6110 a b) ∨ (fact_9fdb227ae99d_6123 a b) ∨ (fact_9fdb227ae99d_6199 a b) ∨ (fact_9fdb227ae99d_7072 a b)) ∨ ((fact_9fdb227ae99d_4061 a b) ∨ (fact_9fdb227ae99d_4089 a b) ∨ (fact_9fdb227ae99d_5295 a b) ∨ (fact_9fdb227ae99d_5910 a b) ∨ (fact_9fdb227ae99d_4993 a b) ∨ (fact_9fdb227ae99d_4135 a b) ∨ (fact_9fdb227ae99d_4152 a b) ∨ (fact_9fdb227ae99d_4200 a b) ∨ (fact_9fdb227ae99d_6143 a b)))) ∨ ((fact_9fdb227ae99d_7665 a b) ∧ (fact_9fdb227ae99d_7398 a b) ∧ ((fact_9fdb227ae99d_6013 a b) ∨ (fact_9fdb227ae99d_6051 a b) ∨ (fact_9fdb227ae99d_6813 a b) ∨ (fact_9fdb227ae99d_7025 a b) ∨ (fact_9fdb227ae99d_6630 a b) ∨ (fact_9fdb227ae99d_6110 a b) ∨ (fact_9fdb227ae99d_6123 a b) ∨ (fact_9fdb227ae99d_6199 a b) ∨ (fact_9fdb227ae99d_7072 a b)) ∧ ((fact_9fdb227ae99d_4061 a b) ∨ (fact_9fdb227ae99d_4089 a b) ∨ (fact_9fdb227ae99d_5295 a b) ∨ (fact_9fdb227ae99d_5910 a b) ∨ (fact_9fdb227ae99d_4993 a b) ∨ (fact_9fdb227ae99d_4135 a b) ∨ (fact_9fdb227ae99d_4152 a b) ∨ (fact_9fdb227ae99d_4200 a b) ∨ (fact_9fdb227ae99d_6143 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n096_run_empty (a b run_x : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((-2 : Int) ≥ run_x))
    (h2 : ((fact_9fdb227ae99d_2365 a b run_x) ∨ (fact_9fdb227ae99d_2382 a b run_x) ∨ (fact_9fdb227ae99d_3038 a b run_x) ∨ (fact_9fdb227ae99d_3479 a b run_x) ∨ (fact_9fdb227ae99d_2945 a b run_x) ∨ (fact_9fdb227ae99d_2400 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_2460 a b run_x) ∨ (fact_9fdb227ae99d_3606 a b run_x)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((-1 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n096_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3177 a b run_x) ∨ (fact_9fdb227ae99d_3187 a b run_x) ∨ (fact_9fdb227ae99d_3729 a b run_x) ∨ (fact_9fdb227ae99d_5194 a b run_x) ∨ (fact_9fdb227ae99d_3552 a b run_x) ∨ (fact_9fdb227ae99d_3199 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_3213 a b run_x) ∨ (fact_9fdb227ae99d_5350 a b run_x))))
    (h1 : (((-1 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h2 : ((-2 : Int) ≥ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n097_run_four (a b : Int)
    (h0 : (¬ ((-1 : Int) ≥ ((-1 : Int) * b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n097_run_short (a b : Int)
    (h0 : (¬ (((-1 : Int) - ((-1 : Int) * b)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n097_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n097_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_4058 a b) ∨ (fact_9fdb227ae99d_4086 a b) ∨ (fact_9fdb227ae99d_5292 a b) ∨ (fact_9fdb227ae99d_5907 a b) ∨ (fact_9fdb227ae99d_4990 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((-1 : Int) * b) - (1 : Int))) ∧ ((((-1 : Int) * b) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ (((3 : Int) ≤ (((-1 : Int) * b) - (1 : Int))) ∧ ((3 : Int) ≥ (((-1 : Int) * b) - (1 : Int))) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((-1 : Int) * b) - (1 : Int))) ∧ ((((-1 : Int) * b) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ (((-1 : Int) * b) - (1 : Int))) ∧ ((4 : Int) ≥ (((-1 : Int) * b) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_6130 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n097_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3410 a b) ∨ (fact_9fdb227ae99d_3428 a b) ∨ (fact_9fdb227ae99d_4503 a b) ∨ (fact_9fdb227ae99d_5587 a b) ∨ (fact_9fdb227ae99d_4127 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((-1 : Int) + (1 : Int))) ∧ (((-1 : Int) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ (((3 : Int) ≤ ((-1 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((-1 : Int) + (1 : Int))) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((-1 : Int) + (1 : Int))) ∧ (((-1 : Int) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ ((-1 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((-1 : Int) + (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_5716 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n097_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ ((((-1 : Int) ≥ (((-1 : Int) * b) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7347 a b) ∨ (fact_9fdb227ae99d_7299 a b))) ∨ (((-1 : Int) ≥ (((-1 : Int) * b) + (2 : Int))) ∧ (fact_9fdb227ae99d_7347 a b) ∧ (fact_9fdb227ae99d_7299 a b)) ∨ ((-1 : Int) ≥ (((-1 : Int) * b) + (4 : Int))) ∨ (((-1 : Int) = (((-1 : Int) * b) + (1 : Int))) ∧ (fact_9fdb227ae99d_7347 a b) ∧ (fact_9fdb227ae99d_7299 a b) ∧ (((fact_9fdb227ae99d_4955 a b) ∨ (fact_9fdb227ae99d_4972 a b) ∨ (fact_9fdb227ae99d_5736 a b) ∨ (fact_9fdb227ae99d_6482 a b) ∨ (fact_9fdb227ae99d_5520 a b) ∨ (fact_9fdb227ae99d_4998 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((-1 : Int) * b) - (1 : Int))) ∧ ((((-1 : Int) * b) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((2 : Int) + a)) ∧ ((3 : Int) ≥ ((2 : Int) + a))) ∨ (((4 : Int) ≤ (((-1 : Int) * b) - (1 : Int))) ∧ ((4 : Int) ≥ (((-1 : Int) * b) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_6659 a b)) ∨ ((fact_9fdb227ae99d_4059 a b) ∨ (fact_9fdb227ae99d_4087 a b) ∨ (fact_9fdb227ae99d_5293 a b) ∨ (fact_9fdb227ae99d_5908 a b) ∨ (fact_9fdb227ae99d_4991 a b) ∨ (fact_9fdb227ae99d_4132 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((-1 : Int) + (1 : Int))) ∧ (((-1 : Int) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((2 : Int) + a)) ∧ ((3 : Int) ≥ ((2 : Int) + a))) ∨ (((4 : Int) ≤ ((-1 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((-1 : Int) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_6131 a b)))) ∨ ((fact_9fdb227ae99d_7347 a b) ∧ (fact_9fdb227ae99d_7299 a b) ∧ ((fact_9fdb227ae99d_4955 a b) ∨ (fact_9fdb227ae99d_4972 a b) ∨ (fact_9fdb227ae99d_5736 a b) ∨ (fact_9fdb227ae99d_6482 a b) ∨ (fact_9fdb227ae99d_5520 a b) ∨ (fact_9fdb227ae99d_4998 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((-1 : Int) * b) - (1 : Int))) ∧ ((((-1 : Int) * b) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((2 : Int) + a)) ∧ ((3 : Int) ≥ ((2 : Int) + a))) ∨ (((4 : Int) ≤ (((-1 : Int) * b) - (1 : Int))) ∧ ((4 : Int) ≥ (((-1 : Int) * b) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_6659 a b)) ∧ ((fact_9fdb227ae99d_4059 a b) ∨ (fact_9fdb227ae99d_4087 a b) ∨ (fact_9fdb227ae99d_5293 a b) ∨ (fact_9fdb227ae99d_5908 a b) ∨ (fact_9fdb227ae99d_4991 a b) ∨ (fact_9fdb227ae99d_4132 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((-1 : Int) + (1 : Int))) ∧ (((-1 : Int) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((2 : Int) + a)) ∧ ((3 : Int) ≥ ((2 : Int) + a))) ∨ (((4 : Int) ≤ ((-1 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((-1 : Int) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_6131 a b))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n097_run_empty (a b run_x : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (((-1 : Int) * b) ≤ run_x))
    (h2 : ((fact_9fdb227ae99d_2365 a b run_x) ∨ (fact_9fdb227ae99d_2382 a b run_x) ∨ (fact_9fdb227ae99d_3038 a b run_x) ∨ (fact_9fdb227ae99d_3479 a b run_x) ∨ (fact_9fdb227ae99d_2945 a b run_x) ∨ (fact_9fdb227ae99d_2400 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_3603 a b run_x)))
    (h3 : ((-1 : Int) ≥ run_x))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n097_run_floor (a b run_x : Int)
    (h0 : ((-1 : Int) ≥ run_x))
    (h1 : (¬ ((fact_9fdb227ae99d_3177 a b run_x) ∨ (fact_9fdb227ae99d_3187 a b run_x) ∨ (fact_9fdb227ae99d_3729 a b run_x) ∨ (fact_9fdb227ae99d_5194 a b run_x) ∨ (fact_9fdb227ae99d_3552 a b run_x) ∨ (fact_9fdb227ae99d_3199 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_5347 a b run_x))))
    (h2 : (((-1 : Int) * b) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n098_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≤ a)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n098_run_short (a b : Int)
    (h0 : (¬ ((a - (3 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n098_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n098_run_left (a b : Int)
    (h0 : (¬ (((((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ ((((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((5 : Int) ≥ (((1 : Int) + b + a) - a)) ∧ ((5 : Int) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((5 : Int) ≥ ((1 : Int) + b + a)) ∧ ((5 : Int) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - b)) ∧ ((5 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((5 : Int) ≥ ((2 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((5 : Int) ≥ ((2 : Int) - b)) ∧ ((5 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ ((((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)) ∧ (((3 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n098_run_right (a b : Int)
    (h0 : (¬ (((((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (a + (1 : Int))) ∧ ((0 : Int) ≥ (a + (1 : Int)))) ∨ (((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ ((((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ (((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((5 : Int) ≥ (((1 : Int) + b + a) - a)) ∧ ((5 : Int) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (a + (1 : Int))) ∧ ((0 : Int) ≥ (a + (1 : Int)))) ∨ (((5 : Int) ≥ ((1 : Int) + b + a)) ∧ ((5 : Int) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - b)) ∧ ((5 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ (((5 : Int) ≥ ((2 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((5 : Int) ≥ ((2 : Int) - b)) ∧ ((5 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ ((((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)) ∧ (((3 : Int) + b) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + b) - b) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n098_run_tall (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a > b))
    (h5 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_9fdb227ae99d_7236 a b) ∨ (fact_9fdb227ae99d_7217 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_9fdb227ae99d_7236 a b) ∧ (fact_9fdb227ae99d_7217 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7236 a b) ∧ (fact_9fdb227ae99d_7217 a b) ∧ (((fact_9fdb227ae99d_3775 a b) ∨ (fact_9fdb227ae99d_3807 a b) ∨ (fact_9fdb227ae99d_5185 a b) ∨ (fact_9fdb227ae99d_5863 a b) ∨ (((((2 : Int) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3838 a b) ∨ (fact_9fdb227ae99d_4695 a b)) ∨ ((fact_9fdb227ae99d_3272 a b) ∨ (fact_9fdb227ae99d_3278 a b) ∨ (fact_9fdb227ae99d_4197 a b) ∨ (fact_9fdb227ae99d_5369 a b) ∨ (((((2 : Int) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3282 a b) ∨ (fact_9fdb227ae99d_3659 a b)))) ∨ ((fact_9fdb227ae99d_7236 a b) ∧ (fact_9fdb227ae99d_7217 a b) ∧ ((fact_9fdb227ae99d_3775 a b) ∨ (fact_9fdb227ae99d_3807 a b) ∨ (fact_9fdb227ae99d_5185 a b) ∨ (fact_9fdb227ae99d_5863 a b) ∨ (((((2 : Int) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3838 a b) ∨ (fact_9fdb227ae99d_4695 a b)) ∧ ((fact_9fdb227ae99d_3272 a b) ∨ (fact_9fdb227ae99d_3278 a b) ∨ (fact_9fdb227ae99d_4197 a b) ∨ (fact_9fdb227ae99d_5369 a b) ∨ (((((2 : Int) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3282 a b) ∨ (fact_9fdb227ae99d_3659 a b))))))
    (h6 : (a ≥ b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n098_run_empty (a b run_x : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (run_x ≤ a))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : ((fact_9fdb227ae99d_2449 a b run_x) ∨ (fact_9fdb227ae99d_2450 a b run_x) ∨ (fact_9fdb227ae99d_3073 a b run_x) ∨ (fact_9fdb227ae99d_3572 a b run_x) ∨ ((((5 : Int) ≥ ((2 : Int) - b)) ∧ ((5 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ ((((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)) ∧ (((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((((3 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + (0 : Int)))))))
    (h6 : ((3 : Int) ≤ run_x))
    (h7 : ((((2 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((2 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + a) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n098_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ a))
    (h1 : ((((2 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((2 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + a) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h2 : ((3 : Int) ≤ run_x))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (¬ ((fact_9fdb227ae99d_3175 a b run_x) ∨ (fact_9fdb227ae99d_3185 a b run_x) ∨ (fact_9fdb227ae99d_3728 a b run_x) ∨ (fact_9fdb227ae99d_5193 a b run_x) ∨ (((((2 : Int) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a)) ∧ (((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n099_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (¬ (((-1 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((-1 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n099_empty (a b : Int)
    (h0 : (((0 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((0 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + a)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int)))))
    (h1 : ((fact_9fdb227ae99d_2858 a b) ∨ (fact_9fdb227ae99d_2860 a b) ∨ (fact_9fdb227ae99d_3258 a b) ∨ (fact_9fdb227ae99d_4159 a b) ∨ (fact_9fdb227ae99d_3090 a b) ∨ ((((-1 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((-1 : Int) ≤ ((3 : Int) + b)) ∧ ((1 : Int) ≥ ((2 : Int) + a)) ∧ ((1 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (3 : Int)) ∧ ((1 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((1 : Int) ≤ (((2 : Int) + a) + (0 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n099_o0 (a b jx jy : Int)
    (h0 : (¬ (((jx = ((-1 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n099_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n099_o2 (a b jx jy : Int)
    (h0 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h1 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (fact_9fdb227ae99d_2924 a b jy))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n099_o3 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h4 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h5 : (fact_9fdb227ae99d_2268 a b jx jy))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n099_o4 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (b = (5 : Int)))
    (h2 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h3 : (fact_9fdb227ae99d_2922 a b jy))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n099_o5 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_2269 a b jx jy))
    (h2 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n099_o6 (a b jx jy : Int)
    (h0 : (¬ (((jx = ((-1 : Int) + ((-1 : Int) * b))) ∧ ((1 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : (b = (5 : Int)))
    (h2 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n099_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n100_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((-1 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((0 : Int) ≥ (0 : Int)) ∧ ((-1 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((0 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n100_empty (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((fact_9fdb227ae99d_2857 a b) ∨ (fact_9fdb227ae99d_2859 a b) ∨ (fact_9fdb227ae99d_3257 a b) ∨ (fact_9fdb227ae99d_4158 a b) ∨ (fact_9fdb227ae99d_3089 a b) ∨ ((((-1 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((-1 : Int) ≤ ((3 : Int) + b)) ∧ ((0 : Int) ≥ ((2 : Int) + a)) ∧ ((0 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (3 : Int)) ∧ ((0 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((0 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_4393 a b)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((0 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((0 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + a)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n100_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < (((-1 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-1 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n100_o1 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (fact_9fdb227ae99d_2923 a b jy))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n100_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (fact_9fdb227ae99d_2924 a b jy))
    (h2 : (b = (5 : Int)))
    (h3 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n100_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < (((-1 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-1 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h6 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n100_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_9fdb227ae99d_2922 a b jy))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n100_o5 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h4 : (b = (5 : Int)))
    (h5 : ((jx < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jx < (((-1 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-1 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h8 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n100_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((jx < (((-1 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-1 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h4 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n100_o7 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_2925 a b jy))
    (h3 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n101_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (¬ (((-2 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n101_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (((1 : Int) + b) - b)) ∨ ((1 : Int) > (((1 : Int) + b) + (0 : Int)))))
    (h2 : (b = (5 : Int)))
    (h3 : ((fact_9fdb227ae99d_2863 a b) ∨ (fact_9fdb227ae99d_2865 a b) ∨ (fact_9fdb227ae99d_3259 a b) ∨ (fact_9fdb227ae99d_4166 a b) ∨ (fact_9fdb227ae99d_3098 a b) ∨ ((((-2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((3 : Int) + b)) ∧ ((1 : Int) ≥ ((2 : Int) + a)) ∧ ((1 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (3 : Int)) ∧ ((1 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((1 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3135 a b)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n101_o0 (a b jx jy : Int)
    (h0 : (((jx + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jx - (0 : Int))) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h1 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b) - b)) ∨ ((((1 : Int) + b) + (0 : Int)) < jy)))
    (h5 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (fact_9fdb227ae99d_7281 a b jx jy))
    (h10 : (¬ (((jx = ((-2 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n101_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b = (5 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n101_o2 (a b jx jy : Int)
    (h0 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < (jy - b))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (fact_9fdb227ae99d_2924 a b jy))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n101_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h8 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n101_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < (jy - a))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n101_o5 (a b jx jy : Int)
    (h0 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h1 : (b = (5 : Int)))
    (h2 : (¬ ((((-2 : Int) = jx) ∧ ((0 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n101_o6 (a b jx jy : Int)
    (h0 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n101_o7 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b) - b)) ∨ ((((1 : Int) + b) + (0 : Int)) < jy)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n102_run_four (a b : Int)
    (h0 : (¬ ((2 : Int) ≤ b)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n102_run_short (a b : Int)
    (h0 : (¬ ((b - (2 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n102_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n102_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5689 a b) ∨ (fact_9fdb227ae99d_5702 a b) ∨ (fact_9fdb227ae99d_6370 a b) ∨ (fact_9fdb227ae99d_6966 a b) ∨ (fact_9fdb227ae99d_6105 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((3 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((((2 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6218 a b) ∨ (fact_9fdb227ae99d_6977 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n102_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_5100 a b) ∨ (fact_9fdb227ae99d_5102 a b) ∨ (fact_9fdb227ae99d_5787 a b) ∨ (fact_9fdb227ae99d_6569 a b) ∨ (fact_9fdb227ae99d_5578 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((3 : Int) + b)) ∧ (((2 : Int) + a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((((2 : Int) + a) - a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_5613 a b) ∨ (fact_9fdb227ae99d_6756 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n102_run_tall (a b : Int)
    (h0 : (¬ (((((2 : Int) + (3 : Int)) ≤ b) ∧ ((fact_9fdb227ae99d_7537 a b) ∨ (fact_9fdb227ae99d_7434 a b))) ∨ ((((2 : Int) + (2 : Int)) ≤ b) ∧ (fact_9fdb227ae99d_7537 a b) ∧ (fact_9fdb227ae99d_7434 a b)) ∨ (((2 : Int) + (4 : Int)) ≤ b) ∨ ((b = ((2 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7537 a b) ∧ (fact_9fdb227ae99d_7434 a b) ∧ (((fact_9fdb227ae99d_6004 a b) ∨ (fact_9fdb227ae99d_6042 a b) ∨ (fact_9fdb227ae99d_6804 a b) ∨ (fact_9fdb227ae99d_7016 a b) ∨ (fact_9fdb227ae99d_6628 a b) ∨ (fact_9fdb227ae99d_6634 a b) ∨ (fact_9fdb227ae99d_6680 a b) ∨ (fact_9fdb227ae99d_7062 a b)) ∨ ((fact_9fdb227ae99d_5558 a b) ∨ (fact_9fdb227ae99d_5566 a b) ∨ (fact_9fdb227ae99d_6315 a b) ∨ (fact_9fdb227ae99d_6900 a b) ∨ (fact_9fdb227ae99d_5894 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + a) ≤ ((3 : Int) + b)) ∧ (((2 : Int) + a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((2 : Int) + a) - a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_5936 a b) ∨ (fact_9fdb227ae99d_6940 a b)))) ∨ ((fact_9fdb227ae99d_7537 a b) ∧ (fact_9fdb227ae99d_7434 a b) ∧ ((fact_9fdb227ae99d_6004 a b) ∨ (fact_9fdb227ae99d_6042 a b) ∨ (fact_9fdb227ae99d_6804 a b) ∨ (fact_9fdb227ae99d_7016 a b) ∨ (fact_9fdb227ae99d_6628 a b) ∨ (fact_9fdb227ae99d_6634 a b) ∨ (fact_9fdb227ae99d_6680 a b) ∨ (fact_9fdb227ae99d_7062 a b)) ∧ ((fact_9fdb227ae99d_5558 a b) ∨ (fact_9fdb227ae99d_5566 a b) ∨ (fact_9fdb227ae99d_6315 a b) ∨ (fact_9fdb227ae99d_6900 a b) ∨ (fact_9fdb227ae99d_5894 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + a) ≤ ((3 : Int) + b)) ∧ (((2 : Int) + a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((2 : Int) + a) - a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_5936 a b) ∨ (fact_9fdb227ae99d_6940 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n102_run_empty (a b run_x : Int)
    (h0 : ((2 : Int) ≤ run_x))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (run_x ≤ b))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((fact_9fdb227ae99d_3627 a b run_x) ∨ (fact_9fdb227ae99d_3636 a b run_x) ∨ (fact_9fdb227ae99d_5035 a b run_x) ∨ (fact_9fdb227ae99d_5788 a b run_x) ∨ (fact_9fdb227ae99d_4491 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((3 : Int) + b)) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_4521 a b run_x) ∨ (fact_9fdb227ae99d_5820 a b run_x)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n102_run_floor (a b run_x : Int)
    (h0 : ((2 : Int) ≤ run_x))
    (h1 : (¬ ((fact_9fdb227ae99d_5410 a b run_x) ∨ (fact_9fdb227ae99d_5413 a b run_x) ∨ (fact_9fdb227ae99d_5988 a b run_x) ∨ (fact_9fdb227ae99d_6841 a b run_x) ∨ (fact_9fdb227ae99d_5805 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((3 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_5811 a b run_x) ∨ (fact_9fdb227ae99d_6897 a b run_x))))
    (h2 : (run_x ≤ b))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n103_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((1 : Int) ≤ b)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n103_run_short (a b : Int)
    (h0 : (¬ ((b - (1 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n103_run_nonnegative (a b : Int)
    (h0 : (¬ ((1 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n103_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3581 a b) ∨ (fact_9fdb227ae99d_3585 a b) ∨ (fact_9fdb227ae99d_4718 a b) ∨ (fact_9fdb227ae99d_5748 a b) ∨ (fact_9fdb227ae99d_4385 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (-(3 : Int))) ∧ ((-(3 : Int)) ≤ ((3 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (-(3 : Int))) ∧ ((3 : Int) ≥ (-(3 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_4429 a b) ∨ (fact_9fdb227ae99d_3625 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n103_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3156 a b) ∨ (fact_9fdb227ae99d_3160 a b) ∨ (fact_9fdb227ae99d_3670 a b) ∨ (fact_9fdb227ae99d_5107 a b) ∨ (fact_9fdb227ae99d_3456 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (-(3 : Int))) ∧ ((-(3 : Int)) ≤ ((3 : Int) + b)) ∧ (((2 : Int) + a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (-(3 : Int))) ∧ ((3 : Int) ≥ (-(3 : Int))) ∧ ((((2 : Int) + a) - a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3506 a b) ∨ (fact_9fdb227ae99d_3169 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n103_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ (((((1 : Int) + (3 : Int)) ≤ b) ∧ ((fact_9fdb227ae99d_7323 a b) ∨ (fact_9fdb227ae99d_7267 a b))) ∨ ((((1 : Int) + (2 : Int)) ≤ b) ∧ (fact_9fdb227ae99d_7323 a b) ∧ (fact_9fdb227ae99d_7267 a b)) ∨ (((1 : Int) + (4 : Int)) ≤ b) ∨ ((b = ((1 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7323 a b) ∧ (fact_9fdb227ae99d_7267 a b) ∧ (((fact_9fdb227ae99d_4341 a b) ∨ (fact_9fdb227ae99d_4358 a b) ∨ (fact_9fdb227ae99d_5451 a b) ∨ (fact_9fdb227ae99d_6174 a b) ∨ (fact_9fdb227ae99d_5144 a b) ∨ (fact_9fdb227ae99d_5146 a b) ∨ (fact_9fdb227ae99d_5207 a b) ∨ (fact_9fdb227ae99d_4445 a b)) ∨ ((fact_9fdb227ae99d_3418 a b) ∨ (fact_9fdb227ae99d_3436 a b) ∨ (fact_9fdb227ae99d_4511 a b) ∨ (fact_9fdb227ae99d_5595 a b) ∨ (fact_9fdb227ae99d_4130 a b) ∨ (fact_9fdb227ae99d_4145 a b) ∨ (fact_9fdb227ae99d_4218 a b) ∨ (fact_9fdb227ae99d_3521 a b)))) ∨ ((fact_9fdb227ae99d_7323 a b) ∧ (fact_9fdb227ae99d_7267 a b) ∧ ((fact_9fdb227ae99d_4341 a b) ∨ (fact_9fdb227ae99d_4358 a b) ∨ (fact_9fdb227ae99d_5451 a b) ∨ (fact_9fdb227ae99d_6174 a b) ∨ (fact_9fdb227ae99d_5144 a b) ∨ (fact_9fdb227ae99d_5146 a b) ∨ (fact_9fdb227ae99d_5207 a b) ∨ (fact_9fdb227ae99d_4445 a b)) ∧ ((fact_9fdb227ae99d_3418 a b) ∨ (fact_9fdb227ae99d_3436 a b) ∨ (fact_9fdb227ae99d_4511 a b) ∨ (fact_9fdb227ae99d_5595 a b) ∨ (fact_9fdb227ae99d_4130 a b) ∨ (fact_9fdb227ae99d_4145 a b) ∨ (fact_9fdb227ae99d_4218 a b) ∨ (fact_9fdb227ae99d_3521 a b))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n103_run_empty (a b run_x : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((1 : Int) ≤ run_x))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (run_x ≤ b))
    (h5 : ((fact_9fdb227ae99d_2587 a b run_x) ∨ (fact_9fdb227ae99d_2592 a b run_x) ∨ (fact_9fdb227ae99d_3153 a b run_x) ∨ (fact_9fdb227ae99d_3673 a b run_x) ∨ (fact_9fdb227ae99d_3034 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ (-(3 : Int))) ∧ ((-(3 : Int)) ≤ ((3 : Int) + b)) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (-(3 : Int))) ∧ ((3 : Int) ≥ (-(3 : Int))) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3042 a b run_x) ∨ (fact_9fdb227ae99d_2713 a b run_x)))
    (h6 : (((-2 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-2 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + b))))
    (h7 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (((1 : Int) + b) - b)) ∨ ((1 : Int) > (((1 : Int) + b) + (0 : Int)))))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n103_run_floor (a b run_x : Int)
    (h0 : ((1 : Int) ≤ run_x))
    (h1 : (¬ ((fact_9fdb227ae99d_3320 a b run_x) ∨ (fact_9fdb227ae99d_3324 a b run_x) ∨ (fact_9fdb227ae99d_4335 a b run_x) ∨ (fact_9fdb227ae99d_5469 a b run_x) ∨ (fact_9fdb227ae99d_3719 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ (-((3 : Int) - (1 : Int)))) ∧ ((-((3 : Int) - (1 : Int))) ≤ ((3 : Int) + b)) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (-((3 : Int) - (1 : Int)))) ∧ ((3 : Int) ≥ (-((3 : Int) - (1 : Int)))) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3741 a b run_x) ∨ (fact_9fdb227ae99d_3358 a b run_x))))
    (h2 : (run_x ≤ b))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n104_point (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_0 a b))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n104_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (a ≥ b))
    (h2 : ((fact_9fdb227ae99d_3050 a b) ∨ (fact_9fdb227ae99d_3052 a b) ∨ (fact_9fdb227ae99d_3562 a b) ∨ (fact_9fdb227ae99d_4700 a b) ∨ (fact_9fdb227ae99d_3290 a b) ∨ (fact_9fdb227ae99d_3291 a b) ∨ (fact_9fdb227ae99d_3114 a b)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n104_o0 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_1604 a b jx jy))
    (h3 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h7 : (b = (5 : Int)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n104_o1 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (fact_9fdb227ae99d_1609 a b jx jy))
    (h6 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - a))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n104_o2 (a b jx jy : Int)
    (h0 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - b))))
    (h3 : (fact_9fdb227ae99d_1613 a b jx jy))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n104_o3 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h3 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (fact_9fdb227ae99d_1616 a b jx jy))
    (h7 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n104_o4 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (fact_9fdb227ae99d_2922 a b jy))
    (h4 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (fact_9fdb227ae99d_1617 a b jx jy))
    (h6 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - a))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n104_o5 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b = (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_1612 a b jx jy))
    (h6 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h7 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h8 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n104_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : (b = (5 : Int)))
    (h3 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (fact_9fdb227ae99d_1608 a b jx jy))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n104_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - b))))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (fact_9fdb227ae99d_1605 a b jx jy))
    (h8 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n105_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ (((-2 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n105_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_2863 a b) ∨ (fact_9fdb227ae99d_2865 a b) ∨ (fact_9fdb227ae99d_3259 a b) ∨ (fact_9fdb227ae99d_4166 a b) ∨ (fact_9fdb227ae99d_3098 a b) ∨ ((((-2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((3 : Int) + b)) ∧ ((1 : Int) ≥ ((2 : Int) + a)) ∧ ((1 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (3 : Int)) ∧ ((1 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((1 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_2957 a b)))
    (h1 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + a))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n105_o0 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b = (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (¬ (((jx = ((-2 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h7 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n105_o1 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n105_o2 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (¬ ((((-2 : Int) = jx) ∧ (jy = ((1 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h2 : (b = (5 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (fact_9fdb227ae99d_2924 a b jy))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n105_o3 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h3 : (¬ ((((-2 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n105_o4 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (¬ ((((-2 : Int) = jx) ∧ (jy = ((1 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_2922 a b jy))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n105_o5 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_7278 a b jx jy))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h3 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n105_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h7 : (¬ (((jx = ((-2 : Int) + ((-1 : Int) * b))) ∧ ((1 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n105_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n106_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((-2 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n106_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_2864 a b) ∨ (fact_9fdb227ae99d_2866 a b) ∨ (fact_9fdb227ae99d_3260 a b) ∨ (fact_9fdb227ae99d_4167 a b) ∨ (fact_9fdb227ae99d_3099 a b) ∨ ((((-2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((3 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) + a)) ∧ ((2 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (3 : Int)) ∧ ((2 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_2958 a b) ∨ (fact_9fdb227ae99d_4394 a b)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n106_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b = (5 : Int)))
    (h6 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h7 : ((jx < ((-2 : Int) + ((-1 : Int) * a))) ∨ (((-2 : Int) + ((-1 : Int) * a)) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n106_o1 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n106_o2 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b = (5 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (¬ ((((-2 : Int) = jx) ∧ (jy = ((2 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h4 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (((jx + (0 : Int)) < ((-2 : Int) + ((-1 : Int) * a))) ∨ (((-2 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n106_o3 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n106_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h2 : (b = (5 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - a))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n106_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((jx + (0 : Int)) < ((-2 : Int) + ((-1 : Int) * a))) ∨ (((-2 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h6 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h7 : (b = (5 : Int)))
    (h8 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n106_o6 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (¬ (((jx = ((-2 : Int) + ((-1 : Int) * b))) ∧ ((2 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h7 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h8 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n106_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n107_run_four (a b : Int)
    (h0 : (¬ ((2 : Int) ≤ ((-1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n107_run_short (a b : Int)
    (h0 : (¬ ((((-1 : Int) + a) - (2 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n107_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n107_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5689 a b) ∨ (fact_9fdb227ae99d_5702 a b) ∨ (fact_9fdb227ae99d_6370 a b) ∨ (fact_9fdb227ae99d_6966 a b) ∨ (fact_9fdb227ae99d_6105 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((3 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((((2 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_5763 a b) ∨ (fact_9fdb227ae99d_6977 a b) ∨ (fact_9fdb227ae99d_6261 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n107_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (¬ ((fact_9fdb227ae99d_6311 a b) ∨ (fact_9fdb227ae99d_6312 a b) ∨ (fact_9fdb227ae99d_6882 a b) ∨ (fact_9fdb227ae99d_7057 a b) ∨ (fact_9fdb227ae99d_6749 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((3 : Int) + b)) ∧ (((2 : Int) + a) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((((2 : Int) + a) - a) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6328 a b) ∨ (fact_9fdb227ae99d_7119 a b) ∨ (fact_9fdb227ae99d_6779 a b))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n107_run_tall (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a > b))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (¬ (((((2 : Int) + (3 : Int)) ≤ ((-1 : Int) + a)) ∧ ((fact_9fdb227ae99d_7685 a b) ∨ (fact_9fdb227ae99d_7768 a b))) ∨ ((((2 : Int) + (2 : Int)) ≤ ((-1 : Int) + a)) ∧ (fact_9fdb227ae99d_7685 a b) ∧ (fact_9fdb227ae99d_7768 a b)) ∨ (((2 : Int) + (4 : Int)) ≤ ((-1 : Int) + a)) ∨ ((((-1 : Int) + a) = ((2 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7685 a b) ∧ (fact_9fdb227ae99d_7768 a b) ∧ (((fact_9fdb227ae99d_6004 a b) ∨ (fact_9fdb227ae99d_6042 a b) ∨ (fact_9fdb227ae99d_6804 a b) ∨ (fact_9fdb227ae99d_7016 a b) ∨ (fact_9fdb227ae99d_6628 a b) ∨ (fact_9fdb227ae99d_6634 a b) ∨ (fact_9fdb227ae99d_6220 a b) ∨ (fact_9fdb227ae99d_7062 a b) ∨ (fact_9fdb227ae99d_6689 a b)) ∨ ((fact_9fdb227ae99d_6741 a b) ∨ (fact_9fdb227ae99d_6745 a b) ∨ (fact_9fdb227ae99d_6995 a b) ∨ (fact_9fdb227ae99d_7154 a b) ∨ (fact_9fdb227ae99d_6934 a b) ∨ (fact_9fdb227ae99d_6936 a b) ∨ (fact_9fdb227ae99d_6776 a b) ∨ (fact_9fdb227ae99d_7164 a b) ∨ (fact_9fdb227ae99d_6969 a b)))) ∨ ((fact_9fdb227ae99d_7685 a b) ∧ (fact_9fdb227ae99d_7768 a b) ∧ ((fact_9fdb227ae99d_6004 a b) ∨ (fact_9fdb227ae99d_6042 a b) ∨ (fact_9fdb227ae99d_6804 a b) ∨ (fact_9fdb227ae99d_7016 a b) ∨ (fact_9fdb227ae99d_6628 a b) ∨ (fact_9fdb227ae99d_6634 a b) ∨ (fact_9fdb227ae99d_6220 a b) ∨ (fact_9fdb227ae99d_7062 a b) ∨ (fact_9fdb227ae99d_6689 a b)) ∧ ((fact_9fdb227ae99d_6741 a b) ∨ (fact_9fdb227ae99d_6745 a b) ∨ (fact_9fdb227ae99d_6995 a b) ∨ (fact_9fdb227ae99d_7154 a b) ∨ (fact_9fdb227ae99d_6934 a b) ∨ (fact_9fdb227ae99d_6936 a b) ∨ (fact_9fdb227ae99d_6776 a b) ∨ (fact_9fdb227ae99d_7164 a b) ∨ (fact_9fdb227ae99d_6969 a b))))))
    (h6 : (a ≥ b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n107_run_empty (a b run_x : Int)
    (h0 : ((fact_9fdb227ae99d_3627 a b run_x) ∨ (fact_9fdb227ae99d_3636 a b run_x) ∨ (fact_9fdb227ae99d_5035 a b run_x) ∨ (fact_9fdb227ae99d_5788 a b run_x) ∨ (fact_9fdb227ae99d_4491 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((3 : Int) + b)) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3686 a b run_x) ∨ (fact_9fdb227ae99d_5820 a b run_x) ∨ (fact_9fdb227ae99d_4522 a b run_x)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : ((2 : Int) ≤ run_x))
    (h6 : (run_x ≤ ((-1 : Int) + a)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a ≥ (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n107_run_floor (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (run_x ≤ ((-1 : Int) + a)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((2 : Int) ≤ run_x))
    (h4 : (¬ ((fact_9fdb227ae99d_5410 a b run_x) ∨ (fact_9fdb227ae99d_5413 a b run_x) ∨ (fact_9fdb227ae99d_5988 a b run_x) ∨ (fact_9fdb227ae99d_6841 a b run_x) ∨ (fact_9fdb227ae99d_5805 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((3 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_5484 a b run_x) ∨ (fact_9fdb227ae99d_6897 a b run_x) ∨ (fact_9fdb227ae99d_5812 a b run_x))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n108_run_four (a b : Int)
    (h0 : (¬ ((-2 : Int) ≥ ((-1 : Int) + ((-1 : Int) * b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n108_run_short (a b : Int)
    (h0 : (¬ (((-2 : Int) - ((-1 : Int) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n108_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n108_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_5684 a b) ∨ (fact_9fdb227ae99d_5697 a b) ∨ (fact_9fdb227ae99d_6365 a b) ∨ (fact_9fdb227ae99d_6961 a b) ∨ (fact_9fdb227ae99d_6104 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≥ ((2 : Int) + a)) ∧ ((3 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_5761 a b) ∨ (fact_9fdb227ae99d_6976 a b) ∨ (fact_9fdb227ae99d_6979 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n108_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3412 a b) ∨ (fact_9fdb227ae99d_3430 a b) ∨ (fact_9fdb227ae99d_4505 a b) ∨ (fact_9fdb227ae99d_5589 a b) ∨ (fact_9fdb227ae99d_4129 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((-2 : Int) + (1 : Int))) ∧ (((-2 : Int) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≥ ((2 : Int) + a)) ∧ ((3 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((-2 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((-2 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3508 a b) ∨ (fact_9fdb227ae99d_5717 a b) ∨ (fact_9fdb227ae99d_5723 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n108_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ ((((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7717 a b) ∨ (fact_9fdb227ae99d_7422 a b))) ∨ (((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) + (2 : Int))) ∧ (fact_9fdb227ae99d_7717 a b) ∧ (fact_9fdb227ae99d_7422 a b)) ∨ ((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) + (4 : Int))) ∨ (((-2 : Int) = (((-1 : Int) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_9fdb227ae99d_7717 a b) ∧ (fact_9fdb227ae99d_7422 a b) ∧ (((fact_9fdb227ae99d_6015 a b) ∨ (fact_9fdb227ae99d_6053 a b) ∨ (fact_9fdb227ae99d_6815 a b) ∨ (fact_9fdb227ae99d_7027 a b) ∨ (fact_9fdb227ae99d_6632 a b) ∨ (fact_9fdb227ae99d_6642 a b) ∨ (fact_9fdb227ae99d_6226 a b) ∨ (fact_9fdb227ae99d_7068 a b) ∨ (fact_9fdb227ae99d_7074 a b)) ∨ ((fact_9fdb227ae99d_4063 a b) ∨ (fact_9fdb227ae99d_4091 a b) ∨ (fact_9fdb227ae99d_5297 a b) ∨ (fact_9fdb227ae99d_5912 a b) ∨ (fact_9fdb227ae99d_4995 a b) ∨ (fact_9fdb227ae99d_5008 a b) ∨ (fact_9fdb227ae99d_4223 a b) ∨ (fact_9fdb227ae99d_6133 a b) ∨ (fact_9fdb227ae99d_6145 a b)))) ∨ ((fact_9fdb227ae99d_7717 a b) ∧ (fact_9fdb227ae99d_7422 a b) ∧ ((fact_9fdb227ae99d_6015 a b) ∨ (fact_9fdb227ae99d_6053 a b) ∨ (fact_9fdb227ae99d_6815 a b) ∨ (fact_9fdb227ae99d_7027 a b) ∨ (fact_9fdb227ae99d_6632 a b) ∨ (fact_9fdb227ae99d_6642 a b) ∨ (fact_9fdb227ae99d_6226 a b) ∨ (fact_9fdb227ae99d_7068 a b) ∨ (fact_9fdb227ae99d_7074 a b)) ∧ ((fact_9fdb227ae99d_4063 a b) ∨ (fact_9fdb227ae99d_4091 a b) ∨ (fact_9fdb227ae99d_5297 a b) ∨ (fact_9fdb227ae99d_5912 a b) ∨ (fact_9fdb227ae99d_4995 a b) ∨ (fact_9fdb227ae99d_5008 a b) ∨ (fact_9fdb227ae99d_4223 a b) ∨ (fact_9fdb227ae99d_6133 a b) ∨ (fact_9fdb227ae99d_6145 a b))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n108_run_empty (a b run_x : Int)
    (h0 : ((-2 : Int) ≥ run_x))
    (h1 : (b = (5 : Int)))
    (h2 : ((fact_9fdb227ae99d_2366 a b run_x) ∨ (fact_9fdb227ae99d_2383 a b run_x) ∨ (fact_9fdb227ae99d_3039 a b run_x) ∨ (fact_9fdb227ae99d_3480 a b run_x) ∨ (fact_9fdb227ae99d_2946 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≥ ((2 : Int) + a)) ∧ ((3 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((3 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_2465 a b run_x) ∨ (fact_9fdb227ae99d_3604 a b run_x) ∨ (fact_9fdb227ae99d_3607 a b run_x)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((-1 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n108_run_floor (a b run_x : Int)
    (h0 : (((-1 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h1 : ((-2 : Int) ≥ run_x))
    (h2 : (¬ ((fact_9fdb227ae99d_3178 a b run_x) ∨ (fact_9fdb227ae99d_3188 a b run_x) ∨ (fact_9fdb227ae99d_3730 a b run_x) ∨ (fact_9fdb227ae99d_5195 a b run_x) ∨ (fact_9fdb227ae99d_3553 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((((2 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3221 a b run_x) ∨ (fact_9fdb227ae99d_5348 a b run_x) ∨ (fact_9fdb227ae99d_5351 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n109_run_four (a b : Int)
    (h0 : (¬ ((1 : Int) ≤ b)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n109_run_short (a b : Int)
    (h0 : (¬ ((b - (1 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n109_run_nonnegative (a b : Int)
    (h0 : (¬ ((1 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n109_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3581 a b) ∨ (fact_9fdb227ae99d_3585 a b) ∨ (fact_9fdb227ae99d_4718 a b) ∨ (fact_9fdb227ae99d_5748 a b) ∨ (fact_9fdb227ae99d_4385 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (-(3 : Int))) ∧ ((-(3 : Int)) ≤ ((3 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (-(3 : Int))) ∧ ((3 : Int) ≥ (-(3 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3623 a b) ∨ (fact_9fdb227ae99d_4453 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n109_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3156 a b) ∨ (fact_9fdb227ae99d_3160 a b) ∨ (fact_9fdb227ae99d_3670 a b) ∨ (fact_9fdb227ae99d_5107 a b) ∨ (fact_9fdb227ae99d_3456 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (-(3 : Int))) ∧ ((-(3 : Int)) ≤ ((3 : Int) + b)) ∧ (((2 : Int) + a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (-(3 : Int))) ∧ ((3 : Int) ≥ (-(3 : Int))) ∧ ((((2 : Int) + a) - a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3167 a b) ∨ (fact_9fdb227ae99d_3525 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n109_run_tall (a b : Int)
    (h0 : (¬ (((((1 : Int) + (3 : Int)) ≤ b) ∧ ((fact_9fdb227ae99d_7325 a b) ∨ (fact_9fdb227ae99d_7269 a b))) ∨ ((((1 : Int) + (2 : Int)) ≤ b) ∧ (fact_9fdb227ae99d_7325 a b) ∧ (fact_9fdb227ae99d_7269 a b)) ∨ (((1 : Int) + (4 : Int)) ≤ b) ∨ ((b = ((1 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7325 a b) ∧ (fact_9fdb227ae99d_7269 a b) ∧ (((fact_9fdb227ae99d_4341 a b) ∨ (fact_9fdb227ae99d_4358 a b) ∨ (fact_9fdb227ae99d_5451 a b) ∨ (fact_9fdb227ae99d_6174 a b) ∨ (fact_9fdb227ae99d_5144 a b) ∨ (fact_9fdb227ae99d_5146 a b) ∨ (fact_9fdb227ae99d_4430 a b) ∨ (fact_9fdb227ae99d_5214 a b)) ∨ ((fact_9fdb227ae99d_3418 a b) ∨ (fact_9fdb227ae99d_3436 a b) ∨ (fact_9fdb227ae99d_4511 a b) ∨ (fact_9fdb227ae99d_5595 a b) ∨ (fact_9fdb227ae99d_4130 a b) ∨ (fact_9fdb227ae99d_4145 a b) ∨ (fact_9fdb227ae99d_3510 a b) ∨ (fact_9fdb227ae99d_4254 a b)))) ∨ ((fact_9fdb227ae99d_7325 a b) ∧ (fact_9fdb227ae99d_7269 a b) ∧ ((fact_9fdb227ae99d_4341 a b) ∨ (fact_9fdb227ae99d_4358 a b) ∨ (fact_9fdb227ae99d_5451 a b) ∨ (fact_9fdb227ae99d_6174 a b) ∨ (fact_9fdb227ae99d_5144 a b) ∨ (fact_9fdb227ae99d_5146 a b) ∨ (fact_9fdb227ae99d_4430 a b) ∨ (fact_9fdb227ae99d_5214 a b)) ∧ ((fact_9fdb227ae99d_3418 a b) ∨ (fact_9fdb227ae99d_3436 a b) ∨ (fact_9fdb227ae99d_4511 a b) ∨ (fact_9fdb227ae99d_5595 a b) ∨ (fact_9fdb227ae99d_4130 a b) ∨ (fact_9fdb227ae99d_4145 a b) ∨ (fact_9fdb227ae99d_3510 a b) ∨ (fact_9fdb227ae99d_4254 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n109_run_empty (a b run_x : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((fact_9fdb227ae99d_2587 a b run_x) ∨ (fact_9fdb227ae99d_2592 a b run_x) ∨ (fact_9fdb227ae99d_3153 a b run_x) ∨ (fact_9fdb227ae99d_3673 a b run_x) ∨ (fact_9fdb227ae99d_3034 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ (-(3 : Int))) ∧ ((-(3 : Int)) ≤ ((3 : Int) + b)) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (-(3 : Int))) ∧ ((3 : Int) ≥ (-(3 : Int))) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_2696 a b run_x) ∨ (fact_9fdb227ae99d_3043 a b run_x)))
    (h3 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + a))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (((-2 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-2 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (((1 : Int) + b) - b)) ∨ ((1 : Int) > (((1 : Int) + b) + (0 : Int)))))
    (h7 : ((1 : Int) ≤ run_x))
    (h8 : (run_x ≤ b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n109_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3320 a b run_x) ∨ (fact_9fdb227ae99d_3324 a b run_x) ∨ (fact_9fdb227ae99d_4335 a b run_x) ∨ (fact_9fdb227ae99d_5469 a b run_x) ∨ (fact_9fdb227ae99d_3719 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ (-((3 : Int) - (1 : Int)))) ∧ ((-((3 : Int) - (1 : Int))) ≤ ((3 : Int) + b)) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (-((3 : Int) - (1 : Int)))) ∧ ((3 : Int) ≥ (-((3 : Int) - (1 : Int)))) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3355 a b run_x) ∨ (fact_9fdb227ae99d_3743 a b run_x))))
    (h1 : (run_x ≤ b))
    (h2 : ((1 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n110_point (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_0 a b))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n110_empty (a b : Int)
    (h0 : (a ≥ b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((fact_9fdb227ae99d_3050 a b) ∨ (fact_9fdb227ae99d_3052 a b) ∨ (fact_9fdb227ae99d_3562 a b) ∨ (fact_9fdb227ae99d_4700 a b) ∨ (fact_9fdb227ae99d_3290 a b) ∨ (fact_9fdb227ae99d_3291 a b) ∨ (fact_9fdb227ae99d_3113 a b) ∨ (fact_9fdb227ae99d_3116 a b)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n110_o0 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_1604 a b jx jy))
    (h3 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h8 : (((jx + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h9 : (b = (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n110_o1 (a b jx jy : Int)
    (h0 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h1 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - a))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (fact_9fdb227ae99d_1609 a b jx jy))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - a))))
    (h9 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n110_o2 (a b jx jy : Int)
    (h0 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - b))))
    (h1 : (fact_9fdb227ae99d_1613 a b jx jy))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - b))))
    (h6 : (a ≥ b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a > b))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n110_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_1616 a b jx jy))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h4 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h8 : (b = (5 : Int)))
    (h9 : (fact_9fdb227ae99d_107 a b))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n110_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - a))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_2922 a b jy))
    (h4 : (fact_9fdb227ae99d_1617 a b jx jy))
    (h5 : (b = (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - a))))
    (h8 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h9 : ((jy - a) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n110_o5 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (fact_9fdb227ae99d_1612 a b jx jy))
    (h5 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h6 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

end LRegionArithmetic

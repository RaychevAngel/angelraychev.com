import TilingSymmetry

namespace PolyominoFormal
namespace LongCrossObstruction
open CrossUnits

def Long (t : Cross) : Prop :=
  2 ≤ t.east ∧ 2 ≤ t.north ∧ 2 ≤ t.west ∧ 2 ≤ t.south

def Bounded (M : Int) (t : Cross) : Prop :=
  t.east ≤ M ∧ t.north ≤ M ∧ t.west ≤ M ∧ t.south ≤ M

set_option maxHeartbeats 2000000

theorem northeast (a b c d : Int) (ha : 2≤a) (hb : 2≤b)
    (hc : 2≤c) (hd : 2≤d) (t : Cross) (lt : Long t)
    (hit : Contains t 1 1) (sep : Apart t ⟨0,0,a,b,c,d⟩) :
    (t.y=1 ∧ t.x-t.west=1 ∧ a<t.x) ∨
    (t.x=1 ∧ t.y-t.south=1 ∧ b<t.y) := by
  rcases lt with ⟨te,tn,tw,ts⟩
  simp only [Contains, Apart] at hit sep
  omega

theorem southeast (a b c d : Int) (ha : 2≤a) (hb : 2≤b)
    (hc : 2≤c) (hd : 2≤d) (t : Cross) (lt : Long t)
    (hit : Contains t 1 (-1)) (sep : Apart t ⟨0,0,a,b,c,d⟩) :
    (t.y= -1 ∧ t.x-t.west=1 ∧ a<t.x) ∨
    (t.x=1 ∧ t.y+t.north= -1 ∧ t.y< -d) := by
  rcases lt with ⟨te,tn,tw,ts⟩
  simp only [Contains, Apart] at hit sep
  omega

theorem northwest (a b c d : Int) (ha : 2≤a) (hb : 2≤b)
    (hc : 2≤c) (hd : 2≤d) (t : Cross) (lt : Long t)
    (hit : Contains t (-1) 1) (sep : Apart t ⟨0,0,a,b,c,d⟩) :
    (t.y=1 ∧ t.x+t.east= -1 ∧ t.x< -c) ∨
    (t.x= -1 ∧ t.y-t.south=1 ∧ b<t.y) := by
  rcases lt with ⟨te,tn,tw,ts⟩
  simp only [Contains, Apart] at hit sep
  omega

theorem southwest (a b c d : Int) (ha : 2≤a) (hb : 2≤b)
    (hc : 2≤c) (hd : 2≤d) (t : Cross) (lt : Long t)
    (hit : Contains t (-1) (-1)) (sep : Apart t ⟨0,0,a,b,c,d⟩) :
    (t.y= -1 ∧ t.x+t.east= -1 ∧ t.x< -c) ∨
    (t.x= -1 ∧ t.y+t.north= -1 ∧ t.y< -d) := by
  rcases lt with ⟨te,tn,tw,ts⟩
  simp only [Contains, Apart] at hit sep
  omega

theorem cannot_share_north (t u : Cross) (lt : Long t) (lu : Long u)
    (tx : t.x=1) (tb : t.y-t.south=1) (ty : 2<t.y)
    (ux : u.x= -1) (ub : u.y-u.south=1) (uy : 2<u.y)
    (sep : Apart t u) : False := by
  rcases lt with ⟨te,tn,tw,ts⟩
  rcases lu with ⟨ue,un,uw,us⟩
  unfold Apart at sep
  omega

theorem cannot_share_south (t u : Cross) (lt : Long t) (lu : Long u)
    (tx : t.x=1) (tb : t.y+t.north= -1) (ty : t.y< -2)
    (ux : u.x= -1) (ub : u.y+u.north= -1) (uy : u.y< -2)
    (sep : Apart t u) : False := by
  rcases lt with ⟨te,tn,tw,ts⟩
  rcases lu with ⟨ue,un,uw,us⟩
  unfold Apart at sep
  omega

theorem cannot_share_west (t u : Cross) (lt : Long t) (lu : Long u)
    (ty : t.y=1) (tb : t.x+t.east= -1) (tx : t.x< -2)
    (uy : u.y= -1) (ub : u.x+u.east= -1) (ux : u.x< -2)
    (sep : Apart t u) : False := by
  rcases lt with ⟨te,tn,tw,ts⟩
  rcases lu with ⟨ue,un,uw,us⟩
  unfold Apart at sep
  omega

theorem above_pair (a b c d : Int) (ha : 2≤a) (hb : 2≤b)
    (hc : 2≤c) (hd : 2≤d) (u t : Cross) (lu : Long u) (lt : Long t)
    (ux : u.x=a+1) (uy : u.y=1) (uw : u.west=a)
    (q : Int) (hq : 1≤q ∧ q≤2) (hit : Contains t q 2)
    (sepO : Apart t ⟨0,0,a,b,c,d⟩) (sepU : Apart t u) :
    t.x=q ∧ t.y-t.south=2 ∧ 2<t.y := by
  rcases lt with ⟨te,tn,tw,ts⟩
  rcases lu with ⟨ue,un,uw',us⟩
  simp only [Contains, Apart] at hit sepO sepU
  omega

theorem below_pair (a b c d : Int) (ha : 2≤a) (hb : 2≤b)
    (hc : 2≤c) (hd : 2≤d) (u t : Cross) (lu : Long u) (lt : Long t)
    (ux : u.x=a+1) (uy : u.y= -1) (uw : u.west=a)
    (q : Int) (hq : 1≤q ∧ q≤2) (hit : Contains t q (-2))
    (sepO : Apart t ⟨0,0,a,b,c,d⟩) (sepU : Apart t u) :
    t.x=q ∧ t.y+t.north= -2 ∧ t.y< -2 := by
  rcases lt with ⟨te,tn,tw,ts⟩
  rcases lu with ⟨ue,un,uw',us⟩
  simp only [Contains, Apart] at hit sepO sepU
  omega

theorem above_pair_overlap (t u : Cross) (lt : Long t) (lu : Long u)
    (tx : t.x=1) (tb : t.y-t.south=2) (ty : 2<t.y)
    (ux : u.x=2) (ub : u.y-u.south=2) (uy : 2<u.y)
    (sep : Apart t u) : False := by
  rcases lt with ⟨te,tn,tw,ts⟩
  rcases lu with ⟨ue,un,uw,us⟩
  unfold Apart at sep
  omega

theorem below_pair_overlap (t u : Cross) (lt : Long t) (lu : Long u)
    (tx : t.x=1) (tb : t.y+t.north= -2) (ty : t.y< -2)
    (ux : u.x=2) (ub : u.y+u.north= -2) (uy : u.y< -2)
    (sep : Apart t u) : False := by
  rcases lt with ⟨te,tn,tw,ts⟩
  rcases lu with ⟨ue,un,uw,us⟩
  unfold Apart at sep
  omega

theorem long_positive {t : Cross} (h : Long t) : Positive t := by
  unfold Long at h
  unfold Positive
  omega

theorem world_apart {world : Cross → Prop}
    (long : ∀ t, world t → Long t)
    (disjoint : ∀ t u x y, world t → world u → Contains t x y → Contains u x y → t=u)
    {t u : Cross} (ht : world t) (hu : world u) (hne : t≠u) : Apart t u := by
  apply apart_of_no_common t u (long_positive (long t ht)) (long_positive (long u hu))
  intro x y hc hd
  exact hne (disjoint t u x y ht hu hc hd)

theorem apart_from_clear {world : Cross → Prop}
    (long : ∀ t, world t → Long t)
    (disjoint : ∀ t u x y, world t → world u → Contains t x y → Contains u x y → t=u)
    {t u : Cross} (ht : world t) (hu : world u) (x y : Int)
    (hit : Contains t x y) (clear : ¬Contains u x y) : Apart t u := by
  apply world_apart long disjoint ht hu
  intro eq
  exact clear (eq ▸ hit)

theorem east_upper_impossible (a b c d : Int) (ha : 2≤a) (hb : 2≤b)
    (hc : 2≤c) (hd : 2≤d) (world : Cross → Prop)
    (long : ∀ t, world t → Long t)
    (bound : ∀ t, world t → Bounded a t)
    (cover : ∀ x y, ∃ t, world t ∧ Contains t x y)
    (disjoint : ∀ t u x y, world t → world u → Contains t x y → Contains u x y → t=u)
    (anchor : world ⟨0,0,a,b,c,d⟩) (u : Cross) (hu : world u)
    (uy : u.y=1) (uw : u.x-u.west=1) (ux : a<u.x) : False := by
  have bu := bound u hu
  have ux' : u.x=a+1 := by unfold Bounded at bu; omega
  have uw' : u.west=a := by omega
  have lu := long u hu
  obtain ⟨v,hv,cv⟩ := cover 1 2
  obtain ⟨w,hw,cw⟩ := cover 2 2
  have clearO : ∀ q : Int, 1≤q → q≤2 → ¬Contains ⟨0,0,a,b,c,d⟩ q 2 := by
    intro q hq hq'; simp only [Contains]; omega
  have clearU : ∀ q : Int, 1≤q → q≤2 → ¬Contains u q 2 := by
    intro q hq hq'; unfold Contains; omega
  have svO := apart_from_clear long disjoint hv anchor 1 2 cv (clearO 1 (by omega) (by omega))
  have swO := apart_from_clear long disjoint hw anchor 2 2 cw (clearO 2 (by omega) (by omega))
  have svU := apart_from_clear long disjoint hv hu 1 2 cv (clearU 1 (by omega) (by omega))
  have swU := apart_from_clear long disjoint hw hu 2 2 cw (clearU 2 (by omega) (by omega))
  obtain ⟨vx,vb,vy⟩ := above_pair a b c d ha hb hc hd u v lu (long v hv)
    ux' uy uw' 1 ⟨by omega,by omega⟩ cv svO svU
  obtain ⟨wx,wb,wy⟩ := above_pair a b c d ha hb hc hd u w lu (long w hw)
    ux' uy uw' 2 ⟨by omega,by omega⟩ cw swO swU
  have sep := world_apart long disjoint hv hw (by intro eq; cases eq; omega)
  exact above_pair_overlap v w (long v hv) (long w hw) vx vb vy wx wb wy sep

theorem east_lower_impossible (a b c d : Int) (ha : 2≤a) (hb : 2≤b)
    (hc : 2≤c) (hd : 2≤d) (world : Cross → Prop)
    (long : ∀ t, world t → Long t)
    (bound : ∀ t, world t → Bounded a t)
    (cover : ∀ x y, ∃ t, world t ∧ Contains t x y)
    (disjoint : ∀ t u x y, world t → world u → Contains t x y → Contains u x y → t=u)
    (anchor : world ⟨0,0,a,b,c,d⟩) (u : Cross) (hu : world u)
    (uy : u.y= -1) (uw : u.x-u.west=1) (ux : a<u.x) : False := by
  have bu := bound u hu
  have ux' : u.x=a+1 := by unfold Bounded at bu; omega
  have uw' : u.west=a := by omega
  have lu := long u hu
  obtain ⟨v,hv,cv⟩ := cover 1 (-2)
  obtain ⟨w,hw,cw⟩ := cover 2 (-2)
  have clearO : ∀ q : Int, 1≤q → q≤2 → ¬Contains ⟨0,0,a,b,c,d⟩ q (-2) := by
    intro q hq hq'; simp only [Contains]; omega
  have clearU : ∀ q : Int, 1≤q → q≤2 → ¬Contains u q (-2) := by
    intro q hq hq'; unfold Contains; omega
  have svO := apart_from_clear long disjoint hv anchor 1 (-2) cv (clearO 1 (by omega) (by omega))
  have swO := apart_from_clear long disjoint hw anchor 2 (-2) cw (clearO 2 (by omega) (by omega))
  have svU := apart_from_clear long disjoint hv hu 1 (-2) cv (clearU 1 (by omega) (by omega))
  have swU := apart_from_clear long disjoint hw hu 2 (-2) cw (clearU 2 (by omega) (by omega))
  obtain ⟨vx,vb,vy⟩ := below_pair a b c d ha hb hc hd u v lu (long v hv)
    ux' uy uw' 1 ⟨by omega,by omega⟩ cv svO svU
  obtain ⟨wx,wb,wy⟩ := below_pair a b c d ha hb hc hd u w lu (long w hw)
    ux' uy uw' 2 ⟨by omega,by omega⟩ cw swO swU
  have sep := world_apart long disjoint hv hw (by intro eq; cases eq; omega)
  exact below_pair_overlap v w (long v hv) (long w hw) vx vb vy wx wb wy sep

theorem anchored_no_plane (a b c d : Int) (ha : 2≤a) (hb : 2≤b)
    (hc : 2≤c) (hd : 2≤d) (world : Cross → Prop)
    (long : ∀ t, world t → Long t)
    (bound : ∀ t, world t → Bounded a t)
    (cover : ∀ x y, ∃ t, world t ∧ Contains t x y)
    (disjoint : ∀ t u x y, world t → world u → Contains t x y → Contains u x y → t=u)
    (anchor : world ⟨0,0,a,b,c,d⟩) : False := by
  obtain ⟨ne,hne,cne⟩ := cover 1 1
  obtain ⟨se,hse,cse⟩ := cover 1 (-1)
  obtain ⟨nw,hnw,cnw⟩ := cover (-1) 1
  obtain ⟨sw,hsw,csw⟩ := cover (-1) (-1)
  have sne := apart_from_clear long disjoint hne anchor 1 1 cne (by simp only [Contains]; omega)
  have sse := apart_from_clear long disjoint hse anchor 1 (-1) cse (by simp only [Contains]; omega)
  have snw := apart_from_clear long disjoint hnw anchor (-1) 1 cnw (by simp only [Contains]; omega)
  have ssw := apart_from_clear long disjoint hsw anchor (-1) (-1) csw (by simp only [Contains]; omega)
  rcases northeast a b c d ha hb hc hd ne (long ne hne) cne sne with east | north
  · exact east_upper_impossible a b c d ha hb hc hd world long bound cover disjoint anchor ne hne east.1 east.2.1 east.2.2
  rcases southeast a b c d ha hb hc hd se (long se hse) cse sse with east | south
  · exact east_lower_impossible a b c d ha hb hc hd world long bound cover disjoint anchor se hse east.1 east.2.1 east.2.2
  rcases northwest a b c d ha hb hc hd nw (long nw hnw) cnw snw with west | north'
  · rcases southwest a b c d ha hb hc hd sw (long sw hsw) csw ssw with west' | south'
    · have sep := world_apart long disjoint hnw hsw (by intro eq; cases eq; omega)
      exact cannot_share_west nw sw (long nw hnw) (long sw hsw)
        west.1 west.2.1 (by omega) west'.1 west'.2.1 (by omega) sep
    · have sep := world_apart long disjoint hse hsw (by intro eq; cases eq; omega)
      exact cannot_share_south se sw (long se hse) (long sw hsw)
        south.1 south.2.1 (by omega) south'.1 south'.2.1 (by omega) sep
  · have sep := world_apart long disjoint hne hnw (by intro eq; cases eq; omega)
    exact cannot_share_north ne nw (long ne hne) (long nw hnw)
      north.1 north.2.1 (by omega) north'.1 north'.2.1 (by omega) sep

#print axioms anchored_no_plane

theorem copy_long {a b c d : Int} (ha : 2≤a) (hb : 2≤b) (hc : 2≤c) (hd : 2≤d)
    (t : Cross) (h : Copy a b c d t) : Long t := by
  rcases h with h | h | h | h | h | h | h | h
  all_goals rcases h with ⟨he,hn,hw,hs⟩
  all_goals unfold Long; exact ⟨by omega,by omega,by omega,by omega⟩

theorem copy_bounded {a b c d M : Int} (ha : a≤M) (hb : b≤M) (hc : c≤M) (hd : d≤M)
    (t : Cross) (h : Copy a b c d t) : Bounded M t := by
  rcases h with h | h | h | h | h | h | h | h
  all_goals rcases h with ⟨he,hn,hw,hs⟩
  all_goals unfold Bounded; exact ⟨by omega,by omega,by omega,by omega⟩

theorem east_longest_no_plane {a b c d : Int}
    (ha : 2≤a) (hb : 2≤b) (hc : 2≤c) (hd : 2≤d)
    (ab : b≤a) (ac : c≤a) (ad : d≤a) : ¬Tiles a b c d Plane := by
  rintro ⟨T⟩
  obtain ⟨U,anchor⟩ := normalize_plane T
  exact anchored_no_plane a b c d ha hb hc hd U.world
    (fun t ht => copy_long ha hb hc hd t (U.copies t ht))
    (fun t ht => copy_bounded (by omega) ab ac ad t (U.copies t ht))
    (fun x y => U.cover x y True.intro) U.disjoint anchor

/-- Every four-arm cross whose arms are all at least two fails to tile
    the plane, with no anchoring, periodicity, or size cutoff. -/
theorem all_long_no_plane {a b c d : Int}
    (ha : 2≤a) (hb : 2≤b) (hc : 2≤c) (hd : 2≤d) : ¬Tiles a b c d Plane := by
  rintro ⟨T⟩
  by_cases h₁ : b≤a ∧ c≤a ∧ d≤a
  · exact east_longest_no_plane ha hb hc hd h₁.1 h₁.2.1 h₁.2.2 ⟨T⟩
  by_cases h₂ : a≤b ∧ c≤b ∧ d≤b
  · exact east_longest_no_plane hb hc hd ha h₂.2.1 h₂.2.2 h₂.1 ⟨T.rotateParameters⟩
  by_cases h₃ : a≤c ∧ b≤c ∧ d≤c
  · exact east_longest_no_plane hc hd ha hb h₃.2.2 h₃.1 h₃.2.1
      ⟨T.rotateParameters.rotateParameters⟩
  · exact east_longest_no_plane hd ha hb hc (by omega) (by omega) (by omega)
      ⟨T.rotateParameters.rotateParameters.rotateParameters⟩

#print axioms all_long_no_plane

end LongCrossObstruction
end PolyominoFormal

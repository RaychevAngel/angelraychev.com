import Std.Tactic
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace LRegionArithmetic

theorem HP_boundaryall_unequal_corner_long_pruned_n000_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((-1 : Int) ≥ (-((2 : Int) * ((a + b) + (1 : Int))))) ∧ (b ≥ (0 : Int)) ∧ ((-1 : Int) ≤ ((2 : Int) * ((a + b) + (1 : Int)))) ∧ (b ≤ ((2 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n000_empty (a b : Int)
    (h0 : (((((-1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-1 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ b) ∧ ((0 : Int) ≥ b)) ∨ (((0 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ b) ∧ (b ≤ ((0 : Int) + b)))) ∨ ((((-1 : Int) ≥ ((1 : Int) - a)) ∧ ((-1 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ b) ∧ (b ≤ ((1 : Int) + b))) ∨ (((1 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (1 : Int)) ∧ ((((1 : Int) + b) - b) ≤ b) ∧ (b ≤ (((1 : Int) + b) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n000_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h2 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ (jy ≤ b) ∧ (b ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ b) ∧ (b ≤ (jy + b)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (¬ (((jx = ((-1 : Int) + ((-1 : Int) * a))) ∧ (jy = b) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n000_o1 (a b jx jy : Int)
    (h0 : (a > b))
    (h1 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ (jy ≤ b) ∧ (b ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - a) ≤ b) ∧ (b ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((1 : Int) - a)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < (jy - a))))
    (h4 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n000_o2 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ b) ∧ (b ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - b) ≤ b) ∧ (b ≤ (jy + (0 : Int))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((1 : Int) - a)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < (jy - b))))
    (h3 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n000_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a > b))
    (h2 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ b) ∧ (b ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ b) ∧ (b ≤ (jy + a)))))
    (h3 : ((jx < ((1 : Int) - a)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n000_o4 (a b jx jy : Int)
    (h0 : (a > b))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ b) ∧ (b ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - a) ≤ b) ∧ (b ≤ (jy + (0 : Int))))))
    (h3 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ ((((0 : Int) = a) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ ((((0 : Int) = b) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = b)))))))
    (h4 : ((jx < ((1 : Int) - a)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n000_o5 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ b) ∧ (b ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ b) ∧ (b ≤ (jy + b)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((1 : Int) - a)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h3 : (¬ ((((-1 : Int) = jx) ∧ ((0 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n000_o6 (a b jx jy : Int)
    (h0 : (¬ (((jx = ((-1 : Int) + ((-1 : Int) * b))) ∧ (jy = b) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h3 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ (jy ≤ b) ∧ (b ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ b) ∧ (b ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n000_o7 (a b jx jy : Int)
    (h0 : ((jx < ((1 : Int) - a)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < (jy - b))))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h2 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ (jy ≤ b) ∧ (b ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - b) ≤ b) ∧ (b ≤ (jy + (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n001_point (a b : Int)
    (h0 : (¬ (((-1 : Int) ≥ (-((2 : Int) * ((a + b) + (1 : Int))))) ∧ (((-1 : Int) + b) ≥ (0 : Int)) ∧ ((-1 : Int) ≤ ((2 : Int) * ((a + b) + (1 : Int)))) ∧ (((-1 : Int) + b) ≤ ((2 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n001_empty (a b : Int)
    (h0 : (((((-1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-1 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((-1 : Int) + b)) ∧ ((0 : Int) ≥ ((-1 : Int) + b))) ∨ (((0 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((-1 : Int) ≥ ((1 : Int) - a)) ∧ ((-1 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ ((1 : Int) + b))) ∨ (((1 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (1 : Int)) ∧ ((((1 : Int) + b) - b) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (((1 : Int) + b) + (0 : Int))))) ∨ ((((-1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((-1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ (b ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ b)) ∨ (((-1 : Int) ≥ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((b - (0 : Int)) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (b + b))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n001_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + b)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((jx < (((-1 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-1 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((jy + b) < b) ∨ (b < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n001_o1 (a b jx jy : Int)
    (h0 : (a > b))
    (h1 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - a) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < (((-1 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-1 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((jy + (0 : Int)) < b) ∨ (b < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n001_o2 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (((jx + (0 : Int)) < ((-1 : Int) + ((-1 : Int) * a))) ∨ (((-1 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < (b - (0 : Int))) ∨ ((b + b) < jy)))
    (h3 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - b) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n001_o3 (a b jx jy : Int)
    (h0 : (a > b))
    (h1 : ((jx < (((-1 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-1 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((jy + a) < b) ∨ (b < (jy - (0 : Int)))))
    (h2 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n001_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((jx < (((-1 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-1 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((jy + (0 : Int)) < b) ∨ (b < (jy - a))))
    (h2 : (a > b))
    (h3 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - a) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n001_o5 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + b)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < (((-1 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-1 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((jy + b) < b) ∨ (b < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n001_o6 (a b jx jy : Int)
    (h0 : ((jx < (((-1 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-1 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((jy + a) < b) ∨ (b < (jy - (0 : Int)))))
    (h1 : (a > b))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n001_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - b) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < (((-1 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-1 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((jy + (0 : Int)) < b) ∨ (b < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n002_point (a b : Int)
    (h0 : (¬ (((-2 : Int) ≥ (-((2 : Int) * ((a + b) + (1 : Int))))) ∧ (b ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((2 : Int) * ((a + b) + (1 : Int)))) ∧ (b ≤ ((2 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n002_empty (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((((-2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ b) ∧ ((0 : Int) ≥ b)) ∨ (((0 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ b) ∧ (b ≤ ((0 : Int) + b)))) ∨ ((((-2 : Int) ≥ ((1 : Int) - a)) ∧ ((-2 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ b) ∧ (b ≤ ((1 : Int) + b))) ∨ (((1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (1 : Int)) ∧ ((((1 : Int) + b) - b) ≤ b) ∧ (b ≤ (((1 : Int) + b) + (0 : Int))))) ∨ ((((-2 : Int) ≥ ((-1 : Int) - a)) ∧ ((-2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ b) ∧ ((0 : Int) ≥ b)) ∨ (((-1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ b) ∧ (b ≤ ((0 : Int) + b))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n002_o0 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ (jy ≤ b) ∧ (b ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ b) ∧ (b ≤ (jy + b)))))
    (h4 : (¬ (((jx = ((-2 : Int) + ((-1 : Int) * a))) ∧ (jy = b) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n002_o1 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ (jy ≤ b) ∧ (b ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - a) ≤ b) ∧ (b ≤ (jy + (0 : Int))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a > b))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((jx < ((1 : Int) - a)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n002_o2 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h2 : ((jx < ((1 : Int) - a)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < (jy - b))))
    (h3 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ b) ∧ (b ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - b) ≤ b) ∧ (b ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n002_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a > b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ b) ∧ (b ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ b) ∧ (b ≤ (jy + a)))))
    (h4 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h5 : ((jx < ((1 : Int) - a)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n002_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a > b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ b) ∧ (b ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - a) ≤ b) ∧ (b ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((1 : Int) - a)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n002_o5 (a b jx jy : Int)
    (h0 : ((jx < ((1 : Int) - a)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h1 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h2 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ b) ∧ (b ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ b) ∧ (b ≤ (jy + b)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h5 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n002_o6 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h1 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ (jy ≤ b) ∧ (b ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ b) ∧ (b ≤ (jy + a)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (¬ (((jx = ((-2 : Int) + ((-1 : Int) * b))) ∧ (jy = b) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n002_o7 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ (jy ≤ b) ∧ (b ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - b) ≤ b) ∧ (b ≤ (jy + (0 : Int))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((1 : Int) - a)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < (jy - b))))
    (h3 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n003_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((-2 : Int) ≥ (-((2 : Int) * ((a + b) + (1 : Int))))) ∧ (((-1 : Int) + b) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((2 : Int) * ((a + b) + (1 : Int)))) ∧ (((-1 : Int) + b) ≤ ((2 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n003_empty (a b : Int)
    (h0 : (((((-2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((-1 : Int) + b)) ∧ ((0 : Int) ≥ ((-1 : Int) + b))) ∨ (((0 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((-2 : Int) ≥ ((1 : Int) - a)) ∧ ((-2 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ ((1 : Int) + b))) ∨ (((1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (1 : Int)) ∧ ((((1 : Int) + b) - b) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (((1 : Int) + b) + (0 : Int))))) ∨ ((((-2 : Int) ≥ ((-1 : Int) - a)) ∧ ((-2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((-1 : Int) + b)) ∧ ((0 : Int) ≥ ((-1 : Int) + b))) ∨ (((-1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ (b ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ b)) ∨ (((-2 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((b - (0 : Int)) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (b + b))))))
    (h1 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n003_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + b)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((jy + b) < b) ∨ (b < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n003_o1 (a b jx jy : Int)
    (h0 : (a > b))
    (h1 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - a) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((jy + (0 : Int)) < b) ∨ (b < (jy - a))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n003_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((jx + (0 : Int)) < ((-2 : Int) + ((-1 : Int) * a))) ∨ (((-2 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < (b - (0 : Int))) ∨ ((b + b) < jy)))
    (h3 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - b) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n003_o3 (a b jx jy : Int)
    (h0 : (a > b))
    (h1 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h2 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + a)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((jy + a) < b) ∨ (b < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n003_o4 (a b jx jy : Int)
    (h0 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((jy + (0 : Int)) < b) ∨ (b < (jy - a))))
    (h1 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - a) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + (0 : Int))))))
    (h2 : (a > b))
    (h3 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n003_o5 (a b jx jy : Int)
    (h0 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((jy + b) < b) ∨ (b < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + b)))))
    (h4 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n003_o6 (a b jx jy : Int)
    (h0 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((jy + a) < b) ∨ (b < (jy - (0 : Int)))))
    (h1 : (a > b))
    (h2 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + a)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n003_o7 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((jy + (0 : Int)) < b) ∨ (b < (jy - b))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - b) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n004_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((-2 : Int) ≥ (-((2 : Int) * ((a + b) + (1 : Int))))) ∧ (((-1 : Int) + b) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((2 : Int) * ((a + b) + (1 : Int)))) ∧ (((-1 : Int) + b) ≤ ((2 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n004_empty (a b : Int)
    (h0 : (((((-2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((-1 : Int) + b)) ∧ ((0 : Int) ≥ ((-1 : Int) + b))) ∨ (((0 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((-2 : Int) ≥ ((1 : Int) - a)) ∧ ((-2 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ ((1 : Int) + b))) ∨ (((1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (1 : Int)) ∧ ((((1 : Int) + b) - b) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (((1 : Int) + b) + (0 : Int))))) ∨ ((((-2 : Int) ≥ ((-1 : Int) - a)) ∧ ((-2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((-1 : Int) + b)) ∧ ((0 : Int) ≥ ((-1 : Int) + b))) ∨ (((-1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∧ ((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) + b)) ∧ (b ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ b)) ∨ (((-2 : Int) ≥ ((-2 : Int) + ((-1 : Int) * b))) ∧ ((-2 : Int) ≤ ((-2 : Int) + ((-1 : Int) * b))) ∧ ((b - (0 : Int)) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (b + a))))))
    (h1 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n004_o0 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + b)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (¬ (((jx = ((-2 : Int) + ((-1 : Int) * a))) ∧ (jy = ((-1 : Int) + b)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n004_o1 (a b jx jy : Int)
    (h0 : (a > b))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((jx < (((-2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * b)) + b) < jx) ∨ ((jy + (0 : Int)) < b) ∨ (b < (jy - a))))
    (h3 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - a) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n004_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((jx < (((-2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * b)) + b) < jx) ∨ ((jy + (0 : Int)) < b) ∨ (b < (jy - b))))
    (h2 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - b) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n004_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h2 : (a > b))
    (h3 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + a)))))
    (h4 : ((jx < ((1 : Int) - a)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h5 : ((jx < (((-2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * b)) + b) < jx) ∨ ((jy + a) < b) ∨ (b < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n004_o4 (a b jx jy : Int)
    (h0 : (a > b))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - a) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + (0 : Int))))))
    (h3 : (((jx + (0 : Int)) < ((-2 : Int) + ((-1 : Int) * b))) ∨ (((-2 : Int) + ((-1 : Int) * b)) < (jx - b)) ∨ (jy < (b - (0 : Int))) ∨ ((b + a) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n004_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < (((-2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * b)) + b) < jx) ∨ ((jy + b) < b) ∨ (b < (jy - (0 : Int)))))
    (h2 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h3 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n004_o6 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + a)))))
    (h1 : ((jx < (((-2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * b)) + b) < jx) ∨ ((jy + a) < b) ∨ (b < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (a > b))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n004_o7 (a b jx jy : Int)
    (h0 : ((jx < (((-2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * b)) + b) < jx) ∨ ((jy + (0 : Int)) < b) ∨ (b < (jy - b))))
    (h1 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - b) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n005_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((-2 : Int) ≥ (-((2 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((2 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((2 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n005_empty (a b : Int)
    (h0 : (((((-2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (0 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + b)))) ∨ ((((-2 : Int) ≥ ((1 : Int) - a)) ∧ ((-2 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ ((1 : Int) ≥ ((1 : Int) + b)) ∧ ((1 : Int) ≤ ((1 : Int) + b))) ∨ (((1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≥ (((1 : Int) + b) - b)) ∧ ((1 : Int) ≤ (((1 : Int) + b) + (0 : Int))))) ∨ ((((-2 : Int) ≥ ((-1 : Int) - a)) ∧ ((-2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-1 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + b)))) ∨ ((((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∧ ((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) + b)) ∧ ((1 : Int) ≥ b) ∧ ((1 : Int) ≤ b)) ∨ (((-2 : Int) ≥ ((-2 : Int) + ((-1 : Int) * b))) ∧ ((-2 : Int) ≤ ((-2 : Int) + ((-1 : Int) * b))) ∧ ((1 : Int) ≥ (b - (0 : Int))) ∧ ((1 : Int) ≤ (b + a)))) ∨ ((((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≥ ((-1 : Int) + b)) ∧ ((1 : Int) ≤ ((-1 : Int) + b))) ∨ (((-2 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) ≥ (((-1 : Int) + b) - (0 : Int))) ∧ ((1 : Int) ≤ (((-1 : Int) + b) + b))))))
    (h1 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n005_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h4 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((jy + b) < ((-1 : Int) + b)) ∨ (((-1 : Int) + b) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n005_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((jy + (0 : Int)) < ((-1 : Int) + b)) ∨ (((-1 : Int) + b) < (jy - a))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h4 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n005_o2 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < (((-2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * b)) + b) < jx) ∨ ((jy + (0 : Int)) < b) ∨ (b < (jy - b))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n005_o3 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h1 : (a > b))
    (h2 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < (((-2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * b)) + b) < jx) ∨ ((jy + a) < b) ∨ (b < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n005_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((jy + (0 : Int)) < ((-1 : Int) + b)) ∨ (((-1 : Int) + b) < (jy - a))))
    (h2 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (a > b))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n005_o5 (a b jx jy : Int)
    (h0 : ((jx < (((-2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * b)) + b) < jx) ∨ ((jy + b) < b) ∨ (b < (jy - (0 : Int)))))
    (h1 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n005_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h2 : ((jx < (((-2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * b)) + b) < jx) ∨ ((jy + a) < b) ∨ (b < (jy - (0 : Int)))))
    (h3 : (a > b))
    (h4 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n005_o7 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b) - b)) ∨ ((((1 : Int) + b) + (0 : Int)) < jy)))
    (h3 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n006_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((-1 : Int) ≥ (-((2 : Int) * ((a + b) + (1 : Int))))) ∧ (((-1 : Int) + b) ≥ (0 : Int)) ∧ ((-1 : Int) ≤ ((2 : Int) * ((a + b) + (1 : Int)))) ∧ (((-1 : Int) + b) ≤ ((2 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n006_empty (a b : Int)
    (h0 : (((((-1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-1 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((-1 : Int) + b)) ∧ ((0 : Int) ≥ ((-1 : Int) + b))) ∨ (((0 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((-1 : Int) ≥ ((1 : Int) - a)) ∧ ((-1 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ ((1 : Int) + b))) ∨ (((1 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (1 : Int)) ∧ ((((1 : Int) + b) - b) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (((1 : Int) + b) + (0 : Int))))) ∨ ((((-1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∧ ((-1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * b)) + b)) ∧ (b ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ b)) ∨ (((-1 : Int) ≥ ((-1 : Int) + ((-1 : Int) * b))) ∧ ((-1 : Int) ≤ ((-1 : Int) + ((-1 : Int) * b))) ∧ ((b - (0 : Int)) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (b + a))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n006_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h3 : (¬ (((jx = ((-1 : Int) + ((-1 : Int) * a))) ∧ (jy = ((-1 : Int) + b)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n006_o1 (a b jx jy : Int)
    (h0 : ((jx < (((-1 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((-1 : Int) + ((-1 : Int) * b)) + b) < jx) ∨ ((jy + (0 : Int)) < b) ∨ (b < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (a > b))
    (h3 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - a) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n006_o2 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - b) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((jx < (((-1 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((-1 : Int) + ((-1 : Int) * b)) + b) < jx) ∨ ((jy + (0 : Int)) < b) ∨ (b < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n006_o3 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + a)))))
    (h1 : ((jx < ((1 : Int) - a)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (a > b))
    (h4 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n006_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a > b))
    (h2 : ((jx < ((1 : Int) - a)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < (jy - a))))
    (h3 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - a) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n006_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + b)))))
    (h2 : ((jx < (((-1 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((-1 : Int) + ((-1 : Int) * b)) + b) < jx) ∨ ((jy + b) < b) ∨ (b < (jy - (0 : Int)))))
    (h3 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n006_o6 (a b jx jy : Int)
    (h0 : ((jx < (((-1 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((-1 : Int) + ((-1 : Int) * b)) + b) < jx) ∨ ((jy + a) < b) ∨ (b < (jy - (0 : Int)))))
    (h1 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + a)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (a > b))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n006_o7 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ (jy ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - b) ≤ ((-1 : Int) + b)) ∧ (((-1 : Int) + b) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((jx < (((-1 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((-1 : Int) + ((-1 : Int) * b)) + b) < jx) ∨ ((jy + (0 : Int)) < b) ∨ (b < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n007_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((-1 : Int) ≥ (-((2 : Int) * ((a + b) + (1 : Int))))) ∧ (((-2 : Int) + b) ≥ (0 : Int)) ∧ ((-1 : Int) ≤ ((2 : Int) * ((a + b) + (1 : Int)))) ∧ (((-2 : Int) + b) ≤ ((2 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n007_empty (a b : Int)
    (h0 : (((((-1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-1 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((-2 : Int) + b)) ∧ ((0 : Int) ≥ ((-2 : Int) + b))) ∨ (((0 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((-2 : Int) + b)) ∧ (((-2 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((-1 : Int) ≥ ((1 : Int) - a)) ∧ ((-1 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ ((-2 : Int) + b)) ∧ (((-2 : Int) + b) ≤ ((1 : Int) + b))) ∨ (((1 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (1 : Int)) ∧ ((((1 : Int) + b) - b) ≤ ((-2 : Int) + b)) ∧ (((-2 : Int) + b) ≤ (((1 : Int) + b) + (0 : Int))))) ∨ ((((-1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∧ ((-1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * b)) + b)) ∧ (b ≤ ((-2 : Int) + b)) ∧ (((-2 : Int) + b) ≤ b)) ∨ (((-1 : Int) ≥ ((-1 : Int) + ((-1 : Int) * b))) ∧ ((-1 : Int) ≤ ((-1 : Int) + ((-1 : Int) * b))) ∧ ((b - (0 : Int)) ≤ ((-2 : Int) + b)) ∧ (((-2 : Int) + b) ≤ (b + a)))) ∨ ((((-1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((-1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ (((-1 : Int) + b) ≤ ((-2 : Int) + b)) ∧ (((-2 : Int) + b) ≤ ((-1 : Int) + b))) ∨ (((-1 : Int) ≥ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((((-1 : Int) + b) - (0 : Int)) ≤ ((-2 : Int) + b)) ∧ (((-2 : Int) + b) ≤ (((-1 : Int) + b) + b))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n007_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ (jy ≤ ((-2 : Int) + b)) ∧ (((-2 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-2 : Int) + b)) ∧ (((-2 : Int) + b) ≤ (jy + b)))))
    (h3 : ((jx < (((-1 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-1 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((jy + b) < ((-1 : Int) + b)) ∨ (((-1 : Int) + b) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n007_o1 (a b jx jy : Int)
    (h0 : ((jx < (((-1 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((-1 : Int) + ((-1 : Int) * b)) + b) < jx) ∨ ((jy + (0 : Int)) < b) ∨ (b < (jy - a))))
    (h1 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ (jy ≤ ((-2 : Int) + b)) ∧ (((-2 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - a) ≤ ((-2 : Int) + b)) ∧ (((-2 : Int) + b) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (a > b))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n007_o2 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((-1 : Int) + ((-1 : Int) * a))) ∨ (((-1 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < (((-1 : Int) + b) - (0 : Int))) ∨ ((((-1 : Int) + b) + b) < jy)))
    (h1 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-2 : Int) + b)) ∧ (((-2 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - b) ≤ ((-2 : Int) + b)) ∧ (((-2 : Int) + b) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n007_o3 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-2 : Int) + b)) ∧ (((-2 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-2 : Int) + b)) ∧ (((-2 : Int) + b) ≤ (jy + a)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h3 : ((jx < (((-1 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-1 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((jy + a) < ((-1 : Int) + b)) ∨ (((-1 : Int) + b) < (jy - (0 : Int)))))
    (h4 : (a > b))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n007_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((jx < (((-1 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-1 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((jy + (0 : Int)) < ((-1 : Int) + b)) ∨ (((-1 : Int) + b) < (jy - a))))
    (h2 : (a > b))
    (h3 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-2 : Int) + b)) ∧ (((-2 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - a) ≤ ((-2 : Int) + b)) ∧ (((-2 : Int) + b) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n007_o5 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-2 : Int) + b)) ∧ (((-2 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-2 : Int) + b)) ∧ (((-2 : Int) + b) ≤ (jy + b)))))
    (h1 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h2 : (a > b))
    (h3 : ((jx < (((-1 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-1 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((jy + b) < ((-1 : Int) + b)) ∨ (((-1 : Int) + b) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n007_o6 (a b jx jy : Int)
    (h0 : (a > b))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < (((-1 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((-1 : Int) + ((-1 : Int) * b)) + b) < jx) ∨ ((jy + a) < b) ∨ (b < (jy - (0 : Int)))))
    (h3 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ (jy ≤ ((-2 : Int) + b)) ∧ (((-2 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-2 : Int) + b)) ∧ (((-2 : Int) + b) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_corner_long_pruned_n007_o7 (a b jx jy : Int)
    (h0 : ((jx < (((-1 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-1 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((jy + (0 : Int)) < ((-1 : Int) + b)) ∨ (((-1 : Int) + b) < (jy - b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ (jy ≤ ((-2 : Int) + b)) ∧ (((-2 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - b) ≤ ((-2 : Int) + b)) ∧ (((-2 : Int) + b) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

end LRegionArithmetic

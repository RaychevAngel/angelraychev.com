import CornerCertificateAffineBetaTransposeGeometry

set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace CornerCertificate
open CrossUnits

section AffineBetaTranspose
variable (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (copies : ∀ t, world t → Copy a 1 1 0 t)
    (separate : DisjointWorld world) (cover : CoversWindow world h)
    (ceiling : SelectedBelow world h)

include ha copies separate cover ceiling in
theorem affine_betaTranspose_node148 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known148 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known148 a) ((1 : Int),(2 : Int)) (affine_betaTranspose_branches148 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative148 a ha) (affine_betaTranspose_window148 a ha world h B state)
    (affine_betaTranspose_empty148 a ha) (affine_betaTranspose_complete148 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches148,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches148,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node147 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known147 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known147 a) ((1 : Int),(2 : Int)) (affine_betaTranspose_branches147 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative147 a ha) (affine_betaTranspose_window147 a ha world h B state)
    (affine_betaTranspose_empty147 a ha) (affine_betaTranspose_complete147 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches147,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches147,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node146 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known146 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known146 a) ((2 : Int),(2 : Int)) (affine_betaTranspose_branches146 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative146 a ha) (affine_betaTranspose_window146 a ha world h B state)
    (affine_betaTranspose_empty146 a ha) (affine_betaTranspose_complete146 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches146,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches146,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node145 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known145 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known145 a) ((2 : Int),(2 : Int)) (affine_betaTranspose_branches145 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative145 a ha) (affine_betaTranspose_window145 a ha world h B state)
    (affine_betaTranspose_empty145 a ha) (affine_betaTranspose_complete145 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches145,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches145,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node144 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known144 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known144 a) ((1 : Int),(2 : Int)) (affine_betaTranspose_branches144 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative144 a ha) (affine_betaTranspose_window144 a ha world h B state)
    (affine_betaTranspose_empty144 a ha) (affine_betaTranspose_complete144 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches144,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known144,affine_betaTranspose_known145,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known144,affine_betaTranspose_known146,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches144,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node145 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node146 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node143 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known143 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known143 a) ((0 : Int),(2 : Int)) (affine_betaTranspose_branches143 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative143 a ha) (affine_betaTranspose_window143 a ha world h B state)
    (affine_betaTranspose_empty143 a ha) (affine_betaTranspose_complete143 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches143,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known143,affine_betaTranspose_known144,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known143,affine_betaTranspose_known147,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known143,affine_betaTranspose_known148,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches143,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_betaTranspose_node144 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node147 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node148 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node142 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known142 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known142 a) ((1 : Int),(0 : Int)) (affine_betaTranspose_branches142 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative142 a ha) (affine_betaTranspose_window142 a ha world h B state)
    (affine_betaTranspose_empty142 a ha) (affine_betaTranspose_complete142 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches142,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known142,affine_betaTranspose_known143,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches142,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_betaTranspose_node143 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_betaTranspose_node141 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known141 a)) B) : Transition world h .betaTranspose B := by
  exact affine_betaTranspose_leaf141 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node140 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known140 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known140 a) ((1 : Int),(4 : Int)) (affine_betaTranspose_branches140 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative140 a ha) (affine_betaTranspose_window140 a ha world h B state)
    (affine_betaTranspose_empty140 a ha) (affine_betaTranspose_complete140 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches140,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches140,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node139 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known139 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known139 a) ((2 : Int),(2 : Int)) (affine_betaTranspose_branches139 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative139 a ha) (affine_betaTranspose_window139 a ha world h B state)
    (affine_betaTranspose_empty139 a ha) (affine_betaTranspose_complete139 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches139,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known139,affine_betaTranspose_known140,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches139,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_betaTranspose_node140 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node138 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known138 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known138 a) ((2 : Int),(2 : Int)) (affine_betaTranspose_branches138 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative138 a ha) (affine_betaTranspose_window138 a ha world h B state)
    (affine_betaTranspose_empty138 a ha) (affine_betaTranspose_complete138 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches138,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches138,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node137 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known137 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known137 a) ((1 : Int),(4 : Int)) (affine_betaTranspose_branches137 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative137 a ha) (affine_betaTranspose_window137 a ha world h B state)
    (affine_betaTranspose_empty137 a ha) (affine_betaTranspose_complete137 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches137,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches137,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node136 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known136 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known136 a) ((2 : Int),(2 : Int)) (affine_betaTranspose_branches136 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative136 a ha) (affine_betaTranspose_window136 a ha world h B state)
    (affine_betaTranspose_empty136 a ha) (affine_betaTranspose_complete136 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches136,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known136,affine_betaTranspose_known137,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches136,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_betaTranspose_node137 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node135 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known135 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known135 a) ((1 : Int),(5 : Int)) (affine_betaTranspose_branches135 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative135 a ha) (affine_betaTranspose_window135 a ha world h B state)
    (affine_betaTranspose_empty135 a ha) (affine_betaTranspose_complete135 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches135,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches135,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node134 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known134 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known134 a) ((1 : Int),(5 : Int)) (affine_betaTranspose_branches134 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative134 a ha) (affine_betaTranspose_window134 a ha world h B state)
    (affine_betaTranspose_empty134 a ha) (affine_betaTranspose_complete134 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches134,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches134,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node133 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known133 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known133 a) ((3 : Int),(2 : Int)) (affine_betaTranspose_branches133 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative133 a ha) (affine_betaTranspose_window133 a ha world h B state)
    (affine_betaTranspose_empty133 a ha) (affine_betaTranspose_complete133 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches133,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known133,affine_betaTranspose_known134,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known133,affine_betaTranspose_known135,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches133,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node134 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node135 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node132 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known132 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known132 a) ((1 : Int),(5 : Int)) (affine_betaTranspose_branches132 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative132 a ha) (affine_betaTranspose_window132 a ha world h B state)
    (affine_betaTranspose_empty132 a ha) (affine_betaTranspose_complete132 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches132,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches132,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node131 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known131 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known131 a) ((1 : Int),(5 : Int)) (affine_betaTranspose_branches131 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative131 a ha) (affine_betaTranspose_window131 a ha world h B state)
    (affine_betaTranspose_empty131 a ha) (affine_betaTranspose_complete131 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches131,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches131,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node130 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known130 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known130 a) ((3 : Int),(2 : Int)) (affine_betaTranspose_branches130 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative130 a ha) (affine_betaTranspose_window130 a ha world h B state)
    (affine_betaTranspose_empty130 a ha) (affine_betaTranspose_complete130 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches130,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known130,affine_betaTranspose_known131,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known130,affine_betaTranspose_known132,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches130,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node131 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node132 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node129 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known129 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known129 a) ((1 : Int),(4 : Int)) (affine_betaTranspose_branches129 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative129 a ha) (affine_betaTranspose_window129 a ha world h B state)
    (affine_betaTranspose_empty129 a ha) (affine_betaTranspose_complete129 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches129,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known129,affine_betaTranspose_known130,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known129,affine_betaTranspose_known133,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches129,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node130 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node133 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_betaTranspose_node128 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known128 a)) B) : Transition world h .betaTranspose B := by
  exact affine_betaTranspose_leaf128 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node127 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known127 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known127 a) ((1 : Int),(3 : Int)) (affine_betaTranspose_branches127 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative127 a ha) (affine_betaTranspose_window127 a ha world h B state)
    (affine_betaTranspose_empty127 a ha) (affine_betaTranspose_complete127 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches127,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known127,affine_betaTranspose_known128,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known127,affine_betaTranspose_known129,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known127,affine_betaTranspose_known136,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known127,affine_betaTranspose_known138,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known127,affine_betaTranspose_known139,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches127,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · exact affine_betaTranspose_node128 a ha world h nextB nextState
    · exact affine_betaTranspose_node129 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node136 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node138 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node139 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_betaTranspose_node126 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known126 a)) B) : Transition world h .betaTranspose B := by
  exact affine_betaTranspose_leaf126 a ha world h B state
include ha in
theorem affine_betaTranspose_node125 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known125 a)) B) : Transition world h .betaTranspose B := by
  exact affine_betaTranspose_leaf125 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node124 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known124 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known124 a) ((0 : Int),(2 : Int)) (affine_betaTranspose_branches124 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative124 a ha) (affine_betaTranspose_window124 a ha world h B state)
    (affine_betaTranspose_empty124 a ha) (affine_betaTranspose_complete124 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches124,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known124,affine_betaTranspose_known125,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known124,affine_betaTranspose_known126,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known124,affine_betaTranspose_known127,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches124,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_betaTranspose_node125 a ha world h nextB nextState
    · exact affine_betaTranspose_node126 a ha world h nextB nextState
    · exact affine_betaTranspose_node127 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node123 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known123 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known123 a) ((1 : Int),(0 : Int)) (affine_betaTranspose_branches123 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative123 a ha) (affine_betaTranspose_window123 a ha world h B state)
    (affine_betaTranspose_empty123 a ha) (affine_betaTranspose_complete123 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches123,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known123,affine_betaTranspose_known124,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches123,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_betaTranspose_node124 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_betaTranspose_node122 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known122 a)) B) : Transition world h .betaTranspose B := by
  exact affine_betaTranspose_leaf122 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node121 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known121 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known121 a) ((3 : Int),(1 : Int)) (affine_betaTranspose_branches121 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative121 a ha) (affine_betaTranspose_window121 a ha world h B state)
    (affine_betaTranspose_empty121 a ha) (affine_betaTranspose_complete121 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches121,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches121,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node120 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known120 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known120 a) ((3 : Int),(1 : Int)) (affine_betaTranspose_branches120 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative120 a ha) (affine_betaTranspose_window120 a ha world h B state)
    (affine_betaTranspose_empty120 a ha) (affine_betaTranspose_complete120 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches120,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches120,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node119 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known119 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known119 a) ((2 : Int),(1 : Int)) (affine_betaTranspose_branches119 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative119 a ha) (affine_betaTranspose_window119 a ha world h B state)
    (affine_betaTranspose_empty119 a ha) (affine_betaTranspose_complete119 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches119,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known119,affine_betaTranspose_known120,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known119,affine_betaTranspose_known121,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches119,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node120 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node121 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_betaTranspose_node118 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known118 a)) B) : Transition world h .betaTranspose B := by
  exact affine_betaTranspose_leaf118 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node117 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known117 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known117 a) ((3 : Int),(3 : Int)) (affine_betaTranspose_branches117 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative117 a ha) (affine_betaTranspose_window117 a ha world h B state)
    (affine_betaTranspose_empty117 a ha) (affine_betaTranspose_complete117 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches117,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches117,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node116 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known116 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known116 a) ((4 : Int),(1 : Int)) (affine_betaTranspose_branches116 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative116 a ha) (affine_betaTranspose_window116 a ha world h B state)
    (affine_betaTranspose_empty116 a ha) (affine_betaTranspose_complete116 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches116,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known116,affine_betaTranspose_known117,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches116,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_betaTranspose_node117 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node115 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known115 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known115 a) ((4 : Int),(1 : Int)) (affine_betaTranspose_branches115 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative115 a ha) (affine_betaTranspose_window115 a ha world h B state)
    (affine_betaTranspose_empty115 a ha) (affine_betaTranspose_complete115 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches115,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches115,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node114 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known114 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known114 a) ((3 : Int),(3 : Int)) (affine_betaTranspose_branches114 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative114 a ha) (affine_betaTranspose_window114 a ha world h B state)
    (affine_betaTranspose_empty114 a ha) (affine_betaTranspose_complete114 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches114,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches114,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node113 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known113 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known113 a) ((4 : Int),(1 : Int)) (affine_betaTranspose_branches113 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative113 a ha) (affine_betaTranspose_window113 a ha world h B state)
    (affine_betaTranspose_empty113 a ha) (affine_betaTranspose_complete113 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches113,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known113,affine_betaTranspose_known114,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches113,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_betaTranspose_node114 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node112 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known112 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known112 a) ((3 : Int),(4 : Int)) (affine_betaTranspose_branches112 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative112 a ha) (affine_betaTranspose_window112 a ha world h B state)
    (affine_betaTranspose_empty112 a ha) (affine_betaTranspose_complete112 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches112,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches112,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node111 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known111 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known111 a) ((3 : Int),(4 : Int)) (affine_betaTranspose_branches111 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative111 a ha) (affine_betaTranspose_window111 a ha world h B state)
    (affine_betaTranspose_empty111 a ha) (affine_betaTranspose_complete111 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches111,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches111,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node110 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known110 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known110 a) ((5 : Int),(1 : Int)) (affine_betaTranspose_branches110 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative110 a ha) (affine_betaTranspose_window110 a ha world h B state)
    (affine_betaTranspose_empty110 a ha) (affine_betaTranspose_complete110 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches110,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known110,affine_betaTranspose_known111,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known110,affine_betaTranspose_known112,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches110,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node111 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node112 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node109 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known109 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known109 a) ((3 : Int),(4 : Int)) (affine_betaTranspose_branches109 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative109 a ha) (affine_betaTranspose_window109 a ha world h B state)
    (affine_betaTranspose_empty109 a ha) (affine_betaTranspose_complete109 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches109,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches109,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node108 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known108 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known108 a) ((3 : Int),(4 : Int)) (affine_betaTranspose_branches108 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative108 a ha) (affine_betaTranspose_window108 a ha world h B state)
    (affine_betaTranspose_empty108 a ha) (affine_betaTranspose_complete108 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches108,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches108,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node107 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known107 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known107 a) ((5 : Int),(1 : Int)) (affine_betaTranspose_branches107 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative107 a ha) (affine_betaTranspose_window107 a ha world h B state)
    (affine_betaTranspose_empty107 a ha) (affine_betaTranspose_complete107 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches107,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known107,affine_betaTranspose_known108,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known107,affine_betaTranspose_known109,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches107,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node108 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node109 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node106 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known106 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known106 a) ((3 : Int),(3 : Int)) (affine_betaTranspose_branches106 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative106 a ha) (affine_betaTranspose_window106 a ha world h B state)
    (affine_betaTranspose_empty106 a ha) (affine_betaTranspose_complete106 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches106,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known106,affine_betaTranspose_known107,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known106,affine_betaTranspose_known110,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches106,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node107 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node110 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_betaTranspose_node105 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known105 a)) B) : Transition world h .betaTranspose B := by
  exact affine_betaTranspose_leaf105 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node104 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known104 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known104 a) ((3 : Int),(2 : Int)) (affine_betaTranspose_branches104 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative104 a ha) (affine_betaTranspose_window104 a ha world h B state)
    (affine_betaTranspose_empty104 a ha) (affine_betaTranspose_complete104 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches104,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known104,affine_betaTranspose_known105,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known104,affine_betaTranspose_known106,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known104,affine_betaTranspose_known113,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known104,affine_betaTranspose_known115,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known104,affine_betaTranspose_known116,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches104,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · exact affine_betaTranspose_node105 a ha world h nextB nextState
    · exact affine_betaTranspose_node106 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node113 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node115 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node116 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_betaTranspose_node103 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known103 a)) B) : Transition world h .betaTranspose B := by
  exact affine_betaTranspose_leaf103 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node102 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known102 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known102 a) ((2 : Int),(1 : Int)) (affine_betaTranspose_branches102 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative102 a ha) (affine_betaTranspose_window102 a ha world h B state)
    (affine_betaTranspose_empty102 a ha) (affine_betaTranspose_complete102 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches102,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known102,affine_betaTranspose_known103,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known102,affine_betaTranspose_known104,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches102,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node103 a ha world h nextB nextState
    · exact affine_betaTranspose_node104 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node101 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known101 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known101 a) ((3 : Int),(1 : Int)) (affine_betaTranspose_branches101 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative101 a ha) (affine_betaTranspose_window101 a ha world h B state)
    (affine_betaTranspose_empty101 a ha) (affine_betaTranspose_complete101 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches101,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches101,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node100 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known100 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known100 a) ((3 : Int),(2 : Int)) (affine_betaTranspose_branches100 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative100 a ha) (affine_betaTranspose_window100 a ha world h B state)
    (affine_betaTranspose_empty100 a ha) (affine_betaTranspose_complete100 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches100,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches100,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node099 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known099 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known099 a) ((3 : Int),(2 : Int)) (affine_betaTranspose_branches099 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative099 a ha) (affine_betaTranspose_window099 a ha world h B state)
    (affine_betaTranspose_empty099 a ha) (affine_betaTranspose_complete099 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches099,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches099,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node098 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known098 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known098 a) ((3 : Int),(1 : Int)) (affine_betaTranspose_branches098 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative098 a ha) (affine_betaTranspose_window098 a ha world h B state)
    (affine_betaTranspose_empty098 a ha) (affine_betaTranspose_complete098 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches098,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known098,affine_betaTranspose_known099,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known098,affine_betaTranspose_known100,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches098,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node099 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node100 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node097 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known097 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known097 a) ((3 : Int),(1 : Int)) (affine_betaTranspose_branches097 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative097 a ha) (affine_betaTranspose_window097 a ha world h B state)
    (affine_betaTranspose_empty097 a ha) (affine_betaTranspose_complete097 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches097,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches097,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node096 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known096 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known096 a) ((3 : Int),(0 : Int)) (affine_betaTranspose_branches096 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative096 a ha) (affine_betaTranspose_window096 a ha world h B state)
    (affine_betaTranspose_empty096 a ha) (affine_betaTranspose_complete096 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches096,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known096,affine_betaTranspose_known097,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known096,affine_betaTranspose_known098,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known096,affine_betaTranspose_known101,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches096,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_betaTranspose_node097 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node098 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node101 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node095 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known095 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known095 a) ((4 : Int),(1 : Int)) (affine_betaTranspose_branches095 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative095 a ha) (affine_betaTranspose_window095 a ha world h B state)
    (affine_betaTranspose_empty095 a ha) (affine_betaTranspose_complete095 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches095,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches095,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node094 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known094 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known094 a) ((4 : Int),(1 : Int)) (affine_betaTranspose_branches094 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative094 a ha) (affine_betaTranspose_window094 a ha world h B state)
    (affine_betaTranspose_empty094 a ha) (affine_betaTranspose_complete094 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches094,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches094,List.mem_cons,List.not_mem_nil,or_false] at member
include ha in
theorem affine_betaTranspose_node093 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known093 a)) B) : Transition world h .betaTranspose B := by
  exact affine_betaTranspose_leaf093 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node092 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known092 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known092 a) ((6 : Int),(1 : Int)) (affine_betaTranspose_branches092 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative092 a ha) (affine_betaTranspose_window092 a ha world h B state)
    (affine_betaTranspose_empty092 a ha) (affine_betaTranspose_complete092 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches092,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches092,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node091 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known091 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known091 a) ((6 : Int),(1 : Int)) (affine_betaTranspose_branches091 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative091 a ha) (affine_betaTranspose_window091 a ha world h B state)
    (affine_betaTranspose_empty091 a ha) (affine_betaTranspose_complete091 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches091,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches091,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node090 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known090 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known090 a) ((5 : Int),(1 : Int)) (affine_betaTranspose_branches090 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative090 a ha) (affine_betaTranspose_window090 a ha world h B state)
    (affine_betaTranspose_empty090 a ha) (affine_betaTranspose_complete090 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches090,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known090,affine_betaTranspose_known091,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known090,affine_betaTranspose_known092,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches090,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node091 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node092 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node089 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known089 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known089 a) ((6 : Int),(1 : Int)) (affine_betaTranspose_branches089 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative089 a ha) (affine_betaTranspose_window089 a ha world h B state)
    (affine_betaTranspose_empty089 a ha) (affine_betaTranspose_complete089 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches089,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches089,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node088 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known088 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known088 a) ((6 : Int),(1 : Int)) (affine_betaTranspose_branches088 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative088 a ha) (affine_betaTranspose_window088 a ha world h B state)
    (affine_betaTranspose_empty088 a ha) (affine_betaTranspose_complete088 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches088,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches088,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node087 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known087 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known087 a) ((5 : Int),(1 : Int)) (affine_betaTranspose_branches087 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative087 a ha) (affine_betaTranspose_window087 a ha world h B state)
    (affine_betaTranspose_empty087 a ha) (affine_betaTranspose_complete087 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches087,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known087,affine_betaTranspose_known088,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known087,affine_betaTranspose_known089,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches087,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node088 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node089 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node086 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known086 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known086 a) ((3 : Int),(3 : Int)) (affine_betaTranspose_branches086 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative086 a ha) (affine_betaTranspose_window086 a ha world h B state)
    (affine_betaTranspose_empty086 a ha) (affine_betaTranspose_complete086 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches086,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known086,affine_betaTranspose_known087,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known086,affine_betaTranspose_known090,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches086,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node087 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node090 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node085 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known085 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known085 a) ((4 : Int),(1 : Int)) (affine_betaTranspose_branches085 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative085 a ha) (affine_betaTranspose_window085 a ha world h B state)
    (affine_betaTranspose_empty085 a ha) (affine_betaTranspose_complete085 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches085,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches085,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node084 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known084 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known084 a) ((4 : Int),(1 : Int)) (affine_betaTranspose_branches084 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative084 a ha) (affine_betaTranspose_window084 a ha world h B state)
    (affine_betaTranspose_empty084 a ha) (affine_betaTranspose_complete084 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches084,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches084,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node083 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known083 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known083 a) ((5 : Int),(1 : Int)) (affine_betaTranspose_branches083 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative083 a ha) (affine_betaTranspose_window083 a ha world h B state)
    (affine_betaTranspose_empty083 a ha) (affine_betaTranspose_complete083 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches083,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches083,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node082 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known082 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known082 a) ((5 : Int),(1 : Int)) (affine_betaTranspose_branches082 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative082 a ha) (affine_betaTranspose_window082 a ha world h B state)
    (affine_betaTranspose_empty082 a ha) (affine_betaTranspose_complete082 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches082,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches082,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node081 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known081 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known081 a) ((4 : Int),(1 : Int)) (affine_betaTranspose_branches081 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative081 a ha) (affine_betaTranspose_window081 a ha world h B state)
    (affine_betaTranspose_empty081 a ha) (affine_betaTranspose_complete081 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches081,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known081,affine_betaTranspose_known082,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known081,affine_betaTranspose_known083,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches081,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node082 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node083 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node080 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known080 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known080 a) ((3 : Int),(2 : Int)) (affine_betaTranspose_branches080 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative080 a ha) (affine_betaTranspose_window080 a ha world h B state)
    (affine_betaTranspose_empty080 a ha) (affine_betaTranspose_complete080 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches080,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known080,affine_betaTranspose_known081,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known080,affine_betaTranspose_known084,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known080,affine_betaTranspose_known085,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known080,affine_betaTranspose_known086,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known080,affine_betaTranspose_known093,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known080,affine_betaTranspose_known094,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known080,affine_betaTranspose_known095,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches080,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact affine_betaTranspose_node081 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node084 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node085 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node086 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node093 a ha world h nextB nextState
    · exact affine_betaTranspose_node094 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node095 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_betaTranspose_node079 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known079 a)) B) : Transition world h .betaTranspose B := by
  exact affine_betaTranspose_leaf079 a ha world h B state
include ha in
theorem affine_betaTranspose_node078 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known078 a)) B) : Transition world h .betaTranspose B := by
  exact affine_betaTranspose_leaf078 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node077 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known077 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known077 a) ((3 : Int),(0 : Int)) (affine_betaTranspose_branches077 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative077 a ha) (affine_betaTranspose_window077 a ha world h B state)
    (affine_betaTranspose_empty077 a ha) (affine_betaTranspose_complete077 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches077,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known077,affine_betaTranspose_known078,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known077,affine_betaTranspose_known079,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known077,affine_betaTranspose_known080,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches077,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_betaTranspose_node078 a ha world h nextB nextState
    · exact affine_betaTranspose_node079 a ha world h nextB nextState
    · exact affine_betaTranspose_node080 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node076 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known076 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known076 a) ((2 : Int),(0 : Int)) (affine_betaTranspose_branches076 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative076 a ha) (affine_betaTranspose_window076 a ha world h B state)
    (affine_betaTranspose_empty076 a ha) (affine_betaTranspose_complete076 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches076,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known076,affine_betaTranspose_known077,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known076,affine_betaTranspose_known096,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known076,affine_betaTranspose_known102,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known076,affine_betaTranspose_known118,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known076,affine_betaTranspose_known119,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches076,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · exact affine_betaTranspose_node077 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node096 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node102 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node118 a ha world h nextB nextState
    · exact affine_betaTranspose_node119 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node075 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known075 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known075 a) ((3 : Int),(1 : Int)) (affine_betaTranspose_branches075 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative075 a ha) (affine_betaTranspose_window075 a ha world h B state)
    (affine_betaTranspose_empty075 a ha) (affine_betaTranspose_complete075 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches075,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches075,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node074 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known074 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known074 a) ((3 : Int),(1 : Int)) (affine_betaTranspose_branches074 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative074 a ha) (affine_betaTranspose_window074 a ha world h B state)
    (affine_betaTranspose_empty074 a ha) (affine_betaTranspose_complete074 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches074,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches074,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node073 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known073 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known073 a) ((2 : Int),(1 : Int)) (affine_betaTranspose_branches073 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative073 a ha) (affine_betaTranspose_window073 a ha world h B state)
    (affine_betaTranspose_empty073 a ha) (affine_betaTranspose_complete073 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches073,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known073,affine_betaTranspose_known074,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known073,affine_betaTranspose_known075,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches073,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node074 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node075 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_betaTranspose_node072 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known072 a)) B) : Transition world h .betaTranspose B := by
  exact affine_betaTranspose_leaf072 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node071 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known071 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known071 a) ((3 : Int),(3 : Int)) (affine_betaTranspose_branches071 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative071 a ha) (affine_betaTranspose_window071 a ha world h B state)
    (affine_betaTranspose_empty071 a ha) (affine_betaTranspose_complete071 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches071,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches071,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node070 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known070 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known070 a) ((4 : Int),(1 : Int)) (affine_betaTranspose_branches070 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative070 a ha) (affine_betaTranspose_window070 a ha world h B state)
    (affine_betaTranspose_empty070 a ha) (affine_betaTranspose_complete070 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches070,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known070,affine_betaTranspose_known071,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches070,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_betaTranspose_node071 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node069 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known069 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known069 a) ((4 : Int),(1 : Int)) (affine_betaTranspose_branches069 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative069 a ha) (affine_betaTranspose_window069 a ha world h B state)
    (affine_betaTranspose_empty069 a ha) (affine_betaTranspose_complete069 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches069,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches069,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node068 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known068 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known068 a) ((3 : Int),(3 : Int)) (affine_betaTranspose_branches068 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative068 a ha) (affine_betaTranspose_window068 a ha world h B state)
    (affine_betaTranspose_empty068 a ha) (affine_betaTranspose_complete068 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches068,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches068,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node067 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known067 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known067 a) ((4 : Int),(1 : Int)) (affine_betaTranspose_branches067 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative067 a ha) (affine_betaTranspose_window067 a ha world h B state)
    (affine_betaTranspose_empty067 a ha) (affine_betaTranspose_complete067 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches067,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known067,affine_betaTranspose_known068,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches067,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_betaTranspose_node068 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node066 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known066 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known066 a) ((3 : Int),(4 : Int)) (affine_betaTranspose_branches066 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative066 a ha) (affine_betaTranspose_window066 a ha world h B state)
    (affine_betaTranspose_empty066 a ha) (affine_betaTranspose_complete066 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches066,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches066,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node065 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known065 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known065 a) ((3 : Int),(4 : Int)) (affine_betaTranspose_branches065 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative065 a ha) (affine_betaTranspose_window065 a ha world h B state)
    (affine_betaTranspose_empty065 a ha) (affine_betaTranspose_complete065 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches065,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches065,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node064 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known064 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known064 a) ((5 : Int),(1 : Int)) (affine_betaTranspose_branches064 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative064 a ha) (affine_betaTranspose_window064 a ha world h B state)
    (affine_betaTranspose_empty064 a ha) (affine_betaTranspose_complete064 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches064,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known064,affine_betaTranspose_known065,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known064,affine_betaTranspose_known066,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches064,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node065 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node066 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node063 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known063 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known063 a) ((3 : Int),(4 : Int)) (affine_betaTranspose_branches063 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative063 a ha) (affine_betaTranspose_window063 a ha world h B state)
    (affine_betaTranspose_empty063 a ha) (affine_betaTranspose_complete063 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches063,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches063,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node062 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known062 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known062 a) ((3 : Int),(4 : Int)) (affine_betaTranspose_branches062 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative062 a ha) (affine_betaTranspose_window062 a ha world h B state)
    (affine_betaTranspose_empty062 a ha) (affine_betaTranspose_complete062 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches062,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches062,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node061 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known061 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known061 a) ((5 : Int),(1 : Int)) (affine_betaTranspose_branches061 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative061 a ha) (affine_betaTranspose_window061 a ha world h B state)
    (affine_betaTranspose_empty061 a ha) (affine_betaTranspose_complete061 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches061,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known061,affine_betaTranspose_known062,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known061,affine_betaTranspose_known063,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches061,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node062 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node063 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node060 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known060 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known060 a) ((3 : Int),(3 : Int)) (affine_betaTranspose_branches060 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative060 a ha) (affine_betaTranspose_window060 a ha world h B state)
    (affine_betaTranspose_empty060 a ha) (affine_betaTranspose_complete060 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches060,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known060,affine_betaTranspose_known061,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known060,affine_betaTranspose_known064,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches060,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node061 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node064 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_betaTranspose_node059 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known059 a)) B) : Transition world h .betaTranspose B := by
  exact affine_betaTranspose_leaf059 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node058 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known058 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known058 a) ((3 : Int),(2 : Int)) (affine_betaTranspose_branches058 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative058 a ha) (affine_betaTranspose_window058 a ha world h B state)
    (affine_betaTranspose_empty058 a ha) (affine_betaTranspose_complete058 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches058,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known058,affine_betaTranspose_known059,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known058,affine_betaTranspose_known060,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known058,affine_betaTranspose_known067,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known058,affine_betaTranspose_known069,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known058,affine_betaTranspose_known070,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches058,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · exact affine_betaTranspose_node059 a ha world h nextB nextState
    · exact affine_betaTranspose_node060 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node067 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node069 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node070 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_betaTranspose_node057 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known057 a)) B) : Transition world h .betaTranspose B := by
  exact affine_betaTranspose_leaf057 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node056 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known056 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known056 a) ((2 : Int),(1 : Int)) (affine_betaTranspose_branches056 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative056 a ha) (affine_betaTranspose_window056 a ha world h B state)
    (affine_betaTranspose_empty056 a ha) (affine_betaTranspose_complete056 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches056,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known056,affine_betaTranspose_known057,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known056,affine_betaTranspose_known058,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches056,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node057 a ha world h nextB nextState
    · exact affine_betaTranspose_node058 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node055 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known055 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known055 a) ((3 : Int),(1 : Int)) (affine_betaTranspose_branches055 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative055 a ha) (affine_betaTranspose_window055 a ha world h B state)
    (affine_betaTranspose_empty055 a ha) (affine_betaTranspose_complete055 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches055,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches055,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node054 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known054 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known054 a) ((3 : Int),(2 : Int)) (affine_betaTranspose_branches054 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative054 a ha) (affine_betaTranspose_window054 a ha world h B state)
    (affine_betaTranspose_empty054 a ha) (affine_betaTranspose_complete054 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches054,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches054,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node053 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known053 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known053 a) ((3 : Int),(2 : Int)) (affine_betaTranspose_branches053 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative053 a ha) (affine_betaTranspose_window053 a ha world h B state)
    (affine_betaTranspose_empty053 a ha) (affine_betaTranspose_complete053 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches053,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches053,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node052 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known052 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known052 a) ((3 : Int),(1 : Int)) (affine_betaTranspose_branches052 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative052 a ha) (affine_betaTranspose_window052 a ha world h B state)
    (affine_betaTranspose_empty052 a ha) (affine_betaTranspose_complete052 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches052,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known052,affine_betaTranspose_known053,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known052,affine_betaTranspose_known054,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches052,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node053 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node054 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node051 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known051 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known051 a) ((3 : Int),(1 : Int)) (affine_betaTranspose_branches051 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative051 a ha) (affine_betaTranspose_window051 a ha world h B state)
    (affine_betaTranspose_empty051 a ha) (affine_betaTranspose_complete051 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches051,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches051,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node050 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known050 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known050 a) ((3 : Int),(0 : Int)) (affine_betaTranspose_branches050 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative050 a ha) (affine_betaTranspose_window050 a ha world h B state)
    (affine_betaTranspose_empty050 a ha) (affine_betaTranspose_complete050 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches050,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known050,affine_betaTranspose_known051,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known050,affine_betaTranspose_known052,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known050,affine_betaTranspose_known055,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches050,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_betaTranspose_node051 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node052 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node055 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node049 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known049 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known049 a) ((4 : Int),(1 : Int)) (affine_betaTranspose_branches049 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative049 a ha) (affine_betaTranspose_window049 a ha world h B state)
    (affine_betaTranspose_empty049 a ha) (affine_betaTranspose_complete049 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches049,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches049,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node048 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known048 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known048 a) ((4 : Int),(1 : Int)) (affine_betaTranspose_branches048 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative048 a ha) (affine_betaTranspose_window048 a ha world h B state)
    (affine_betaTranspose_empty048 a ha) (affine_betaTranspose_complete048 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches048,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches048,List.mem_cons,List.not_mem_nil,or_false] at member
include ha in
theorem affine_betaTranspose_node047 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known047 a)) B) : Transition world h .betaTranspose B := by
  exact affine_betaTranspose_leaf047 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node046 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known046 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known046 a) ((6 : Int),(1 : Int)) (affine_betaTranspose_branches046 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative046 a ha) (affine_betaTranspose_window046 a ha world h B state)
    (affine_betaTranspose_empty046 a ha) (affine_betaTranspose_complete046 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches046,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches046,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node045 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known045 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known045 a) ((6 : Int),(1 : Int)) (affine_betaTranspose_branches045 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative045 a ha) (affine_betaTranspose_window045 a ha world h B state)
    (affine_betaTranspose_empty045 a ha) (affine_betaTranspose_complete045 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches045,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches045,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node044 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known044 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known044 a) ((5 : Int),(1 : Int)) (affine_betaTranspose_branches044 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative044 a ha) (affine_betaTranspose_window044 a ha world h B state)
    (affine_betaTranspose_empty044 a ha) (affine_betaTranspose_complete044 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches044,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known044,affine_betaTranspose_known045,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known044,affine_betaTranspose_known046,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches044,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node045 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node046 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node043 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known043 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known043 a) ((6 : Int),(1 : Int)) (affine_betaTranspose_branches043 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative043 a ha) (affine_betaTranspose_window043 a ha world h B state)
    (affine_betaTranspose_empty043 a ha) (affine_betaTranspose_complete043 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches043,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches043,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node042 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known042 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known042 a) ((6 : Int),(1 : Int)) (affine_betaTranspose_branches042 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative042 a ha) (affine_betaTranspose_window042 a ha world h B state)
    (affine_betaTranspose_empty042 a ha) (affine_betaTranspose_complete042 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches042,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches042,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node041 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known041 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known041 a) ((5 : Int),(1 : Int)) (affine_betaTranspose_branches041 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative041 a ha) (affine_betaTranspose_window041 a ha world h B state)
    (affine_betaTranspose_empty041 a ha) (affine_betaTranspose_complete041 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches041,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known041,affine_betaTranspose_known042,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known041,affine_betaTranspose_known043,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches041,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node042 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node043 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node040 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known040 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known040 a) ((3 : Int),(3 : Int)) (affine_betaTranspose_branches040 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative040 a ha) (affine_betaTranspose_window040 a ha world h B state)
    (affine_betaTranspose_empty040 a ha) (affine_betaTranspose_complete040 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches040,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known040,affine_betaTranspose_known041,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known040,affine_betaTranspose_known044,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches040,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node041 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node044 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node039 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known039 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known039 a) ((4 : Int),(1 : Int)) (affine_betaTranspose_branches039 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative039 a ha) (affine_betaTranspose_window039 a ha world h B state)
    (affine_betaTranspose_empty039 a ha) (affine_betaTranspose_complete039 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches039,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches039,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node038 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known038 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known038 a) ((4 : Int),(1 : Int)) (affine_betaTranspose_branches038 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative038 a ha) (affine_betaTranspose_window038 a ha world h B state)
    (affine_betaTranspose_empty038 a ha) (affine_betaTranspose_complete038 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches038,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches038,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node037 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known037 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known037 a) ((5 : Int),(1 : Int)) (affine_betaTranspose_branches037 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative037 a ha) (affine_betaTranspose_window037 a ha world h B state)
    (affine_betaTranspose_empty037 a ha) (affine_betaTranspose_complete037 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches037,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches037,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node036 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known036 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known036 a) ((5 : Int),(1 : Int)) (affine_betaTranspose_branches036 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative036 a ha) (affine_betaTranspose_window036 a ha world h B state)
    (affine_betaTranspose_empty036 a ha) (affine_betaTranspose_complete036 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches036,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches036,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node035 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known035 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known035 a) ((4 : Int),(1 : Int)) (affine_betaTranspose_branches035 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative035 a ha) (affine_betaTranspose_window035 a ha world h B state)
    (affine_betaTranspose_empty035 a ha) (affine_betaTranspose_complete035 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches035,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known035,affine_betaTranspose_known036,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known035,affine_betaTranspose_known037,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches035,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node036 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node037 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node034 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known034 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known034 a) ((3 : Int),(2 : Int)) (affine_betaTranspose_branches034 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative034 a ha) (affine_betaTranspose_window034 a ha world h B state)
    (affine_betaTranspose_empty034 a ha) (affine_betaTranspose_complete034 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches034,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known034,affine_betaTranspose_known035,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known034,affine_betaTranspose_known038,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known034,affine_betaTranspose_known039,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known034,affine_betaTranspose_known040,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known034,affine_betaTranspose_known047,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known034,affine_betaTranspose_known048,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known034,affine_betaTranspose_known049,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches034,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact affine_betaTranspose_node035 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node038 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node039 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node040 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node047 a ha world h nextB nextState
    · exact affine_betaTranspose_node048 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node049 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_betaTranspose_node033 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known033 a)) B) : Transition world h .betaTranspose B := by
  exact affine_betaTranspose_leaf033 a ha world h B state
include ha in
theorem affine_betaTranspose_node032 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known032 a)) B) : Transition world h .betaTranspose B := by
  exact affine_betaTranspose_leaf032 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node031 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known031 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known031 a) ((3 : Int),(0 : Int)) (affine_betaTranspose_branches031 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative031 a ha) (affine_betaTranspose_window031 a ha world h B state)
    (affine_betaTranspose_empty031 a ha) (affine_betaTranspose_complete031 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches031,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known031,affine_betaTranspose_known032,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known031,affine_betaTranspose_known033,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known031,affine_betaTranspose_known034,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches031,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_betaTranspose_node032 a ha world h nextB nextState
    · exact affine_betaTranspose_node033 a ha world h nextB nextState
    · exact affine_betaTranspose_node034 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node030 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known030 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known030 a) ((2 : Int),(0 : Int)) (affine_betaTranspose_branches030 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative030 a ha) (affine_betaTranspose_window030 a ha world h B state)
    (affine_betaTranspose_empty030 a ha) (affine_betaTranspose_complete030 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches030,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known030,affine_betaTranspose_known031,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known030,affine_betaTranspose_known050,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known030,affine_betaTranspose_known056,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known030,affine_betaTranspose_known072,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known030,affine_betaTranspose_known073,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches030,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · exact affine_betaTranspose_node031 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node050 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node056 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node072 a ha world h nextB nextState
    · exact affine_betaTranspose_node073 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node029 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known029 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known029 a) ((0 : Int),(2 : Int)) (affine_betaTranspose_branches029 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative029 a ha) (affine_betaTranspose_window029 a ha world h B state)
    (affine_betaTranspose_empty029 a ha) (affine_betaTranspose_complete029 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches029,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known029,affine_betaTranspose_known030,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known029,affine_betaTranspose_known076,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches029,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node030 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node076 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node028 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known028 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known028 a) ((1 : Int),(1 : Int)) (affine_betaTranspose_branches028 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative028 a ha) (affine_betaTranspose_window028 a ha world h B state)
    (affine_betaTranspose_empty028 a ha) (affine_betaTranspose_complete028 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches028,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches028,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node027 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known027 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known027 a) ((1 : Int),(2 : Int)) (affine_betaTranspose_branches027 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative027 a ha) (affine_betaTranspose_window027 a ha world h B state)
    (affine_betaTranspose_empty027 a ha) (affine_betaTranspose_complete027 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches027,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches027,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node026 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known026 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known026 a) ((1 : Int),(2 : Int)) (affine_betaTranspose_branches026 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative026 a ha) (affine_betaTranspose_window026 a ha world h B state)
    (affine_betaTranspose_empty026 a ha) (affine_betaTranspose_complete026 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches026,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches026,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node025 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known025 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known025 a) ((1 : Int),(1 : Int)) (affine_betaTranspose_branches025 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative025 a ha) (affine_betaTranspose_window025 a ha world h B state)
    (affine_betaTranspose_empty025 a ha) (affine_betaTranspose_complete025 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches025,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known025,affine_betaTranspose_known026,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known025,affine_betaTranspose_known027,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches025,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node026 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node027 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node024 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known024 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known024 a) ((1 : Int),(1 : Int)) (affine_betaTranspose_branches024 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative024 a ha) (affine_betaTranspose_window024 a ha world h B state)
    (affine_betaTranspose_empty024 a ha) (affine_betaTranspose_complete024 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches024,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches024,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node023 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known023 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known023 a) ((1 : Int),(0 : Int)) (affine_betaTranspose_branches023 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative023 a ha) (affine_betaTranspose_window023 a ha world h B state)
    (affine_betaTranspose_empty023 a ha) (affine_betaTranspose_complete023 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches023,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known023,affine_betaTranspose_known024,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known023,affine_betaTranspose_known025,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known023,affine_betaTranspose_known028,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches023,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_betaTranspose_node024 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node025 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node028 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node022 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known022 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known022 a) ((1 : Int),(1 : Int)) (affine_betaTranspose_branches022 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative022 a ha) (affine_betaTranspose_window022 a ha world h B state)
    (affine_betaTranspose_empty022 a ha) (affine_betaTranspose_complete022 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches022,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches022,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node021 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known021 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known021 a) ((2 : Int),(2 : Int)) (affine_betaTranspose_branches021 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative021 a ha) (affine_betaTranspose_window021 a ha world h B state)
    (affine_betaTranspose_empty021 a ha) (affine_betaTranspose_complete021 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches021,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches021,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node020 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known020 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known020 a) ((2 : Int),(2 : Int)) (affine_betaTranspose_branches020 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative020 a ha) (affine_betaTranspose_window020 a ha world h B state)
    (affine_betaTranspose_empty020 a ha) (affine_betaTranspose_complete020 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches020,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches020,List.mem_cons,List.not_mem_nil,or_false] at member
include ha in
theorem affine_betaTranspose_node019 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known019 a)) B) : Transition world h .betaTranspose B := by
  exact affine_betaTranspose_leaf019 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node018 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known018 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known018 a) ((4 : Int),(2 : Int)) (affine_betaTranspose_branches018 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative018 a ha) (affine_betaTranspose_window018 a ha world h B state)
    (affine_betaTranspose_empty018 a ha) (affine_betaTranspose_complete018 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches018,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches018,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node017 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known017 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known017 a) ((4 : Int),(2 : Int)) (affine_betaTranspose_branches017 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative017 a ha) (affine_betaTranspose_window017 a ha world h B state)
    (affine_betaTranspose_empty017 a ha) (affine_betaTranspose_complete017 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches017,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches017,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node016 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known016 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known016 a) ((3 : Int),(2 : Int)) (affine_betaTranspose_branches016 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative016 a ha) (affine_betaTranspose_window016 a ha world h B state)
    (affine_betaTranspose_empty016 a ha) (affine_betaTranspose_complete016 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches016,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known016,affine_betaTranspose_known017,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known016,affine_betaTranspose_known018,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches016,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node017 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node018 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node015 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known015 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known015 a) ((4 : Int),(2 : Int)) (affine_betaTranspose_branches015 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative015 a ha) (affine_betaTranspose_window015 a ha world h B state)
    (affine_betaTranspose_empty015 a ha) (affine_betaTranspose_complete015 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches015,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches015,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node014 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known014 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known014 a) ((4 : Int),(2 : Int)) (affine_betaTranspose_branches014 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative014 a ha) (affine_betaTranspose_window014 a ha world h B state)
    (affine_betaTranspose_empty014 a ha) (affine_betaTranspose_complete014 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches014,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches014,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node013 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known013 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known013 a) ((3 : Int),(2 : Int)) (affine_betaTranspose_branches013 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative013 a ha) (affine_betaTranspose_window013 a ha world h B state)
    (affine_betaTranspose_empty013 a ha) (affine_betaTranspose_complete013 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches013,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known013,affine_betaTranspose_known014,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known013,affine_betaTranspose_known015,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches013,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node014 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node015 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node012 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known012 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known012 a) ((1 : Int),(4 : Int)) (affine_betaTranspose_branches012 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative012 a ha) (affine_betaTranspose_window012 a ha world h B state)
    (affine_betaTranspose_empty012 a ha) (affine_betaTranspose_complete012 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches012,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known012,affine_betaTranspose_known013,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known012,affine_betaTranspose_known016,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches012,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node013 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node016 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node011 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known011 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known011 a) ((2 : Int),(2 : Int)) (affine_betaTranspose_branches011 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative011 a ha) (affine_betaTranspose_window011 a ha world h B state)
    (affine_betaTranspose_empty011 a ha) (affine_betaTranspose_complete011 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches011,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches011,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node010 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known010 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known010 a) ((2 : Int),(2 : Int)) (affine_betaTranspose_branches010 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative010 a ha) (affine_betaTranspose_window010 a ha world h B state)
    (affine_betaTranspose_empty010 a ha) (affine_betaTranspose_complete010 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches010,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches010,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node009 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known009 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known009 a) ((3 : Int),(2 : Int)) (affine_betaTranspose_branches009 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative009 a ha) (affine_betaTranspose_window009 a ha world h B state)
    (affine_betaTranspose_empty009 a ha) (affine_betaTranspose_complete009 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches009,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches009,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node008 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known008 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known008 a) ((3 : Int),(2 : Int)) (affine_betaTranspose_branches008 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative008 a ha) (affine_betaTranspose_window008 a ha world h B state)
    (affine_betaTranspose_empty008 a ha) (affine_betaTranspose_complete008 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches008,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches008,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node007 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known007 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known007 a) ((2 : Int),(2 : Int)) (affine_betaTranspose_branches007 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative007 a ha) (affine_betaTranspose_window007 a ha world h B state)
    (affine_betaTranspose_empty007 a ha) (affine_betaTranspose_complete007 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches007,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known007,affine_betaTranspose_known008,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known007,affine_betaTranspose_known009,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches007,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node008 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node009 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node006 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known006 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known006 a) ((1 : Int),(3 : Int)) (affine_betaTranspose_branches006 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative006 a ha) (affine_betaTranspose_window006 a ha world h B state)
    (affine_betaTranspose_empty006 a ha) (affine_betaTranspose_complete006 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches006,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known006,affine_betaTranspose_known007,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known006,affine_betaTranspose_known010,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known006,affine_betaTranspose_known011,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known006,affine_betaTranspose_known012,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known006,affine_betaTranspose_known019,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known006,affine_betaTranspose_known020,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known006,affine_betaTranspose_known021,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches006,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact affine_betaTranspose_node007 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node010 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node011 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node012 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node019 a ha world h nextB nextState
    · exact affine_betaTranspose_node020 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node021 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_betaTranspose_node005 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known005 a)) B) : Transition world h .betaTranspose B := by
  exact affine_betaTranspose_leaf005 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node004 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known004 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known004 a) ((1 : Int),(1 : Int)) (affine_betaTranspose_branches004 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative004 a ha) (affine_betaTranspose_window004 a ha world h B state)
    (affine_betaTranspose_empty004 a ha) (affine_betaTranspose_complete004 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches004,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known004,affine_betaTranspose_known005,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known004,affine_betaTranspose_known006,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches004,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_betaTranspose_node005 a ha world h nextB nextState
    · exact affine_betaTranspose_node006 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node003 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known003 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known003 a) ((1 : Int),(1 : Int)) (affine_betaTranspose_branches003 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative003 a ha) (affine_betaTranspose_window003 a ha world h B state)
    (affine_betaTranspose_empty003 a ha) (affine_betaTranspose_complete003 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches003,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches003,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node002 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known002 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known002 a) ((1 : Int),(0 : Int)) (affine_betaTranspose_branches002 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative002 a ha) (affine_betaTranspose_window002 a ha world h B state)
    (affine_betaTranspose_empty002 a ha) (affine_betaTranspose_complete002 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches002,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known002,affine_betaTranspose_known003,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known002,affine_betaTranspose_known004,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known002,affine_betaTranspose_known022,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches002,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_betaTranspose_node003 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node004 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node022 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_betaTranspose_node001 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known001 a)) B) : Transition world h .betaTranspose B := by
  exact affine_betaTranspose_leaf001 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_betaTranspose_node000 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_betaTranspose_known000 a)) B) : Transition world h .betaTranspose B := by
  apply replay_affine_step a (by omega) world h .betaTranspose (affine_betaTranspose_known000 a) ((0 : Int),(1 : Int)) (affine_betaTranspose_branches000 a) copies separate cover ceiling
    (affine_betaTranspose_nonnegative000 a ha) (affine_betaTranspose_window000 a ha world h B state)
    (affine_betaTranspose_empty000 a ha) (affine_betaTranspose_complete000 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_betaTranspose_branches000,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known000,affine_betaTranspose_known001,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known000,affine_betaTranspose_known002,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known000,affine_betaTranspose_known023,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known000,affine_betaTranspose_known029,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known000,affine_betaTranspose_known122,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known000,affine_betaTranspose_known123,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known000,affine_betaTranspose_known141,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_betaTranspose_known000,affine_betaTranspose_known142,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_betaTranspose_branches000,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact affine_betaTranspose_node001 a ha world h nextB nextState
    · exact affine_betaTranspose_node002 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node023 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node029 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node122 a ha world h nextB nextState
    · exact affine_betaTranspose_node123 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_betaTranspose_node141 a ha world h nextB nextState
    · exact affine_betaTranspose_node142 a ha world h copies separate cover ceiling nextB nextState
end AffineBetaTranspose

theorem affine_betaTranspose_seed_eq (a : Int) : SameCells (seed .betaTranspose) (knownCells (affine_betaTranspose_known000 a)) := by
  change SameCells (seed .betaTranspose) (knownCells (affine_betaTranspose_known000 (0 : Int)))
  decide

theorem affine_betaTranspose_local (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (copies : ∀ t, world t → Copy a 1 1 0 t)
    (separate : DisjointWorld world) (cover : CoversWindow world h)
    (ceiling : SelectedBelow world h) (closed : TileClosed world B)
    (bounded : Below h B) (clean : Clean .betaTranspose 0 0 B) : Transition world h .betaTranspose B := by
  exact affine_betaTranspose_node000 a ha world h copies separate cover ceiling B
    (state_congr (affine_betaTranspose_seed_eq a) (seed_state world h .betaTranspose B closed bounded clean))
#print axioms affine_betaTranspose_local

end CornerCertificate

import CornerCertificateAffineGammaTransposeGeometry

set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace CornerCertificate
open CrossUnits

section AffineGammaTranspose
variable (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (copies : ∀ t, world t → Copy a 1 1 0 t)
    (separate : DisjointWorld world) (cover : CoversWindow world h)
    (ceiling : SelectedBelow world h)

include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node186 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known186 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known186 a) ((1 : Int),(1 : Int)) (affine_gammaTranspose_branches186 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative186 a ha) (affine_gammaTranspose_window186 a ha world h B state)
    (affine_gammaTranspose_empty186 a ha) (affine_gammaTranspose_complete186 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches186,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches186,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node185 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known185 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known185 a) ((1 : Int),(1 : Int)) (affine_gammaTranspose_branches185 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative185 a ha) (affine_gammaTranspose_window185 a ha world h B state)
    (affine_gammaTranspose_empty185 a ha) (affine_gammaTranspose_complete185 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches185,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches185,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node184 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known184 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known184 a) ((1 : Int),(1 : Int)) (affine_gammaTranspose_branches184 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative184 a ha) (affine_gammaTranspose_window184 a ha world h B state)
    (affine_gammaTranspose_empty184 a ha) (affine_gammaTranspose_complete184 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches184,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches184,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node183 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known183 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known183 a) ((2 : Int),(1 : Int)) (affine_gammaTranspose_branches183 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative183 a ha) (affine_gammaTranspose_window183 a ha world h B state)
    (affine_gammaTranspose_empty183 a ha) (affine_gammaTranspose_complete183 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches183,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches183,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node182 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known182 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known182 a) ((2 : Int),(1 : Int)) (affine_gammaTranspose_branches182 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative182 a ha) (affine_gammaTranspose_window182 a ha world h B state)
    (affine_gammaTranspose_empty182 a ha) (affine_gammaTranspose_complete182 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches182,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches182,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node181 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known181 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known181 a) ((2 : Int),(1 : Int)) (affine_gammaTranspose_branches181 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative181 a ha) (affine_gammaTranspose_window181 a ha world h B state)
    (affine_gammaTranspose_empty181 a ha) (affine_gammaTranspose_complete181 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches181,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches181,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node180 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known180 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known180 a) ((2 : Int),(1 : Int)) (affine_gammaTranspose_branches180 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative180 a ha) (affine_gammaTranspose_window180 a ha world h B state)
    (affine_gammaTranspose_empty180 a ha) (affine_gammaTranspose_complete180 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches180,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches180,List.mem_cons,List.not_mem_nil,or_false] at member
include ha in
theorem affine_gammaTranspose_node179 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known179 a)) B) : Transition world h .gammaTranspose B := by
  exact affine_gammaTranspose_leaf179 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node178 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known178 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known178 a) ((0 : Int),(3 : Int)) (affine_gammaTranspose_branches178 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative178 a ha) (affine_gammaTranspose_window178 a ha world h B state)
    (affine_gammaTranspose_empty178 a ha) (affine_gammaTranspose_complete178 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches178,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known178,affine_gammaTranspose_known179,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known178,affine_gammaTranspose_known180,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known178,affine_gammaTranspose_known181,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known178,affine_gammaTranspose_known182,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known178,affine_gammaTranspose_known183,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches178,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · exact affine_gammaTranspose_node179 a ha world h nextB nextState
    · exact affine_gammaTranspose_node180 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node181 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node182 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node183 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node177 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known177 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known177 a) ((3 : Int),(1 : Int)) (affine_gammaTranspose_branches177 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative177 a ha) (affine_gammaTranspose_window177 a ha world h B state)
    (affine_gammaTranspose_empty177 a ha) (affine_gammaTranspose_complete177 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches177,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches177,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node176 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known176 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known176 a) ((3 : Int),(1 : Int)) (affine_gammaTranspose_branches176 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative176 a ha) (affine_gammaTranspose_window176 a ha world h B state)
    (affine_gammaTranspose_empty176 a ha) (affine_gammaTranspose_complete176 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches176,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches176,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node175 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known175 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known175 a) ((2 : Int),(1 : Int)) (affine_gammaTranspose_branches175 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative175 a ha) (affine_gammaTranspose_window175 a ha world h B state)
    (affine_gammaTranspose_empty175 a ha) (affine_gammaTranspose_complete175 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches175,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known175,affine_gammaTranspose_known176,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known175,affine_gammaTranspose_known177,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches175,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node176 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node177 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node174 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known174 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known174 a) ((3 : Int),(1 : Int)) (affine_gammaTranspose_branches174 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative174 a ha) (affine_gammaTranspose_window174 a ha world h B state)
    (affine_gammaTranspose_empty174 a ha) (affine_gammaTranspose_complete174 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches174,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches174,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node173 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known173 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known173 a) ((3 : Int),(1 : Int)) (affine_gammaTranspose_branches173 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative173 a ha) (affine_gammaTranspose_window173 a ha world h B state)
    (affine_gammaTranspose_empty173 a ha) (affine_gammaTranspose_complete173 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches173,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches173,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node172 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known172 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known172 a) ((2 : Int),(1 : Int)) (affine_gammaTranspose_branches172 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative172 a ha) (affine_gammaTranspose_window172 a ha world h B state)
    (affine_gammaTranspose_empty172 a ha) (affine_gammaTranspose_complete172 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches172,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known172,affine_gammaTranspose_known173,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known172,affine_gammaTranspose_known174,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches172,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node173 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node174 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node171 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known171 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known171 a) ((0 : Int),(3 : Int)) (affine_gammaTranspose_branches171 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative171 a ha) (affine_gammaTranspose_window171 a ha world h B state)
    (affine_gammaTranspose_empty171 a ha) (affine_gammaTranspose_complete171 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches171,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known171,affine_gammaTranspose_known172,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known171,affine_gammaTranspose_known175,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches171,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node172 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node175 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node170 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known170 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known170 a) ((1 : Int),(1 : Int)) (affine_gammaTranspose_branches170 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative170 a ha) (affine_gammaTranspose_window170 a ha world h B state)
    (affine_gammaTranspose_empty170 a ha) (affine_gammaTranspose_complete170 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches170,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches170,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node169 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known169 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known169 a) ((1 : Int),(1 : Int)) (affine_gammaTranspose_branches169 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative169 a ha) (affine_gammaTranspose_window169 a ha world h B state)
    (affine_gammaTranspose_empty169 a ha) (affine_gammaTranspose_complete169 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches169,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches169,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node168 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known168 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known168 a) ((2 : Int),(1 : Int)) (affine_gammaTranspose_branches168 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative168 a ha) (affine_gammaTranspose_window168 a ha world h B state)
    (affine_gammaTranspose_empty168 a ha) (affine_gammaTranspose_complete168 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches168,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches168,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node167 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known167 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known167 a) ((2 : Int),(1 : Int)) (affine_gammaTranspose_branches167 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative167 a ha) (affine_gammaTranspose_window167 a ha world h B state)
    (affine_gammaTranspose_empty167 a ha) (affine_gammaTranspose_complete167 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches167,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches167,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node166 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known166 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known166 a) ((1 : Int),(1 : Int)) (affine_gammaTranspose_branches166 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative166 a ha) (affine_gammaTranspose_window166 a ha world h B state)
    (affine_gammaTranspose_empty166 a ha) (affine_gammaTranspose_complete166 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches166,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known166,affine_gammaTranspose_known167,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known166,affine_gammaTranspose_known168,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches166,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node167 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node168 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node165 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known165 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known165 a) ((0 : Int),(2 : Int)) (affine_gammaTranspose_branches165 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative165 a ha) (affine_gammaTranspose_window165 a ha world h B state)
    (affine_gammaTranspose_empty165 a ha) (affine_gammaTranspose_complete165 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches165,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known165,affine_gammaTranspose_known166,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known165,affine_gammaTranspose_known169,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known165,affine_gammaTranspose_known170,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known165,affine_gammaTranspose_known171,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known165,affine_gammaTranspose_known178,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known165,affine_gammaTranspose_known184,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known165,affine_gammaTranspose_known185,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known165,affine_gammaTranspose_known186,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches165,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact affine_gammaTranspose_node166 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node169 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node170 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node171 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node178 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node184 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node185 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node186 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_gammaTranspose_node164 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known164 a)) B) : Transition world h .gammaTranspose B := by
  exact affine_gammaTranspose_leaf164 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node163 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known163 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known163 a) ((1 : Int),(1 : Int)) (affine_gammaTranspose_branches163 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative163 a ha) (affine_gammaTranspose_window163 a ha world h B state)
    (affine_gammaTranspose_empty163 a ha) (affine_gammaTranspose_complete163 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches163,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches163,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node162 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known162 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known162 a) ((1 : Int),(1 : Int)) (affine_gammaTranspose_branches162 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative162 a ha) (affine_gammaTranspose_window162 a ha world h B state)
    (affine_gammaTranspose_empty162 a ha) (affine_gammaTranspose_complete162 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches162,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches162,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node161 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known161 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known161 a) ((1 : Int),(1 : Int)) (affine_gammaTranspose_branches161 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative161 a ha) (affine_gammaTranspose_window161 a ha world h B state)
    (affine_gammaTranspose_empty161 a ha) (affine_gammaTranspose_complete161 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches161,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches161,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node160 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known160 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known160 a) ((1 : Int),(4 : Int)) (affine_gammaTranspose_branches160 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative160 a ha) (affine_gammaTranspose_window160 a ha world h B state)
    (affine_gammaTranspose_empty160 a ha) (affine_gammaTranspose_complete160 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches160,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches160,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node159 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known159 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known159 a) ((1 : Int),(4 : Int)) (affine_gammaTranspose_branches159 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative159 a ha) (affine_gammaTranspose_window159 a ha world h B state)
    (affine_gammaTranspose_empty159 a ha) (affine_gammaTranspose_complete159 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches159,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches159,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node158 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known158 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known158 a) ((3 : Int),(1 : Int)) (affine_gammaTranspose_branches158 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative158 a ha) (affine_gammaTranspose_window158 a ha world h B state)
    (affine_gammaTranspose_empty158 a ha) (affine_gammaTranspose_complete158 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches158,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known158,affine_gammaTranspose_known159,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known158,affine_gammaTranspose_known160,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches158,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node159 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node160 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node157 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known157 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known157 a) ((1 : Int),(4 : Int)) (affine_gammaTranspose_branches157 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative157 a ha) (affine_gammaTranspose_window157 a ha world h B state)
    (affine_gammaTranspose_empty157 a ha) (affine_gammaTranspose_complete157 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches157,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches157,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node156 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known156 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known156 a) ((1 : Int),(4 : Int)) (affine_gammaTranspose_branches156 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative156 a ha) (affine_gammaTranspose_window156 a ha world h B state)
    (affine_gammaTranspose_empty156 a ha) (affine_gammaTranspose_complete156 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches156,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches156,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node155 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known155 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known155 a) ((3 : Int),(1 : Int)) (affine_gammaTranspose_branches155 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative155 a ha) (affine_gammaTranspose_window155 a ha world h B state)
    (affine_gammaTranspose_empty155 a ha) (affine_gammaTranspose_complete155 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches155,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known155,affine_gammaTranspose_known156,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known155,affine_gammaTranspose_known157,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches155,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node156 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node157 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node154 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known154 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known154 a) ((2 : Int),(4 : Int)) (affine_gammaTranspose_branches154 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative154 a ha) (affine_gammaTranspose_window154 a ha world h B state)
    (affine_gammaTranspose_empty154 a ha) (affine_gammaTranspose_complete154 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches154,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches154,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node153 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known153 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known153 a) ((2 : Int),(4 : Int)) (affine_gammaTranspose_branches153 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative153 a ha) (affine_gammaTranspose_window153 a ha world h B state)
    (affine_gammaTranspose_empty153 a ha) (affine_gammaTranspose_complete153 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches153,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches153,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node152 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known152 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known152 a) ((1 : Int),(4 : Int)) (affine_gammaTranspose_branches152 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative152 a ha) (affine_gammaTranspose_window152 a ha world h B state)
    (affine_gammaTranspose_empty152 a ha) (affine_gammaTranspose_complete152 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches152,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known152,affine_gammaTranspose_known153,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known152,affine_gammaTranspose_known154,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches152,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node153 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node154 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node151 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known151 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known151 a) ((2 : Int),(4 : Int)) (affine_gammaTranspose_branches151 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative151 a ha) (affine_gammaTranspose_window151 a ha world h B state)
    (affine_gammaTranspose_empty151 a ha) (affine_gammaTranspose_complete151 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches151,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches151,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node150 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known150 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known150 a) ((2 : Int),(4 : Int)) (affine_gammaTranspose_branches150 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative150 a ha) (affine_gammaTranspose_window150 a ha world h B state)
    (affine_gammaTranspose_empty150 a ha) (affine_gammaTranspose_complete150 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches150,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches150,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node149 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known149 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known149 a) ((1 : Int),(4 : Int)) (affine_gammaTranspose_branches149 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative149 a ha) (affine_gammaTranspose_window149 a ha world h B state)
    (affine_gammaTranspose_empty149 a ha) (affine_gammaTranspose_complete149 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches149,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known149,affine_gammaTranspose_known150,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known149,affine_gammaTranspose_known151,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches149,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node150 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node151 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node148 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known148 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known148 a) ((3 : Int),(1 : Int)) (affine_gammaTranspose_branches148 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative148 a ha) (affine_gammaTranspose_window148 a ha world h B state)
    (affine_gammaTranspose_empty148 a ha) (affine_gammaTranspose_complete148 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches148,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known148,affine_gammaTranspose_known149,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known148,affine_gammaTranspose_known152,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches148,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node149 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node152 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node147 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known147 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known147 a) ((0 : Int),(4 : Int)) (affine_gammaTranspose_branches147 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative147 a ha) (affine_gammaTranspose_window147 a ha world h B state)
    (affine_gammaTranspose_empty147 a ha) (affine_gammaTranspose_complete147 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches147,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known147,affine_gammaTranspose_known148,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known147,affine_gammaTranspose_known155,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known147,affine_gammaTranspose_known158,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches147,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_gammaTranspose_node148 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node155 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node158 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node146 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known146 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known146 a) ((1 : Int),(6 : Int)) (affine_gammaTranspose_branches146 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative146 a ha) (affine_gammaTranspose_window146 a ha world h B state)
    (affine_gammaTranspose_empty146 a ha) (affine_gammaTranspose_complete146 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches146,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches146,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node145 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known145 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known145 a) ((2 : Int),(4 : Int)) (affine_gammaTranspose_branches145 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative145 a ha) (affine_gammaTranspose_window145 a ha world h B state)
    (affine_gammaTranspose_empty145 a ha) (affine_gammaTranspose_complete145 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches145,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known145,affine_gammaTranspose_known146,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches145,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_gammaTranspose_node146 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node144 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known144 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known144 a) ((2 : Int),(4 : Int)) (affine_gammaTranspose_branches144 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative144 a ha) (affine_gammaTranspose_window144 a ha world h B state)
    (affine_gammaTranspose_empty144 a ha) (affine_gammaTranspose_complete144 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches144,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches144,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node143 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known143 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known143 a) ((1 : Int),(6 : Int)) (affine_gammaTranspose_branches143 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative143 a ha) (affine_gammaTranspose_window143 a ha world h B state)
    (affine_gammaTranspose_empty143 a ha) (affine_gammaTranspose_complete143 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches143,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches143,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node142 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known142 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known142 a) ((2 : Int),(4 : Int)) (affine_gammaTranspose_branches142 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative142 a ha) (affine_gammaTranspose_window142 a ha world h B state)
    (affine_gammaTranspose_empty142 a ha) (affine_gammaTranspose_complete142 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches142,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known142,affine_gammaTranspose_known143,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches142,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_gammaTranspose_node143 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node141 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known141 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known141 a) ((1 : Int),(7 : Int)) (affine_gammaTranspose_branches141 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative141 a ha) (affine_gammaTranspose_window141 a ha world h B state)
    (affine_gammaTranspose_empty141 a ha) (affine_gammaTranspose_complete141 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches141,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches141,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node140 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known140 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known140 a) ((1 : Int),(7 : Int)) (affine_gammaTranspose_branches140 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative140 a ha) (affine_gammaTranspose_window140 a ha world h B state)
    (affine_gammaTranspose_empty140 a ha) (affine_gammaTranspose_complete140 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches140,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches140,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node139 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known139 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known139 a) ((3 : Int),(4 : Int)) (affine_gammaTranspose_branches139 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative139 a ha) (affine_gammaTranspose_window139 a ha world h B state)
    (affine_gammaTranspose_empty139 a ha) (affine_gammaTranspose_complete139 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches139,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known139,affine_gammaTranspose_known140,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known139,affine_gammaTranspose_known141,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches139,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node140 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node141 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node138 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known138 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known138 a) ((1 : Int),(7 : Int)) (affine_gammaTranspose_branches138 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative138 a ha) (affine_gammaTranspose_window138 a ha world h B state)
    (affine_gammaTranspose_empty138 a ha) (affine_gammaTranspose_complete138 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches138,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches138,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node137 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known137 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known137 a) ((1 : Int),(7 : Int)) (affine_gammaTranspose_branches137 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative137 a ha) (affine_gammaTranspose_window137 a ha world h B state)
    (affine_gammaTranspose_empty137 a ha) (affine_gammaTranspose_complete137 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches137,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches137,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node136 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known136 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known136 a) ((3 : Int),(4 : Int)) (affine_gammaTranspose_branches136 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative136 a ha) (affine_gammaTranspose_window136 a ha world h B state)
    (affine_gammaTranspose_empty136 a ha) (affine_gammaTranspose_complete136 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches136,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known136,affine_gammaTranspose_known137,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known136,affine_gammaTranspose_known138,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches136,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node137 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node138 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node135 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known135 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known135 a) ((1 : Int),(6 : Int)) (affine_gammaTranspose_branches135 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative135 a ha) (affine_gammaTranspose_window135 a ha world h B state)
    (affine_gammaTranspose_empty135 a ha) (affine_gammaTranspose_complete135 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches135,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known135,affine_gammaTranspose_known136,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known135,affine_gammaTranspose_known139,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches135,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node136 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node139 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_gammaTranspose_node134 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known134 a)) B) : Transition world h .gammaTranspose B := by
  exact affine_gammaTranspose_leaf134 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node133 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known133 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known133 a) ((1 : Int),(5 : Int)) (affine_gammaTranspose_branches133 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative133 a ha) (affine_gammaTranspose_window133 a ha world h B state)
    (affine_gammaTranspose_empty133 a ha) (affine_gammaTranspose_complete133 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches133,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known133,affine_gammaTranspose_known134,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known133,affine_gammaTranspose_known135,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known133,affine_gammaTranspose_known142,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known133,affine_gammaTranspose_known144,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known133,affine_gammaTranspose_known145,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches133,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · exact affine_gammaTranspose_node134 a ha world h nextB nextState
    · exact affine_gammaTranspose_node135 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node142 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node144 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node145 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node132 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known132 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known132 a) ((1 : Int),(6 : Int)) (affine_gammaTranspose_branches132 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative132 a ha) (affine_gammaTranspose_window132 a ha world h B state)
    (affine_gammaTranspose_empty132 a ha) (affine_gammaTranspose_complete132 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches132,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches132,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node131 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known131 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known131 a) ((2 : Int),(4 : Int)) (affine_gammaTranspose_branches131 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative131 a ha) (affine_gammaTranspose_window131 a ha world h B state)
    (affine_gammaTranspose_empty131 a ha) (affine_gammaTranspose_complete131 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches131,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known131,affine_gammaTranspose_known132,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches131,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_gammaTranspose_node132 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node130 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known130 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known130 a) ((2 : Int),(4 : Int)) (affine_gammaTranspose_branches130 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative130 a ha) (affine_gammaTranspose_window130 a ha world h B state)
    (affine_gammaTranspose_empty130 a ha) (affine_gammaTranspose_complete130 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches130,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches130,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node129 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known129 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known129 a) ((1 : Int),(6 : Int)) (affine_gammaTranspose_branches129 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative129 a ha) (affine_gammaTranspose_window129 a ha world h B state)
    (affine_gammaTranspose_empty129 a ha) (affine_gammaTranspose_complete129 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches129,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches129,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node128 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known128 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known128 a) ((2 : Int),(4 : Int)) (affine_gammaTranspose_branches128 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative128 a ha) (affine_gammaTranspose_window128 a ha world h B state)
    (affine_gammaTranspose_empty128 a ha) (affine_gammaTranspose_complete128 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches128,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known128,affine_gammaTranspose_known129,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches128,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_gammaTranspose_node129 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node127 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known127 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known127 a) ((1 : Int),(7 : Int)) (affine_gammaTranspose_branches127 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative127 a ha) (affine_gammaTranspose_window127 a ha world h B state)
    (affine_gammaTranspose_empty127 a ha) (affine_gammaTranspose_complete127 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches127,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches127,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node126 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known126 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known126 a) ((1 : Int),(7 : Int)) (affine_gammaTranspose_branches126 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative126 a ha) (affine_gammaTranspose_window126 a ha world h B state)
    (affine_gammaTranspose_empty126 a ha) (affine_gammaTranspose_complete126 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches126,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches126,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node125 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known125 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known125 a) ((3 : Int),(4 : Int)) (affine_gammaTranspose_branches125 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative125 a ha) (affine_gammaTranspose_window125 a ha world h B state)
    (affine_gammaTranspose_empty125 a ha) (affine_gammaTranspose_complete125 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches125,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known125,affine_gammaTranspose_known126,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known125,affine_gammaTranspose_known127,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches125,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node126 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node127 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node124 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known124 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known124 a) ((1 : Int),(7 : Int)) (affine_gammaTranspose_branches124 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative124 a ha) (affine_gammaTranspose_window124 a ha world h B state)
    (affine_gammaTranspose_empty124 a ha) (affine_gammaTranspose_complete124 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches124,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches124,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node123 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known123 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known123 a) ((1 : Int),(7 : Int)) (affine_gammaTranspose_branches123 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative123 a ha) (affine_gammaTranspose_window123 a ha world h B state)
    (affine_gammaTranspose_empty123 a ha) (affine_gammaTranspose_complete123 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches123,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches123,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node122 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known122 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known122 a) ((3 : Int),(4 : Int)) (affine_gammaTranspose_branches122 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative122 a ha) (affine_gammaTranspose_window122 a ha world h B state)
    (affine_gammaTranspose_empty122 a ha) (affine_gammaTranspose_complete122 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches122,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known122,affine_gammaTranspose_known123,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known122,affine_gammaTranspose_known124,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches122,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node123 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node124 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node121 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known121 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known121 a) ((1 : Int),(6 : Int)) (affine_gammaTranspose_branches121 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative121 a ha) (affine_gammaTranspose_window121 a ha world h B state)
    (affine_gammaTranspose_empty121 a ha) (affine_gammaTranspose_complete121 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches121,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known121,affine_gammaTranspose_known122,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known121,affine_gammaTranspose_known125,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches121,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node122 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node125 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_gammaTranspose_node120 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known120 a)) B) : Transition world h .gammaTranspose B := by
  exact affine_gammaTranspose_leaf120 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node119 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known119 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known119 a) ((1 : Int),(5 : Int)) (affine_gammaTranspose_branches119 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative119 a ha) (affine_gammaTranspose_window119 a ha world h B state)
    (affine_gammaTranspose_empty119 a ha) (affine_gammaTranspose_complete119 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches119,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known119,affine_gammaTranspose_known120,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known119,affine_gammaTranspose_known121,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known119,affine_gammaTranspose_known128,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known119,affine_gammaTranspose_known130,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known119,affine_gammaTranspose_known131,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches119,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · exact affine_gammaTranspose_node120 a ha world h nextB nextState
    · exact affine_gammaTranspose_node121 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node128 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node130 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node131 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node118 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known118 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known118 a) ((3 : Int),(1 : Int)) (affine_gammaTranspose_branches118 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative118 a ha) (affine_gammaTranspose_window118 a ha world h B state)
    (affine_gammaTranspose_empty118 a ha) (affine_gammaTranspose_complete118 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches118,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known118,affine_gammaTranspose_known119,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known118,affine_gammaTranspose_known133,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches118,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node119 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node133 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_gammaTranspose_node117 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known117 a)) B) : Transition world h .gammaTranspose B := by
  exact affine_gammaTranspose_leaf117 a ha world h B state
include ha in
theorem affine_gammaTranspose_node116 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known116 a)) B) : Transition world h .gammaTranspose B := by
  exact affine_gammaTranspose_leaf116 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node115 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known115 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known115 a) ((0 : Int),(4 : Int)) (affine_gammaTranspose_branches115 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative115 a ha) (affine_gammaTranspose_window115 a ha world h B state)
    (affine_gammaTranspose_empty115 a ha) (affine_gammaTranspose_complete115 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches115,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known115,affine_gammaTranspose_known116,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known115,affine_gammaTranspose_known117,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known115,affine_gammaTranspose_known118,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches115,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_gammaTranspose_node116 a ha world h nextB nextState
    · exact affine_gammaTranspose_node117 a ha world h nextB nextState
    · exact affine_gammaTranspose_node118 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node114 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known114 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known114 a) ((1 : Int),(4 : Int)) (affine_gammaTranspose_branches114 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative114 a ha) (affine_gammaTranspose_window114 a ha world h B state)
    (affine_gammaTranspose_empty114 a ha) (affine_gammaTranspose_complete114 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches114,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches114,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node113 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known113 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known113 a) ((1 : Int),(4 : Int)) (affine_gammaTranspose_branches113 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative113 a ha) (affine_gammaTranspose_window113 a ha world h B state)
    (affine_gammaTranspose_empty113 a ha) (affine_gammaTranspose_complete113 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches113,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches113,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node112 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known112 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known112 a) ((3 : Int),(1 : Int)) (affine_gammaTranspose_branches112 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative112 a ha) (affine_gammaTranspose_window112 a ha world h B state)
    (affine_gammaTranspose_empty112 a ha) (affine_gammaTranspose_complete112 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches112,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known112,affine_gammaTranspose_known113,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known112,affine_gammaTranspose_known114,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches112,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node113 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node114 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node111 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known111 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known111 a) ((1 : Int),(4 : Int)) (affine_gammaTranspose_branches111 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative111 a ha) (affine_gammaTranspose_window111 a ha world h B state)
    (affine_gammaTranspose_empty111 a ha) (affine_gammaTranspose_complete111 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches111,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches111,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node110 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known110 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known110 a) ((1 : Int),(4 : Int)) (affine_gammaTranspose_branches110 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative110 a ha) (affine_gammaTranspose_window110 a ha world h B state)
    (affine_gammaTranspose_empty110 a ha) (affine_gammaTranspose_complete110 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches110,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches110,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node109 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known109 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known109 a) ((3 : Int),(1 : Int)) (affine_gammaTranspose_branches109 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative109 a ha) (affine_gammaTranspose_window109 a ha world h B state)
    (affine_gammaTranspose_empty109 a ha) (affine_gammaTranspose_complete109 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches109,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known109,affine_gammaTranspose_known110,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known109,affine_gammaTranspose_known111,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches109,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node110 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node111 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node108 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known108 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known108 a) ((1 : Int),(3 : Int)) (affine_gammaTranspose_branches108 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative108 a ha) (affine_gammaTranspose_window108 a ha world h B state)
    (affine_gammaTranspose_empty108 a ha) (affine_gammaTranspose_complete108 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches108,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known108,affine_gammaTranspose_known109,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known108,affine_gammaTranspose_known112,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches108,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node109 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node112 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node107 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known107 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known107 a) ((2 : Int),(4 : Int)) (affine_gammaTranspose_branches107 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative107 a ha) (affine_gammaTranspose_window107 a ha world h B state)
    (affine_gammaTranspose_empty107 a ha) (affine_gammaTranspose_complete107 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches107,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches107,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node106 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known106 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known106 a) ((2 : Int),(4 : Int)) (affine_gammaTranspose_branches106 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative106 a ha) (affine_gammaTranspose_window106 a ha world h B state)
    (affine_gammaTranspose_empty106 a ha) (affine_gammaTranspose_complete106 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches106,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches106,List.mem_cons,List.not_mem_nil,or_false] at member
include ha in
theorem affine_gammaTranspose_node105 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known105 a)) B) : Transition world h .gammaTranspose B := by
  exact affine_gammaTranspose_leaf105 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node104 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known104 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known104 a) ((4 : Int),(4 : Int)) (affine_gammaTranspose_branches104 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative104 a ha) (affine_gammaTranspose_window104 a ha world h B state)
    (affine_gammaTranspose_empty104 a ha) (affine_gammaTranspose_complete104 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches104,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches104,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node103 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known103 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known103 a) ((4 : Int),(4 : Int)) (affine_gammaTranspose_branches103 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative103 a ha) (affine_gammaTranspose_window103 a ha world h B state)
    (affine_gammaTranspose_empty103 a ha) (affine_gammaTranspose_complete103 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches103,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches103,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node102 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known102 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known102 a) ((3 : Int),(4 : Int)) (affine_gammaTranspose_branches102 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative102 a ha) (affine_gammaTranspose_window102 a ha world h B state)
    (affine_gammaTranspose_empty102 a ha) (affine_gammaTranspose_complete102 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches102,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known102,affine_gammaTranspose_known103,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known102,affine_gammaTranspose_known104,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches102,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node103 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node104 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node101 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known101 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known101 a) ((4 : Int),(4 : Int)) (affine_gammaTranspose_branches101 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative101 a ha) (affine_gammaTranspose_window101 a ha world h B state)
    (affine_gammaTranspose_empty101 a ha) (affine_gammaTranspose_complete101 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches101,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches101,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node100 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known100 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known100 a) ((4 : Int),(4 : Int)) (affine_gammaTranspose_branches100 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative100 a ha) (affine_gammaTranspose_window100 a ha world h B state)
    (affine_gammaTranspose_empty100 a ha) (affine_gammaTranspose_complete100 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches100,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches100,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node099 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known099 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known099 a) ((3 : Int),(4 : Int)) (affine_gammaTranspose_branches099 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative099 a ha) (affine_gammaTranspose_window099 a ha world h B state)
    (affine_gammaTranspose_empty099 a ha) (affine_gammaTranspose_complete099 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches099,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known099,affine_gammaTranspose_known100,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known099,affine_gammaTranspose_known101,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches099,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node100 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node101 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node098 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known098 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known098 a) ((1 : Int),(6 : Int)) (affine_gammaTranspose_branches098 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative098 a ha) (affine_gammaTranspose_window098 a ha world h B state)
    (affine_gammaTranspose_empty098 a ha) (affine_gammaTranspose_complete098 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches098,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known098,affine_gammaTranspose_known099,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known098,affine_gammaTranspose_known102,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches098,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node099 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node102 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node097 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known097 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known097 a) ((2 : Int),(4 : Int)) (affine_gammaTranspose_branches097 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative097 a ha) (affine_gammaTranspose_window097 a ha world h B state)
    (affine_gammaTranspose_empty097 a ha) (affine_gammaTranspose_complete097 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches097,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches097,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node096 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known096 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known096 a) ((2 : Int),(4 : Int)) (affine_gammaTranspose_branches096 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative096 a ha) (affine_gammaTranspose_window096 a ha world h B state)
    (affine_gammaTranspose_empty096 a ha) (affine_gammaTranspose_complete096 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches096,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches096,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node095 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known095 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known095 a) ((3 : Int),(4 : Int)) (affine_gammaTranspose_branches095 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative095 a ha) (affine_gammaTranspose_window095 a ha world h B state)
    (affine_gammaTranspose_empty095 a ha) (affine_gammaTranspose_complete095 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches095,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches095,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node094 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known094 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known094 a) ((3 : Int),(4 : Int)) (affine_gammaTranspose_branches094 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative094 a ha) (affine_gammaTranspose_window094 a ha world h B state)
    (affine_gammaTranspose_empty094 a ha) (affine_gammaTranspose_complete094 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches094,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches094,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node093 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known093 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known093 a) ((2 : Int),(4 : Int)) (affine_gammaTranspose_branches093 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative093 a ha) (affine_gammaTranspose_window093 a ha world h B state)
    (affine_gammaTranspose_empty093 a ha) (affine_gammaTranspose_complete093 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches093,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known093,affine_gammaTranspose_known094,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known093,affine_gammaTranspose_known095,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches093,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node094 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node095 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node092 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known092 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known092 a) ((1 : Int),(5 : Int)) (affine_gammaTranspose_branches092 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative092 a ha) (affine_gammaTranspose_window092 a ha world h B state)
    (affine_gammaTranspose_empty092 a ha) (affine_gammaTranspose_complete092 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches092,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known092,affine_gammaTranspose_known093,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known092,affine_gammaTranspose_known096,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known092,affine_gammaTranspose_known097,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known092,affine_gammaTranspose_known098,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known092,affine_gammaTranspose_known105,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known092,affine_gammaTranspose_known106,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known092,affine_gammaTranspose_known107,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches092,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact affine_gammaTranspose_node093 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node096 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node097 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node098 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node105 a ha world h nextB nextState
    · exact affine_gammaTranspose_node106 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node107 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node091 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known091 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known091 a) ((2 : Int),(4 : Int)) (affine_gammaTranspose_branches091 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative091 a ha) (affine_gammaTranspose_window091 a ha world h B state)
    (affine_gammaTranspose_empty091 a ha) (affine_gammaTranspose_complete091 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches091,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches091,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node090 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known090 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known090 a) ((2 : Int),(4 : Int)) (affine_gammaTranspose_branches090 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative090 a ha) (affine_gammaTranspose_window090 a ha world h B state)
    (affine_gammaTranspose_empty090 a ha) (affine_gammaTranspose_complete090 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches090,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches090,List.mem_cons,List.not_mem_nil,or_false] at member
include ha in
theorem affine_gammaTranspose_node089 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known089 a)) B) : Transition world h .gammaTranspose B := by
  exact affine_gammaTranspose_leaf089 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node088 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known088 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known088 a) ((4 : Int),(4 : Int)) (affine_gammaTranspose_branches088 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative088 a ha) (affine_gammaTranspose_window088 a ha world h B state)
    (affine_gammaTranspose_empty088 a ha) (affine_gammaTranspose_complete088 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches088,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches088,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node087 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known087 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known087 a) ((4 : Int),(4 : Int)) (affine_gammaTranspose_branches087 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative087 a ha) (affine_gammaTranspose_window087 a ha world h B state)
    (affine_gammaTranspose_empty087 a ha) (affine_gammaTranspose_complete087 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches087,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches087,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node086 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known086 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known086 a) ((3 : Int),(4 : Int)) (affine_gammaTranspose_branches086 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative086 a ha) (affine_gammaTranspose_window086 a ha world h B state)
    (affine_gammaTranspose_empty086 a ha) (affine_gammaTranspose_complete086 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches086,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known086,affine_gammaTranspose_known087,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known086,affine_gammaTranspose_known088,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches086,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node087 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node088 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node085 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known085 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known085 a) ((4 : Int),(4 : Int)) (affine_gammaTranspose_branches085 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative085 a ha) (affine_gammaTranspose_window085 a ha world h B state)
    (affine_gammaTranspose_empty085 a ha) (affine_gammaTranspose_complete085 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches085,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches085,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node084 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known084 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known084 a) ((4 : Int),(4 : Int)) (affine_gammaTranspose_branches084 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative084 a ha) (affine_gammaTranspose_window084 a ha world h B state)
    (affine_gammaTranspose_empty084 a ha) (affine_gammaTranspose_complete084 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches084,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches084,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node083 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known083 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known083 a) ((3 : Int),(4 : Int)) (affine_gammaTranspose_branches083 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative083 a ha) (affine_gammaTranspose_window083 a ha world h B state)
    (affine_gammaTranspose_empty083 a ha) (affine_gammaTranspose_complete083 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches083,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known083,affine_gammaTranspose_known084,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known083,affine_gammaTranspose_known085,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches083,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node084 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node085 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node082 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known082 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known082 a) ((1 : Int),(6 : Int)) (affine_gammaTranspose_branches082 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative082 a ha) (affine_gammaTranspose_window082 a ha world h B state)
    (affine_gammaTranspose_empty082 a ha) (affine_gammaTranspose_complete082 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches082,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known082,affine_gammaTranspose_known083,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known082,affine_gammaTranspose_known086,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches082,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node083 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node086 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node081 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known081 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known081 a) ((2 : Int),(4 : Int)) (affine_gammaTranspose_branches081 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative081 a ha) (affine_gammaTranspose_window081 a ha world h B state)
    (affine_gammaTranspose_empty081 a ha) (affine_gammaTranspose_complete081 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches081,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches081,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node080 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known080 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known080 a) ((2 : Int),(4 : Int)) (affine_gammaTranspose_branches080 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative080 a ha) (affine_gammaTranspose_window080 a ha world h B state)
    (affine_gammaTranspose_empty080 a ha) (affine_gammaTranspose_complete080 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches080,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches080,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node079 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known079 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known079 a) ((3 : Int),(4 : Int)) (affine_gammaTranspose_branches079 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative079 a ha) (affine_gammaTranspose_window079 a ha world h B state)
    (affine_gammaTranspose_empty079 a ha) (affine_gammaTranspose_complete079 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches079,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches079,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node078 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known078 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known078 a) ((3 : Int),(4 : Int)) (affine_gammaTranspose_branches078 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative078 a ha) (affine_gammaTranspose_window078 a ha world h B state)
    (affine_gammaTranspose_empty078 a ha) (affine_gammaTranspose_complete078 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches078,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches078,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node077 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known077 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known077 a) ((2 : Int),(4 : Int)) (affine_gammaTranspose_branches077 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative077 a ha) (affine_gammaTranspose_window077 a ha world h B state)
    (affine_gammaTranspose_empty077 a ha) (affine_gammaTranspose_complete077 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches077,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known077,affine_gammaTranspose_known078,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known077,affine_gammaTranspose_known079,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches077,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node078 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node079 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node076 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known076 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known076 a) ((1 : Int),(5 : Int)) (affine_gammaTranspose_branches076 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative076 a ha) (affine_gammaTranspose_window076 a ha world h B state)
    (affine_gammaTranspose_empty076 a ha) (affine_gammaTranspose_complete076 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches076,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known076,affine_gammaTranspose_known077,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known076,affine_gammaTranspose_known080,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known076,affine_gammaTranspose_known081,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known076,affine_gammaTranspose_known082,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known076,affine_gammaTranspose_known089,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known076,affine_gammaTranspose_known090,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known076,affine_gammaTranspose_known091,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches076,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact affine_gammaTranspose_node077 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node080 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node081 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node082 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node089 a ha world h nextB nextState
    · exact affine_gammaTranspose_node090 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node091 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node075 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known075 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known075 a) ((3 : Int),(1 : Int)) (affine_gammaTranspose_branches075 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative075 a ha) (affine_gammaTranspose_window075 a ha world h B state)
    (affine_gammaTranspose_empty075 a ha) (affine_gammaTranspose_complete075 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches075,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known075,affine_gammaTranspose_known076,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known075,affine_gammaTranspose_known092,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches075,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node076 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node092 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_gammaTranspose_node074 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known074 a)) B) : Transition world h .gammaTranspose B := by
  exact affine_gammaTranspose_leaf074 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node073 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known073 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known073 a) ((1 : Int),(3 : Int)) (affine_gammaTranspose_branches073 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative073 a ha) (affine_gammaTranspose_window073 a ha world h B state)
    (affine_gammaTranspose_empty073 a ha) (affine_gammaTranspose_complete073 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches073,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known073,affine_gammaTranspose_known074,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known073,affine_gammaTranspose_known075,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches073,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node074 a ha world h nextB nextState
    · exact affine_gammaTranspose_node075 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_gammaTranspose_node072 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known072 a)) B) : Transition world h .gammaTranspose B := by
  exact affine_gammaTranspose_leaf072 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node071 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known071 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known071 a) ((0 : Int),(3 : Int)) (affine_gammaTranspose_branches071 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative071 a ha) (affine_gammaTranspose_window071 a ha world h B state)
    (affine_gammaTranspose_empty071 a ha) (affine_gammaTranspose_complete071 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches071,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known071,affine_gammaTranspose_known072,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known071,affine_gammaTranspose_known073,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known071,affine_gammaTranspose_known108,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known071,affine_gammaTranspose_known115,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known071,affine_gammaTranspose_known147,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches071,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · exact affine_gammaTranspose_node072 a ha world h nextB nextState
    · exact affine_gammaTranspose_node073 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node108 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node115 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node147 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_gammaTranspose_node070 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known070 a)) B) : Transition world h .gammaTranspose B := by
  exact affine_gammaTranspose_leaf070 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node069 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known069 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known069 a) ((1 : Int),(1 : Int)) (affine_gammaTranspose_branches069 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative069 a ha) (affine_gammaTranspose_window069 a ha world h B state)
    (affine_gammaTranspose_empty069 a ha) (affine_gammaTranspose_complete069 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches069,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches069,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node068 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known068 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known068 a) ((1 : Int),(1 : Int)) (affine_gammaTranspose_branches068 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative068 a ha) (affine_gammaTranspose_window068 a ha world h B state)
    (affine_gammaTranspose_empty068 a ha) (affine_gammaTranspose_complete068 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches068,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches068,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node067 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known067 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known067 a) ((2 : Int),(3 : Int)) (affine_gammaTranspose_branches067 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative067 a ha) (affine_gammaTranspose_window067 a ha world h B state)
    (affine_gammaTranspose_empty067 a ha) (affine_gammaTranspose_complete067 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches067,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches067,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node066 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known066 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known066 a) ((3 : Int),(1 : Int)) (affine_gammaTranspose_branches066 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative066 a ha) (affine_gammaTranspose_window066 a ha world h B state)
    (affine_gammaTranspose_empty066 a ha) (affine_gammaTranspose_complete066 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches066,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known066,affine_gammaTranspose_known067,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches066,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_gammaTranspose_node067 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node065 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known065 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known065 a) ((3 : Int),(1 : Int)) (affine_gammaTranspose_branches065 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative065 a ha) (affine_gammaTranspose_window065 a ha world h B state)
    (affine_gammaTranspose_empty065 a ha) (affine_gammaTranspose_complete065 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches065,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches065,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node064 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known064 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known064 a) ((2 : Int),(3 : Int)) (affine_gammaTranspose_branches064 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative064 a ha) (affine_gammaTranspose_window064 a ha world h B state)
    (affine_gammaTranspose_empty064 a ha) (affine_gammaTranspose_complete064 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches064,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches064,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node063 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known063 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known063 a) ((3 : Int),(1 : Int)) (affine_gammaTranspose_branches063 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative063 a ha) (affine_gammaTranspose_window063 a ha world h B state)
    (affine_gammaTranspose_empty063 a ha) (affine_gammaTranspose_complete063 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches063,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known063,affine_gammaTranspose_known064,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches063,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_gammaTranspose_node064 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node062 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known062 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known062 a) ((2 : Int),(4 : Int)) (affine_gammaTranspose_branches062 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative062 a ha) (affine_gammaTranspose_window062 a ha world h B state)
    (affine_gammaTranspose_empty062 a ha) (affine_gammaTranspose_complete062 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches062,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches062,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node061 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known061 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known061 a) ((2 : Int),(4 : Int)) (affine_gammaTranspose_branches061 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative061 a ha) (affine_gammaTranspose_window061 a ha world h B state)
    (affine_gammaTranspose_empty061 a ha) (affine_gammaTranspose_complete061 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches061,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches061,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node060 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known060 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known060 a) ((4 : Int),(1 : Int)) (affine_gammaTranspose_branches060 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative060 a ha) (affine_gammaTranspose_window060 a ha world h B state)
    (affine_gammaTranspose_empty060 a ha) (affine_gammaTranspose_complete060 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches060,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known060,affine_gammaTranspose_known061,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known060,affine_gammaTranspose_known062,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches060,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node061 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node062 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node059 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known059 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known059 a) ((2 : Int),(4 : Int)) (affine_gammaTranspose_branches059 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative059 a ha) (affine_gammaTranspose_window059 a ha world h B state)
    (affine_gammaTranspose_empty059 a ha) (affine_gammaTranspose_complete059 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches059,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches059,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node058 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known058 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known058 a) ((2 : Int),(4 : Int)) (affine_gammaTranspose_branches058 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative058 a ha) (affine_gammaTranspose_window058 a ha world h B state)
    (affine_gammaTranspose_empty058 a ha) (affine_gammaTranspose_complete058 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches058,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches058,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node057 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known057 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known057 a) ((4 : Int),(1 : Int)) (affine_gammaTranspose_branches057 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative057 a ha) (affine_gammaTranspose_window057 a ha world h B state)
    (affine_gammaTranspose_empty057 a ha) (affine_gammaTranspose_complete057 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches057,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known057,affine_gammaTranspose_known058,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known057,affine_gammaTranspose_known059,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches057,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node058 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node059 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node056 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known056 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known056 a) ((2 : Int),(3 : Int)) (affine_gammaTranspose_branches056 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative056 a ha) (affine_gammaTranspose_window056 a ha world h B state)
    (affine_gammaTranspose_empty056 a ha) (affine_gammaTranspose_complete056 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches056,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known056,affine_gammaTranspose_known057,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known056,affine_gammaTranspose_known060,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches056,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node057 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node060 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_gammaTranspose_node055 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known055 a)) B) : Transition world h .gammaTranspose B := by
  exact affine_gammaTranspose_leaf055 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node054 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known054 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known054 a) ((2 : Int),(2 : Int)) (affine_gammaTranspose_branches054 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative054 a ha) (affine_gammaTranspose_window054 a ha world h B state)
    (affine_gammaTranspose_empty054 a ha) (affine_gammaTranspose_complete054 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches054,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known054,affine_gammaTranspose_known055,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known054,affine_gammaTranspose_known056,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known054,affine_gammaTranspose_known063,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known054,affine_gammaTranspose_known065,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known054,affine_gammaTranspose_known066,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches054,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · exact affine_gammaTranspose_node055 a ha world h nextB nextState
    · exact affine_gammaTranspose_node056 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node063 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node065 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node066 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_gammaTranspose_node053 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known053 a)) B) : Transition world h .gammaTranspose B := by
  exact affine_gammaTranspose_leaf053 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node052 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known052 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known052 a) ((1 : Int),(1 : Int)) (affine_gammaTranspose_branches052 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative052 a ha) (affine_gammaTranspose_window052 a ha world h B state)
    (affine_gammaTranspose_empty052 a ha) (affine_gammaTranspose_complete052 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches052,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known052,affine_gammaTranspose_known053,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known052,affine_gammaTranspose_known054,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches052,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node053 a ha world h nextB nextState
    · exact affine_gammaTranspose_node054 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node051 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known051 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known051 a) ((0 : Int),(2 : Int)) (affine_gammaTranspose_branches051 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative051 a ha) (affine_gammaTranspose_window051 a ha world h B state)
    (affine_gammaTranspose_empty051 a ha) (affine_gammaTranspose_complete051 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches051,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known051,affine_gammaTranspose_known052,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known051,affine_gammaTranspose_known068,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known051,affine_gammaTranspose_known069,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known051,affine_gammaTranspose_known070,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known051,affine_gammaTranspose_known071,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known051,affine_gammaTranspose_known161,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known051,affine_gammaTranspose_known162,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known051,affine_gammaTranspose_known163,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches051,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact affine_gammaTranspose_node052 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node068 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node069 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node070 a ha world h nextB nextState
    · exact affine_gammaTranspose_node071 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node161 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node162 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node163 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node050 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known050 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known050 a) ((2 : Int),(1 : Int)) (affine_gammaTranspose_branches050 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative050 a ha) (affine_gammaTranspose_window050 a ha world h B state)
    (affine_gammaTranspose_empty050 a ha) (affine_gammaTranspose_complete050 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches050,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches050,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node049 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known049 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known049 a) ((2 : Int),(2 : Int)) (affine_gammaTranspose_branches049 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative049 a ha) (affine_gammaTranspose_window049 a ha world h B state)
    (affine_gammaTranspose_empty049 a ha) (affine_gammaTranspose_complete049 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches049,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches049,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node048 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known048 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known048 a) ((2 : Int),(2 : Int)) (affine_gammaTranspose_branches048 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative048 a ha) (affine_gammaTranspose_window048 a ha world h B state)
    (affine_gammaTranspose_empty048 a ha) (affine_gammaTranspose_complete048 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches048,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches048,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node047 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known047 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known047 a) ((2 : Int),(1 : Int)) (affine_gammaTranspose_branches047 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative047 a ha) (affine_gammaTranspose_window047 a ha world h B state)
    (affine_gammaTranspose_empty047 a ha) (affine_gammaTranspose_complete047 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches047,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known047,affine_gammaTranspose_known048,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known047,affine_gammaTranspose_known049,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches047,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node048 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node049 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node046 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known046 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known046 a) ((2 : Int),(1 : Int)) (affine_gammaTranspose_branches046 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative046 a ha) (affine_gammaTranspose_window046 a ha world h B state)
    (affine_gammaTranspose_empty046 a ha) (affine_gammaTranspose_complete046 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches046,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches046,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node045 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known045 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known045 a) ((2 : Int),(0 : Int)) (affine_gammaTranspose_branches045 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative045 a ha) (affine_gammaTranspose_window045 a ha world h B state)
    (affine_gammaTranspose_empty045 a ha) (affine_gammaTranspose_complete045 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches045,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known045,affine_gammaTranspose_known046,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known045,affine_gammaTranspose_known047,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known045,affine_gammaTranspose_known050,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches045,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_gammaTranspose_node046 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node047 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node050 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node044 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known044 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known044 a) ((2 : Int),(1 : Int)) (affine_gammaTranspose_branches044 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative044 a ha) (affine_gammaTranspose_window044 a ha world h B state)
    (affine_gammaTranspose_empty044 a ha) (affine_gammaTranspose_complete044 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches044,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches044,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node043 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known043 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known043 a) ((2 : Int),(2 : Int)) (affine_gammaTranspose_branches043 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative043 a ha) (affine_gammaTranspose_window043 a ha world h B state)
    (affine_gammaTranspose_empty043 a ha) (affine_gammaTranspose_complete043 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches043,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches043,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node042 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known042 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known042 a) ((2 : Int),(2 : Int)) (affine_gammaTranspose_branches042 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative042 a ha) (affine_gammaTranspose_window042 a ha world h B state)
    (affine_gammaTranspose_empty042 a ha) (affine_gammaTranspose_complete042 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches042,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches042,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node041 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known041 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known041 a) ((2 : Int),(1 : Int)) (affine_gammaTranspose_branches041 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative041 a ha) (affine_gammaTranspose_window041 a ha world h B state)
    (affine_gammaTranspose_empty041 a ha) (affine_gammaTranspose_complete041 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches041,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known041,affine_gammaTranspose_known042,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known041,affine_gammaTranspose_known043,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches041,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node042 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node043 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node040 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known040 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known040 a) ((2 : Int),(1 : Int)) (affine_gammaTranspose_branches040 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative040 a ha) (affine_gammaTranspose_window040 a ha world h B state)
    (affine_gammaTranspose_empty040 a ha) (affine_gammaTranspose_complete040 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches040,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches040,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node039 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known039 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known039 a) ((2 : Int),(0 : Int)) (affine_gammaTranspose_branches039 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative039 a ha) (affine_gammaTranspose_window039 a ha world h B state)
    (affine_gammaTranspose_empty039 a ha) (affine_gammaTranspose_complete039 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches039,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known039,affine_gammaTranspose_known040,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known039,affine_gammaTranspose_known041,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known039,affine_gammaTranspose_known044,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches039,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_gammaTranspose_node040 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node041 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node044 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node038 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known038 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known038 a) ((0 : Int),(2 : Int)) (affine_gammaTranspose_branches038 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative038 a ha) (affine_gammaTranspose_window038 a ha world h B state)
    (affine_gammaTranspose_empty038 a ha) (affine_gammaTranspose_complete038 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches038,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known038,affine_gammaTranspose_known039,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known038,affine_gammaTranspose_known045,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches038,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node039 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node045 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node037 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known037 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known037 a) ((3 : Int),(1 : Int)) (affine_gammaTranspose_branches037 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative037 a ha) (affine_gammaTranspose_window037 a ha world h B state)
    (affine_gammaTranspose_empty037 a ha) (affine_gammaTranspose_complete037 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches037,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches037,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node036 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known036 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known036 a) ((3 : Int),(1 : Int)) (affine_gammaTranspose_branches036 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative036 a ha) (affine_gammaTranspose_window036 a ha world h B state)
    (affine_gammaTranspose_empty036 a ha) (affine_gammaTranspose_complete036 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches036,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches036,List.mem_cons,List.not_mem_nil,or_false] at member
include ha in
theorem affine_gammaTranspose_node035 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known035 a)) B) : Transition world h .gammaTranspose B := by
  exact affine_gammaTranspose_leaf035 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node034 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known034 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known034 a) ((5 : Int),(1 : Int)) (affine_gammaTranspose_branches034 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative034 a ha) (affine_gammaTranspose_window034 a ha world h B state)
    (affine_gammaTranspose_empty034 a ha) (affine_gammaTranspose_complete034 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches034,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches034,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node033 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known033 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known033 a) ((5 : Int),(1 : Int)) (affine_gammaTranspose_branches033 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative033 a ha) (affine_gammaTranspose_window033 a ha world h B state)
    (affine_gammaTranspose_empty033 a ha) (affine_gammaTranspose_complete033 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches033,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches033,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node032 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known032 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known032 a) ((4 : Int),(1 : Int)) (affine_gammaTranspose_branches032 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative032 a ha) (affine_gammaTranspose_window032 a ha world h B state)
    (affine_gammaTranspose_empty032 a ha) (affine_gammaTranspose_complete032 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches032,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known032,affine_gammaTranspose_known033,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known032,affine_gammaTranspose_known034,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches032,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node033 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node034 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node031 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known031 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known031 a) ((5 : Int),(1 : Int)) (affine_gammaTranspose_branches031 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative031 a ha) (affine_gammaTranspose_window031 a ha world h B state)
    (affine_gammaTranspose_empty031 a ha) (affine_gammaTranspose_complete031 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches031,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches031,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node030 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known030 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known030 a) ((5 : Int),(1 : Int)) (affine_gammaTranspose_branches030 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative030 a ha) (affine_gammaTranspose_window030 a ha world h B state)
    (affine_gammaTranspose_empty030 a ha) (affine_gammaTranspose_complete030 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches030,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches030,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node029 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known029 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known029 a) ((4 : Int),(1 : Int)) (affine_gammaTranspose_branches029 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative029 a ha) (affine_gammaTranspose_window029 a ha world h B state)
    (affine_gammaTranspose_empty029 a ha) (affine_gammaTranspose_complete029 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches029,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known029,affine_gammaTranspose_known030,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known029,affine_gammaTranspose_known031,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches029,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node030 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node031 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node028 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known028 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known028 a) ((2 : Int),(3 : Int)) (affine_gammaTranspose_branches028 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative028 a ha) (affine_gammaTranspose_window028 a ha world h B state)
    (affine_gammaTranspose_empty028 a ha) (affine_gammaTranspose_complete028 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches028,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known028,affine_gammaTranspose_known029,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known028,affine_gammaTranspose_known032,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches028,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node029 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node032 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node027 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known027 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known027 a) ((3 : Int),(1 : Int)) (affine_gammaTranspose_branches027 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative027 a ha) (affine_gammaTranspose_window027 a ha world h B state)
    (affine_gammaTranspose_empty027 a ha) (affine_gammaTranspose_complete027 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches027,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches027,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node026 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known026 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known026 a) ((3 : Int),(1 : Int)) (affine_gammaTranspose_branches026 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative026 a ha) (affine_gammaTranspose_window026 a ha world h B state)
    (affine_gammaTranspose_empty026 a ha) (affine_gammaTranspose_complete026 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches026,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches026,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node025 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known025 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known025 a) ((2 : Int),(2 : Int)) (affine_gammaTranspose_branches025 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative025 a ha) (affine_gammaTranspose_window025 a ha world h B state)
    (affine_gammaTranspose_empty025 a ha) (affine_gammaTranspose_complete025 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches025,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known025,affine_gammaTranspose_known026,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known025,affine_gammaTranspose_known027,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known025,affine_gammaTranspose_known028,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known025,affine_gammaTranspose_known035,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known025,affine_gammaTranspose_known036,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known025,affine_gammaTranspose_known037,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches025,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl
    · exact affine_gammaTranspose_node026 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node027 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node028 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node035 a ha world h nextB nextState
    · exact affine_gammaTranspose_node036 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node037 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_gammaTranspose_node024 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known024 a)) B) : Transition world h .gammaTranspose B := by
  exact affine_gammaTranspose_leaf024 a ha world h B state
include ha in
theorem affine_gammaTranspose_node023 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known023 a)) B) : Transition world h .gammaTranspose B := by
  exact affine_gammaTranspose_leaf023 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node022 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known022 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known022 a) ((2 : Int),(0 : Int)) (affine_gammaTranspose_branches022 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative022 a ha) (affine_gammaTranspose_window022 a ha world h B state)
    (affine_gammaTranspose_empty022 a ha) (affine_gammaTranspose_complete022 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches022,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known022,affine_gammaTranspose_known023,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known022,affine_gammaTranspose_known024,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known022,affine_gammaTranspose_known025,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches022,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_gammaTranspose_node023 a ha world h nextB nextState
    · exact affine_gammaTranspose_node024 a ha world h nextB nextState
    · exact affine_gammaTranspose_node025 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node021 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known021 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known021 a) ((3 : Int),(1 : Int)) (affine_gammaTranspose_branches021 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative021 a ha) (affine_gammaTranspose_window021 a ha world h B state)
    (affine_gammaTranspose_empty021 a ha) (affine_gammaTranspose_complete021 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches021,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches021,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node020 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known020 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known020 a) ((3 : Int),(1 : Int)) (affine_gammaTranspose_branches020 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative020 a ha) (affine_gammaTranspose_window020 a ha world h B state)
    (affine_gammaTranspose_empty020 a ha) (affine_gammaTranspose_complete020 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches020,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches020,List.mem_cons,List.not_mem_nil,or_false] at member
include ha in
theorem affine_gammaTranspose_node019 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known019 a)) B) : Transition world h .gammaTranspose B := by
  exact affine_gammaTranspose_leaf019 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node018 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known018 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known018 a) ((5 : Int),(1 : Int)) (affine_gammaTranspose_branches018 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative018 a ha) (affine_gammaTranspose_window018 a ha world h B state)
    (affine_gammaTranspose_empty018 a ha) (affine_gammaTranspose_complete018 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches018,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches018,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node017 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known017 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known017 a) ((5 : Int),(1 : Int)) (affine_gammaTranspose_branches017 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative017 a ha) (affine_gammaTranspose_window017 a ha world h B state)
    (affine_gammaTranspose_empty017 a ha) (affine_gammaTranspose_complete017 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches017,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches017,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node016 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known016 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known016 a) ((4 : Int),(1 : Int)) (affine_gammaTranspose_branches016 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative016 a ha) (affine_gammaTranspose_window016 a ha world h B state)
    (affine_gammaTranspose_empty016 a ha) (affine_gammaTranspose_complete016 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches016,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known016,affine_gammaTranspose_known017,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known016,affine_gammaTranspose_known018,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches016,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node017 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node018 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node015 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known015 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known015 a) ((5 : Int),(1 : Int)) (affine_gammaTranspose_branches015 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative015 a ha) (affine_gammaTranspose_window015 a ha world h B state)
    (affine_gammaTranspose_empty015 a ha) (affine_gammaTranspose_complete015 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches015,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches015,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node014 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known014 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known014 a) ((5 : Int),(1 : Int)) (affine_gammaTranspose_branches014 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative014 a ha) (affine_gammaTranspose_window014 a ha world h B state)
    (affine_gammaTranspose_empty014 a ha) (affine_gammaTranspose_complete014 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches014,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches014,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node013 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known013 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known013 a) ((4 : Int),(1 : Int)) (affine_gammaTranspose_branches013 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative013 a ha) (affine_gammaTranspose_window013 a ha world h B state)
    (affine_gammaTranspose_empty013 a ha) (affine_gammaTranspose_complete013 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches013,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known013,affine_gammaTranspose_known014,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known013,affine_gammaTranspose_known015,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches013,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node014 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node015 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node012 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known012 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known012 a) ((2 : Int),(3 : Int)) (affine_gammaTranspose_branches012 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative012 a ha) (affine_gammaTranspose_window012 a ha world h B state)
    (affine_gammaTranspose_empty012 a ha) (affine_gammaTranspose_complete012 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches012,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known012,affine_gammaTranspose_known013,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known012,affine_gammaTranspose_known016,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches012,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node013 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node016 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node011 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known011 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known011 a) ((3 : Int),(1 : Int)) (affine_gammaTranspose_branches011 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative011 a ha) (affine_gammaTranspose_window011 a ha world h B state)
    (affine_gammaTranspose_empty011 a ha) (affine_gammaTranspose_complete011 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches011,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches011,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node010 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known010 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known010 a) ((3 : Int),(1 : Int)) (affine_gammaTranspose_branches010 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative010 a ha) (affine_gammaTranspose_window010 a ha world h B state)
    (affine_gammaTranspose_empty010 a ha) (affine_gammaTranspose_complete010 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches010,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches010,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node009 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known009 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known009 a) ((4 : Int),(1 : Int)) (affine_gammaTranspose_branches009 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative009 a ha) (affine_gammaTranspose_window009 a ha world h B state)
    (affine_gammaTranspose_empty009 a ha) (affine_gammaTranspose_complete009 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches009,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches009,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node008 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known008 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known008 a) ((4 : Int),(1 : Int)) (affine_gammaTranspose_branches008 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative008 a ha) (affine_gammaTranspose_window008 a ha world h B state)
    (affine_gammaTranspose_empty008 a ha) (affine_gammaTranspose_complete008 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches008,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches008,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node007 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known007 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known007 a) ((3 : Int),(1 : Int)) (affine_gammaTranspose_branches007 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative007 a ha) (affine_gammaTranspose_window007 a ha world h B state)
    (affine_gammaTranspose_empty007 a ha) (affine_gammaTranspose_complete007 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches007,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known007,affine_gammaTranspose_known008,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known007,affine_gammaTranspose_known009,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches007,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node008 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node009 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node006 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known006 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known006 a) ((2 : Int),(2 : Int)) (affine_gammaTranspose_branches006 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative006 a ha) (affine_gammaTranspose_window006 a ha world h B state)
    (affine_gammaTranspose_empty006 a ha) (affine_gammaTranspose_complete006 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches006,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known006,affine_gammaTranspose_known007,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known006,affine_gammaTranspose_known010,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known006,affine_gammaTranspose_known011,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known006,affine_gammaTranspose_known012,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known006,affine_gammaTranspose_known019,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known006,affine_gammaTranspose_known020,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known006,affine_gammaTranspose_known021,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches006,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact affine_gammaTranspose_node007 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node010 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node011 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node012 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node019 a ha world h nextB nextState
    · exact affine_gammaTranspose_node020 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node021 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_gammaTranspose_node005 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known005 a)) B) : Transition world h .gammaTranspose B := by
  exact affine_gammaTranspose_leaf005 a ha world h B state
include ha in
theorem affine_gammaTranspose_node004 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known004 a)) B) : Transition world h .gammaTranspose B := by
  exact affine_gammaTranspose_leaf004 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node003 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known003 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known003 a) ((2 : Int),(0 : Int)) (affine_gammaTranspose_branches003 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative003 a ha) (affine_gammaTranspose_window003 a ha world h B state)
    (affine_gammaTranspose_empty003 a ha) (affine_gammaTranspose_complete003 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches003,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known003,affine_gammaTranspose_known004,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known003,affine_gammaTranspose_known005,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known003,affine_gammaTranspose_known006,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches003,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_gammaTranspose_node004 a ha world h nextB nextState
    · exact affine_gammaTranspose_node005 a ha world h nextB nextState
    · exact affine_gammaTranspose_node006 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node002 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known002 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known002 a) ((0 : Int),(2 : Int)) (affine_gammaTranspose_branches002 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative002 a ha) (affine_gammaTranspose_window002 a ha world h B state)
    (affine_gammaTranspose_empty002 a ha) (affine_gammaTranspose_complete002 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches002,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known002,affine_gammaTranspose_known003,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known002,affine_gammaTranspose_known022,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches002,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gammaTranspose_node003 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node022 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node001 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known001 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known001 a) ((0 : Int),(2 : Int)) (affine_gammaTranspose_branches001 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative001 a ha) (affine_gammaTranspose_window001 a ha world h B state)
    (affine_gammaTranspose_empty001 a ha) (affine_gammaTranspose_complete001 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches001,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches001,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gammaTranspose_node000 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gammaTranspose_known000 a)) B) : Transition world h .gammaTranspose B := by
  apply replay_affine_step a (by omega) world h .gammaTranspose (affine_gammaTranspose_known000 a) ((1 : Int),(0 : Int)) (affine_gammaTranspose_branches000 a) copies separate cover ceiling
    (affine_gammaTranspose_nonnegative000 a ha) (affine_gammaTranspose_window000 a ha world h B state)
    (affine_gammaTranspose_empty000 a ha) (affine_gammaTranspose_complete000 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gammaTranspose_branches000,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known000,affine_gammaTranspose_known001,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known000,affine_gammaTranspose_known002,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known000,affine_gammaTranspose_known038,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known000,affine_gammaTranspose_known051,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known000,affine_gammaTranspose_known164,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gammaTranspose_known000,affine_gammaTranspose_known165,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gammaTranspose_branches000,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl
    · exact affine_gammaTranspose_node001 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node002 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node038 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node051 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gammaTranspose_node164 a ha world h nextB nextState
    · exact affine_gammaTranspose_node165 a ha world h copies separate cover ceiling nextB nextState
end AffineGammaTranspose

theorem affine_gammaTranspose_seed_eq (a : Int) : SameCells (seed .gammaTranspose) (knownCells (affine_gammaTranspose_known000 a)) := by
  change SameCells (seed .gammaTranspose) (knownCells (affine_gammaTranspose_known000 (0 : Int)))
  decide

theorem affine_gammaTranspose_local (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (copies : ∀ t, world t → Copy a 1 1 0 t)
    (separate : DisjointWorld world) (cover : CoversWindow world h)
    (ceiling : SelectedBelow world h) (closed : TileClosed world B)
    (bounded : Below h B) (clean : Clean .gammaTranspose 0 0 B) : Transition world h .gammaTranspose B := by
  exact affine_gammaTranspose_node000 a ha world h copies separate cover ceiling B
    (state_congr (affine_gammaTranspose_seed_eq a) (seed_state world h .gammaTranspose B closed bounded clean))
#print axioms affine_gammaTranspose_local

end CornerCertificate

import LQuadrantHpBoundaryallUnequalShortbarTipRightPrunedArithmetic
import TilingCore
import TPlaneGeometry
import TilingSymmetry
import LHalfPlaneBoundaryTips
import LHalfPlaneBoundaryPairPruning
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PolyominoFormal.LRegion
open CrossUnits
def HP_boundaryall_unequal_shortbar_tip_right_pruned_M (a b : Int) : Int := 2*(a+b+1)
def HP_boundaryall_unequal_shortbar_tip_right_pruned_Box (a b x y : Int) : Prop := -HP_boundaryall_unequal_shortbar_tip_right_pruned_M a b ≤ x ∧ 0≤y ∧ x≤HP_boundaryall_unequal_shortbar_tip_right_pruned_M a b ∧ y≤HP_boundaryall_unequal_shortbar_tip_right_pruned_M a b
def HP_boundaryall_unequal_shortbar_tip_right_pruned_Inside (t : Cross) : Prop := 0≤t.y-t.south

theorem HP_boundaryall_unequal_shortbar_tip_right_pruned_node001 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_shortbar_tip_right_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_shortbar_tip_right_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ht2 : world (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht1
  have in2 := inside (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht1
  have allowed2 := avoid (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht2
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have support : HP_boundaryall_unequal_shortbar_tip_right_pruned_Box a b (2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_tip_right_pruned_n001_point a b ((by simpa only [HP_boundaryall_unequal_shortbar_tip_right_pruned_Box,HP_boundaryall_unequal_shortbar_tip_right_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) (2 : Int) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_tip_right_pruned_n001_empty a b ((by simpa only [Contains] using occupied)) (hb) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_tip_right_pruned_n001_o0 a b jx jy (sep1).2.2.1 (hlong) (hb) (hit) (sep1).2.1 (sep0).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_tip_right_pruned_n001_o1 a b jx jy (hstrict) (hb) (hit) (insideT) (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_tip_right_pruned_n001_o2 a b jx jy (hlong) (hit) (allowed) (hb) (sep1).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_tip_right_pruned_n001_o3 a b jx jy (hstrict) (hit) (hb) (sep1).2.2.1 (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_tip_right_pruned_n001_o4 a b jx jy (insideT) (sep1).2.1 (hb) (sep1).2.2.1 (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_tip_right_pruned_n001_o5 a b jx jy (hit) (hlong) (sep2).2.2.2 (hb) (sep2).2.2.1 (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_tip_right_pruned_n001_o6 a b jx jy (insideT) (hit) (sep1).2.2.1 (sep1).2.1 (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_tip_right_pruned_n001_o7 a b jx jy (hit) (hlong) (insideT) (hb) (allowed) (sep1).2.2.1

theorem HP_boundaryall_unequal_shortbar_tip_right_pruned_node000 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_shortbar_tip_right_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_shortbar_tip_right_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht1
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht1
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht1
  have support : HP_boundaryall_unequal_shortbar_tip_right_pruned_Box a b (2 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_tip_right_pruned_n000_point a b (hb) ((by simpa only [HP_boundaryall_unequal_shortbar_tip_right_pruned_Box,HP_boundaryall_unequal_shortbar_tip_right_pruned_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (2 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) (2 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_tip_right_pruned_n000_empty a b ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht ht1
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_tip_right_pruned_n000_o0 a b jx jy (sep0).2.2.1 (hb) (hlong) (hit) (sep0).2.1 (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_tip_right_pruned_n000_o1 a b jx jy (insideT) (sep1).2.2.1 (hit) (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_tip_right_pruned_n000_o2 a b jx jy (hit) (hb) (insideT) (hlong) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_tip_right_pruned_n000_o3 a b jx jy (hstrict) (insideT) (hit) (sep1).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_tip_right_pruned_n000_o4 a b jx jy (hlong) (hit) (sep1).2.2.1 (sep1).2.1 (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_tip_right_pruned_n000_o5 a b jx jy (hit) ((by simpa only [Same,eq_comm] using absent)) (sep0).2.1 (hlong) (insideT) (hb) (sep1).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_boundaryall_unequal_shortbar_tip_right_pruned_node001 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_tip_right_pruned_n000_o6 a b jx jy (sep0).2.1 (sep1).2.2.1 (hstrict) (insideT) (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_shortbar_tip_right_pruned_n000_o7 a b jx jy (hlong) (allowed) (hit) (hb) (insideT) (sep1).2.2.1

theorem HP_boundaryall_unequal_shortbar_tip_right_pruned_bounded_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_shortbar_tip_right_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_shortbar_tip_right_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (disjoint : ∀ t u x y, world t → world u → Contains t x y → Contains u x y → t=u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (anchor0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (anchor1 : world (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have sep : ∀ t u, world t → world u → t=u ∨ Apart t u := by
    intro t u ht hu
    by_cases eq : t=u
    · exact Or.inl eq
    · right
      apply TPlane.apart_of_no_common_nonnegative t u
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies t ht)
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies u hu)
      · intro x y hx hy; exact eq (disjoint t u x y ht hu hx hy)
  have rootap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases sep (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) anchor0 anchor1 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  exact HP_boundaryall_unequal_shortbar_tip_right_pruned_node000 a b ha hb hstrict hlong world copies inside cover sep avoid avoidPair anchor0 anchor1 rootap0_1

theorem HP_boundaryall_unequal_shortbar_tip_right_pruned_anchored_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor0 : T.world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (anchor1 : T.world (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  have avoid : ∀ t, T.world t → ¬ForbiddenBoundaryTip a b t := by
    exact unequal_avoid_boundary_tips a b (by omega) (by omega) (by omega) T
  have avoidPair := avoid_boundary_pairs a b (by omega) (by omega) (by omega) T
  apply HP_boundaryall_unequal_shortbar_tip_right_pruned_bounded_obstruction a b ha hb hstrict hlong T.world T.copies ?_ ?_ T.disjoint avoid avoidPair anchor0 anchor1
  · intro t ht
    have nn := TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (T.copies t ht)
    exact T.inside t ht t.x (t.y-t.south) (by
      unfold Contains; unfold TPlane.Nonnegative at nn; right; omega)
  · intro x y h; exact T.cover x y h.2.1
theorem HP_boundaryall_unequal_shortbar_tip_right_pruned_no_shifted_anchor (a b p : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor0 : T.world (shift p 0 (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int))))
    (anchor1 : T.world (shift p 0 (Cross.mk (1 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b)))
    : False := by
  let U : Tiling a b 0 0 HalfPlane :=
    (T.translate (-p) 0).congr (by intro x y; simp only [HalfPlane,Int.sub_zero])
  apply HP_boundaryall_unequal_shortbar_tip_right_pruned_anchored_obstruction a b ha hb hstrict hlong U
  · refine ⟨_,anchor0,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
  · refine ⟨_,anchor1,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
#print axioms HP_boundaryall_unequal_shortbar_tip_right_pruned_no_shifted_anchor
#print axioms HP_boundaryall_unequal_shortbar_tip_right_pruned_bounded_obstruction
end PolyominoFormal.LRegion

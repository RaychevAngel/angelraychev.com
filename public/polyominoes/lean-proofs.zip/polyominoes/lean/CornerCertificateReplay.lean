import CornerCertificateCore

namespace CornerCertificate
open CrossUnits

deriving instance DecidableEq for CrossUnits.Cross

abbrev Cell := Int × Int

instance (t : Cross) (x y : Int) : Decidable (Contains t x y) :=
  inferInstanceAs (Decidable
    ((t.x-t.west ≤ x ∧ x ≤ t.x+t.east ∧ t.y ≤ y ∧ y ≤ t.y) ∨
     (t.x ≤ x ∧ x ≤ t.x ∧ t.y-t.south ≤ y ∧ y ≤ t.y+t.north)))

def Nonnegative (t : Cross) : Prop :=
  0 ≤ t.east ∧ 0 ≤ t.north ∧ 0 ≤ t.west ∧ 0 ≤ t.south

def cells (t : Cross) : List Cell :=
  (List.range (t.west+t.east+1).toNat).map (fun (i : Nat) => (t.x-t.west+(i : Int),t.y)) ++
  (List.range (t.south+t.north+1).toNat).map (fun (i : Nat) => (t.x,t.y-t.south+(i : Int)))

theorem mem_cells_iff {t : Cross} (nn : Nonnegative t) (x y : Int) :
    (x,y) ∈ cells t ↔ Contains t x y := by
  rcases nn with ⟨he,hn,hw,hs⟩
  simp only [cells, List.mem_append, List.mem_map, List.mem_range]
  constructor
  · rintro (⟨i,hi,eq⟩ | ⟨i,hi,eq⟩)
    · have hh := congrArg Prod.fst eq
      have hv := congrArg Prod.snd eq
      simp only [Prod.fst, Prod.snd] at hh hv
      left
      exact ⟨by omega,by omega,by omega,by omega⟩
    · have hh := congrArg Prod.fst eq
      have hv := congrArg Prod.snd eq
      simp only [Prod.fst, Prod.snd] at hh hv
      right
      exact ⟨by omega,by omega,by omega,by omega⟩
  · intro hit
    rcases hit with ⟨hx1,hx2,hy1,hy2⟩ | ⟨hx1,hx2,hy1,hy2⟩
    · left
      refine ⟨(x-(t.x-t.west)).toNat, by omega, ?_⟩
      apply Prod.ext <;> dsimp <;> omega
    · right
      refine ⟨(y-(t.y-t.south)).toNat, by omega, ?_⟩
      apply Prod.ext <;> dsimp <;> omega

def translate (t : Cross) (dx dy : Int) : Cross :=
  ⟨t.x+dx,t.y+dy,t.east,t.north,t.west,t.south⟩

def templates (a : Int) : List Cross :=
  [⟨0,0,a,1,1,0⟩,⟨0,0,1,1,0,a⟩,⟨0,0,1,0,a,1⟩,⟨0,0,0,a,1,1⟩,
   ⟨0,0,0,1,1,a⟩,⟨0,0,1,1,a,0⟩,⟨0,0,1,a,0,1⟩,⟨0,0,a,0,1,1⟩]

def candidates (a : Int) (p : Cell) : List Cross :=
  (templates a).flatMap fun s =>
    (cells s).map fun q => translate s (p.1-q.1) (p.2-q.2)

theorem template_properties {a : Int} (ha : 0 ≤ a) {s : Cross}
    (mem : s ∈ templates a) :
    s.x=0 ∧ s.y=0 ∧ Nonnegative s := by
  simp only [templates, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]
  all_goals omega

theorem template_of_copy {a : Int} {t : Cross} (copy : Copy a 1 1 0 t) :
    ∃ s, s ∈ templates a ∧ t = translate s t.x t.y := by
  rcases t with ⟨x,y,e,n,w,s⟩
  rcases copy with h | h | h | h | h | h | h | h
  all_goals rcases h with ⟨he,hn,hw,hs⟩
  all_goals dsimp only at he hn hw hs
  all_goals subst e; subst n; subst w; subst s
  all_goals simp [templates, translate]

theorem candidate_complete {a : Int} (ha : 0 ≤ a) {t : Cross} {p : Cell}
    (copy : Copy a 1 1 0 t) (hit : Contains t p.1 p.2) :
    t ∈ candidates a p := by
  obtain ⟨s,mem,eq⟩ := template_of_copy copy
  obtain ⟨sx,sy,nn⟩ := template_properties ha mem
  have localHit : Contains s (p.1-t.x) (p.2-t.y) := by
    rw [eq] at hit
    dsimp [translate, Contains] at hit ⊢
    omega
  have cellMem := (mem_cells_iff nn (p.1-t.x) (p.2-t.y)).2 localHit
  simp only [candidates, List.mem_flatMap, List.mem_map]
  refine ⟨s,mem,(p.1-t.x,p.2-t.y),cellMem,?_⟩
  have coords : translate s (p.1-(p.1-t.x)) (p.2-(p.2-t.y)) = translate s t.x t.y := by
    congr 1 <;> omega
  exact coords.trans eq.symm

theorem copy_nonnegative {a : Int} (ha : 0 ≤ a) {t : Cross}
    (copy : Copy a 1 1 0 t) : Nonnegative t := by
  rcases copy with h | h | h | h | h | h | h | h
  all_goals rcases h with ⟨he,hn,hw,hs⟩
  all_goals unfold Nonnegative
  all_goals omega

def SameCells (xs ys : List Cell) : Prop :=
  (∀ p, p ∈ xs → p ∈ ys) ∧ (∀ p, p ∈ ys → p ∈ xs)

instance (xs ys : List Cell) : Decidable (SameCells xs ys) := by
  unfold SameCells
  infer_instance

theorem sameCells_iff {xs ys : List Cell} (eq : SameCells xs ys) (p : Cell) :
    p ∈ xs ↔ p ∈ ys := ⟨eq.1 p,eq.2 p⟩

def State (world : Cross → Prop) (h : Int) (occ : List Cell)
    (B : Int → Int → Prop) : Prop :=
  TileClosed world B ∧ Below h B ∧
  (∀ p, p ∈ occ → B p.1 p.2) ∧
  (∀ x y, 0 ≤ x → 0 ≤ y → (B x y ↔ (x,y) ∈ occ))

def addTile (B : Int → Int → Prop) (t : Cross) : Int → Int → Prop :=
  fun x y => B x y ∨ Contains t x y

theorem fresh_disjoint {world : Cross → Prop} {B : Int → Int → Prop}
    (closed : TileClosed world B) {t : Cross} (inWorld : world t)
    {x y : Int} (hit : Contains t x y) (fresh : ¬B x y) :
    ∀ u v, Contains t u v → ¬B u v := by
  intro u v there blocked
  exact fresh (closed t inWorld u v there blocked x y hit)

theorem addTile_closed {world : Cross → Prop} {B : Int → Int → Prop}
    (closed : TileClosed world B) (separate : DisjointWorld world)
    {t : Cross} (inWorld : world t) : TileClosed world (addTile B t) := by
  intro u hu x y hit blocked v w there
  rcases blocked with old | new
  · exact Or.inl (closed u hu x y hit old v w there)
  · have eq := separate u t x y hu inWorld hit new
    subst u
    exact Or.inr there

theorem addTile_enlarges {world : Cross → Prop} {B : Int → Int → Prop}
    {t : Cross} (ht : world t) : EnlargesByTiles world B (addTile B t) := by
  refine ⟨[t],?_,?_⟩
  · intro u hu
    simp only [List.mem_singleton] at hu
    subst u
    exact ht
  · intro x y
    simp [addTile]

theorem enlarges_refl (world : Cross → Prop) (B : Int → Int → Prop) :
    EnlargesByTiles world B B := by
  refine ⟨[],by simp,?_⟩
  simp

theorem enlarges_trans {world : Cross → Prop} {B B' B'' : Int → Int → Prop}
    (first : EnlargesByTiles world B B') (second : EnlargesByTiles world B' B'') :
    EnlargesByTiles world B B'' := by
  obtain ⟨xs,hxs,first⟩ := first
  obtain ⟨ys,hys,second⟩ := second
  refine ⟨xs++ys,?_,?_⟩
  · intro t ht
    rcases List.mem_append.mp ht with ht | ht
    · exact hxs t ht
    · exact hys t ht
  · intro x y
    rw [second, first]
    simp only [List.mem_append]
    constructor
    · rintro ((old | ⟨t,ht,hit⟩) | ⟨t,ht,hit⟩)
      · exact Or.inl old
      · exact Or.inr ⟨t,Or.inl ht,hit⟩
      · exact Or.inr ⟨t,Or.inr ht,hit⟩
    · rintro (old | ⟨t,ht,hit⟩)
      · exact Or.inl (Or.inl old)
      · rcases ht with ht | ht
        · exact Or.inl (Or.inr ⟨t,ht,hit⟩)
        · exact Or.inr ⟨t,ht,hit⟩

theorem transition_back {world : Cross → Prop} {h : Int} {old : Kind}
    {B B' : Int → Int → Prop} (added : EnlargesByTiles world B B')
    (step : Transition world h old B') : Transition world h old B := by
  obtain ⟨B'',new,dx,dy,enlarged,closed,bounded,clean,progress⟩ := step
  exact ⟨B'',new,dx,dy,enlarges_trans added enlarged,closed,bounded,clean,progress⟩

structure Branch where
  tile : Cross
  occupied : List Cell
  deriving DecidableEq

def StepCheck (a : Int) (occ : List Cell) (p : Cell) (branches : List Branch) : Prop :=
  0 ≤ p.1 ∧ p.1 ≤ 7 ∧ 0 ≤ p.2 ∧
  (∃ q, q ∈ occ ∧ p.2 ≤ q.2) ∧ p ∉ occ ∧
  (∀ t, t ∈ candidates a p →
    (∃ q, q ∈ occ ∧ Contains t q.1 q.2) ∨
    (∃ b, b ∈ branches ∧ b.tile=t)) ∧
  (∀ b, b ∈ branches → SameCells b.occupied (occ ++ cells b.tile))

instance (a : Int) (occ : List Cell) (p : Cell) (branches : List Branch) :
    Decidable (StepCheck a occ p branches) := by
  unfold StepCheck
  infer_instance

/-- A witness aligned with each candidate avoids searching the occupied list
for a collision during kernel reduction. `none` names a genuine child. -/
def EvidenceCase (occ : List Cell) (branches : List Branch)
    (pair : Cross × Option Cell) : Prop :=
    match pair.2 with
    | some q => q ∈ occ ∧ Contains pair.1 q.1 q.2
    | none => ∃ b, b ∈ branches ∧ b.tile=pair.1

instance (occ : List Cell) (branches : List Branch) (pair : Cross × Option Cell) :
    Decidable (EvidenceCase occ branches pair) := by
  unfold EvidenceCase
  cases pair.2 <;> infer_instance

def CoverageEvidence (a : Int) (occ : List Cell) (p : Cell)
    (branches : List Branch) (witnesses : List (Option Cell)) : Prop :=
  (candidates a p).length ≤ witnesses.length ∧
  ∀ pair, pair ∈ (candidates a p).zip witnesses → EvidenceCase occ branches pair

instance (a : Int) (occ : List Cell) (p : Cell) (branches : List Branch)
    (witnesses : List (Option Cell)) :
    Decidable (CoverageEvidence a occ p branches witnesses) := by
  unfold CoverageEvidence
  infer_instance

theorem stepCheck_of_evidence {a : Int} {occ : List Cell} {p : Cell}
    {branches : List Branch} {witnesses : List (Option Cell)}
    (bounds : 0 ≤ p.1 ∧ p.1 ≤ 7 ∧ 0 ≤ p.2 ∧
      (∃ q, q ∈ occ ∧ p.2 ≤ q.2) ∧ p ∉ occ)
    (evidence : CoverageEvidence a occ p branches witnesses)
    (updates : ∀ b, b ∈ branches → SameCells b.occupied (occ ++ cells b.tile)) :
    StepCheck a occ p branches := by
  refine ⟨bounds.1,bounds.2.1,bounds.2.2.1,bounds.2.2.2.1,bounds.2.2.2.2,?_,updates⟩
  intro t mem
  have firsts := List.map_fst_zip evidence.1
  have mapped : t ∈ ((candidates a p).zip witnesses).map Prod.fst := by
    rw [firsts]
    exact mem
  obtain ⟨pair,hpair,eq⟩ := List.mem_map.mp mapped
  have why := evidence.2 pair hpair
  unfold EvidenceCase at why
  cases which : pair.2 with
  | some q =>
    rw [which] at why
    exact Or.inl ⟨q,why.1,by simpa only [eq] using why.2⟩
  | none =>
    rw [which] at why
    exact Or.inr (by simpa only [eq] using why)

theorem replay_step (a : Int) (ha : 0 ≤ a) (world : Cross → Prop) (h : Int)
    (source : Kind) (occ : List Cell) (p : Cell) (branches : List Branch)
    (copies : ∀ t, world t → Copy a 1 1 0 t)
    (separate : DisjointWorld world) (cover : CoversWindow world h)
    (ceiling : SelectedBelow world h) (checked : StepCheck a occ p branches)
    (next : ∀ b, b ∈ branches → ∀ B, State world h b.occupied B →
      Transition world h source B)
    (B : Int → Int → Prop) (state : State world h occ B) :
    Transition world h source B := by
  obtain ⟨hx,hx7,hy,⟨q,hq,hqy⟩,fresh,complete,updates⟩ := checked
  obtain ⟨closed,bounded,occupied,agreement⟩ := state
  have qBelow := bounded q.1 q.2 (occupied q hq)
  have window : QueryWindow h p.1 p.2 := ⟨hx,hx7,hy,by omega⟩
  obtain ⟨t,ht,hit⟩ := cover p.1 p.2 window
  have freshB : ¬B p.1 p.2 := fun bad => fresh ((agreement p.1 p.2 hx hy).1 bad)
  have apart := fresh_disjoint closed ht hit freshB
  have possible := candidate_complete ha (copies t ht) hit
  obtain overlap | ⟨b,hb,eq⟩ := complete t possible
  · obtain ⟨q,hq,hitq⟩ := overlap
    exact False.elim (apart q.1 q.2 hitq (occupied q hq))
  · have nn := copy_nonnegative ha (copies t ht)
    have update := updates b hb
    have bState : State world h b.occupied (addTile B t) := by
      refine ⟨addTile_closed closed separate ht,?_,?_,?_⟩
      · intro x y member
        rcases member with member | member
        · exact bounded x y member
        · exact ceiling t ht ⟨p.1,p.2,window,hit⟩ x y member
      · intro q hq
        have union := (sameCells_iff update q).1 hq
        rw [List.mem_append, eq] at union
        rcases union with old | new
        · exact Or.inl (occupied q old)
        · exact Or.inr ((mem_cells_iff nn q.1 q.2).1 new)
      · intro x y hx hy
        rw [sameCells_iff update (x,y), List.mem_append, eq]
        exact or_congr (agreement x y hx hy) (mem_cells_iff nn x y).symm
    exact transition_back (addTile_enlarges ht) (next b hb (addTile B t) bState)

def wallCells (k : Kind) : List Cell :=
  (List.range (wallHeight k).toNat).map (fun (i : Nat) => ((-1 : Int),(i : Int))) ++
  (List.range (wallWidth k).toNat).map (fun (i : Nat) => ((i : Int),(-1 : Int)))

def extraCells : Kind → List Cell
  | .alpha => []
  | .beta | .betaTranspose => [(0,0)]
  | .gamma => [(0,0),(1,0)]
  | .gammaTranspose => [(0,0),(0,1)]

theorem mem_wallCells (k : Kind) (x y : Int) :
    (x,y) ∈ wallCells k ↔ Wall k x y := by
  have hh := (kind_bounds k).1
  have hw : 0 < wallWidth k := by cases k <;> decide
  simp only [wallCells, List.mem_append, List.mem_map, List.mem_range]
  constructor
  · rintro (⟨i,hi,eq⟩ | ⟨i,hi,eq⟩)
    · have ex := congrArg Prod.fst eq
      have ey := congrArg Prod.snd eq
      dsimp at ex ey
      exact Or.inl ⟨by omega,by omega,by omega⟩
    · have ex := congrArg Prod.fst eq
      have ey := congrArg Prod.snd eq
      dsimp at ex ey
      exact Or.inr ⟨by omega,by omega,by omega⟩
  · rintro (⟨hx,hy0,hy⟩ | ⟨hy,hx0,hx⟩)
    · left
      refine ⟨y.toNat,by omega,?_⟩
      apply Prod.ext <;> dsimp <;> omega
    · right
      refine ⟨x.toNat,by omega,?_⟩
      apply Prod.ext <;> dsimp <;> omega

theorem mem_extraCells (k : Kind) (x y : Int) :
    (x,y) ∈ extraCells k ↔ Extra k x y := by
  cases k <;> simp [extraCells, Extra, Prod.mk.injEq] <;> omega

theorem extra_nonnegative {k : Kind} {x y : Int} (extra : Extra k x y) :
    0 ≤ x ∧ 0 ≤ y := by
  cases k <;> dsimp [Extra] at extra <;> omega

def seed (k : Kind) : List Cell := wallCells k ++ extraCells k

theorem seed_state (world : Cross → Prop) (h : Int) (k : Kind)
    (B : Int → Int → Prop) (closed : TileClosed world B) (bounded : Below h B)
    (clean : Clean k 0 0 B) : State world h (seed k) B := by
  refine ⟨closed,bounded,?_,?_⟩
  · rintro ⟨x,y⟩ member
    rcases List.mem_append.mp member with wall | extra
    · simpa using clean.1 x y ((mem_wallCells k x y).1 wall)
    · have ex := (mem_extraCells k x y).1 extra
      have nn := extra_nonnegative ex
      simpa using (clean.2 x y nn.1 nn.2).2 ex
  · intro x y hx hy
    simp only [seed, List.mem_append, mem_wallCells, mem_extraCells]
    have notWall : ¬Wall k x y := by
      unfold Wall
      omega
    simpa only [Int.zero_add, notWall, false_or] using clean.2 x y hx hy

theorem state_congr {world : Cross → Prop} {h : Int} {xs ys : List Cell}
    {B : Int → Int → Prop} (eq : SameCells xs ys) (state : State world h xs B) :
    State world h ys B := by
  obtain ⟨closed,bounded,occupied,agreement⟩ := state
  refine ⟨closed,bounded,?_,?_⟩
  · intro p member
    exact occupied p (eq.2 p member)
  · intro x y hx hy
    exact (agreement x y hx hy).trans (sameCells_iff eq (x,y))

def shiftCell (dx dy : Int) (p : Cell) : Cell := (dx+p.1,dy+p.2)

theorem mem_shifted (xs : List Cell) (dx dy x y : Int) :
    (dx+x,dy+y) ∈ xs.map (shiftCell dx dy) ↔ (x,y) ∈ xs := by
  simp only [List.mem_map]
  constructor
  · rintro ⟨q,hq,eq⟩
    have ex := congrArg Prod.fst eq
    have ey := congrArg Prod.snd eq
    dsimp [shiftCell] at ex ey
    have qeq : q=(x,y) := by apply Prod.ext <;> dsimp <;> omega
    simpa only [qeq] using hq
  · intro member
    exact ⟨(x,y),member,rfl⟩

def futureCells (occ : List Cell) (dx dy : Int) : List Cell :=
  occ.filter fun p => decide (dx ≤ p.1 ∧ dy ≤ p.2)

theorem mem_future {occ : List Cell} {dx dy x y : Int} (hx : 0 ≤ x) (hy : 0 ≤ y) :
    (dx+x,dy+y) ∈ futureCells occ dx dy ↔ (dx+x,dy+y) ∈ occ := by
  simp [futureCells, List.mem_filter]
  omega

instance (old new : Kind) (dx dy : Int) : Decidable (Progress old new dx dy) := by
  unfold Progress
  infer_instance

def LeafCheck (source : Kind) (occ : List Cell) (new : Kind) (dx dy : Int) : Prop :=
  Progress source new dx dy ∧
  (∀ p, p ∈ wallCells new → shiftCell dx dy p ∈ occ) ∧
  SameCells (futureCells occ dx dy) ((extraCells new).map (shiftCell dx dy))

instance (source : Kind) (occ : List Cell) (new : Kind) (dx dy : Int) :
    Decidable (LeafCheck source occ new dx dy) := by
  unfold LeafCheck
  infer_instance

theorem replay_leaf (world : Cross → Prop) (h : Int) (source : Kind)
    (occ : List Cell) (new : Kind) (dx dy : Int)
    (checked : LeafCheck source occ new dx dy)
    (B : Int → Int → Prop) (state : State world h occ B) :
    Transition world h source B := by
  obtain ⟨progress,walls,future⟩ := checked
  obtain ⟨closed,bounded,occupied,agreement⟩ := state
  refine ⟨B,new,dx,dy,enlarges_refl world B,closed,bounded,?_,progress⟩
  constructor
  · intro x y wall
    exact occupied _ (walls (x,y) ((mem_wallCells new x y).2 wall))
  · intro x y hx hy
    have hx' : 0 ≤ dx+x := by have := progress.1; omega
    have hy' : 0 ≤ dy+y := by have := progress.2.1; omega
    exact (agreement (dx+x) (dy+y) hx' hy').trans
      ((mem_future hx hy).symm.trans
        ((sameCells_iff future (dx+x,dy+y)).trans
          ((mem_shifted (extraCells new) dx dy x y).trans (mem_extraCells new x y))))

end CornerCertificate

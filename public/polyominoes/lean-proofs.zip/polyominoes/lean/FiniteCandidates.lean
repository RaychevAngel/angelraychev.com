import TilingCompactness

namespace PolyominoFormal.TilingCompactness
open CrossUnits

def orientations (a b c d x y : Int) : List Cross :=
  [⟨x,y,a,b,c,d⟩,⟨x,y,b,c,d,a⟩,⟨x,y,c,d,a,b⟩,⟨x,y,d,a,b,c⟩,
   ⟨x,y,d,c,b,a⟩,⟨x,y,c,b,a,d⟩,⟨x,y,b,a,d,c⟩,⟨x,y,a,d,c,b⟩]

theorem copy_mem_orientations {a b c d : Int} {t : Cross} (h : Copy a b c d t) :
    t∈orientations a b c d t.x t.y := by
  cases t with | mk x y e n w s =>
  rcases h with h | h | h | h | h | h | h | h
  all_goals rcases h with ⟨he,hn,hw,hs⟩
  all_goals simp only at he hn hw hs
  all_goals subst e; subst n; subst w; subst s
  all_goals simp [orientations]

def candidates (a b c d : Int) (N : Nat) : List Cross :=
  let B := N+(a+b+c+d).toNat
  (List.range (2*B+1)).flatMap fun (i : Nat) =>
    (List.range (2*B+1)).flatMap fun (j : Nat) =>
      orientations a b c d ((i : Int)-B) ((j : Int)-B)

theorem copy_arm_bounds {a b c d : Int} (ha : 0≤a) (hb : 0≤b) (hc : 0≤c) (hd : 0≤d)
    {t : Cross} (h : Copy a b c d t) :
    0≤t.east ∧ t.east≤a+b+c+d ∧ 0≤t.north ∧ t.north≤a+b+c+d ∧
    0≤t.west ∧ t.west≤a+b+c+d ∧ 0≤t.south ∧ t.south≤a+b+c+d := by
  rcases h with h | h | h | h | h | h | h | h
  all_goals rcases h with ⟨he,hn,hw,hs⟩
  all_goals omega

theorem candidate_mem {a b c d : Int} (ha : 0≤a) (hb : 0≤b) (hc : 0≤c) (hd : 0≤d)
    {N : Nat} {x y : Int} (hx : -(N : Int)≤x ∧ x≤N) (hy : -(N : Int)≤y ∧ y≤N)
    {t : Cross} (copy : Copy a b c d t) (hit : Contains t x y) :
    t∈candidates a b c d N := by
  have bounds := copy_arm_bounds ha hb hc hd copy
  let B : Nat := N+(a+b+c+d).toNat
  have hM : ((a+b+c+d).toNat : Int)=a+b+c+d := by omega
  have tx : -(B : Int)≤t.x ∧ t.x≤B := by
    unfold Contains at hit
    dsimp [B]
    omega
  have ty : -(B : Int)≤t.y ∧ t.y≤B := by
    unfold Contains at hit
    dsimp [B]
    omega
  have ex : (((t.x+B).toNat : Nat) : Int)=t.x+B := by omega
  have ey : (((t.y+B).toNat : Nat) : Int)=t.y+B := by omega
  apply List.mem_flatMap.mpr
  refine ⟨(t.x+B).toNat,?_,?_⟩
  · apply List.mem_range.mpr
    change (t.x+(B : Int)).toNat<2*B+1
    omega
  · apply List.mem_flatMap.mpr
    refine ⟨(t.y+B).toNat,?_,?_⟩
    · apply List.mem_range.mpr
      change (t.y+(B : Int)).toNat<2*B+1
      omega
    · change t∈orientations a b c d (((t.x+B).toNat : Int)-B) (((t.y+B).toNat : Int)-B)
      rw [ex,ey]
      have xx : t.x+(B : Int)-B=t.x := by omega
      have yy : t.y+(B : Int)-B=t.y := by omega
      rw [xx,yy]
      exact copy_mem_orientations copy

theorem finite_candidates {a b c d : Int} (ha : 0≤a) (hb : 0≤b) (hc : 0≤c) (hd : 0≤d)
    (x y : Int) :
    ∃ N,∀ t,Copy a b c d t→Contains t x y→t∈candidates a b c d N := by
  refine ⟨x.natAbs+y.natAbs,?_⟩
  intro t copy hit
  apply candidate_mem ha hb hc hd (t:=t) (x:=x) (y:=y) _ _ copy hit
  · have : x≤(x.natAbs : Int) := Int.le_natAbs
    have : -(x.natAbs : Int)≤x := by cases x <;> simp [Int.natAbs] <;> omega
    omega
  · have : y≤(y.natAbs : Int) := Int.le_natAbs
    have : -(y.natAbs : Int)≤y := by cases y <;> simp [Int.natAbs] <;> omega
    omega

/-- A sequence of genuine disjoint worlds inside R covering every cell
of R eventually has an ordinary exact tiling limit. -/
theorem world_limit {a b c d : Int} {R : Region}
    (ha : 0≤a) (hb : 0≤b) (hc : 0≤c) (hd : 0≤d)
    (world : Nat→Cross→Prop)
    (copies : ∀ n t,world n t→Copy a b c d t)
    (inside : ∀ n t,world n t→∀ x y,Contains t x y→R x y)
    (disjoint : ∀ n t u x y,world n t→world n u→Contains t x y→Contains u x y→t=u)
    (cover : ∀ x y,R x y→Eventually (fun n => ∃ t,world n t∧Contains t x y)) :
    Tiles a b c d R :=
  compact world (candidates a b c d) (by intro x y _; exact finite_candidates ha hb hc hd x y)
    copies inside disjoint cover

#print axioms world_limit
end PolyominoFormal.TilingCompactness

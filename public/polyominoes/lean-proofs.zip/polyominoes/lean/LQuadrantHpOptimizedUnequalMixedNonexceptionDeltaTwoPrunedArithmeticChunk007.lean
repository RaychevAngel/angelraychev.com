import LQuadrantHpOptimizedUnequalMixedNonexceptionDeltaTwoPrunedArithmeticDefs
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace LRegionArithmetic

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n196_o4 (a b jx jy : Int)
    (h0 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((6 : Int) ≥ (jx - b)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n196_o5 (a b jx jy : Int)
    (h0 : ((((6 : Int) ≥ (jx - a)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h1 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h3 : (¬ (((jx = ((6 : Int) + a)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n196_o6 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((jy + a) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((4 : Int) > (jx + b)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h5 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n196_o7 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (¬ ((((6 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h3 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h4 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h5 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jy - b) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n197_run_four (a b : Int)
    (h0 : (¬ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ ((2 : Int) + ((2 : Int) * b)))))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n197_run_short (a b : Int)
    (h0 : (a > b))
    (h1 : (¬ ((((2 : Int) + ((2 : Int) * b)) - ((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n197_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n197_run_left (a b : Int)
    (h0 : ((((2 : Int) * a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (¬ ((fact_366edf150095_6949 a b) ∨ (fact_366edf150095_6921 a b) ∨ (fact_366edf150095_7263 a b) ∨ (fact_366edf150095_7265 a b) ∨ (fact_366edf150095_6923 a b) ∨ (fact_366edf150095_6974 a b) ∨ (fact_366edf150095_6924 a b) ∨ (fact_366edf150095_7266 a b) ∨ (fact_366edf150095_6989 a b) ∨ (fact_366edf150095_6930 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) + a))) ∨ (fact_366edf150095_2439 a b)) ∨ (((((6 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((6 : Int) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((6 : Int) ≥ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b)))))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n197_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5830 a b) ∨ (fact_366edf150095_5796 a b) ∨ (fact_366edf150095_6942 a b) ∨ (fact_366edf150095_6944 a b) ∨ (fact_366edf150095_5798 a b) ∨ (fact_366edf150095_5944 a b) ∨ (fact_366edf150095_5800 a b) ∨ (fact_366edf150095_6946 a b) ∨ (fact_366edf150095_6090 a b) ∨ (fact_366edf150095_5804 a b) ∨ (fact_366edf150095_6102 a b) ∨ (fact_366edf150095_5808 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n197_run_tall (a b : Int)
    (h0 : (¬ ((((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7165 a b) ∨ (fact_366edf150095_6999 a b)) ∨ (fact_366edf150095_7763 a b))) ∨ (((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (2 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7165 a b) ∨ (fact_366edf150095_6999 a b)) ∧ (fact_366edf150095_7763 a b)) ∨ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∨ ((((2 : Int) + ((2 : Int) * b)) = (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7165 a b) ∨ (fact_366edf150095_6999 a b)) ∧ (fact_366edf150095_7763 a b) ∧ (((fact_366edf150095_7023 a b) ∨ (fact_366edf150095_6979 a b) ∨ (fact_366edf150095_7281 a b) ∨ (fact_366edf150095_7285 a b) ∨ (fact_366edf150095_6983 a b) ∨ (fact_366edf150095_7095 a b) ∨ (fact_366edf150095_6985 a b) ∨ (fact_366edf150095_7287 a b) ∨ (fact_366edf150095_7160 a b) ∨ (fact_366edf150095_6992 a b) ∨ (fact_366edf150095_7164 a b) ∨ (fact_366edf150095_6998 a b)) ∨ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6597 a b) ∨ (fact_366edf150095_6094 a b) ∨ (fact_366edf150095_6614 a b) ∨ (fact_366edf150095_6109 a b)))) ∨ (((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7165 a b) ∨ (fact_366edf150095_6999 a b)) ∧ (fact_366edf150095_7763 a b) ∧ ((fact_366edf150095_7023 a b) ∨ (fact_366edf150095_6979 a b) ∨ (fact_366edf150095_7281 a b) ∨ (fact_366edf150095_7285 a b) ∨ (fact_366edf150095_6983 a b) ∨ (fact_366edf150095_7095 a b) ∨ (fact_366edf150095_6985 a b) ∨ (fact_366edf150095_7287 a b) ∨ (fact_366edf150095_7160 a b) ∨ (fact_366edf150095_6992 a b) ∨ (fact_366edf150095_7164 a b) ∨ (fact_366edf150095_6998 a b)) ∧ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6597 a b) ∨ (fact_366edf150095_6094 a b) ∨ (fact_366edf150095_6614 a b) ∨ (fact_366edf150095_6109 a b))))))
    (h1 : (a > b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n197_run_empty (a b run_x : Int)
    (h0 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2319 a b run_x) ∨ (fact_366edf150095_3537 a b run_x) ∨ (fact_366edf150095_2995 a b run_x) ∨ (fact_366edf150095_2334 a b run_x) ∨ (fact_366edf150095_3014 a b run_x) ∨ (fact_366edf150095_2340 a b run_x)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n197_run_floor (a b run_x : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h5 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3315 a b run_x) ∨ (fact_366edf150095_5230 a b run_x) ∨ (fact_366edf150095_3578 a b run_x) ∨ (fact_366edf150095_3334 a b run_x) ∨ (fact_366edf150095_3599 a b run_x) ∨ (fact_366edf150095_3341 a b run_x))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h5
  clear h5
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n198_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((6 : Int) ≤ ((5 : Int) + b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n198_run_short (a b : Int)
    (h0 : (¬ ((((5 : Int) + b) - (6 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n198_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n198_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3506 a b) ∨ (fact_366edf150095_3455 a b) ∨ (fact_366edf150095_5782 a b) ∨ (fact_366edf150095_5790 a b) ∨ (fact_366edf150095_3463 a b) ∨ (fact_366edf150095_3701 a b) ∨ (fact_366edf150095_3468 a b) ∨ (fact_366edf150095_5795 a b) ∨ (fact_366edf150095_3973 a b) ∨ (fact_366edf150095_3472 a b) ∨ (fact_366edf150095_4040 a b) ∨ (fact_366edf150095_3710 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n198_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4130 a b) ∨ (fact_366edf150095_3725 a b) ∨ (fact_366edf150095_5876 a b) ∨ (fact_366edf150095_5959 a b) ∨ (fact_366edf150095_3806 a b) ∨ (fact_366edf150095_4239 a b) ∨ (fact_366edf150095_3877 a b) ∨ (fact_366edf150095_6030 a b) ∨ (((((3 : Int) - b) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3976 a b) ∨ (fact_366edf150095_4983 a b) ∨ (fact_366edf150095_4395 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n198_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ (((((6 : Int) + (3 : Int)) ≤ ((5 : Int) + b)) ∧ ((fact_366edf150095_7607 a b) ∨ (fact_366edf150095_7670 a b))) ∨ ((((6 : Int) + (2 : Int)) ≤ ((5 : Int) + b)) ∧ (fact_366edf150095_7607 a b) ∧ (fact_366edf150095_7670 a b)) ∨ (((6 : Int) + (4 : Int)) ≤ ((5 : Int) + b)) ∨ ((((5 : Int) + b) = ((6 : Int) + (1 : Int))) ∧ (fact_366edf150095_7607 a b) ∧ (fact_366edf150095_7670 a b) ∧ (((fact_366edf150095_4175 a b) ∨ (fact_366edf150095_3770 a b) ∨ (fact_366edf150095_5921 a b) ∨ (fact_366edf150095_6004 a b) ∨ (fact_366edf150095_3851 a b) ∨ (fact_366edf150095_4284 a b) ∨ (fact_366edf150095_3904 a b) ∨ (fact_366edf150095_6056 a b) ∨ (fact_366edf150095_4818 a b) ∨ (fact_366edf150095_4006 a b) ∨ (fact_366edf150095_5009 a b) ∨ (fact_366edf150095_4398 a b)) ∨ ((fact_366edf150095_5153 a b) ∨ (fact_366edf150095_4447 a b) ∨ (fact_366edf150095_6372 a b) ∨ (fact_366edf150095_6460 a b) ∨ (fact_366edf150095_4531 a b) ∨ (fact_366edf150095_5281 a b) ∨ (fact_366edf150095_4606 a b) ∨ (fact_366edf150095_6531 a b) ∨ (fact_366edf150095_5546 a b) ∨ (fact_366edf150095_4866 a b) ∨ (fact_366edf150095_5674 a b) ∨ (fact_366edf150095_5412 a b)))) ∨ ((fact_366edf150095_7607 a b) ∧ (fact_366edf150095_7670 a b) ∧ ((fact_366edf150095_4175 a b) ∨ (fact_366edf150095_3770 a b) ∨ (fact_366edf150095_5921 a b) ∨ (fact_366edf150095_6004 a b) ∨ (fact_366edf150095_3851 a b) ∨ (fact_366edf150095_4284 a b) ∨ (fact_366edf150095_3904 a b) ∨ (fact_366edf150095_6056 a b) ∨ (fact_366edf150095_4818 a b) ∨ (fact_366edf150095_4006 a b) ∨ (fact_366edf150095_5009 a b) ∨ (fact_366edf150095_4398 a b)) ∧ ((fact_366edf150095_5153 a b) ∨ (fact_366edf150095_4447 a b) ∨ (fact_366edf150095_6372 a b) ∨ (fact_366edf150095_6460 a b) ∨ (fact_366edf150095_4531 a b) ∨ (fact_366edf150095_5281 a b) ∨ (fact_366edf150095_4606 a b) ∨ (fact_366edf150095_6531 a b) ∨ (fact_366edf150095_5546 a b) ∨ (fact_366edf150095_4866 a b) ∨ (fact_366edf150095_5674 a b) ∨ (fact_366edf150095_5412 a b))))))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + b) - b)) ∨ ((((6 : Int) + b) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n198_run_empty (a b run_x : Int)
    (h0 : (run_x ≤ ((5 : Int) + b)))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + b) - b)) ∨ ((((6 : Int) + b) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((fact_366edf150095_2377 a b run_x) ∨ (fact_366edf150095_2312 a b run_x) ∨ (fact_366edf150095_3520 a b run_x) ∨ (fact_366edf150095_3535 a b run_x) ∨ (fact_366edf150095_2317 a b run_x) ∨ (fact_366edf150095_2959 a b run_x) ∨ (fact_366edf150095_2321 a b run_x) ∨ (fact_366edf150095_3539 a b run_x) ∨ (fact_366edf150095_2999 a b run_x) ∨ (fact_366edf150095_2335 a b run_x) ∨ (fact_366edf150095_3016 a b run_x) ∨ (fact_366edf150095_2976 a b run_x)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((6 : Int) ≤ run_x))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n198_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((5 : Int) + b)))
    (h1 : (¬ ((fact_366edf150095_3351 a b run_x) ∨ (fact_366edf150095_3300 a b run_x) ∨ (fact_366edf150095_5215 a b run_x) ∨ (fact_366edf150095_5225 a b run_x) ∨ (fact_366edf150095_3310 a b run_x) ∨ (fact_366edf150095_3530 a b run_x) ∨ (fact_366edf150095_3317 a b run_x) ∨ (fact_366edf150095_5232 a b run_x) ∨ (fact_366edf150095_3580 a b run_x) ∨ (fact_366edf150095_3335 a b run_x) ∨ (fact_366edf150095_3600 a b run_x) ∨ (fact_366edf150095_3556 a b run_x))))
    (h2 : ((6 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n199_run_four (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ ((2 : Int) + ((2 : Int) * b)))))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n199_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + ((2 : Int) * b)) - ((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) < b)))
    (h1 : (a > b))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n199_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n199_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : ((((2 : Int) * a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (¬ ((fact_366edf150095_6949 a b) ∨ (fact_366edf150095_6921 a b) ∨ (fact_366edf150095_7263 a b) ∨ (fact_366edf150095_7265 a b) ∨ (fact_366edf150095_6923 a b) ∨ (fact_366edf150095_6974 a b) ∨ (fact_366edf150095_6924 a b) ∨ (fact_366edf150095_7266 a b) ∨ (fact_366edf150095_6989 a b) ∨ (fact_366edf150095_6930 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) + a))) ∨ (fact_366edf150095_2439 a b)) ∨ ((((((6 : Int) + a) - a) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((6 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ ((((6 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b)))))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n199_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5830 a b) ∨ (fact_366edf150095_5796 a b) ∨ (fact_366edf150095_6942 a b) ∨ (fact_366edf150095_6944 a b) ∨ (fact_366edf150095_5798 a b) ∨ (fact_366edf150095_5944 a b) ∨ (fact_366edf150095_5800 a b) ∨ (fact_366edf150095_6946 a b) ∨ (fact_366edf150095_6090 a b) ∨ (fact_366edf150095_5804 a b) ∨ (fact_366edf150095_6102 a b) ∨ (fact_366edf150095_6067 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n199_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : (¬ ((((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7165 a b) ∨ (fact_366edf150095_7149 a b)) ∨ (fact_366edf150095_7773 a b))) ∨ (((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (2 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7165 a b) ∨ (fact_366edf150095_7149 a b)) ∧ (fact_366edf150095_7773 a b)) ∨ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∨ ((((2 : Int) + ((2 : Int) * b)) = (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7165 a b) ∨ (fact_366edf150095_7149 a b)) ∧ (fact_366edf150095_7773 a b) ∧ (((fact_366edf150095_7023 a b) ∨ (fact_366edf150095_6979 a b) ∨ (fact_366edf150095_7281 a b) ∨ (fact_366edf150095_7285 a b) ∨ (fact_366edf150095_6983 a b) ∨ (fact_366edf150095_7095 a b) ∨ (fact_366edf150095_6985 a b) ∨ (fact_366edf150095_7287 a b) ∨ (fact_366edf150095_7160 a b) ∨ (fact_366edf150095_6992 a b) ∨ (fact_366edf150095_7164 a b) ∨ (fact_366edf150095_7148 a b)) ∨ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6597 a b) ∨ (fact_366edf150095_6094 a b) ∨ (fact_366edf150095_6614 a b) ∨ (fact_366edf150095_6558 a b)))) ∨ (((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7165 a b) ∨ (fact_366edf150095_7149 a b)) ∧ (fact_366edf150095_7773 a b) ∧ ((fact_366edf150095_7023 a b) ∨ (fact_366edf150095_6979 a b) ∨ (fact_366edf150095_7281 a b) ∨ (fact_366edf150095_7285 a b) ∨ (fact_366edf150095_6983 a b) ∨ (fact_366edf150095_7095 a b) ∨ (fact_366edf150095_6985 a b) ∨ (fact_366edf150095_7287 a b) ∨ (fact_366edf150095_7160 a b) ∨ (fact_366edf150095_6992 a b) ∨ (fact_366edf150095_7164 a b) ∨ (fact_366edf150095_7148 a b)) ∧ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6597 a b) ∨ (fact_366edf150095_6094 a b) ∨ (fact_366edf150095_6614 a b) ∨ (fact_366edf150095_6558 a b))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n199_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2319 a b run_x) ∨ (fact_366edf150095_3537 a b run_x) ∨ (fact_366edf150095_2995 a b run_x) ∨ (fact_366edf150095_2334 a b run_x) ∨ (fact_366edf150095_3014 a b run_x) ∨ (fact_366edf150095_2974 a b run_x)))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n199_run_floor (a b run_x : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h4 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3315 a b run_x) ∨ (fact_366edf150095_5230 a b run_x) ∨ (fact_366edf150095_3578 a b run_x) ∨ (fact_366edf150095_3334 a b run_x) ∨ (fact_366edf150095_3599 a b run_x) ∨ (fact_366edf150095_3554 a b run_x))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h4
  clear h4
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n200_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ ((2 : Int) + ((2 : Int) * b)))))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n200_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + ((2 : Int) * b)) - ((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) < b)))
    (h1 : (a > b))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n200_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n200_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_6949 a b) ∨ (fact_366edf150095_6921 a b) ∨ (fact_366edf150095_7263 a b) ∨ (fact_366edf150095_7265 a b) ∨ (fact_366edf150095_6923 a b) ∨ (fact_366edf150095_6974 a b) ∨ (fact_366edf150095_6924 a b) ∨ (fact_366edf150095_7266 a b) ∨ (fact_366edf150095_6989 a b) ∨ (fact_366edf150095_6930 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) + a))) ∨ (fact_366edf150095_2439 a b)) ∨ (((((6 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + b))) ∨ (((6 : Int) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((6 : Int) ≥ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h1 : ((((2 : Int) * a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n200_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5830 a b) ∨ (fact_366edf150095_5796 a b) ∨ (fact_366edf150095_6942 a b) ∨ (fact_366edf150095_6944 a b) ∨ (fact_366edf150095_5798 a b) ∨ (fact_366edf150095_5944 a b) ∨ (fact_366edf150095_5800 a b) ∨ (fact_366edf150095_6946 a b) ∨ (fact_366edf150095_6090 a b) ∨ (fact_366edf150095_5804 a b) ∨ (fact_366edf150095_6102 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + b))) ∨ (((6 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((6 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n200_run_tall (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7165 a b) ∨ (fact_366edf150095_7173 a b)) ∨ (fact_366edf150095_7774 a b))) ∨ (((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (2 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7165 a b) ∨ (fact_366edf150095_7173 a b)) ∧ (fact_366edf150095_7774 a b)) ∨ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∨ ((((2 : Int) + ((2 : Int) * b)) = (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7165 a b) ∨ (fact_366edf150095_7173 a b)) ∧ (fact_366edf150095_7774 a b) ∧ (((fact_366edf150095_7023 a b) ∨ (fact_366edf150095_6979 a b) ∨ (fact_366edf150095_7281 a b) ∨ (fact_366edf150095_7285 a b) ∨ (fact_366edf150095_6983 a b) ∨ (fact_366edf150095_7095 a b) ∨ (fact_366edf150095_6985 a b) ∨ (fact_366edf150095_7287 a b) ∨ (fact_366edf150095_7160 a b) ∨ (fact_366edf150095_6992 a b) ∨ (fact_366edf150095_7164 a b) ∨ (fact_366edf150095_7172 a b)) ∨ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6597 a b) ∨ (fact_366edf150095_6094 a b) ∨ (fact_366edf150095_6614 a b) ∨ (fact_366edf150095_6621 a b)))) ∨ (((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7165 a b) ∨ (fact_366edf150095_7173 a b)) ∧ (fact_366edf150095_7774 a b) ∧ ((fact_366edf150095_7023 a b) ∨ (fact_366edf150095_6979 a b) ∨ (fact_366edf150095_7281 a b) ∨ (fact_366edf150095_7285 a b) ∨ (fact_366edf150095_6983 a b) ∨ (fact_366edf150095_7095 a b) ∨ (fact_366edf150095_6985 a b) ∨ (fact_366edf150095_7287 a b) ∨ (fact_366edf150095_7160 a b) ∨ (fact_366edf150095_6992 a b) ∨ (fact_366edf150095_7164 a b) ∨ (fact_366edf150095_7172 a b)) ∧ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6597 a b) ∨ (fact_366edf150095_6094 a b) ∨ (fact_366edf150095_6614 a b) ∨ (fact_366edf150095_6621 a b))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a > b))
    (h5 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (a ≥ b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n200_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2319 a b run_x) ∨ (fact_366edf150095_3537 a b run_x) ∨ (fact_366edf150095_2995 a b run_x) ∨ (fact_366edf150095_2334 a b run_x) ∨ (fact_366edf150095_3014 a b run_x) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + b))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((3 : Int) ≥ (((4 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((4 : Int) + b) + (0 : Int)))))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h5 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h6 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n200_run_floor (a b run_x : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h1 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h5 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3315 a b run_x) ∨ (fact_366edf150095_5230 a b run_x) ∨ (fact_366edf150095_3578 a b run_x) ∨ (fact_366edf150095_3334 a b run_x) ∨ (fact_366edf150095_3599 a b run_x) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ (((4 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((((4 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h5
  clear h5
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n201_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((5 : Int) ≤ ((4 : Int) + b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n201_run_short (a b : Int)
    (h0 : (¬ ((((4 : Int) + b) - (5 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n201_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n201_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_3504 a b) ∨ (fact_366edf150095_3453 a b) ∨ (fact_366edf150095_5780 a b) ∨ (fact_366edf150095_5788 a b) ∨ (fact_366edf150095_3461 a b) ∨ (fact_366edf150095_3699 a b) ∨ (fact_366edf150095_3467 a b) ∨ (fact_366edf150095_5794 a b) ∨ (fact_366edf150095_3971 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)))) ∨ (fact_366edf150095_3708 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n201_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4126 a b) ∨ (fact_366edf150095_3721 a b) ∨ (fact_366edf150095_5872 a b) ∨ (fact_366edf150095_5955 a b) ∨ (fact_366edf150095_3802 a b) ∨ (fact_366edf150095_4235 a b) ∨ (fact_366edf150095_3875 a b) ∨ (fact_366edf150095_6028 a b) ∨ (fact_366edf150095_4776 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)))) ∨ (fact_366edf150095_4387 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n201_run_tall (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((((5 : Int) + (3 : Int)) ≤ ((4 : Int) + b)) ∧ ((fact_366edf150095_7506 a b) ∨ (fact_366edf150095_7579 a b))) ∨ ((((5 : Int) + (2 : Int)) ≤ ((4 : Int) + b)) ∧ (fact_366edf150095_7506 a b) ∧ (fact_366edf150095_7579 a b)) ∨ (((5 : Int) + (4 : Int)) ≤ ((4 : Int) + b)) ∨ ((((4 : Int) + b) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7506 a b) ∧ (fact_366edf150095_7579 a b) ∧ (((fact_366edf150095_4160 a b) ∨ (fact_366edf150095_3755 a b) ∨ (fact_366edf150095_5906 a b) ∨ (fact_366edf150095_5989 a b) ∨ (fact_366edf150095_3836 a b) ∨ (fact_366edf150095_4269 a b) ∨ (fact_366edf150095_3893 a b) ∨ (fact_366edf150095_6045 a b) ∨ (fact_366edf150095_4796 a b) ∨ (fact_366edf150095_3986 a b) ∨ (fact_366edf150095_4390 a b)) ∨ ((fact_366edf150095_5144 a b) ∨ (fact_366edf150095_4438 a b) ∨ (fact_366edf150095_6363 a b) ∨ (fact_366edf150095_6451 a b) ∨ (fact_366edf150095_4522 a b) ∨ (fact_366edf150095_5272 a b) ∨ (fact_366edf150095_4601 a b) ∨ (fact_366edf150095_6526 a b) ∨ (fact_366edf150095_5537 a b) ∨ (fact_366edf150095_4857 a b) ∨ (fact_366edf150095_5401 a b)))) ∨ ((fact_366edf150095_7506 a b) ∧ (fact_366edf150095_7579 a b) ∧ ((fact_366edf150095_4160 a b) ∨ (fact_366edf150095_3755 a b) ∨ (fact_366edf150095_5906 a b) ∨ (fact_366edf150095_5989 a b) ∨ (fact_366edf150095_3836 a b) ∨ (fact_366edf150095_4269 a b) ∨ (fact_366edf150095_3893 a b) ∨ (fact_366edf150095_6045 a b) ∨ (fact_366edf150095_4796 a b) ∨ (fact_366edf150095_3986 a b) ∨ (fact_366edf150095_4390 a b)) ∧ ((fact_366edf150095_5144 a b) ∨ (fact_366edf150095_4438 a b) ∨ (fact_366edf150095_6363 a b) ∨ (fact_366edf150095_6451 a b) ∨ (fact_366edf150095_4522 a b) ∨ (fact_366edf150095_5272 a b) ∨ (fact_366edf150095_4601 a b) ∨ (fact_366edf150095_6526 a b) ∨ (fact_366edf150095_5537 a b) ∨ (fact_366edf150095_4857 a b) ∨ (fact_366edf150095_5401 a b))))))
    (h3 : (a > b))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n201_run_empty (a b run_x : Int)
    (h0 : ((fact_366edf150095_2377 a b run_x) ∨ (fact_366edf150095_2312 a b run_x) ∨ (fact_366edf150095_3520 a b run_x) ∨ (fact_366edf150095_3535 a b run_x) ∨ (fact_366edf150095_2317 a b run_x) ∨ (fact_366edf150095_2959 a b run_x) ∨ (fact_366edf150095_2321 a b run_x) ∨ (fact_366edf150095_3539 a b run_x) ∨ (fact_366edf150095_2999 a b run_x) ∨ (fact_366edf150095_2335 a b run_x) ∨ (fact_366edf150095_2973 a b run_x)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (run_x ≤ ((4 : Int) + b)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((5 : Int) ≤ run_x))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n201_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3351 a b run_x) ∨ (fact_366edf150095_3300 a b run_x) ∨ (fact_366edf150095_5215 a b run_x) ∨ (fact_366edf150095_5225 a b run_x) ∨ (fact_366edf150095_3310 a b run_x) ∨ (fact_366edf150095_3530 a b run_x) ∨ (fact_366edf150095_3317 a b run_x) ∨ (fact_366edf150095_5232 a b run_x) ∨ (fact_366edf150095_3580 a b run_x) ∨ (fact_366edf150095_3335 a b run_x) ∨ (fact_366edf150095_3553 a b run_x))))
    (h1 : ((5 : Int) ≤ run_x))
    (h2 : (run_x ≤ ((4 : Int) + b)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n202_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((6 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((6 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n202_empty (a b : Int)
    (h0 : ((fact_366edf150095_2908 a b) ∨ (fact_366edf150095_2588 a b) ∨ (fact_366edf150095_4081 a b) ∨ (fact_366edf150095_4086 a b) ∨ (fact_366edf150095_2591 a b) ∨ (fact_366edf150095_3193 a b) ∨ (fact_366edf150095_2593 a b) ∨ (fact_366edf150095_4088 a b) ∨ (fact_366edf150095_3201 a b) ∨ (fact_366edf150095_2596 a b) ∨ ((((6 : Int) ≥ ((5 : Int) - b)) ∧ ((6 : Int) ≤ ((5 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((4 : Int) + a)) ∧ ((4 : Int) ≤ ((4 : Int) + a))) ∨ (((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int)) ∧ ((4 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((4 : Int) + a) + (0 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n202_o0 (a b jx jy : Int)
    (h0 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h1 : (((5 : Int) > (jx + a)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ ((((6 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n202_o1 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (¬ ((((6 : Int) = jx) ∧ (jy = ((4 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n202_o2 (a b jx jy : Int)
    (h0 : ((jx < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((((6 : Int) ≥ (jx - a)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (((jx + (0 : Int)) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jy - b) ≥ (0 : Int)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (fact_366edf150095_2954 a b jy))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n202_o3 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((6 : Int) ≥ (jx - b)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h4 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (¬ (((jx = ((6 : Int) + b)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n202_o4 (a b jx jy : Int)
    (h0 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((6 : Int) ≥ (jx - b)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n202_o5 (a b jx jy : Int)
    (h0 : ((((6 : Int) ≥ (jx - a)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h1 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ (((jx = ((6 : Int) + a)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n202_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((5 : Int) > (jx + b)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h5 : (¬ ((((6 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n202_o7 (a b jx jy : Int)
    (h0 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h1 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (¬ ((((6 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h3 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h4 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n203_run_four (a b : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : (¬ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ ((2 : Int) + ((2 : Int) * b)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n203_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + ((2 : Int) * b)) - ((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) < b)))
    (h1 : (a > b))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n203_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n203_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((1 : Int) + ((2 : Int) * a)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h4 : (¬ ((fact_366edf150095_6949 a b) ∨ (fact_366edf150095_6921 a b) ∨ (fact_366edf150095_7263 a b) ∨ (fact_366edf150095_7265 a b) ∨ (fact_366edf150095_6923 a b) ∨ (fact_366edf150095_6974 a b) ∨ (fact_366edf150095_6924 a b) ∨ (fact_366edf150095_7266 a b) ∨ (fact_366edf150095_6989 a b) ∨ (fact_366edf150095_6930 a b) ∨ (fact_366edf150095_6995 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((6 : Int) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((6 : Int) ≥ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b)))))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h4
  clear h4
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n203_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5830 a b) ∨ (fact_366edf150095_5796 a b) ∨ (fact_366edf150095_6942 a b) ∨ (fact_366edf150095_6944 a b) ∨ (fact_366edf150095_5798 a b) ∨ (fact_366edf150095_5944 a b) ∨ (fact_366edf150095_5800 a b) ∨ (fact_366edf150095_6946 a b) ∨ (fact_366edf150095_6090 a b) ∨ (fact_366edf150095_5804 a b) ∨ (fact_366edf150095_6108 a b) ∨ (fact_366edf150095_5808 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n203_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (¬ ((((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7169 a b) ∨ (fact_366edf150095_6999 a b)) ∨ (fact_366edf150095_7764 a b))) ∨ (((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (2 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7169 a b) ∨ (fact_366edf150095_6999 a b)) ∧ (fact_366edf150095_7764 a b)) ∨ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∨ ((((2 : Int) + ((2 : Int) * b)) = (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7169 a b) ∨ (fact_366edf150095_6999 a b)) ∧ (fact_366edf150095_7764 a b) ∧ (((fact_366edf150095_7023 a b) ∨ (fact_366edf150095_6979 a b) ∨ (fact_366edf150095_7281 a b) ∨ (fact_366edf150095_7285 a b) ∨ (fact_366edf150095_6983 a b) ∨ (fact_366edf150095_7095 a b) ∨ (fact_366edf150095_6985 a b) ∨ (fact_366edf150095_7287 a b) ∨ (fact_366edf150095_7160 a b) ∨ (fact_366edf150095_6992 a b) ∨ (fact_366edf150095_7168 a b) ∨ (fact_366edf150095_6998 a b)) ∨ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6597 a b) ∨ (fact_366edf150095_6094 a b) ∨ (fact_366edf150095_6619 a b) ∨ (fact_366edf150095_6109 a b)))) ∨ (((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7169 a b) ∨ (fact_366edf150095_6999 a b)) ∧ (fact_366edf150095_7764 a b) ∧ ((fact_366edf150095_7023 a b) ∨ (fact_366edf150095_6979 a b) ∨ (fact_366edf150095_7281 a b) ∨ (fact_366edf150095_7285 a b) ∨ (fact_366edf150095_6983 a b) ∨ (fact_366edf150095_7095 a b) ∨ (fact_366edf150095_6985 a b) ∨ (fact_366edf150095_7287 a b) ∨ (fact_366edf150095_7160 a b) ∨ (fact_366edf150095_6992 a b) ∨ (fact_366edf150095_7168 a b) ∨ (fact_366edf150095_6998 a b)) ∧ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6597 a b) ∨ (fact_366edf150095_6094 a b) ∨ (fact_366edf150095_6619 a b) ∨ (fact_366edf150095_6109 a b))))))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h5
  clear h5
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n203_run_empty (a b run_x : Int)
    (h0 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2319 a b run_x) ∨ (fact_366edf150095_3537 a b run_x) ∨ (fact_366edf150095_2995 a b run_x) ∨ (fact_366edf150095_2334 a b run_x) ∨ (fact_366edf150095_3018 a b run_x) ∨ (fact_366edf150095_2340 a b run_x)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h3 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n203_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h6 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3315 a b run_x) ∨ (fact_366edf150095_5230 a b run_x) ∨ (fact_366edf150095_3578 a b run_x) ∨ (fact_366edf150095_3334 a b run_x) ∨ (fact_366edf150095_3603 a b run_x) ∨ (fact_366edf150095_3341 a b run_x))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h6
  clear h6
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n204_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((7 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((7 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n204_empty (a b : Int)
    (h0 : ((fact_366edf150095_2910 a b) ∨ (fact_366edf150095_2597 a b) ∨ (fact_366edf150095_4096 a b) ∨ (fact_366edf150095_4100 a b) ∨ (fact_366edf150095_2598 a b) ∨ (fact_366edf150095_3204 a b) ∨ ((((7 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ ((((7 : Int) ≥ (((3 : Int) + ((2 : Int) * b)) - b)) ∧ ((7 : Int) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((7 : Int) ≥ ((3 : Int) + ((2 : Int) * b))) ∧ ((7 : Int) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ ((((7 : Int) ≥ ((3 : Int) - b)) ∧ ((7 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((7 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)))) ∨ ((((7 : Int) ≥ ((5 : Int) - b)) ∧ ((7 : Int) ≤ ((5 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((4 : Int) + a)) ∧ ((4 : Int) ≤ ((4 : Int) + a))) ∨ (((5 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (5 : Int)) ∧ ((4 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3209 a b)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n204_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h2 : (((6 : Int) > (jx + a)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (¬ ((((7 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n204_o1 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h1 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h2 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n204_o2 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (fact_366edf150095_2954 a b jy))
    (h3 : ((((7 : Int) ≥ (jx - a)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jx < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h6 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n204_o3 (a b jx jy : Int)
    (h0 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (¬ (((jx = ((7 : Int) + b)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : ((((7 : Int) ≥ (jx - b)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n204_o4 (a b jx jy : Int)
    (h0 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((7 : Int) ≥ (jx - b)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n204_o5 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (¬ (((jx = ((7 : Int) + a)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((7 : Int) ≥ (jx - a)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n204_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h3 : (((6 : Int) > (jx + b)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((jy + a) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - (0 : Int)))))
    (h5 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n204_o7 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h1 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h4 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (¬ ((((7 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h7 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a ≥ (5 : Int)))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n205_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ ((2 : Int) + ((2 : Int) * b)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n205_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + ((2 : Int) * b)) - ((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) < b)))
    (h1 : (a > b))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n205_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n205_run_left (a b : Int)
    (h0 : ((((1 : Int) + ((2 : Int) * a)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h1 : (¬ ((fact_366edf150095_6949 a b) ∨ (fact_366edf150095_6921 a b) ∨ (fact_366edf150095_7263 a b) ∨ (fact_366edf150095_7265 a b) ∨ (fact_366edf150095_6923 a b) ∨ (fact_366edf150095_6974 a b) ∨ (fact_366edf150095_6924 a b) ∨ (fact_366edf150095_7266 a b) ∨ (fact_366edf150095_6989 a b) ∨ (fact_366edf150095_6930 a b) ∨ (fact_366edf150095_6995 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((6 : Int) ≥ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((7 : Int) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((7 : Int) ≥ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b)))))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n205_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_5830 a b) ∨ (fact_366edf150095_5796 a b) ∨ (fact_366edf150095_6942 a b) ∨ (fact_366edf150095_6944 a b) ∨ (fact_366edf150095_5798 a b) ∨ (fact_366edf150095_5944 a b) ∨ (fact_366edf150095_5800 a b) ∨ (fact_366edf150095_6946 a b) ∨ (fact_366edf150095_6090 a b) ∨ (fact_366edf150095_5804 a b) ∨ (fact_366edf150095_6108 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((6 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((7 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((7 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b)))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n205_run_tall (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : (¬ ((((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7169 a b) ∨ (fact_366edf150095_7177 a b) ∨ (fact_366edf150095_7001 a b)) ∨ (fact_366edf150095_7824 a b))) ∨ (((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (2 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7169 a b) ∨ (fact_366edf150095_7177 a b) ∨ (fact_366edf150095_7001 a b)) ∧ (fact_366edf150095_7824 a b)) ∨ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∨ ((((2 : Int) + ((2 : Int) * b)) = (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7169 a b) ∨ (fact_366edf150095_7177 a b) ∨ (fact_366edf150095_7001 a b)) ∧ (fact_366edf150095_7824 a b) ∧ (((fact_366edf150095_7023 a b) ∨ (fact_366edf150095_6979 a b) ∨ (fact_366edf150095_7281 a b) ∨ (fact_366edf150095_7285 a b) ∨ (fact_366edf150095_6983 a b) ∨ (fact_366edf150095_7095 a b) ∨ (fact_366edf150095_6985 a b) ∨ (fact_366edf150095_7287 a b) ∨ (fact_366edf150095_7160 a b) ∨ (fact_366edf150095_6992 a b) ∨ (fact_366edf150095_7168 a b) ∨ (fact_366edf150095_7176 a b) ∨ (((((7 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) + a))) ∨ (((7 : Int) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((7 : Int) ≥ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b))))) ∨ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6597 a b) ∨ (fact_366edf150095_6094 a b) ∨ (fact_366edf150095_6619 a b) ∨ (fact_366edf150095_6624 a b) ∨ (((((7 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) + a))) ∨ (((7 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((7 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b))))))) ∨ (((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7169 a b) ∨ (fact_366edf150095_7177 a b) ∨ (fact_366edf150095_7001 a b)) ∧ (fact_366edf150095_7824 a b) ∧ ((fact_366edf150095_7023 a b) ∨ (fact_366edf150095_6979 a b) ∨ (fact_366edf150095_7281 a b) ∨ (fact_366edf150095_7285 a b) ∨ (fact_366edf150095_6983 a b) ∨ (fact_366edf150095_7095 a b) ∨ (fact_366edf150095_6985 a b) ∨ (fact_366edf150095_7287 a b) ∨ (fact_366edf150095_7160 a b) ∨ (fact_366edf150095_6992 a b) ∨ (fact_366edf150095_7168 a b) ∨ (fact_366edf150095_7176 a b) ∨ (((((7 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) + a))) ∨ (((7 : Int) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((7 : Int) ≥ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b))))) ∧ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6597 a b) ∨ (fact_366edf150095_6094 a b) ∨ (fact_366edf150095_6619 a b) ∨ (fact_366edf150095_6624 a b) ∨ (((((7 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) + a))) ∨ (((7 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((7 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b)))))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a > b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n205_run_empty (a b run_x : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h3 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h4 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2319 a b run_x) ∨ (fact_366edf150095_3537 a b run_x) ∨ (fact_366edf150095_2995 a b run_x) ∨ (fact_366edf150095_2334 a b run_x) ∨ (fact_366edf150095_3018 a b run_x) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((3 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + a)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((7 : Int) ≤ run_x) ∧ ((7 : Int) ≥ run_x) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b))))))
    (h5 : ((((3 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n205_run_floor (a b run_x : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h2 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h3 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3315 a b run_x) ∨ (fact_366edf150095_5230 a b run_x) ∨ (fact_366edf150095_3578 a b run_x) ∨ (fact_366edf150095_3334 a b run_x) ∨ (fact_366edf150095_3603 a b run_x) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((7 : Int) ≤ run_x) ∧ ((7 : Int) ≥ run_x) ∧ (((4 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((4 : Int) + b)))))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n206_run_four (a b : Int)
    (h0 : (¬ ((7 : Int) ≤ ((6 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n206_run_short (a b : Int)
    (h0 : (¬ ((((6 : Int) + b) - (7 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n206_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n206_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3507 a b) ∨ (fact_366edf150095_3456 a b) ∨ (fact_366edf150095_5783 a b) ∨ (fact_366edf150095_5791 a b) ∨ (fact_366edf150095_3464 a b) ∨ (fact_366edf150095_3702 a b) ∨ (((((2 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)))) ∨ (((((5 : Int) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((5 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((5 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4054 a b) ∨ (fact_366edf150095_3711 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n206_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_4131 a b) ∨ (fact_366edf150095_3726 a b) ∨ (fact_366edf150095_5877 a b) ∨ (fact_366edf150095_5960 a b) ∨ (fact_366edf150095_3807 a b) ∨ (fact_366edf150095_4240 a b) ∨ (((((2 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)))) ∨ (((((5 : Int) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((5 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5044 a b) ∨ (fact_366edf150095_4403 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n206_run_tall (a b : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < (((7 : Int) + b) - b)) ∨ ((((7 : Int) + b) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : (¬ (((((7 : Int) + (3 : Int)) ≤ ((6 : Int) + b)) ∧ ((fact_366edf150095_7694 a b) ∨ (fact_366edf150095_7720 a b))) ∨ ((((7 : Int) + (2 : Int)) ≤ ((6 : Int) + b)) ∧ (fact_366edf150095_7694 a b) ∧ (fact_366edf150095_7720 a b)) ∨ (((7 : Int) + (4 : Int)) ≤ ((6 : Int) + b)) ∨ ((((6 : Int) + b) = ((7 : Int) + (1 : Int))) ∧ (fact_366edf150095_7694 a b) ∧ (fact_366edf150095_7720 a b) ∧ (((fact_366edf150095_4187 a b) ∨ (fact_366edf150095_3782 a b) ∨ (fact_366edf150095_5933 a b) ∨ (fact_366edf150095_6016 a b) ∨ (fact_366edf150095_3863 a b) ∨ (fact_366edf150095_4296 a b) ∨ (((((2 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a))) ∨ (((2 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ (((4 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)))) ∨ (((((5 : Int) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((5 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((5 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5053 a b) ∨ (fact_366edf150095_4406 a b)) ∨ ((fact_366edf150095_5158 a b) ∨ (fact_366edf150095_4452 a b) ∨ (fact_366edf150095_6377 a b) ∨ (fact_366edf150095_6465 a b) ∨ (fact_366edf150095_4536 a b) ∨ (fact_366edf150095_5286 a b) ∨ (((((2 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a))) ∨ (((2 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ (((4 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)))) ∨ (((((5 : Int) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((5 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5721 a b) ∨ (fact_366edf150095_5420 a b)))) ∨ ((fact_366edf150095_7694 a b) ∧ (fact_366edf150095_7720 a b) ∧ ((fact_366edf150095_4187 a b) ∨ (fact_366edf150095_3782 a b) ∨ (fact_366edf150095_5933 a b) ∨ (fact_366edf150095_6016 a b) ∨ (fact_366edf150095_3863 a b) ∨ (fact_366edf150095_4296 a b) ∨ (((((2 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a))) ∨ (((2 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ (((4 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)))) ∨ (((((5 : Int) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((5 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((5 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5053 a b) ∨ (fact_366edf150095_4406 a b)) ∧ ((fact_366edf150095_5158 a b) ∨ (fact_366edf150095_4452 a b) ∨ (fact_366edf150095_6377 a b) ∨ (fact_366edf150095_6465 a b) ∨ (fact_366edf150095_4536 a b) ∨ (fact_366edf150095_5286 a b) ∨ (((((2 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a))) ∨ (((2 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ (((4 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)))) ∨ (((((5 : Int) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((5 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5721 a b) ∨ (fact_366edf150095_5420 a b))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n206_run_empty (a b run_x : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < (((7 : Int) + b) - b)) ∨ ((((7 : Int) + b) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : (run_x ≤ ((6 : Int) + b)))
    (h5 : ((fact_366edf150095_2377 a b run_x) ∨ (fact_366edf150095_2312 a b run_x) ∨ (fact_366edf150095_3520 a b run_x) ∨ (fact_366edf150095_3535 a b run_x) ∨ (fact_366edf150095_2317 a b run_x) ∨ (fact_366edf150095_2959 a b run_x) ∨ (fact_366edf150095_2321 a b run_x) ∨ (fact_366edf150095_3539 a b run_x) ∨ (fact_366edf150095_2999 a b run_x) ∨ (fact_366edf150095_2335 a b run_x) ∨ (((((5 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3024 a b run_x) ∨ (fact_366edf150095_2978 a b run_x)))
    (h6 : ((7 : Int) ≤ run_x))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n206_run_floor (a b run_x : Int)
    (h0 : ((7 : Int) ≤ run_x))
    (h1 : (¬ ((fact_366edf150095_3351 a b run_x) ∨ (fact_366edf150095_3300 a b run_x) ∨ (fact_366edf150095_5215 a b run_x) ∨ (fact_366edf150095_5225 a b run_x) ∨ (fact_366edf150095_3310 a b run_x) ∨ (fact_366edf150095_3530 a b run_x) ∨ (fact_366edf150095_3317 a b run_x) ∨ (fact_366edf150095_5232 a b run_x) ∨ (fact_366edf150095_3580 a b run_x) ∨ (fact_366edf150095_3335 a b run_x) ∨ (((((5 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3611 a b run_x) ∨ (fact_366edf150095_3558 a b run_x))))
    (h2 : (run_x ≤ ((6 : Int) + b)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n207_run_four (a b : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (¬ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ ((2 : Int) + ((2 : Int) * b)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n207_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + ((2 : Int) * b)) - ((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) < b)))
    (h1 : (a > b))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n207_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n207_run_left (a b : Int)
    (h0 : ((((1 : Int) + ((2 : Int) * a)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ ((fact_366edf150095_6949 a b) ∨ (fact_366edf150095_6921 a b) ∨ (fact_366edf150095_7263 a b) ∨ (fact_366edf150095_7265 a b) ∨ (fact_366edf150095_6923 a b) ∨ (fact_366edf150095_6974 a b) ∨ (fact_366edf150095_6924 a b) ∨ (fact_366edf150095_7266 a b) ∨ (fact_366edf150095_6989 a b) ∨ (fact_366edf150095_6930 a b) ∨ (fact_366edf150095_6995 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((6 : Int) ≥ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((7 : Int) + a) - a) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ ((((7 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b)))))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n207_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5830 a b) ∨ (fact_366edf150095_5796 a b) ∨ (fact_366edf150095_6942 a b) ∨ (fact_366edf150095_6944 a b) ∨ (fact_366edf150095_5798 a b) ∨ (fact_366edf150095_5944 a b) ∨ (fact_366edf150095_5800 a b) ∨ (fact_366edf150095_6946 a b) ∨ (fact_366edf150095_6090 a b) ∨ (fact_366edf150095_5804 a b) ∨ (fact_366edf150095_6108 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((6 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((7 : Int) + a) - a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ ((((7 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n207_run_tall (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : (¬ ((((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7169 a b) ∨ (fact_366edf150095_7177 a b) ∨ (fact_366edf150095_7151 a b)) ∨ (fact_366edf150095_7826 a b))) ∨ (((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (2 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7169 a b) ∨ (fact_366edf150095_7177 a b) ∨ (fact_366edf150095_7151 a b)) ∧ (fact_366edf150095_7826 a b)) ∨ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∨ ((((2 : Int) + ((2 : Int) * b)) = (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7169 a b) ∨ (fact_366edf150095_7177 a b) ∨ (fact_366edf150095_7151 a b)) ∧ (fact_366edf150095_7826 a b) ∧ (((fact_366edf150095_7023 a b) ∨ (fact_366edf150095_6979 a b) ∨ (fact_366edf150095_7281 a b) ∨ (fact_366edf150095_7285 a b) ∨ (fact_366edf150095_6983 a b) ∨ (fact_366edf150095_7095 a b) ∨ (fact_366edf150095_6985 a b) ∨ (fact_366edf150095_7287 a b) ∨ (fact_366edf150095_7160 a b) ∨ (fact_366edf150095_6992 a b) ∨ (fact_366edf150095_7168 a b) ∨ (fact_366edf150095_7176 a b) ∨ ((((((7 : Int) + a) - a) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) + a))) ∨ ((((7 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b))))) ∨ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6597 a b) ∨ (fact_366edf150095_6094 a b) ∨ (fact_366edf150095_6619 a b) ∨ (fact_366edf150095_6624 a b) ∨ ((((((7 : Int) + a) - a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) + a))) ∨ ((((7 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((7 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b))))))) ∨ (((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7169 a b) ∨ (fact_366edf150095_7177 a b) ∨ (fact_366edf150095_7151 a b)) ∧ (fact_366edf150095_7826 a b) ∧ ((fact_366edf150095_7023 a b) ∨ (fact_366edf150095_6979 a b) ∨ (fact_366edf150095_7281 a b) ∨ (fact_366edf150095_7285 a b) ∨ (fact_366edf150095_6983 a b) ∨ (fact_366edf150095_7095 a b) ∨ (fact_366edf150095_6985 a b) ∨ (fact_366edf150095_7287 a b) ∨ (fact_366edf150095_7160 a b) ∨ (fact_366edf150095_6992 a b) ∨ (fact_366edf150095_7168 a b) ∨ (fact_366edf150095_7176 a b) ∨ ((((((7 : Int) + a) - a) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) + a))) ∨ ((((7 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b))))) ∧ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6597 a b) ∨ (fact_366edf150095_6094 a b) ∨ (fact_366edf150095_6619 a b) ∨ (fact_366edf150095_6624 a b) ∨ ((((((7 : Int) + a) - a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) + a))) ∨ ((((7 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((7 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b)))))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n207_run_empty (a b run_x : Int)
    (h0 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2319 a b run_x) ∨ (fact_366edf150095_3537 a b run_x) ∨ (fact_366edf150095_2995 a b run_x) ∨ (fact_366edf150095_2334 a b run_x) ∨ (fact_366edf150095_3018 a b run_x) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((3 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((7 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ ((((7 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b))))))
    (h5 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n207_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h3 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3315 a b run_x) ∨ (fact_366edf150095_5230 a b run_x) ∨ (fact_366edf150095_3578 a b run_x) ∨ (fact_366edf150095_3334 a b run_x) ∨ (fact_366edf150095_3603 a b run_x) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((7 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((7 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((4 : Int) + b)))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : ((((3 : Int) + ((2 : Int) * b)) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n208_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h2 : (¬ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ ((2 : Int) + ((2 : Int) * b)))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n208_run_short (a b : Int)
    (h0 : (a > b))
    (h1 : (¬ ((((2 : Int) + ((2 : Int) * b)) - ((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n208_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n208_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_6949 a b) ∨ (fact_366edf150095_6921 a b) ∨ (fact_366edf150095_7263 a b) ∨ (fact_366edf150095_7265 a b) ∨ (fact_366edf150095_6923 a b) ∨ (fact_366edf150095_6974 a b) ∨ (fact_366edf150095_6924 a b) ∨ (fact_366edf150095_7266 a b) ∨ (fact_366edf150095_6989 a b) ∨ (fact_366edf150095_6930 a b) ∨ (fact_366edf150095_6995 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((6 : Int) ≥ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + b))) ∨ (((7 : Int) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((7 : Int) ≥ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h1 : ((((2 : Int) * a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n208_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5830 a b) ∨ (fact_366edf150095_5796 a b) ∨ (fact_366edf150095_6942 a b) ∨ (fact_366edf150095_6944 a b) ∨ (fact_366edf150095_5798 a b) ∨ (fact_366edf150095_5944 a b) ∨ (fact_366edf150095_5800 a b) ∨ (fact_366edf150095_6946 a b) ∨ (fact_366edf150095_6090 a b) ∨ (fact_366edf150095_5804 a b) ∨ (fact_366edf150095_6108 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((6 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + b))) ∨ (((7 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((7 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n208_run_tall (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a > b))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h4 : (¬ ((((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7169 a b) ∨ (fact_366edf150095_7177 a b) ∨ (fact_366edf150095_7179 a b)) ∨ (fact_366edf150095_7827 a b))) ∨ (((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (2 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7169 a b) ∨ (fact_366edf150095_7177 a b) ∨ (fact_366edf150095_7179 a b)) ∧ (fact_366edf150095_7827 a b)) ∨ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∨ ((((2 : Int) + ((2 : Int) * b)) = (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7169 a b) ∨ (fact_366edf150095_7177 a b) ∨ (fact_366edf150095_7179 a b)) ∧ (fact_366edf150095_7827 a b) ∧ (((fact_366edf150095_7023 a b) ∨ (fact_366edf150095_6979 a b) ∨ (fact_366edf150095_7281 a b) ∨ (fact_366edf150095_7285 a b) ∨ (fact_366edf150095_6983 a b) ∨ (fact_366edf150095_7095 a b) ∨ (fact_366edf150095_6985 a b) ∨ (fact_366edf150095_7287 a b) ∨ (fact_366edf150095_7160 a b) ∨ (fact_366edf150095_6992 a b) ∨ (fact_366edf150095_7168 a b) ∨ (fact_366edf150095_7176 a b) ∨ (((((7 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b))) ∨ (((7 : Int) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((7 : Int) ≥ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + b) - b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((4 : Int) + b) + (0 : Int)))))) ∨ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6597 a b) ∨ (fact_366edf150095_6094 a b) ∨ (fact_366edf150095_6619 a b) ∨ (fact_366edf150095_6624 a b) ∨ (((((7 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((7 : Int) + a)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b))) ∨ (((7 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((7 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((4 : Int) + b) - b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((4 : Int) + b) + (0 : Int)))))))) ∨ (((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7169 a b) ∨ (fact_366edf150095_7177 a b) ∨ (fact_366edf150095_7179 a b)) ∧ (fact_366edf150095_7827 a b) ∧ ((fact_366edf150095_7023 a b) ∨ (fact_366edf150095_6979 a b) ∨ (fact_366edf150095_7281 a b) ∨ (fact_366edf150095_7285 a b) ∨ (fact_366edf150095_6983 a b) ∨ (fact_366edf150095_7095 a b) ∨ (fact_366edf150095_6985 a b) ∨ (fact_366edf150095_7287 a b) ∨ (fact_366edf150095_7160 a b) ∨ (fact_366edf150095_6992 a b) ∨ (fact_366edf150095_7168 a b) ∨ (fact_366edf150095_7176 a b) ∨ (((((7 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b))) ∨ (((7 : Int) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((7 : Int) ≥ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((4 : Int) + b) - b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((4 : Int) + b) + (0 : Int)))))) ∧ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6597 a b) ∨ (fact_366edf150095_6094 a b) ∨ (fact_366edf150095_6619 a b) ∨ (fact_366edf150095_6624 a b) ∨ (((((7 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((7 : Int) + a)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b))) ∨ (((7 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((7 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((4 : Int) + b) - b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((4 : Int) + b) + (0 : Int))))))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h4
  clear h4
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n208_run_empty (a b run_x : Int)
    (h0 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2319 a b run_x) ∨ (fact_366edf150095_3537 a b run_x) ∨ (fact_366edf150095_2995 a b run_x) ∨ (fact_366edf150095_2334 a b run_x) ∨ (fact_366edf150095_3018 a b run_x) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((3 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + b))) ∨ (((7 : Int) ≤ run_x) ∧ ((7 : Int) ≥ run_x) ∧ ((3 : Int) ≥ (((4 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((4 : Int) + b) + (0 : Int)))))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h5 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n208_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3315 a b run_x) ∨ (fact_366edf150095_5230 a b run_x) ∨ (fact_366edf150095_3578 a b run_x) ∨ (fact_366edf150095_3334 a b run_x) ∨ (fact_366edf150095_3603 a b run_x) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + a)) ∧ (((4 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((7 : Int) ≤ run_x) ∧ ((7 : Int) ≥ run_x) ∧ ((((4 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h1 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h2 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((3 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n209_run_four (a b : Int)
    (h0 : (¬ ((6 : Int) ≤ ((5 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n209_run_short (a b : Int)
    (h0 : (¬ ((((5 : Int) + b) - (6 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n209_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n209_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_3506 a b) ∨ (fact_366edf150095_3455 a b) ∨ (fact_366edf150095_5782 a b) ∨ (fact_366edf150095_5790 a b) ∨ (fact_366edf150095_3463 a b) ∨ (fact_366edf150095_3701 a b) ∨ (fact_366edf150095_3468 a b) ∨ (fact_366edf150095_5795 a b) ∨ (fact_366edf150095_3973 a b) ∨ (fact_366edf150095_3472 a b) ∨ (((((5 : Int) - b) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((5 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((5 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3710 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n209_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4130 a b) ∨ (fact_366edf150095_3725 a b) ∨ (fact_366edf150095_5876 a b) ∨ (fact_366edf150095_5959 a b) ∨ (fact_366edf150095_3806 a b) ∨ (fact_366edf150095_4239 a b) ∨ (fact_366edf150095_3877 a b) ∨ (fact_366edf150095_6030 a b) ∨ (((((3 : Int) - b) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3976 a b) ∨ (((((5 : Int) - b) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((5 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4395 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n209_run_tall (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + b) - b)) ∨ ((((6 : Int) + b) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : (¬ (((((6 : Int) + (3 : Int)) ≤ ((5 : Int) + b)) ∧ ((fact_366edf150095_7608 a b) ∨ (fact_366edf150095_7671 a b))) ∨ ((((6 : Int) + (2 : Int)) ≤ ((5 : Int) + b)) ∧ (fact_366edf150095_7608 a b) ∧ (fact_366edf150095_7671 a b)) ∨ (((6 : Int) + (4 : Int)) ≤ ((5 : Int) + b)) ∨ ((((5 : Int) + b) = ((6 : Int) + (1 : Int))) ∧ (fact_366edf150095_7608 a b) ∧ (fact_366edf150095_7671 a b) ∧ (((fact_366edf150095_4175 a b) ∨ (fact_366edf150095_3770 a b) ∨ (fact_366edf150095_5921 a b) ∨ (fact_366edf150095_6004 a b) ∨ (fact_366edf150095_3851 a b) ∨ (fact_366edf150095_4284 a b) ∨ (fact_366edf150095_3904 a b) ∨ (fact_366edf150095_6056 a b) ∨ (fact_366edf150095_4818 a b) ∨ (fact_366edf150095_4006 a b) ∨ (fact_366edf150095_5031 a b) ∨ (fact_366edf150095_4398 a b)) ∨ ((fact_366edf150095_5153 a b) ∨ (fact_366edf150095_4447 a b) ∨ (fact_366edf150095_6372 a b) ∨ (fact_366edf150095_6460 a b) ∨ (fact_366edf150095_4531 a b) ∨ (fact_366edf150095_5281 a b) ∨ (fact_366edf150095_4606 a b) ∨ (fact_366edf150095_6531 a b) ∨ (fact_366edf150095_5546 a b) ∨ (fact_366edf150095_4866 a b) ∨ (fact_366edf150095_5694 a b) ∨ (fact_366edf150095_5412 a b)))) ∨ ((fact_366edf150095_7608 a b) ∧ (fact_366edf150095_7671 a b) ∧ ((fact_366edf150095_4175 a b) ∨ (fact_366edf150095_3770 a b) ∨ (fact_366edf150095_5921 a b) ∨ (fact_366edf150095_6004 a b) ∨ (fact_366edf150095_3851 a b) ∨ (fact_366edf150095_4284 a b) ∨ (fact_366edf150095_3904 a b) ∨ (fact_366edf150095_6056 a b) ∨ (fact_366edf150095_4818 a b) ∨ (fact_366edf150095_4006 a b) ∨ (fact_366edf150095_5031 a b) ∨ (fact_366edf150095_4398 a b)) ∧ ((fact_366edf150095_5153 a b) ∨ (fact_366edf150095_4447 a b) ∨ (fact_366edf150095_6372 a b) ∨ (fact_366edf150095_6460 a b) ∨ (fact_366edf150095_4531 a b) ∨ (fact_366edf150095_5281 a b) ∨ (fact_366edf150095_4606 a b) ∨ (fact_366edf150095_6531 a b) ∨ (fact_366edf150095_5546 a b) ∨ (fact_366edf150095_4866 a b) ∨ (fact_366edf150095_5694 a b) ∨ (fact_366edf150095_5412 a b))))))
    (h3 : (a > b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n209_run_empty (a b run_x : Int)
    (h0 : ((fact_366edf150095_2377 a b run_x) ∨ (fact_366edf150095_2312 a b run_x) ∨ (fact_366edf150095_3520 a b run_x) ∨ (fact_366edf150095_3535 a b run_x) ∨ (fact_366edf150095_2317 a b run_x) ∨ (fact_366edf150095_2959 a b run_x) ∨ (fact_366edf150095_2321 a b run_x) ∨ (fact_366edf150095_3539 a b run_x) ∨ (fact_366edf150095_2999 a b run_x) ∨ (fact_366edf150095_2335 a b run_x) ∨ (((((5 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_2976 a b run_x)))
    (h1 : ((6 : Int) ≤ run_x))
    (h2 : (run_x ≤ ((5 : Int) + b)))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + b) - b)) ∨ ((((6 : Int) + b) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n209_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3351 a b run_x) ∨ (fact_366edf150095_3300 a b run_x) ∨ (fact_366edf150095_5215 a b run_x) ∨ (fact_366edf150095_5225 a b run_x) ∨ (fact_366edf150095_3310 a b run_x) ∨ (fact_366edf150095_3530 a b run_x) ∨ (fact_366edf150095_3317 a b run_x) ∨ (fact_366edf150095_5232 a b run_x) ∨ (fact_366edf150095_3580 a b run_x) ∨ (fact_366edf150095_3335 a b run_x) ∨ (((((5 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3556 a b run_x))))
    (h1 : ((6 : Int) ≤ run_x))
    (h2 : (run_x ≤ ((5 : Int) + b)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n210_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ ((2 : Int) + ((2 : Int) * b)))))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n210_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + ((2 : Int) * b)) - ((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) < b)))
    (h1 : (a > b))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n210_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n210_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_6949 a b) ∨ (fact_366edf150095_6921 a b) ∨ (fact_366edf150095_7263 a b) ∨ (fact_366edf150095_7265 a b) ∨ (fact_366edf150095_6923 a b) ∨ (fact_366edf150095_6974 a b) ∨ (fact_366edf150095_6924 a b) ∨ (fact_366edf150095_7266 a b) ∨ (fact_366edf150095_6989 a b) ∨ (fact_366edf150095_6930 a b) ∨ (fact_366edf150095_6995 a b) ∨ ((((((6 : Int) + a) - a) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((6 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ ((((6 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b)))))))
    (h1 : ((((1 : Int) + ((2 : Int) * a)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n210_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_5830 a b) ∨ (fact_366edf150095_5796 a b) ∨ (fact_366edf150095_6942 a b) ∨ (fact_366edf150095_6944 a b) ∨ (fact_366edf150095_5798 a b) ∨ (fact_366edf150095_5944 a b) ∨ (fact_366edf150095_5800 a b) ∨ (fact_366edf150095_6946 a b) ∨ (fact_366edf150095_6090 a b) ∨ (fact_366edf150095_5804 a b) ∨ (fact_366edf150095_6108 a b) ∨ (fact_366edf150095_6067 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n210_run_tall (a b : Int)
    (h0 : (¬ ((((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7169 a b) ∨ (fact_366edf150095_7149 a b)) ∨ (fact_366edf150095_7775 a b))) ∨ (((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (2 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7169 a b) ∨ (fact_366edf150095_7149 a b)) ∧ (fact_366edf150095_7775 a b)) ∨ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∨ ((((2 : Int) + ((2 : Int) * b)) = (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7169 a b) ∨ (fact_366edf150095_7149 a b)) ∧ (fact_366edf150095_7775 a b) ∧ (((fact_366edf150095_7023 a b) ∨ (fact_366edf150095_6979 a b) ∨ (fact_366edf150095_7281 a b) ∨ (fact_366edf150095_7285 a b) ∨ (fact_366edf150095_6983 a b) ∨ (fact_366edf150095_7095 a b) ∨ (fact_366edf150095_6985 a b) ∨ (fact_366edf150095_7287 a b) ∨ (fact_366edf150095_7160 a b) ∨ (fact_366edf150095_6992 a b) ∨ (fact_366edf150095_7168 a b) ∨ (fact_366edf150095_7148 a b)) ∨ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6597 a b) ∨ (fact_366edf150095_6094 a b) ∨ (fact_366edf150095_6619 a b) ∨ (fact_366edf150095_6558 a b)))) ∨ (((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7169 a b) ∨ (fact_366edf150095_7149 a b)) ∧ (fact_366edf150095_7775 a b) ∧ ((fact_366edf150095_7023 a b) ∨ (fact_366edf150095_6979 a b) ∨ (fact_366edf150095_7281 a b) ∨ (fact_366edf150095_7285 a b) ∨ (fact_366edf150095_6983 a b) ∨ (fact_366edf150095_7095 a b) ∨ (fact_366edf150095_6985 a b) ∨ (fact_366edf150095_7287 a b) ∨ (fact_366edf150095_7160 a b) ∨ (fact_366edf150095_6992 a b) ∨ (fact_366edf150095_7168 a b) ∨ (fact_366edf150095_7148 a b)) ∧ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6597 a b) ∨ (fact_366edf150095_6094 a b) ∨ (fact_366edf150095_6619 a b) ∨ (fact_366edf150095_6558 a b))))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a > b))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n210_run_empty (a b run_x : Int)
    (h0 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2319 a b run_x) ∨ (fact_366edf150095_3537 a b run_x) ∨ (fact_366edf150095_2995 a b run_x) ∨ (fact_366edf150095_2334 a b run_x) ∨ (fact_366edf150095_3018 a b run_x) ∨ (fact_366edf150095_2974 a b run_x)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n210_run_floor (a b run_x : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3315 a b run_x) ∨ (fact_366edf150095_5230 a b run_x) ∨ (fact_366edf150095_3578 a b run_x) ∨ (fact_366edf150095_3334 a b run_x) ∨ (fact_366edf150095_3603 a b run_x) ∨ (fact_366edf150095_3554 a b run_x))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h5 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n211_point (a b : Int)
    (h0 : (fact_366edf150095_4 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n211_empty (a b : Int)
    (h0 : (((-1 : Int) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((-1 : Int) > (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((1 : Int) + ((2 : Int) * a)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h3 : ((fact_366edf150095_3226 a b) ∨ (fact_366edf150095_3132 a b) ∨ (fact_366edf150095_4222 a b) ∨ (fact_366edf150095_4311 a b) ∨ (fact_366edf150095_3140 a b) ∨ (fact_366edf150095_3357 a b) ∨ (fact_366edf150095_3145 a b) ∨ (fact_366edf150095_4317 a b) ∨ (fact_366edf150095_3405 a b) ∨ (fact_366edf150095_3154 a b) ∨ (((((5 : Int) - b) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((5 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) + a))) ∨ (((5 : Int) ≤ ((5 : Int) + b)) ∧ ((5 : Int) ≥ ((5 : Int) + b)) ∧ ((3 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((6 : Int) + b)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((6 : Int) ≤ ((5 : Int) + b)) ∧ ((6 : Int) ≥ ((5 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + a))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((0 : Int) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((0 : Int) > (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h6 : ((((2 : Int) * a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h7 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n211_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((5 : Int) > jx) ∨ ((5 : Int) < jx) ∨ ((jy + b) < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h2 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h3 : (fact_366edf150095_1828 a b jx jy))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n211_o1 (a b jx jy : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (fact_366edf150095_1835 a b jx jy))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n211_o2 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1855 a b jx jy))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n211_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : (fact_366edf150095_1870 a b jx jy))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((jx + (0 : Int)) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - b)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n211_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_366edf150095_1871 a b jx jy))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n211_o5 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (((jx + (0 : Int)) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (fact_366edf150095_1854 a b jx jy))
    (h6 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h7 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - a)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n211_o6 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (fact_366edf150095_1834 a b jx jy))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n211_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (fact_366edf150095_1829 a b jx jy))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n212_run_four (a b : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (¬ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ ((2 : Int) + ((2 : Int) * b)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n212_run_short (a b : Int)
    (h0 : (a > b))
    (h1 : (¬ ((((2 : Int) + ((2 : Int) * b)) - ((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n212_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n212_run_left (a b : Int)
    (h0 : ((((2 : Int) * a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (¬ ((fact_366edf150095_6949 a b) ∨ (fact_366edf150095_6921 a b) ∨ (fact_366edf150095_7263 a b) ∨ (fact_366edf150095_7265 a b) ∨ (fact_366edf150095_6923 a b) ∨ (fact_366edf150095_6974 a b) ∨ (fact_366edf150095_6924 a b) ∨ (fact_366edf150095_7266 a b) ∨ (fact_366edf150095_6989 a b) ∨ (fact_366edf150095_6930 a b) ∨ (fact_366edf150095_6995 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + b))) ∨ (((6 : Int) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((6 : Int) ≥ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n212_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5830 a b) ∨ (fact_366edf150095_5796 a b) ∨ (fact_366edf150095_6942 a b) ∨ (fact_366edf150095_6944 a b) ∨ (fact_366edf150095_5798 a b) ∨ (fact_366edf150095_5944 a b) ∨ (fact_366edf150095_5800 a b) ∨ (fact_366edf150095_6946 a b) ∨ (fact_366edf150095_6090 a b) ∨ (fact_366edf150095_5804 a b) ∨ (fact_366edf150095_6108 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + b))) ∨ (((6 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((6 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n212_run_tall (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (¬ ((((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7169 a b) ∨ (fact_366edf150095_7173 a b)) ∨ (fact_366edf150095_7776 a b))) ∨ (((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (2 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7169 a b) ∨ (fact_366edf150095_7173 a b)) ∧ (fact_366edf150095_7776 a b)) ∨ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∨ ((((2 : Int) + ((2 : Int) * b)) = (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7169 a b) ∨ (fact_366edf150095_7173 a b)) ∧ (fact_366edf150095_7776 a b) ∧ (((fact_366edf150095_7023 a b) ∨ (fact_366edf150095_6979 a b) ∨ (fact_366edf150095_7281 a b) ∨ (fact_366edf150095_7285 a b) ∨ (fact_366edf150095_6983 a b) ∨ (fact_366edf150095_7095 a b) ∨ (fact_366edf150095_6985 a b) ∨ (fact_366edf150095_7287 a b) ∨ (fact_366edf150095_7160 a b) ∨ (fact_366edf150095_6992 a b) ∨ (fact_366edf150095_7168 a b) ∨ (fact_366edf150095_7172 a b)) ∨ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6597 a b) ∨ (fact_366edf150095_6094 a b) ∨ (fact_366edf150095_6619 a b) ∨ (fact_366edf150095_6621 a b)))) ∨ (((fact_366edf150095_7024 a b) ∨ (fact_366edf150095_6980 a b) ∨ (fact_366edf150095_7282 a b) ∨ (fact_366edf150095_7286 a b) ∨ (fact_366edf150095_6984 a b) ∨ (fact_366edf150095_7096 a b) ∨ (fact_366edf150095_6986 a b) ∨ (fact_366edf150095_7288 a b) ∨ (fact_366edf150095_7161 a b) ∨ (fact_366edf150095_6993 a b) ∨ (fact_366edf150095_7169 a b) ∨ (fact_366edf150095_7173 a b)) ∧ (fact_366edf150095_7776 a b) ∧ ((fact_366edf150095_7023 a b) ∨ (fact_366edf150095_6979 a b) ∨ (fact_366edf150095_7281 a b) ∨ (fact_366edf150095_7285 a b) ∨ (fact_366edf150095_6983 a b) ∨ (fact_366edf150095_7095 a b) ∨ (fact_366edf150095_6985 a b) ∨ (fact_366edf150095_7287 a b) ∨ (fact_366edf150095_7160 a b) ∨ (fact_366edf150095_6992 a b) ∨ (fact_366edf150095_7168 a b) ∨ (fact_366edf150095_7172 a b)) ∧ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6597 a b) ∨ (fact_366edf150095_6094 a b) ∨ (fact_366edf150095_6619 a b) ∨ (fact_366edf150095_6621 a b))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n212_run_empty (a b run_x : Int)
    (h0 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2319 a b run_x) ∨ (fact_366edf150095_3537 a b run_x) ∨ (fact_366edf150095_2995 a b run_x) ∨ (fact_366edf150095_2334 a b run_x) ∨ (fact_366edf150095_3018 a b run_x) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + b))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((3 : Int) ≥ (((4 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((4 : Int) + b) + (0 : Int)))))))
    (h1 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h2 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n212_run_floor (a b run_x : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h2 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h4 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3315 a b run_x) ∨ (fact_366edf150095_5230 a b run_x) ∨ (fact_366edf150095_3578 a b run_x) ∨ (fact_366edf150095_3334 a b run_x) ∨ (fact_366edf150095_3603 a b run_x) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ (((4 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((((4 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h4
  clear h4
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n213_point (a b : Int)
    (h0 : (fact_366edf150095_4 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n213_empty (a b : Int)
    (h0 : ((((1 : Int) + ((2 : Int) * a)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h1 : (((0 : Int) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((0 : Int) > (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h2 : (((-1 : Int) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((-1 : Int) > (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h5 : ((fact_366edf150095_3226 a b) ∨ (fact_366edf150095_3132 a b) ∨ (fact_366edf150095_4222 a b) ∨ (fact_366edf150095_4311 a b) ∨ (fact_366edf150095_3140 a b) ∨ (fact_366edf150095_3357 a b) ∨ (fact_366edf150095_3145 a b) ∨ (fact_366edf150095_4317 a b) ∨ (fact_366edf150095_3405 a b) ∨ (fact_366edf150095_3154 a b) ∨ ((((((5 : Int) + a) - a) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ ((((5 : Int) + a) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b))))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((((2 : Int) * a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n213_o0 (a b jx jy : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((jx + a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - (0 : Int))) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h5 : (fact_366edf150095_1828 a b jx jy))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n213_o1 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1835 a b jx jy))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n213_o2 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_366edf150095_1855 a b jx jy))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n213_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h3 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h4 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h7 : (((jx + (0 : Int)) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h8 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h9 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h10 : (fact_366edf150095_1870 a b jx jy))
    (h11 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - b)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h12 : (a = (b + (2 : Int))))
    (h13 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h14 : (a ≥ (5 : Int)))
    (h15 : (a ≥ b))
    (h16 : (a > b))
    (h17 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n213_o4 (a b jx jy : Int)
    (h0 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_366edf150095_1871 a b jx jy))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n213_o5 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - a)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h1 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h2 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (fact_366edf150095_1854 a b jx jy))
    (h8 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h9 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h10 : (((jx + (0 : Int)) < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h11 : (a = (b + (2 : Int))))
    (h12 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h13 : (a ≥ (5 : Int)))
    (h14 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h15 : (a ≥ b))
    (h16 : (a > b))
    (h17 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n213_o6 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1834 a b jx jy))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h6 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n213_o7 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1829 a b jx jy))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (((jx + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n214_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_366edf150095_4 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n214_empty (a b : Int)
    (h0 : ((((1 : Int) + ((2 : Int) * a)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h1 : (((-1 : Int) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((-1 : Int) > (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((2 : Int) * a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h5 : (((0 : Int) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((0 : Int) > (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h6 : ((fact_366edf150095_3226 a b) ∨ (fact_366edf150095_3132 a b) ∨ (fact_366edf150095_4222 a b) ∨ (fact_366edf150095_4311 a b) ∨ (fact_366edf150095_3140 a b) ∨ (fact_366edf150095_3357 a b) ∨ (fact_366edf150095_3145 a b) ∨ (fact_366edf150095_4317 a b) ∨ (fact_366edf150095_3405 a b) ∨ (fact_366edf150095_3154 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ ((5 : Int) + b)) ∧ ((5 : Int) ≥ ((5 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + a))))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n214_o0 (a b jx jy : Int)
    (h0 : (((jx + a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - (0 : Int))) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h1 : (fact_366edf150095_1828 a b jx jy))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h5 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n214_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h2 : (fact_366edf150095_1835 a b jx jy))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n214_o2 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h1 : (fact_366edf150095_1855 a b jx jy))
    (h2 : (fact_366edf150095_2954 a b jy))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n214_o3 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - b)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h5 : (fact_366edf150095_1870 a b jx jy))
    (h6 : (((jx + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n214_o4 (a b jx jy : Int)
    (h0 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (fact_366edf150095_1871 a b jx jy))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n214_o5 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - a)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h3 : (((jx + (0 : Int)) < (((1 : Int) + ((2 : Int) * a)) - a)) ∨ ((((1 : Int) + ((2 : Int) * a)) + (0 : Int)) < (jx - a)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (((jx + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (fact_366edf150095_1854 a b jx jy))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n214_o6 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_366edf150095_1834 a b jx jy))
    (h2 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n214_o7 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (fact_366edf150095_2955 a b jy))
    (h3 : (fact_366edf150095_1829 a b jx jy))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n215_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n215_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((1 : Int) + a) - (4 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n215_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n215_run_left (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_366edf150095_3512 a b) ∨ (fact_366edf150095_3482 a b) ∨ (fact_366edf150095_5817 a b) ∨ (fact_366edf150095_5819 a b) ∨ (fact_366edf150095_3484 a b) ∨ (fact_366edf150095_4084 a b) ∨ (fact_366edf150095_3485 a b) ∨ (fact_366edf150095_5820 a b) ∨ ((((6 : Int) ≥ ((3 : Int) - b)) ∧ ((6 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((((3 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3487 a b) ∨ (fact_366edf150095_4095 a b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n215_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (¬ ((fact_366edf150095_4209 a b) ∨ (fact_366edf150095_4090 a b) ∨ (fact_366edf150095_6120 a b) ∨ (fact_366edf150095_6121 a b) ∨ (fact_366edf150095_4091 a b) ∨ (fact_366edf150095_5103 a b) ∨ (fact_366edf150095_4092 a b) ∨ (fact_366edf150095_6122 a b) ∨ ((((6 : Int) ≥ ((3 : Int) - b)) ∧ ((6 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((((3 : Int) + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_366edf150095_5105 a b))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n215_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_366edf150095_7509 a b) ∨ (fact_366edf150095_7583 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ (fact_366edf150095_7509 a b) ∧ (fact_366edf150095_7583 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = ((4 : Int) + (1 : Int))) ∧ (fact_366edf150095_7509 a b) ∧ (fact_366edf150095_7583 a b) ∧ (((fact_366edf150095_4165 a b) ∨ (fact_366edf150095_3760 a b) ∨ (fact_366edf150095_5911 a b) ∨ (fact_366edf150095_5994 a b) ∨ (fact_366edf150095_3841 a b) ∨ (fact_366edf150095_4274 a b) ∨ (fact_366edf150095_3897 a b) ∨ (fact_366edf150095_6049 a b) ∨ (fact_366edf150095_4803 a b) ∨ (fact_366edf150095_3993 a b) ∨ (fact_366edf150095_4995 a b)) ∨ ((fact_366edf150095_5180 a b) ∨ (fact_366edf150095_4474 a b) ∨ (fact_366edf150095_6399 a b) ∨ (fact_366edf150095_6487 a b) ∨ (fact_366edf150095_4558 a b) ∨ (fact_366edf150095_5308 a b) ∨ (fact_366edf150095_4621 a b) ∨ (fact_366edf150095_6540 a b) ∨ (fact_366edf150095_5556 a b) ∨ (fact_366edf150095_4897 a b) ∨ (fact_366edf150095_5677 a b)))) ∨ ((fact_366edf150095_7509 a b) ∧ (fact_366edf150095_7583 a b) ∧ ((fact_366edf150095_4165 a b) ∨ (fact_366edf150095_3760 a b) ∨ (fact_366edf150095_5911 a b) ∨ (fact_366edf150095_5994 a b) ∨ (fact_366edf150095_3841 a b) ∨ (fact_366edf150095_4274 a b) ∨ (fact_366edf150095_3897 a b) ∨ (fact_366edf150095_6049 a b) ∨ (fact_366edf150095_4803 a b) ∨ (fact_366edf150095_3993 a b) ∨ (fact_366edf150095_4995 a b)) ∧ ((fact_366edf150095_5180 a b) ∨ (fact_366edf150095_4474 a b) ∨ (fact_366edf150095_6399 a b) ∨ (fact_366edf150095_6487 a b) ∨ (fact_366edf150095_4558 a b) ∨ (fact_366edf150095_5308 a b) ∨ (fact_366edf150095_4621 a b) ∨ (fact_366edf150095_6540 a b) ∨ (fact_366edf150095_5556 a b) ∨ (fact_366edf150095_4897 a b) ∨ (fact_366edf150095_5677 a b))))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n215_run_empty (a b run_x : Int)
    (h0 : ((4 : Int) ≤ run_x))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((fact_366edf150095_2381 a b run_x) ∨ (fact_366edf150095_2347 a b run_x) ∨ (fact_366edf150095_3622 a b run_x) ∨ (fact_366edf150095_3623 a b run_x) ∨ (fact_366edf150095_2348 a b run_x) ∨ (fact_366edf150095_3045 a b run_x) ∨ (fact_366edf150095_2349 a b run_x) ∨ (fact_366edf150095_3624 a b run_x) ∨ (fact_366edf150095_3048 a b run_x) ∨ (fact_366edf150095_2351 a b run_x) ∨ (fact_366edf150095_3051 a b run_x)))
    (h3 : (run_x ≤ ((1 : Int) + a)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n215_run_floor (a b run_x : Int)
    (h0 : ((4 : Int) ≤ run_x))
    (h1 : (run_x ≤ ((1 : Int) + a)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (¬ ((fact_366edf150095_3345 a b run_x) ∨ (fact_366edf150095_3294 a b run_x) ∨ (fact_366edf150095_5209 a b run_x) ∨ (fact_366edf150095_5219 a b run_x) ∨ (fact_366edf150095_3304 a b run_x) ∨ (fact_366edf150095_3524 a b run_x) ∨ (fact_366edf150095_3313 a b run_x) ∨ (fact_366edf150095_5228 a b run_x) ∨ (fact_366edf150095_3573 a b run_x) ∨ (fact_366edf150095_3328 a b run_x) ∨ (fact_366edf150095_3596 a b run_x))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n216_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((3 : Int) ≤ a)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n216_run_short (a b : Int)
    (h0 : (¬ ((a - (3 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n216_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n216_run_left (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_366edf150095_3509 a b) ∨ (fact_366edf150095_3476 a b) ∨ (fact_366edf150095_5811 a b) ∨ (fact_366edf150095_5813 a b) ∨ (fact_366edf150095_3478 a b) ∨ (fact_366edf150095_4068 a b) ∨ ((((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((5 : Int) ≥ (((3 : Int) + ((2 : Int) * b)) - b)) ∧ ((5 : Int) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((5 : Int) ≥ ((3 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((5 : Int) ≥ ((3 : Int) - b)) ∧ ((5 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((((3 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4078 a b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n216_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3235 a b) ∨ (fact_366edf150095_3183 a b) ∨ (fact_366edf150095_5098 a b) ∨ (fact_366edf150095_5100 a b) ∨ (fact_366edf150095_3184 a b) ∨ (fact_366edf150095_3430 a b) ∨ ((((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ (((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((5 : Int) ≥ (((3 : Int) + ((2 : Int) * b)) - b)) ∧ ((5 : Int) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ (((5 : Int) ≥ ((3 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((5 : Int) ≥ ((3 : Int) - b)) ∧ ((5 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((((3 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3431 a b))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n216_run_tall (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_366edf150095_7426 a b) ∨ (fact_366edf150095_7358 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_366edf150095_7426 a b) ∧ (fact_366edf150095_7358 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_366edf150095_7426 a b) ∧ (fact_366edf150095_7358 a b) ∧ (((fact_366edf150095_4150 a b) ∨ (fact_366edf150095_3745 a b) ∨ (fact_366edf150095_5896 a b) ∨ (fact_366edf150095_5979 a b) ∨ (fact_366edf150095_3826 a b) ∨ (fact_366edf150095_4259 a b) ∨ (fact_366edf150095_3886 a b) ∨ (fact_366edf150095_6038 a b) ∨ (((((3 : Int) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((((3 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4877 a b)) ∨ ((fact_366edf150095_3440 a b) ∨ (fact_366edf150095_3364 a b) ∨ (fact_366edf150095_5236 a b) ∨ (fact_366edf150095_5331 a b) ∨ (fact_366edf150095_3375 a b) ∨ (fact_366edf150095_3632 a b) ∨ (fact_366edf150095_3385 a b) ∨ (fact_366edf150095_5341 a b) ∨ (((((3 : Int) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((((3 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3678 a b)))) ∨ ((fact_366edf150095_7426 a b) ∧ (fact_366edf150095_7358 a b) ∧ ((fact_366edf150095_4150 a b) ∨ (fact_366edf150095_3745 a b) ∨ (fact_366edf150095_5896 a b) ∨ (fact_366edf150095_5979 a b) ∨ (fact_366edf150095_3826 a b) ∨ (fact_366edf150095_4259 a b) ∨ (fact_366edf150095_3886 a b) ∨ (fact_366edf150095_6038 a b) ∨ (((((3 : Int) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((((3 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4877 a b)) ∧ ((fact_366edf150095_3440 a b) ∨ (fact_366edf150095_3364 a b) ∨ (fact_366edf150095_5236 a b) ∨ (fact_366edf150095_5331 a b) ∨ (fact_366edf150095_3375 a b) ∨ (fact_366edf150095_3632 a b) ∨ (fact_366edf150095_3385 a b) ∨ (fact_366edf150095_5341 a b) ∨ (((((3 : Int) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((((3 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3678 a b))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (a > b))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n216_run_empty (a b run_x : Int)
    (h0 : (run_x ≤ a))
    (h1 : ((3 : Int) ≤ run_x))
    (h2 : ((fact_366edf150095_2380 a b run_x) ∨ (fact_366edf150095_2344 a b run_x) ∨ (fact_366edf150095_3619 a b run_x) ∨ (fact_366edf150095_3620 a b run_x) ∨ (fact_366edf150095_2345 a b run_x) ∨ (fact_366edf150095_3040 a b run_x) ∨ (fact_366edf150095_2346 a b run_x) ∨ (fact_366edf150095_3621 a b run_x) ∨ ((((5 : Int) ≥ ((3 : Int) - b)) ∧ ((5 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3043 a b run_x)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n216_run_floor (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((3 : Int) ≤ run_x))
    (h2 : (¬ ((fact_366edf150095_3344 a b run_x) ∨ (fact_366edf150095_3293 a b run_x) ∨ (fact_366edf150095_5208 a b run_x) ∨ (fact_366edf150095_5218 a b run_x) ∨ (fact_366edf150095_3303 a b run_x) ∨ (fact_366edf150095_3523 a b run_x) ∨ (fact_366edf150095_3312 a b run_x) ∨ (fact_366edf150095_5227 a b run_x) ∨ (((((3 : Int) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3582 a b run_x))))
    (h3 : (run_x ≤ a))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n217_point (a b : Int)
    (h0 : (¬ (((3 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((3 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n217_empty (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((((3 : Int) ≥ ((-1 : Int) - a)) ∧ ((3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-1 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((3 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((3 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((3 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((3 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((3 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((3 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((3 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((3 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ ((((3 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((3 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((3 : Int) ≥ ((2 : Int) * a)) ∧ ((3 : Int) ≤ ((2 : Int) * a)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)))) ∨ ((((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ ((((3 : Int) ≥ (((3 : Int) + ((2 : Int) * b)) - b)) ∧ ((3 : Int) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((3 : Int) ≥ ((3 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ ((((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + b))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n217_o0 (a b jx jy : Int)
    (h0 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h6 : (((jx + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n217_o1 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h3 : (¬ ((((3 : Int) = jx) ∧ (jy = ((4 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n217_o2 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n217_o3 (a b jx jy : Int)
    (h0 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h1 : (¬ (((jx = ((3 : Int) + b)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h5 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n217_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h3 : (¬ ((((3 : Int) = jx) ∧ (jy = ((4 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h4 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n217_o5 (a b jx jy : Int)
    (h0 : ((jx < ((3 : Int) + a)) ∨ (((3 : Int) + a) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h1 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h2 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h5 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((jx + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jx - a)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n217_o6 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (¬ ((((3 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h5 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h6 : (a ≥ b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n217_o7 (a b jx jy : Int)
    (h0 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h1 : (((jx + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h4 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (¬ ((((3 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n218_point (a b : Int)
    (h0 : (¬ (((4 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n218_empty (a b : Int)
    (h0 : ((fact_366edf150095_2903 a b) ∨ (fact_366edf150095_2572 a b) ∨ (fact_366edf150095_4059 a b) ∨ (fact_366edf150095_4062 a b) ∨ (fact_366edf150095_2574 a b) ∨ (fact_366edf150095_3173 a b) ∨ (fact_366edf150095_2575 a b) ∨ (fact_366edf150095_4063 a b) ∨ ((((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + b)))) ∨ ((((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≥ ((4 : Int) + a)) ∧ ((4 : Int) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((4 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((4 : Int) + a) + (0 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n218_o0 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : (((jx + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n218_o1 (a b jx jy : Int)
    (h0 : (((jx + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) + a)) ∨ (((4 : Int) + a) < jy)))
    (h1 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n218_o2 (a b jx jy : Int)
    (h0 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_366edf150095_2954 a b jy))
    (h4 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - b))))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h7 : ((jy - b) ≥ (0 : Int)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n218_o3 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (¬ (((jx = ((4 : Int) + b)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n218_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n218_o5 (a b jx jy : Int)
    (h0 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((jx + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h3 : (((jx + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jx - a)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h4 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n218_o6 (a b jx jy : Int)
    (h0 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + a) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n218_o7 (a b jx jy : Int)
    (h0 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h1 : (¬ ((((4 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h5 : (((jx + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n219_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)))))
    (h1 : ((((2 : Int) * a) < (((4 : Int) + b) - b)) ∨ ((((4 : Int) + b) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n219_run_short (a b : Int)
    (h0 : (¬ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (4 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n219_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n219_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_3501 a b) ∨ (fact_366edf150095_3450 a b) ∨ (fact_366edf150095_5777 a b) ∨ (fact_366edf150095_5785 a b) ∨ (fact_366edf150095_3458 a b) ∨ (fact_366edf150095_3696 a b) ∨ (fact_366edf150095_3465 a b) ∨ (fact_366edf150095_5792 a b) ∨ ((((((3 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3706 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n219_run_right (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (¬ ((fact_366edf150095_6963 a b) ∨ (fact_366edf150095_6951 a b) ∨ (fact_366edf150095_7268 a b) ∨ (fact_366edf150095_7270 a b) ∨ (fact_366edf150095_6953 a b) ∨ (fact_366edf150095_7009 a b) ∨ (fact_366edf150095_6954 a b) ∨ (fact_366edf150095_7275 a b) ∨ ((((((3 : Int) + a) - a) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_7020 a b))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n219_run_tall (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) ∧ ((fact_366edf150095_7510 a b) ∨ (fact_366edf150095_7829 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) ∧ (fact_366edf150095_7510 a b) ∧ (fact_366edf150095_7829 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) ∨ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) = ((4 : Int) + (1 : Int))) ∧ (fact_366edf150095_7510 a b) ∧ (fact_366edf150095_7829 a b) ∧ (((fact_366edf150095_4146 a b) ∨ (fact_366edf150095_3741 a b) ∨ (fact_366edf150095_5892 a b) ∨ (fact_366edf150095_5975 a b) ∨ (fact_366edf150095_3822 a b) ∨ (fact_366edf150095_4255 a b) ∨ (fact_366edf150095_3883 a b) ∨ (fact_366edf150095_6035 a b) ∨ (fact_366edf150095_4331 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4378 a b)) ∨ ((fact_366edf150095_7058 a b) ∨ (fact_366edf150095_7027 a b) ∨ (fact_366edf150095_7291 a b) ∨ (fact_366edf150095_7296 a b) ∨ (fact_366edf150095_7032 a b) ∨ (fact_366edf150095_7186 a b) ∨ (fact_366edf150095_7035 a b) ∨ (fact_366edf150095_7299 a b) ∨ (fact_366edf150095_7193 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a))) ∨ (fact_366edf150095_2924 a b)) ∨ (fact_366edf150095_7202 a b)))) ∨ ((fact_366edf150095_7510 a b) ∧ (fact_366edf150095_7829 a b) ∧ ((fact_366edf150095_4146 a b) ∨ (fact_366edf150095_3741 a b) ∨ (fact_366edf150095_5892 a b) ∨ (fact_366edf150095_5975 a b) ∨ (fact_366edf150095_3822 a b) ∨ (fact_366edf150095_4255 a b) ∨ (fact_366edf150095_3883 a b) ∨ (fact_366edf150095_6035 a b) ∨ (fact_366edf150095_4331 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4378 a b)) ∧ ((fact_366edf150095_7058 a b) ∨ (fact_366edf150095_7027 a b) ∨ (fact_366edf150095_7291 a b) ∨ (fact_366edf150095_7296 a b) ∨ (fact_366edf150095_7032 a b) ∨ (fact_366edf150095_7186 a b) ∨ (fact_366edf150095_7035 a b) ∨ (fact_366edf150095_7299 a b) ∨ (fact_366edf150095_7193 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a))) ∨ (fact_366edf150095_2924 a b)) ∨ (fact_366edf150095_7202 a b))))))
    (h3 : (a > b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n219_run_empty (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((4 : Int) ≤ run_x))
    (h2 : ((fact_366edf150095_2377 a b run_x) ∨ (fact_366edf150095_2312 a b run_x) ∨ (fact_366edf150095_3520 a b run_x) ∨ (fact_366edf150095_3535 a b run_x) ∨ (fact_366edf150095_2317 a b run_x) ∨ (fact_366edf150095_2959 a b run_x) ∨ (fact_366edf150095_2321 a b run_x) ∨ (fact_366edf150095_3539 a b run_x) ∨ (fact_366edf150095_2965 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_2970 a b run_x)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n219_run_floor (a b run_x : Int)
    (h0 : ((4 : Int) ≤ run_x))
    (h1 : (¬ ((fact_366edf150095_3351 a b run_x) ∨ (fact_366edf150095_3300 a b run_x) ∨ (fact_366edf150095_5215 a b run_x) ∨ (fact_366edf150095_5225 a b run_x) ∨ (fact_366edf150095_3310 a b run_x) ∨ (fact_366edf150095_3530 a b run_x) ∨ (fact_366edf150095_3317 a b run_x) ∨ (fact_366edf150095_5232 a b run_x) ∨ (fact_366edf150095_3545 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3550 a b run_x))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n220_run_four (a b : Int)
    (h0 : (¬ ((5 : Int) ≤ ((2 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n220_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + a) - (5 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n220_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n220_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3503 a b) ∨ (fact_366edf150095_3452 a b) ∨ (fact_366edf150095_5779 a b) ∨ (fact_366edf150095_5787 a b) ∨ (fact_366edf150095_3460 a b) ∨ (fact_366edf150095_3698 a b) ∨ (fact_366edf150095_3466 a b) ∨ (fact_366edf150095_5793 a b) ∨ ((((((3 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≥ ((4 : Int) + a)) ∧ ((4 : Int) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((4 : Int) ≥ ((4 : Int) + b)) ∧ ((4 : Int) ≤ ((4 : Int) + b))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n220_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4118 a b) ∨ (fact_366edf150095_3713 a b) ∨ (fact_366edf150095_5864 a b) ∨ (fact_366edf150095_5947 a b) ∨ (fact_366edf150095_3794 a b) ∨ (fact_366edf150095_4227 a b) ∨ (((((2 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≥ ((4 : Int) + a)) ∧ ((4 : Int) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((4 : Int) ≥ ((4 : Int) + b)) ∧ ((4 : Int) ≤ ((4 : Int) + b))) ∨ (((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n220_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((((5 : Int) + (3 : Int)) ≤ ((2 : Int) + a)) ∧ ((fact_366edf150095_7516 a b) ∨ (fact_366edf150095_7584 a b))) ∨ ((((5 : Int) + (2 : Int)) ≤ ((2 : Int) + a)) ∧ (fact_366edf150095_7516 a b) ∧ (fact_366edf150095_7584 a b)) ∨ (((5 : Int) + (4 : Int)) ≤ ((2 : Int) + a)) ∨ ((((2 : Int) + a) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7516 a b) ∧ (fact_366edf150095_7584 a b) ∧ (((fact_366edf150095_4158 a b) ∨ (fact_366edf150095_3753 a b) ∨ (fact_366edf150095_5904 a b) ∨ (fact_366edf150095_5987 a b) ∨ (fact_366edf150095_3834 a b) ∨ (fact_366edf150095_4267 a b) ∨ (fact_366edf150095_3891 a b) ∨ (fact_366edf150095_6043 a b) ∨ (fact_366edf150095_4341 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4885 a b)) ∨ ((fact_366edf150095_5120 a b) ∨ (fact_366edf150095_4414 a b) ∨ (fact_366edf150095_6339 a b) ∨ (fact_366edf150095_6427 a b) ∨ (fact_366edf150095_4498 a b) ∨ (fact_366edf150095_5248 a b) ∨ (fact_366edf150095_4580 a b) ∨ (fact_366edf150095_6509 a b) ∨ (fact_366edf150095_5351 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5571 a b)))) ∨ ((fact_366edf150095_7516 a b) ∧ (fact_366edf150095_7584 a b) ∧ ((fact_366edf150095_4158 a b) ∨ (fact_366edf150095_3753 a b) ∨ (fact_366edf150095_5904 a b) ∨ (fact_366edf150095_5987 a b) ∨ (fact_366edf150095_3834 a b) ∨ (fact_366edf150095_4267 a b) ∨ (fact_366edf150095_3891 a b) ∨ (fact_366edf150095_6043 a b) ∨ (fact_366edf150095_4341 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4885 a b)) ∧ ((fact_366edf150095_5120 a b) ∨ (fact_366edf150095_4414 a b) ∨ (fact_366edf150095_6339 a b) ∨ (fact_366edf150095_6427 a b) ∨ (fact_366edf150095_4498 a b) ∨ (fact_366edf150095_5248 a b) ∨ (fact_366edf150095_4580 a b) ∨ (fact_366edf150095_6509 a b) ∨ (fact_366edf150095_5351 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5571 a b))))))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n220_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((fact_366edf150095_2376 a b run_x) ∨ (fact_366edf150095_2311 a b run_x) ∨ (fact_366edf150095_3519 a b run_x) ∨ (fact_366edf150095_3534 a b run_x) ∨ (fact_366edf150095_2316 a b run_x) ∨ (fact_366edf150095_2958 a b run_x) ∨ (fact_366edf150095_2320 a b run_x) ∨ (fact_366edf150095_3538 a b run_x) ∨ ((((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≥ ((4 : Int) + a)) ∧ ((4 : Int) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((4 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a)) ∧ ((4 : Int) ≥ ((4 : Int) + b)) ∧ ((4 : Int) ≤ ((4 : Int) + b))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((4 : Int) ≥ (((4 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((4 : Int) + b) + (0 : Int)))))))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h5 : ((5 : Int) ≤ run_x))
    (h6 : (run_x ≤ ((2 : Int) + a)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n220_run_floor (a b run_x : Int)
    (h0 : ((5 : Int) ≤ run_x))
    (h1 : (¬ ((fact_366edf150095_3350 a b run_x) ∨ (fact_366edf150095_3299 a b run_x) ∨ (fact_366edf150095_5214 a b run_x) ∨ (fact_366edf150095_5224 a b run_x) ∨ (fact_366edf150095_3309 a b run_x) ∨ (fact_366edf150095_3529 a b run_x) ∨ (fact_366edf150095_3316 a b run_x) ∨ (fact_366edf150095_5231 a b run_x) ∨ ((((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ ((((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a)) ∧ (((4 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((4 : Int) + b) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h2 : (run_x ≤ ((2 : Int) + a)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n221_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≤ a)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n221_run_short (a b : Int)
    (h0 : (¬ ((a - (3 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n221_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n221_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((((-1 : Int) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)))) ∨ ((((((3 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))) ∧ ((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int))) ∨ ((((3 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n221_run_right (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ ((((((-1 : Int) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (a + (1 : Int))) ∧ ((-1 : Int) ≥ (a + (1 : Int))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (a + (1 : Int))) ∧ ((0 : Int) ≥ (a + (1 : Int))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)))) ∨ ((((((3 : Int) + b) - b) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))) ∧ ((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int))) ∨ ((((3 : Int) + b) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)))))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n221_run_tall (a b : Int)
    (h0 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_366edf150095_7423 a b) ∨ (fact_366edf150095_7359 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_366edf150095_7423 a b) ∧ (fact_366edf150095_7359 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_366edf150095_7423 a b) ∧ (fact_366edf150095_7359 a b) ∧ (((((((-1 : Int) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) + a)) ∧ ((0 : Int) ≥ ((5 : Int) + a))) ∨ (((-1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((5 : Int) + a)) ∧ ((0 : Int) ≥ ((5 : Int) + a))) ∨ (((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) + a)) ∧ ((0 : Int) ≥ ((5 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((5 : Int) + a)) ∧ ((0 : Int) ≥ ((5 : Int) + a))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((5 : Int) + a)) ∧ ((1 : Int) ≥ ((5 : Int) + a))) ∨ (((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((5 : Int) + a)) ∧ ((1 : Int) ≥ ((5 : Int) + a))) ∨ ((((2 : Int) * a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a))) ∨ (((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ ((((3 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b)))) ∨ ((((((3 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))) ∧ ((4 : Int) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≥ ((5 : Int) + a))) ∨ ((((3 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ (((4 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a))))) ∨ ((((((-1 : Int) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) + a)) ∧ ((0 : Int) ≥ ((5 : Int) + a))) ∨ (((-1 : Int) ≤ (a + (1 : Int))) ∧ ((-1 : Int) ≥ (a + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((5 : Int) + a)) ∧ ((0 : Int) ≥ ((5 : Int) + a))) ∨ (((0 : Int) ≤ (a + (1 : Int))) ∧ ((0 : Int) ≥ (a + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) + a)) ∧ ((0 : Int) ≥ ((5 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((5 : Int) + a)) ∧ ((0 : Int) ≥ ((5 : Int) + a))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((5 : Int) + a)) ∧ ((1 : Int) ≥ ((5 : Int) + a))) ∨ (((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((5 : Int) + a)) ∧ ((1 : Int) ≥ ((5 : Int) + a))) ∨ ((((2 : Int) * a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a))) ∨ (((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ ((((3 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b)))) ∨ ((((((3 : Int) + b) - b) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))) ∧ ((4 : Int) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≥ ((5 : Int) + a))) ∨ ((((3 : Int) + b) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + b)) ∧ (((4 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a))))))) ∨ ((fact_366edf150095_7423 a b) ∧ (fact_366edf150095_7359 a b) ∧ ((((((-1 : Int) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) + a)) ∧ ((0 : Int) ≥ ((5 : Int) + a))) ∨ (((-1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((5 : Int) + a)) ∧ ((0 : Int) ≥ ((5 : Int) + a))) ∨ (((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) + a)) ∧ ((0 : Int) ≥ ((5 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((5 : Int) + a)) ∧ ((0 : Int) ≥ ((5 : Int) + a))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((5 : Int) + a)) ∧ ((1 : Int) ≥ ((5 : Int) + a))) ∨ (((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((5 : Int) + a)) ∧ ((1 : Int) ≥ ((5 : Int) + a))) ∨ ((((2 : Int) * a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a))) ∨ (((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ ((((3 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b)))) ∨ ((((((3 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))) ∧ ((4 : Int) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≥ ((5 : Int) + a))) ∨ ((((3 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ (((4 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a))))) ∧ ((((((-1 : Int) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) + a)) ∧ ((0 : Int) ≥ ((5 : Int) + a))) ∨ (((-1 : Int) ≤ (a + (1 : Int))) ∧ ((-1 : Int) ≥ (a + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((5 : Int) + a)) ∧ ((0 : Int) ≥ ((5 : Int) + a))) ∨ (((0 : Int) ≤ (a + (1 : Int))) ∧ ((0 : Int) ≥ (a + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) + a)) ∧ ((0 : Int) ≥ ((5 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((5 : Int) + a)) ∧ ((0 : Int) ≥ ((5 : Int) + a))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((5 : Int) + a)) ∧ ((1 : Int) ≥ ((5 : Int) + a))) ∨ (((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((5 : Int) + a)) ∧ ((1 : Int) ≥ ((5 : Int) + a))) ∨ ((((2 : Int) * a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a))) ∨ (((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ ((((3 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b)))) ∨ ((((((3 : Int) + b) - b) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))) ∧ ((4 : Int) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≥ ((5 : Int) + a))) ∨ ((((3 : Int) + b) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + b)) ∧ (((4 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a)))))))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a > b))
    (h7 : (a ≥ b))
    : False := by
  apply h2
  clear h2
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n221_run_empty (a b run_x : Int)
    (h0 : ((fact_366edf150095_2377 a b run_x) ∨ (fact_366edf150095_2312 a b run_x) ∨ (fact_366edf150095_3520 a b run_x) ∨ (fact_366edf150095_3535 a b run_x) ∨ (fact_366edf150095_2317 a b run_x) ∨ (fact_366edf150095_2959 a b run_x) ∨ (fact_366edf150095_2321 a b run_x) ∨ (fact_366edf150095_3539 a b run_x) ∨ (fact_366edf150095_2965 a b run_x) ∨ ((((((3 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + (0 : Int))) ∧ ((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int))) ∨ ((((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ ((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a))))))
    (h1 : (run_x ≤ a))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((3 : Int) ≤ run_x))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n221_run_floor (a b run_x : Int)
    (h0 : ((3 : Int) ≤ run_x))
    (h1 : (run_x ≤ a))
    (h2 : (¬ ((fact_366edf150095_3351 a b run_x) ∨ (fact_366edf150095_3300 a b run_x) ∨ (fact_366edf150095_5215 a b run_x) ∨ (fact_366edf150095_5225 a b run_x) ∨ (fact_366edf150095_3310 a b run_x) ∨ (fact_366edf150095_3530 a b run_x) ∨ (fact_366edf150095_3317 a b run_x) ∨ (fact_366edf150095_5232 a b run_x) ∨ (fact_366edf150095_3545 a b run_x) ∨ ((((((3 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + (0 : Int))) ∧ ((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ ((((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ (((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a)))))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n222_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((4 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n222_empty (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((fact_366edf150095_2903 a b) ∨ (fact_366edf150095_2572 a b) ∨ (fact_366edf150095_4059 a b) ∨ (fact_366edf150095_4062 a b) ∨ (fact_366edf150095_2574 a b) ∨ (fact_366edf150095_3173 a b) ∨ (fact_366edf150095_2575 a b) ∨ (fact_366edf150095_4063 a b) ∨ ((((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + b)))) ∨ ((((4 : Int) ≥ ((3 : Int) - b)) ∧ ((4 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((4 : Int) + a)) ∧ ((4 : Int) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((4 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((4 : Int) + a) + (0 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n222_o0 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h4 : (((jx + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n222_o1 (a b jx jy : Int)
    (h0 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h1 : (¬ ((((4 : Int) = jx) ∧ (jy = ((4 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n222_o2 (a b jx jy : Int)
    (h0 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (fact_366edf150095_2954 a b jy))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n222_o3 (a b jx jy : Int)
    (h0 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h1 : (((jx + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jx - b)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h2 : (¬ (((jx = ((4 : Int) + b)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h4 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n222_o4 (a b jx jy : Int)
    (h0 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n222_o5 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h4 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h5 : (((jx + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jx - a)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h6 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n222_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h3 : (¬ ((((4 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h5 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n222_o7 (a b jx jy : Int)
    (h0 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h1 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (((jx + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h3 : (¬ ((((4 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n223_run_four (a b : Int)
    (h0 : (¬ ((5 : Int) ≤ ((2 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n223_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((2 : Int) + a) - (5 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n223_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n223_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3503 a b) ∨ (fact_366edf150095_3452 a b) ∨ (fact_366edf150095_5779 a b) ∨ (fact_366edf150095_5787 a b) ∨ (fact_366edf150095_3460 a b) ∨ (fact_366edf150095_3698 a b) ∨ (fact_366edf150095_3466 a b) ∨ (fact_366edf150095_5793 a b) ∨ ((((((3 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((4 : Int) + a)) ∧ ((4 : Int) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≥ ((4 : Int) + a)) ∧ ((4 : Int) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((4 : Int) + a) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n223_run_right (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_366edf150095_4118 a b) ∨ (fact_366edf150095_3713 a b) ∨ (fact_366edf150095_5864 a b) ∨ (fact_366edf150095_5947 a b) ∨ (fact_366edf150095_3794 a b) ∨ (fact_366edf150095_4227 a b) ∨ (((((2 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((4 : Int) + a)) ∧ ((4 : Int) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≥ ((4 : Int) + a)) ∧ ((4 : Int) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((4 : Int) + a) + (0 : Int))))))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n223_run_tall (a b : Int)
    (h0 : (¬ (((((5 : Int) + (3 : Int)) ≤ ((2 : Int) + a)) ∧ ((fact_366edf150095_7518 a b) ∨ (fact_366edf150095_7586 a b))) ∨ ((((5 : Int) + (2 : Int)) ≤ ((2 : Int) + a)) ∧ (fact_366edf150095_7518 a b) ∧ (fact_366edf150095_7586 a b)) ∨ (((5 : Int) + (4 : Int)) ≤ ((2 : Int) + a)) ∨ ((((2 : Int) + a) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7518 a b) ∧ (fact_366edf150095_7586 a b) ∧ (((fact_366edf150095_4158 a b) ∨ (fact_366edf150095_3753 a b) ∨ (fact_366edf150095_5904 a b) ∨ (fact_366edf150095_5987 a b) ∨ (fact_366edf150095_3834 a b) ∨ (fact_366edf150095_4267 a b) ∨ (fact_366edf150095_3891 a b) ∨ (fact_366edf150095_6043 a b) ∨ (fact_366edf150095_4341 a b) ∨ (fact_366edf150095_4799 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int)))))) ∨ ((fact_366edf150095_5120 a b) ∨ (fact_366edf150095_4414 a b) ∨ (fact_366edf150095_6339 a b) ∨ (fact_366edf150095_6427 a b) ∨ (fact_366edf150095_4498 a b) ∨ (fact_366edf150095_5248 a b) ∨ (fact_366edf150095_4580 a b) ∨ (fact_366edf150095_6509 a b) ∨ (fact_366edf150095_5351 a b) ∨ (fact_366edf150095_5518 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int)))))))) ∨ ((fact_366edf150095_7518 a b) ∧ (fact_366edf150095_7586 a b) ∧ ((fact_366edf150095_4158 a b) ∨ (fact_366edf150095_3753 a b) ∨ (fact_366edf150095_5904 a b) ∨ (fact_366edf150095_5987 a b) ∨ (fact_366edf150095_3834 a b) ∨ (fact_366edf150095_4267 a b) ∨ (fact_366edf150095_3891 a b) ∨ (fact_366edf150095_6043 a b) ∨ (fact_366edf150095_4341 a b) ∨ (fact_366edf150095_4799 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int)))))) ∧ ((fact_366edf150095_5120 a b) ∨ (fact_366edf150095_4414 a b) ∨ (fact_366edf150095_6339 a b) ∨ (fact_366edf150095_6427 a b) ∨ (fact_366edf150095_4498 a b) ∨ (fact_366edf150095_5248 a b) ∨ (fact_366edf150095_4580 a b) ∨ (fact_366edf150095_6509 a b) ∨ (fact_366edf150095_5351 a b) ∨ (fact_366edf150095_5518 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int))))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (a ≥ b))
    (h4 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n223_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((fact_366edf150095_2376 a b run_x) ∨ (fact_366edf150095_2311 a b run_x) ∨ (fact_366edf150095_3519 a b run_x) ∨ (fact_366edf150095_3534 a b run_x) ∨ (fact_366edf150095_2316 a b run_x) ∨ (fact_366edf150095_2958 a b run_x) ∨ (fact_366edf150095_2320 a b run_x) ∨ (fact_366edf150095_3538 a b run_x) ∨ ((((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((4 : Int) + a)) ∧ ((4 : Int) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((4 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≥ ((4 : Int) + a)) ∧ ((4 : Int) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((4 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((4 : Int) + a) + (0 : Int)))))))
    (h3 : (run_x ≤ ((2 : Int) + a)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((5 : Int) ≤ run_x))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n223_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((2 : Int) + a)))
    (h1 : ((5 : Int) ≤ run_x))
    (h2 : (¬ ((fact_366edf150095_3350 a b run_x) ∨ (fact_366edf150095_3299 a b run_x) ∨ (fact_366edf150095_5214 a b run_x) ∨ (fact_366edf150095_5224 a b run_x) ∨ (fact_366edf150095_3309 a b run_x) ∨ (fact_366edf150095_3529 a b run_x) ∨ (fact_366edf150095_3316 a b run_x) ∨ (fact_366edf150095_5231 a b run_x) ∨ ((((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ ((((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n224_run_four (a b : Int)
    (h0 : ((((2 : Int) * a) < (((4 : Int) + b) - b)) ∨ ((((4 : Int) + b) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (¬ ((4 : Int) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n224_run_short (a b : Int)
    (h0 : (¬ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (4 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n224_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n224_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3501 a b) ∨ (fact_366edf150095_3450 a b) ∨ (fact_366edf150095_5777 a b) ∨ (fact_366edf150095_5785 a b) ∨ (fact_366edf150095_3458 a b) ∨ (fact_366edf150095_3696 a b) ∨ (fact_366edf150095_3465 a b) ∨ (fact_366edf150095_5792 a b) ∨ ((((((3 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3706 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n224_run_right (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (¬ ((fact_366edf150095_6963 a b) ∨ (fact_366edf150095_6951 a b) ∨ (fact_366edf150095_7268 a b) ∨ (fact_366edf150095_7270 a b) ∨ (fact_366edf150095_6953 a b) ∨ (fact_366edf150095_7009 a b) ∨ (fact_366edf150095_6954 a b) ∨ (fact_366edf150095_7275 a b) ∨ ((((((3 : Int) + a) - a) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - b) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_7020 a b))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n224_run_tall (a b : Int)
    (h0 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) ∧ ((fact_366edf150095_7511 a b) ∨ (fact_366edf150095_7830 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) ∧ (fact_366edf150095_7511 a b) ∧ (fact_366edf150095_7830 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) ∨ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) = ((4 : Int) + (1 : Int))) ∧ (fact_366edf150095_7511 a b) ∧ (fact_366edf150095_7830 a b) ∧ (((fact_366edf150095_4146 a b) ∨ (fact_366edf150095_3741 a b) ∨ (fact_366edf150095_5892 a b) ∨ (fact_366edf150095_5975 a b) ∨ (fact_366edf150095_3822 a b) ∨ (fact_366edf150095_4255 a b) ∨ (fact_366edf150095_3883 a b) ∨ (fact_366edf150095_6035 a b) ∨ (fact_366edf150095_4331 a b) ∨ (((((3 : Int) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4378 a b)) ∨ ((fact_366edf150095_7058 a b) ∨ (fact_366edf150095_7027 a b) ∨ (fact_366edf150095_7291 a b) ∨ (fact_366edf150095_7296 a b) ∨ (fact_366edf150095_7032 a b) ∨ (fact_366edf150095_7186 a b) ∨ (fact_366edf150095_7035 a b) ∨ (fact_366edf150095_7299 a b) ∨ (fact_366edf150095_7193 a b) ∨ (((((3 : Int) - b) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a))) ∨ (fact_366edf150095_2924 a b)) ∨ (fact_366edf150095_7202 a b)))) ∨ ((fact_366edf150095_7511 a b) ∧ (fact_366edf150095_7830 a b) ∧ ((fact_366edf150095_4146 a b) ∨ (fact_366edf150095_3741 a b) ∨ (fact_366edf150095_5892 a b) ∨ (fact_366edf150095_5975 a b) ∨ (fact_366edf150095_3822 a b) ∨ (fact_366edf150095_4255 a b) ∨ (fact_366edf150095_3883 a b) ∨ (fact_366edf150095_6035 a b) ∨ (fact_366edf150095_4331 a b) ∨ (((((3 : Int) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4378 a b)) ∧ ((fact_366edf150095_7058 a b) ∨ (fact_366edf150095_7027 a b) ∨ (fact_366edf150095_7291 a b) ∨ (fact_366edf150095_7296 a b) ∨ (fact_366edf150095_7032 a b) ∨ (fact_366edf150095_7186 a b) ∨ (fact_366edf150095_7035 a b) ∨ (fact_366edf150095_7299 a b) ∨ (fact_366edf150095_7193 a b) ∨ (((((3 : Int) - b) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a))) ∨ (fact_366edf150095_2924 a b)) ∨ (fact_366edf150095_7202 a b))))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n224_run_empty (a b run_x : Int)
    (h0 : ((4 : Int) ≤ run_x))
    (h1 : ((fact_366edf150095_2377 a b run_x) ∨ (fact_366edf150095_2312 a b run_x) ∨ (fact_366edf150095_3520 a b run_x) ∨ (fact_366edf150095_3535 a b run_x) ∨ (fact_366edf150095_2317 a b run_x) ∨ (fact_366edf150095_2959 a b run_x) ∨ (fact_366edf150095_2321 a b run_x) ∨ (fact_366edf150095_3539 a b run_x) ∨ (fact_366edf150095_2965 a b run_x) ∨ (((((3 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_2970 a b run_x)))
    (h2 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n224_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3351 a b run_x) ∨ (fact_366edf150095_3300 a b run_x) ∨ (fact_366edf150095_5215 a b run_x) ∨ (fact_366edf150095_5225 a b run_x) ∨ (fact_366edf150095_3310 a b run_x) ∨ (fact_366edf150095_3530 a b run_x) ∨ (fact_366edf150095_3317 a b run_x) ∨ (fact_366edf150095_5232 a b run_x) ∨ (fact_366edf150095_3545 a b run_x) ∨ (((((3 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3550 a b run_x))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))))
    (h3 : ((4 : Int) ≤ run_x))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n225_run_four (a b : Int)
    (h0 : (¬ ((5 : Int) ≤ ((2 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n225_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + a) - (5 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n225_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n225_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_3504 a b) ∨ (fact_366edf150095_3453 a b) ∨ (fact_366edf150095_5780 a b) ∨ (fact_366edf150095_5788 a b) ∨ (fact_366edf150095_3461 a b) ∨ (fact_366edf150095_3699 a b) ∨ (fact_366edf150095_3467 a b) ∨ (fact_366edf150095_5794 a b) ∨ ((((((3 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n225_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4119 a b) ∨ (fact_366edf150095_3714 a b) ∨ (fact_366edf150095_5865 a b) ∨ (fact_366edf150095_5948 a b) ∨ (fact_366edf150095_3795 a b) ∨ (fact_366edf150095_4228 a b) ∨ (((((2 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + a) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int))) ∨ (((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n225_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (¬ (((((5 : Int) + (3 : Int)) ≤ ((2 : Int) + a)) ∧ ((fact_366edf150095_7500 a b) ∨ (fact_366edf150095_7569 a b))) ∨ ((((5 : Int) + (2 : Int)) ≤ ((2 : Int) + a)) ∧ (fact_366edf150095_7500 a b) ∧ (fact_366edf150095_7569 a b)) ∨ (((5 : Int) + (4 : Int)) ≤ ((2 : Int) + a)) ∨ ((((2 : Int) + a) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7500 a b) ∧ (fact_366edf150095_7569 a b) ∧ (((fact_366edf150095_4160 a b) ∨ (fact_366edf150095_3755 a b) ∨ (fact_366edf150095_5906 a b) ∨ (fact_366edf150095_5989 a b) ∨ (fact_366edf150095_3836 a b) ∨ (fact_366edf150095_4269 a b) ∨ (fact_366edf150095_3893 a b) ∨ (fact_366edf150095_6045 a b) ∨ ((((((3 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ ((((3 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3988 a b)) ∨ ((fact_366edf150095_5122 a b) ∨ (fact_366edf150095_4416 a b) ∨ (fact_366edf150095_6341 a b) ∨ (fact_366edf150095_6429 a b) ∨ (fact_366edf150095_4500 a b) ∨ (fact_366edf150095_5250 a b) ∨ (fact_366edf150095_4582 a b) ∨ (fact_366edf150095_6511 a b) ∨ ((((((3 : Int) + a) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ ((((3 : Int) + a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4840 a b)))) ∨ ((fact_366edf150095_7500 a b) ∧ (fact_366edf150095_7569 a b) ∧ ((fact_366edf150095_4160 a b) ∨ (fact_366edf150095_3755 a b) ∨ (fact_366edf150095_5906 a b) ∨ (fact_366edf150095_5989 a b) ∨ (fact_366edf150095_3836 a b) ∨ (fact_366edf150095_4269 a b) ∨ (fact_366edf150095_3893 a b) ∨ (fact_366edf150095_6045 a b) ∨ ((((((3 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ ((((3 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3988 a b)) ∧ ((fact_366edf150095_5122 a b) ∨ (fact_366edf150095_4416 a b) ∨ (fact_366edf150095_6341 a b) ∨ (fact_366edf150095_6429 a b) ∨ (fact_366edf150095_4500 a b) ∨ (fact_366edf150095_5250 a b) ∨ (fact_366edf150095_4582 a b) ∨ (fact_366edf150095_6511 a b) ∨ ((((((3 : Int) + a) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ ((((3 : Int) + a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (((((3 : Int) - b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4840 a b))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  apply h4
  clear h4
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

end LRegionArithmetic

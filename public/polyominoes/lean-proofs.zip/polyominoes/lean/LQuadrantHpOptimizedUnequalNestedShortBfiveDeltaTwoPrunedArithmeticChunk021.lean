import LQuadrantHpOptimizedUnequalNestedShortBfiveDeltaTwoPrunedArithmeticDefs
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace LRegionArithmetic

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n588_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_2 a b))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n588_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_3061 a b) ∨ (fact_9fdb227ae99d_3062 a b) ∨ (fact_9fdb227ae99d_3567 a b) ∨ (fact_9fdb227ae99d_4706 a b) ∨ (fact_9fdb227ae99d_3298 a b) ∨ (fact_9fdb227ae99d_3118 a b) ∨ (fact_9fdb227ae99d_3119 a b) ∨ ((((2 : Int) ≥ ((-3 : Int) - b)) ∧ ((2 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((-3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3063 a b) ∨ (fact_9fdb227ae99d_3299 a b) ∨ (fact_9fdb227ae99d_5106 a b) ∨ (fact_9fdb227ae99d_3599 a b) ∨ (fact_9fdb227ae99d_3568 a b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n588_o0 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1672 a b jx jy))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - (0 : Int)))))
    (h6 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + b) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n588_o1 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1675 a b jx jy))
    (h1 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - a))))
    (h2 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - a))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b = (5 : Int)))
    (h5 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : ((jy - a) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n588_o2 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1677 a b jx jy))
    (h1 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - b))))
    (h2 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - b))))
    (h3 : (b = (5 : Int)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (a ≥ b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a > b))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n588_o3 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1678 a b jx jy))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h8 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h9 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n588_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_1679 a b jx jy))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - a))))
    (h7 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - a))))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n588_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h2 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (fact_9fdb227ae99d_1676 a b jx jy))
    (h6 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n588_o6 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + a) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - (0 : Int)))))
    (h5 : (fact_9fdb227ae99d_1674 a b jx jy))
    (h6 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n588_o7 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - b))))
    (h3 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + b + a) - a)) ∨ ((((3 : Int) + b + a) + (0 : Int)) < jy)))
    (h4 : (fact_9fdb227ae99d_1673 a b jx jy))
    (h5 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - b))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((jy - b) ≥ (0 : Int)))
    (h9 : (fact_9fdb227ae99d_107 a b))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n589_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ (((-4 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((-4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n589_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_3208 a b))
    (h2 : ((fact_9fdb227ae99d_2876 a b) ∨ (fact_9fdb227ae99d_2879 a b) ∨ (fact_9fdb227ae99d_3265 a b) ∨ (fact_9fdb227ae99d_4172 a b) ∨ (fact_9fdb227ae99d_3107 a b) ∨ (fact_9fdb227ae99d_2965 a b) ∨ ((((-4 : Int) ≥ ((-2 : Int) - a)) ∧ ((-4 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-2 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ ((((-4 : Int) ≥ ((-3 : Int) - b)) ∧ ((-4 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-3 : Int)) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_2882 a b) ∨ (fact_9fdb227ae99d_3109 a b) ∨ (fact_9fdb227ae99d_4398 a b) ∨ ((((-4 : Int) ≥ ((-1 : Int) - b)) ∧ ((-4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) + b + a)) ∧ ((4 : Int) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-1 : Int)) ∧ ((4 : Int) ≥ (((1 : Int) + b + a) - a)) ∧ ((4 : Int) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3266 a b)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((3 : Int) + b + a) - a) ≥ (0 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : ((((2 : Int) + a) < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < ((2 : Int) + a)) ∨ ((3 : Int) > ((2 : Int) + b)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n589_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h2 : ((jx < ((-4 : Int) + ((-1 : Int) * a))) ∨ (((-4 : Int) + ((-1 : Int) * a)) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h3 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (b = (5 : Int)))
    (h9 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n589_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b = (5 : Int)))
    (h5 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n589_o2 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((-4 : Int) + ((-1 : Int) * a))) ∨ (((-4 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (¬ ((((-4 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n589_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ ((((-4 : Int) = jx) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h5 : (b = (5 : Int)))
    (h6 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h7 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n589_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b = (5 : Int)))
    (h3 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (¬ ((((-4 : Int) = jx) ∧ (jy = ((4 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n589_o5 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h4 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h5 : (((jx + (0 : Int)) < ((-4 : Int) + ((-1 : Int) * a))) ∨ (((-4 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h6 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n589_o6 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ (((jx = ((-4 : Int) + ((-1 : Int) * b))) ∧ ((4 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((-3 : Int) > (jx + b)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h8 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n589_o7 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_2925 a b jy))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h4 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : ((jy - b) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n590_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((4 : Int) ≤ ((1 : Int) + a))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n590_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((1 : Int) + a) - (4 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n590_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n590_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5690 a b) ∨ (fact_9fdb227ae99d_5703 a b) ∨ (fact_9fdb227ae99d_6371 a b) ∨ (fact_9fdb227ae99d_6967 a b) ∨ (fact_9fdb227ae99d_5996 a b) ∨ (fact_9fdb227ae99d_5759 a b) ∨ (((((-2 : Int) - a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((-2 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((-3 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-3 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_5709 a b) ∨ (fact_9fdb227ae99d_6120 a b) ∨ (fact_9fdb227ae99d_6983 a b) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + b + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6451 a b) ∨ (fact_9fdb227ae99d_6310 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n590_run_right (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (¬ ((((((0 : Int) - (0 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((0 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((1 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ ((((2 : Int) + a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-2 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-3 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-3 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((2 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((2 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((((4 : Int) + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((-4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + b + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (((((0 : Int) - b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + b + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + b + a) + (0 : Int))))) ∨ (((((-4 : Int) - a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-4 : Int) + (0 : Int))) ∧ (((4 : Int) + b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((-4 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-4 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((((4 : Int) + b) - b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n590_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ (((fact_9fdb227ae99d_6032 a b) ∨ (fact_9fdb227ae99d_6070 a b) ∨ (fact_9fdb227ae99d_6832 a b) ∨ (fact_9fdb227ae99d_7044 a b) ∨ (fact_9fdb227ae99d_6598 a b) ∨ (fact_9fdb227ae99d_6211 a b) ∨ (fact_9fdb227ae99d_6260 a b) ∨ (fact_9fdb227ae99d_6305 a b) ∨ (fact_9fdb227ae99d_6094 a b) ∨ (fact_9fdb227ae99d_6646 a b) ∨ (fact_9fdb227ae99d_7098 a b) ∨ (fact_9fdb227ae99d_6886 a b) ∨ (fact_9fdb227ae99d_6866 a b) ∨ (fact_9fdb227ae99d_6737 a b)) ∨ ((fact_9fdb227ae99d_6618 a b) ∨ (fact_9fdb227ae99d_6622 a b) ∨ (fact_9fdb227ae99d_6990 a b) ∨ (fact_9fdb227ae99d_7151 a b) ∨ (fact_9fdb227ae99d_6910 a b) ∨ (fact_9fdb227ae99d_6683 a b) ∨ (fact_9fdb227ae99d_6692 a b) ∨ (fact_9fdb227ae99d_6725 a b) ∨ (fact_9fdb227ae99d_6626 a b) ∨ (fact_9fdb227ae99d_6914 a b) ∨ (fact_9fdb227ae99d_7162 a b) ∨ (fact_9fdb227ae99d_7002 a b) ∨ (fact_9fdb227ae99d_6993 a b) ∨ (fact_9fdb227ae99d_6932 a b)))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_9fdb227ae99d_6032 a b) ∨ (fact_9fdb227ae99d_6070 a b) ∨ (fact_9fdb227ae99d_6832 a b) ∨ (fact_9fdb227ae99d_7044 a b) ∨ (fact_9fdb227ae99d_6598 a b) ∨ (fact_9fdb227ae99d_6211 a b) ∨ (fact_9fdb227ae99d_6260 a b) ∨ (fact_9fdb227ae99d_6305 a b) ∨ (fact_9fdb227ae99d_6094 a b) ∨ (fact_9fdb227ae99d_6646 a b) ∨ (fact_9fdb227ae99d_7098 a b) ∨ (fact_9fdb227ae99d_6886 a b) ∨ (fact_9fdb227ae99d_6866 a b) ∨ (fact_9fdb227ae99d_6737 a b)) ∧ ((fact_9fdb227ae99d_6618 a b) ∨ (fact_9fdb227ae99d_6622 a b) ∨ (fact_9fdb227ae99d_6990 a b) ∨ (fact_9fdb227ae99d_7151 a b) ∨ (fact_9fdb227ae99d_6910 a b) ∨ (fact_9fdb227ae99d_6683 a b) ∨ (fact_9fdb227ae99d_6692 a b) ∨ (fact_9fdb227ae99d_6725 a b) ∨ (fact_9fdb227ae99d_6626 a b) ∨ (fact_9fdb227ae99d_6914 a b) ∨ (fact_9fdb227ae99d_7162 a b) ∨ (fact_9fdb227ae99d_7002 a b) ∨ (fact_9fdb227ae99d_6993 a b) ∨ (fact_9fdb227ae99d_6932 a b))) ∨ (((4 : Int) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = ((4 : Int) + (1 : Int))) ∧ ((fact_9fdb227ae99d_6032 a b) ∨ (fact_9fdb227ae99d_6070 a b) ∨ (fact_9fdb227ae99d_6832 a b) ∨ (fact_9fdb227ae99d_7044 a b) ∨ (fact_9fdb227ae99d_6598 a b) ∨ (fact_9fdb227ae99d_6211 a b) ∨ (fact_9fdb227ae99d_6260 a b) ∨ (fact_9fdb227ae99d_6305 a b) ∨ (fact_9fdb227ae99d_6094 a b) ∨ (fact_9fdb227ae99d_6646 a b) ∨ (fact_9fdb227ae99d_7098 a b) ∨ (fact_9fdb227ae99d_6886 a b) ∨ (fact_9fdb227ae99d_6866 a b) ∨ (fact_9fdb227ae99d_6737 a b)) ∧ ((fact_9fdb227ae99d_6618 a b) ∨ (fact_9fdb227ae99d_6622 a b) ∨ (fact_9fdb227ae99d_6990 a b) ∨ (fact_9fdb227ae99d_7151 a b) ∨ (fact_9fdb227ae99d_6910 a b) ∨ (fact_9fdb227ae99d_6683 a b) ∨ (fact_9fdb227ae99d_6692 a b) ∨ (fact_9fdb227ae99d_6725 a b) ∨ (fact_9fdb227ae99d_6626 a b) ∨ (fact_9fdb227ae99d_6914 a b) ∨ (fact_9fdb227ae99d_7162 a b) ∨ (fact_9fdb227ae99d_7002 a b) ∨ (fact_9fdb227ae99d_6993 a b) ∨ (fact_9fdb227ae99d_6932 a b)) ∧ (((fact_9fdb227ae99d_6030 a b) ∨ (fact_9fdb227ae99d_6068 a b) ∨ (fact_9fdb227ae99d_6830 a b) ∨ (fact_9fdb227ae99d_7042 a b) ∨ (fact_9fdb227ae99d_6596 a b) ∨ (fact_9fdb227ae99d_6209 a b) ∨ (fact_9fdb227ae99d_6258 a b) ∨ (fact_9fdb227ae99d_6304 a b) ∨ (fact_9fdb227ae99d_6092 a b) ∨ (fact_9fdb227ae99d_6645 a b) ∨ (fact_9fdb227ae99d_7096 a b) ∨ (fact_9fdb227ae99d_6885 a b) ∨ (fact_9fdb227ae99d_6865 a b) ∨ (fact_9fdb227ae99d_6735 a b)) ∨ ((fact_9fdb227ae99d_6616 a b) ∨ (fact_9fdb227ae99d_6620 a b) ∨ (fact_9fdb227ae99d_6988 a b) ∨ (fact_9fdb227ae99d_7149 a b) ∨ (fact_9fdb227ae99d_6908 a b) ∨ (((((-1 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-3 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-3 : Int) + ((-1 : Int) * a)) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-2 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-2 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_6723 a b) ∨ (fact_9fdb227ae99d_6624 a b) ∨ (fact_9fdb227ae99d_6912 a b) ∨ (fact_9fdb227ae99d_7160 a b) ∨ (((((-1 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-3 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((1 : Int) + b + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (((((0 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-3 : Int) + ((-1 : Int) * a)) + a) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + b + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((0 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((3 : Int) + b + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6930 a b)))) ∨ (((fact_9fdb227ae99d_6032 a b) ∨ (fact_9fdb227ae99d_6070 a b) ∨ (fact_9fdb227ae99d_6832 a b) ∨ (fact_9fdb227ae99d_7044 a b) ∨ (fact_9fdb227ae99d_6598 a b) ∨ (fact_9fdb227ae99d_6211 a b) ∨ (fact_9fdb227ae99d_6260 a b) ∨ (fact_9fdb227ae99d_6305 a b) ∨ (fact_9fdb227ae99d_6094 a b) ∨ (fact_9fdb227ae99d_6646 a b) ∨ (fact_9fdb227ae99d_7098 a b) ∨ (fact_9fdb227ae99d_6886 a b) ∨ (fact_9fdb227ae99d_6866 a b) ∨ (fact_9fdb227ae99d_6737 a b)) ∧ ((fact_9fdb227ae99d_6618 a b) ∨ (fact_9fdb227ae99d_6622 a b) ∨ (fact_9fdb227ae99d_6990 a b) ∨ (fact_9fdb227ae99d_7151 a b) ∨ (fact_9fdb227ae99d_6910 a b) ∨ (fact_9fdb227ae99d_6683 a b) ∨ (fact_9fdb227ae99d_6692 a b) ∨ (fact_9fdb227ae99d_6725 a b) ∨ (fact_9fdb227ae99d_6626 a b) ∨ (fact_9fdb227ae99d_6914 a b) ∨ (fact_9fdb227ae99d_7162 a b) ∨ (fact_9fdb227ae99d_7002 a b) ∨ (fact_9fdb227ae99d_6993 a b) ∨ (fact_9fdb227ae99d_6932 a b)) ∧ ((fact_9fdb227ae99d_6030 a b) ∨ (fact_9fdb227ae99d_6068 a b) ∨ (fact_9fdb227ae99d_6830 a b) ∨ (fact_9fdb227ae99d_7042 a b) ∨ (fact_9fdb227ae99d_6596 a b) ∨ (fact_9fdb227ae99d_6209 a b) ∨ (fact_9fdb227ae99d_6258 a b) ∨ (fact_9fdb227ae99d_6304 a b) ∨ (fact_9fdb227ae99d_6092 a b) ∨ (fact_9fdb227ae99d_6645 a b) ∨ (fact_9fdb227ae99d_7096 a b) ∨ (fact_9fdb227ae99d_6885 a b) ∨ (fact_9fdb227ae99d_6865 a b) ∨ (fact_9fdb227ae99d_6735 a b)) ∧ ((fact_9fdb227ae99d_6616 a b) ∨ (fact_9fdb227ae99d_6620 a b) ∨ (fact_9fdb227ae99d_6988 a b) ∨ (fact_9fdb227ae99d_7149 a b) ∨ (fact_9fdb227ae99d_6908 a b) ∨ (((((-1 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-3 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-3 : Int) + ((-1 : Int) * a)) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-2 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-2 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_6723 a b) ∨ (fact_9fdb227ae99d_6624 a b) ∨ (fact_9fdb227ae99d_6912 a b) ∨ (fact_9fdb227ae99d_7160 a b) ∨ (((((-1 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-3 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((1 : Int) + b + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (((((0 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-3 : Int) + ((-1 : Int) * a)) + a) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + b + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((0 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((3 : Int) + b + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6930 a b))))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n590_run_empty (a b run_x : Int)
    (h0 : (a > b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (run_x ≤ ((1 : Int) + a)))
    (h3 : ((fact_9fdb227ae99d_3629 a b run_x) ∨ (fact_9fdb227ae99d_3638 a b run_x) ∨ (fact_9fdb227ae99d_5037 a b run_x) ∨ (fact_9fdb227ae99d_5790 a b run_x) ∨ (fact_9fdb227ae99d_4412 a b run_x) ∨ (fact_9fdb227ae99d_3681 a b run_x) ∨ (((((-2 : Int) - a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-3 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3645 a b run_x) ∨ (fact_9fdb227ae99d_4492 a b run_x) ∨ (fact_9fdb227ae99d_5824 a b run_x) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + b + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_5101 a b run_x) ∨ (fact_9fdb227ae99d_4526 a b run_x)))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : ((4 : Int) ≤ run_x))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((((2 : Int) + a) < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < ((2 : Int) + a)) ∨ ((3 : Int) > ((2 : Int) + b)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h10 : (fact_9fdb227ae99d_107 a b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n590_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((1 : Int) + a)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (¬ ((fact_9fdb227ae99d_5412 a b run_x) ∨ (fact_9fdb227ae99d_5415 a b run_x) ∨ (fact_9fdb227ae99d_5990 a b run_x) ∨ (fact_9fdb227ae99d_6843 a b run_x) ∨ (fact_9fdb227ae99d_5796 a b run_x) ∨ (fact_9fdb227ae99d_5483 a b run_x) ∨ (((((-2 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_5416 a b run_x) ∨ (fact_9fdb227ae99d_5806 a b run_x) ∨ (fact_9fdb227ae99d_6898 a b run_x) ∨ (((((-1 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((1 : Int) + b + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6041 a b run_x) ∨ (fact_9fdb227ae99d_5813 a b run_x))))
    (h3 : ((4 : Int) ≤ run_x))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n591_point (a b : Int)
    (h0 : (¬ (((-2 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ (((2 : Int) + b) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ (((2 : Int) + b) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n591_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((((-2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((2 : Int) + b)) ∧ ((0 : Int) ≥ ((2 : Int) + b))) ∨ (((0 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((0 : Int) + a)))) ∨ ((((-2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ ((2 : Int) + b)) ∧ ((1 : Int) ≥ ((2 : Int) + b))) ∨ (((1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((1 : Int) + a)))) ∨ ((((-2 : Int) ≥ (((1 : Int) + b + a) - a)) ∧ ((-2 : Int) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) + b)) ∧ ((0 : Int) ≥ ((2 : Int) + b))) ∨ (((-2 : Int) ≥ ((1 : Int) + b + a)) ∧ ((-2 : Int) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((-2 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - b)) ∧ ((-2 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) + b)) ∧ ((1 : Int) ≥ ((2 : Int) + b))) ∨ (((-2 : Int) ≥ ((2 : Int) + ((2 : Int) * b))) ∧ ((-2 : Int) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((1 : Int) + a)))) ∨ ((((-2 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((-2 : Int) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) + b))) ∨ (((-2 : Int) ≥ ((2 : Int) + a)) ∧ ((-2 : Int) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((2 : Int) + b)))) ∨ ((((-2 : Int) ≥ ((-1 : Int) - a)) ∧ ((-2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) + b)) ∧ ((0 : Int) ≥ ((2 : Int) + b))) ∨ (((-1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((-2 : Int) ≥ ((-2 : Int) - a)) ∧ ((-2 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) + b)) ∧ ((1 : Int) ≥ ((2 : Int) + b))) ∨ (((-2 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-2 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((1 : Int) + b)))) ∨ ((((-2 : Int) ≥ ((-3 : Int) - b)) ∧ ((-2 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) + b))) ∨ (((-3 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((2 : Int) + a)))) ∨ ((((-2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≥ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (2 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((3 : Int) + a)))) ∨ ((((-2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (3 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((-2 : Int) ≥ (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((-2 : Int) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≥ ((2 : Int) + b))) ∨ (((-2 : Int) ≥ ((-4 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((3 : Int) + b)))) ∨ ((((-2 : Int) ≥ ((-1 : Int) - b)) ∧ ((-2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-1 : Int)) ∧ ((((1 : Int) + b + a) - a) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ ((((-2 : Int) ≥ ((0 : Int) - b)) ∧ ((-2 : Int) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + b + a) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (0 : Int)) ∧ ((((3 : Int) + b + a) - a) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (((3 : Int) + b + a) + (0 : Int))))) ∨ ((((-2 : Int) ≥ ((-4 : Int) - b)) ∧ ((-2 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)) ∧ ((4 : Int) ≥ ((2 : Int) + b))) ∨ (((-4 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-4 : Int)) ∧ (((4 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((4 : Int) + a))))))
    (h2 : (fact_9fdb227ae99d_3206 a b))
    (h3 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n591_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h3 : (b = (5 : Int)))
    (h4 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + b)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h8 : (((-4 : Int) > (jx + a)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n591_o1 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + b + a) - a)) ∨ ((((3 : Int) + b + a) + (0 : Int)) < jy)))
    (h5 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - a) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + (0 : Int))))))
    (h6 : (fact_9fdb227ae99d_2923 a b jy))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n591_o2 (a b jx jy : Int)
    (h0 : (¬ ((((-2 : Int) = jx) ∧ (jy = ((2 : Int) + ((2 : Int) * b))) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - b) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + (0 : Int))))))
    (h5 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - b))))
    (h6 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - a)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h7 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : ((jy - b) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n591_o3 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h4 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h5 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - (0 : Int)))))
    (h6 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + a)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n591_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_2922 a b jy))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - a) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + (0 : Int))))))
    (h5 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - a))))
    (h6 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - a))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n591_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + b)))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h7 : (b = (5 : Int)))
    (h8 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n591_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + a)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((jx < ((-4 : Int) - b)) ∨ (((-4 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h6 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h7 : (((-4 : Int) > (jx + b)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n591_o7 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h2 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - b) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_9fdb227ae99d_2925 a b jy))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h8 : ((jy - b) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n592_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_3206 a b))
    (h2 : (¬ (((-3 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ (((2 : Int) * b) ≥ (0 : Int)) ∧ ((-3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ (((2 : Int) * b) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b = (5 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n592_empty (a b : Int)
    (h0 : (((-4 : Int) < ((-2 : Int) - a)) ∨ ((-4 : Int) > ((-2 : Int) + (0 : Int))) ∨ (((4 : Int) + a) < ((2 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int)))))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_3208 a b))
    (h3 : (((((-3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((2 : Int) * b)) ∧ ((0 : Int) ≥ ((2 : Int) * b))) ∨ (((0 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ ((0 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ ((2 : Int) * b)) ∧ ((1 : Int) ≥ ((2 : Int) * b))) ∨ (((1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ ((1 : Int) + a)))) ∨ ((((-3 : Int) ≥ (((1 : Int) + b + a) - a)) ∧ ((-3 : Int) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) * b)) ∧ ((0 : Int) ≥ ((2 : Int) * b))) ∨ (((-3 : Int) ≥ ((1 : Int) + b + a)) ∧ ((-3 : Int) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ ((0 : Int) + b)))) ∨ ((((-3 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - b)) ∧ ((-3 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) * b)) ∧ ((1 : Int) ≥ ((2 : Int) * b))) ∨ (((-3 : Int) ≥ ((2 : Int) + ((2 : Int) * b))) ∧ ((-3 : Int) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ ((1 : Int) + a)))) ∨ ((((-3 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((-3 : Int) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) * b)) ∧ ((2 : Int) ≥ ((2 : Int) * b))) ∨ (((-3 : Int) ≥ ((2 : Int) + a)) ∧ ((-3 : Int) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ ((2 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-1 : Int) - a)) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) * b)) ∧ ((0 : Int) ≥ ((2 : Int) * b))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ ((0 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-2 : Int) - a)) ∧ ((-3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) * b)) ∧ ((1 : Int) ≥ ((2 : Int) * b))) ∨ (((-2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-2 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ ((1 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-3 : Int) - b)) ∧ ((-3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) * b)) ∧ ((2 : Int) ≥ ((2 : Int) * b))) ∨ (((-3 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ ((2 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ ((2 : Int) * b)) ∧ ((3 : Int) ≥ ((2 : Int) * b))) ∨ (((2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (2 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ ((3 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (3 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((-3 : Int) ≥ (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((-3 : Int) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ ((2 : Int) * b)) ∧ ((3 : Int) ≥ ((2 : Int) * b))) ∨ (((-3 : Int) ≥ ((-4 : Int) + ((-1 : Int) * a))) ∧ ((-3 : Int) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ ((3 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-1 : Int) - b)) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ ((((1 : Int) + b + a) - a) ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ ((((-3 : Int) ≥ ((0 : Int) - b)) ∧ ((-3 : Int) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + b + a) ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (0 : Int)) ∧ ((((3 : Int) + b + a) - a) ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ (((3 : Int) + b + a) + (0 : Int))))) ∨ ((((-3 : Int) ≥ ((-4 : Int) - b)) ∧ ((-3 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) * b)) ∧ ((4 : Int) ≥ ((2 : Int) * b))) ∨ (((-4 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-4 : Int)) ∧ (((4 : Int) - (0 : Int)) ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ ((4 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((-2 : Int) - a)) ∧ ((-3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + ((2 : Int) * b)) ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ ((2 : Int) + ((2 : Int) * b)))) ∨ (((-2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-2 : Int)) ∧ ((((2 : Int) + ((2 : Int) * b)) - b) ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int)))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((3 : Int) + b + a) - a) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n592_o0 (a b jx jy : Int)
    (h0 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ (jy ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ (jy + b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((((2 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((-4 : Int) > (jx + a)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h5 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h6 : (b = (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n592_o1 (a b jx jy : Int)
    (h0 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ (jy ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - a) ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ (jy + (0 : Int))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : ((jx < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + ((2 : Int) * b)) < (jy - a))))
    (h8 : (((-4 : Int) > (jx + b)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n592_o2 (a b jx jy : Int)
    (h0 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - b))))
    (h1 : (b = (5 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((jx < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + ((2 : Int) * b)) < (jy - b))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - b) ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ (jy + (0 : Int))))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((((2 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n592_o3 (a b jx jy : Int)
    (h0 : ((jx < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((2 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + ((2 : Int) * b)) < (jy - (0 : Int)))))
    (h1 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ (jy + a)))))
    (h2 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - (0 : Int)))))
    (h7 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + b + a) - a)) ∨ ((((3 : Int) + b + a) + (0 : Int)) < jy)))
    (h8 : (b = (5 : Int)))
    (h9 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n592_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + ((2 : Int) * b)) < (jy - a))))
    (h2 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((((2 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - a))))
    (h6 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - a) ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ (jy + (0 : Int))))))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n592_o5 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - a)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h4 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - a)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h5 : (((-4 : Int) < ((-2 : Int) - a)) ∨ ((-4 : Int) > ((-2 : Int) + (0 : Int))) ∨ (((4 : Int) + a) < ((2 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int)))))
    (h6 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((((2 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h7 : ((jx < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((2 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + ((2 : Int) * b)) < (jy - (0 : Int)))))
    (h8 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h9 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h10 : (b = (5 : Int)))
    (h11 : (a ≥ (5 : Int)))
    (h12 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ (jy + b)))))
    (h13 : (fact_9fdb227ae99d_107 a b))
    (h14 : (a ≥ b))
    (h15 : (a > b))
    (h16 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n592_o6 (a b jx jy : Int)
    (h0 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h1 : (((-4 : Int) > (jx + b)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h2 : (b = (5 : Int)))
    (h3 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((((2 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jx < ((-3 : Int) - b)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ (jy ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ (jy + a)))))
    (h9 : ((jx < ((-4 : Int) - b)) ∨ (((-4 : Int) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h10 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n592_o7 (a b jx jy : Int)
    (h0 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - b))))
    (h1 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ (jy ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - b) ≤ ((2 : Int) * b)) ∧ (((2 : Int) * b) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((-4 : Int) > (jx + a)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h8 : (((jx + a) < ((0 : Int) - b)) ∨ (((0 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n593_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b = (5 : Int)))
    (h2 : (¬ (((-3 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ (((3 : Int) + a) ≥ (0 : Int)) ∧ ((-3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ (((3 : Int) + a) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n593_empty (a b : Int)
    (h0 : (a > b))
    (h1 : ((((3 : Int) + b + a) - a) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((((-3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((3 : Int) + a)) ∧ ((0 : Int) ≥ ((3 : Int) + a))) ∨ (((0 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((0 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ (((1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + a)))) ∨ ((((-3 : Int) ≥ (((1 : Int) + b + a) - a)) ∧ ((-3 : Int) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) + a)) ∧ ((0 : Int) ≥ ((3 : Int) + a))) ∨ (((-3 : Int) ≥ ((1 : Int) + b + a)) ∧ ((-3 : Int) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((-3 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - b)) ∧ ((-3 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ (((-3 : Int) ≥ ((2 : Int) + ((2 : Int) * b))) ∧ ((-3 : Int) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + a)))) ∨ ((((-3 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((-3 : Int) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) + a))) ∨ (((-3 : Int) ≥ ((2 : Int) + a)) ∧ ((-3 : Int) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((2 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-1 : Int) - a)) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) + a)) ∧ ((0 : Int) ≥ ((3 : Int) + a))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-2 : Int) - a)) ∧ ((-3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ (((-2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-2 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-3 : Int) - b)) ∧ ((-3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) + a))) ∨ (((-3 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≥ ((3 : Int) + a))) ∨ (((2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (2 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((3 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (3 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((-3 : Int) ≥ (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((-3 : Int) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≥ ((3 : Int) + a))) ∨ (((-3 : Int) ≥ ((-4 : Int) + ((-1 : Int) * a))) ∧ ((-3 : Int) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((3 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-1 : Int) - b)) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ ((((1 : Int) + b + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ ((((-3 : Int) ≥ ((0 : Int) - b)) ∧ ((-3 : Int) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + b + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (0 : Int)) ∧ ((((3 : Int) + b + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((3 : Int) + b + a) + (0 : Int))))) ∨ ((((-3 : Int) ≥ ((-4 : Int) - b)) ∧ ((-3 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((-4 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-4 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int)))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n593_o0 (a b jx jy : Int)
    (h0 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ (jy ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (jy + b)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b = (5 : Int)))
    (h7 : (((-4 : Int) > (jx + a)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h8 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n593_o1 (a b jx jy : Int)
    (h0 : ((jx < ((0 : Int) - b)) ∨ (((0 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - a))))
    (h1 : (((-4 : Int) > (jx + b)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ (jy ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (jy + (0 : Int))))))
    (h6 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (fact_9fdb227ae99d_2923 a b jy))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + b + a) - a)) ∨ ((((3 : Int) + b + a) + (0 : Int)) < jy)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n593_o2 (a b jx jy : Int)
    (h0 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (jy + (0 : Int))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - b))))
    (h7 : (((jx + (0 : Int)) < ((0 : Int) - b)) ∨ (((0 : Int) + (0 : Int)) < (jx - a)) ∨ (jy < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < jy)))
    (h8 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h9 : ((jy - b) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n593_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h2 : (((jx + (0 : Int)) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - b)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h3 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (jy + a)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b = (5 : Int)))
    (h7 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h8 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h9 : (((jx + (0 : Int)) < ((-3 : Int) - b)) ∨ (((-3 : Int) + (0 : Int)) < (jx - b)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h10 : (((jx + (0 : Int)) < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < (jx - b)) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h11 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    (h14 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n593_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - a))))
    (h4 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - a))))
    (h5 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h6 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (jy + (0 : Int))))))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n593_o5 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (jy + b)))))
    (h2 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h5 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : (b = (5 : Int)))
    (h7 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n593_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ (jy ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (jy + a)))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (((-4 : Int) > (jx + b)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h8 : (b = (5 : Int)))
    (h9 : ((jx < ((-3 : Int) - b)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n593_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((-4 : Int) > (jx + a)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h5 : (((jx + a) < ((0 : Int) - b)) ∨ (((0 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < jy)))
    (h6 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ (jy ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (jy + (0 : Int))))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - b))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n594_run_four (a b : Int)
    (h0 : (¬ ((-4 : Int) ≥ ((-1 : Int) + ((-1 : Int) * a)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n594_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ (((-4 : Int) - ((-1 : Int) + ((-1 : Int) * a))) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n594_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n594_run_left (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (¬ ((((((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((0 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + b + a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((1 : Int) + b + a)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ ((((2 : Int) + a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((2 : Int) + a)) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((2 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((3 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((-4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) + b + a)) ∧ ((5 : Int) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((5 : Int) ≥ (((1 : Int) + b + a) - a)) ∧ ((5 : Int) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (((((0 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((0 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + b + a)) ∧ ((5 : Int) ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((0 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + b + a) - a)) ∧ ((5 : Int) ≤ (((3 : Int) + b + a) + (0 : Int))))) ∨ ((((((-4 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((-4 : Int) + ((-1 : Int) * b)) + b)) ∧ ((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * b)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-4 : Int) + ((-1 : Int) * b))) ∧ ((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n594_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3417 a b) ∨ (fact_9fdb227ae99d_3435 a b) ∨ (fact_9fdb227ae99d_4510 a b) ∨ (fact_9fdb227ae99d_5594 a b) ∨ (fact_9fdb227ae99d_3882 a b) ∨ (fact_9fdb227ae99d_3499 a b) ∨ (((((-2 : Int) - a) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-2 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - b) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-3 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3449 a b) ∨ (fact_9fdb227ae99d_4144 a b) ∨ (fact_9fdb227ae99d_5727 a b) ∨ (((((-1 : Int) - b) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) + b + a)) ∧ ((5 : Int) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((5 : Int) ≥ (((1 : Int) + b + a) - a)) ∧ ((5 : Int) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_4529 a b) ∨ (fact_9fdb227ae99d_5730 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n594_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ ((((-4 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + (3 : Int))) ∧ (((fact_9fdb227ae99d_6012 a b) ∨ (fact_9fdb227ae99d_6050 a b) ∨ (fact_9fdb227ae99d_6812 a b) ∨ (fact_9fdb227ae99d_7024 a b) ∨ (fact_9fdb227ae99d_6578 a b) ∨ (fact_9fdb227ae99d_6198 a b) ∨ (fact_9fdb227ae99d_6255 a b) ∨ (fact_9fdb227ae99d_6301 a b) ∨ (fact_9fdb227ae99d_6083 a b) ∨ (fact_9fdb227ae99d_6639 a b) ∨ (fact_9fdb227ae99d_7094 a b) ∨ (fact_9fdb227ae99d_6884 a b) ∨ (fact_9fdb227ae99d_6864 a b) ∨ (fact_9fdb227ae99d_7108 a b)) ∨ (fact_9fdb227ae99d_7922 a b))) ∨ (((-4 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + (2 : Int))) ∧ ((fact_9fdb227ae99d_6012 a b) ∨ (fact_9fdb227ae99d_6050 a b) ∨ (fact_9fdb227ae99d_6812 a b) ∨ (fact_9fdb227ae99d_7024 a b) ∨ (fact_9fdb227ae99d_6578 a b) ∨ (fact_9fdb227ae99d_6198 a b) ∨ (fact_9fdb227ae99d_6255 a b) ∨ (fact_9fdb227ae99d_6301 a b) ∨ (fact_9fdb227ae99d_6083 a b) ∨ (fact_9fdb227ae99d_6639 a b) ∨ (fact_9fdb227ae99d_7094 a b) ∨ (fact_9fdb227ae99d_6884 a b) ∨ (fact_9fdb227ae99d_6864 a b) ∨ (fact_9fdb227ae99d_7108 a b)) ∧ (fact_9fdb227ae99d_7922 a b)) ∨ ((-4 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + (4 : Int))) ∨ (((-4 : Int) = (((-1 : Int) + ((-1 : Int) * a)) + (1 : Int))) ∧ ((fact_9fdb227ae99d_6012 a b) ∨ (fact_9fdb227ae99d_6050 a b) ∨ (fact_9fdb227ae99d_6812 a b) ∨ (fact_9fdb227ae99d_7024 a b) ∨ (fact_9fdb227ae99d_6578 a b) ∨ (fact_9fdb227ae99d_6198 a b) ∨ (fact_9fdb227ae99d_6255 a b) ∨ (fact_9fdb227ae99d_6301 a b) ∨ (fact_9fdb227ae99d_6083 a b) ∨ (fact_9fdb227ae99d_6639 a b) ∨ (fact_9fdb227ae99d_7094 a b) ∨ (fact_9fdb227ae99d_6884 a b) ∨ (fact_9fdb227ae99d_6864 a b) ∨ (fact_9fdb227ae99d_7108 a b)) ∧ (fact_9fdb227ae99d_7922 a b) ∧ (((fact_9fdb227ae99d_6011 a b) ∨ (fact_9fdb227ae99d_6049 a b) ∨ (fact_9fdb227ae99d_6811 a b) ∨ (fact_9fdb227ae99d_7023 a b) ∨ (fact_9fdb227ae99d_6577 a b) ∨ (fact_9fdb227ae99d_6197 a b) ∨ (fact_9fdb227ae99d_6254 a b) ∨ (((((-3 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a))) ∨ (((-3 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_6082 a b) ∨ (fact_9fdb227ae99d_6638 a b) ∨ (fact_9fdb227ae99d_7093 a b) ∨ (fact_9fdb227ae99d_6883 a b) ∨ (fact_9fdb227ae99d_6863 a b) ∨ (fact_9fdb227ae99d_7107 a b)) ∨ ((fact_9fdb227ae99d_4077 a b) ∨ (fact_9fdb227ae99d_4105 a b) ∨ (fact_9fdb227ae99d_5311 a b) ∨ (fact_9fdb227ae99d_5926 a b) ∨ (fact_9fdb227ae99d_4740 a b) ∨ (fact_9fdb227ae99d_4214 a b) ∨ (fact_9fdb227ae99d_4251 a b) ∨ (fact_9fdb227ae99d_4297 a b) ∨ (fact_9fdb227ae99d_4119 a b) ∨ (fact_9fdb227ae99d_5012 a b) ∨ (fact_9fdb227ae99d_6164 a b) ∨ (fact_9fdb227ae99d_5408 a b) ∨ (fact_9fdb227ae99d_5341 a b) ∨ (fact_9fdb227ae99d_6170 a b)))) ∨ (((fact_9fdb227ae99d_6012 a b) ∨ (fact_9fdb227ae99d_6050 a b) ∨ (fact_9fdb227ae99d_6812 a b) ∨ (fact_9fdb227ae99d_7024 a b) ∨ (fact_9fdb227ae99d_6578 a b) ∨ (fact_9fdb227ae99d_6198 a b) ∨ (fact_9fdb227ae99d_6255 a b) ∨ (fact_9fdb227ae99d_6301 a b) ∨ (fact_9fdb227ae99d_6083 a b) ∨ (fact_9fdb227ae99d_6639 a b) ∨ (fact_9fdb227ae99d_7094 a b) ∨ (fact_9fdb227ae99d_6884 a b) ∨ (fact_9fdb227ae99d_6864 a b) ∨ (fact_9fdb227ae99d_7108 a b)) ∧ (fact_9fdb227ae99d_7922 a b) ∧ ((fact_9fdb227ae99d_6011 a b) ∨ (fact_9fdb227ae99d_6049 a b) ∨ (fact_9fdb227ae99d_6811 a b) ∨ (fact_9fdb227ae99d_7023 a b) ∨ (fact_9fdb227ae99d_6577 a b) ∨ (fact_9fdb227ae99d_6197 a b) ∨ (fact_9fdb227ae99d_6254 a b) ∨ (((((-3 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a))) ∨ (((-3 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_6082 a b) ∨ (fact_9fdb227ae99d_6638 a b) ∨ (fact_9fdb227ae99d_7093 a b) ∨ (fact_9fdb227ae99d_6883 a b) ∨ (fact_9fdb227ae99d_6863 a b) ∨ (fact_9fdb227ae99d_7107 a b)) ∧ ((fact_9fdb227ae99d_4077 a b) ∨ (fact_9fdb227ae99d_4105 a b) ∨ (fact_9fdb227ae99d_5311 a b) ∨ (fact_9fdb227ae99d_5926 a b) ∨ (fact_9fdb227ae99d_4740 a b) ∨ (fact_9fdb227ae99d_4214 a b) ∨ (fact_9fdb227ae99d_4251 a b) ∨ (fact_9fdb227ae99d_4297 a b) ∨ (fact_9fdb227ae99d_4119 a b) ∨ (fact_9fdb227ae99d_5012 a b) ∨ (fact_9fdb227ae99d_6164 a b) ∨ (fact_9fdb227ae99d_5408 a b) ∨ (fact_9fdb227ae99d_5341 a b) ∨ (fact_9fdb227ae99d_6170 a b))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n594_run_empty (a b run_x : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b = (5 : Int)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((fact_9fdb227ae99d_2368 a b run_x) ∨ (fact_9fdb227ae99d_2385 a b run_x) ∨ (fact_9fdb227ae99d_3041 a b run_x) ∨ (fact_9fdb227ae99d_3482 a b run_x) ∨ (fact_9fdb227ae99d_2929 a b run_x) ∨ (fact_9fdb227ae99d_2463 a b run_x) ∨ (fact_9fdb227ae99d_2475 a b run_x) ∨ (fact_9fdb227ae99d_2486 a b run_x) ∨ (fact_9fdb227ae99d_2399 a b run_x) ∨ (fact_9fdb227ae99d_2949 a b run_x) ∨ (fact_9fdb227ae99d_3614 a b run_x) ∨ (((((-1 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) + b + a)) ∧ ((5 : Int) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ run_x) ∧ ((-1 : Int) ≥ run_x) ∧ ((5 : Int) ≥ (((1 : Int) + b + a) - a)) ∧ ((5 : Int) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3048 a b run_x) ∨ (fact_9fdb227ae99d_3617 a b run_x)))
    (h4 : (((-1 : Int) + ((-1 : Int) * a)) ≤ run_x))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((-4 : Int) ≥ run_x))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n594_run_floor (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (((-1 : Int) + ((-1 : Int) * a)) ≤ run_x))
    (h2 : ((-4 : Int) ≥ run_x))
    (h3 : (¬ ((fact_9fdb227ae99d_3180 a b run_x) ∨ (fact_9fdb227ae99d_3190 a b run_x) ∨ (fact_9fdb227ae99d_3732 a b run_x) ∨ (fact_9fdb227ae99d_5197 a b run_x) ∨ (fact_9fdb227ae99d_3491 a b run_x) ∨ (fact_9fdb227ae99d_3216 a b run_x) ∨ (fact_9fdb227ae99d_3231 a b run_x) ∨ (fact_9fdb227ae99d_3249 a b run_x) ∨ (fact_9fdb227ae99d_3198 a b run_x) ∨ (fact_9fdb227ae99d_3560 a b run_x) ∨ (fact_9fdb227ae99d_5361 a b run_x) ∨ (((((-1 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ run_x) ∧ ((-1 : Int) ≥ run_x) ∧ ((((1 : Int) + b + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3779 a b run_x) ∨ (fact_9fdb227ae99d_5364 a b run_x))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n595_run_four (a b : Int)
    (h0 : (¬ (((2 : Int) + a) ≤ (b + a))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n595_run_short (a b : Int)
    (h0 : (¬ (((b + a) - ((2 : Int) + a)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n595_run_nonnegative (a b : Int)
    (h0 : (¬ (((2 : Int) + a) ≥ (0 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n595_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3845 a b) ∨ (fact_9fdb227ae99d_3846 a b) ∨ (fact_9fdb227ae99d_5286 a b) ∨ (fact_9fdb227ae99d_5900 a b) ∨ (fact_9fdb227ae99d_4704 a b) ∨ (fact_9fdb227ae99d_4180 a b) ∨ (fact_9fdb227ae99d_4181 a b) ∨ ((((1 : Int) ≥ ((-3 : Int) - b)) ∧ ((1 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + a) - (1 : Int)))) ∨ (((-3 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3847 a b) ∨ (fact_9fdb227ae99d_4705 a b) ∨ (fact_9fdb227ae99d_6129 a b) ∨ (fact_9fdb227ae99d_5346 a b) ∨ (fact_9fdb227ae99d_5901 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n595_run_right (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int)) ∨ (((0 : Int) + a) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((0 : Int) - (0 : Int)))))
    (h2 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (¬ ((fact_9fdb227ae99d_3295 a b) ∨ (fact_9fdb227ae99d_3296 a b) ∨ (fact_9fdb227ae99d_4318 a b) ∨ (fact_9fdb227ae99d_5449 a b) ∨ (fact_9fdb227ae99d_3667 a b) ∨ (fact_9fdb227ae99d_3349 a b) ∨ (fact_9fdb227ae99d_3350 a b) ∨ ((((1 : Int) ≥ ((-3 : Int) - b)) ∧ ((1 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((b + a) + (1 : Int))) ∧ ((2 : Int) ≥ ((b + a) + (1 : Int)))) ∨ (((-3 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((b + a) + (1 : Int))) ∧ (((b + a) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3297 a b) ∨ (fact_9fdb227ae99d_3668 a b) ∨ ((((1 : Int) ≥ (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((1 : Int) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ ((b + a) + (1 : Int))) ∧ ((3 : Int) ≥ ((b + a) + (1 : Int)))) ∨ (((1 : Int) ≥ ((-4 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ ((b + a) + (1 : Int))) ∧ (((b + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_4400 a b) ∨ (fact_9fdb227ae99d_5450 a b))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (b = (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n595_run_tall (a b : Int)
    (h0 : (¬ ((((((2 : Int) + a) + (3 : Int)) ≤ (b + a)) ∧ ((fact_9fdb227ae99d_7914 a b) ∨ (fact_9fdb227ae99d_7833 a b))) ∨ (((((2 : Int) + a) + (2 : Int)) ≤ (b + a)) ∧ (fact_9fdb227ae99d_7914 a b) ∧ (fact_9fdb227ae99d_7833 a b)) ∨ ((((2 : Int) + a) + (4 : Int)) ≤ (b + a)) ∨ (((b + a) = (((2 : Int) + a) + (1 : Int))) ∧ (fact_9fdb227ae99d_7914 a b) ∧ (fact_9fdb227ae99d_7833 a b) ∧ (((fact_9fdb227ae99d_4589 a b) ∨ (fact_9fdb227ae99d_4624 a b) ∨ (fact_9fdb227ae99d_5654 a b) ∨ (fact_9fdb227ae99d_6393 a b) ∨ (fact_9fdb227ae99d_5383 a b) ∨ (fact_9fdb227ae99d_4765 a b) ∨ (fact_9fdb227ae99d_4807 a b) ∨ (fact_9fdb227ae99d_4894 a b) ∨ (fact_9fdb227ae99d_4647 a b) ∨ (fact_9fdb227ae99d_5433 a b) ∨ (fact_9fdb227ae99d_6561 a b) ∨ (fact_9fdb227ae99d_5764 a b) ∨ (fact_9fdb227ae99d_6449 a b)) ∨ ((fact_9fdb227ae99d_3632 a b) ∨ (fact_9fdb227ae99d_3641 a b) ∨ (fact_9fdb227ae99d_5040 a b) ∨ (fact_9fdb227ae99d_5793 a b) ∨ (fact_9fdb227ae99d_4415 a b) ∨ (fact_9fdb227ae99d_3684 a b) ∨ (fact_9fdb227ae99d_3689 a b) ∨ (fact_9fdb227ae99d_3706 a b) ∨ (fact_9fdb227ae99d_3648 a b) ∨ (fact_9fdb227ae99d_4495 a b) ∨ (fact_9fdb227ae99d_5827 a b) ∨ (fact_9fdb227ae99d_5130 a b) ∨ (fact_9fdb227ae99d_5803 a b)))) ∨ ((fact_9fdb227ae99d_7914 a b) ∧ (fact_9fdb227ae99d_7833 a b) ∧ ((fact_9fdb227ae99d_4589 a b) ∨ (fact_9fdb227ae99d_4624 a b) ∨ (fact_9fdb227ae99d_5654 a b) ∨ (fact_9fdb227ae99d_6393 a b) ∨ (fact_9fdb227ae99d_5383 a b) ∨ (fact_9fdb227ae99d_4765 a b) ∨ (fact_9fdb227ae99d_4807 a b) ∨ (fact_9fdb227ae99d_4894 a b) ∨ (fact_9fdb227ae99d_4647 a b) ∨ (fact_9fdb227ae99d_5433 a b) ∨ (fact_9fdb227ae99d_6561 a b) ∨ (fact_9fdb227ae99d_5764 a b) ∨ (fact_9fdb227ae99d_6449 a b)) ∧ ((fact_9fdb227ae99d_3632 a b) ∨ (fact_9fdb227ae99d_3641 a b) ∨ (fact_9fdb227ae99d_5040 a b) ∨ (fact_9fdb227ae99d_5793 a b) ∨ (fact_9fdb227ae99d_4415 a b) ∨ (fact_9fdb227ae99d_3684 a b) ∨ (fact_9fdb227ae99d_3689 a b) ∨ (fact_9fdb227ae99d_3706 a b) ∨ (fact_9fdb227ae99d_3648 a b) ∨ (fact_9fdb227ae99d_4495 a b) ∨ (fact_9fdb227ae99d_5827 a b) ∨ (fact_9fdb227ae99d_5130 a b) ∨ (fact_9fdb227ae99d_5803 a b))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int)) ∨ (((0 : Int) + a) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((0 : Int) - (0 : Int)))))
    (h5 : (a > b))
    (h6 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n595_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_3206 a b))
    (h3 : (((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int)) ∨ (((0 : Int) + a) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((0 : Int) - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((fact_9fdb227ae99d_2431 a b run_x) ∨ (fact_9fdb227ae99d_2432 a b run_x) ∨ (fact_9fdb227ae99d_3059 a b run_x) ∨ (fact_9fdb227ae99d_3565 a b run_x) ∨ (fact_9fdb227ae99d_2974 a b run_x) ∨ (fact_9fdb227ae99d_2529 a b run_x) ∨ (fact_9fdb227ae99d_2530 a b run_x) ∨ ((((1 : Int) ≥ ((-3 : Int) - b)) ∧ ((1 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_2433 a b run_x) ∨ (fact_9fdb227ae99d_2975 a b run_x) ∨ (fact_9fdb227ae99d_3666 a b run_x) ∨ (fact_9fdb227ae99d_3117 a b run_x) ∨ (fact_9fdb227ae99d_3566 a b run_x)))
    (h7 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h8 : (((2 : Int) + a) ≤ run_x))
    (h9 : (run_x ≤ (b + a)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n595_run_floor (a b run_x : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (((2 : Int) + a) ≤ run_x))
    (h2 : (((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int)) ∨ (((0 : Int) + a) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((0 : Int) - (0 : Int)))))
    (h3 : (¬ ((fact_9fdb227ae99d_3172 a b run_x) ∨ (fact_9fdb227ae99d_3182 a b run_x) ∨ (fact_9fdb227ae99d_3725 a b run_x) ∨ (fact_9fdb227ae99d_5190 a b run_x) ∨ (fact_9fdb227ae99d_3484 a b run_x) ∨ (fact_9fdb227ae99d_3210 a b run_x) ∨ (fact_9fdb227ae99d_3226 a b run_x) ∨ (((((-3 : Int) - b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3192 a b run_x) ∨ (fact_9fdb227ae99d_3555 a b run_x) ∨ (fact_9fdb227ae99d_5358 a b run_x) ∨ (fact_9fdb227ae99d_3922 a b run_x) ∨ (fact_9fdb227ae99d_5261 a b run_x))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (run_x ≤ (b + a)))
    (h6 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (b = (5 : Int)))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n596_run_four (a b : Int)
    (h0 : (¬ ((-2 : Int) ≤ (1 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n596_run_short (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ (((1 : Int) - (-2 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n596_run_nonnegative (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((-2 : Int) + ((-1 : Int) * a)) ≤ (0 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n596_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5882 a b) ∨ (fact_9fdb227ae99d_5887 a b) ∨ (fact_9fdb227ae99d_6759 a b) ∨ (fact_9fdb227ae99d_7006 a b) ∨ (fact_9fdb227ae99d_6404 a b) ∨ (fact_9fdb227ae99d_5938 a b) ∨ (((((-2 : Int) - a) ≤ ((-2 : Int) - (1 : Int))) ∧ (((-2 : Int) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-2 : Int) ≤ ((-2 : Int) - (1 : Int))) ∧ ((-2 : Int) ≥ ((-2 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_5949 a b) ∨ (((((2 : Int) - (0 : Int)) ≤ ((-2 : Int) - (1 : Int))) ∧ (((-2 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((2 : Int) ≤ ((-2 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((-2 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((-2 : Int) - (1 : Int))) ∧ (((-2 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((-2 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((-2 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((-4 : Int) - (0 : Int)) ≤ ((-2 : Int) - (1 : Int))) ∧ (((-2 : Int) - (1 : Int)) ≤ ((-4 : Int) + b)) ∧ (((3 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a))) ∨ (((-4 : Int) ≤ ((-2 : Int) - (1 : Int))) ∧ ((-4 : Int) ≥ ((-2 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + a) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n596_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5814 a b) ∨ (fact_9fdb227ae99d_5816 a b) ∨ (fact_9fdb227ae99d_6674 a b) ∨ (fact_9fdb227ae99d_6999 a b) ∨ (fact_9fdb227ae99d_6339 a b) ∨ (fact_9fdb227ae99d_5874 a b) ∨ (fact_9fdb227ae99d_5876 a b) ∨ (fact_9fdb227ae99d_5879 a b) ∨ (fact_9fdb227ae99d_5818 a b) ∨ (fact_9fdb227ae99d_6359 a b) ∨ (fact_9fdb227ae99d_6437 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n596_run_tall (a b : Int)
    (h0 : (a ≥ b))
    (h1 : (¬ ((((1 : Int) ≥ ((-2 : Int) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7903 a b) ∨ (fact_9fdb227ae99d_7888 a b))) ∨ (((1 : Int) ≥ ((-2 : Int) + (2 : Int))) ∧ (fact_9fdb227ae99d_7903 a b) ∧ (fact_9fdb227ae99d_7888 a b)) ∨ ((1 : Int) ≥ ((-2 : Int) + (4 : Int))) ∨ (((1 : Int) = ((-2 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7903 a b) ∧ (fact_9fdb227ae99d_7888 a b) ∧ (((fact_9fdb227ae99d_6441 a b) ∨ (fact_9fdb227ae99d_6455 a b) ∨ (fact_9fdb227ae99d_6951 a b) ∨ (fact_9fdb227ae99d_7129 a b) ∨ (fact_9fdb227ae99d_6847 a b) ∨ (fact_9fdb227ae99d_6497 a b) ∨ (fact_9fdb227ae99d_6513 a b) ∨ (fact_9fdb227ae99d_6530 a b) ∨ (fact_9fdb227ae99d_6464 a b) ∨ (fact_9fdb227ae99d_6873 a b) ∨ (fact_9fdb227ae99d_6891 a b)) ∨ ((fact_9fdb227ae99d_6342 a b) ∨ (fact_9fdb227ae99d_6348 a b) ∨ (fact_9fdb227ae99d_6917 a b) ∨ (fact_9fdb227ae99d_7121 a b) ∨ (fact_9fdb227ae99d_6787 a b) ∨ (fact_9fdb227ae99d_6410 a b) ∨ (fact_9fdb227ae99d_6420 a b) ∨ (fact_9fdb227ae99d_6432 a b) ∨ (fact_9fdb227ae99d_6353 a b) ∨ (fact_9fdb227ae99d_6798 a b) ∨ (fact_9fdb227ae99d_6859 a b)))) ∨ ((fact_9fdb227ae99d_7903 a b) ∧ (fact_9fdb227ae99d_7888 a b) ∧ ((fact_9fdb227ae99d_6441 a b) ∨ (fact_9fdb227ae99d_6455 a b) ∨ (fact_9fdb227ae99d_6951 a b) ∨ (fact_9fdb227ae99d_7129 a b) ∨ (fact_9fdb227ae99d_6847 a b) ∨ (fact_9fdb227ae99d_6497 a b) ∨ (fact_9fdb227ae99d_6513 a b) ∨ (fact_9fdb227ae99d_6530 a b) ∨ (fact_9fdb227ae99d_6464 a b) ∨ (fact_9fdb227ae99d_6873 a b) ∨ (fact_9fdb227ae99d_6891 a b)) ∧ ((fact_9fdb227ae99d_6342 a b) ∨ (fact_9fdb227ae99d_6348 a b) ∨ (fact_9fdb227ae99d_6917 a b) ∨ (fact_9fdb227ae99d_7121 a b) ∨ (fact_9fdb227ae99d_6787 a b) ∨ (fact_9fdb227ae99d_6410 a b) ∨ (fact_9fdb227ae99d_6420 a b) ∨ (fact_9fdb227ae99d_6432 a b) ∨ (fact_9fdb227ae99d_6353 a b) ∨ (fact_9fdb227ae99d_6798 a b) ∨ (fact_9fdb227ae99d_6859 a b))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n596_run_empty (a b run_x : Int)
    (h0 : ((1 : Int) ≥ run_x))
    (h1 : (a > b))
    (h2 : ((fact_9fdb227ae99d_4083 a b run_x) ∨ (fact_9fdb227ae99d_4111 a b run_x) ∨ (fact_9fdb227ae99d_5317 a b run_x) ∨ (fact_9fdb227ae99d_5932 a b run_x) ∨ (fact_9fdb227ae99d_4746 a b run_x) ∨ (fact_9fdb227ae99d_4220 a b run_x) ∨ (fact_9fdb227ae99d_4257 a b run_x) ∨ (fact_9fdb227ae99d_4305 a b run_x) ∨ (fact_9fdb227ae99d_4125 a b run_x) ∨ (fact_9fdb227ae99d_5017 a b run_x) ∨ (fact_9fdb227ae99d_5094 a b run_x)))
    (h3 : (a ≥ b))
    (h4 : ((-2 : Int) ≤ run_x))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n596_run_floor (a b run_x : Int)
    (h0 : ((-2 : Int) ≤ run_x))
    (h1 : ((1 : Int) ≥ run_x))
    (h2 : (¬ ((fact_9fdb227ae99d_5622 a b run_x) ∨ (fact_9fdb227ae99d_5624 a b run_x) ∨ (fact_9fdb227ae99d_6337 a b run_x) ∨ (fact_9fdb227ae99d_6922 a b run_x) ∨ (fact_9fdb227ae99d_5934 a b run_x) ∨ (fact_9fdb227ae99d_5670 a b run_x) ∨ (fact_9fdb227ae99d_5672 a b run_x) ∨ (fact_9fdb227ae99d_5677 a b run_x) ∨ (fact_9fdb227ae99d_5626 a b run_x) ∨ (fact_9fdb227ae99d_5957 a b run_x) ∨ (fact_9fdb227ae99d_6002 a b run_x))))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n597_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≤ a)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n597_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((a - (3 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n597_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n597_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3584 a b) ∨ (fact_9fdb227ae99d_3588 a b) ∨ (fact_9fdb227ae99d_4721 a b) ∨ (fact_9fdb227ae99d_5751 a b) ∨ (fact_9fdb227ae99d_4340 a b) ∨ (fact_9fdb227ae99d_3622 a b) ∨ (((((-2 : Int) - a) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-2 : Int) ≤ (-(5 : Int))) ∧ ((-2 : Int) ≥ (-(5 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - b) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-3 : Int) ≤ (-(5 : Int))) ∧ ((-3 : Int) ≥ (-(5 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3590 a b) ∨ (fact_9fdb227ae99d_4390 a b) ∨ (fact_9fdb227ae99d_4485 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n597_run_right (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ ((fact_9fdb227ae99d_3157 a b) ∨ (fact_9fdb227ae99d_3161 a b) ∨ (fact_9fdb227ae99d_3671 a b) ∨ (fact_9fdb227ae99d_5108 a b) ∨ (fact_9fdb227ae99d_3389 a b) ∨ (fact_9fdb227ae99d_3166 a b) ∨ (((((-2 : Int) - a) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ (((-2 : Int) ≤ (-(5 : Int))) ∧ ((-2 : Int) ≥ (-(5 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - b) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ (((-3 : Int) ≤ (-(5 : Int))) ∧ ((-3 : Int) ≥ (-(5 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3162 a b) ∨ (fact_9fdb227ae99d_3463 a b) ∨ (fact_9fdb227ae99d_3548 a b))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n597_run_tall (a b : Int)
    (h0 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_9fdb227ae99d_7660 a b) ∨ (fact_9fdb227ae99d_7539 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_9fdb227ae99d_7660 a b) ∧ (fact_9fdb227ae99d_7539 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7660 a b) ∧ (fact_9fdb227ae99d_7539 a b) ∧ (((fact_9fdb227ae99d_4351 a b) ∨ (fact_9fdb227ae99d_4368 a b) ∨ (fact_9fdb227ae99d_5461 a b) ∨ (fact_9fdb227ae99d_6184 a b) ∨ (fact_9fdb227ae99d_5119 a b) ∨ (fact_9fdb227ae99d_4424 a b) ∨ (fact_9fdb227ae99d_4448 a b) ∨ (fact_9fdb227ae99d_4477 a b) ∨ (fact_9fdb227ae99d_4378 a b) ∨ (fact_9fdb227ae99d_5148 a b) ∨ (fact_9fdb227ae99d_5250 a b)) ∨ ((fact_9fdb227ae99d_3424 a b) ∨ (fact_9fdb227ae99d_3442 a b) ∨ (fact_9fdb227ae99d_4517 a b) ∨ (fact_9fdb227ae99d_5601 a b) ∨ (fact_9fdb227ae99d_3889 a b) ∨ (fact_9fdb227ae99d_3504 a b) ∨ (fact_9fdb227ae99d_3523 a b) ∨ (fact_9fdb227ae99d_3543 a b) ∨ (fact_9fdb227ae99d_3452 a b) ∨ (fact_9fdb227ae99d_4147 a b) ∨ (fact_9fdb227ae99d_4306 a b)))) ∨ ((fact_9fdb227ae99d_7660 a b) ∧ (fact_9fdb227ae99d_7539 a b) ∧ ((fact_9fdb227ae99d_4351 a b) ∨ (fact_9fdb227ae99d_4368 a b) ∨ (fact_9fdb227ae99d_5461 a b) ∨ (fact_9fdb227ae99d_6184 a b) ∨ (fact_9fdb227ae99d_5119 a b) ∨ (fact_9fdb227ae99d_4424 a b) ∨ (fact_9fdb227ae99d_4448 a b) ∨ (fact_9fdb227ae99d_4477 a b) ∨ (fact_9fdb227ae99d_4378 a b) ∨ (fact_9fdb227ae99d_5148 a b) ∨ (fact_9fdb227ae99d_5250 a b)) ∧ ((fact_9fdb227ae99d_3424 a b) ∨ (fact_9fdb227ae99d_3442 a b) ∨ (fact_9fdb227ae99d_4517 a b) ∨ (fact_9fdb227ae99d_5601 a b) ∨ (fact_9fdb227ae99d_3889 a b) ∨ (fact_9fdb227ae99d_3504 a b) ∨ (fact_9fdb227ae99d_3523 a b) ∨ (fact_9fdb227ae99d_3543 a b) ∨ (fact_9fdb227ae99d_3452 a b) ∨ (fact_9fdb227ae99d_4147 a b) ∨ (fact_9fdb227ae99d_4306 a b))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n597_run_empty (a b run_x : Int)
    (h0 : ((fact_9fdb227ae99d_2589 a b run_x) ∨ (fact_9fdb227ae99d_2594 a b run_x) ∨ (fact_9fdb227ae99d_3155 a b run_x) ∨ (fact_9fdb227ae99d_3675 a b run_x) ∨ (fact_9fdb227ae99d_3033 a b run_x) ∨ (fact_9fdb227ae99d_2695 a b run_x) ∨ (((((-2 : Int) - a) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ (-(5 : Int))) ∧ ((-2 : Int) ≥ (-(5 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - b) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ (-(5 : Int))) ∧ ((-3 : Int) ≥ (-(5 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_2633 a b run_x) ∨ (fact_9fdb227ae99d_3036 a b run_x) ∨ (fact_9fdb227ae99d_3047 a b run_x)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((3 : Int) ≤ run_x))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (run_x ≤ a))
    (h5 : (b = (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (((-2 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-2 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) > ((1 : Int) + b))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n597_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3322 a b run_x) ∨ (fact_9fdb227ae99d_3326 a b run_x) ∨ (fact_9fdb227ae99d_4337 a b run_x) ∨ (fact_9fdb227ae99d_5471 a b run_x) ∨ (fact_9fdb227ae99d_3679 a b run_x) ∨ (fact_9fdb227ae99d_3354 a b run_x) ∨ (((((-2 : Int) - a) ≤ (-((5 : Int) - (1 : Int)))) ∧ ((-((5 : Int) - (1 : Int))) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ (-((5 : Int) - (1 : Int)))) ∧ ((-2 : Int) ≥ (-((5 : Int) - (1 : Int)))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - b) ≤ (-((5 : Int) - (1 : Int)))) ∧ ((-((5 : Int) - (1 : Int))) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ (-((5 : Int) - (1 : Int)))) ∧ ((-3 : Int) ≥ (-((5 : Int) - (1 : Int)))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3328 a b run_x) ∨ (fact_9fdb227ae99d_3721 a b run_x) ∨ (fact_9fdb227ae99d_3747 a b run_x))))
    (h1 : ((3 : Int) ≤ run_x))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (run_x ≤ a))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n598_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (fact_9fdb227ae99d_29 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n598_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((fact_9fdb227ae99d_3086 a b) ∨ (fact_9fdb227ae99d_3087 a b) ∨ (fact_9fdb227ae99d_3593 a b) ∨ (fact_9fdb227ae99d_5028 a b) ∨ (fact_9fdb227ae99d_3330 a b) ∨ (fact_9fdb227ae99d_3125 a b) ∨ (fact_9fdb227ae99d_3127 a b) ∨ (fact_9fdb227ae99d_3130 a b) ∨ (fact_9fdb227ae99d_3088 a b) ∨ (fact_9fdb227ae99d_3333 a b) ∨ (fact_9fdb227ae99d_3132 a b)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n598_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((jx + a) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_1974 a b jx jy))
    (h4 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h7 : (b = (5 : Int)))
    (h8 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n598_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + b + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (fact_9fdb227ae99d_1977 a b jx jy))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n598_o2 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + ((2 : Int) * b))) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - b))))
    (h6 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h7 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h8 : (fact_9fdb227ae99d_1979 a b jx jy))
    (h9 : ((jy - b) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n598_o3 (a b jx jy : Int)
    (h0 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h1 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_9fdb227ae99d_1980 a b jx jy))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (b = (5 : Int)))
    (h8 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n598_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1981 a b jx jy))
    (h1 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + b + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h2 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n598_o5 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h7 : (fact_9fdb227ae99d_1978 a b jx jy))
    (h8 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h9 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n598_o6 (a b jx jy : Int)
    (h0 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h1 : (fact_9fdb227ae99d_1976 a b jx jy))
    (h2 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h3 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jx < ((-3 : Int) - b)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (((jx + b) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (b = (5 : Int)))
    (h11 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    (h14 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n598_o7 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_2925 a b jy))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h8 : (fact_9fdb227ae99d_1975 a b jx jy))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n599_run_four (a b : Int)
    (h0 : (¬ (((1 : Int) + a) ≤ (b + a))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n599_run_short (a b : Int)
    (h0 : (¬ (((b + a) - ((1 : Int) + a)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n599_run_nonnegative (a b : Int)
    (h0 : (¬ (((1 : Int) + a) ≥ (0 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n599_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3842 a b) ∨ (fact_9fdb227ae99d_3843 a b) ∨ (fact_9fdb227ae99d_5285 a b) ∨ (fact_9fdb227ae99d_5899 a b) ∨ (fact_9fdb227ae99d_4702 a b) ∨ (fact_9fdb227ae99d_4173 a b) ∨ (fact_9fdb227ae99d_4174 a b) ∨ (fact_9fdb227ae99d_4177 a b) ∨ (fact_9fdb227ae99d_3844 a b) ∨ (fact_9fdb227ae99d_4703 a b) ∨ (fact_9fdb227ae99d_4179 a b) ∨ (fact_9fdb227ae99d_5345 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n599_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3287 a b) ∨ (fact_9fdb227ae99d_3288 a b) ∨ (fact_9fdb227ae99d_4317 a b) ∨ (fact_9fdb227ae99d_5448 a b) ∨ (fact_9fdb227ae99d_3664 a b) ∨ (fact_9fdb227ae99d_3340 a b) ∨ (fact_9fdb227ae99d_3342 a b) ∨ (fact_9fdb227ae99d_3346 a b) ∨ (fact_9fdb227ae99d_3289 a b) ∨ (fact_9fdb227ae99d_3665 a b) ∨ (fact_9fdb227ae99d_3348 a b) ∨ (fact_9fdb227ae99d_4399 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n599_run_tall (a b : Int)
    (h0 : (¬ ((((((1 : Int) + a) + (3 : Int)) ≤ (b + a)) ∧ ((fact_9fdb227ae99d_7799 a b) ∨ (fact_9fdb227ae99d_7709 a b))) ∨ (((((1 : Int) + a) + (2 : Int)) ≤ (b + a)) ∧ (fact_9fdb227ae99d_7799 a b) ∧ (fact_9fdb227ae99d_7709 a b)) ∨ ((((1 : Int) + a) + (4 : Int)) ≤ (b + a)) ∨ (((b + a) = (((1 : Int) + a) + (1 : Int))) ∧ (fact_9fdb227ae99d_7799 a b) ∧ (fact_9fdb227ae99d_7709 a b) ∧ (((fact_9fdb227ae99d_4587 a b) ∨ (fact_9fdb227ae99d_4622 a b) ∨ (fact_9fdb227ae99d_5652 a b) ∨ (fact_9fdb227ae99d_6391 a b) ∨ (fact_9fdb227ae99d_5381 a b) ∨ (fact_9fdb227ae99d_4763 a b) ∨ (fact_9fdb227ae99d_4805 a b) ∨ (fact_9fdb227ae99d_4890 a b) ∨ (fact_9fdb227ae99d_4645 a b) ∨ (fact_9fdb227ae99d_5431 a b) ∨ (fact_9fdb227ae99d_4938 a b) ∨ (fact_9fdb227ae99d_5752 a b)) ∨ ((fact_9fdb227ae99d_3630 a b) ∨ (fact_9fdb227ae99d_3639 a b) ∨ (fact_9fdb227ae99d_5038 a b) ∨ (fact_9fdb227ae99d_5791 a b) ∨ (fact_9fdb227ae99d_4413 a b) ∨ (fact_9fdb227ae99d_3682 a b) ∨ (fact_9fdb227ae99d_3687 a b) ∨ (fact_9fdb227ae99d_3702 a b) ∨ (fact_9fdb227ae99d_3646 a b) ∨ (fact_9fdb227ae99d_4493 a b) ∨ (fact_9fdb227ae99d_3717 a b) ∨ (fact_9fdb227ae99d_5128 a b)))) ∨ ((fact_9fdb227ae99d_7799 a b) ∧ (fact_9fdb227ae99d_7709 a b) ∧ ((fact_9fdb227ae99d_4587 a b) ∨ (fact_9fdb227ae99d_4622 a b) ∨ (fact_9fdb227ae99d_5652 a b) ∨ (fact_9fdb227ae99d_6391 a b) ∨ (fact_9fdb227ae99d_5381 a b) ∨ (fact_9fdb227ae99d_4763 a b) ∨ (fact_9fdb227ae99d_4805 a b) ∨ (fact_9fdb227ae99d_4890 a b) ∨ (fact_9fdb227ae99d_4645 a b) ∨ (fact_9fdb227ae99d_5431 a b) ∨ (fact_9fdb227ae99d_4938 a b) ∨ (fact_9fdb227ae99d_5752 a b)) ∧ ((fact_9fdb227ae99d_3630 a b) ∨ (fact_9fdb227ae99d_3639 a b) ∨ (fact_9fdb227ae99d_5038 a b) ∨ (fact_9fdb227ae99d_5791 a b) ∨ (fact_9fdb227ae99d_4413 a b) ∨ (fact_9fdb227ae99d_3682 a b) ∨ (fact_9fdb227ae99d_3687 a b) ∨ (fact_9fdb227ae99d_3702 a b) ∨ (fact_9fdb227ae99d_3646 a b) ∨ (fact_9fdb227ae99d_4493 a b) ∨ (fact_9fdb227ae99d_3717 a b) ∨ (fact_9fdb227ae99d_5128 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n599_run_empty (a b run_x : Int)
    (h0 : (fact_9fdb227ae99d_3207 a b))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h4 : (run_x ≤ (b + a)))
    (h5 : (((1 : Int) + a) ≤ run_x))
    (h6 : (b = (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((fact_9fdb227ae99d_2416 a b run_x) ∨ (fact_9fdb227ae99d_2417 a b run_x) ∨ (fact_9fdb227ae99d_3049 a b run_x) ∨ (fact_9fdb227ae99d_3564 a b run_x) ∨ (fact_9fdb227ae99d_2972 a b run_x) ∨ (fact_9fdb227ae99d_2518 a b run_x) ∨ (fact_9fdb227ae99d_2519 a b run_x) ∨ (fact_9fdb227ae99d_2522 a b run_x) ∨ (fact_9fdb227ae99d_2418 a b run_x) ∨ (fact_9fdb227ae99d_2973 a b run_x) ∨ (fact_9fdb227ae99d_2524 a b run_x) ∨ (fact_9fdb227ae99d_3110 a b run_x)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n599_run_floor (a b run_x : Int)
    (h0 : (((1 : Int) + a) ≤ run_x))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (run_x ≤ (b + a)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (¬ ((fact_9fdb227ae99d_3171 a b run_x) ∨ (fact_9fdb227ae99d_3181 a b run_x) ∨ (fact_9fdb227ae99d_3724 a b run_x) ∨ (fact_9fdb227ae99d_5189 a b run_x) ∨ (fact_9fdb227ae99d_3483 a b run_x) ∨ (fact_9fdb227ae99d_3209 a b run_x) ∨ (fact_9fdb227ae99d_3225 a b run_x) ∨ (fact_9fdb227ae99d_3246 a b run_x) ∨ (fact_9fdb227ae99d_3191 a b run_x) ∨ (fact_9fdb227ae99d_3554 a b run_x) ∨ (fact_9fdb227ae99d_3253 a b run_x) ∨ (fact_9fdb227ae99d_3895 a b run_x))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n600_run_four (a b : Int)
    (h0 : (¬ (((2 : Int) + b) ≤ ((3 : Int) + a))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n600_run_short (a b : Int)
    (h0 : (((-4 : Int) < ((-1 : Int) - a)) ∨ ((-4 : Int) > ((-1 : Int) + (0 : Int))) ∨ (((3 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((3 : Int) - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ ((((3 : Int) + a) - ((2 : Int) + b)) < b)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n600_run_nonnegative (a b : Int)
    (h0 : (¬ (((2 : Int) + b) ≥ (0 : Int))))
    (h1 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n600_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_4356 a b) ∨ (fact_9fdb227ae99d_4373 a b) ∨ (fact_9fdb227ae99d_5466 a b) ∨ (fact_9fdb227ae99d_6189 a b) ∨ (fact_9fdb227ae99d_5124 a b) ∨ (fact_9fdb227ae99d_4427 a b) ∨ (fact_9fdb227ae99d_4451 a b) ∨ (fact_9fdb227ae99d_4480 a b) ∨ (fact_9fdb227ae99d_4383 a b) ∨ (fact_9fdb227ae99d_5152 a b) ∨ (((((-4 : Int) - b) ≤ (-(2 : Int))) ∧ ((-(2 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (((2 : Int) + b) - (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + b) - (1 : Int)))) ∨ (((-4 : Int) ≤ (-(2 : Int))) ∧ ((-4 : Int) ≥ (-(2 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (((2 : Int) + b) - (1 : Int))) ∧ ((((2 : Int) + b) - (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_6326 a b))))
    (h1 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_3478 a b))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n600_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (((-4 : Int) < ((-1 : Int) - a)) ∨ ((-4 : Int) > ((-1 : Int) + (0 : Int))) ∨ (((3 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((3 : Int) - (0 : Int)))))
    (h3 : (b = (5 : Int)))
    (h4 : (¬ ((fact_9fdb227ae99d_4357 a b) ∨ (fact_9fdb227ae99d_4374 a b) ∨ (fact_9fdb227ae99d_5467 a b) ∨ (fact_9fdb227ae99d_6190 a b) ∨ (fact_9fdb227ae99d_5125 a b) ∨ (fact_9fdb227ae99d_4428 a b) ∨ (fact_9fdb227ae99d_4452 a b) ∨ (fact_9fdb227ae99d_4481 a b) ∨ (fact_9fdb227ae99d_4384 a b) ∨ (fact_9fdb227ae99d_5153 a b) ∨ (((((-4 : Int) - b) ≤ (-(2 : Int))) ∧ ((-(2 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + a) + (1 : Int)))) ∨ (((-4 : Int) ≤ (-(2 : Int))) ∧ ((-4 : Int) ≥ (-(2 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_6327 a b))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n600_run_tall (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((-4 : Int) < ((-1 : Int) - a)) ∨ ((-4 : Int) > ((-1 : Int) + (0 : Int))) ∨ (((3 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((3 : Int) - (0 : Int)))))
    (h2 : (b = (5 : Int)))
    (h3 : (¬ ((((((2 : Int) + b) + (3 : Int)) ≤ ((3 : Int) + a)) ∧ ((fact_9fdb227ae99d_7846 a b) ∨ (fact_9fdb227ae99d_7850 a b))) ∨ (((((2 : Int) + b) + (2 : Int)) ≤ ((3 : Int) + a)) ∧ (fact_9fdb227ae99d_7846 a b) ∧ (fact_9fdb227ae99d_7850 a b)) ∨ ((((2 : Int) + b) + (4 : Int)) ≤ ((3 : Int) + a)) ∨ ((((3 : Int) + a) = (((2 : Int) + b) + (1 : Int))) ∧ (fact_9fdb227ae99d_7846 a b) ∧ (fact_9fdb227ae99d_7850 a b) ∧ (((fact_9fdb227ae99d_5132 a b) ∨ (fact_9fdb227ae99d_5136 a b) ∨ (fact_9fdb227ae99d_5807 a b) ∨ (fact_9fdb227ae99d_6676 a b) ∨ (fact_9fdb227ae99d_5605 a b) ∨ (fact_9fdb227ae99d_5203 a b) ∨ (fact_9fdb227ae99d_5210 a b) ∨ (fact_9fdb227ae99d_5235 a b) ∨ (fact_9fdb227ae99d_5140 a b) ∨ (fact_9fdb227ae99d_5628 a b) ∨ (fact_9fdb227ae99d_5253 a b) ∨ (fact_9fdb227ae99d_6772 a b)) ∨ ((fact_9fdb227ae99d_5133 a b) ∨ (fact_9fdb227ae99d_5137 a b) ∨ (fact_9fdb227ae99d_5808 a b) ∨ (fact_9fdb227ae99d_6677 a b) ∨ (fact_9fdb227ae99d_5606 a b) ∨ (fact_9fdb227ae99d_5204 a b) ∨ (fact_9fdb227ae99d_5211 a b) ∨ (fact_9fdb227ae99d_5236 a b) ∨ (fact_9fdb227ae99d_5141 a b) ∨ (fact_9fdb227ae99d_5629 a b) ∨ (fact_9fdb227ae99d_5254 a b) ∨ (fact_9fdb227ae99d_6773 a b)))) ∨ ((fact_9fdb227ae99d_7846 a b) ∧ (fact_9fdb227ae99d_7850 a b) ∧ ((fact_9fdb227ae99d_5132 a b) ∨ (fact_9fdb227ae99d_5136 a b) ∨ (fact_9fdb227ae99d_5807 a b) ∨ (fact_9fdb227ae99d_6676 a b) ∨ (fact_9fdb227ae99d_5605 a b) ∨ (fact_9fdb227ae99d_5203 a b) ∨ (fact_9fdb227ae99d_5210 a b) ∨ (fact_9fdb227ae99d_5235 a b) ∨ (fact_9fdb227ae99d_5140 a b) ∨ (fact_9fdb227ae99d_5628 a b) ∨ (fact_9fdb227ae99d_5253 a b) ∨ (fact_9fdb227ae99d_6772 a b)) ∧ ((fact_9fdb227ae99d_5133 a b) ∨ (fact_9fdb227ae99d_5137 a b) ∨ (fact_9fdb227ae99d_5808 a b) ∨ (fact_9fdb227ae99d_6677 a b) ∨ (fact_9fdb227ae99d_5606 a b) ∨ (fact_9fdb227ae99d_5204 a b) ∨ (fact_9fdb227ae99d_5211 a b) ∨ (fact_9fdb227ae99d_5236 a b) ∨ (fact_9fdb227ae99d_5141 a b) ∨ (fact_9fdb227ae99d_5629 a b) ∨ (fact_9fdb227ae99d_5254 a b) ∨ (fact_9fdb227ae99d_6773 a b))))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n600_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((2 : Int) + b) ≤ run_x))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((fact_9fdb227ae99d_2586 a b run_x) ∨ (fact_9fdb227ae99d_2591 a b run_x) ∨ (fact_9fdb227ae99d_3152 a b run_x) ∨ (fact_9fdb227ae99d_3672 a b run_x) ∨ (fact_9fdb227ae99d_3030 a b run_x) ∨ (fact_9fdb227ae99d_2692 a b run_x) ∨ (fact_9fdb227ae99d_2712 a b run_x) ∨ (fact_9fdb227ae99d_2733 a b run_x) ∨ (fact_9fdb227ae99d_2632 a b run_x) ∨ (fact_9fdb227ae99d_3035 a b run_x) ∨ (((((-4 : Int) - b) ≤ (-(2 : Int))) ∧ ((-(2 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((-4 : Int) ≤ (-(2 : Int))) ∧ ((-4 : Int) ≥ (-(2 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_3742 a b run_x)))
    (h5 : (((-4 : Int) < ((-1 : Int) - a)) ∨ ((-4 : Int) > ((-1 : Int) + (0 : Int))) ∨ (((3 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((3 : Int) - (0 : Int)))))
    (h6 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h7 : (run_x ≤ ((3 : Int) + a)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n600_run_floor (a b run_x : Int)
    (h0 : (((-4 : Int) < ((-1 : Int) - a)) ∨ ((-4 : Int) > ((-1 : Int) + (0 : Int))) ∨ (((3 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((3 : Int) - (0 : Int)))))
    (h1 : (((2 : Int) + b) ≤ run_x))
    (h2 : (run_x ≤ ((3 : Int) + a)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (¬ ((fact_9fdb227ae99d_3319 a b run_x) ∨ (fact_9fdb227ae99d_3323 a b run_x) ∨ (fact_9fdb227ae99d_4334 a b run_x) ∨ (fact_9fdb227ae99d_5468 a b run_x) ∨ (fact_9fdb227ae99d_3676 a b run_x) ∨ (fact_9fdb227ae99d_3351 a b run_x) ∨ (fact_9fdb227ae99d_3357 a b run_x) ∨ (fact_9fdb227ae99d_3362 a b run_x) ∨ (fact_9fdb227ae99d_3327 a b run_x) ∨ (fact_9fdb227ae99d_3720 a b run_x) ∨ (((((-4 : Int) - b) ≤ (-((2 : Int) - (1 : Int)))) ∧ ((-((2 : Int) - (1 : Int))) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((-4 : Int) ≤ (-((2 : Int) - (1 : Int)))) ∧ ((-4 : Int) ≥ (-((2 : Int) - (1 : Int)))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_5550 a b run_x))))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (b = (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n601_point (a b : Int)
    (h0 : (¬ (((-3 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ (((3 : Int) + a) ≥ (0 : Int)) ∧ ((-3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ (((3 : Int) + a) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n601_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h2 : (a ≥ b))
    (h3 : (((((-3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((3 : Int) + a)) ∧ ((0 : Int) ≥ ((3 : Int) + a))) ∨ (((0 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((0 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ (((1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + a)))) ∨ ((((-3 : Int) ≥ (((1 : Int) + b + a) - a)) ∧ ((-3 : Int) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) + a)) ∧ ((0 : Int) ≥ ((3 : Int) + a))) ∨ (((-3 : Int) ≥ ((1 : Int) + b + a)) ∧ ((-3 : Int) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((-3 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - b)) ∧ ((-3 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ (((-3 : Int) ≥ ((2 : Int) + ((2 : Int) * b))) ∧ ((-3 : Int) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + a)))) ∨ ((((-3 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((-3 : Int) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) + a))) ∨ (((-3 : Int) ≥ ((2 : Int) + a)) ∧ ((-3 : Int) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((2 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-1 : Int) - a)) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) + a)) ∧ ((0 : Int) ≥ ((3 : Int) + a))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-2 : Int) - a)) ∧ ((-3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ (((-2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-2 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-3 : Int) - b)) ∧ ((-3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) + a))) ∨ (((-3 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≥ ((3 : Int) + a))) ∨ (((2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (2 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((3 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (3 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((-3 : Int) ≥ ((-4 : Int) - b)) ∧ ((-3 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≥ ((3 : Int) + a))) ∨ (((-4 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((3 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((-1 : Int) - b)) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ ((((1 : Int) + b + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((1 : Int) + b + a) + (0 : Int)))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n601_o0 (a b jx jy : Int)
    (h0 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ (jy ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (jy + b)))))
    (h1 : (((-4 : Int) > (jx + a)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h2 : (b = (5 : Int)))
    (h3 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n601_o1 (a b jx jy : Int)
    (h0 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ (jy ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (jy + (0 : Int))))))
    (h6 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (((-4 : Int) > (jx + b)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h9 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - a))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n601_o2 (a b jx jy : Int)
    (h0 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - b))))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h5 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (jy + (0 : Int))))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h8 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - b))))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n601_o3 (a b jx jy : Int)
    (h0 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h1 : (((jx + (0 : Int)) < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < (jx - b)) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h2 : (((jx + (0 : Int)) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - b)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h3 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (jy + a)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((jx + (0 : Int)) < ((-3 : Int) - b)) ∨ (((-3 : Int) + (0 : Int)) < (jx - b)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h10 : (a ≥ (5 : Int)))
    (h11 : (b = (5 : Int)))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    (h14 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n601_o4 (a b jx jy : Int)
    (h0 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - a))))
    (h1 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - a))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h4 : (b = (5 : Int)))
    (h5 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (jy + (0 : Int))))))
    (h6 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((jy - a) ≥ (0 : Int)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n601_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((jx + (0 : Int)) < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < (jx - a)) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h2 : (b = (5 : Int)))
    (h3 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (jy + b)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((jx + (0 : Int)) < ((-3 : Int) - b)) ∨ (((-3 : Int) + (0 : Int)) < (jx - a)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h8 : (((jx + (0 : Int)) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - a)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h11 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    (h14 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n601_o6 (a b jx jy : Int)
    (h0 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ (jy ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (jy + a)))))
    (h3 : (((-4 : Int) > (jx + b)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h4 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jx < ((-3 : Int) - b)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (b = (5 : Int)))
    (h9 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n601_o7 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - b))))
    (h4 : (((-4 : Int) > (jx + a)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h7 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ (jy ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (jy + (0 : Int))))))
    (h8 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - b))))
    (h9 : (b = (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n602_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_29 a b))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n602_empty (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((fact_9fdb227ae99d_3086 a b) ∨ (fact_9fdb227ae99d_3087 a b) ∨ (fact_9fdb227ae99d_3593 a b) ∨ (fact_9fdb227ae99d_5028 a b) ∨ (fact_9fdb227ae99d_3330 a b) ∨ (fact_9fdb227ae99d_3125 a b) ∨ (fact_9fdb227ae99d_3127 a b) ∨ (fact_9fdb227ae99d_3130 a b) ∨ (fact_9fdb227ae99d_3088 a b) ∨ (fact_9fdb227ae99d_3333 a b) ∨ (fact_9fdb227ae99d_3380 a b)))
    (h2 : (((0 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((0 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + a)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n602_o0 (a b jx jy : Int)
    (h0 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_1974 a b jx jy))
    (h3 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h4 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n602_o1 (a b jx jy : Int)
    (h0 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + b + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_1977 a b jx jy))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n602_o2 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - b))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h4 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + ((2 : Int) * b))) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h5 : (b = (5 : Int)))
    (h6 : (fact_9fdb227ae99d_1979 a b jx jy))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n602_o3 (a b jx jy : Int)
    (h0 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (fact_9fdb227ae99d_1980 a b jx jy))
    (h7 : (((jx + (0 : Int)) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - b)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h8 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h9 : (fact_9fdb227ae99d_107 a b))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n602_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_1981 a b jx jy))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h4 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + b + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h5 : (b = (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n602_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_1978 a b jx jy))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b = (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h7 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h8 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n602_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((jx + b) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h2 : (fact_9fdb227ae99d_1976 a b jx jy))
    (h3 : (b = (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h6 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h7 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : ((jx < ((-3 : Int) - b)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h10 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h11 : (b ≥ (3 : Int)))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    (h14 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n602_o7 (a b jx jy : Int)
    (h0 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (fact_9fdb227ae99d_1975 a b jx jy))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - b))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n603_run_four (a b : Int)
    (h0 : (¬ (((1 : Int) + a) ≤ (b + a))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n603_run_short (a b : Int)
    (h0 : (¬ (((b + a) - ((1 : Int) + a)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n603_run_nonnegative (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((1 : Int) + a) ≥ (0 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n603_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3842 a b) ∨ (fact_9fdb227ae99d_3843 a b) ∨ (fact_9fdb227ae99d_5285 a b) ∨ (fact_9fdb227ae99d_5899 a b) ∨ (fact_9fdb227ae99d_4702 a b) ∨ (fact_9fdb227ae99d_4173 a b) ∨ (fact_9fdb227ae99d_4174 a b) ∨ (fact_9fdb227ae99d_4177 a b) ∨ (fact_9fdb227ae99d_3844 a b) ∨ (fact_9fdb227ae99d_4703 a b) ∨ (fact_9fdb227ae99d_5034 a b) ∨ (fact_9fdb227ae99d_5345 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n603_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3287 a b) ∨ (fact_9fdb227ae99d_3288 a b) ∨ (fact_9fdb227ae99d_4317 a b) ∨ (fact_9fdb227ae99d_5448 a b) ∨ (fact_9fdb227ae99d_3664 a b) ∨ (fact_9fdb227ae99d_3340 a b) ∨ (fact_9fdb227ae99d_3342 a b) ∨ (fact_9fdb227ae99d_3346 a b) ∨ (fact_9fdb227ae99d_3289 a b) ∨ (fact_9fdb227ae99d_3665 a b) ∨ (fact_9fdb227ae99d_3722 a b) ∨ (fact_9fdb227ae99d_4399 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n603_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ ((((((1 : Int) + a) + (3 : Int)) ≤ (b + a)) ∧ ((fact_9fdb227ae99d_7812 a b) ∨ (fact_9fdb227ae99d_7731 a b))) ∨ (((((1 : Int) + a) + (2 : Int)) ≤ (b + a)) ∧ (fact_9fdb227ae99d_7812 a b) ∧ (fact_9fdb227ae99d_7731 a b)) ∨ ((((1 : Int) + a) + (4 : Int)) ≤ (b + a)) ∨ (((b + a) = (((1 : Int) + a) + (1 : Int))) ∧ (fact_9fdb227ae99d_7812 a b) ∧ (fact_9fdb227ae99d_7731 a b) ∧ (((fact_9fdb227ae99d_4587 a b) ∨ (fact_9fdb227ae99d_4622 a b) ∨ (fact_9fdb227ae99d_5652 a b) ∨ (fact_9fdb227ae99d_6391 a b) ∨ (fact_9fdb227ae99d_5381 a b) ∨ (fact_9fdb227ae99d_4763 a b) ∨ (fact_9fdb227ae99d_4805 a b) ∨ (fact_9fdb227ae99d_4890 a b) ∨ (fact_9fdb227ae99d_4645 a b) ∨ (fact_9fdb227ae99d_5431 a b) ∨ (fact_9fdb227ae99d_5510 a b) ∨ (fact_9fdb227ae99d_5752 a b)) ∨ ((fact_9fdb227ae99d_3630 a b) ∨ (fact_9fdb227ae99d_3639 a b) ∨ (fact_9fdb227ae99d_5038 a b) ∨ (fact_9fdb227ae99d_5791 a b) ∨ (fact_9fdb227ae99d_4413 a b) ∨ (fact_9fdb227ae99d_3682 a b) ∨ (fact_9fdb227ae99d_3687 a b) ∨ (fact_9fdb227ae99d_3702 a b) ∨ (fact_9fdb227ae99d_3646 a b) ∨ (fact_9fdb227ae99d_4493 a b) ∨ (fact_9fdb227ae99d_4527 a b) ∨ (fact_9fdb227ae99d_5128 a b)))) ∨ ((fact_9fdb227ae99d_7812 a b) ∧ (fact_9fdb227ae99d_7731 a b) ∧ ((fact_9fdb227ae99d_4587 a b) ∨ (fact_9fdb227ae99d_4622 a b) ∨ (fact_9fdb227ae99d_5652 a b) ∨ (fact_9fdb227ae99d_6391 a b) ∨ (fact_9fdb227ae99d_5381 a b) ∨ (fact_9fdb227ae99d_4763 a b) ∨ (fact_9fdb227ae99d_4805 a b) ∨ (fact_9fdb227ae99d_4890 a b) ∨ (fact_9fdb227ae99d_4645 a b) ∨ (fact_9fdb227ae99d_5431 a b) ∨ (fact_9fdb227ae99d_5510 a b) ∨ (fact_9fdb227ae99d_5752 a b)) ∧ ((fact_9fdb227ae99d_3630 a b) ∨ (fact_9fdb227ae99d_3639 a b) ∨ (fact_9fdb227ae99d_5038 a b) ∨ (fact_9fdb227ae99d_5791 a b) ∨ (fact_9fdb227ae99d_4413 a b) ∨ (fact_9fdb227ae99d_3682 a b) ∨ (fact_9fdb227ae99d_3687 a b) ∨ (fact_9fdb227ae99d_3702 a b) ∨ (fact_9fdb227ae99d_3646 a b) ∨ (fact_9fdb227ae99d_4493 a b) ∨ (fact_9fdb227ae99d_4527 a b) ∨ (fact_9fdb227ae99d_5128 a b))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n603_run_empty (a b run_x : Int)
    (h0 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((fact_9fdb227ae99d_2416 a b run_x) ∨ (fact_9fdb227ae99d_2417 a b run_x) ∨ (fact_9fdb227ae99d_3049 a b run_x) ∨ (fact_9fdb227ae99d_3564 a b run_x) ∨ (fact_9fdb227ae99d_2972 a b run_x) ∨ (fact_9fdb227ae99d_2518 a b run_x) ∨ (fact_9fdb227ae99d_2519 a b run_x) ∨ (fact_9fdb227ae99d_2522 a b run_x) ∨ (fact_9fdb227ae99d_2418 a b run_x) ∨ (fact_9fdb227ae99d_2973 a b run_x) ∨ (fact_9fdb227ae99d_3015 a b run_x) ∨ (fact_9fdb227ae99d_3110 a b run_x)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_3207 a b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((1 : Int) + a) ≤ run_x))
    (h8 : (run_x ≤ (b + a)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n603_run_floor (a b run_x : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (((1 : Int) + a) ≤ run_x))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (run_x ≤ (b + a)))
    (h5 : (¬ ((fact_9fdb227ae99d_3171 a b run_x) ∨ (fact_9fdb227ae99d_3181 a b run_x) ∨ (fact_9fdb227ae99d_3724 a b run_x) ∨ (fact_9fdb227ae99d_5189 a b run_x) ∨ (fact_9fdb227ae99d_3483 a b run_x) ∨ (fact_9fdb227ae99d_3209 a b run_x) ∨ (fact_9fdb227ae99d_3225 a b run_x) ∨ (fact_9fdb227ae99d_3246 a b run_x) ∨ (fact_9fdb227ae99d_3191 a b run_x) ∨ (fact_9fdb227ae99d_3554 a b run_x) ∨ (fact_9fdb227ae99d_3579 a b run_x) ∨ (fact_9fdb227ae99d_3895 a b run_x))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n604_run_four (a b : Int)
    (h0 : (¬ (((2 : Int) + b) ≤ ((3 : Int) + a))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n604_run_short (a b : Int)
    (h0 : (((-4 : Int) < ((-1 : Int) - a)) ∨ ((-4 : Int) > ((-1 : Int) + (0 : Int))) ∨ ((((3 : Int) + a) + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (((3 : Int) + a) - a))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (¬ ((((3 : Int) + a) - ((2 : Int) + b)) < b)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n604_run_nonnegative (a b : Int)
    (h0 : (¬ (((2 : Int) + b) ≥ (0 : Int))))
    (h1 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n604_run_left (a b : Int)
    (h0 : (fact_9fdb227ae99d_3478 a b))
    (h1 : (¬ ((fact_9fdb227ae99d_4356 a b) ∨ (fact_9fdb227ae99d_4373 a b) ∨ (fact_9fdb227ae99d_5466 a b) ∨ (fact_9fdb227ae99d_6189 a b) ∨ (fact_9fdb227ae99d_5124 a b) ∨ (fact_9fdb227ae99d_4427 a b) ∨ (fact_9fdb227ae99d_4451 a b) ∨ (fact_9fdb227ae99d_4480 a b) ∨ (fact_9fdb227ae99d_4383 a b) ∨ (fact_9fdb227ae99d_5152 a b) ∨ (((((-4 : Int) - b) ≤ (-(2 : Int))) ∧ ((-(2 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (((2 : Int) + b) - (1 : Int))) ∧ ((((2 : Int) + b) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((-4 : Int) ≤ (-(2 : Int))) ∧ ((-4 : Int) ≥ (-(2 : Int))) ∧ ((((3 : Int) + a) - a) ≤ (((2 : Int) + b) - (1 : Int))) ∧ ((((2 : Int) + b) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6326 a b))))
    (h2 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n604_run_right (a b : Int)
    (h0 : (((-4 : Int) < ((-1 : Int) - a)) ∨ ((-4 : Int) > ((-1 : Int) + (0 : Int))) ∨ ((((3 : Int) + a) + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (((3 : Int) + a) - a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (¬ ((fact_9fdb227ae99d_4357 a b) ∨ (fact_9fdb227ae99d_4374 a b) ∨ (fact_9fdb227ae99d_5467 a b) ∨ (fact_9fdb227ae99d_6190 a b) ∨ (fact_9fdb227ae99d_5125 a b) ∨ (fact_9fdb227ae99d_4428 a b) ∨ (fact_9fdb227ae99d_4452 a b) ∨ (fact_9fdb227ae99d_4481 a b) ∨ (fact_9fdb227ae99d_4384 a b) ∨ (fact_9fdb227ae99d_5153 a b) ∨ (((((-4 : Int) - b) ≤ (-(2 : Int))) ∧ ((-(2 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((-4 : Int) ≤ (-(2 : Int))) ∧ ((-4 : Int) ≥ (-(2 : Int))) ∧ ((((3 : Int) + a) - a) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6327 a b))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n604_run_tall (a b : Int)
    (h0 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h1 : (¬ ((((((2 : Int) + b) + (3 : Int)) ≤ ((3 : Int) + a)) ∧ ((fact_9fdb227ae99d_7853 a b) ∨ (fact_9fdb227ae99d_7856 a b))) ∨ (((((2 : Int) + b) + (2 : Int)) ≤ ((3 : Int) + a)) ∧ (fact_9fdb227ae99d_7853 a b) ∧ (fact_9fdb227ae99d_7856 a b)) ∨ ((((2 : Int) + b) + (4 : Int)) ≤ ((3 : Int) + a)) ∨ ((((3 : Int) + a) = (((2 : Int) + b) + (1 : Int))) ∧ (fact_9fdb227ae99d_7853 a b) ∧ (fact_9fdb227ae99d_7856 a b) ∧ (((fact_9fdb227ae99d_5132 a b) ∨ (fact_9fdb227ae99d_5136 a b) ∨ (fact_9fdb227ae99d_5807 a b) ∨ (fact_9fdb227ae99d_6676 a b) ∨ (fact_9fdb227ae99d_5605 a b) ∨ (fact_9fdb227ae99d_5203 a b) ∨ (fact_9fdb227ae99d_5210 a b) ∨ (fact_9fdb227ae99d_5235 a b) ∨ (fact_9fdb227ae99d_5140 a b) ∨ (fact_9fdb227ae99d_5628 a b) ∨ (fact_9fdb227ae99d_5678 a b) ∨ (fact_9fdb227ae99d_6772 a b)) ∨ ((fact_9fdb227ae99d_5133 a b) ∨ (fact_9fdb227ae99d_5137 a b) ∨ (fact_9fdb227ae99d_5808 a b) ∨ (fact_9fdb227ae99d_6677 a b) ∨ (fact_9fdb227ae99d_5606 a b) ∨ (fact_9fdb227ae99d_5204 a b) ∨ (fact_9fdb227ae99d_5211 a b) ∨ (fact_9fdb227ae99d_5236 a b) ∨ (fact_9fdb227ae99d_5141 a b) ∨ (fact_9fdb227ae99d_5629 a b) ∨ (fact_9fdb227ae99d_5679 a b) ∨ (fact_9fdb227ae99d_6773 a b)))) ∨ ((fact_9fdb227ae99d_7853 a b) ∧ (fact_9fdb227ae99d_7856 a b) ∧ ((fact_9fdb227ae99d_5132 a b) ∨ (fact_9fdb227ae99d_5136 a b) ∨ (fact_9fdb227ae99d_5807 a b) ∨ (fact_9fdb227ae99d_6676 a b) ∨ (fact_9fdb227ae99d_5605 a b) ∨ (fact_9fdb227ae99d_5203 a b) ∨ (fact_9fdb227ae99d_5210 a b) ∨ (fact_9fdb227ae99d_5235 a b) ∨ (fact_9fdb227ae99d_5140 a b) ∨ (fact_9fdb227ae99d_5628 a b) ∨ (fact_9fdb227ae99d_5678 a b) ∨ (fact_9fdb227ae99d_6772 a b)) ∧ ((fact_9fdb227ae99d_5133 a b) ∨ (fact_9fdb227ae99d_5137 a b) ∨ (fact_9fdb227ae99d_5808 a b) ∨ (fact_9fdb227ae99d_6677 a b) ∨ (fact_9fdb227ae99d_5606 a b) ∨ (fact_9fdb227ae99d_5204 a b) ∨ (fact_9fdb227ae99d_5211 a b) ∨ (fact_9fdb227ae99d_5236 a b) ∨ (fact_9fdb227ae99d_5141 a b) ∨ (fact_9fdb227ae99d_5629 a b) ∨ (fact_9fdb227ae99d_5679 a b) ∨ (fact_9fdb227ae99d_6773 a b))))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((-4 : Int) < ((-1 : Int) - a)) ∨ ((-4 : Int) > ((-1 : Int) + (0 : Int))) ∨ ((((3 : Int) + a) + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (((3 : Int) + a) - a))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n604_run_empty (a b run_x : Int)
    (h0 : (run_x ≤ ((3 : Int) + a)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((-4 : Int) < ((-1 : Int) - a)) ∨ ((-4 : Int) > ((-1 : Int) + (0 : Int))) ∨ ((((3 : Int) + a) + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (((3 : Int) + a) - a))))
    (h3 : (((2 : Int) + b) ≤ run_x))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h7 : ((fact_9fdb227ae99d_2586 a b run_x) ∨ (fact_9fdb227ae99d_2591 a b run_x) ∨ (fact_9fdb227ae99d_3152 a b run_x) ∨ (fact_9fdb227ae99d_3672 a b run_x) ∨ (fact_9fdb227ae99d_3030 a b run_x) ∨ (fact_9fdb227ae99d_2692 a b run_x) ∨ (fact_9fdb227ae99d_2712 a b run_x) ∨ (fact_9fdb227ae99d_2733 a b run_x) ∨ (fact_9fdb227ae99d_2632 a b run_x) ∨ (fact_9fdb227ae99d_3035 a b run_x) ∨ (((((-4 : Int) - b) ≤ (-(2 : Int))) ∧ ((-(2 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a))) ∨ (((-4 : Int) ≤ (-(2 : Int))) ∧ ((-4 : Int) ≥ (-(2 : Int))) ∧ ((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3742 a b run_x)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n604_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3319 a b run_x) ∨ (fact_9fdb227ae99d_3323 a b run_x) ∨ (fact_9fdb227ae99d_4334 a b run_x) ∨ (fact_9fdb227ae99d_5468 a b run_x) ∨ (fact_9fdb227ae99d_3676 a b run_x) ∨ (fact_9fdb227ae99d_3351 a b run_x) ∨ (fact_9fdb227ae99d_3357 a b run_x) ∨ (fact_9fdb227ae99d_3362 a b run_x) ∨ (fact_9fdb227ae99d_3327 a b run_x) ∨ (fact_9fdb227ae99d_3720 a b run_x) ∨ (((((-4 : Int) - b) ≤ (-((2 : Int) - (1 : Int)))) ∧ ((-((2 : Int) - (1 : Int))) ≤ ((-4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a))) ∨ (((-4 : Int) ≤ (-((2 : Int) - (1 : Int)))) ∧ ((-4 : Int) ≥ (-((2 : Int) - (1 : Int)))) ∧ ((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_5550 a b run_x))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (run_x ≤ ((3 : Int) + a)))
    (h4 : (((-4 : Int) < ((-1 : Int) - a)) ∨ ((-4 : Int) > ((-1 : Int) + (0 : Int))) ∨ ((((3 : Int) + a) + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (((3 : Int) + a) - a))))
    (h5 : (((2 : Int) + b) ≤ run_x))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (b = (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n605_point (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((-3 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ (((3 : Int) + a) ≥ (0 : Int)) ∧ ((-3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ (((3 : Int) + a) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n605_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((((-3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((3 : Int) + a)) ∧ ((0 : Int) ≥ ((3 : Int) + a))) ∨ (((0 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((0 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ (((1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + a)))) ∨ ((((-3 : Int) ≥ (((1 : Int) + b + a) - a)) ∧ ((-3 : Int) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) + a)) ∧ ((0 : Int) ≥ ((3 : Int) + a))) ∨ (((-3 : Int) ≥ ((1 : Int) + b + a)) ∧ ((-3 : Int) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((-3 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - b)) ∧ ((-3 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ (((-3 : Int) ≥ ((2 : Int) + ((2 : Int) * b))) ∧ ((-3 : Int) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + a)))) ∨ ((((-3 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((-3 : Int) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) + a))) ∨ (((-3 : Int) ≥ ((2 : Int) + a)) ∧ ((-3 : Int) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((2 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-1 : Int) - a)) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) + a)) ∧ ((0 : Int) ≥ ((3 : Int) + a))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-2 : Int) - a)) ∧ ((-3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ (((-2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-2 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-3 : Int) - b)) ∧ ((-3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) + a))) ∨ (((-3 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≥ ((3 : Int) + a))) ∨ (((2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (2 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((3 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (3 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((-3 : Int) ≥ ((-4 : Int) - b)) ∧ ((-3 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((-4 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-4 : Int)) ∧ ((((3 : Int) + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((-3 : Int) ≥ ((-1 : Int) - b)) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ ((((1 : Int) + b + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((1 : Int) + b + a) + (0 : Int)))))))
    (h2 : (a ≥ b))
    (h3 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n605_o0 (a b jx jy : Int)
    (h0 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h1 : (b = (5 : Int)))
    (h2 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ (jy ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (jy + b)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h5 : ((jx < ((-3 : Int) - b)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((-4 : Int) > (jx + a)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (fact_9fdb227ae99d_107 a b))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n605_o1 (a b jx jy : Int)
    (h0 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - a))))
    (h1 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - a))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b = (5 : Int)))
    (h5 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (((-4 : Int) > (jx + b)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h9 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ (jy ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (jy + (0 : Int))))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n605_o2 (a b jx jy : Int)
    (h0 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - b))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((jx + (0 : Int)) < ((-4 : Int) - b)) ∨ (((-4 : Int) + (0 : Int)) < (jx - a)) ∨ (jy < ((3 : Int) + a)) ∨ (((3 : Int) + a) < jy)))
    (h5 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - b))))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h8 : (b = (5 : Int)))
    (h9 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (jy + (0 : Int))))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n605_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h2 : (((jx + (0 : Int)) < ((-3 : Int) - b)) ∨ (((-3 : Int) + (0 : Int)) < (jx - b)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h3 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h4 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (jy + a)))))
    (h5 : (((jx + (0 : Int)) < ((-4 : Int) - b)) ∨ (((-4 : Int) + (0 : Int)) < (jx - b)) ∨ (jy < ((3 : Int) + a)) ∨ (((3 : Int) + a) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (((jx + (0 : Int)) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - b)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h10 : (((jx + (0 : Int)) < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < (jx - b)) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h11 : (b = (5 : Int)))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    (h14 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n605_o4 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((-4 : Int) - b)) ∨ (((-4 : Int) + (0 : Int)) < (jx - b)) ∨ (jy < ((3 : Int) + a)) ∨ (((3 : Int) + a) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h4 : (b = (5 : Int)))
    (h5 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - a))))
    (h6 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (jy + (0 : Int))))))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - a))))
    (h9 : (fact_9fdb227ae99d_107 a b))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n605_o5 (a b jx jy : Int)
    (h0 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (jy + b)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n605_o6 (a b jx jy : Int)
    (h0 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ (jy ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (jy + a)))))
    (h1 : (((-4 : Int) > (jx + b)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h3 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n605_o7 (a b jx jy : Int)
    (h0 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - b))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - b))))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ (jy ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((jy - b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (jy + (0 : Int))))))
    (h9 : (((-4 : Int) > (jx + a)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n606_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_29 a b))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n606_empty (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((fact_9fdb227ae99d_3086 a b) ∨ (fact_9fdb227ae99d_3087 a b) ∨ (fact_9fdb227ae99d_3593 a b) ∨ (fact_9fdb227ae99d_5028 a b) ∨ (fact_9fdb227ae99d_3330 a b) ∨ (fact_9fdb227ae99d_3125 a b) ∨ (fact_9fdb227ae99d_3127 a b) ∨ (fact_9fdb227ae99d_3130 a b) ∨ (fact_9fdb227ae99d_3088 a b) ∨ (fact_9fdb227ae99d_3333 a b) ∨ (fact_9fdb227ae99d_3131 a b)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n606_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (fact_9fdb227ae99d_1974 a b jx jy))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((jx + a) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h5 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h6 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h7 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h8 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h9 : (b = (5 : Int)))
    (h10 : (fact_9fdb227ae99d_107 a b))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n606_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_1977 a b jx jy))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + b + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n606_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h2 : (fact_9fdb227ae99d_1979 a b jx jy))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + ((2 : Int) * b))) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h5 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - b))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n606_o3 (a b jx jy : Int)
    (h0 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h1 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (fact_9fdb227ae99d_1980 a b jx jy))
    (h6 : (b = (5 : Int)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n606_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_1981 a b jx jy))
    (h2 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + b + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n606_o5 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (fact_9fdb227ae99d_1978 a b jx jy))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h7 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n606_o6 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h2 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h3 : ((jx < ((-3 : Int) - b)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (fact_9fdb227ae99d_1976 a b jx jy))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n606_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_1975 a b jx jy))
    (h3 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - b))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n607_run_four (a b : Int)
    (h0 : (¬ (((1 : Int) + a) ≤ (b + a))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n607_run_short (a b : Int)
    (h0 : (¬ (((b + a) - ((1 : Int) + a)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n607_run_nonnegative (a b : Int)
    (h0 : (¬ (((1 : Int) + a) ≥ (0 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n607_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3842 a b) ∨ (fact_9fdb227ae99d_3843 a b) ∨ (fact_9fdb227ae99d_5285 a b) ∨ (fact_9fdb227ae99d_5899 a b) ∨ (fact_9fdb227ae99d_4702 a b) ∨ (fact_9fdb227ae99d_4173 a b) ∨ (fact_9fdb227ae99d_4174 a b) ∨ (fact_9fdb227ae99d_4177 a b) ∨ (fact_9fdb227ae99d_3844 a b) ∨ (fact_9fdb227ae99d_4703 a b) ∨ (fact_9fdb227ae99d_4178 a b) ∨ (fact_9fdb227ae99d_5345 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n607_run_right (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3287 a b) ∨ (fact_9fdb227ae99d_3288 a b) ∨ (fact_9fdb227ae99d_4317 a b) ∨ (fact_9fdb227ae99d_5448 a b) ∨ (fact_9fdb227ae99d_3664 a b) ∨ (fact_9fdb227ae99d_3340 a b) ∨ (fact_9fdb227ae99d_3342 a b) ∨ (fact_9fdb227ae99d_3346 a b) ∨ (fact_9fdb227ae99d_3289 a b) ∨ (fact_9fdb227ae99d_3665 a b) ∨ (fact_9fdb227ae99d_3347 a b) ∨ (fact_9fdb227ae99d_4399 a b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n607_run_tall (a b : Int)
    (h0 : (¬ ((((((1 : Int) + a) + (3 : Int)) ≤ (b + a)) ∧ ((fact_9fdb227ae99d_7798 a b) ∨ (fact_9fdb227ae99d_7708 a b))) ∨ (((((1 : Int) + a) + (2 : Int)) ≤ (b + a)) ∧ (fact_9fdb227ae99d_7798 a b) ∧ (fact_9fdb227ae99d_7708 a b)) ∨ ((((1 : Int) + a) + (4 : Int)) ≤ (b + a)) ∨ (((b + a) = (((1 : Int) + a) + (1 : Int))) ∧ (fact_9fdb227ae99d_7798 a b) ∧ (fact_9fdb227ae99d_7708 a b) ∧ (((fact_9fdb227ae99d_4587 a b) ∨ (fact_9fdb227ae99d_4622 a b) ∨ (fact_9fdb227ae99d_5652 a b) ∨ (fact_9fdb227ae99d_6391 a b) ∨ (fact_9fdb227ae99d_5381 a b) ∨ (fact_9fdb227ae99d_4763 a b) ∨ (fact_9fdb227ae99d_4805 a b) ∨ (fact_9fdb227ae99d_4890 a b) ∨ (fact_9fdb227ae99d_4645 a b) ∨ (fact_9fdb227ae99d_5431 a b) ∨ (fact_9fdb227ae99d_4926 a b) ∨ (fact_9fdb227ae99d_5752 a b)) ∨ ((fact_9fdb227ae99d_3630 a b) ∨ (fact_9fdb227ae99d_3639 a b) ∨ (fact_9fdb227ae99d_5038 a b) ∨ (fact_9fdb227ae99d_5791 a b) ∨ (fact_9fdb227ae99d_4413 a b) ∨ (fact_9fdb227ae99d_3682 a b) ∨ (fact_9fdb227ae99d_3687 a b) ∨ (fact_9fdb227ae99d_3702 a b) ∨ (fact_9fdb227ae99d_3646 a b) ∨ (fact_9fdb227ae99d_4493 a b) ∨ (fact_9fdb227ae99d_3712 a b) ∨ (fact_9fdb227ae99d_5128 a b)))) ∨ ((fact_9fdb227ae99d_7798 a b) ∧ (fact_9fdb227ae99d_7708 a b) ∧ ((fact_9fdb227ae99d_4587 a b) ∨ (fact_9fdb227ae99d_4622 a b) ∨ (fact_9fdb227ae99d_5652 a b) ∨ (fact_9fdb227ae99d_6391 a b) ∨ (fact_9fdb227ae99d_5381 a b) ∨ (fact_9fdb227ae99d_4763 a b) ∨ (fact_9fdb227ae99d_4805 a b) ∨ (fact_9fdb227ae99d_4890 a b) ∨ (fact_9fdb227ae99d_4645 a b) ∨ (fact_9fdb227ae99d_5431 a b) ∨ (fact_9fdb227ae99d_4926 a b) ∨ (fact_9fdb227ae99d_5752 a b)) ∧ ((fact_9fdb227ae99d_3630 a b) ∨ (fact_9fdb227ae99d_3639 a b) ∨ (fact_9fdb227ae99d_5038 a b) ∨ (fact_9fdb227ae99d_5791 a b) ∨ (fact_9fdb227ae99d_4413 a b) ∨ (fact_9fdb227ae99d_3682 a b) ∨ (fact_9fdb227ae99d_3687 a b) ∨ (fact_9fdb227ae99d_3702 a b) ∨ (fact_9fdb227ae99d_3646 a b) ∨ (fact_9fdb227ae99d_4493 a b) ∨ (fact_9fdb227ae99d_3712 a b) ∨ (fact_9fdb227ae99d_5128 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n607_run_empty (a b run_x : Int)
    (h0 : ((fact_9fdb227ae99d_2416 a b run_x) ∨ (fact_9fdb227ae99d_2417 a b run_x) ∨ (fact_9fdb227ae99d_3049 a b run_x) ∨ (fact_9fdb227ae99d_3564 a b run_x) ∨ (fact_9fdb227ae99d_2972 a b run_x) ∨ (fact_9fdb227ae99d_2518 a b run_x) ∨ (fact_9fdb227ae99d_2519 a b run_x) ∨ (fact_9fdb227ae99d_2522 a b run_x) ∨ (fact_9fdb227ae99d_2418 a b run_x) ∨ (fact_9fdb227ae99d_2973 a b run_x) ∨ (fact_9fdb227ae99d_2523 a b run_x) ∨ (fact_9fdb227ae99d_3110 a b run_x)))
    (h1 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_3207 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (run_x ≤ (b + a)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (((1 : Int) + a) ≤ run_x))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n607_run_floor (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((1 : Int) + a) ≤ run_x))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (¬ ((fact_9fdb227ae99d_3171 a b run_x) ∨ (fact_9fdb227ae99d_3181 a b run_x) ∨ (fact_9fdb227ae99d_3724 a b run_x) ∨ (fact_9fdb227ae99d_5189 a b run_x) ∨ (fact_9fdb227ae99d_3483 a b run_x) ∨ (fact_9fdb227ae99d_3209 a b run_x) ∨ (fact_9fdb227ae99d_3225 a b run_x) ∨ (fact_9fdb227ae99d_3246 a b run_x) ∨ (fact_9fdb227ae99d_3191 a b run_x) ∨ (fact_9fdb227ae99d_3554 a b run_x) ∨ (fact_9fdb227ae99d_3251 a b run_x) ∨ (fact_9fdb227ae99d_3895 a b run_x))))
    (h5 : (run_x ≤ (b + a)))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n608_run_four (a b : Int)
    (h0 : (¬ (((2 : Int) + b) ≤ ((3 : Int) + a))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n608_run_short (a b : Int)
    (h0 : (¬ ((((3 : Int) + a) - ((2 : Int) + b)) < b)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((-3 : Int) < ((-1 : Int) - a)) ∨ ((-3 : Int) > ((-1 : Int) + (0 : Int))) ∨ (((2 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((2 : Int) - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n608_run_nonnegative (a b : Int)
    (h0 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h1 : (¬ (((2 : Int) + b) ≥ (0 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n608_run_left (a b : Int)
    (h0 : (fact_9fdb227ae99d_3478 a b))
    (h1 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h2 : (¬ ((fact_9fdb227ae99d_4356 a b) ∨ (fact_9fdb227ae99d_4373 a b) ∨ (fact_9fdb227ae99d_5466 a b) ∨ (fact_9fdb227ae99d_6189 a b) ∨ (fact_9fdb227ae99d_5124 a b) ∨ (fact_9fdb227ae99d_4427 a b) ∨ (fact_9fdb227ae99d_4451 a b) ∨ (fact_9fdb227ae99d_4480 a b) ∨ (fact_9fdb227ae99d_4383 a b) ∨ (fact_9fdb227ae99d_5152 a b) ∨ (((((-4 : Int) - a) ≤ (-(2 : Int))) ∧ ((-(2 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (((2 : Int) + b) - (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + b) - (1 : Int)))) ∨ (((-4 : Int) ≤ (-(2 : Int))) ∧ ((-4 : Int) ≥ (-(2 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (((2 : Int) + b) - (1 : Int))) ∧ ((((2 : Int) + b) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_6326 a b))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n608_run_right (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_4357 a b) ∨ (fact_9fdb227ae99d_4374 a b) ∨ (fact_9fdb227ae99d_5467 a b) ∨ (fact_9fdb227ae99d_6190 a b) ∨ (fact_9fdb227ae99d_5125 a b) ∨ (fact_9fdb227ae99d_4428 a b) ∨ (fact_9fdb227ae99d_4452 a b) ∨ (fact_9fdb227ae99d_4481 a b) ∨ (fact_9fdb227ae99d_4384 a b) ∨ (fact_9fdb227ae99d_5153 a b) ∨ (((((-4 : Int) - a) ≤ (-(2 : Int))) ∧ ((-(2 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + a) + (1 : Int)))) ∨ (((-4 : Int) ≤ (-(2 : Int))) ∧ ((-4 : Int) ≥ (-(2 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_6327 a b))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n608_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h4 : (¬ ((((((2 : Int) + b) + (3 : Int)) ≤ ((3 : Int) + a)) ∧ ((fact_9fdb227ae99d_7845 a b) ∨ (fact_9fdb227ae99d_7849 a b))) ∨ (((((2 : Int) + b) + (2 : Int)) ≤ ((3 : Int) + a)) ∧ (fact_9fdb227ae99d_7845 a b) ∧ (fact_9fdb227ae99d_7849 a b)) ∨ ((((2 : Int) + b) + (4 : Int)) ≤ ((3 : Int) + a)) ∨ ((((3 : Int) + a) = (((2 : Int) + b) + (1 : Int))) ∧ (fact_9fdb227ae99d_7845 a b) ∧ (fact_9fdb227ae99d_7849 a b) ∧ (((fact_9fdb227ae99d_5132 a b) ∨ (fact_9fdb227ae99d_5136 a b) ∨ (fact_9fdb227ae99d_5807 a b) ∨ (fact_9fdb227ae99d_6676 a b) ∨ (fact_9fdb227ae99d_5605 a b) ∨ (fact_9fdb227ae99d_5203 a b) ∨ (fact_9fdb227ae99d_5210 a b) ∨ (fact_9fdb227ae99d_5235 a b) ∨ (fact_9fdb227ae99d_5140 a b) ∨ (fact_9fdb227ae99d_5628 a b) ∨ (fact_9fdb227ae99d_5243 a b) ∨ (fact_9fdb227ae99d_6772 a b)) ∨ ((fact_9fdb227ae99d_5133 a b) ∨ (fact_9fdb227ae99d_5137 a b) ∨ (fact_9fdb227ae99d_5808 a b) ∨ (fact_9fdb227ae99d_6677 a b) ∨ (fact_9fdb227ae99d_5606 a b) ∨ (fact_9fdb227ae99d_5204 a b) ∨ (fact_9fdb227ae99d_5211 a b) ∨ (fact_9fdb227ae99d_5236 a b) ∨ (fact_9fdb227ae99d_5141 a b) ∨ (fact_9fdb227ae99d_5629 a b) ∨ (fact_9fdb227ae99d_5244 a b) ∨ (fact_9fdb227ae99d_6773 a b)))) ∨ ((fact_9fdb227ae99d_7845 a b) ∧ (fact_9fdb227ae99d_7849 a b) ∧ ((fact_9fdb227ae99d_5132 a b) ∨ (fact_9fdb227ae99d_5136 a b) ∨ (fact_9fdb227ae99d_5807 a b) ∨ (fact_9fdb227ae99d_6676 a b) ∨ (fact_9fdb227ae99d_5605 a b) ∨ (fact_9fdb227ae99d_5203 a b) ∨ (fact_9fdb227ae99d_5210 a b) ∨ (fact_9fdb227ae99d_5235 a b) ∨ (fact_9fdb227ae99d_5140 a b) ∨ (fact_9fdb227ae99d_5628 a b) ∨ (fact_9fdb227ae99d_5243 a b) ∨ (fact_9fdb227ae99d_6772 a b)) ∧ ((fact_9fdb227ae99d_5133 a b) ∨ (fact_9fdb227ae99d_5137 a b) ∨ (fact_9fdb227ae99d_5808 a b) ∨ (fact_9fdb227ae99d_6677 a b) ∨ (fact_9fdb227ae99d_5606 a b) ∨ (fact_9fdb227ae99d_5204 a b) ∨ (fact_9fdb227ae99d_5211 a b) ∨ (fact_9fdb227ae99d_5236 a b) ∨ (fact_9fdb227ae99d_5141 a b) ∨ (fact_9fdb227ae99d_5629 a b) ∨ (fact_9fdb227ae99d_5244 a b) ∨ (fact_9fdb227ae99d_6773 a b))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n608_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((2 : Int) + b) ≤ run_x))
    (h2 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (run_x ≤ ((3 : Int) + a)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((fact_9fdb227ae99d_2586 a b run_x) ∨ (fact_9fdb227ae99d_2591 a b run_x) ∨ (fact_9fdb227ae99d_3152 a b run_x) ∨ (fact_9fdb227ae99d_3672 a b run_x) ∨ (fact_9fdb227ae99d_3030 a b run_x) ∨ (fact_9fdb227ae99d_2692 a b run_x) ∨ (fact_9fdb227ae99d_2712 a b run_x) ∨ (fact_9fdb227ae99d_2733 a b run_x) ∨ (fact_9fdb227ae99d_2632 a b run_x) ∨ (fact_9fdb227ae99d_3035 a b run_x) ∨ (((((-4 : Int) - a) ≤ (-(2 : Int))) ∧ ((-(2 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((-4 : Int) ≤ (-(2 : Int))) ∧ ((-4 : Int) ≥ (-(2 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_3742 a b run_x)))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n608_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3319 a b run_x) ∨ (fact_9fdb227ae99d_3323 a b run_x) ∨ (fact_9fdb227ae99d_4334 a b run_x) ∨ (fact_9fdb227ae99d_5468 a b run_x) ∨ (fact_9fdb227ae99d_3676 a b run_x) ∨ (fact_9fdb227ae99d_3351 a b run_x) ∨ (fact_9fdb227ae99d_3357 a b run_x) ∨ (fact_9fdb227ae99d_3362 a b run_x) ∨ (fact_9fdb227ae99d_3327 a b run_x) ∨ (fact_9fdb227ae99d_3720 a b run_x) ∨ (((((-4 : Int) - a) ≤ (-((2 : Int) - (1 : Int)))) ∧ ((-((2 : Int) - (1 : Int))) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((-4 : Int) ≤ (-((2 : Int) - (1 : Int)))) ∧ ((-4 : Int) ≥ (-((2 : Int) - (1 : Int)))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_5550 a b run_x))))
    (h1 : (run_x ≤ ((3 : Int) + a)))
    (h2 : (((-3 : Int) < ((-1 : Int) - a)) ∨ ((-3 : Int) > ((-1 : Int) + (0 : Int))) ∨ (((2 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((2 : Int) - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((2 : Int) + b) ≤ run_x))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (b = (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n609_point (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (fact_9fdb227ae99d_1 a b))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n609_empty (a b : Int)
    (h0 : (fact_9fdb227ae99d_3206 a b))
    (h1 : ((fact_9fdb227ae99d_3051 a b) ∨ (fact_9fdb227ae99d_3053 a b) ∨ (fact_9fdb227ae99d_3563 a b) ∨ (fact_9fdb227ae99d_4701 a b) ∨ (fact_9fdb227ae99d_3285 a b) ∨ (fact_9fdb227ae99d_3112 a b) ∨ (fact_9fdb227ae99d_3115 a b) ∨ ((((0 : Int) ≥ ((-3 : Int) - b)) ∧ ((0 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + b)) ∧ ((2 : Int) ≥ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3055 a b) ∨ (fact_9fdb227ae99d_3292 a b) ∨ ((((0 : Int) ≥ ((-4 : Int) - a)) ∧ ((0 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≥ ((3 : Int) + b))) ∨ (((-4 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (-4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_3598 a b)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n609_o0 (a b jx jy : Int)
    (h0 : (((jx + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h1 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (fact_9fdb227ae99d_1606 a b jx jy))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n609_o1 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h1 : (fact_9fdb227ae99d_1611 a b jx jy))
    (h2 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - a))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (¬ ((((0 : Int) = jx) ∧ (jy = ((3 : Int) + b + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h8 : (b = (5 : Int)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n609_o2 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_1615 a b jx jy))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - b))))
    (h5 : (((jx + (0 : Int)) < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < (jx - a)) ∨ (jy < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < jy)))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h9 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n609_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (fact_9fdb227ae99d_1618 a b jx jy))
    (h6 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h9 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n609_o4 (a b jx jy : Int)
    (h0 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - a))))
    (h1 : (b = (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (¬ ((((0 : Int) = jx) ∧ (jy = ((3 : Int) + b + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h5 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (fact_9fdb227ae99d_1619 a b jx jy))
    (h8 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h9 : ((jy - a) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n609_o5 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (((-4 : Int) > (jx + (0 : Int))) ∨ ((-4 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h3 : (fact_9fdb227ae99d_1614 a b jx jy))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h7 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n609_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h3 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (fact_9fdb227ae99d_1610 a b jx jy))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n609_o7 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1607 a b jx jy))
    (h1 : (b = (5 : Int)))
    (h2 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (((-4 : Int) > (jx + a)) ∨ ((-4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (¬ ((((0 : Int) = jx) ∧ (jy = ((3 : Int) + ((2 : Int) * b))) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h7 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - b))))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n610_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_2 a b))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n610_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_3061 a b) ∨ (fact_9fdb227ae99d_3062 a b) ∨ (fact_9fdb227ae99d_3567 a b) ∨ (fact_9fdb227ae99d_4706 a b) ∨ (fact_9fdb227ae99d_3298 a b) ∨ (fact_9fdb227ae99d_3118 a b) ∨ (fact_9fdb227ae99d_3119 a b) ∨ ((((2 : Int) ≥ ((-3 : Int) - b)) ∧ ((2 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((-3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3063 a b) ∨ (fact_9fdb227ae99d_3299 a b) ∨ ((((2 : Int) ≥ ((-4 : Int) - a)) ∧ ((2 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) + a))) ∨ (((-4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_3599 a b) ∨ (fact_9fdb227ae99d_3568 a b)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n610_o0 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h4 : (fact_9fdb227ae99d_1672 a b jx jy))
    (h5 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + b) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - (0 : Int)))))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n610_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_1675 a b jx jy))
    (h3 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - a))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (b = (5 : Int)))
    (h7 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + b + a) - a)) ∨ ((((3 : Int) + b + a) + (0 : Int)) < jy)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - a))))
    (h10 : (fact_9fdb227ae99d_2923 a b jy))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n610_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - b))))
    (h2 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - b))))
    (h3 : (b = (5 : Int)))
    (h4 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (fact_9fdb227ae99d_1677 a b jx jy))
    (h6 : (a ≥ b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a > b))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n610_o3 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h2 : (fact_9fdb227ae99d_1678 a b jx jy))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h9 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n610_o4 (a b jx jy : Int)
    (h0 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - a))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - a))))
    (h5 : (fact_9fdb227ae99d_1679 a b jx jy))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n610_o5 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_1676 a b jx jy))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h7 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n610_o6 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1674 a b jx jy))
    (h1 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + a) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h6 : (b = (5 : Int)))
    (h7 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n610_o7 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - b))))
    (h2 : (fact_9fdb227ae99d_1673 a b jx jy))
    (h3 : (b = (5 : Int)))
    (h4 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h5 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - b))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (fact_9fdb227ae99d_2925 a b jy))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (((jx + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) + a)) ∨ (((4 : Int) + a) < jy)))
    (h10 : ((jy - b) ≥ (0 : Int)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n611_point (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (¬ (((4 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n611_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_2824 a b) ∨ (fact_9fdb227ae99d_2825 a b) ∨ (fact_9fdb227ae99d_3205 a b) ∨ (fact_9fdb227ae99d_3853 a b) ∨ (fact_9fdb227ae99d_3071 a b) ∨ ((((4 : Int) ≥ ((-1 : Int) - a)) ∧ ((4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-1 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((4 : Int) ≥ ((-2 : Int) - a)) ∧ ((4 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-2 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_2909 a b) ∨ (fact_9fdb227ae99d_2826 a b) ∨ (fact_9fdb227ae99d_3072 a b) ∨ ((((4 : Int) ≥ ((-4 : Int) - a)) ∧ ((4 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ (((-4 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-4 : Int)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + b)))) ∨ ((((4 : Int) ≥ ((-1 : Int) - b)) ∧ ((4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) + b + a)) ∧ ((4 : Int) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-1 : Int)) ∧ ((4 : Int) ≥ (((1 : Int) + b + a) - a)) ∧ ((4 : Int) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ ((((4 : Int) ≥ ((0 : Int) - b)) ∧ ((4 : Int) ≤ ((0 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + b + a)) ∧ ((4 : Int) ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int)) ∧ ((4 : Int) ≥ (((3 : Int) + b + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + b + a) + (0 : Int)))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n611_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h2 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (b = (5 : Int)))
    (h4 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n611_o1 (a b jx jy : Int)
    (h0 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n611_o2 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_2924 a b jy))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h7 : ((jy - b) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n611_o3 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (((jx + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h7 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n611_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h6 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n611_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h2 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (b = (5 : Int)))
    (h8 : (((jx + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h9 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h10 : (a ≥ (5 : Int)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n611_o6 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + a) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - (0 : Int)))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h5 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n611_o7 (a b jx jy : Int)
    (h0 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (¬ ((((4 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h2 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h3 : (b = (5 : Int)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n612_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n612_run_short (a b : Int)
    (h0 : (¬ ((((1 : Int) + a) - (4 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n612_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n612_run_left (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3386 a b) ∨ (fact_9fdb227ae99d_3387 a b) ∨ (fact_9fdb227ae99d_4499 a b) ∨ (fact_9fdb227ae99d_5586 a b) ∨ (fact_9fdb227ae99d_3862 a b) ∨ ((((5 : Int) ≥ ((-1 : Int) - a)) ∧ ((5 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ ((-2 : Int) - a)) ∧ ((5 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((-2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-2 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3477 a b) ∨ (fact_9fdb227ae99d_3388 a b) ∨ (fact_9fdb227ae99d_3869 a b) ∨ ((((5 : Int) ≥ ((-4 : Int) - a)) ∧ ((5 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((-4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ ((((5 : Int) ≥ ((-1 : Int) - b)) ∧ ((5 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-1 : Int)) ∧ ((((1 : Int) + b + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((0 : Int) - b)) ∧ ((5 : Int) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + b + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int)) ∧ ((((3 : Int) + b + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3870 a b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n612_run_right (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ ((fact_9fdb227ae99d_3863 a b) ∨ (fact_9fdb227ae99d_3865 a b) ∨ (fact_9fdb227ae99d_5289 a b) ∨ (fact_9fdb227ae99d_5904 a b) ∨ (fact_9fdb227ae99d_4712 a b) ∨ ((((5 : Int) ≥ ((-1 : Int) - a)) ∧ ((5 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ ((-2 : Int) - a)) ∧ ((5 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-2 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_4191 a b) ∨ (fact_9fdb227ae99d_3867 a b) ∨ (fact_9fdb227ae99d_4714 a b) ∨ ((((5 : Int) ≥ ((-4 : Int) - a)) ∧ ((5 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ ((((5 : Int) ≥ ((-1 : Int) - b)) ∧ ((5 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-1 : Int)) ∧ ((((1 : Int) + b + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((0 : Int) - b)) ∧ ((5 : Int) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + b + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int)) ∧ ((((3 : Int) + b + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_4716 a b))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n612_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_9fdb227ae99d_7882 a b) ∨ (fact_9fdb227ae99d_7926 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ (fact_9fdb227ae99d_7882 a b) ∧ (fact_9fdb227ae99d_7926 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = ((4 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7882 a b) ∧ (fact_9fdb227ae99d_7926 a b) ∧ (((fact_9fdb227ae99d_3776 a b) ∨ (fact_9fdb227ae99d_3808 a b) ∨ (fact_9fdb227ae99d_5186 a b) ∨ (fact_9fdb227ae99d_5864 a b) ∨ (fact_9fdb227ae99d_4550 a b) ∨ (fact_9fdb227ae99d_3915 a b) ∨ (fact_9fdb227ae99d_3962 a b) ∨ (fact_9fdb227ae99d_4037 a b) ∨ (fact_9fdb227ae99d_3826 a b) ∨ (fact_9fdb227ae99d_4691 a b) ∨ (fact_9fdb227ae99d_4048 a b) ∨ (fact_9fdb227ae99d_5324 a b) ∨ (fact_9fdb227ae99d_5269 a b) ∨ (fact_9fdb227ae99d_4696 a b)) ∨ ((fact_9fdb227ae99d_4596 a b) ∨ (fact_9fdb227ae99d_4631 a b) ∨ (fact_9fdb227ae99d_5661 a b) ∨ (fact_9fdb227ae99d_6400 a b) ∨ (fact_9fdb227ae99d_5389 a b) ∨ (fact_9fdb227ae99d_4771 a b) ∨ (fact_9fdb227ae99d_4813 a b) ∨ (fact_9fdb227ae99d_4916 a b) ∨ (fact_9fdb227ae99d_4665 a b) ∨ (fact_9fdb227ae99d_5439 a b) ∨ (fact_9fdb227ae99d_4934 a b) ∨ (fact_9fdb227ae99d_5766 a b) ∨ (fact_9fdb227ae99d_5692 a b) ∨ (fact_9fdb227ae99d_5443 a b)))) ∨ ((fact_9fdb227ae99d_7882 a b) ∧ (fact_9fdb227ae99d_7926 a b) ∧ ((fact_9fdb227ae99d_3776 a b) ∨ (fact_9fdb227ae99d_3808 a b) ∨ (fact_9fdb227ae99d_5186 a b) ∨ (fact_9fdb227ae99d_5864 a b) ∨ (fact_9fdb227ae99d_4550 a b) ∨ (fact_9fdb227ae99d_3915 a b) ∨ (fact_9fdb227ae99d_3962 a b) ∨ (fact_9fdb227ae99d_4037 a b) ∨ (fact_9fdb227ae99d_3826 a b) ∨ (fact_9fdb227ae99d_4691 a b) ∨ (fact_9fdb227ae99d_4048 a b) ∨ (fact_9fdb227ae99d_5324 a b) ∨ (fact_9fdb227ae99d_5269 a b) ∨ (fact_9fdb227ae99d_4696 a b)) ∧ ((fact_9fdb227ae99d_4596 a b) ∨ (fact_9fdb227ae99d_4631 a b) ∨ (fact_9fdb227ae99d_5661 a b) ∨ (fact_9fdb227ae99d_6400 a b) ∨ (fact_9fdb227ae99d_5389 a b) ∨ (fact_9fdb227ae99d_4771 a b) ∨ (fact_9fdb227ae99d_4813 a b) ∨ (fact_9fdb227ae99d_4916 a b) ∨ (fact_9fdb227ae99d_4665 a b) ∨ (fact_9fdb227ae99d_5439 a b) ∨ (fact_9fdb227ae99d_4934 a b) ∨ (fact_9fdb227ae99d_5766 a b) ∨ (fact_9fdb227ae99d_5692 a b) ∨ (fact_9fdb227ae99d_5443 a b))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n612_run_empty (a b run_x : Int)
    (h0 : (run_x ≤ ((1 : Int) + a)))
    (h1 : ((fact_9fdb227ae99d_2449 a b run_x) ∨ (fact_9fdb227ae99d_2450 a b run_x) ∨ (fact_9fdb227ae99d_3073 a b run_x) ∨ (fact_9fdb227ae99d_3572 a b run_x) ∨ (fact_9fdb227ae99d_2984 a b run_x) ∨ ((((5 : Int) ≥ ((-1 : Int) - a)) ∧ ((5 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ ((-2 : Int) - a)) ∧ ((5 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-2 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_2542 a b run_x) ∨ (fact_9fdb227ae99d_2451 a b run_x) ∨ (fact_9fdb227ae99d_2985 a b run_x) ∨ ((((5 : Int) ≥ ((-4 : Int) - a)) ∧ ((5 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((-4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ ((((5 : Int) ≥ ((-1 : Int) - b)) ∧ ((5 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-1 : Int)) ∧ ((((1 : Int) + b + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((0 : Int) - b)) ∧ ((5 : Int) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + b + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int)) ∧ ((((3 : Int) + b + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_2986 a b run_x)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((4 : Int) ≤ run_x))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n612_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3175 a b run_x) ∨ (fact_9fdb227ae99d_3185 a b run_x) ∨ (fact_9fdb227ae99d_3728 a b run_x) ∨ (fact_9fdb227ae99d_5193 a b run_x) ∨ (fact_9fdb227ae99d_3487 a b run_x) ∨ (((((-1 : Int) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((-2 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3247 a b run_x) ∨ (fact_9fdb227ae99d_3194 a b run_x) ∨ (fact_9fdb227ae99d_3557 a b run_x) ∨ (((((-4 : Int) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((-4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((-4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((1 : Int) + b + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (((((0 : Int) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + b + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((3 : Int) + b + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3561 a b run_x))))
    (h1 : ((4 : Int) ≤ run_x))
    (h2 : (run_x ≤ ((1 : Int) + a)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n613_run_four (a b : Int)
    (h0 : (¬ (((2 : Int) + a) ≤ (b + a))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n613_run_short (a b : Int)
    (h0 : (¬ (((b + a) - ((2 : Int) + a)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n613_run_nonnegative (a b : Int)
    (h0 : (¬ (((2 : Int) + a) ≥ (0 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n613_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3845 a b) ∨ (fact_9fdb227ae99d_3846 a b) ∨ (fact_9fdb227ae99d_5286 a b) ∨ (fact_9fdb227ae99d_5900 a b) ∨ (fact_9fdb227ae99d_4704 a b) ∨ (fact_9fdb227ae99d_4180 a b) ∨ (fact_9fdb227ae99d_4181 a b) ∨ ((((1 : Int) ≥ ((-3 : Int) - b)) ∧ ((1 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + a) - (1 : Int)))) ∨ (((-3 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3847 a b) ∨ (fact_9fdb227ae99d_4705 a b) ∨ ((((1 : Int) ≥ ((-4 : Int) - a)) ∧ ((1 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) - (1 : Int)))) ∨ (((-4 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_5346 a b) ∨ (fact_9fdb227ae99d_5901 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n613_run_right (a b : Int)
    (h0 : (((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int)) ∨ (((0 : Int) + a) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((0 : Int) - (0 : Int)))))
    (h1 : (¬ ((fact_9fdb227ae99d_3295 a b) ∨ (fact_9fdb227ae99d_3296 a b) ∨ (fact_9fdb227ae99d_4318 a b) ∨ (fact_9fdb227ae99d_5449 a b) ∨ (fact_9fdb227ae99d_3667 a b) ∨ (fact_9fdb227ae99d_3349 a b) ∨ (fact_9fdb227ae99d_3350 a b) ∨ ((((1 : Int) ≥ ((-3 : Int) - b)) ∧ ((1 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((b + a) + (1 : Int))) ∧ ((2 : Int) ≥ ((b + a) + (1 : Int)))) ∨ (((-3 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((b + a) + (1 : Int))) ∧ (((b + a) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3297 a b) ∨ (fact_9fdb227ae99d_3668 a b) ∨ ((((1 : Int) ≥ ((-4 : Int) - a)) ∧ ((1 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ ((b + a) + (1 : Int))) ∧ ((3 : Int) ≥ ((b + a) + (1 : Int)))) ∨ (((-4 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((b + a) + (1 : Int))) ∧ (((b + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_4400 a b) ∨ (fact_9fdb227ae99d_5450 a b))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (b = (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n613_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (¬ ((((((2 : Int) + a) + (3 : Int)) ≤ (b + a)) ∧ ((fact_9fdb227ae99d_7881 a b) ∨ (fact_9fdb227ae99d_7807 a b))) ∨ (((((2 : Int) + a) + (2 : Int)) ≤ (b + a)) ∧ (fact_9fdb227ae99d_7881 a b) ∧ (fact_9fdb227ae99d_7807 a b)) ∨ ((((2 : Int) + a) + (4 : Int)) ≤ (b + a)) ∨ (((b + a) = (((2 : Int) + a) + (1 : Int))) ∧ (fact_9fdb227ae99d_7881 a b) ∧ (fact_9fdb227ae99d_7807 a b) ∧ (((fact_9fdb227ae99d_4589 a b) ∨ (fact_9fdb227ae99d_4624 a b) ∨ (fact_9fdb227ae99d_5654 a b) ∨ (fact_9fdb227ae99d_6393 a b) ∨ (fact_9fdb227ae99d_5383 a b) ∨ (fact_9fdb227ae99d_4765 a b) ∨ (fact_9fdb227ae99d_4807 a b) ∨ (fact_9fdb227ae99d_4894 a b) ∨ (fact_9fdb227ae99d_4647 a b) ∨ (fact_9fdb227ae99d_5433 a b) ∨ (((((-4 : Int) - a) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) - (1 : Int)))) ∨ (((-4 : Int) ≤ ((1 : Int) + a)) ∧ ((-4 : Int) ≥ ((1 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_5764 a b) ∨ (fact_9fdb227ae99d_6449 a b)) ∨ ((fact_9fdb227ae99d_3632 a b) ∨ (fact_9fdb227ae99d_3641 a b) ∨ (fact_9fdb227ae99d_5040 a b) ∨ (fact_9fdb227ae99d_5793 a b) ∨ (fact_9fdb227ae99d_4415 a b) ∨ (fact_9fdb227ae99d_3684 a b) ∨ (fact_9fdb227ae99d_3689 a b) ∨ (fact_9fdb227ae99d_3706 a b) ∨ (fact_9fdb227ae99d_3648 a b) ∨ (fact_9fdb227ae99d_4495 a b) ∨ (((((-4 : Int) - a) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ ((b + a) + (1 : Int))) ∧ ((3 : Int) ≥ ((b + a) + (1 : Int)))) ∨ (((-4 : Int) ≤ ((1 : Int) + a)) ∧ ((-4 : Int) ≥ ((1 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((b + a) + (1 : Int))) ∧ (((b + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_5130 a b) ∨ (fact_9fdb227ae99d_5803 a b)))) ∨ ((fact_9fdb227ae99d_7881 a b) ∧ (fact_9fdb227ae99d_7807 a b) ∧ ((fact_9fdb227ae99d_4589 a b) ∨ (fact_9fdb227ae99d_4624 a b) ∨ (fact_9fdb227ae99d_5654 a b) ∨ (fact_9fdb227ae99d_6393 a b) ∨ (fact_9fdb227ae99d_5383 a b) ∨ (fact_9fdb227ae99d_4765 a b) ∨ (fact_9fdb227ae99d_4807 a b) ∨ (fact_9fdb227ae99d_4894 a b) ∨ (fact_9fdb227ae99d_4647 a b) ∨ (fact_9fdb227ae99d_5433 a b) ∨ (((((-4 : Int) - a) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) - (1 : Int)))) ∨ (((-4 : Int) ≤ ((1 : Int) + a)) ∧ ((-4 : Int) ≥ ((1 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_5764 a b) ∨ (fact_9fdb227ae99d_6449 a b)) ∧ ((fact_9fdb227ae99d_3632 a b) ∨ (fact_9fdb227ae99d_3641 a b) ∨ (fact_9fdb227ae99d_5040 a b) ∨ (fact_9fdb227ae99d_5793 a b) ∨ (fact_9fdb227ae99d_4415 a b) ∨ (fact_9fdb227ae99d_3684 a b) ∨ (fact_9fdb227ae99d_3689 a b) ∨ (fact_9fdb227ae99d_3706 a b) ∨ (fact_9fdb227ae99d_3648 a b) ∨ (fact_9fdb227ae99d_4495 a b) ∨ (((((-4 : Int) - a) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ ((b + a) + (1 : Int))) ∧ ((3 : Int) ≥ ((b + a) + (1 : Int)))) ∨ (((-4 : Int) ≤ ((1 : Int) + a)) ∧ ((-4 : Int) ≥ ((1 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((b + a) + (1 : Int))) ∧ (((b + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_5130 a b) ∨ (fact_9fdb227ae99d_5803 a b))))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int)) ∨ (((0 : Int) + a) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((0 : Int) - (0 : Int)))))
    (h4 : (b = (5 : Int)))
    (h5 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n613_run_empty (a b run_x : Int)
    (h0 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_3206 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int)) ∨ (((0 : Int) + a) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((0 : Int) - (0 : Int)))))
    (h7 : (((2 : Int) + a) ≤ run_x))
    (h8 : ((fact_9fdb227ae99d_2431 a b run_x) ∨ (fact_9fdb227ae99d_2432 a b run_x) ∨ (fact_9fdb227ae99d_3059 a b run_x) ∨ (fact_9fdb227ae99d_3565 a b run_x) ∨ (fact_9fdb227ae99d_2974 a b run_x) ∨ (fact_9fdb227ae99d_2529 a b run_x) ∨ (fact_9fdb227ae99d_2530 a b run_x) ∨ ((((1 : Int) ≥ ((-3 : Int) - b)) ∧ ((1 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_2433 a b run_x) ∨ (fact_9fdb227ae99d_2975 a b run_x) ∨ ((((1 : Int) ≥ ((-4 : Int) - a)) ∧ ((1 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((-4 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_3117 a b run_x) ∨ (fact_9fdb227ae99d_3566 a b run_x)))
    (h9 : (run_x ≤ (b + a)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n613_run_floor (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int)) ∨ (((0 : Int) + a) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((0 : Int) - (0 : Int)))))
    (h2 : (((2 : Int) + a) ≤ run_x))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (run_x ≤ (b + a)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h7 : (¬ ((fact_9fdb227ae99d_3172 a b run_x) ∨ (fact_9fdb227ae99d_3182 a b run_x) ∨ (fact_9fdb227ae99d_3725 a b run_x) ∨ (fact_9fdb227ae99d_5190 a b run_x) ∨ (fact_9fdb227ae99d_3484 a b run_x) ∨ (fact_9fdb227ae99d_3210 a b run_x) ∨ (fact_9fdb227ae99d_3226 a b run_x) ∨ (((((-3 : Int) - b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3192 a b run_x) ∨ (fact_9fdb227ae99d_3555 a b run_x) ∨ (((((-4 : Int) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((-4 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((-4 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_3922 a b run_x) ∨ (fact_9fdb227ae99d_5261 a b run_x))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (b = (5 : Int)))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n614_run_four (a b : Int)
    (h0 : (¬ ((-4 : Int) ≥ ((-1 : Int) + ((-1 : Int) * a)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n614_run_short (a b : Int)
    (h0 : (¬ (((-4 : Int) - ((-1 : Int) + ((-1 : Int) * a))) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n614_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n614_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5682 a b) ∨ (fact_9fdb227ae99d_5695 a b) ∨ (fact_9fdb227ae99d_6363 a b) ∨ (fact_9fdb227ae99d_6959 a b) ∨ (fact_9fdb227ae99d_5991 a b) ∨ (fact_9fdb227ae99d_5754 a b) ∨ (fact_9fdb227ae99d_5769 a b) ∨ (((((-3 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_5705 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≥ ((4 : Int) + a)) ∧ ((4 : Int) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((3 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6984 a b))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n614_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3416 a b) ∨ (fact_9fdb227ae99d_3434 a b) ∨ (fact_9fdb227ae99d_4509 a b) ∨ (fact_9fdb227ae99d_5593 a b) ∨ (fact_9fdb227ae99d_3881 a b) ∨ (fact_9fdb227ae99d_3498 a b) ∨ (fact_9fdb227ae99d_3520 a b) ∨ (((((-3 : Int) - b) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-3 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3448 a b) ∨ (fact_9fdb227ae99d_4143 a b) ∨ (fact_9fdb227ae99d_5729 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n614_run_tall (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a > b))
    (h4 : (¬ ((((-4 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7868 a b) ∨ (fact_9fdb227ae99d_7649 a b))) ∨ (((-4 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + (2 : Int))) ∧ (fact_9fdb227ae99d_7868 a b) ∧ (fact_9fdb227ae99d_7649 a b)) ∨ ((-4 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + (4 : Int))) ∨ (((-4 : Int) = (((-1 : Int) + ((-1 : Int) * a)) + (1 : Int))) ∧ (fact_9fdb227ae99d_7868 a b) ∧ (fact_9fdb227ae99d_7649 a b) ∧ (((fact_9fdb227ae99d_6009 a b) ∨ (fact_9fdb227ae99d_6047 a b) ∨ (fact_9fdb227ae99d_6809 a b) ∨ (fact_9fdb227ae99d_7021 a b) ∨ (fact_9fdb227ae99d_6575 a b) ∨ (fact_9fdb227ae99d_6195 a b) ∨ (fact_9fdb227ae99d_6252 a b) ∨ (((((-3 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((-3 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_6080 a b) ∨ (fact_9fdb227ae99d_6636 a b) ∨ (fact_9fdb227ae99d_7105 a b)) ∨ ((fact_9fdb227ae99d_4075 a b) ∨ (fact_9fdb227ae99d_4103 a b) ∨ (fact_9fdb227ae99d_5309 a b) ∨ (fact_9fdb227ae99d_5924 a b) ∨ (fact_9fdb227ae99d_4738 a b) ∨ (fact_9fdb227ae99d_4212 a b) ∨ (fact_9fdb227ae99d_4249 a b) ∨ (fact_9fdb227ae99d_4295 a b) ∨ (fact_9fdb227ae99d_4117 a b) ∨ (fact_9fdb227ae99d_5010 a b) ∨ (fact_9fdb227ae99d_6168 a b)))) ∨ ((fact_9fdb227ae99d_7868 a b) ∧ (fact_9fdb227ae99d_7649 a b) ∧ ((fact_9fdb227ae99d_6009 a b) ∨ (fact_9fdb227ae99d_6047 a b) ∨ (fact_9fdb227ae99d_6809 a b) ∨ (fact_9fdb227ae99d_7021 a b) ∨ (fact_9fdb227ae99d_6575 a b) ∨ (fact_9fdb227ae99d_6195 a b) ∨ (fact_9fdb227ae99d_6252 a b) ∨ (((((-3 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((-3 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_6080 a b) ∨ (fact_9fdb227ae99d_6636 a b) ∨ (fact_9fdb227ae99d_7105 a b)) ∧ ((fact_9fdb227ae99d_4075 a b) ∨ (fact_9fdb227ae99d_4103 a b) ∨ (fact_9fdb227ae99d_5309 a b) ∨ (fact_9fdb227ae99d_5924 a b) ∨ (fact_9fdb227ae99d_4738 a b) ∨ (fact_9fdb227ae99d_4212 a b) ∨ (fact_9fdb227ae99d_4249 a b) ∨ (fact_9fdb227ae99d_4295 a b) ∨ (fact_9fdb227ae99d_4117 a b) ∨ (fact_9fdb227ae99d_5010 a b) ∨ (fact_9fdb227ae99d_6168 a b))))))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n614_run_empty (a b run_x : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((-1 : Int) + ((-1 : Int) * a)) ≤ run_x))
    (h3 : ((fact_9fdb227ae99d_2367 a b run_x) ∨ (fact_9fdb227ae99d_2384 a b run_x) ∨ (fact_9fdb227ae99d_3040 a b run_x) ∨ (fact_9fdb227ae99d_3481 a b run_x) ∨ (fact_9fdb227ae99d_2928 a b run_x) ∨ (fact_9fdb227ae99d_2462 a b run_x) ∨ (fact_9fdb227ae99d_2474 a b run_x) ∨ (fact_9fdb227ae99d_2485 a b run_x) ∨ (fact_9fdb227ae99d_2398 a b run_x) ∨ (fact_9fdb227ae99d_2948 a b run_x) ∨ (fact_9fdb227ae99d_3616 a b run_x)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((-4 : Int) ≥ run_x))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n614_run_floor (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((-4 : Int) ≥ run_x))
    (h2 : (¬ ((fact_9fdb227ae99d_3179 a b run_x) ∨ (fact_9fdb227ae99d_3189 a b run_x) ∨ (fact_9fdb227ae99d_3731 a b run_x) ∨ (fact_9fdb227ae99d_5196 a b run_x) ∨ (fact_9fdb227ae99d_3490 a b run_x) ∨ (fact_9fdb227ae99d_3215 a b run_x) ∨ (fact_9fdb227ae99d_3230 a b run_x) ∨ (fact_9fdb227ae99d_3248 a b run_x) ∨ (fact_9fdb227ae99d_3197 a b run_x) ∨ (fact_9fdb227ae99d_3559 a b run_x) ∨ (fact_9fdb227ae99d_5363 a b run_x))))
    (h3 : (((-1 : Int) + ((-1 : Int) * a)) ≤ run_x))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n615_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≤ ((2 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n615_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + b) - (3 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n615_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n615_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3365 a b) ∨ (fact_9fdb227ae99d_3372 a b) ∨ (fact_9fdb227ae99d_4407 a b) ∨ (fact_9fdb227ae99d_5546 a b) ∨ (fact_9fdb227ae99d_3735 a b) ∨ (fact_9fdb227ae99d_3392 a b) ∨ (fact_9fdb227ae99d_3402 a b) ∨ (((((-3 : Int) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3376 a b) ∨ (fact_9fdb227ae99d_3740 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n615_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3752 a b) ∨ (fact_9fdb227ae99d_3784 a b) ∨ (fact_9fdb227ae99d_5162 a b) ∨ (fact_9fdb227ae99d_5840 a b) ∨ (fact_9fdb227ae99d_4535 a b) ∨ (fact_9fdb227ae99d_3900 a b) ∨ (fact_9fdb227ae99d_3947 a b) ∨ (((((-3 : Int) - b) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((-3 : Int) ≥ (((2 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3812 a b) ∨ (fact_9fdb227ae99d_4558 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n615_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ (((((3 : Int) + (3 : Int)) ≤ ((2 : Int) + b)) ∧ ((fact_9fdb227ae99d_7467 a b) ∨ (fact_9fdb227ae99d_7575 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ ((2 : Int) + b)) ∧ (fact_9fdb227ae99d_7467 a b) ∧ (fact_9fdb227ae99d_7575 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ ((2 : Int) + b)) ∨ ((((2 : Int) + b) = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7467 a b) ∧ (fact_9fdb227ae99d_7575 a b) ∧ (((fact_9fdb227ae99d_3761 a b) ∨ (fact_9fdb227ae99d_3793 a b) ∨ (fact_9fdb227ae99d_5171 a b) ∨ (fact_9fdb227ae99d_5849 a b) ∨ (fact_9fdb227ae99d_4542 a b) ∨ (fact_9fdb227ae99d_3907 a b) ∨ (fact_9fdb227ae99d_3954 a b) ∨ (fact_9fdb227ae99d_4023 a b) ∨ (fact_9fdb227ae99d_3814 a b) ∨ (fact_9fdb227ae99d_4561 a b)) ∨ ((fact_9fdb227ae99d_4576 a b) ∨ (fact_9fdb227ae99d_4611 a b) ∨ (fact_9fdb227ae99d_5642 a b) ∨ (fact_9fdb227ae99d_6383 a b) ∨ (fact_9fdb227ae99d_5379 a b) ∨ (fact_9fdb227ae99d_4761 a b) ∨ (fact_9fdb227ae99d_4803 a b) ∨ (fact_9fdb227ae99d_4886 a b) ∨ (fact_9fdb227ae99d_4641 a b) ∨ (fact_9fdb227ae99d_5399 a b)))) ∨ ((fact_9fdb227ae99d_7467 a b) ∧ (fact_9fdb227ae99d_7575 a b) ∧ ((fact_9fdb227ae99d_3761 a b) ∨ (fact_9fdb227ae99d_3793 a b) ∨ (fact_9fdb227ae99d_5171 a b) ∨ (fact_9fdb227ae99d_5849 a b) ∨ (fact_9fdb227ae99d_4542 a b) ∨ (fact_9fdb227ae99d_3907 a b) ∨ (fact_9fdb227ae99d_3954 a b) ∨ (fact_9fdb227ae99d_4023 a b) ∨ (fact_9fdb227ae99d_3814 a b) ∨ (fact_9fdb227ae99d_4561 a b)) ∧ ((fact_9fdb227ae99d_4576 a b) ∨ (fact_9fdb227ae99d_4611 a b) ∨ (fact_9fdb227ae99d_5642 a b) ∨ (fact_9fdb227ae99d_6383 a b) ∨ (fact_9fdb227ae99d_5379 a b) ∨ (fact_9fdb227ae99d_4761 a b) ∨ (fact_9fdb227ae99d_4803 a b) ∨ (fact_9fdb227ae99d_4886 a b) ∨ (fact_9fdb227ae99d_4641 a b) ∨ (fact_9fdb227ae99d_5399 a b))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n615_run_empty (a b run_x : Int)
    (h0 : ((fact_9fdb227ae99d_2368 a b run_x) ∨ (fact_9fdb227ae99d_2385 a b run_x) ∨ (fact_9fdb227ae99d_3041 a b run_x) ∨ (fact_9fdb227ae99d_3482 a b run_x) ∨ (fact_9fdb227ae99d_2929 a b run_x) ∨ (fact_9fdb227ae99d_2463 a b run_x) ∨ (fact_9fdb227ae99d_2475 a b run_x) ∨ (fact_9fdb227ae99d_2486 a b run_x) ∨ (fact_9fdb227ae99d_2399 a b run_x) ∨ (fact_9fdb227ae99d_2932 a b run_x)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((3 : Int) ≤ run_x))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (run_x ≤ ((2 : Int) + b)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n615_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((2 : Int) + b)))
    (h1 : (¬ ((fact_9fdb227ae99d_3180 a b run_x) ∨ (fact_9fdb227ae99d_3190 a b run_x) ∨ (fact_9fdb227ae99d_3732 a b run_x) ∨ (fact_9fdb227ae99d_5197 a b run_x) ∨ (fact_9fdb227ae99d_3491 a b run_x) ∨ (fact_9fdb227ae99d_3216 a b run_x) ∨ (fact_9fdb227ae99d_3231 a b run_x) ∨ (fact_9fdb227ae99d_3249 a b run_x) ∨ (fact_9fdb227ae99d_3198 a b run_x) ∨ (fact_9fdb227ae99d_3494 a b run_x))))
    (h2 : ((3 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

end LRegionArithmetic

import HPFiniteA5B5Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
namespace THalfPlaneFinite
open CrossUnits PolyominoFormal

theorem hp5_5_node870 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected870 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected870 ((8 : Int),(1 : Int)) hp5_5_branches870 hp5_5_evidence870 hp5_5_check870 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches870,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node869 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected869 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected869 ((6 : Int),(1 : Int)) hp5_5_branches869 hp5_5_evidence869 hp5_5_check869 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches869,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node868 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected868 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected868 ((6 : Int),(1 : Int)) hp5_5_branches868 hp5_5_evidence868 hp5_5_check868 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches868,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node867 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected867 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected867 ((6 : Int),(1 : Int)) hp5_5_branches867 hp5_5_evidence867 hp5_5_check867 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches867,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node866 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected866 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected866 ((7 : Int),(1 : Int)) hp5_5_branches866 hp5_5_evidence866 hp5_5_check866 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches866,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node867 T childKnown
  · exact hp5_5_node868 T childKnown
  · exact hp5_5_node869 T childKnown
  · exact hp5_5_node870 T childKnown
theorem hp5_5_node865 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected865 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected865 ((7 : Int),(1 : Int)) hp5_5_branches865 hp5_5_evidence865 hp5_5_check865 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches865,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node864 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected864 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected864 ((7 : Int),(1 : Int)) hp5_5_branches864 hp5_5_evidence864 hp5_5_check864 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches864,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node863 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected863 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected863 ((7 : Int),(1 : Int)) hp5_5_branches863 hp5_5_evidence863 hp5_5_check863 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches863,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node862 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected862 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected862 ((1 : Int),(2 : Int)) hp5_5_branches862 hp5_5_evidence862 hp5_5_check862 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches862,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node861 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected861 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected861 ((1 : Int),(2 : Int)) hp5_5_branches861 hp5_5_evidence861 hp5_5_check861 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches861,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node860 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected860 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected860 ((4 : Int),(1 : Int)) hp5_5_branches860 hp5_5_evidence860 hp5_5_check860 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches860,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node861 T childKnown
  · exact hp5_5_node862 T childKnown
theorem hp5_5_node859 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected859 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected859 ((7 : Int),(1 : Int)) hp5_5_branches859 hp5_5_evidence859 hp5_5_check859 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches859,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node860 T childKnown
theorem hp5_5_node858 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected858 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected858 ((6 : Int),(1 : Int)) hp5_5_branches858 hp5_5_evidence858 hp5_5_check858 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches858,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node859 T childKnown
  · exact hp5_5_node863 T childKnown
  · exact hp5_5_node864 T childKnown
  · exact hp5_5_node865 T childKnown
theorem hp5_5_node857 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected857 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected857 ((8 : Int),(1 : Int)) hp5_5_branches857 hp5_5_evidence857 hp5_5_check857 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches857,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node856 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected856 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected856 ((8 : Int),(0 : Int)) hp5_5_branches856 hp5_5_evidence856 hp5_5_check856 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches856,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node857 T childKnown
theorem hp5_5_node855 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected855 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected855 ((6 : Int),(1 : Int)) hp5_5_branches855 hp5_5_evidence855 hp5_5_check855 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches855,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node856 T childKnown
theorem hp5_5_node854 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected854 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected854 ((1 : Int),(2 : Int)) hp5_5_branches854 hp5_5_evidence854 hp5_5_check854 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches854,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node853 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected853 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected853 ((1 : Int),(2 : Int)) hp5_5_branches853 hp5_5_evidence853 hp5_5_check853 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches853,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node852 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected852 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected852 ((4 : Int),(1 : Int)) hp5_5_branches852 hp5_5_evidence852 hp5_5_check852 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches852,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node853 T childKnown
  · exact hp5_5_node854 T childKnown
theorem hp5_5_node851 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected851 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected851 ((8 : Int),(0 : Int)) hp5_5_branches851 hp5_5_evidence851 hp5_5_check851 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches851,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node852 T childKnown
theorem hp5_5_node850 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected850 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected850 ((6 : Int),(1 : Int)) hp5_5_branches850 hp5_5_evidence850 hp5_5_check850 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches850,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node851 T childKnown
theorem hp5_5_node849 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected849 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected849 ((6 : Int),(1 : Int)) hp5_5_branches849 hp5_5_evidence849 hp5_5_check849 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches849,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node848 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected848 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected848 ((7 : Int),(0 : Int)) hp5_5_branches848 hp5_5_evidence848 hp5_5_check848 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches848,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node849 T childKnown
  · exact hp5_5_node850 T childKnown
  · exact hp5_5_node855 T childKnown
  · exact hp5_5_node858 T childKnown
  · exact hp5_5_node866 T childKnown
theorem hp5_5_node847 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected847 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected847 ((2 : Int),(2 : Int)) hp5_5_branches847 hp5_5_evidence847 hp5_5_check847 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches847,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node846 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected846 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected846 ((2 : Int),(2 : Int)) hp5_5_branches846 hp5_5_evidence846 hp5_5_check846 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches846,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node845 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected845 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected845 ((2 : Int),(1 : Int)) hp5_5_branches845 hp5_5_evidence845 hp5_5_check845 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches845,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node846 T childKnown
  · exact hp5_5_node847 T childKnown
theorem hp5_5_node844 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected844 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected844 ((2 : Int),(2 : Int)) hp5_5_branches844 hp5_5_evidence844 hp5_5_check844 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches844,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node843 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected843 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected843 ((2 : Int),(2 : Int)) hp5_5_branches843 hp5_5_evidence843 hp5_5_check843 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches843,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node842 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected842 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected842 ((2 : Int),(1 : Int)) hp5_5_branches842 hp5_5_evidence842 hp5_5_check842 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches842,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node843 T childKnown
  · exact hp5_5_node844 T childKnown
theorem hp5_5_node841 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected841 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected841 ((10 : Int),(1 : Int)) hp5_5_branches841 hp5_5_evidence841 hp5_5_check841 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches841,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node840 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected840 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected840 ((8 : Int),(2 : Int)) hp5_5_branches840 hp5_5_evidence840 hp5_5_check840 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches840,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node839 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected839 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected839 ((9 : Int),(1 : Int)) hp5_5_branches839 hp5_5_evidence839 hp5_5_check839 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches839,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node840 T childKnown
  · exact hp5_5_node841 T childKnown
theorem hp5_5_node838 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected838 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected838 ((7 : Int),(0 : Int)) hp5_5_branches838 hp5_5_evidence838 hp5_5_check838 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches838,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node839 T childKnown
theorem hp5_5_node837 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected837 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected837 ((3 : Int),(2 : Int)) hp5_5_branches837 hp5_5_evidence837 hp5_5_check837 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches837,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node836 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected836 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected836 ((3 : Int),(2 : Int)) hp5_5_branches836 hp5_5_evidence836 hp5_5_check836 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches836,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node835 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected835 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected835 ((3 : Int),(2 : Int)) hp5_5_branches835 hp5_5_evidence835 hp5_5_check835 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches835,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node834 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected834 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected834 ((4 : Int),(2 : Int)) hp5_5_branches834 hp5_5_evidence834 hp5_5_check834 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches834,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node833 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected833 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected833 ((3 : Int),(2 : Int)) hp5_5_branches833 hp5_5_evidence833 hp5_5_check833 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches833,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node834 T childKnown
theorem hp5_5_node832 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected832 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected832 ((2 : Int),(2 : Int)) hp5_5_branches832 hp5_5_evidence832 hp5_5_check832 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches832,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node833 T childKnown
  · exact hp5_5_node835 T childKnown
  · exact hp5_5_node836 T childKnown
  · exact hp5_5_node837 T childKnown
theorem hp5_5_node831 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected831 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected831 ((9 : Int),(1 : Int)) hp5_5_branches831 hp5_5_evidence831 hp5_5_check831 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches831,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node830 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected830 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected830 ((11 : Int),(1 : Int)) hp5_5_branches830 hp5_5_evidence830 hp5_5_check830 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches830,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node829 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected829 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected829 ((10 : Int),(1 : Int)) hp5_5_branches829 hp5_5_evidence829 hp5_5_check829 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches829,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node830 T childKnown
theorem hp5_5_node828 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected828 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected828 ((4 : Int),(2 : Int)) hp5_5_branches828 hp5_5_evidence828 hp5_5_check828 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches828,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node829 T childKnown
  · exact hp5_5_node831 T childKnown
theorem hp5_5_node827 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected827 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected827 ((9 : Int),(1 : Int)) hp5_5_branches827 hp5_5_evidence827 hp5_5_check827 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches827,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node826 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected826 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected826 ((11 : Int),(1 : Int)) hp5_5_branches826 hp5_5_evidence826 hp5_5_check826 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches826,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node825 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected825 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected825 ((10 : Int),(1 : Int)) hp5_5_branches825 hp5_5_evidence825 hp5_5_check825 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches825,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node826 T childKnown
theorem hp5_5_node824 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected824 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected824 ((4 : Int),(2 : Int)) hp5_5_branches824 hp5_5_evidence824 hp5_5_check824 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches824,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node825 T childKnown
  · exact hp5_5_node827 T childKnown
theorem hp5_5_node823 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected823 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected823 ((9 : Int),(1 : Int)) hp5_5_branches823 hp5_5_evidence823 hp5_5_check823 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches823,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node822 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected822 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected822 ((11 : Int),(1 : Int)) hp5_5_branches822 hp5_5_evidence822 hp5_5_check822 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches822,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node821 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected821 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected821 ((10 : Int),(1 : Int)) hp5_5_branches821 hp5_5_evidence821 hp5_5_check821 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches821,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node822 T childKnown
theorem hp5_5_node820 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected820 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected820 ((9 : Int),(1 : Int)) hp5_5_branches820 hp5_5_evidence820 hp5_5_check820 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches820,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node819 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected819 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected819 ((5 : Int),(2 : Int)) hp5_5_branches819 hp5_5_evidence819 hp5_5_check819 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches819,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node818 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected818 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected818 ((9 : Int),(1 : Int)) hp5_5_branches818 hp5_5_evidence818 hp5_5_check818 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches818,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node819 T childKnown
theorem hp5_5_node817 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected817 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected817 ((9 : Int),(1 : Int)) hp5_5_branches817 hp5_5_evidence817 hp5_5_check817 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches817,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node816 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected816 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected816 ((4 : Int),(2 : Int)) hp5_5_branches816 hp5_5_evidence816 hp5_5_check816 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches816,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node817 T childKnown
  · exact hp5_5_node818 T childKnown
  · exact hp5_5_node820 T childKnown
  · exact hp5_5_node821 T childKnown
  · exact hp5_5_node823 T childKnown
theorem hp5_5_node815 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected815 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected815 ((4 : Int),(2 : Int)) hp5_5_branches815 hp5_5_evidence815 hp5_5_check815 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches815,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node814 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected814 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected814 ((8 : Int),(2 : Int)) hp5_5_branches814 hp5_5_evidence814 hp5_5_check814 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches814,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node813 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected813 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected813 ((4 : Int),(2 : Int)) hp5_5_branches813 hp5_5_evidence813 hp5_5_check813 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches813,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node812 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected812 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected812 ((4 : Int),(2 : Int)) hp5_5_branches812 hp5_5_evidence812 hp5_5_check812 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches812,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node811 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected811 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected811 ((11 : Int),(1 : Int)) hp5_5_branches811 hp5_5_evidence811 hp5_5_check811 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches811,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node810 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected810 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected810 ((10 : Int),(1 : Int)) hp5_5_branches810 hp5_5_evidence810 hp5_5_check810 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches810,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node811 T childKnown
theorem hp5_5_node809 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected809 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected809 ((9 : Int),(1 : Int)) hp5_5_branches809 hp5_5_evidence809 hp5_5_check809 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches809,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node810 T childKnown
  · exact hp5_5_node812 T childKnown
  · exact hp5_5_node813 T childKnown
  · exact hp5_5_node814 T childKnown
  · exact hp5_5_node815 T childKnown
theorem hp5_5_node808 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected808 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected808 ((2 : Int),(2 : Int)) hp5_5_branches808 hp5_5_evidence808 hp5_5_check808 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches808,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node809 T childKnown
  · exact hp5_5_node816 T childKnown
  · exact hp5_5_node824 T childKnown
  · exact hp5_5_node828 T childKnown
theorem hp5_5_node807 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected807 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected807 ((7 : Int),(0 : Int)) hp5_5_branches807 hp5_5_evidence807 hp5_5_check807 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches807,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node808 T childKnown
theorem hp5_5_node806 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected806 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected806 ((3 : Int),(2 : Int)) hp5_5_branches806 hp5_5_evidence806 hp5_5_check806 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches806,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node805 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected805 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected805 ((3 : Int),(2 : Int)) hp5_5_branches805 hp5_5_evidence805 hp5_5_check805 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches805,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node804 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected804 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected804 ((3 : Int),(1 : Int)) hp5_5_branches804 hp5_5_evidence804 hp5_5_check804 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches804,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node805 T childKnown
  · exact hp5_5_node806 T childKnown
theorem hp5_5_node803 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected803 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected803 ((11 : Int),(1 : Int)) hp5_5_branches803 hp5_5_evidence803 hp5_5_check803 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches803,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node802 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected802 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected802 ((9 : Int),(2 : Int)) hp5_5_branches802 hp5_5_evidence802 hp5_5_check802 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches802,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node801 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected801 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected801 ((10 : Int),(1 : Int)) hp5_5_branches801 hp5_5_evidence801 hp5_5_check801 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches801,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node802 T childKnown
  · exact hp5_5_node803 T childKnown
theorem hp5_5_node800 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected800 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected800 ((7 : Int),(0 : Int)) hp5_5_branches800 hp5_5_evidence800 hp5_5_check800 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches800,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node801 T childKnown
theorem hp5_5_node799 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected799 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected799 ((7 : Int),(0 : Int)) hp5_5_branches799 hp5_5_evidence799 hp5_5_check799 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches799,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node798 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected798 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected798 ((3 : Int),(1 : Int)) hp5_5_branches798 hp5_5_evidence798 hp5_5_check798 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches798,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node799 T childKnown
  · exact hp5_5_node800 T childKnown
theorem hp5_5_node797 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected797 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected797 ((2 : Int),(1 : Int)) hp5_5_branches797 hp5_5_evidence797 hp5_5_check797 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches797,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node798 T childKnown
  · exact hp5_5_node804 T childKnown
  · exact hp5_5_node807 T childKnown
  · exact hp5_5_node832 T childKnown
  · exact hp5_5_node838 T childKnown
theorem hp5_5_node796 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected796 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected796 ((3 : Int),(2 : Int)) hp5_5_branches796 hp5_5_evidence796 hp5_5_check796 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches796,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node795 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected795 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected795 ((3 : Int),(2 : Int)) hp5_5_branches795 hp5_5_evidence795 hp5_5_check795 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches795,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node794 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected794 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected794 ((2 : Int),(2 : Int)) hp5_5_branches794 hp5_5_evidence794 hp5_5_check794 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches794,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node795 T childKnown
  · exact hp5_5_node796 T childKnown
theorem hp5_5_node793 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected793 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected793 ((7 : Int),(0 : Int)) hp5_5_branches793 hp5_5_evidence793 hp5_5_check793 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches793,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node794 T childKnown
theorem hp5_5_node792 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected792 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected792 ((3 : Int),(2 : Int)) hp5_5_branches792 hp5_5_evidence792 hp5_5_check792 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches792,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node791 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected791 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected791 ((3 : Int),(2 : Int)) hp5_5_branches791 hp5_5_evidence791 hp5_5_check791 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches791,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node790 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected790 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected790 ((2 : Int),(2 : Int)) hp5_5_branches790 hp5_5_evidence790 hp5_5_check790 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches790,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node791 T childKnown
  · exact hp5_5_node792 T childKnown
theorem hp5_5_node789 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected789 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected789 ((9 : Int),(1 : Int)) hp5_5_branches789 hp5_5_evidence789 hp5_5_check789 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches789,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node788 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected788 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected788 ((11 : Int),(1 : Int)) hp5_5_branches788 hp5_5_evidence788 hp5_5_check788 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches788,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node787 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected787 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected787 ((10 : Int),(1 : Int)) hp5_5_branches787 hp5_5_evidence787 hp5_5_check787 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches787,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node788 T childKnown
theorem hp5_5_node786 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected786 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected786 ((4 : Int),(2 : Int)) hp5_5_branches786 hp5_5_evidence786 hp5_5_check786 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches786,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node787 T childKnown
  · exact hp5_5_node789 T childKnown
theorem hp5_5_node785 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected785 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected785 ((9 : Int),(1 : Int)) hp5_5_branches785 hp5_5_evidence785 hp5_5_check785 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches785,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node784 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected784 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected784 ((11 : Int),(1 : Int)) hp5_5_branches784 hp5_5_evidence784 hp5_5_check784 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches784,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node783 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected783 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected783 ((10 : Int),(1 : Int)) hp5_5_branches783 hp5_5_evidence783 hp5_5_check783 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches783,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node784 T childKnown
theorem hp5_5_node782 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected782 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected782 ((4 : Int),(2 : Int)) hp5_5_branches782 hp5_5_evidence782 hp5_5_check782 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches782,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node783 T childKnown
  · exact hp5_5_node785 T childKnown
theorem hp5_5_node781 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected781 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected781 ((2 : Int),(2 : Int)) hp5_5_branches781 hp5_5_evidence781 hp5_5_check781 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches781,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node782 T childKnown
  · exact hp5_5_node786 T childKnown
theorem hp5_5_node780 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected780 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected780 ((7 : Int),(0 : Int)) hp5_5_branches780 hp5_5_evidence780 hp5_5_check780 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches780,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node781 T childKnown
theorem hp5_5_node779 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected779 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected779 ((3 : Int),(2 : Int)) hp5_5_branches779 hp5_5_evidence779 hp5_5_check779 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches779,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node778 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected778 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected778 ((3 : Int),(2 : Int)) hp5_5_branches778 hp5_5_evidence778 hp5_5_check778 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches778,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node777 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected777 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected777 ((3 : Int),(1 : Int)) hp5_5_branches777 hp5_5_evidence777 hp5_5_check777 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches777,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node778 T childKnown
  · exact hp5_5_node779 T childKnown
theorem hp5_5_node776 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected776 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected776 ((11 : Int),(1 : Int)) hp5_5_branches776 hp5_5_evidence776 hp5_5_check776 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches776,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node775 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected775 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected775 ((9 : Int),(2 : Int)) hp5_5_branches775 hp5_5_evidence775 hp5_5_check775 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches775,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node774 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected774 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected774 ((10 : Int),(1 : Int)) hp5_5_branches774 hp5_5_evidence774 hp5_5_check774 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches774,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node775 T childKnown
  · exact hp5_5_node776 T childKnown
theorem hp5_5_node773 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected773 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected773 ((7 : Int),(0 : Int)) hp5_5_branches773 hp5_5_evidence773 hp5_5_check773 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches773,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node774 T childKnown
theorem hp5_5_node772 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected772 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected772 ((7 : Int),(0 : Int)) hp5_5_branches772 hp5_5_evidence772 hp5_5_check772 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches772,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node771 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected771 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected771 ((3 : Int),(1 : Int)) hp5_5_branches771 hp5_5_evidence771 hp5_5_check771 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches771,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node772 T childKnown
  · exact hp5_5_node773 T childKnown
theorem hp5_5_node770 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected770 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected770 ((3 : Int),(2 : Int)) hp5_5_branches770 hp5_5_evidence770 hp5_5_check770 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches770,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node769 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected769 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected769 ((3 : Int),(2 : Int)) hp5_5_branches769 hp5_5_evidence769 hp5_5_check769 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches769,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node768 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected768 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected768 ((3 : Int),(1 : Int)) hp5_5_branches768 hp5_5_evidence768 hp5_5_check768 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches768,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node769 T childKnown
  · exact hp5_5_node770 T childKnown
theorem hp5_5_node767 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected767 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected767 ((2 : Int),(1 : Int)) hp5_5_branches767 hp5_5_evidence767 hp5_5_check767 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches767,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node768 T childKnown
  · exact hp5_5_node771 T childKnown
  · exact hp5_5_node777 T childKnown
  · exact hp5_5_node780 T childKnown
  · exact hp5_5_node790 T childKnown
  · exact hp5_5_node793 T childKnown
theorem hp5_5_node766 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected766 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected766 ((3 : Int),(2 : Int)) hp5_5_branches766 hp5_5_evidence766 hp5_5_check766 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches766,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node765 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected765 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected765 ((3 : Int),(2 : Int)) hp5_5_branches765 hp5_5_evidence765 hp5_5_check765 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches765,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node764 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected764 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected764 ((2 : Int),(2 : Int)) hp5_5_branches764 hp5_5_evidence764 hp5_5_check764 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches764,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node765 T childKnown
  · exact hp5_5_node766 T childKnown
theorem hp5_5_node763 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected763 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected763 ((7 : Int),(0 : Int)) hp5_5_branches763 hp5_5_evidence763 hp5_5_check763 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches763,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node764 T childKnown
theorem hp5_5_node762 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected762 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected762 ((3 : Int),(2 : Int)) hp5_5_branches762 hp5_5_evidence762 hp5_5_check762 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches762,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node761 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected761 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected761 ((3 : Int),(2 : Int)) hp5_5_branches761 hp5_5_evidence761 hp5_5_check761 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches761,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node760 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected760 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected760 ((2 : Int),(2 : Int)) hp5_5_branches760 hp5_5_evidence760 hp5_5_check760 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches760,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node761 T childKnown
  · exact hp5_5_node762 T childKnown
theorem hp5_5_node759 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected759 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected759 ((9 : Int),(1 : Int)) hp5_5_branches759 hp5_5_evidence759 hp5_5_check759 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches759,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node758 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected758 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected758 ((11 : Int),(1 : Int)) hp5_5_branches758 hp5_5_evidence758 hp5_5_check758 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches758,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node757 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected757 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected757 ((10 : Int),(1 : Int)) hp5_5_branches757 hp5_5_evidence757 hp5_5_check757 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches757,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node758 T childKnown
theorem hp5_5_node756 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected756 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected756 ((4 : Int),(2 : Int)) hp5_5_branches756 hp5_5_evidence756 hp5_5_check756 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches756,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node757 T childKnown
  · exact hp5_5_node759 T childKnown
theorem hp5_5_node755 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected755 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected755 ((9 : Int),(1 : Int)) hp5_5_branches755 hp5_5_evidence755 hp5_5_check755 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches755,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node754 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected754 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected754 ((11 : Int),(1 : Int)) hp5_5_branches754 hp5_5_evidence754 hp5_5_check754 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches754,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node753 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected753 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected753 ((10 : Int),(1 : Int)) hp5_5_branches753 hp5_5_evidence753 hp5_5_check753 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches753,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node754 T childKnown
theorem hp5_5_node752 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected752 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected752 ((4 : Int),(2 : Int)) hp5_5_branches752 hp5_5_evidence752 hp5_5_check752 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches752,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node753 T childKnown
  · exact hp5_5_node755 T childKnown
theorem hp5_5_node751 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected751 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected751 ((2 : Int),(2 : Int)) hp5_5_branches751 hp5_5_evidence751 hp5_5_check751 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches751,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node752 T childKnown
  · exact hp5_5_node756 T childKnown
theorem hp5_5_node750 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected750 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected750 ((7 : Int),(0 : Int)) hp5_5_branches750 hp5_5_evidence750 hp5_5_check750 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches750,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node751 T childKnown
theorem hp5_5_node749 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected749 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected749 ((3 : Int),(2 : Int)) hp5_5_branches749 hp5_5_evidence749 hp5_5_check749 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches749,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node748 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected748 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected748 ((3 : Int),(2 : Int)) hp5_5_branches748 hp5_5_evidence748 hp5_5_check748 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches748,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node747 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected747 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected747 ((3 : Int),(1 : Int)) hp5_5_branches747 hp5_5_evidence747 hp5_5_check747 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches747,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node748 T childKnown
  · exact hp5_5_node749 T childKnown
theorem hp5_5_node746 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected746 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected746 ((11 : Int),(1 : Int)) hp5_5_branches746 hp5_5_evidence746 hp5_5_check746 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches746,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node745 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected745 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected745 ((9 : Int),(2 : Int)) hp5_5_branches745 hp5_5_evidence745 hp5_5_check745 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches745,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node744 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected744 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected744 ((10 : Int),(1 : Int)) hp5_5_branches744 hp5_5_evidence744 hp5_5_check744 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches744,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node745 T childKnown
  · exact hp5_5_node746 T childKnown
theorem hp5_5_node743 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected743 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected743 ((7 : Int),(0 : Int)) hp5_5_branches743 hp5_5_evidence743 hp5_5_check743 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches743,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node744 T childKnown
theorem hp5_5_node742 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected742 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected742 ((7 : Int),(0 : Int)) hp5_5_branches742 hp5_5_evidence742 hp5_5_check742 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches742,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node741 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected741 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected741 ((3 : Int),(1 : Int)) hp5_5_branches741 hp5_5_evidence741 hp5_5_check741 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches741,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node742 T childKnown
  · exact hp5_5_node743 T childKnown
theorem hp5_5_node740 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected740 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected740 ((3 : Int),(2 : Int)) hp5_5_branches740 hp5_5_evidence740 hp5_5_check740 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches740,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node739 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected739 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected739 ((3 : Int),(2 : Int)) hp5_5_branches739 hp5_5_evidence739 hp5_5_check739 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches739,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node738 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected738 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected738 ((3 : Int),(1 : Int)) hp5_5_branches738 hp5_5_evidence738 hp5_5_check738 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches738,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node739 T childKnown
  · exact hp5_5_node740 T childKnown
theorem hp5_5_node737 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected737 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected737 ((2 : Int),(1 : Int)) hp5_5_branches737 hp5_5_evidence737 hp5_5_check737 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches737,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node738 T childKnown
  · exact hp5_5_node741 T childKnown
  · exact hp5_5_node747 T childKnown
  · exact hp5_5_node750 T childKnown
  · exact hp5_5_node760 T childKnown
  · exact hp5_5_node763 T childKnown
theorem hp5_5_node736 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected736 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected736 ((2 : Int),(1 : Int)) hp5_5_branches736 hp5_5_evidence736 hp5_5_check736 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches736,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node735 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected735 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected735 ((2 : Int),(1 : Int)) hp5_5_branches735 hp5_5_evidence735 hp5_5_check735 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches735,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node734 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected734 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected734 ((3 : Int),(2 : Int)) hp5_5_branches734 hp5_5_evidence734 hp5_5_check734 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches734,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node733 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected733 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected733 ((3 : Int),(2 : Int)) hp5_5_branches733 hp5_5_evidence733 hp5_5_check733 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches733,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node732 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected732 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected732 ((3 : Int),(1 : Int)) hp5_5_branches732 hp5_5_evidence732 hp5_5_check732 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches732,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node733 T childKnown
  · exact hp5_5_node734 T childKnown
theorem hp5_5_node731 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected731 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected731 ((2 : Int),(2 : Int)) hp5_5_branches731 hp5_5_evidence731 hp5_5_check731 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches731,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp5_5_node732 T childKnown
  · exact hp5_5_node735 T childKnown
  · exact hp5_5_node736 T childKnown
theorem hp5_5_node730 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected730 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected730 ((2 : Int),(1 : Int)) hp5_5_branches730 hp5_5_evidence730 hp5_5_check730 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches730,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node729 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected729 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected729 ((2 : Int),(1 : Int)) hp5_5_branches729 hp5_5_evidence729 hp5_5_check729 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches729,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node728 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected728 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected728 ((3 : Int),(2 : Int)) hp5_5_branches728 hp5_5_evidence728 hp5_5_check728 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches728,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node727 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected727 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected727 ((3 : Int),(2 : Int)) hp5_5_branches727 hp5_5_evidence727 hp5_5_check727 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches727,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node726 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected726 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected726 ((3 : Int),(1 : Int)) hp5_5_branches726 hp5_5_evidence726 hp5_5_check726 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches726,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node727 T childKnown
  · exact hp5_5_node728 T childKnown
theorem hp5_5_node725 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected725 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected725 ((2 : Int),(2 : Int)) hp5_5_branches725 hp5_5_evidence725 hp5_5_check725 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches725,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp5_5_node726 T childKnown
  · exact hp5_5_node729 T childKnown
  · exact hp5_5_node730 T childKnown
theorem hp5_5_node724 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected724 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected724 ((3 : Int),(2 : Int)) hp5_5_branches724 hp5_5_evidence724 hp5_5_check724 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches724,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node723 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected723 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected723 ((2 : Int),(2 : Int)) hp5_5_branches723 hp5_5_evidence723 hp5_5_check723 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches723,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node724 T childKnown
theorem hp5_5_node722 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected722 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected722 ((3 : Int),(2 : Int)) hp5_5_branches722 hp5_5_evidence722 hp5_5_check722 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches722,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node721 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected721 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected721 ((2 : Int),(2 : Int)) hp5_5_branches721 hp5_5_evidence721 hp5_5_check721 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches721,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node722 T childKnown
theorem hp5_5_node720 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected720 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected720 ((9 : Int),(1 : Int)) hp5_5_branches720 hp5_5_evidence720 hp5_5_check720 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches720,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node719 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected719 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected719 ((11 : Int),(1 : Int)) hp5_5_branches719 hp5_5_evidence719 hp5_5_check719 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches719,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node718 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected718 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected718 ((10 : Int),(1 : Int)) hp5_5_branches718 hp5_5_evidence718 hp5_5_check718 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches718,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node719 T childKnown
theorem hp5_5_node717 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected717 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected717 ((4 : Int),(2 : Int)) hp5_5_branches717 hp5_5_evidence717 hp5_5_check717 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches717,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node718 T childKnown
  · exact hp5_5_node720 T childKnown
theorem hp5_5_node716 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected716 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected716 ((7 : Int),(0 : Int)) hp5_5_branches716 hp5_5_evidence716 hp5_5_check716 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches716,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node717 T childKnown
theorem hp5_5_node715 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected715 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected715 ((2 : Int),(2 : Int)) hp5_5_branches715 hp5_5_evidence715 hp5_5_check715 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches715,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node716 T childKnown
theorem hp5_5_node714 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected714 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected714 ((3 : Int),(2 : Int)) hp5_5_branches714 hp5_5_evidence714 hp5_5_check714 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches714,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node713 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected713 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected713 ((3 : Int),(2 : Int)) hp5_5_branches713 hp5_5_evidence713 hp5_5_check713 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches713,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node712 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected712 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected712 ((3 : Int),(1 : Int)) hp5_5_branches712 hp5_5_evidence712 hp5_5_check712 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches712,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node713 T childKnown
  · exact hp5_5_node714 T childKnown
theorem hp5_5_node711 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected711 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected711 ((11 : Int),(1 : Int)) hp5_5_branches711 hp5_5_evidence711 hp5_5_check711 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches711,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node710 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected710 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected710 ((9 : Int),(2 : Int)) hp5_5_branches710 hp5_5_evidence710 hp5_5_check710 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches710,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node709 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected709 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected709 ((10 : Int),(1 : Int)) hp5_5_branches709 hp5_5_evidence709 hp5_5_check709 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches709,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node710 T childKnown
  · exact hp5_5_node711 T childKnown
theorem hp5_5_node708 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected708 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected708 ((7 : Int),(0 : Int)) hp5_5_branches708 hp5_5_evidence708 hp5_5_check708 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches708,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node709 T childKnown
theorem hp5_5_node707 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected707 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected707 ((7 : Int),(0 : Int)) hp5_5_branches707 hp5_5_evidence707 hp5_5_check707 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches707,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node706 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected706 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected706 ((3 : Int),(1 : Int)) hp5_5_branches706 hp5_5_evidence706 hp5_5_check706 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches706,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node707 T childKnown
  · exact hp5_5_node708 T childKnown
theorem hp5_5_node705 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected705 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected705 ((3 : Int),(2 : Int)) hp5_5_branches705 hp5_5_evidence705 hp5_5_check705 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches705,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node704 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected704 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected704 ((3 : Int),(2 : Int)) hp5_5_branches704 hp5_5_evidence704 hp5_5_check704 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches704,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node703 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected703 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected703 ((3 : Int),(1 : Int)) hp5_5_branches703 hp5_5_evidence703 hp5_5_check703 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches703,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node704 T childKnown
  · exact hp5_5_node705 T childKnown
theorem hp5_5_node702 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected702 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected702 ((2 : Int),(1 : Int)) hp5_5_branches702 hp5_5_evidence702 hp5_5_check702 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches702,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node703 T childKnown
  · exact hp5_5_node706 T childKnown
  · exact hp5_5_node712 T childKnown
  · exact hp5_5_node715 T childKnown
  · exact hp5_5_node721 T childKnown
  · exact hp5_5_node723 T childKnown
theorem hp5_5_node701 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected701 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected701 ((3 : Int),(2 : Int)) hp5_5_branches701 hp5_5_evidence701 hp5_5_check701 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches701,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node700 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected700 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected700 ((3 : Int),(2 : Int)) hp5_5_branches700 hp5_5_evidence700 hp5_5_check700 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches700,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node699 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected699 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected699 ((2 : Int),(2 : Int)) hp5_5_branches699 hp5_5_evidence699 hp5_5_check699 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches699,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node700 T childKnown
  · exact hp5_5_node701 T childKnown
theorem hp5_5_node698 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected698 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected698 ((7 : Int),(0 : Int)) hp5_5_branches698 hp5_5_evidence698 hp5_5_check698 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches698,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node699 T childKnown
theorem hp5_5_node697 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected697 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected697 ((3 : Int),(2 : Int)) hp5_5_branches697 hp5_5_evidence697 hp5_5_check697 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches697,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node696 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected696 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected696 ((3 : Int),(2 : Int)) hp5_5_branches696 hp5_5_evidence696 hp5_5_check696 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches696,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node695 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected695 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected695 ((2 : Int),(2 : Int)) hp5_5_branches695 hp5_5_evidence695 hp5_5_check695 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches695,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node696 T childKnown
  · exact hp5_5_node697 T childKnown
theorem hp5_5_node694 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected694 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected694 ((9 : Int),(1 : Int)) hp5_5_branches694 hp5_5_evidence694 hp5_5_check694 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches694,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node693 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected693 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected693 ((11 : Int),(1 : Int)) hp5_5_branches693 hp5_5_evidence693 hp5_5_check693 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches693,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node692 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected692 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected692 ((10 : Int),(1 : Int)) hp5_5_branches692 hp5_5_evidence692 hp5_5_check692 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches692,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node693 T childKnown
theorem hp5_5_node691 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected691 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected691 ((4 : Int),(2 : Int)) hp5_5_branches691 hp5_5_evidence691 hp5_5_check691 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches691,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node692 T childKnown
  · exact hp5_5_node694 T childKnown
theorem hp5_5_node690 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected690 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected690 ((9 : Int),(1 : Int)) hp5_5_branches690 hp5_5_evidence690 hp5_5_check690 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches690,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node689 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected689 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected689 ((11 : Int),(1 : Int)) hp5_5_branches689 hp5_5_evidence689 hp5_5_check689 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches689,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node688 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected688 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected688 ((10 : Int),(1 : Int)) hp5_5_branches688 hp5_5_evidence688 hp5_5_check688 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches688,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node689 T childKnown
theorem hp5_5_node687 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected687 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected687 ((4 : Int),(2 : Int)) hp5_5_branches687 hp5_5_evidence687 hp5_5_check687 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches687,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node688 T childKnown
  · exact hp5_5_node690 T childKnown
theorem hp5_5_node686 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected686 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected686 ((2 : Int),(2 : Int)) hp5_5_branches686 hp5_5_evidence686 hp5_5_check686 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches686,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node687 T childKnown
  · exact hp5_5_node691 T childKnown
theorem hp5_5_node685 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected685 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected685 ((7 : Int),(0 : Int)) hp5_5_branches685 hp5_5_evidence685 hp5_5_check685 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches685,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node686 T childKnown
theorem hp5_5_node684 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected684 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected684 ((3 : Int),(2 : Int)) hp5_5_branches684 hp5_5_evidence684 hp5_5_check684 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches684,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node683 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected683 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected683 ((3 : Int),(2 : Int)) hp5_5_branches683 hp5_5_evidence683 hp5_5_check683 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches683,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node682 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected682 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected682 ((3 : Int),(1 : Int)) hp5_5_branches682 hp5_5_evidence682 hp5_5_check682 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches682,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node683 T childKnown
  · exact hp5_5_node684 T childKnown
theorem hp5_5_node681 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected681 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected681 ((11 : Int),(1 : Int)) hp5_5_branches681 hp5_5_evidence681 hp5_5_check681 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches681,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node680 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected680 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected680 ((9 : Int),(2 : Int)) hp5_5_branches680 hp5_5_evidence680 hp5_5_check680 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches680,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node679 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected679 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected679 ((10 : Int),(1 : Int)) hp5_5_branches679 hp5_5_evidence679 hp5_5_check679 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches679,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node680 T childKnown
  · exact hp5_5_node681 T childKnown
theorem hp5_5_node678 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected678 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected678 ((7 : Int),(0 : Int)) hp5_5_branches678 hp5_5_evidence678 hp5_5_check678 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches678,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node679 T childKnown
theorem hp5_5_node677 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected677 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected677 ((7 : Int),(0 : Int)) hp5_5_branches677 hp5_5_evidence677 hp5_5_check677 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches677,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node676 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected676 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected676 ((3 : Int),(1 : Int)) hp5_5_branches676 hp5_5_evidence676 hp5_5_check676 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches676,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node677 T childKnown
  · exact hp5_5_node678 T childKnown
theorem hp5_5_node675 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected675 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected675 ((3 : Int),(2 : Int)) hp5_5_branches675 hp5_5_evidence675 hp5_5_check675 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches675,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node674 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected674 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected674 ((3 : Int),(2 : Int)) hp5_5_branches674 hp5_5_evidence674 hp5_5_check674 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches674,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node673 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected673 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected673 ((3 : Int),(1 : Int)) hp5_5_branches673 hp5_5_evidence673 hp5_5_check673 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches673,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node674 T childKnown
  · exact hp5_5_node675 T childKnown
theorem hp5_5_node672 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected672 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected672 ((2 : Int),(1 : Int)) hp5_5_branches672 hp5_5_evidence672 hp5_5_check672 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches672,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node673 T childKnown
  · exact hp5_5_node676 T childKnown
  · exact hp5_5_node682 T childKnown
  · exact hp5_5_node685 T childKnown
  · exact hp5_5_node695 T childKnown
  · exact hp5_5_node698 T childKnown
theorem hp5_5_node671 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected671 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected671 ((0 : Int),(2 : Int)) hp5_5_branches671 hp5_5_evidence671 hp5_5_check671 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches671,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node672 T childKnown
  · exact hp5_5_node702 T childKnown
  · exact hp5_5_node725 T childKnown
  · exact hp5_5_node731 T childKnown
theorem hp5_5_node670 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected670 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected670 ((2 : Int),(1 : Int)) hp5_5_branches670 hp5_5_evidence670 hp5_5_check670 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches670,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node669 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected669 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected669 ((2 : Int),(1 : Int)) hp5_5_branches669 hp5_5_evidence669 hp5_5_check669 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches669,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node668 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected668 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected668 ((3 : Int),(2 : Int)) hp5_5_branches668 hp5_5_evidence668 hp5_5_check668 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches668,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node667 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected667 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected667 ((3 : Int),(2 : Int)) hp5_5_branches667 hp5_5_evidence667 hp5_5_check667 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches667,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node666 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected666 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected666 ((3 : Int),(1 : Int)) hp5_5_branches666 hp5_5_evidence666 hp5_5_check666 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches666,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node667 T childKnown
  · exact hp5_5_node668 T childKnown
theorem hp5_5_node665 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected665 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected665 ((2 : Int),(2 : Int)) hp5_5_branches665 hp5_5_evidence665 hp5_5_check665 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches665,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp5_5_node666 T childKnown
  · exact hp5_5_node669 T childKnown
  · exact hp5_5_node670 T childKnown
theorem hp5_5_node664 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected664 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected664 ((2 : Int),(1 : Int)) hp5_5_branches664 hp5_5_evidence664 hp5_5_check664 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches664,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node663 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected663 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected663 ((2 : Int),(1 : Int)) hp5_5_branches663 hp5_5_evidence663 hp5_5_check663 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches663,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node662 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected662 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected662 ((3 : Int),(2 : Int)) hp5_5_branches662 hp5_5_evidence662 hp5_5_check662 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches662,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node661 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected661 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected661 ((3 : Int),(2 : Int)) hp5_5_branches661 hp5_5_evidence661 hp5_5_check661 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches661,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node660 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected660 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected660 ((3 : Int),(1 : Int)) hp5_5_branches660 hp5_5_evidence660 hp5_5_check660 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches660,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node661 T childKnown
  · exact hp5_5_node662 T childKnown
theorem hp5_5_node659 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected659 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected659 ((2 : Int),(2 : Int)) hp5_5_branches659 hp5_5_evidence659 hp5_5_check659 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches659,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp5_5_node660 T childKnown
  · exact hp5_5_node663 T childKnown
  · exact hp5_5_node664 T childKnown
theorem hp5_5_node658 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected658 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected658 ((3 : Int),(2 : Int)) hp5_5_branches658 hp5_5_evidence658 hp5_5_check658 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches658,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node657 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected657 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected657 ((2 : Int),(2 : Int)) hp5_5_branches657 hp5_5_evidence657 hp5_5_check657 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches657,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node658 T childKnown
theorem hp5_5_node656 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected656 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected656 ((3 : Int),(2 : Int)) hp5_5_branches656 hp5_5_evidence656 hp5_5_check656 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches656,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node655 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected655 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected655 ((2 : Int),(2 : Int)) hp5_5_branches655 hp5_5_evidence655 hp5_5_check655 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches655,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node656 T childKnown
theorem hp5_5_node654 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected654 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected654 ((9 : Int),(1 : Int)) hp5_5_branches654 hp5_5_evidence654 hp5_5_check654 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches654,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node653 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected653 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected653 ((11 : Int),(1 : Int)) hp5_5_branches653 hp5_5_evidence653 hp5_5_check653 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches653,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node652 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected652 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected652 ((10 : Int),(1 : Int)) hp5_5_branches652 hp5_5_evidence652 hp5_5_check652 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches652,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node653 T childKnown
theorem hp5_5_node651 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected651 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected651 ((4 : Int),(2 : Int)) hp5_5_branches651 hp5_5_evidence651 hp5_5_check651 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches651,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node652 T childKnown
  · exact hp5_5_node654 T childKnown
theorem hp5_5_node650 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected650 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected650 ((7 : Int),(0 : Int)) hp5_5_branches650 hp5_5_evidence650 hp5_5_check650 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches650,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node651 T childKnown
theorem hp5_5_node649 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected649 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected649 ((2 : Int),(2 : Int)) hp5_5_branches649 hp5_5_evidence649 hp5_5_check649 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches649,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node650 T childKnown
theorem hp5_5_node648 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected648 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected648 ((3 : Int),(2 : Int)) hp5_5_branches648 hp5_5_evidence648 hp5_5_check648 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches648,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node647 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected647 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected647 ((3 : Int),(2 : Int)) hp5_5_branches647 hp5_5_evidence647 hp5_5_check647 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches647,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node646 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected646 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected646 ((3 : Int),(1 : Int)) hp5_5_branches646 hp5_5_evidence646 hp5_5_check646 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches646,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node647 T childKnown
  · exact hp5_5_node648 T childKnown
theorem hp5_5_node645 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected645 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected645 ((11 : Int),(1 : Int)) hp5_5_branches645 hp5_5_evidence645 hp5_5_check645 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches645,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node644 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected644 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected644 ((9 : Int),(2 : Int)) hp5_5_branches644 hp5_5_evidence644 hp5_5_check644 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches644,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node643 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected643 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected643 ((10 : Int),(1 : Int)) hp5_5_branches643 hp5_5_evidence643 hp5_5_check643 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches643,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node644 T childKnown
  · exact hp5_5_node645 T childKnown
theorem hp5_5_node642 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected642 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected642 ((7 : Int),(0 : Int)) hp5_5_branches642 hp5_5_evidence642 hp5_5_check642 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches642,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node643 T childKnown
theorem hp5_5_node641 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected641 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected641 ((7 : Int),(0 : Int)) hp5_5_branches641 hp5_5_evidence641 hp5_5_check641 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches641,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node640 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected640 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected640 ((3 : Int),(1 : Int)) hp5_5_branches640 hp5_5_evidence640 hp5_5_check640 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches640,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node641 T childKnown
  · exact hp5_5_node642 T childKnown
theorem hp5_5_node639 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected639 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected639 ((3 : Int),(2 : Int)) hp5_5_branches639 hp5_5_evidence639 hp5_5_check639 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches639,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node638 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected638 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected638 ((3 : Int),(2 : Int)) hp5_5_branches638 hp5_5_evidence638 hp5_5_check638 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches638,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node637 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected637 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected637 ((3 : Int),(1 : Int)) hp5_5_branches637 hp5_5_evidence637 hp5_5_check637 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches637,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node638 T childKnown
  · exact hp5_5_node639 T childKnown
theorem hp5_5_node636 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected636 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected636 ((2 : Int),(1 : Int)) hp5_5_branches636 hp5_5_evidence636 hp5_5_check636 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches636,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node637 T childKnown
  · exact hp5_5_node640 T childKnown
  · exact hp5_5_node646 T childKnown
  · exact hp5_5_node649 T childKnown
  · exact hp5_5_node655 T childKnown
  · exact hp5_5_node657 T childKnown
theorem hp5_5_node635 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected635 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected635 ((3 : Int),(2 : Int)) hp5_5_branches635 hp5_5_evidence635 hp5_5_check635 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches635,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node634 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected634 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected634 ((3 : Int),(2 : Int)) hp5_5_branches634 hp5_5_evidence634 hp5_5_check634 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches634,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node633 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected633 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected633 ((2 : Int),(2 : Int)) hp5_5_branches633 hp5_5_evidence633 hp5_5_check633 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches633,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node634 T childKnown
  · exact hp5_5_node635 T childKnown
theorem hp5_5_node632 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected632 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected632 ((7 : Int),(0 : Int)) hp5_5_branches632 hp5_5_evidence632 hp5_5_check632 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches632,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node633 T childKnown
theorem hp5_5_node631 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected631 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected631 ((3 : Int),(2 : Int)) hp5_5_branches631 hp5_5_evidence631 hp5_5_check631 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches631,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node630 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected630 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected630 ((3 : Int),(2 : Int)) hp5_5_branches630 hp5_5_evidence630 hp5_5_check630 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches630,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node629 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected629 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected629 ((2 : Int),(2 : Int)) hp5_5_branches629 hp5_5_evidence629 hp5_5_check629 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches629,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node630 T childKnown
  · exact hp5_5_node631 T childKnown
theorem hp5_5_node628 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected628 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected628 ((9 : Int),(1 : Int)) hp5_5_branches628 hp5_5_evidence628 hp5_5_check628 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches628,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node627 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected627 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected627 ((11 : Int),(1 : Int)) hp5_5_branches627 hp5_5_evidence627 hp5_5_check627 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches627,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node626 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected626 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected626 ((10 : Int),(1 : Int)) hp5_5_branches626 hp5_5_evidence626 hp5_5_check626 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches626,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node627 T childKnown
theorem hp5_5_node625 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected625 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected625 ((4 : Int),(2 : Int)) hp5_5_branches625 hp5_5_evidence625 hp5_5_check625 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches625,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node626 T childKnown
  · exact hp5_5_node628 T childKnown
theorem hp5_5_node624 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected624 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected624 ((9 : Int),(1 : Int)) hp5_5_branches624 hp5_5_evidence624 hp5_5_check624 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches624,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node623 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected623 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected623 ((11 : Int),(1 : Int)) hp5_5_branches623 hp5_5_evidence623 hp5_5_check623 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches623,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node622 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected622 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected622 ((10 : Int),(1 : Int)) hp5_5_branches622 hp5_5_evidence622 hp5_5_check622 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches622,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node623 T childKnown
theorem hp5_5_node621 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected621 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected621 ((4 : Int),(2 : Int)) hp5_5_branches621 hp5_5_evidence621 hp5_5_check621 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches621,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node622 T childKnown
  · exact hp5_5_node624 T childKnown
theorem hp5_5_node620 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected620 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected620 ((2 : Int),(2 : Int)) hp5_5_branches620 hp5_5_evidence620 hp5_5_check620 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches620,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node621 T childKnown
  · exact hp5_5_node625 T childKnown
theorem hp5_5_node619 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected619 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected619 ((7 : Int),(0 : Int)) hp5_5_branches619 hp5_5_evidence619 hp5_5_check619 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches619,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node620 T childKnown
theorem hp5_5_node618 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected618 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected618 ((3 : Int),(2 : Int)) hp5_5_branches618 hp5_5_evidence618 hp5_5_check618 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches618,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node617 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected617 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected617 ((3 : Int),(2 : Int)) hp5_5_branches617 hp5_5_evidence617 hp5_5_check617 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches617,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node616 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected616 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected616 ((3 : Int),(1 : Int)) hp5_5_branches616 hp5_5_evidence616 hp5_5_check616 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches616,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node617 T childKnown
  · exact hp5_5_node618 T childKnown
theorem hp5_5_node615 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected615 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected615 ((11 : Int),(1 : Int)) hp5_5_branches615 hp5_5_evidence615 hp5_5_check615 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches615,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node614 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected614 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected614 ((9 : Int),(2 : Int)) hp5_5_branches614 hp5_5_evidence614 hp5_5_check614 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches614,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node613 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected613 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected613 ((10 : Int),(1 : Int)) hp5_5_branches613 hp5_5_evidence613 hp5_5_check613 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches613,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node614 T childKnown
  · exact hp5_5_node615 T childKnown
theorem hp5_5_node612 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected612 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected612 ((7 : Int),(0 : Int)) hp5_5_branches612 hp5_5_evidence612 hp5_5_check612 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches612,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node613 T childKnown
theorem hp5_5_node611 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected611 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected611 ((7 : Int),(0 : Int)) hp5_5_branches611 hp5_5_evidence611 hp5_5_check611 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches611,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node610 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected610 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected610 ((3 : Int),(1 : Int)) hp5_5_branches610 hp5_5_evidence610 hp5_5_check610 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches610,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node611 T childKnown
  · exact hp5_5_node612 T childKnown
theorem hp5_5_node609 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected609 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected609 ((3 : Int),(2 : Int)) hp5_5_branches609 hp5_5_evidence609 hp5_5_check609 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches609,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node608 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected608 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected608 ((3 : Int),(2 : Int)) hp5_5_branches608 hp5_5_evidence608 hp5_5_check608 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches608,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node607 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected607 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected607 ((3 : Int),(1 : Int)) hp5_5_branches607 hp5_5_evidence607 hp5_5_check607 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches607,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node608 T childKnown
  · exact hp5_5_node609 T childKnown
theorem hp5_5_node606 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected606 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected606 ((2 : Int),(1 : Int)) hp5_5_branches606 hp5_5_evidence606 hp5_5_check606 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches606,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node607 T childKnown
  · exact hp5_5_node610 T childKnown
  · exact hp5_5_node616 T childKnown
  · exact hp5_5_node619 T childKnown
  · exact hp5_5_node629 T childKnown
  · exact hp5_5_node632 T childKnown
theorem hp5_5_node605 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected605 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected605 ((0 : Int),(2 : Int)) hp5_5_branches605 hp5_5_evidence605 hp5_5_check605 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches605,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node606 T childKnown
  · exact hp5_5_node636 T childKnown
  · exact hp5_5_node659 T childKnown
  · exact hp5_5_node665 T childKnown
theorem hp5_5_node604 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected604 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected604 ((2 : Int),(1 : Int)) hp5_5_branches604 hp5_5_evidence604 hp5_5_check604 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches604,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node603 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected603 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected603 ((2 : Int),(1 : Int)) hp5_5_branches603 hp5_5_evidence603 hp5_5_check603 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches603,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node602 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected602 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected602 ((3 : Int),(2 : Int)) hp5_5_branches602 hp5_5_evidence602 hp5_5_check602 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches602,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node601 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected601 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected601 ((3 : Int),(2 : Int)) hp5_5_branches601 hp5_5_evidence601 hp5_5_check601 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches601,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node600 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected600 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected600 ((3 : Int),(1 : Int)) hp5_5_branches600 hp5_5_evidence600 hp5_5_check600 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches600,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node601 T childKnown
  · exact hp5_5_node602 T childKnown
theorem hp5_5_node599 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected599 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected599 ((2 : Int),(2 : Int)) hp5_5_branches599 hp5_5_evidence599 hp5_5_check599 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches599,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp5_5_node600 T childKnown
  · exact hp5_5_node603 T childKnown
  · exact hp5_5_node604 T childKnown
theorem hp5_5_node598 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected598 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected598 ((2 : Int),(1 : Int)) hp5_5_branches598 hp5_5_evidence598 hp5_5_check598 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches598,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node597 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected597 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected597 ((2 : Int),(1 : Int)) hp5_5_branches597 hp5_5_evidence597 hp5_5_check597 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches597,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node596 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected596 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected596 ((3 : Int),(2 : Int)) hp5_5_branches596 hp5_5_evidence596 hp5_5_check596 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches596,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node595 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected595 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected595 ((3 : Int),(2 : Int)) hp5_5_branches595 hp5_5_evidence595 hp5_5_check595 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches595,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node594 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected594 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected594 ((3 : Int),(1 : Int)) hp5_5_branches594 hp5_5_evidence594 hp5_5_check594 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches594,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node595 T childKnown
  · exact hp5_5_node596 T childKnown
theorem hp5_5_node593 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected593 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected593 ((2 : Int),(2 : Int)) hp5_5_branches593 hp5_5_evidence593 hp5_5_check593 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches593,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp5_5_node594 T childKnown
  · exact hp5_5_node597 T childKnown
  · exact hp5_5_node598 T childKnown
theorem hp5_5_node592 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected592 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected592 ((3 : Int),(2 : Int)) hp5_5_branches592 hp5_5_evidence592 hp5_5_check592 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches592,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node591 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected591 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected591 ((2 : Int),(2 : Int)) hp5_5_branches591 hp5_5_evidence591 hp5_5_check591 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches591,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node592 T childKnown
theorem hp5_5_node590 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected590 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected590 ((3 : Int),(2 : Int)) hp5_5_branches590 hp5_5_evidence590 hp5_5_check590 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches590,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node589 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected589 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected589 ((2 : Int),(2 : Int)) hp5_5_branches589 hp5_5_evidence589 hp5_5_check589 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches589,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node590 T childKnown
theorem hp5_5_node588 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected588 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected588 ((9 : Int),(1 : Int)) hp5_5_branches588 hp5_5_evidence588 hp5_5_check588 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches588,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node587 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected587 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected587 ((11 : Int),(1 : Int)) hp5_5_branches587 hp5_5_evidence587 hp5_5_check587 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches587,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node586 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected586 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected586 ((10 : Int),(1 : Int)) hp5_5_branches586 hp5_5_evidence586 hp5_5_check586 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches586,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node587 T childKnown
theorem hp5_5_node585 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected585 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected585 ((4 : Int),(2 : Int)) hp5_5_branches585 hp5_5_evidence585 hp5_5_check585 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches585,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node586 T childKnown
  · exact hp5_5_node588 T childKnown
theorem hp5_5_node584 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected584 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected584 ((7 : Int),(0 : Int)) hp5_5_branches584 hp5_5_evidence584 hp5_5_check584 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches584,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node585 T childKnown
theorem hp5_5_node583 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected583 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected583 ((2 : Int),(2 : Int)) hp5_5_branches583 hp5_5_evidence583 hp5_5_check583 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches583,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node584 T childKnown
theorem hp5_5_node582 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected582 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected582 ((3 : Int),(2 : Int)) hp5_5_branches582 hp5_5_evidence582 hp5_5_check582 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches582,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node581 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected581 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected581 ((3 : Int),(2 : Int)) hp5_5_branches581 hp5_5_evidence581 hp5_5_check581 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches581,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node580 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected580 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected580 ((3 : Int),(1 : Int)) hp5_5_branches580 hp5_5_evidence580 hp5_5_check580 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches580,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node581 T childKnown
  · exact hp5_5_node582 T childKnown
theorem hp5_5_node579 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected579 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected579 ((11 : Int),(1 : Int)) hp5_5_branches579 hp5_5_evidence579 hp5_5_check579 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches579,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node578 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected578 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected578 ((9 : Int),(2 : Int)) hp5_5_branches578 hp5_5_evidence578 hp5_5_check578 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches578,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node577 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected577 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected577 ((10 : Int),(1 : Int)) hp5_5_branches577 hp5_5_evidence577 hp5_5_check577 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches577,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node578 T childKnown
  · exact hp5_5_node579 T childKnown
theorem hp5_5_node576 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected576 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected576 ((7 : Int),(0 : Int)) hp5_5_branches576 hp5_5_evidence576 hp5_5_check576 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches576,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node577 T childKnown
theorem hp5_5_node575 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected575 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected575 ((7 : Int),(0 : Int)) hp5_5_branches575 hp5_5_evidence575 hp5_5_check575 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches575,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node574 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected574 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected574 ((3 : Int),(1 : Int)) hp5_5_branches574 hp5_5_evidence574 hp5_5_check574 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches574,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node575 T childKnown
  · exact hp5_5_node576 T childKnown
theorem hp5_5_node573 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected573 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected573 ((3 : Int),(2 : Int)) hp5_5_branches573 hp5_5_evidence573 hp5_5_check573 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches573,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node572 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected572 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected572 ((3 : Int),(2 : Int)) hp5_5_branches572 hp5_5_evidence572 hp5_5_check572 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches572,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node571 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected571 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected571 ((3 : Int),(1 : Int)) hp5_5_branches571 hp5_5_evidence571 hp5_5_check571 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches571,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node572 T childKnown
  · exact hp5_5_node573 T childKnown
theorem hp5_5_node570 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected570 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected570 ((2 : Int),(1 : Int)) hp5_5_branches570 hp5_5_evidence570 hp5_5_check570 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches570,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node571 T childKnown
  · exact hp5_5_node574 T childKnown
  · exact hp5_5_node580 T childKnown
  · exact hp5_5_node583 T childKnown
  · exact hp5_5_node589 T childKnown
  · exact hp5_5_node591 T childKnown
theorem hp5_5_node569 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected569 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected569 ((3 : Int),(2 : Int)) hp5_5_branches569 hp5_5_evidence569 hp5_5_check569 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches569,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node568 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected568 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected568 ((3 : Int),(2 : Int)) hp5_5_branches568 hp5_5_evidence568 hp5_5_check568 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches568,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node567 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected567 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected567 ((2 : Int),(2 : Int)) hp5_5_branches567 hp5_5_evidence567 hp5_5_check567 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches567,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node568 T childKnown
  · exact hp5_5_node569 T childKnown
theorem hp5_5_node566 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected566 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected566 ((7 : Int),(0 : Int)) hp5_5_branches566 hp5_5_evidence566 hp5_5_check566 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches566,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node567 T childKnown
theorem hp5_5_node565 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected565 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected565 ((3 : Int),(2 : Int)) hp5_5_branches565 hp5_5_evidence565 hp5_5_check565 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches565,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node564 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected564 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected564 ((3 : Int),(2 : Int)) hp5_5_branches564 hp5_5_evidence564 hp5_5_check564 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches564,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node563 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected563 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected563 ((2 : Int),(2 : Int)) hp5_5_branches563 hp5_5_evidence563 hp5_5_check563 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches563,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node564 T childKnown
  · exact hp5_5_node565 T childKnown
theorem hp5_5_node562 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected562 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected562 ((9 : Int),(1 : Int)) hp5_5_branches562 hp5_5_evidence562 hp5_5_check562 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches562,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node561 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected561 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected561 ((11 : Int),(1 : Int)) hp5_5_branches561 hp5_5_evidence561 hp5_5_check561 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches561,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node560 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected560 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected560 ((10 : Int),(1 : Int)) hp5_5_branches560 hp5_5_evidence560 hp5_5_check560 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches560,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node561 T childKnown
theorem hp5_5_node559 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected559 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected559 ((4 : Int),(2 : Int)) hp5_5_branches559 hp5_5_evidence559 hp5_5_check559 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches559,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node560 T childKnown
  · exact hp5_5_node562 T childKnown
theorem hp5_5_node558 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected558 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected558 ((9 : Int),(1 : Int)) hp5_5_branches558 hp5_5_evidence558 hp5_5_check558 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches558,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node557 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected557 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected557 ((11 : Int),(1 : Int)) hp5_5_branches557 hp5_5_evidence557 hp5_5_check557 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches557,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node556 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected556 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected556 ((10 : Int),(1 : Int)) hp5_5_branches556 hp5_5_evidence556 hp5_5_check556 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches556,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node557 T childKnown
theorem hp5_5_node555 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected555 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected555 ((4 : Int),(2 : Int)) hp5_5_branches555 hp5_5_evidence555 hp5_5_check555 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches555,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node556 T childKnown
  · exact hp5_5_node558 T childKnown
theorem hp5_5_node554 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected554 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected554 ((2 : Int),(2 : Int)) hp5_5_branches554 hp5_5_evidence554 hp5_5_check554 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches554,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node555 T childKnown
  · exact hp5_5_node559 T childKnown
theorem hp5_5_node553 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected553 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected553 ((7 : Int),(0 : Int)) hp5_5_branches553 hp5_5_evidence553 hp5_5_check553 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches553,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node554 T childKnown
theorem hp5_5_node552 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected552 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected552 ((3 : Int),(2 : Int)) hp5_5_branches552 hp5_5_evidence552 hp5_5_check552 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches552,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node551 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected551 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected551 ((3 : Int),(2 : Int)) hp5_5_branches551 hp5_5_evidence551 hp5_5_check551 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches551,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node550 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected550 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected550 ((3 : Int),(1 : Int)) hp5_5_branches550 hp5_5_evidence550 hp5_5_check550 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches550,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node551 T childKnown
  · exact hp5_5_node552 T childKnown
theorem hp5_5_node549 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected549 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected549 ((11 : Int),(1 : Int)) hp5_5_branches549 hp5_5_evidence549 hp5_5_check549 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches549,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node548 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected548 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected548 ((9 : Int),(2 : Int)) hp5_5_branches548 hp5_5_evidence548 hp5_5_check548 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches548,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node547 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected547 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected547 ((10 : Int),(1 : Int)) hp5_5_branches547 hp5_5_evidence547 hp5_5_check547 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches547,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node548 T childKnown
  · exact hp5_5_node549 T childKnown
theorem hp5_5_node546 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected546 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected546 ((7 : Int),(0 : Int)) hp5_5_branches546 hp5_5_evidence546 hp5_5_check546 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches546,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node547 T childKnown
theorem hp5_5_node545 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected545 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected545 ((7 : Int),(0 : Int)) hp5_5_branches545 hp5_5_evidence545 hp5_5_check545 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches545,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node544 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected544 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected544 ((3 : Int),(1 : Int)) hp5_5_branches544 hp5_5_evidence544 hp5_5_check544 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches544,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node545 T childKnown
  · exact hp5_5_node546 T childKnown
theorem hp5_5_node543 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected543 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected543 ((3 : Int),(2 : Int)) hp5_5_branches543 hp5_5_evidence543 hp5_5_check543 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches543,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node542 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected542 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected542 ((3 : Int),(2 : Int)) hp5_5_branches542 hp5_5_evidence542 hp5_5_check542 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches542,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node541 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected541 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected541 ((3 : Int),(1 : Int)) hp5_5_branches541 hp5_5_evidence541 hp5_5_check541 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches541,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node542 T childKnown
  · exact hp5_5_node543 T childKnown
theorem hp5_5_node540 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected540 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected540 ((2 : Int),(1 : Int)) hp5_5_branches540 hp5_5_evidence540 hp5_5_check540 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches540,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node541 T childKnown
  · exact hp5_5_node544 T childKnown
  · exact hp5_5_node550 T childKnown
  · exact hp5_5_node553 T childKnown
  · exact hp5_5_node563 T childKnown
  · exact hp5_5_node566 T childKnown
theorem hp5_5_node539 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected539 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected539 ((0 : Int),(2 : Int)) hp5_5_branches539 hp5_5_evidence539 hp5_5_check539 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches539,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node540 T childKnown
  · exact hp5_5_node570 T childKnown
  · exact hp5_5_node593 T childKnown
  · exact hp5_5_node599 T childKnown
theorem hp5_5_node538 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected538 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected538 ((0 : Int),(1 : Int)) hp5_5_branches538 hp5_5_evidence538 hp5_5_check538 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches538,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node539 T childKnown
  · exact hp5_5_node605 T childKnown
  · exact hp5_5_node671 T childKnown
  · exact hp5_5_node737 T childKnown
  · exact hp5_5_node767 T childKnown
  · exact hp5_5_node797 T childKnown
  · exact hp5_5_node842 T childKnown
  · exact hp5_5_node845 T childKnown
theorem hp5_5_node537 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected537 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected537 ((1 : Int),(1 : Int)) hp5_5_branches537 hp5_5_evidence537 hp5_5_check537 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches537,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node536 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected536 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected536 ((1 : Int),(0 : Int)) hp5_5_branches536 hp5_5_evidence536 hp5_5_check536 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches536,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node537 T childKnown
theorem hp5_5_node535 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected535 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected535 ((2 : Int),(2 : Int)) hp5_5_branches535 hp5_5_evidence535 hp5_5_check535 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches535,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node534 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected534 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected534 ((2 : Int),(2 : Int)) hp5_5_branches534 hp5_5_evidence534 hp5_5_check534 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches534,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node533 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected533 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected533 ((2 : Int),(2 : Int)) hp5_5_branches533 hp5_5_evidence533 hp5_5_check533 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches533,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node532 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected532 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected532 ((3 : Int),(2 : Int)) hp5_5_branches532 hp5_5_evidence532 hp5_5_check532 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches532,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node531 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected531 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected531 ((2 : Int),(2 : Int)) hp5_5_branches531 hp5_5_evidence531 hp5_5_check531 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches531,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node532 T childKnown
theorem hp5_5_node530 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected530 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected530 ((1 : Int),(2 : Int)) hp5_5_branches530 hp5_5_evidence530 hp5_5_check530 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches530,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node531 T childKnown
  · exact hp5_5_node533 T childKnown
  · exact hp5_5_node534 T childKnown
  · exact hp5_5_node535 T childKnown
theorem hp5_5_node529 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected529 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected529 ((1 : Int),(0 : Int)) hp5_5_branches529 hp5_5_evidence529 hp5_5_check529 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches529,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node530 T childKnown
theorem hp5_5_node528 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected528 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected528 ((1 : Int),(1 : Int)) hp5_5_branches528 hp5_5_evidence528 hp5_5_check528 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches528,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node527 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected527 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected527 ((1 : Int),(0 : Int)) hp5_5_branches527 hp5_5_evidence527 hp5_5_check527 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches527,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node528 T childKnown
theorem hp5_5_node526 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected526 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected526 ((7 : Int),(1 : Int)) hp5_5_branches526 hp5_5_evidence526 hp5_5_check526 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches526,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node525 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected525 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected525 ((5 : Int),(1 : Int)) hp5_5_branches525 hp5_5_evidence525 hp5_5_check525 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches525,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node524 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected524 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected524 ((5 : Int),(1 : Int)) hp5_5_branches524 hp5_5_evidence524 hp5_5_check524 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches524,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node523 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected523 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected523 ((5 : Int),(1 : Int)) hp5_5_branches523 hp5_5_evidence523 hp5_5_check523 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches523,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node522 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected522 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected522 ((6 : Int),(1 : Int)) hp5_5_branches522 hp5_5_evidence522 hp5_5_check522 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches522,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node523 T childKnown
  · exact hp5_5_node524 T childKnown
  · exact hp5_5_node525 T childKnown
  · exact hp5_5_node526 T childKnown
theorem hp5_5_node521 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected521 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected521 ((6 : Int),(1 : Int)) hp5_5_branches521 hp5_5_evidence521 hp5_5_check521 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches521,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node520 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected520 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected520 ((6 : Int),(1 : Int)) hp5_5_branches520 hp5_5_evidence520 hp5_5_check520 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches520,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node519 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected519 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected519 ((6 : Int),(1 : Int)) hp5_5_branches519 hp5_5_evidence519 hp5_5_check519 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches519,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node518 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected518 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected518 ((0 : Int),(2 : Int)) hp5_5_branches518 hp5_5_evidence518 hp5_5_check518 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches518,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node517 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected517 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected517 ((0 : Int),(2 : Int)) hp5_5_branches517 hp5_5_evidence517 hp5_5_check517 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches517,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node516 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected516 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected516 ((3 : Int),(1 : Int)) hp5_5_branches516 hp5_5_evidence516 hp5_5_check516 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches516,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node517 T childKnown
  · exact hp5_5_node518 T childKnown
theorem hp5_5_node515 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected515 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected515 ((6 : Int),(1 : Int)) hp5_5_branches515 hp5_5_evidence515 hp5_5_check515 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches515,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node516 T childKnown
theorem hp5_5_node514 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected514 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected514 ((5 : Int),(1 : Int)) hp5_5_branches514 hp5_5_evidence514 hp5_5_check514 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches514,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node515 T childKnown
  · exact hp5_5_node519 T childKnown
  · exact hp5_5_node520 T childKnown
  · exact hp5_5_node521 T childKnown
theorem hp5_5_node513 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected513 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected513 ((7 : Int),(1 : Int)) hp5_5_branches513 hp5_5_evidence513 hp5_5_check513 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches513,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node512 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected512 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected512 ((7 : Int),(0 : Int)) hp5_5_branches512 hp5_5_evidence512 hp5_5_check512 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches512,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node513 T childKnown
theorem hp5_5_node511 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected511 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected511 ((5 : Int),(1 : Int)) hp5_5_branches511 hp5_5_evidence511 hp5_5_check511 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches511,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node512 T childKnown
theorem hp5_5_node510 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected510 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected510 ((0 : Int),(2 : Int)) hp5_5_branches510 hp5_5_evidence510 hp5_5_check510 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches510,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node509 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected509 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected509 ((0 : Int),(2 : Int)) hp5_5_branches509 hp5_5_evidence509 hp5_5_check509 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches509,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node508 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected508 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected508 ((3 : Int),(1 : Int)) hp5_5_branches508 hp5_5_evidence508 hp5_5_check508 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches508,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node509 T childKnown
  · exact hp5_5_node510 T childKnown
theorem hp5_5_node507 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected507 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected507 ((7 : Int),(0 : Int)) hp5_5_branches507 hp5_5_evidence507 hp5_5_check507 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches507,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node508 T childKnown
theorem hp5_5_node506 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected506 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected506 ((5 : Int),(1 : Int)) hp5_5_branches506 hp5_5_evidence506 hp5_5_check506 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches506,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node507 T childKnown
theorem hp5_5_node505 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected505 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected505 ((5 : Int),(1 : Int)) hp5_5_branches505 hp5_5_evidence505 hp5_5_check505 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches505,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node504 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected504 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected504 ((6 : Int),(0 : Int)) hp5_5_branches504 hp5_5_evidence504 hp5_5_check504 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches504,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node505 T childKnown
  · exact hp5_5_node506 T childKnown
  · exact hp5_5_node511 T childKnown
  · exact hp5_5_node514 T childKnown
  · exact hp5_5_node522 T childKnown
theorem hp5_5_node503 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected503 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected503 ((9 : Int),(1 : Int)) hp5_5_branches503 hp5_5_evidence503 hp5_5_check503 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches503,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node502 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected502 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected502 ((7 : Int),(2 : Int)) hp5_5_branches502 hp5_5_evidence502 hp5_5_check502 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches502,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node501 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected501 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected501 ((8 : Int),(1 : Int)) hp5_5_branches501 hp5_5_evidence501 hp5_5_check501 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches501,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node502 T childKnown
  · exact hp5_5_node503 T childKnown
theorem hp5_5_node500 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected500 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected500 ((6 : Int),(0 : Int)) hp5_5_branches500 hp5_5_evidence500 hp5_5_check500 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches500,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node501 T childKnown
theorem hp5_5_node499 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected499 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected499 ((2 : Int),(2 : Int)) hp5_5_branches499 hp5_5_evidence499 hp5_5_check499 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches499,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node498 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected498 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected498 ((2 : Int),(2 : Int)) hp5_5_branches498 hp5_5_evidence498 hp5_5_check498 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches498,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node497 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected497 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected497 ((2 : Int),(2 : Int)) hp5_5_branches497 hp5_5_evidence497 hp5_5_check497 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches497,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node496 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected496 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected496 ((3 : Int),(2 : Int)) hp5_5_branches496 hp5_5_evidence496 hp5_5_check496 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches496,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node495 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected495 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected495 ((2 : Int),(2 : Int)) hp5_5_branches495 hp5_5_evidence495 hp5_5_check495 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches495,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node496 T childKnown
theorem hp5_5_node494 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected494 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected494 ((1 : Int),(2 : Int)) hp5_5_branches494 hp5_5_evidence494 hp5_5_check494 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches494,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node495 T childKnown
  · exact hp5_5_node497 T childKnown
  · exact hp5_5_node498 T childKnown
  · exact hp5_5_node499 T childKnown
theorem hp5_5_node493 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected493 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected493 ((8 : Int),(1 : Int)) hp5_5_branches493 hp5_5_evidence493 hp5_5_check493 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches493,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node492 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected492 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected492 ((10 : Int),(1 : Int)) hp5_5_branches492 hp5_5_evidence492 hp5_5_check492 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches492,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node491 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected491 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected491 ((9 : Int),(1 : Int)) hp5_5_branches491 hp5_5_evidence491 hp5_5_check491 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches491,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node492 T childKnown
theorem hp5_5_node490 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected490 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected490 ((3 : Int),(2 : Int)) hp5_5_branches490 hp5_5_evidence490 hp5_5_check490 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches490,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node491 T childKnown
  · exact hp5_5_node493 T childKnown
theorem hp5_5_node489 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected489 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected489 ((8 : Int),(1 : Int)) hp5_5_branches489 hp5_5_evidence489 hp5_5_check489 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches489,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node488 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected488 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected488 ((10 : Int),(1 : Int)) hp5_5_branches488 hp5_5_evidence488 hp5_5_check488 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches488,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node487 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected487 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected487 ((9 : Int),(1 : Int)) hp5_5_branches487 hp5_5_evidence487 hp5_5_check487 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches487,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node488 T childKnown
theorem hp5_5_node486 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected486 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected486 ((3 : Int),(2 : Int)) hp5_5_branches486 hp5_5_evidence486 hp5_5_check486 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches486,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node487 T childKnown
  · exact hp5_5_node489 T childKnown
theorem hp5_5_node485 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected485 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected485 ((8 : Int),(1 : Int)) hp5_5_branches485 hp5_5_evidence485 hp5_5_check485 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches485,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node484 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected484 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected484 ((10 : Int),(1 : Int)) hp5_5_branches484 hp5_5_evidence484 hp5_5_check484 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches484,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node483 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected483 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected483 ((9 : Int),(1 : Int)) hp5_5_branches483 hp5_5_evidence483 hp5_5_check483 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches483,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node484 T childKnown
theorem hp5_5_node482 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected482 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected482 ((8 : Int),(1 : Int)) hp5_5_branches482 hp5_5_evidence482 hp5_5_check482 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches482,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node481 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected481 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected481 ((4 : Int),(2 : Int)) hp5_5_branches481 hp5_5_evidence481 hp5_5_check481 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches481,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node480 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected480 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected480 ((8 : Int),(1 : Int)) hp5_5_branches480 hp5_5_evidence480 hp5_5_check480 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches480,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node481 T childKnown
theorem hp5_5_node479 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected479 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected479 ((8 : Int),(1 : Int)) hp5_5_branches479 hp5_5_evidence479 hp5_5_check479 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches479,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node478 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected478 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected478 ((3 : Int),(2 : Int)) hp5_5_branches478 hp5_5_evidence478 hp5_5_check478 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches478,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node479 T childKnown
  · exact hp5_5_node480 T childKnown
  · exact hp5_5_node482 T childKnown
  · exact hp5_5_node483 T childKnown
  · exact hp5_5_node485 T childKnown
theorem hp5_5_node477 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected477 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected477 ((3 : Int),(2 : Int)) hp5_5_branches477 hp5_5_evidence477 hp5_5_check477 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches477,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node476 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected476 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected476 ((7 : Int),(2 : Int)) hp5_5_branches476 hp5_5_evidence476 hp5_5_check476 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches476,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node475 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected475 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected475 ((3 : Int),(2 : Int)) hp5_5_branches475 hp5_5_evidence475 hp5_5_check475 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches475,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node474 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected474 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected474 ((3 : Int),(2 : Int)) hp5_5_branches474 hp5_5_evidence474 hp5_5_check474 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches474,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node473 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected473 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected473 ((10 : Int),(1 : Int)) hp5_5_branches473 hp5_5_evidence473 hp5_5_check473 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches473,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node472 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected472 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected472 ((9 : Int),(1 : Int)) hp5_5_branches472 hp5_5_evidence472 hp5_5_check472 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches472,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node473 T childKnown
theorem hp5_5_node471 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected471 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected471 ((8 : Int),(1 : Int)) hp5_5_branches471 hp5_5_evidence471 hp5_5_check471 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches471,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node472 T childKnown
  · exact hp5_5_node474 T childKnown
  · exact hp5_5_node475 T childKnown
  · exact hp5_5_node476 T childKnown
  · exact hp5_5_node477 T childKnown
theorem hp5_5_node470 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected470 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected470 ((1 : Int),(2 : Int)) hp5_5_branches470 hp5_5_evidence470 hp5_5_check470 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches470,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node471 T childKnown
  · exact hp5_5_node478 T childKnown
  · exact hp5_5_node486 T childKnown
  · exact hp5_5_node490 T childKnown
theorem hp5_5_node469 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected469 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected469 ((6 : Int),(0 : Int)) hp5_5_branches469 hp5_5_evidence469 hp5_5_check469 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches469,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node470 T childKnown
theorem hp5_5_node468 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected468 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected468 ((2 : Int),(2 : Int)) hp5_5_branches468 hp5_5_evidence468 hp5_5_check468 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches468,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node467 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected467 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected467 ((2 : Int),(2 : Int)) hp5_5_branches467 hp5_5_evidence467 hp5_5_check467 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches467,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node466 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected466 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected466 ((2 : Int),(1 : Int)) hp5_5_branches466 hp5_5_evidence466 hp5_5_check466 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches466,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node467 T childKnown
  · exact hp5_5_node468 T childKnown
theorem hp5_5_node465 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected465 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected465 ((10 : Int),(1 : Int)) hp5_5_branches465 hp5_5_evidence465 hp5_5_check465 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches465,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node464 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected464 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected464 ((8 : Int),(2 : Int)) hp5_5_branches464 hp5_5_evidence464 hp5_5_check464 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches464,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node463 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected463 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected463 ((9 : Int),(1 : Int)) hp5_5_branches463 hp5_5_evidence463 hp5_5_check463 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches463,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node464 T childKnown
  · exact hp5_5_node465 T childKnown
theorem hp5_5_node462 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected462 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected462 ((6 : Int),(0 : Int)) hp5_5_branches462 hp5_5_evidence462 hp5_5_check462 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches462,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node463 T childKnown
theorem hp5_5_node461 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected461 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected461 ((6 : Int),(0 : Int)) hp5_5_branches461 hp5_5_evidence461 hp5_5_check461 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches461,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node460 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected460 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected460 ((2 : Int),(1 : Int)) hp5_5_branches460 hp5_5_evidence460 hp5_5_check460 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches460,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node461 T childKnown
  · exact hp5_5_node462 T childKnown
theorem hp5_5_node459 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected459 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected459 ((2 : Int),(2 : Int)) hp5_5_branches459 hp5_5_evidence459 hp5_5_check459 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches459,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node458 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected458 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected458 ((2 : Int),(2 : Int)) hp5_5_branches458 hp5_5_evidence458 hp5_5_check458 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches458,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node457 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected457 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected457 ((2 : Int),(1 : Int)) hp5_5_branches457 hp5_5_evidence457 hp5_5_check457 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches457,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node458 T childKnown
  · exact hp5_5_node459 T childKnown
theorem hp5_5_node456 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected456 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected456 ((2 : Int),(2 : Int)) hp5_5_branches456 hp5_5_evidence456 hp5_5_check456 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches456,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node455 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected455 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected455 ((2 : Int),(2 : Int)) hp5_5_branches455 hp5_5_evidence455 hp5_5_check455 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches455,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node454 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected454 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected454 ((2 : Int),(2 : Int)) hp5_5_branches454 hp5_5_evidence454 hp5_5_check454 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches454,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node453 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected453 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected453 ((2 : Int),(1 : Int)) hp5_5_branches453 hp5_5_evidence453 hp5_5_check453 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches453,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp5_5_node454 T childKnown
  · exact hp5_5_node455 T childKnown
  · exact hp5_5_node456 T childKnown
theorem hp5_5_node452 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected452 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected452 ((3 : Int),(2 : Int)) hp5_5_branches452 hp5_5_evidence452 hp5_5_check452 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches452,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node451 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected451 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected451 ((2 : Int),(2 : Int)) hp5_5_branches451 hp5_5_evidence451 hp5_5_check451 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches451,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node452 T childKnown
theorem hp5_5_node450 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected450 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected450 ((6 : Int),(0 : Int)) hp5_5_branches450 hp5_5_evidence450 hp5_5_check450 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches450,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node449 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected449 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected449 ((9 : Int),(1 : Int)) hp5_5_branches449 hp5_5_evidence449 hp5_5_check449 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches449,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node448 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected448 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected448 ((12 : Int),(2 : Int)) hp5_5_branches448 hp5_5_evidence448 hp5_5_check448 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches448,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node447 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected447 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected447 ((12 : Int),(2 : Int)) hp5_5_branches447 hp5_5_evidence447 hp5_5_check447 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches447,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node446 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected446 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected446 ((12 : Int),(1 : Int)) hp5_5_branches446 hp5_5_evidence446 hp5_5_check446 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches446,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node447 T childKnown
  · exact hp5_5_node448 T childKnown
theorem hp5_5_node445 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected445 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected445 ((10 : Int),(1 : Int)) hp5_5_branches445 hp5_5_evidence445 hp5_5_check445 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches445,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node446 T childKnown
theorem hp5_5_node444 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected444 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected444 ((4 : Int),(2 : Int)) hp5_5_branches444 hp5_5_evidence444 hp5_5_check444 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches444,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node445 T childKnown
  · exact hp5_5_node449 T childKnown
theorem hp5_5_node443 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected443 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected443 ((6 : Int),(0 : Int)) hp5_5_branches443 hp5_5_evidence443 hp5_5_check443 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches443,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node444 T childKnown
theorem hp5_5_node442 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected442 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected442 ((2 : Int),(2 : Int)) hp5_5_branches442 hp5_5_evidence442 hp5_5_check442 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches442,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node443 T childKnown
theorem hp5_5_node441 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected441 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected441 ((3 : Int),(2 : Int)) hp5_5_branches441 hp5_5_evidence441 hp5_5_check441 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches441,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node440 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected440 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected440 ((3 : Int),(2 : Int)) hp5_5_branches440 hp5_5_evidence440 hp5_5_check440 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches440,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node439 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected439 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected439 ((3 : Int),(1 : Int)) hp5_5_branches439 hp5_5_evidence439 hp5_5_check439 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches439,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node440 T childKnown
  · exact hp5_5_node441 T childKnown
theorem hp5_5_node438 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected438 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected438 ((12 : Int),(2 : Int)) hp5_5_branches438 hp5_5_evidence438 hp5_5_check438 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches438,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node437 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected437 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected437 ((12 : Int),(2 : Int)) hp5_5_branches437 hp5_5_evidence437 hp5_5_check437 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches437,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node436 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected436 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected436 ((12 : Int),(1 : Int)) hp5_5_branches436 hp5_5_evidence436 hp5_5_check436 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches436,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node437 T childKnown
  · exact hp5_5_node438 T childKnown
theorem hp5_5_node435 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected435 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected435 ((9 : Int),(2 : Int)) hp5_5_branches435 hp5_5_evidence435 hp5_5_check435 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches435,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node436 T childKnown
theorem hp5_5_node434 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected434 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected434 ((9 : Int),(2 : Int)) hp5_5_branches434 hp5_5_evidence434 hp5_5_check434 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches434,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node433 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected433 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected433 ((10 : Int),(1 : Int)) hp5_5_branches433 hp5_5_evidence433 hp5_5_check433 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches433,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node434 T childKnown
  · exact hp5_5_node435 T childKnown
theorem hp5_5_node432 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected432 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected432 ((3 : Int),(1 : Int)) hp5_5_branches432 hp5_5_evidence432 hp5_5_check432 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches432,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node433 T childKnown
theorem hp5_5_node431 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected431 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected431 ((6 : Int),(0 : Int)) hp5_5_branches431 hp5_5_evidence431 hp5_5_check431 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches431,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node432 T childKnown
theorem hp5_5_node430 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected430 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected430 ((2 : Int),(1 : Int)) hp5_5_branches430 hp5_5_evidence430 hp5_5_check430 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches430,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node431 T childKnown
  · exact hp5_5_node439 T childKnown
  · exact hp5_5_node442 T childKnown
  · exact hp5_5_node450 T childKnown
  · exact hp5_5_node451 T childKnown
theorem hp5_5_node429 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected429 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected429 ((1 : Int),(1 : Int)) hp5_5_branches429 hp5_5_evidence429 hp5_5_check429 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches429,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node430 T childKnown
  · exact hp5_5_node453 T childKnown
  · exact hp5_5_node457 T childKnown
  · exact hp5_5_node460 T childKnown
  · exact hp5_5_node466 T childKnown
  · exact hp5_5_node469 T childKnown
  · exact hp5_5_node494 T childKnown
  · exact hp5_5_node500 T childKnown
theorem hp5_5_node428 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected428 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected428 ((6 : Int),(1 : Int)) hp5_5_branches428 hp5_5_evidence428 hp5_5_check428 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches428,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node427 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected427 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected427 ((4 : Int),(1 : Int)) hp5_5_branches427 hp5_5_evidence427 hp5_5_check427 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches427,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node426 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected426 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected426 ((4 : Int),(1 : Int)) hp5_5_branches426 hp5_5_evidence426 hp5_5_check426 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches426,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node425 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected425 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected425 ((4 : Int),(1 : Int)) hp5_5_branches425 hp5_5_evidence425 hp5_5_check425 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches425,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node424 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected424 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected424 ((5 : Int),(1 : Int)) hp5_5_branches424 hp5_5_evidence424 hp5_5_check424 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches424,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node425 T childKnown
  · exact hp5_5_node426 T childKnown
  · exact hp5_5_node427 T childKnown
  · exact hp5_5_node428 T childKnown
theorem hp5_5_node423 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected423 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected423 ((5 : Int),(1 : Int)) hp5_5_branches423 hp5_5_evidence423 hp5_5_check423 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches423,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node422 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected422 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected422 ((5 : Int),(1 : Int)) hp5_5_branches422 hp5_5_evidence422 hp5_5_check422 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches422,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node421 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected421 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected421 ((5 : Int),(1 : Int)) hp5_5_branches421 hp5_5_evidence421 hp5_5_check421 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches421,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node420 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected420 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected420 ((0 : Int),(2 : Int)) hp5_5_branches420 hp5_5_evidence420 hp5_5_check420 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches420,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node419 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected419 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected419 ((0 : Int),(2 : Int)) hp5_5_branches419 hp5_5_evidence419 hp5_5_check419 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches419,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node418 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected418 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected418 ((2 : Int),(1 : Int)) hp5_5_branches418 hp5_5_evidence418 hp5_5_check418 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches418,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node419 T childKnown
  · exact hp5_5_node420 T childKnown
theorem hp5_5_node417 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected417 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected417 ((5 : Int),(1 : Int)) hp5_5_branches417 hp5_5_evidence417 hp5_5_check417 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches417,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node418 T childKnown
theorem hp5_5_node416 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected416 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected416 ((4 : Int),(1 : Int)) hp5_5_branches416 hp5_5_evidence416 hp5_5_check416 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches416,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node417 T childKnown
  · exact hp5_5_node421 T childKnown
  · exact hp5_5_node422 T childKnown
  · exact hp5_5_node423 T childKnown
theorem hp5_5_node415 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected415 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected415 ((6 : Int),(1 : Int)) hp5_5_branches415 hp5_5_evidence415 hp5_5_check415 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches415,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node414 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected414 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected414 ((6 : Int),(0 : Int)) hp5_5_branches414 hp5_5_evidence414 hp5_5_check414 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches414,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node415 T childKnown
theorem hp5_5_node413 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected413 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected413 ((4 : Int),(1 : Int)) hp5_5_branches413 hp5_5_evidence413 hp5_5_check413 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches413,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node414 T childKnown
theorem hp5_5_node412 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected412 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected412 ((0 : Int),(2 : Int)) hp5_5_branches412 hp5_5_evidence412 hp5_5_check412 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches412,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node411 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected411 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected411 ((0 : Int),(2 : Int)) hp5_5_branches411 hp5_5_evidence411 hp5_5_check411 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches411,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node410 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected410 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected410 ((2 : Int),(1 : Int)) hp5_5_branches410 hp5_5_evidence410 hp5_5_check410 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches410,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node411 T childKnown
  · exact hp5_5_node412 T childKnown
theorem hp5_5_node409 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected409 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected409 ((6 : Int),(0 : Int)) hp5_5_branches409 hp5_5_evidence409 hp5_5_check409 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches409,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node410 T childKnown
theorem hp5_5_node408 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected408 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected408 ((4 : Int),(1 : Int)) hp5_5_branches408 hp5_5_evidence408 hp5_5_check408 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches408,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node409 T childKnown
theorem hp5_5_node407 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected407 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected407 ((4 : Int),(1 : Int)) hp5_5_branches407 hp5_5_evidence407 hp5_5_check407 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches407,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node406 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected406 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected406 ((5 : Int),(0 : Int)) hp5_5_branches406 hp5_5_evidence406 hp5_5_check406 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches406,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node407 T childKnown
  · exact hp5_5_node408 T childKnown
  · exact hp5_5_node413 T childKnown
  · exact hp5_5_node416 T childKnown
  · exact hp5_5_node424 T childKnown
theorem hp5_5_node405 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected405 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected405 ((8 : Int),(1 : Int)) hp5_5_branches405 hp5_5_evidence405 hp5_5_check405 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches405,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node404 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected404 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected404 ((6 : Int),(2 : Int)) hp5_5_branches404 hp5_5_evidence404 hp5_5_check404 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches404,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node403 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected403 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected403 ((7 : Int),(1 : Int)) hp5_5_branches403 hp5_5_evidence403 hp5_5_check403 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches403,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node404 T childKnown
  · exact hp5_5_node405 T childKnown
theorem hp5_5_node402 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected402 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected402 ((5 : Int),(0 : Int)) hp5_5_branches402 hp5_5_evidence402 hp5_5_check402 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches402,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node403 T childKnown
theorem hp5_5_node401 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected401 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected401 ((1 : Int),(2 : Int)) hp5_5_branches401 hp5_5_evidence401 hp5_5_check401 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches401,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node400 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected400 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected400 ((1 : Int),(2 : Int)) hp5_5_branches400 hp5_5_evidence400 hp5_5_check400 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches400,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node399 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected399 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected399 ((1 : Int),(2 : Int)) hp5_5_branches399 hp5_5_evidence399 hp5_5_check399 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches399,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node398 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected398 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected398 ((2 : Int),(2 : Int)) hp5_5_branches398 hp5_5_evidence398 hp5_5_check398 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches398,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node397 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected397 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected397 ((1 : Int),(2 : Int)) hp5_5_branches397 hp5_5_evidence397 hp5_5_check397 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches397,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node398 T childKnown
theorem hp5_5_node396 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected396 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected396 ((0 : Int),(2 : Int)) hp5_5_branches396 hp5_5_evidence396 hp5_5_check396 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches396,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node397 T childKnown
  · exact hp5_5_node399 T childKnown
  · exact hp5_5_node400 T childKnown
  · exact hp5_5_node401 T childKnown
theorem hp5_5_node395 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected395 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected395 ((7 : Int),(1 : Int)) hp5_5_branches395 hp5_5_evidence395 hp5_5_check395 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches395,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node394 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected394 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected394 ((9 : Int),(1 : Int)) hp5_5_branches394 hp5_5_evidence394 hp5_5_check394 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches394,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node393 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected393 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected393 ((8 : Int),(1 : Int)) hp5_5_branches393 hp5_5_evidence393 hp5_5_check393 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches393,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node394 T childKnown
theorem hp5_5_node392 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected392 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected392 ((2 : Int),(2 : Int)) hp5_5_branches392 hp5_5_evidence392 hp5_5_check392 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches392,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node393 T childKnown
  · exact hp5_5_node395 T childKnown
theorem hp5_5_node391 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected391 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected391 ((7 : Int),(1 : Int)) hp5_5_branches391 hp5_5_evidence391 hp5_5_check391 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches391,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node390 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected390 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected390 ((9 : Int),(1 : Int)) hp5_5_branches390 hp5_5_evidence390 hp5_5_check390 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches390,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node389 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected389 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected389 ((8 : Int),(1 : Int)) hp5_5_branches389 hp5_5_evidence389 hp5_5_check389 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches389,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node390 T childKnown
theorem hp5_5_node388 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected388 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected388 ((2 : Int),(2 : Int)) hp5_5_branches388 hp5_5_evidence388 hp5_5_check388 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches388,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node389 T childKnown
  · exact hp5_5_node391 T childKnown
theorem hp5_5_node387 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected387 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected387 ((7 : Int),(1 : Int)) hp5_5_branches387 hp5_5_evidence387 hp5_5_check387 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches387,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node386 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected386 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected386 ((9 : Int),(1 : Int)) hp5_5_branches386 hp5_5_evidence386 hp5_5_check386 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches386,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node385 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected385 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected385 ((8 : Int),(1 : Int)) hp5_5_branches385 hp5_5_evidence385 hp5_5_check385 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches385,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node386 T childKnown
theorem hp5_5_node384 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected384 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected384 ((7 : Int),(1 : Int)) hp5_5_branches384 hp5_5_evidence384 hp5_5_check384 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches384,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node383 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected383 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected383 ((3 : Int),(2 : Int)) hp5_5_branches383 hp5_5_evidence383 hp5_5_check383 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches383,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node382 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected382 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected382 ((7 : Int),(1 : Int)) hp5_5_branches382 hp5_5_evidence382 hp5_5_check382 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches382,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node383 T childKnown
theorem hp5_5_node381 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected381 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected381 ((7 : Int),(1 : Int)) hp5_5_branches381 hp5_5_evidence381 hp5_5_check381 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches381,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node380 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected380 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected380 ((2 : Int),(2 : Int)) hp5_5_branches380 hp5_5_evidence380 hp5_5_check380 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches380,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node381 T childKnown
  · exact hp5_5_node382 T childKnown
  · exact hp5_5_node384 T childKnown
  · exact hp5_5_node385 T childKnown
  · exact hp5_5_node387 T childKnown
theorem hp5_5_node379 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected379 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected379 ((2 : Int),(2 : Int)) hp5_5_branches379 hp5_5_evidence379 hp5_5_check379 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches379,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node378 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected378 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected378 ((6 : Int),(2 : Int)) hp5_5_branches378 hp5_5_evidence378 hp5_5_check378 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches378,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node377 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected377 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected377 ((2 : Int),(2 : Int)) hp5_5_branches377 hp5_5_evidence377 hp5_5_check377 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches377,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node376 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected376 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected376 ((2 : Int),(2 : Int)) hp5_5_branches376 hp5_5_evidence376 hp5_5_check376 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches376,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node375 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected375 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected375 ((9 : Int),(1 : Int)) hp5_5_branches375 hp5_5_evidence375 hp5_5_check375 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches375,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node374 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected374 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected374 ((8 : Int),(1 : Int)) hp5_5_branches374 hp5_5_evidence374 hp5_5_check374 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches374,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node375 T childKnown
theorem hp5_5_node373 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected373 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected373 ((7 : Int),(1 : Int)) hp5_5_branches373 hp5_5_evidence373 hp5_5_check373 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches373,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node374 T childKnown
  · exact hp5_5_node376 T childKnown
  · exact hp5_5_node377 T childKnown
  · exact hp5_5_node378 T childKnown
  · exact hp5_5_node379 T childKnown
theorem hp5_5_node372 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected372 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected372 ((0 : Int),(2 : Int)) hp5_5_branches372 hp5_5_evidence372 hp5_5_check372 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches372,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node373 T childKnown
  · exact hp5_5_node380 T childKnown
  · exact hp5_5_node388 T childKnown
  · exact hp5_5_node392 T childKnown
theorem hp5_5_node371 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected371 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected371 ((5 : Int),(0 : Int)) hp5_5_branches371 hp5_5_evidence371 hp5_5_check371 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches371,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node372 T childKnown
theorem hp5_5_node370 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected370 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected370 ((1 : Int),(2 : Int)) hp5_5_branches370 hp5_5_evidence370 hp5_5_check370 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches370,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node369 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected369 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected369 ((1 : Int),(2 : Int)) hp5_5_branches369 hp5_5_evidence369 hp5_5_check369 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches369,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node368 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected368 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected368 ((1 : Int),(1 : Int)) hp5_5_branches368 hp5_5_evidence368 hp5_5_check368 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches368,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node369 T childKnown
  · exact hp5_5_node370 T childKnown
theorem hp5_5_node367 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected367 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected367 ((9 : Int),(1 : Int)) hp5_5_branches367 hp5_5_evidence367 hp5_5_check367 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches367,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node366 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected366 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected366 ((7 : Int),(2 : Int)) hp5_5_branches366 hp5_5_evidence366 hp5_5_check366 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches366,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node365 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected365 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected365 ((8 : Int),(1 : Int)) hp5_5_branches365 hp5_5_evidence365 hp5_5_check365 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches365,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node366 T childKnown
  · exact hp5_5_node367 T childKnown
theorem hp5_5_node364 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected364 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected364 ((5 : Int),(0 : Int)) hp5_5_branches364 hp5_5_evidence364 hp5_5_check364 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches364,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node365 T childKnown
theorem hp5_5_node363 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected363 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected363 ((5 : Int),(0 : Int)) hp5_5_branches363 hp5_5_evidence363 hp5_5_check363 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches363,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node362 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected362 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected362 ((1 : Int),(1 : Int)) hp5_5_branches362 hp5_5_evidence362 hp5_5_check362 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches362,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node363 T childKnown
  · exact hp5_5_node364 T childKnown
theorem hp5_5_node361 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected361 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected361 ((1 : Int),(2 : Int)) hp5_5_branches361 hp5_5_evidence361 hp5_5_check361 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches361,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node360 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected360 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected360 ((1 : Int),(2 : Int)) hp5_5_branches360 hp5_5_evidence360 hp5_5_check360 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches360,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node359 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected359 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected359 ((1 : Int),(1 : Int)) hp5_5_branches359 hp5_5_evidence359 hp5_5_check359 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches359,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node360 T childKnown
  · exact hp5_5_node361 T childKnown
theorem hp5_5_node358 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected358 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected358 ((1 : Int),(2 : Int)) hp5_5_branches358 hp5_5_evidence358 hp5_5_check358 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches358,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node357 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected357 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected357 ((1 : Int),(2 : Int)) hp5_5_branches357 hp5_5_evidence357 hp5_5_check357 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches357,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node356 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected356 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected356 ((1 : Int),(2 : Int)) hp5_5_branches356 hp5_5_evidence356 hp5_5_check356 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches356,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node355 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected355 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected355 ((1 : Int),(1 : Int)) hp5_5_branches355 hp5_5_evidence355 hp5_5_check355 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches355,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp5_5_node356 T childKnown
  · exact hp5_5_node357 T childKnown
  · exact hp5_5_node358 T childKnown
theorem hp5_5_node354 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected354 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected354 ((2 : Int),(2 : Int)) hp5_5_branches354 hp5_5_evidence354 hp5_5_check354 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches354,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node353 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected353 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected353 ((1 : Int),(2 : Int)) hp5_5_branches353 hp5_5_evidence353 hp5_5_check353 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches353,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node354 T childKnown
theorem hp5_5_node352 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected352 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected352 ((5 : Int),(0 : Int)) hp5_5_branches352 hp5_5_evidence352 hp5_5_check352 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches352,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node351 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected351 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected351 ((8 : Int),(1 : Int)) hp5_5_branches351 hp5_5_evidence351 hp5_5_check351 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches351,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node350 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected350 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected350 ((11 : Int),(2 : Int)) hp5_5_branches350 hp5_5_evidence350 hp5_5_check350 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches350,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node349 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected349 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected349 ((11 : Int),(2 : Int)) hp5_5_branches349 hp5_5_evidence349 hp5_5_check349 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches349,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node348 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected348 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected348 ((11 : Int),(1 : Int)) hp5_5_branches348 hp5_5_evidence348 hp5_5_check348 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches348,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node349 T childKnown
  · exact hp5_5_node350 T childKnown
theorem hp5_5_node347 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected347 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected347 ((9 : Int),(1 : Int)) hp5_5_branches347 hp5_5_evidence347 hp5_5_check347 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches347,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node348 T childKnown
theorem hp5_5_node346 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected346 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected346 ((3 : Int),(2 : Int)) hp5_5_branches346 hp5_5_evidence346 hp5_5_check346 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches346,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node347 T childKnown
  · exact hp5_5_node351 T childKnown
theorem hp5_5_node345 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected345 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected345 ((5 : Int),(0 : Int)) hp5_5_branches345 hp5_5_evidence345 hp5_5_check345 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches345,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node346 T childKnown
theorem hp5_5_node344 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected344 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected344 ((1 : Int),(2 : Int)) hp5_5_branches344 hp5_5_evidence344 hp5_5_check344 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches344,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node345 T childKnown
theorem hp5_5_node343 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected343 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected343 ((2 : Int),(2 : Int)) hp5_5_branches343 hp5_5_evidence343 hp5_5_check343 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches343,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node342 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected342 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected342 ((2 : Int),(2 : Int)) hp5_5_branches342 hp5_5_evidence342 hp5_5_check342 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches342,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node341 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected341 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected341 ((2 : Int),(1 : Int)) hp5_5_branches341 hp5_5_evidence341 hp5_5_check341 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches341,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node342 T childKnown
  · exact hp5_5_node343 T childKnown
theorem hp5_5_node340 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected340 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected340 ((11 : Int),(2 : Int)) hp5_5_branches340 hp5_5_evidence340 hp5_5_check340 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches340,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node339 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected339 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected339 ((11 : Int),(2 : Int)) hp5_5_branches339 hp5_5_evidence339 hp5_5_check339 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches339,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node338 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected338 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected338 ((11 : Int),(1 : Int)) hp5_5_branches338 hp5_5_evidence338 hp5_5_check338 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches338,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node339 T childKnown
  · exact hp5_5_node340 T childKnown
theorem hp5_5_node337 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected337 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected337 ((8 : Int),(2 : Int)) hp5_5_branches337 hp5_5_evidence337 hp5_5_check337 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches337,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node338 T childKnown
theorem hp5_5_node336 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected336 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected336 ((8 : Int),(2 : Int)) hp5_5_branches336 hp5_5_evidence336 hp5_5_check336 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches336,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node335 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected335 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected335 ((9 : Int),(1 : Int)) hp5_5_branches335 hp5_5_evidence335 hp5_5_check335 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches335,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node336 T childKnown
  · exact hp5_5_node337 T childKnown
theorem hp5_5_node334 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected334 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected334 ((2 : Int),(1 : Int)) hp5_5_branches334 hp5_5_evidence334 hp5_5_check334 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches334,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node335 T childKnown
theorem hp5_5_node333 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected333 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected333 ((5 : Int),(0 : Int)) hp5_5_branches333 hp5_5_evidence333 hp5_5_check333 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches333,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node334 T childKnown
theorem hp5_5_node332 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected332 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected332 ((1 : Int),(1 : Int)) hp5_5_branches332 hp5_5_evidence332 hp5_5_check332 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches332,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node333 T childKnown
  · exact hp5_5_node341 T childKnown
  · exact hp5_5_node344 T childKnown
  · exact hp5_5_node352 T childKnown
  · exact hp5_5_node353 T childKnown
theorem hp5_5_node331 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected331 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected331 ((0 : Int),(1 : Int)) hp5_5_branches331 hp5_5_evidence331 hp5_5_check331 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches331,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node332 T childKnown
  · exact hp5_5_node355 T childKnown
  · exact hp5_5_node359 T childKnown
  · exact hp5_5_node362 T childKnown
  · exact hp5_5_node368 T childKnown
  · exact hp5_5_node371 T childKnown
  · exact hp5_5_node396 T childKnown
  · exact hp5_5_node402 T childKnown
theorem hp5_5_node330 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected330 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected330 ((5 : Int),(1 : Int)) hp5_5_branches330 hp5_5_evidence330 hp5_5_check330 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches330,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node329 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected329 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected329 ((3 : Int),(1 : Int)) hp5_5_branches329 hp5_5_evidence329 hp5_5_check329 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches329,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node328 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected328 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected328 ((3 : Int),(1 : Int)) hp5_5_branches328 hp5_5_evidence328 hp5_5_check328 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches328,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node327 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected327 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected327 ((3 : Int),(1 : Int)) hp5_5_branches327 hp5_5_evidence327 hp5_5_check327 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches327,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node326 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected326 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected326 ((4 : Int),(1 : Int)) hp5_5_branches326 hp5_5_evidence326 hp5_5_check326 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches326,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node327 T childKnown
  · exact hp5_5_node328 T childKnown
  · exact hp5_5_node329 T childKnown
  · exact hp5_5_node330 T childKnown
theorem hp5_5_node325 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected325 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected325 ((4 : Int),(1 : Int)) hp5_5_branches325 hp5_5_evidence325 hp5_5_check325 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches325,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node324 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected324 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected324 ((4 : Int),(1 : Int)) hp5_5_branches324 hp5_5_evidence324 hp5_5_check324 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches324,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node323 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected323 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected323 ((4 : Int),(1 : Int)) hp5_5_branches323 hp5_5_evidence323 hp5_5_check323 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches323,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node322 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected322 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected322 ((0 : Int),(2 : Int)) hp5_5_branches322 hp5_5_evidence322 hp5_5_check322 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches322,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node321 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected321 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected321 ((0 : Int),(2 : Int)) hp5_5_branches321 hp5_5_evidence321 hp5_5_check321 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches321,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node320 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected320 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected320 ((1 : Int),(1 : Int)) hp5_5_branches320 hp5_5_evidence320 hp5_5_check320 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches320,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node321 T childKnown
  · exact hp5_5_node322 T childKnown
theorem hp5_5_node319 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected319 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected319 ((4 : Int),(1 : Int)) hp5_5_branches319 hp5_5_evidence319 hp5_5_check319 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches319,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node320 T childKnown
theorem hp5_5_node318 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected318 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected318 ((3 : Int),(1 : Int)) hp5_5_branches318 hp5_5_evidence318 hp5_5_check318 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches318,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node319 T childKnown
  · exact hp5_5_node323 T childKnown
  · exact hp5_5_node324 T childKnown
  · exact hp5_5_node325 T childKnown
theorem hp5_5_node317 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected317 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected317 ((5 : Int),(1 : Int)) hp5_5_branches317 hp5_5_evidence317 hp5_5_check317 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches317,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node316 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected316 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected316 ((5 : Int),(0 : Int)) hp5_5_branches316 hp5_5_evidence316 hp5_5_check316 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches316,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node317 T childKnown
theorem hp5_5_node315 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected315 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected315 ((3 : Int),(1 : Int)) hp5_5_branches315 hp5_5_evidence315 hp5_5_check315 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches315,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node316 T childKnown
theorem hp5_5_node314 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected314 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected314 ((0 : Int),(2 : Int)) hp5_5_branches314 hp5_5_evidence314 hp5_5_check314 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches314,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node313 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected313 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected313 ((0 : Int),(2 : Int)) hp5_5_branches313 hp5_5_evidence313 hp5_5_check313 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches313,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node312 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected312 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected312 ((1 : Int),(1 : Int)) hp5_5_branches312 hp5_5_evidence312 hp5_5_check312 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches312,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node313 T childKnown
  · exact hp5_5_node314 T childKnown
theorem hp5_5_node311 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected311 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected311 ((5 : Int),(0 : Int)) hp5_5_branches311 hp5_5_evidence311 hp5_5_check311 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches311,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node312 T childKnown
theorem hp5_5_node310 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected310 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected310 ((3 : Int),(1 : Int)) hp5_5_branches310 hp5_5_evidence310 hp5_5_check310 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches310,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node311 T childKnown
theorem hp5_5_node309 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected309 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected309 ((3 : Int),(1 : Int)) hp5_5_branches309 hp5_5_evidence309 hp5_5_check309 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches309,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node308 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected308 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected308 ((4 : Int),(0 : Int)) hp5_5_branches308 hp5_5_evidence308 hp5_5_check308 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches308,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node309 T childKnown
  · exact hp5_5_node310 T childKnown
  · exact hp5_5_node315 T childKnown
  · exact hp5_5_node318 T childKnown
  · exact hp5_5_node326 T childKnown
theorem hp5_5_node307 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected307 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected307 ((12 : Int),(1 : Int)) hp5_5_branches307 hp5_5_evidence307 hp5_5_check307 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches307,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node306 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected306 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected306 ((10 : Int),(1 : Int)) hp5_5_branches306 hp5_5_evidence306 hp5_5_check306 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches306,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node305 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected305 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected305 ((10 : Int),(1 : Int)) hp5_5_branches305 hp5_5_evidence305 hp5_5_check305 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches305,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node304 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected304 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected304 ((10 : Int),(1 : Int)) hp5_5_branches304 hp5_5_evidence304 hp5_5_check304 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches304,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node303 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected303 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected303 ((11 : Int),(1 : Int)) hp5_5_branches303 hp5_5_evidence303 hp5_5_check303 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches303,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node304 T childKnown
  · exact hp5_5_node305 T childKnown
  · exact hp5_5_node306 T childKnown
  · exact hp5_5_node307 T childKnown
theorem hp5_5_node302 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected302 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected302 ((11 : Int),(1 : Int)) hp5_5_branches302 hp5_5_evidence302 hp5_5_check302 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches302,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node301 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected301 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected301 ((11 : Int),(1 : Int)) hp5_5_branches301 hp5_5_evidence301 hp5_5_check301 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches301,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node300 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected300 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected300 ((11 : Int),(1 : Int)) hp5_5_branches300 hp5_5_evidence300 hp5_5_check300 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches300,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node299 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected299 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected299 ((5 : Int),(2 : Int)) hp5_5_branches299 hp5_5_evidence299 hp5_5_check299 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches299,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node298 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected298 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected298 ((8 : Int),(1 : Int)) hp5_5_branches298 hp5_5_evidence298 hp5_5_check298 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches298,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node299 T childKnown
theorem hp5_5_node297 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected297 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected297 ((10 : Int),(1 : Int)) hp5_5_branches297 hp5_5_evidence297 hp5_5_check297 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches297,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node298 T childKnown
  · exact hp5_5_node300 T childKnown
  · exact hp5_5_node301 T childKnown
  · exact hp5_5_node302 T childKnown
theorem hp5_5_node296 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected296 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected296 ((5 : Int),(2 : Int)) hp5_5_branches296 hp5_5_evidence296 hp5_5_check296 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches296,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node295 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected295 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected295 ((8 : Int),(1 : Int)) hp5_5_branches295 hp5_5_evidence295 hp5_5_check295 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches295,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node296 T childKnown
theorem hp5_5_node294 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected294 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected294 ((10 : Int),(1 : Int)) hp5_5_branches294 hp5_5_evidence294 hp5_5_check294 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches294,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node295 T childKnown
theorem hp5_5_node293 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected293 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected293 ((5 : Int),(2 : Int)) hp5_5_branches293 hp5_5_evidence293 hp5_5_check293 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches293,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node292 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected292 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected292 ((8 : Int),(1 : Int)) hp5_5_branches292 hp5_5_evidence292 hp5_5_check292 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches292,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node293 T childKnown
theorem hp5_5_node291 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected291 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected291 ((10 : Int),(1 : Int)) hp5_5_branches291 hp5_5_evidence291 hp5_5_check291 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches291,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node292 T childKnown
theorem hp5_5_node290 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected290 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected290 ((10 : Int),(1 : Int)) hp5_5_branches290 hp5_5_evidence290 hp5_5_check290 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches290,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node289 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected289 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected289 ((11 : Int),(0 : Int)) hp5_5_branches289 hp5_5_evidence289 hp5_5_check289 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches289,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node290 T childKnown
  · exact hp5_5_node291 T childKnown
  · exact hp5_5_node294 T childKnown
  · exact hp5_5_node297 T childKnown
  · exact hp5_5_node303 T childKnown
theorem hp5_5_node288 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected288 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected288 ((1 : Int),(1 : Int)) hp5_5_branches288 hp5_5_evidence288 hp5_5_check288 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches288,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node287 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected287 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected287 ((1 : Int),(1 : Int)) hp5_5_branches287 hp5_5_evidence287 hp5_5_check287 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches287,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node286 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected286 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected286 ((1 : Int),(1 : Int)) hp5_5_branches286 hp5_5_evidence286 hp5_5_check286 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches286,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node285 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected285 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected285 ((2 : Int),(1 : Int)) hp5_5_branches285 hp5_5_evidence285 hp5_5_check285 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches285,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node284 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected284 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected284 ((1 : Int),(1 : Int)) hp5_5_branches284 hp5_5_evidence284 hp5_5_check284 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches284,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node285 T childKnown
theorem hp5_5_node283 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected283 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected283 ((0 : Int),(1 : Int)) hp5_5_branches283 hp5_5_evidence283 hp5_5_check283 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches283,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node284 T childKnown
  · exact hp5_5_node286 T childKnown
  · exact hp5_5_node287 T childKnown
  · exact hp5_5_node288 T childKnown
theorem hp5_5_node282 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected282 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected282 ((0 : Int),(1 : Int)) hp5_5_branches282 hp5_5_evidence282 hp5_5_check282 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches282,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node281 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected281 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected281 ((3 : Int),(1 : Int)) hp5_5_branches281 hp5_5_evidence281 hp5_5_check281 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches281,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node282 T childKnown
theorem hp5_5_node280 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected280 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected280 ((0 : Int),(1 : Int)) hp5_5_branches280 hp5_5_evidence280 hp5_5_check280 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches280,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node279 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected279 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected279 ((3 : Int),(1 : Int)) hp5_5_branches279 hp5_5_evidence279 hp5_5_check279 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches279,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node280 T childKnown
theorem hp5_5_node278 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected278 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected278 ((3 : Int),(1 : Int)) hp5_5_branches278 hp5_5_evidence278 hp5_5_check278 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches278,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node277 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected277 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected277 ((0 : Int),(1 : Int)) hp5_5_branches277 hp5_5_evidence277 hp5_5_check277 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches277,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node276 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected276 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected276 ((0 : Int),(1 : Int)) hp5_5_branches276 hp5_5_evidence276 hp5_5_check276 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches276,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node275 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected275 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected275 ((1 : Int),(2 : Int)) hp5_5_branches275 hp5_5_evidence275 hp5_5_check275 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches275,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node274 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected274 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected274 ((1 : Int),(2 : Int)) hp5_5_branches274 hp5_5_evidence274 hp5_5_check274 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches274,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node273 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected273 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected273 ((1 : Int),(2 : Int)) hp5_5_branches273 hp5_5_evidence273 hp5_5_check273 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches273,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node272 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected272 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected272 ((2 : Int),(2 : Int)) hp5_5_branches272 hp5_5_evidence272 hp5_5_check272 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches272,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node271 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected271 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected271 ((1 : Int),(2 : Int)) hp5_5_branches271 hp5_5_evidence271 hp5_5_check271 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches271,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node272 T childKnown
theorem hp5_5_node270 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected270 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected270 ((0 : Int),(2 : Int)) hp5_5_branches270 hp5_5_evidence270 hp5_5_check270 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches270,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node271 T childKnown
  · exact hp5_5_node273 T childKnown
  · exact hp5_5_node274 T childKnown
  · exact hp5_5_node275 T childKnown
theorem hp5_5_node269 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected269 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected269 ((4 : Int),(0 : Int)) hp5_5_branches269 hp5_5_evidence269 hp5_5_check269 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches269,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node270 T childKnown
  · exact hp5_5_node276 T childKnown
  · exact hp5_5_node277 T childKnown
  · exact hp5_5_node278 T childKnown
  · exact hp5_5_node279 T childKnown
  · exact hp5_5_node281 T childKnown
  · exact hp5_5_node283 T childKnown
  · exact hp5_5_node289 T childKnown
theorem hp5_5_node268 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected268 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected268 ((4 : Int),(1 : Int)) hp5_5_branches268 hp5_5_evidence268 hp5_5_check268 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches268,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node267 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected267 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected267 ((2 : Int),(1 : Int)) hp5_5_branches267 hp5_5_evidence267 hp5_5_check267 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches267,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node266 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected266 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected266 ((2 : Int),(1 : Int)) hp5_5_branches266 hp5_5_evidence266 hp5_5_check266 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches266,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node265 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected265 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected265 ((2 : Int),(1 : Int)) hp5_5_branches265 hp5_5_evidence265 hp5_5_check265 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches265,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node264 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected264 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected264 ((3 : Int),(1 : Int)) hp5_5_branches264 hp5_5_evidence264 hp5_5_check264 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches264,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node265 T childKnown
  · exact hp5_5_node266 T childKnown
  · exact hp5_5_node267 T childKnown
  · exact hp5_5_node268 T childKnown
theorem hp5_5_node263 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected263 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected263 ((3 : Int),(1 : Int)) hp5_5_branches263 hp5_5_evidence263 hp5_5_check263 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches263,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node262 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected262 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected262 ((3 : Int),(1 : Int)) hp5_5_branches262 hp5_5_evidence262 hp5_5_check262 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches262,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node261 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected261 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected261 ((3 : Int),(1 : Int)) hp5_5_branches261 hp5_5_evidence261 hp5_5_check261 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches261,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node260 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected260 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected260 ((0 : Int),(2 : Int)) hp5_5_branches260 hp5_5_evidence260 hp5_5_check260 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches260,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node259 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected259 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected259 ((0 : Int),(2 : Int)) hp5_5_branches259 hp5_5_evidence259 hp5_5_check259 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches259,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node258 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected258 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected258 ((0 : Int),(1 : Int)) hp5_5_branches258 hp5_5_evidence258 hp5_5_check258 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches258,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node259 T childKnown
  · exact hp5_5_node260 T childKnown
theorem hp5_5_node257 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected257 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected257 ((3 : Int),(1 : Int)) hp5_5_branches257 hp5_5_evidence257 hp5_5_check257 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches257,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node258 T childKnown
theorem hp5_5_node256 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected256 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected256 ((2 : Int),(1 : Int)) hp5_5_branches256 hp5_5_evidence256 hp5_5_check256 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches256,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node257 T childKnown
  · exact hp5_5_node261 T childKnown
  · exact hp5_5_node262 T childKnown
  · exact hp5_5_node263 T childKnown
theorem hp5_5_node255 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected255 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected255 ((4 : Int),(1 : Int)) hp5_5_branches255 hp5_5_evidence255 hp5_5_check255 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches255,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node254 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected254 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected254 ((4 : Int),(0 : Int)) hp5_5_branches254 hp5_5_evidence254 hp5_5_check254 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches254,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node255 T childKnown
theorem hp5_5_node253 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected253 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected253 ((2 : Int),(1 : Int)) hp5_5_branches253 hp5_5_evidence253 hp5_5_check253 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches253,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node254 T childKnown
theorem hp5_5_node252 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected252 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected252 ((0 : Int),(2 : Int)) hp5_5_branches252 hp5_5_evidence252 hp5_5_check252 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches252,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node251 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected251 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected251 ((0 : Int),(2 : Int)) hp5_5_branches251 hp5_5_evidence251 hp5_5_check251 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches251,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node250 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected250 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected250 ((0 : Int),(1 : Int)) hp5_5_branches250 hp5_5_evidence250 hp5_5_check250 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches250,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node251 T childKnown
  · exact hp5_5_node252 T childKnown
theorem hp5_5_node249 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected249 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected249 ((4 : Int),(0 : Int)) hp5_5_branches249 hp5_5_evidence249 hp5_5_check249 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches249,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node250 T childKnown
theorem hp5_5_node248 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected248 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected248 ((2 : Int),(1 : Int)) hp5_5_branches248 hp5_5_evidence248 hp5_5_check248 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches248,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node249 T childKnown
theorem hp5_5_node247 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected247 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected247 ((2 : Int),(1 : Int)) hp5_5_branches247 hp5_5_evidence247 hp5_5_check247 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches247,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node246 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected246 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected246 ((3 : Int),(0 : Int)) hp5_5_branches246 hp5_5_evidence246 hp5_5_check246 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches246,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node247 T childKnown
  · exact hp5_5_node248 T childKnown
  · exact hp5_5_node253 T childKnown
  · exact hp5_5_node256 T childKnown
  · exact hp5_5_node264 T childKnown
theorem hp5_5_node245 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected245 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected245 ((11 : Int),(1 : Int)) hp5_5_branches245 hp5_5_evidence245 hp5_5_check245 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches245,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node244 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected244 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected244 ((9 : Int),(1 : Int)) hp5_5_branches244 hp5_5_evidence244 hp5_5_check244 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches244,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node243 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected243 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected243 ((9 : Int),(1 : Int)) hp5_5_branches243 hp5_5_evidence243 hp5_5_check243 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches243,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node242 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected242 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected242 ((9 : Int),(1 : Int)) hp5_5_branches242 hp5_5_evidence242 hp5_5_check242 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches242,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node241 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected241 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected241 ((10 : Int),(1 : Int)) hp5_5_branches241 hp5_5_evidence241 hp5_5_check241 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches241,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node242 T childKnown
  · exact hp5_5_node243 T childKnown
  · exact hp5_5_node244 T childKnown
  · exact hp5_5_node245 T childKnown
theorem hp5_5_node240 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected240 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected240 ((10 : Int),(1 : Int)) hp5_5_branches240 hp5_5_evidence240 hp5_5_check240 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches240,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node239 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected239 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected239 ((10 : Int),(1 : Int)) hp5_5_branches239 hp5_5_evidence239 hp5_5_check239 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches239,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node238 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected238 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected238 ((10 : Int),(1 : Int)) hp5_5_branches238 hp5_5_evidence238 hp5_5_check238 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches238,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node237 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected237 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected237 ((4 : Int),(2 : Int)) hp5_5_branches237 hp5_5_evidence237 hp5_5_check237 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches237,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node236 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected236 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected236 ((7 : Int),(1 : Int)) hp5_5_branches236 hp5_5_evidence236 hp5_5_check236 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches236,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node237 T childKnown
theorem hp5_5_node235 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected235 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected235 ((9 : Int),(1 : Int)) hp5_5_branches235 hp5_5_evidence235 hp5_5_check235 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches235,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node236 T childKnown
  · exact hp5_5_node238 T childKnown
  · exact hp5_5_node239 T childKnown
  · exact hp5_5_node240 T childKnown
theorem hp5_5_node234 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected234 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected234 ((4 : Int),(2 : Int)) hp5_5_branches234 hp5_5_evidence234 hp5_5_check234 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches234,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node233 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected233 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected233 ((7 : Int),(1 : Int)) hp5_5_branches233 hp5_5_evidence233 hp5_5_check233 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches233,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node234 T childKnown
theorem hp5_5_node232 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected232 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected232 ((9 : Int),(1 : Int)) hp5_5_branches232 hp5_5_evidence232 hp5_5_check232 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches232,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node233 T childKnown
theorem hp5_5_node231 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected231 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected231 ((4 : Int),(2 : Int)) hp5_5_branches231 hp5_5_evidence231 hp5_5_check231 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches231,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node230 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected230 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected230 ((7 : Int),(1 : Int)) hp5_5_branches230 hp5_5_evidence230 hp5_5_check230 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches230,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node231 T childKnown
theorem hp5_5_node229 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected229 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected229 ((9 : Int),(1 : Int)) hp5_5_branches229 hp5_5_evidence229 hp5_5_check229 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches229,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node230 T childKnown
theorem hp5_5_node228 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected228 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected228 ((9 : Int),(1 : Int)) hp5_5_branches228 hp5_5_evidence228 hp5_5_check228 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches228,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node227 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected227 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected227 ((10 : Int),(0 : Int)) hp5_5_branches227 hp5_5_evidence227 hp5_5_check227 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches227,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node228 T childKnown
  · exact hp5_5_node229 T childKnown
  · exact hp5_5_node232 T childKnown
  · exact hp5_5_node235 T childKnown
  · exact hp5_5_node241 T childKnown
theorem hp5_5_node226 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected226 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected226 ((1 : Int),(1 : Int)) hp5_5_branches226 hp5_5_evidence226 hp5_5_check226 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches226,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node225 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected225 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected225 ((1 : Int),(1 : Int)) hp5_5_branches225 hp5_5_evidence225 hp5_5_check225 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches225,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node224 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected224 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected224 ((1 : Int),(1 : Int)) hp5_5_branches224 hp5_5_evidence224 hp5_5_check224 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches224,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node223 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected223 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected223 ((2 : Int),(1 : Int)) hp5_5_branches223 hp5_5_evidence223 hp5_5_check223 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches223,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node222 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected222 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected222 ((1 : Int),(1 : Int)) hp5_5_branches222 hp5_5_evidence222 hp5_5_check222 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches222,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node223 T childKnown
theorem hp5_5_node221 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected221 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected221 ((0 : Int),(1 : Int)) hp5_5_branches221 hp5_5_evidence221 hp5_5_check221 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches221,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node222 T childKnown
  · exact hp5_5_node224 T childKnown
  · exact hp5_5_node225 T childKnown
  · exact hp5_5_node226 T childKnown
theorem hp5_5_node220 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected220 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected220 ((0 : Int),(1 : Int)) hp5_5_branches220 hp5_5_evidence220 hp5_5_check220 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches220,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node219 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected219 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected219 ((2 : Int),(1 : Int)) hp5_5_branches219 hp5_5_evidence219 hp5_5_check219 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches219,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node220 T childKnown
theorem hp5_5_node218 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected218 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected218 ((0 : Int),(1 : Int)) hp5_5_branches218 hp5_5_evidence218 hp5_5_check218 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches218,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node217 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected217 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected217 ((2 : Int),(1 : Int)) hp5_5_branches217 hp5_5_evidence217 hp5_5_check217 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches217,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node218 T childKnown
theorem hp5_5_node216 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected216 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected216 ((2 : Int),(1 : Int)) hp5_5_branches216 hp5_5_evidence216 hp5_5_check216 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches216,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node215 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected215 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected215 ((0 : Int),(1 : Int)) hp5_5_branches215 hp5_5_evidence215 hp5_5_check215 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches215,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node214 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected214 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected214 ((0 : Int),(1 : Int)) hp5_5_branches214 hp5_5_evidence214 hp5_5_check214 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches214,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node213 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected213 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected213 ((1 : Int),(2 : Int)) hp5_5_branches213 hp5_5_evidence213 hp5_5_check213 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches213,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node212 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected212 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected212 ((1 : Int),(2 : Int)) hp5_5_branches212 hp5_5_evidence212 hp5_5_check212 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches212,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node211 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected211 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected211 ((1 : Int),(2 : Int)) hp5_5_branches211 hp5_5_evidence211 hp5_5_check211 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches211,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node210 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected210 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected210 ((2 : Int),(2 : Int)) hp5_5_branches210 hp5_5_evidence210 hp5_5_check210 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches210,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node209 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected209 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected209 ((1 : Int),(2 : Int)) hp5_5_branches209 hp5_5_evidence209 hp5_5_check209 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches209,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node210 T childKnown
theorem hp5_5_node208 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected208 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected208 ((0 : Int),(2 : Int)) hp5_5_branches208 hp5_5_evidence208 hp5_5_check208 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches208,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node209 T childKnown
  · exact hp5_5_node211 T childKnown
  · exact hp5_5_node212 T childKnown
  · exact hp5_5_node213 T childKnown
theorem hp5_5_node207 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected207 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected207 ((3 : Int),(0 : Int)) hp5_5_branches207 hp5_5_evidence207 hp5_5_check207 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches207,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node208 T childKnown
  · exact hp5_5_node214 T childKnown
  · exact hp5_5_node215 T childKnown
  · exact hp5_5_node216 T childKnown
  · exact hp5_5_node217 T childKnown
  · exact hp5_5_node219 T childKnown
  · exact hp5_5_node221 T childKnown
  · exact hp5_5_node227 T childKnown
theorem hp5_5_node206 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected206 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected206 ((1 : Int),(1 : Int)) hp5_5_branches206 hp5_5_evidence206 hp5_5_check206 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches206,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node205 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected205 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected205 ((1 : Int),(1 : Int)) hp5_5_branches205 hp5_5_evidence205 hp5_5_check205 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches205,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node204 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected204 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected204 ((1 : Int),(0 : Int)) hp5_5_branches204 hp5_5_evidence204 hp5_5_check204 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches204,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node205 T childKnown
  · exact hp5_5_node206 T childKnown
theorem hp5_5_node203 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected203 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected203 ((2 : Int),(1 : Int)) hp5_5_branches203 hp5_5_evidence203 hp5_5_check203 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches203,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node202 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected202 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected202 ((1 : Int),(1 : Int)) hp5_5_branches202 hp5_5_evidence202 hp5_5_check202 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches202,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node203 T childKnown
theorem hp5_5_node201 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected201 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected201 ((3 : Int),(2 : Int)) hp5_5_branches201 hp5_5_evidence201 hp5_5_check201 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches201,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node200 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected200 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected200 ((3 : Int),(2 : Int)) hp5_5_branches200 hp5_5_evidence200 hp5_5_check200 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches200,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node199 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected199 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected199 ((3 : Int),(1 : Int)) hp5_5_branches199 hp5_5_evidence199 hp5_5_check199 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches199,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node200 T childKnown
  · exact hp5_5_node201 T childKnown
theorem hp5_5_node198 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected198 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected198 ((1 : Int),(1 : Int)) hp5_5_branches198 hp5_5_evidence198 hp5_5_check198 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches198,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node199 T childKnown
theorem hp5_5_node197 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected197 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected197 ((2 : Int),(1 : Int)) hp5_5_branches197 hp5_5_evidence197 hp5_5_check197 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches197,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node196 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected196 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected196 ((2 : Int),(0 : Int)) hp5_5_branches196 hp5_5_evidence196 hp5_5_check196 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches196,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node197 T childKnown
theorem hp5_5_node195 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected195 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected195 ((3 : Int),(2 : Int)) hp5_5_branches195 hp5_5_evidence195 hp5_5_check195 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches195,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node194 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected194 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected194 ((3 : Int),(2 : Int)) hp5_5_branches194 hp5_5_evidence194 hp5_5_check194 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches194,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node193 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected193 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected193 ((3 : Int),(2 : Int)) hp5_5_branches193 hp5_5_evidence193 hp5_5_check193 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches193,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node192 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected192 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected192 ((4 : Int),(2 : Int)) hp5_5_branches192 hp5_5_evidence192 hp5_5_check192 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches192,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node191 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected191 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected191 ((3 : Int),(2 : Int)) hp5_5_branches191 hp5_5_evidence191 hp5_5_check191 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches191,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node192 T childKnown
theorem hp5_5_node190 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected190 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected190 ((2 : Int),(2 : Int)) hp5_5_branches190 hp5_5_evidence190 hp5_5_check190 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches190,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node191 T childKnown
  · exact hp5_5_node193 T childKnown
  · exact hp5_5_node194 T childKnown
  · exact hp5_5_node195 T childKnown
theorem hp5_5_node189 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected189 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected189 ((2 : Int),(0 : Int)) hp5_5_branches189 hp5_5_evidence189 hp5_5_check189 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches189,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node190 T childKnown
theorem hp5_5_node188 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected188 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected188 ((1 : Int),(0 : Int)) hp5_5_branches188 hp5_5_evidence188 hp5_5_check188 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches188,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node189 T childKnown
  · exact hp5_5_node196 T childKnown
  · exact hp5_5_node198 T childKnown
  · exact hp5_5_node202 T childKnown
theorem hp5_5_node187 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected187 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected187 ((2 : Int),(1 : Int)) hp5_5_branches187 hp5_5_evidence187 hp5_5_check187 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches187,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node186 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected186 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected186 ((1 : Int),(1 : Int)) hp5_5_branches186 hp5_5_evidence186 hp5_5_check186 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches186,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node187 T childKnown
theorem hp5_5_node185 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected185 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected185 ((3 : Int),(2 : Int)) hp5_5_branches185 hp5_5_evidence185 hp5_5_check185 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches185,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node184 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected184 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected184 ((3 : Int),(2 : Int)) hp5_5_branches184 hp5_5_evidence184 hp5_5_check184 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches184,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node183 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected183 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected183 ((3 : Int),(1 : Int)) hp5_5_branches183 hp5_5_evidence183 hp5_5_check183 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches183,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node184 T childKnown
  · exact hp5_5_node185 T childKnown
theorem hp5_5_node182 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected182 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected182 ((1 : Int),(1 : Int)) hp5_5_branches182 hp5_5_evidence182 hp5_5_check182 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches182,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node183 T childKnown
theorem hp5_5_node181 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected181 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected181 ((2 : Int),(1 : Int)) hp5_5_branches181 hp5_5_evidence181 hp5_5_check181 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches181,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node180 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected180 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected180 ((2 : Int),(0 : Int)) hp5_5_branches180 hp5_5_evidence180 hp5_5_check180 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches180,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node181 T childKnown
theorem hp5_5_node179 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected179 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected179 ((3 : Int),(2 : Int)) hp5_5_branches179 hp5_5_evidence179 hp5_5_check179 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches179,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node178 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected178 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected178 ((3 : Int),(2 : Int)) hp5_5_branches178 hp5_5_evidence178 hp5_5_check178 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches178,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node177 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected177 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected177 ((3 : Int),(2 : Int)) hp5_5_branches177 hp5_5_evidence177 hp5_5_check177 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches177,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node176 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected176 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected176 ((4 : Int),(2 : Int)) hp5_5_branches176 hp5_5_evidence176 hp5_5_check176 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches176,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node175 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected175 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected175 ((3 : Int),(2 : Int)) hp5_5_branches175 hp5_5_evidence175 hp5_5_check175 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches175,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node176 T childKnown
theorem hp5_5_node174 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected174 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected174 ((2 : Int),(2 : Int)) hp5_5_branches174 hp5_5_evidence174 hp5_5_check174 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches174,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node175 T childKnown
  · exact hp5_5_node177 T childKnown
  · exact hp5_5_node178 T childKnown
  · exact hp5_5_node179 T childKnown
theorem hp5_5_node173 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected173 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected173 ((2 : Int),(0 : Int)) hp5_5_branches173 hp5_5_evidence173 hp5_5_check173 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches173,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node174 T childKnown
theorem hp5_5_node172 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected172 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected172 ((1 : Int),(0 : Int)) hp5_5_branches172 hp5_5_evidence172 hp5_5_check172 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches172,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node173 T childKnown
  · exact hp5_5_node180 T childKnown
  · exact hp5_5_node182 T childKnown
  · exact hp5_5_node186 T childKnown
theorem hp5_5_node171 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected171 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected171 ((3 : Int),(1 : Int)) hp5_5_branches171 hp5_5_evidence171 hp5_5_check171 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches171,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node170 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected170 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected170 ((1 : Int),(1 : Int)) hp5_5_branches170 hp5_5_evidence170 hp5_5_check170 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches170,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node169 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected169 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected169 ((1 : Int),(1 : Int)) hp5_5_branches169 hp5_5_evidence169 hp5_5_check169 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches169,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node168 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected168 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected168 ((1 : Int),(1 : Int)) hp5_5_branches168 hp5_5_evidence168 hp5_5_check168 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches168,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node167 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected167 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected167 ((2 : Int),(1 : Int)) hp5_5_branches167 hp5_5_evidence167 hp5_5_check167 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches167,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node168 T childKnown
  · exact hp5_5_node169 T childKnown
  · exact hp5_5_node170 T childKnown
  · exact hp5_5_node171 T childKnown
theorem hp5_5_node166 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected166 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected166 ((2 : Int),(1 : Int)) hp5_5_branches166 hp5_5_evidence166 hp5_5_check166 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches166,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node165 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected165 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected165 ((2 : Int),(1 : Int)) hp5_5_branches165 hp5_5_evidence165 hp5_5_check165 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches165,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node164 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected164 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected164 ((2 : Int),(1 : Int)) hp5_5_branches164 hp5_5_evidence164 hp5_5_check164 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches164,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node163 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected163 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected163 ((4 : Int),(2 : Int)) hp5_5_branches163 hp5_5_evidence163 hp5_5_check163 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches163,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node162 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected162 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected162 ((4 : Int),(2 : Int)) hp5_5_branches162 hp5_5_evidence162 hp5_5_check162 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches162,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node161 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected161 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected161 ((4 : Int),(1 : Int)) hp5_5_branches161 hp5_5_evidence161 hp5_5_check161 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches161,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node162 T childKnown
  · exact hp5_5_node163 T childKnown
theorem hp5_5_node160 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected160 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected160 ((2 : Int),(1 : Int)) hp5_5_branches160 hp5_5_evidence160 hp5_5_check160 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches160,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node161 T childKnown
theorem hp5_5_node159 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected159 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected159 ((1 : Int),(1 : Int)) hp5_5_branches159 hp5_5_evidence159 hp5_5_check159 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches159,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node160 T childKnown
  · exact hp5_5_node164 T childKnown
  · exact hp5_5_node165 T childKnown
  · exact hp5_5_node166 T childKnown
theorem hp5_5_node158 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected158 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected158 ((3 : Int),(1 : Int)) hp5_5_branches158 hp5_5_evidence158 hp5_5_check158 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches158,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node157 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected157 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected157 ((3 : Int),(0 : Int)) hp5_5_branches157 hp5_5_evidence157 hp5_5_check157 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches157,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node158 T childKnown
theorem hp5_5_node156 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected156 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected156 ((1 : Int),(1 : Int)) hp5_5_branches156 hp5_5_evidence156 hp5_5_check156 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches156,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node157 T childKnown
theorem hp5_5_node155 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected155 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected155 ((4 : Int),(2 : Int)) hp5_5_branches155 hp5_5_evidence155 hp5_5_check155 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches155,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node154 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected154 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected154 ((4 : Int),(2 : Int)) hp5_5_branches154 hp5_5_evidence154 hp5_5_check154 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches154,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node153 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected153 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected153 ((3 : Int),(2 : Int)) hp5_5_branches153 hp5_5_evidence153 hp5_5_check153 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches153,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node154 T childKnown
  · exact hp5_5_node155 T childKnown
theorem hp5_5_node152 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected152 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected152 ((3 : Int),(0 : Int)) hp5_5_branches152 hp5_5_evidence152 hp5_5_check152 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches152,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node153 T childKnown
theorem hp5_5_node151 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected151 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected151 ((1 : Int),(1 : Int)) hp5_5_branches151 hp5_5_evidence151 hp5_5_check151 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches151,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node152 T childKnown
theorem hp5_5_node150 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected150 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected150 ((1 : Int),(1 : Int)) hp5_5_branches150 hp5_5_evidence150 hp5_5_check150 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches150,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node149 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected149 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected149 ((2 : Int),(0 : Int)) hp5_5_branches149 hp5_5_evidence149 hp5_5_check149 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches149,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node150 T childKnown
  · exact hp5_5_node151 T childKnown
  · exact hp5_5_node156 T childKnown
  · exact hp5_5_node159 T childKnown
  · exact hp5_5_node167 T childKnown
theorem hp5_5_node148 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected148 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected148 ((10 : Int),(1 : Int)) hp5_5_branches148 hp5_5_evidence148 hp5_5_check148 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches148,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node147 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected147 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected147 ((8 : Int),(1 : Int)) hp5_5_branches147 hp5_5_evidence147 hp5_5_check147 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches147,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node146 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected146 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected146 ((8 : Int),(1 : Int)) hp5_5_branches146 hp5_5_evidence146 hp5_5_check146 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches146,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node145 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected145 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected145 ((8 : Int),(1 : Int)) hp5_5_branches145 hp5_5_evidence145 hp5_5_check145 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches145,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node144 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected144 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected144 ((9 : Int),(1 : Int)) hp5_5_branches144 hp5_5_evidence144 hp5_5_check144 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches144,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node145 T childKnown
  · exact hp5_5_node146 T childKnown
  · exact hp5_5_node147 T childKnown
  · exact hp5_5_node148 T childKnown
theorem hp5_5_node143 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected143 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected143 ((9 : Int),(1 : Int)) hp5_5_branches143 hp5_5_evidence143 hp5_5_check143 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches143,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node142 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected142 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected142 ((9 : Int),(1 : Int)) hp5_5_branches142 hp5_5_evidence142 hp5_5_check142 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches142,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node141 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected141 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected141 ((9 : Int),(1 : Int)) hp5_5_branches141 hp5_5_evidence141 hp5_5_check141 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches141,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node140 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected140 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected140 ((3 : Int),(2 : Int)) hp5_5_branches140 hp5_5_evidence140 hp5_5_check140 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches140,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node139 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected139 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected139 ((6 : Int),(1 : Int)) hp5_5_branches139 hp5_5_evidence139 hp5_5_check139 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches139,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node140 T childKnown
theorem hp5_5_node138 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected138 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected138 ((8 : Int),(1 : Int)) hp5_5_branches138 hp5_5_evidence138 hp5_5_check138 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches138,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node139 T childKnown
  · exact hp5_5_node141 T childKnown
  · exact hp5_5_node142 T childKnown
  · exact hp5_5_node143 T childKnown
theorem hp5_5_node137 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected137 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected137 ((3 : Int),(2 : Int)) hp5_5_branches137 hp5_5_evidence137 hp5_5_check137 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches137,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node136 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected136 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected136 ((6 : Int),(1 : Int)) hp5_5_branches136 hp5_5_evidence136 hp5_5_check136 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches136,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node137 T childKnown
theorem hp5_5_node135 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected135 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected135 ((8 : Int),(1 : Int)) hp5_5_branches135 hp5_5_evidence135 hp5_5_check135 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches135,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node136 T childKnown
theorem hp5_5_node134 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected134 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected134 ((3 : Int),(2 : Int)) hp5_5_branches134 hp5_5_evidence134 hp5_5_check134 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches134,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node133 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected133 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected133 ((6 : Int),(1 : Int)) hp5_5_branches133 hp5_5_evidence133 hp5_5_check133 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches133,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node134 T childKnown
theorem hp5_5_node132 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected132 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected132 ((8 : Int),(1 : Int)) hp5_5_branches132 hp5_5_evidence132 hp5_5_check132 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches132,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node133 T childKnown
theorem hp5_5_node131 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected131 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected131 ((8 : Int),(1 : Int)) hp5_5_branches131 hp5_5_evidence131 hp5_5_check131 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches131,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node130 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected130 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected130 ((9 : Int),(0 : Int)) hp5_5_branches130 hp5_5_evidence130 hp5_5_check130 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches130,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node131 T childKnown
  · exact hp5_5_node132 T childKnown
  · exact hp5_5_node135 T childKnown
  · exact hp5_5_node138 T childKnown
  · exact hp5_5_node144 T childKnown
theorem hp5_5_node129 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected129 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected129 ((1 : Int),(1 : Int)) hp5_5_branches129 hp5_5_evidence129 hp5_5_check129 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches129,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node128 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected128 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected128 ((1 : Int),(1 : Int)) hp5_5_branches128 hp5_5_evidence128 hp5_5_check128 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches128,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node127 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected127 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected127 ((1 : Int),(1 : Int)) hp5_5_branches127 hp5_5_evidence127 hp5_5_check127 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches127,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node126 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected126 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected126 ((2 : Int),(1 : Int)) hp5_5_branches126 hp5_5_evidence126 hp5_5_check126 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches126,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node125 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected125 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected125 ((1 : Int),(1 : Int)) hp5_5_branches125 hp5_5_evidence125 hp5_5_check125 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches125,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node126 T childKnown
theorem hp5_5_node124 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected124 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected124 ((0 : Int),(1 : Int)) hp5_5_branches124 hp5_5_evidence124 hp5_5_check124 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches124,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node125 T childKnown
  · exact hp5_5_node127 T childKnown
  · exact hp5_5_node128 T childKnown
  · exact hp5_5_node129 T childKnown
theorem hp5_5_node123 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected123 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected123 ((0 : Int),(1 : Int)) hp5_5_branches123 hp5_5_evidence123 hp5_5_check123 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches123,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node122 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected122 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected122 ((1 : Int),(1 : Int)) hp5_5_branches122 hp5_5_evidence122 hp5_5_check122 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches122,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node123 T childKnown
theorem hp5_5_node121 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected121 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected121 ((0 : Int),(1 : Int)) hp5_5_branches121 hp5_5_evidence121 hp5_5_check121 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches121,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node120 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected120 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected120 ((1 : Int),(1 : Int)) hp5_5_branches120 hp5_5_evidence120 hp5_5_check120 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches120,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node121 T childKnown
theorem hp5_5_node119 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected119 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected119 ((1 : Int),(1 : Int)) hp5_5_branches119 hp5_5_evidence119 hp5_5_check119 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches119,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node118 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected118 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected118 ((0 : Int),(1 : Int)) hp5_5_branches118 hp5_5_evidence118 hp5_5_check118 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches118,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node117 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected117 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected117 ((0 : Int),(1 : Int)) hp5_5_branches117 hp5_5_evidence117 hp5_5_check117 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches117,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node116 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected116 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected116 ((1 : Int),(2 : Int)) hp5_5_branches116 hp5_5_evidence116 hp5_5_check116 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches116,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node115 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected115 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected115 ((1 : Int),(2 : Int)) hp5_5_branches115 hp5_5_evidence115 hp5_5_check115 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches115,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node114 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected114 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected114 ((1 : Int),(2 : Int)) hp5_5_branches114 hp5_5_evidence114 hp5_5_check114 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches114,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node113 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected113 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected113 ((3 : Int),(1 : Int)) hp5_5_branches113 hp5_5_evidence113 hp5_5_check113 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches113,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node112 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected112 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected112 ((3 : Int),(1 : Int)) hp5_5_branches112 hp5_5_evidence112 hp5_5_check112 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches112,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node111 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected111 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected111 ((4 : Int),(1 : Int)) hp5_5_branches111 hp5_5_evidence111 hp5_5_check111 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches111,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node110 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected110 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected110 ((4 : Int),(0 : Int)) hp5_5_branches110 hp5_5_evidence110 hp5_5_check110 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches110,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node111 T childKnown
theorem hp5_5_node109 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected109 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected109 ((4 : Int),(2 : Int)) hp5_5_branches109 hp5_5_evidence109 hp5_5_check109 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches109,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node108 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected108 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected108 ((4 : Int),(0 : Int)) hp5_5_branches108 hp5_5_evidence108 hp5_5_check108 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches108,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node109 T childKnown
theorem hp5_5_node107 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected107 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected107 ((3 : Int),(0 : Int)) hp5_5_branches107 hp5_5_evidence107 hp5_5_check107 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches107,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node108 T childKnown
  · exact hp5_5_node110 T childKnown
  · exact hp5_5_node112 T childKnown
  · exact hp5_5_node113 T childKnown
theorem hp5_5_node106 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected106 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected106 ((1 : Int),(2 : Int)) hp5_5_branches106 hp5_5_evidence106 hp5_5_check106 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches106,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node107 T childKnown
theorem hp5_5_node105 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected105 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected105 ((0 : Int),(2 : Int)) hp5_5_branches105 hp5_5_evidence105 hp5_5_check105 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches105,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node106 T childKnown
  · exact hp5_5_node114 T childKnown
  · exact hp5_5_node115 T childKnown
  · exact hp5_5_node116 T childKnown
theorem hp5_5_node104 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected104 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected104 ((2 : Int),(0 : Int)) hp5_5_branches104 hp5_5_evidence104 hp5_5_check104 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches104,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node105 T childKnown
  · exact hp5_5_node117 T childKnown
  · exact hp5_5_node118 T childKnown
  · exact hp5_5_node119 T childKnown
  · exact hp5_5_node120 T childKnown
  · exact hp5_5_node122 T childKnown
  · exact hp5_5_node124 T childKnown
  · exact hp5_5_node130 T childKnown
theorem hp5_5_node103 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected103 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected103 ((2 : Int),(1 : Int)) hp5_5_branches103 hp5_5_evidence103 hp5_5_check103 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches103,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node102 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected102 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected102 ((0 : Int),(1 : Int)) hp5_5_branches102 hp5_5_evidence102 hp5_5_check102 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches102,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node101 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected101 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected101 ((0 : Int),(1 : Int)) hp5_5_branches101 hp5_5_evidence101 hp5_5_check101 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches101,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node100 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected100 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected100 ((0 : Int),(1 : Int)) hp5_5_branches100 hp5_5_evidence100 hp5_5_check100 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches100,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node99 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected99 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected99 ((1 : Int),(1 : Int)) hp5_5_branches99 hp5_5_evidence99 hp5_5_check99 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches99,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node100 T childKnown
  · exact hp5_5_node101 T childKnown
  · exact hp5_5_node102 T childKnown
  · exact hp5_5_node103 T childKnown
theorem hp5_5_node98 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected98 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected98 ((1 : Int),(1 : Int)) hp5_5_branches98 hp5_5_evidence98 hp5_5_check98 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches98,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node97 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected97 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected97 ((1 : Int),(1 : Int)) hp5_5_branches97 hp5_5_evidence97 hp5_5_check97 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches97,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node96 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected96 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected96 ((1 : Int),(1 : Int)) hp5_5_branches96 hp5_5_evidence96 hp5_5_check96 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches96,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node95 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected95 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected95 ((3 : Int),(2 : Int)) hp5_5_branches95 hp5_5_evidence95 hp5_5_check95 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches95,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node94 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected94 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected94 ((3 : Int),(2 : Int)) hp5_5_branches94 hp5_5_evidence94 hp5_5_check94 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches94,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node93 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected93 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected93 ((3 : Int),(1 : Int)) hp5_5_branches93 hp5_5_evidence93 hp5_5_check93 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches93,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node94 T childKnown
  · exact hp5_5_node95 T childKnown
theorem hp5_5_node92 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected92 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected92 ((1 : Int),(1 : Int)) hp5_5_branches92 hp5_5_evidence92 hp5_5_check92 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches92,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node93 T childKnown
theorem hp5_5_node91 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected91 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected91 ((0 : Int),(1 : Int)) hp5_5_branches91 hp5_5_evidence91 hp5_5_check91 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches91,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node92 T childKnown
  · exact hp5_5_node96 T childKnown
  · exact hp5_5_node97 T childKnown
  · exact hp5_5_node98 T childKnown
theorem hp5_5_node90 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected90 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected90 ((2 : Int),(1 : Int)) hp5_5_branches90 hp5_5_evidence90 hp5_5_check90 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches90,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node89 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected89 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected89 ((2 : Int),(0 : Int)) hp5_5_branches89 hp5_5_evidence89 hp5_5_check89 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches89,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node90 T childKnown
theorem hp5_5_node88 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected88 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected88 ((0 : Int),(1 : Int)) hp5_5_branches88 hp5_5_evidence88 hp5_5_check88 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches88,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node89 T childKnown
theorem hp5_5_node87 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected87 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected87 ((3 : Int),(2 : Int)) hp5_5_branches87 hp5_5_evidence87 hp5_5_check87 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches87,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node86 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected86 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected86 ((3 : Int),(2 : Int)) hp5_5_branches86 hp5_5_evidence86 hp5_5_check86 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches86,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node85 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected85 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected85 ((2 : Int),(2 : Int)) hp5_5_branches85 hp5_5_evidence85 hp5_5_check85 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches85,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node86 T childKnown
  · exact hp5_5_node87 T childKnown
theorem hp5_5_node84 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected84 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected84 ((2 : Int),(0 : Int)) hp5_5_branches84 hp5_5_evidence84 hp5_5_check84 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches84,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node85 T childKnown
theorem hp5_5_node83 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected83 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected83 ((0 : Int),(1 : Int)) hp5_5_branches83 hp5_5_evidence83 hp5_5_check83 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches83,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node84 T childKnown
theorem hp5_5_node82 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected82 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected82 ((0 : Int),(1 : Int)) hp5_5_branches82 hp5_5_evidence82 hp5_5_check82 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches82,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node81 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected81 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected81 ((1 : Int),(0 : Int)) hp5_5_branches81 hp5_5_evidence81 hp5_5_check81 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches81,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node82 T childKnown
  · exact hp5_5_node83 T childKnown
  · exact hp5_5_node88 T childKnown
  · exact hp5_5_node91 T childKnown
  · exact hp5_5_node99 T childKnown
theorem hp5_5_node80 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected80 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected80 ((9 : Int),(1 : Int)) hp5_5_branches80 hp5_5_evidence80 hp5_5_check80 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches80,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node79 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected79 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected79 ((7 : Int),(1 : Int)) hp5_5_branches79 hp5_5_evidence79 hp5_5_check79 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches79,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node78 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected78 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected78 ((7 : Int),(1 : Int)) hp5_5_branches78 hp5_5_evidence78 hp5_5_check78 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches78,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node77 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected77 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected77 ((7 : Int),(1 : Int)) hp5_5_branches77 hp5_5_evidence77 hp5_5_check77 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches77,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node76 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected76 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected76 ((8 : Int),(1 : Int)) hp5_5_branches76 hp5_5_evidence76 hp5_5_check76 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches76,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node77 T childKnown
  · exact hp5_5_node78 T childKnown
  · exact hp5_5_node79 T childKnown
  · exact hp5_5_node80 T childKnown
theorem hp5_5_node75 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected75 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected75 ((8 : Int),(1 : Int)) hp5_5_branches75 hp5_5_evidence75 hp5_5_check75 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches75,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node74 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected74 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected74 ((8 : Int),(1 : Int)) hp5_5_branches74 hp5_5_evidence74 hp5_5_check74 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches74,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node73 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected73 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected73 ((8 : Int),(1 : Int)) hp5_5_branches73 hp5_5_evidence73 hp5_5_check73 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches73,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node72 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected72 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected72 ((2 : Int),(2 : Int)) hp5_5_branches72 hp5_5_evidence72 hp5_5_check72 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches72,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node71 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected71 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected71 ((5 : Int),(1 : Int)) hp5_5_branches71 hp5_5_evidence71 hp5_5_check71 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches71,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node72 T childKnown
theorem hp5_5_node70 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected70 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected70 ((7 : Int),(1 : Int)) hp5_5_branches70 hp5_5_evidence70 hp5_5_check70 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches70,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node71 T childKnown
  · exact hp5_5_node73 T childKnown
  · exact hp5_5_node74 T childKnown
  · exact hp5_5_node75 T childKnown
theorem hp5_5_node69 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected69 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected69 ((2 : Int),(2 : Int)) hp5_5_branches69 hp5_5_evidence69 hp5_5_check69 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches69,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node68 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected68 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected68 ((5 : Int),(1 : Int)) hp5_5_branches68 hp5_5_evidence68 hp5_5_check68 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches68,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node69 T childKnown
theorem hp5_5_node67 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected67 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected67 ((7 : Int),(1 : Int)) hp5_5_branches67 hp5_5_evidence67 hp5_5_check67 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches67,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node68 T childKnown
theorem hp5_5_node66 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected66 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected66 ((2 : Int),(2 : Int)) hp5_5_branches66 hp5_5_evidence66 hp5_5_check66 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches66,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node65 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected65 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected65 ((5 : Int),(1 : Int)) hp5_5_branches65 hp5_5_evidence65 hp5_5_check65 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches65,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node66 T childKnown
theorem hp5_5_node64 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected64 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected64 ((7 : Int),(1 : Int)) hp5_5_branches64 hp5_5_evidence64 hp5_5_check64 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches64,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node65 T childKnown
theorem hp5_5_node63 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected63 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected63 ((7 : Int),(1 : Int)) hp5_5_branches63 hp5_5_evidence63 hp5_5_check63 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches63,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node62 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected62 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected62 ((8 : Int),(0 : Int)) hp5_5_branches62 hp5_5_evidence62 hp5_5_check62 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches62,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node63 T childKnown
  · exact hp5_5_node64 T childKnown
  · exact hp5_5_node67 T childKnown
  · exact hp5_5_node70 T childKnown
  · exact hp5_5_node76 T childKnown
theorem hp5_5_node61 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected61 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected61 ((1 : Int),(1 : Int)) hp5_5_branches61 hp5_5_evidence61 hp5_5_check61 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches61,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node60 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected60 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected60 ((1 : Int),(1 : Int)) hp5_5_branches60 hp5_5_evidence60 hp5_5_check60 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches60,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node59 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected59 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected59 ((1 : Int),(1 : Int)) hp5_5_branches59 hp5_5_evidence59 hp5_5_check59 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches59,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node58 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected58 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected58 ((3 : Int),(2 : Int)) hp5_5_branches58 hp5_5_evidence58 hp5_5_check58 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches58,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node57 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected57 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected57 ((3 : Int),(2 : Int)) hp5_5_branches57 hp5_5_evidence57 hp5_5_check57 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches57,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node56 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected56 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected56 ((3 : Int),(1 : Int)) hp5_5_branches56 hp5_5_evidence56 hp5_5_check56 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches56,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node57 T childKnown
  · exact hp5_5_node58 T childKnown
theorem hp5_5_node55 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected55 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected55 ((1 : Int),(1 : Int)) hp5_5_branches55 hp5_5_evidence55 hp5_5_check55 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches55,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node56 T childKnown
theorem hp5_5_node54 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected54 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected54 ((0 : Int),(1 : Int)) hp5_5_branches54 hp5_5_evidence54 hp5_5_check54 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches54,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node55 T childKnown
  · exact hp5_5_node59 T childKnown
  · exact hp5_5_node60 T childKnown
  · exact hp5_5_node61 T childKnown
theorem hp5_5_node53 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected53 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected53 ((2 : Int),(1 : Int)) hp5_5_branches53 hp5_5_evidence53 hp5_5_check53 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches53,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node52 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected52 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected52 ((2 : Int),(0 : Int)) hp5_5_branches52 hp5_5_evidence52 hp5_5_check52 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches52,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node53 T childKnown
theorem hp5_5_node51 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected51 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected51 ((0 : Int),(1 : Int)) hp5_5_branches51 hp5_5_evidence51 hp5_5_check51 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches51,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node52 T childKnown
theorem hp5_5_node50 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected50 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected50 ((3 : Int),(2 : Int)) hp5_5_branches50 hp5_5_evidence50 hp5_5_check50 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches50,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node49 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected49 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected49 ((3 : Int),(2 : Int)) hp5_5_branches49 hp5_5_evidence49 hp5_5_check49 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches49,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node48 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected48 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected48 ((2 : Int),(2 : Int)) hp5_5_branches48 hp5_5_evidence48 hp5_5_check48 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches48,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node49 T childKnown
  · exact hp5_5_node50 T childKnown
theorem hp5_5_node47 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected47 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected47 ((2 : Int),(0 : Int)) hp5_5_branches47 hp5_5_evidence47 hp5_5_check47 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches47,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node48 T childKnown
theorem hp5_5_node46 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected46 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected46 ((0 : Int),(1 : Int)) hp5_5_branches46 hp5_5_evidence46 hp5_5_check46 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches46,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node47 T childKnown
theorem hp5_5_node45 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected45 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected45 ((0 : Int),(1 : Int)) hp5_5_branches45 hp5_5_evidence45 hp5_5_check45 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches45,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node44 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected44 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected44 ((0 : Int),(1 : Int)) hp5_5_branches44 hp5_5_evidence44 hp5_5_check44 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches44,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node43 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected43 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected43 ((0 : Int),(1 : Int)) hp5_5_branches43 hp5_5_evidence43 hp5_5_check43 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches43,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node42 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected42 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected42 ((2 : Int),(1 : Int)) hp5_5_branches42 hp5_5_evidence42 hp5_5_check42 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches42,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node41 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected41 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected41 ((2 : Int),(1 : Int)) hp5_5_branches41 hp5_5_evidence41 hp5_5_check41 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches41,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node40 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected40 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected40 ((3 : Int),(1 : Int)) hp5_5_branches40 hp5_5_evidence40 hp5_5_check40 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches40,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node39 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected39 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected39 ((3 : Int),(0 : Int)) hp5_5_branches39 hp5_5_evidence39 hp5_5_check39 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches39,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node40 T childKnown
theorem hp5_5_node38 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected38 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected38 ((3 : Int),(2 : Int)) hp5_5_branches38 hp5_5_evidence38 hp5_5_check38 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches38,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node37 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected37 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected37 ((3 : Int),(0 : Int)) hp5_5_branches37 hp5_5_evidence37 hp5_5_check37 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches37,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node38 T childKnown
theorem hp5_5_node36 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected36 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected36 ((2 : Int),(0 : Int)) hp5_5_branches36 hp5_5_evidence36 hp5_5_check36 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches36,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node37 T childKnown
  · exact hp5_5_node39 T childKnown
  · exact hp5_5_node41 T childKnown
  · exact hp5_5_node42 T childKnown
theorem hp5_5_node35 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected35 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected35 ((2 : Int),(1 : Int)) hp5_5_branches35 hp5_5_evidence35 hp5_5_check35 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches35,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node34 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected34 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected34 ((2 : Int),(1 : Int)) hp5_5_branches34 hp5_5_evidence34 hp5_5_check34 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches34,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node33 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected33 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected33 ((3 : Int),(1 : Int)) hp5_5_branches33 hp5_5_evidence33 hp5_5_check33 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches33,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node32 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected32 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected32 ((3 : Int),(0 : Int)) hp5_5_branches32 hp5_5_evidence32 hp5_5_check32 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches32,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node33 T childKnown
theorem hp5_5_node31 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected31 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected31 ((3 : Int),(2 : Int)) hp5_5_branches31 hp5_5_evidence31 hp5_5_check31 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches31,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node30 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected30 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected30 ((3 : Int),(0 : Int)) hp5_5_branches30 hp5_5_evidence30 hp5_5_check30 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches30,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node31 T childKnown
theorem hp5_5_node29 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected29 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected29 ((2 : Int),(0 : Int)) hp5_5_branches29 hp5_5_evidence29 hp5_5_check29 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches29,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node30 T childKnown
  · exact hp5_5_node32 T childKnown
  · exact hp5_5_node34 T childKnown
  · exact hp5_5_node35 T childKnown
theorem hp5_5_node28 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected28 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected28 ((3 : Int),(1 : Int)) hp5_5_branches28 hp5_5_evidence28 hp5_5_check28 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches28,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node27 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected27 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected27 ((2 : Int),(1 : Int)) hp5_5_branches27 hp5_5_evidence27 hp5_5_check27 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches27,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node28 T childKnown
theorem hp5_5_node26 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected26 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected26 ((4 : Int),(2 : Int)) hp5_5_branches26 hp5_5_evidence26 hp5_5_check26 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches26,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node25 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected25 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected25 ((4 : Int),(2 : Int)) hp5_5_branches25 hp5_5_evidence25 hp5_5_check25 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches25,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node24 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected24 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected24 ((4 : Int),(1 : Int)) hp5_5_branches24 hp5_5_evidence24 hp5_5_check24 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches24,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node25 T childKnown
  · exact hp5_5_node26 T childKnown
theorem hp5_5_node23 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected23 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected23 ((2 : Int),(1 : Int)) hp5_5_branches23 hp5_5_evidence23 hp5_5_check23 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches23,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node24 T childKnown
theorem hp5_5_node22 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected22 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected22 ((3 : Int),(1 : Int)) hp5_5_branches22 hp5_5_evidence22 hp5_5_check22 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches22,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node21 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected21 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected21 ((3 : Int),(0 : Int)) hp5_5_branches21 hp5_5_evidence21 hp5_5_check21 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches21,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node22 T childKnown
theorem hp5_5_node20 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected20 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected20 ((4 : Int),(2 : Int)) hp5_5_branches20 hp5_5_evidence20 hp5_5_check20 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches20,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node19 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected19 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected19 ((4 : Int),(2 : Int)) hp5_5_branches19 hp5_5_evidence19 hp5_5_check19 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches19,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node18 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected18 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected18 ((3 : Int),(2 : Int)) hp5_5_branches18 hp5_5_evidence18 hp5_5_check18 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches18,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node19 T childKnown
  · exact hp5_5_node20 T childKnown
theorem hp5_5_node17 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected17 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected17 ((3 : Int),(0 : Int)) hp5_5_branches17 hp5_5_evidence17 hp5_5_check17 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches17,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node18 T childKnown
theorem hp5_5_node16 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected16 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected16 ((2 : Int),(0 : Int)) hp5_5_branches16 hp5_5_evidence16 hp5_5_check16 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches16,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node17 T childKnown
  · exact hp5_5_node21 T childKnown
  · exact hp5_5_node23 T childKnown
  · exact hp5_5_node27 T childKnown
theorem hp5_5_node15 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected15 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected15 ((3 : Int),(1 : Int)) hp5_5_branches15 hp5_5_evidence15 hp5_5_check15 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches15,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node14 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected14 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected14 ((2 : Int),(1 : Int)) hp5_5_branches14 hp5_5_evidence14 hp5_5_check14 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches14,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node15 T childKnown
theorem hp5_5_node13 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected13 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected13 ((4 : Int),(2 : Int)) hp5_5_branches13 hp5_5_evidence13 hp5_5_check13 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches13,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node12 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected12 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected12 ((4 : Int),(2 : Int)) hp5_5_branches12 hp5_5_evidence12 hp5_5_check12 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches12,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node11 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected11 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected11 ((4 : Int),(1 : Int)) hp5_5_branches11 hp5_5_evidence11 hp5_5_check11 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches11,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node12 T childKnown
  · exact hp5_5_node13 T childKnown
theorem hp5_5_node10 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected10 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected10 ((2 : Int),(1 : Int)) hp5_5_branches10 hp5_5_evidence10 hp5_5_check10 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches10,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node11 T childKnown
theorem hp5_5_node9 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected9 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected9 ((3 : Int),(1 : Int)) hp5_5_branches9 hp5_5_evidence9 hp5_5_check9 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches9,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node8 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected8 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected8 ((3 : Int),(0 : Int)) hp5_5_branches8 hp5_5_evidence8 hp5_5_check8 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches8,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node9 T childKnown
theorem hp5_5_node7 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected7 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected7 ((4 : Int),(2 : Int)) hp5_5_branches7 hp5_5_evidence7 hp5_5_check7 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches7,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node6 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected6 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected6 ((4 : Int),(2 : Int)) hp5_5_branches6 hp5_5_evidence6 hp5_5_check6 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches6,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp5_5_node5 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected5 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected5 ((3 : Int),(2 : Int)) hp5_5_branches5 hp5_5_evidence5 hp5_5_check5 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches5,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp5_5_node6 T childKnown
  · exact hp5_5_node7 T childKnown
theorem hp5_5_node4 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected4 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected4 ((3 : Int),(0 : Int)) hp5_5_branches4 hp5_5_evidence4 hp5_5_check4 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches4,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp5_5_node5 T childKnown
theorem hp5_5_node3 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected3 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected3 ((2 : Int),(0 : Int)) hp5_5_branches3 hp5_5_evidence3 hp5_5_check3 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches3,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node4 T childKnown
  · exact hp5_5_node8 T childKnown
  · exact hp5_5_node10 T childKnown
  · exact hp5_5_node14 T childKnown
theorem hp5_5_node2 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected2 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected2 ((0 : Int),(2 : Int)) hp5_5_branches2 hp5_5_evidence2 hp5_5_check2 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches2,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp5_5_node3 T childKnown
  · exact hp5_5_node16 T childKnown
  · exact hp5_5_node29 T childKnown
  · exact hp5_5_node36 T childKnown
theorem hp5_5_node1 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected1 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected1 ((1 : Int),(0 : Int)) hp5_5_branches1 hp5_5_evidence1 hp5_5_check1 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches1,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node2 T childKnown
  · exact hp5_5_node43 T childKnown
  · exact hp5_5_node44 T childKnown
  · exact hp5_5_node45 T childKnown
  · exact hp5_5_node46 T childKnown
  · exact hp5_5_node51 T childKnown
  · exact hp5_5_node54 T childKnown
  · exact hp5_5_node62 T childKnown
theorem hp5_5_node0 (T : Tiling (5 : Int) (5 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp5_5_selected0 → T.world s) : False := by
  apply replay_step (5 : Int) (5 : Int) (by decide) (by decide) T hp5_5_selected0 ((0 : Int),(0 : Int)) hp5_5_branches0 hp5_5_evidence0 hp5_5_check0 ?_ known
  intro t member childKnown
  simp only [hp5_5_branches0,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp5_5_node1 T childKnown
  · exact hp5_5_node81 T childKnown
  · exact hp5_5_node104 T childKnown
  · exact hp5_5_node149 T childKnown
  · exact hp5_5_node172 T childKnown
  · exact hp5_5_node188 T childKnown
  · exact hp5_5_node204 T childKnown
  · exact hp5_5_node207 T childKnown
  · exact hp5_5_node246 T childKnown
  · exact hp5_5_node269 T childKnown
  · exact hp5_5_node308 T childKnown
  · exact hp5_5_node331 T childKnown
  · exact hp5_5_node406 T childKnown
  · exact hp5_5_node429 T childKnown
  · exact hp5_5_node504 T childKnown
  · exact hp5_5_node527 T childKnown
  · exact hp5_5_node529 T childKnown
  · exact hp5_5_node536 T childKnown
  · exact hp5_5_node538 T childKnown
  · exact hp5_5_node848 T childKnown

theorem hp5_5_no_half_plane : ¬Tiles (5 : Int) (5 : Int) 1 0 HalfPlane := by
  rintro ⟨T⟩
  exact hp5_5_node0 T (by simp [hp5_5_selected0])
#print axioms hp5_5_no_half_plane

end THalfPlaneFinite

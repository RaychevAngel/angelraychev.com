import CornerCertificateAffineGammaGeometry

set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace CornerCertificate
open CrossUnits

section AffineGamma
variable (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (copies : ∀ t, world t → Copy a 1 1 0 t)
    (separate : DisjointWorld world) (cover : CoversWindow world h)
    (ceiling : SelectedBelow world h)

include ha copies separate cover ceiling in
theorem affine_gamma_node180 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known180 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known180 a) ((1 : Int),(2 : Int)) (affine_gamma_branches180 a) copies separate cover ceiling
    (affine_gamma_nonnegative180 a ha) (affine_gamma_window180 a ha world h B state)
    (affine_gamma_empty180 a ha) (affine_gamma_complete180 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches180,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches180,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node179 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known179 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known179 a) ((1 : Int),(2 : Int)) (affine_gamma_branches179 a) copies separate cover ceiling
    (affine_gamma_nonnegative179 a ha) (affine_gamma_window179 a ha world h B state)
    (affine_gamma_empty179 a ha) (affine_gamma_complete179 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches179,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches179,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node178 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known178 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known178 a) ((2 : Int),(0 : Int)) (affine_gamma_branches178 a) copies separate cover ceiling
    (affine_gamma_nonnegative178 a ha) (affine_gamma_window178 a ha world h B state)
    (affine_gamma_empty178 a ha) (affine_gamma_complete178 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches178,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known178,affine_gamma_known179,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known178,affine_gamma_known180,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches178,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node179 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node180 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node177 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known177 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known177 a) ((1 : Int),(2 : Int)) (affine_gamma_branches177 a) copies separate cover ceiling
    (affine_gamma_nonnegative177 a ha) (affine_gamma_window177 a ha world h B state)
    (affine_gamma_empty177 a ha) (affine_gamma_complete177 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches177,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches177,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node176 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known176 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known176 a) ((1 : Int),(2 : Int)) (affine_gamma_branches176 a) copies separate cover ceiling
    (affine_gamma_nonnegative176 a ha) (affine_gamma_window176 a ha world h B state)
    (affine_gamma_empty176 a ha) (affine_gamma_complete176 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches176,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches176,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node175 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known175 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known175 a) ((2 : Int),(0 : Int)) (affine_gamma_branches175 a) copies separate cover ceiling
    (affine_gamma_nonnegative175 a ha) (affine_gamma_window175 a ha world h B state)
    (affine_gamma_empty175 a ha) (affine_gamma_complete175 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches175,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known175,affine_gamma_known176,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known175,affine_gamma_known177,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches175,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node176 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node177 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node174 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known174 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known174 a) ((2 : Int),(2 : Int)) (affine_gamma_branches174 a) copies separate cover ceiling
    (affine_gamma_nonnegative174 a ha) (affine_gamma_window174 a ha world h B state)
    (affine_gamma_empty174 a ha) (affine_gamma_complete174 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches174,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches174,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node173 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known173 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known173 a) ((2 : Int),(2 : Int)) (affine_gamma_branches173 a) copies separate cover ceiling
    (affine_gamma_nonnegative173 a ha) (affine_gamma_window173 a ha world h B state)
    (affine_gamma_empty173 a ha) (affine_gamma_complete173 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches173,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches173,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node172 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known172 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known172 a) ((1 : Int),(2 : Int)) (affine_gamma_branches172 a) copies separate cover ceiling
    (affine_gamma_nonnegative172 a ha) (affine_gamma_window172 a ha world h B state)
    (affine_gamma_empty172 a ha) (affine_gamma_complete172 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches172,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known172,affine_gamma_known173,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known172,affine_gamma_known174,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches172,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node173 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node174 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node171 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known171 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known171 a) ((2 : Int),(2 : Int)) (affine_gamma_branches171 a) copies separate cover ceiling
    (affine_gamma_nonnegative171 a ha) (affine_gamma_window171 a ha world h B state)
    (affine_gamma_empty171 a ha) (affine_gamma_complete171 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches171,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches171,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node170 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known170 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known170 a) ((2 : Int),(2 : Int)) (affine_gamma_branches170 a) copies separate cover ceiling
    (affine_gamma_nonnegative170 a ha) (affine_gamma_window170 a ha world h B state)
    (affine_gamma_empty170 a ha) (affine_gamma_complete170 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches170,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches170,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node169 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known169 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known169 a) ((1 : Int),(2 : Int)) (affine_gamma_branches169 a) copies separate cover ceiling
    (affine_gamma_nonnegative169 a ha) (affine_gamma_window169 a ha world h B state)
    (affine_gamma_empty169 a ha) (affine_gamma_complete169 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches169,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known169,affine_gamma_known170,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known169,affine_gamma_known171,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches169,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node170 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node171 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node168 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known168 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known168 a) ((2 : Int),(0 : Int)) (affine_gamma_branches168 a) copies separate cover ceiling
    (affine_gamma_nonnegative168 a ha) (affine_gamma_window168 a ha world h B state)
    (affine_gamma_empty168 a ha) (affine_gamma_complete168 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches168,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known168,affine_gamma_known169,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known168,affine_gamma_known172,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches168,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node169 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node172 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node167 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known167 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known167 a) ((0 : Int),(2 : Int)) (affine_gamma_branches167 a) copies separate cover ceiling
    (affine_gamma_nonnegative167 a ha) (affine_gamma_window167 a ha world h B state)
    (affine_gamma_empty167 a ha) (affine_gamma_complete167 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches167,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known167,affine_gamma_known168,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known167,affine_gamma_known175,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known167,affine_gamma_known178,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches167,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_gamma_node168 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node175 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node178 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node166 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known166 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known166 a) ((2 : Int),(0 : Int)) (affine_gamma_branches166 a) copies separate cover ceiling
    (affine_gamma_nonnegative166 a ha) (affine_gamma_window166 a ha world h B state)
    (affine_gamma_empty166 a ha) (affine_gamma_complete166 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches166,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches166,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node165 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known165 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known165 a) ((2 : Int),(0 : Int)) (affine_gamma_branches165 a) copies separate cover ceiling
    (affine_gamma_nonnegative165 a ha) (affine_gamma_window165 a ha world h B state)
    (affine_gamma_empty165 a ha) (affine_gamma_complete165 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches165,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches165,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node164 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known164 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known164 a) ((2 : Int),(0 : Int)) (affine_gamma_branches164 a) copies separate cover ceiling
    (affine_gamma_nonnegative164 a ha) (affine_gamma_window164 a ha world h B state)
    (affine_gamma_empty164 a ha) (affine_gamma_complete164 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches164,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches164,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node163 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known163 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known163 a) ((2 : Int),(0 : Int)) (affine_gamma_branches163 a) copies separate cover ceiling
    (affine_gamma_nonnegative163 a ha) (affine_gamma_window163 a ha world h B state)
    (affine_gamma_empty163 a ha) (affine_gamma_complete163 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches163,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches163,List.mem_cons,List.not_mem_nil,or_false] at member
include ha in
theorem affine_gamma_node162 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known162 a)) B) : Transition world h .gamma B := by
  exact affine_gamma_leaf162 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gamma_node161 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known161 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known161 a) ((0 : Int),(2 : Int)) (affine_gamma_branches161 a) copies separate cover ceiling
    (affine_gamma_nonnegative161 a ha) (affine_gamma_window161 a ha world h B state)
    (affine_gamma_empty161 a ha) (affine_gamma_complete161 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches161,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known161,affine_gamma_known162,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known161,affine_gamma_known163,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known161,affine_gamma_known164,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known161,affine_gamma_known165,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known161,affine_gamma_known166,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches161,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · exact affine_gamma_node162 a ha world h nextB nextState
    · exact affine_gamma_node163 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node164 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node165 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node166 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node160 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known160 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known160 a) ((2 : Int),(2 : Int)) (affine_gamma_branches160 a) copies separate cover ceiling
    (affine_gamma_nonnegative160 a ha) (affine_gamma_window160 a ha world h B state)
    (affine_gamma_empty160 a ha) (affine_gamma_complete160 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches160,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches160,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node159 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known159 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known159 a) ((2 : Int),(2 : Int)) (affine_gamma_branches159 a) copies separate cover ceiling
    (affine_gamma_nonnegative159 a ha) (affine_gamma_window159 a ha world h B state)
    (affine_gamma_empty159 a ha) (affine_gamma_complete159 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches159,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches159,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node158 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known158 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known158 a) ((2 : Int),(2 : Int)) (affine_gamma_branches158 a) copies separate cover ceiling
    (affine_gamma_nonnegative158 a ha) (affine_gamma_window158 a ha world h B state)
    (affine_gamma_empty158 a ha) (affine_gamma_complete158 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches158,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches158,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node157 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known157 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known157 a) ((1 : Int),(5 : Int)) (affine_gamma_branches157 a) copies separate cover ceiling
    (affine_gamma_nonnegative157 a ha) (affine_gamma_window157 a ha world h B state)
    (affine_gamma_empty157 a ha) (affine_gamma_complete157 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches157,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches157,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node156 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known156 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known156 a) ((1 : Int),(5 : Int)) (affine_gamma_branches156 a) copies separate cover ceiling
    (affine_gamma_nonnegative156 a ha) (affine_gamma_window156 a ha world h B state)
    (affine_gamma_empty156 a ha) (affine_gamma_complete156 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches156,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches156,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node155 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known155 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known155 a) ((3 : Int),(2 : Int)) (affine_gamma_branches155 a) copies separate cover ceiling
    (affine_gamma_nonnegative155 a ha) (affine_gamma_window155 a ha world h B state)
    (affine_gamma_empty155 a ha) (affine_gamma_complete155 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches155,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known155,affine_gamma_known156,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known155,affine_gamma_known157,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches155,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node156 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node157 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node154 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known154 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known154 a) ((1 : Int),(5 : Int)) (affine_gamma_branches154 a) copies separate cover ceiling
    (affine_gamma_nonnegative154 a ha) (affine_gamma_window154 a ha world h B state)
    (affine_gamma_empty154 a ha) (affine_gamma_complete154 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches154,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches154,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node153 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known153 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known153 a) ((1 : Int),(5 : Int)) (affine_gamma_branches153 a) copies separate cover ceiling
    (affine_gamma_nonnegative153 a ha) (affine_gamma_window153 a ha world h B state)
    (affine_gamma_empty153 a ha) (affine_gamma_complete153 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches153,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches153,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node152 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known152 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known152 a) ((3 : Int),(2 : Int)) (affine_gamma_branches152 a) copies separate cover ceiling
    (affine_gamma_nonnegative152 a ha) (affine_gamma_window152 a ha world h B state)
    (affine_gamma_empty152 a ha) (affine_gamma_complete152 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches152,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known152,affine_gamma_known153,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known152,affine_gamma_known154,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches152,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node153 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node154 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node151 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known151 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known151 a) ((1 : Int),(4 : Int)) (affine_gamma_branches151 a) copies separate cover ceiling
    (affine_gamma_nonnegative151 a ha) (affine_gamma_window151 a ha world h B state)
    (affine_gamma_empty151 a ha) (affine_gamma_complete151 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches151,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known151,affine_gamma_known152,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known151,affine_gamma_known155,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches151,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node152 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node155 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_gamma_node150 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known150 a)) B) : Transition world h .gamma B := by
  exact affine_gamma_leaf150 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gamma_node149 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known149 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known149 a) ((1 : Int),(3 : Int)) (affine_gamma_branches149 a) copies separate cover ceiling
    (affine_gamma_nonnegative149 a ha) (affine_gamma_window149 a ha world h B state)
    (affine_gamma_empty149 a ha) (affine_gamma_complete149 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches149,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known149,affine_gamma_known150,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known149,affine_gamma_known151,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known149,affine_gamma_known158,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known149,affine_gamma_known159,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known149,affine_gamma_known160,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches149,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · exact affine_gamma_node150 a ha world h nextB nextState
    · exact affine_gamma_node151 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node158 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node159 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node160 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node148 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known148 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known148 a) ((1 : Int),(4 : Int)) (affine_gamma_branches148 a) copies separate cover ceiling
    (affine_gamma_nonnegative148 a ha) (affine_gamma_window148 a ha world h B state)
    (affine_gamma_empty148 a ha) (affine_gamma_complete148 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches148,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches148,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node147 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known147 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known147 a) ((2 : Int),(2 : Int)) (affine_gamma_branches147 a) copies separate cover ceiling
    (affine_gamma_nonnegative147 a ha) (affine_gamma_window147 a ha world h B state)
    (affine_gamma_empty147 a ha) (affine_gamma_complete147 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches147,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known147,affine_gamma_known148,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches147,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_gamma_node148 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node146 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known146 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known146 a) ((2 : Int),(2 : Int)) (affine_gamma_branches146 a) copies separate cover ceiling
    (affine_gamma_nonnegative146 a ha) (affine_gamma_window146 a ha world h B state)
    (affine_gamma_empty146 a ha) (affine_gamma_complete146 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches146,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches146,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node145 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known145 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known145 a) ((1 : Int),(4 : Int)) (affine_gamma_branches145 a) copies separate cover ceiling
    (affine_gamma_nonnegative145 a ha) (affine_gamma_window145 a ha world h B state)
    (affine_gamma_empty145 a ha) (affine_gamma_complete145 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches145,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches145,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node144 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known144 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known144 a) ((2 : Int),(2 : Int)) (affine_gamma_branches144 a) copies separate cover ceiling
    (affine_gamma_nonnegative144 a ha) (affine_gamma_window144 a ha world h B state)
    (affine_gamma_empty144 a ha) (affine_gamma_complete144 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches144,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known144,affine_gamma_known145,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches144,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_gamma_node145 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node143 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known143 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known143 a) ((1 : Int),(5 : Int)) (affine_gamma_branches143 a) copies separate cover ceiling
    (affine_gamma_nonnegative143 a ha) (affine_gamma_window143 a ha world h B state)
    (affine_gamma_empty143 a ha) (affine_gamma_complete143 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches143,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches143,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node142 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known142 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known142 a) ((1 : Int),(5 : Int)) (affine_gamma_branches142 a) copies separate cover ceiling
    (affine_gamma_nonnegative142 a ha) (affine_gamma_window142 a ha world h B state)
    (affine_gamma_empty142 a ha) (affine_gamma_complete142 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches142,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches142,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node141 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known141 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known141 a) ((3 : Int),(2 : Int)) (affine_gamma_branches141 a) copies separate cover ceiling
    (affine_gamma_nonnegative141 a ha) (affine_gamma_window141 a ha world h B state)
    (affine_gamma_empty141 a ha) (affine_gamma_complete141 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches141,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known141,affine_gamma_known142,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known141,affine_gamma_known143,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches141,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node142 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node143 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node140 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known140 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known140 a) ((1 : Int),(5 : Int)) (affine_gamma_branches140 a) copies separate cover ceiling
    (affine_gamma_nonnegative140 a ha) (affine_gamma_window140 a ha world h B state)
    (affine_gamma_empty140 a ha) (affine_gamma_complete140 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches140,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches140,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node139 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known139 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known139 a) ((1 : Int),(5 : Int)) (affine_gamma_branches139 a) copies separate cover ceiling
    (affine_gamma_nonnegative139 a ha) (affine_gamma_window139 a ha world h B state)
    (affine_gamma_empty139 a ha) (affine_gamma_complete139 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches139,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches139,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node138 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known138 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known138 a) ((3 : Int),(2 : Int)) (affine_gamma_branches138 a) copies separate cover ceiling
    (affine_gamma_nonnegative138 a ha) (affine_gamma_window138 a ha world h B state)
    (affine_gamma_empty138 a ha) (affine_gamma_complete138 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches138,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known138,affine_gamma_known139,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known138,affine_gamma_known140,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches138,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node139 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node140 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node137 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known137 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known137 a) ((1 : Int),(4 : Int)) (affine_gamma_branches137 a) copies separate cover ceiling
    (affine_gamma_nonnegative137 a ha) (affine_gamma_window137 a ha world h B state)
    (affine_gamma_empty137 a ha) (affine_gamma_complete137 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches137,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known137,affine_gamma_known138,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known137,affine_gamma_known141,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches137,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node138 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node141 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_gamma_node136 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known136 a)) B) : Transition world h .gamma B := by
  exact affine_gamma_leaf136 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gamma_node135 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known135 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known135 a) ((1 : Int),(3 : Int)) (affine_gamma_branches135 a) copies separate cover ceiling
    (affine_gamma_nonnegative135 a ha) (affine_gamma_window135 a ha world h B state)
    (affine_gamma_empty135 a ha) (affine_gamma_complete135 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches135,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known135,affine_gamma_known136,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known135,affine_gamma_known137,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known135,affine_gamma_known144,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known135,affine_gamma_known146,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known135,affine_gamma_known147,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches135,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · exact affine_gamma_node136 a ha world h nextB nextState
    · exact affine_gamma_node137 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node144 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node146 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node147 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node134 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known134 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known134 a) ((2 : Int),(0 : Int)) (affine_gamma_branches134 a) copies separate cover ceiling
    (affine_gamma_nonnegative134 a ha) (affine_gamma_window134 a ha world h B state)
    (affine_gamma_empty134 a ha) (affine_gamma_complete134 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches134,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known134,affine_gamma_known135,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known134,affine_gamma_known149,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches134,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node135 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node149 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_gamma_node133 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known133 a)) B) : Transition world h .gamma B := by
  exact affine_gamma_leaf133 a ha world h B state
include ha in
theorem affine_gamma_node132 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known132 a)) B) : Transition world h .gamma B := by
  exact affine_gamma_leaf132 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gamma_node131 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known131 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known131 a) ((0 : Int),(2 : Int)) (affine_gamma_branches131 a) copies separate cover ceiling
    (affine_gamma_nonnegative131 a ha) (affine_gamma_window131 a ha world h B state)
    (affine_gamma_empty131 a ha) (affine_gamma_complete131 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches131,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known131,affine_gamma_known132,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known131,affine_gamma_known133,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known131,affine_gamma_known134,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches131,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_gamma_node132 a ha world h nextB nextState
    · exact affine_gamma_node133 a ha world h nextB nextState
    · exact affine_gamma_node134 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node130 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known130 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known130 a) ((1 : Int),(2 : Int)) (affine_gamma_branches130 a) copies separate cover ceiling
    (affine_gamma_nonnegative130 a ha) (affine_gamma_window130 a ha world h B state)
    (affine_gamma_empty130 a ha) (affine_gamma_complete130 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches130,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches130,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node129 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known129 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known129 a) ((2 : Int),(0 : Int)) (affine_gamma_branches129 a) copies separate cover ceiling
    (affine_gamma_nonnegative129 a ha) (affine_gamma_window129 a ha world h B state)
    (affine_gamma_empty129 a ha) (affine_gamma_complete129 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches129,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known129,affine_gamma_known130,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches129,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_gamma_node130 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node128 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known128 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known128 a) ((2 : Int),(0 : Int)) (affine_gamma_branches128 a) copies separate cover ceiling
    (affine_gamma_nonnegative128 a ha) (affine_gamma_window128 a ha world h B state)
    (affine_gamma_empty128 a ha) (affine_gamma_complete128 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches128,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches128,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node127 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known127 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known127 a) ((1 : Int),(2 : Int)) (affine_gamma_branches127 a) copies separate cover ceiling
    (affine_gamma_nonnegative127 a ha) (affine_gamma_window127 a ha world h B state)
    (affine_gamma_empty127 a ha) (affine_gamma_complete127 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches127,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches127,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node126 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known126 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known126 a) ((2 : Int),(0 : Int)) (affine_gamma_branches126 a) copies separate cover ceiling
    (affine_gamma_nonnegative126 a ha) (affine_gamma_window126 a ha world h B state)
    (affine_gamma_empty126 a ha) (affine_gamma_complete126 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches126,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known126,affine_gamma_known127,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches126,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_gamma_node127 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node125 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known125 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known125 a) ((1 : Int),(3 : Int)) (affine_gamma_branches125 a) copies separate cover ceiling
    (affine_gamma_nonnegative125 a ha) (affine_gamma_window125 a ha world h B state)
    (affine_gamma_empty125 a ha) (affine_gamma_complete125 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches125,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches125,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node124 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known124 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known124 a) ((1 : Int),(3 : Int)) (affine_gamma_branches124 a) copies separate cover ceiling
    (affine_gamma_nonnegative124 a ha) (affine_gamma_window124 a ha world h B state)
    (affine_gamma_empty124 a ha) (affine_gamma_complete124 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches124,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches124,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node123 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known123 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known123 a) ((3 : Int),(0 : Int)) (affine_gamma_branches123 a) copies separate cover ceiling
    (affine_gamma_nonnegative123 a ha) (affine_gamma_window123 a ha world h B state)
    (affine_gamma_empty123 a ha) (affine_gamma_complete123 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches123,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known123,affine_gamma_known124,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known123,affine_gamma_known125,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches123,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node124 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node125 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node122 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known122 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known122 a) ((1 : Int),(3 : Int)) (affine_gamma_branches122 a) copies separate cover ceiling
    (affine_gamma_nonnegative122 a ha) (affine_gamma_window122 a ha world h B state)
    (affine_gamma_empty122 a ha) (affine_gamma_complete122 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches122,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches122,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node121 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known121 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known121 a) ((1 : Int),(3 : Int)) (affine_gamma_branches121 a) copies separate cover ceiling
    (affine_gamma_nonnegative121 a ha) (affine_gamma_window121 a ha world h B state)
    (affine_gamma_empty121 a ha) (affine_gamma_complete121 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches121,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches121,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node120 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known120 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known120 a) ((3 : Int),(0 : Int)) (affine_gamma_branches120 a) copies separate cover ceiling
    (affine_gamma_nonnegative120 a ha) (affine_gamma_window120 a ha world h B state)
    (affine_gamma_empty120 a ha) (affine_gamma_complete120 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches120,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known120,affine_gamma_known121,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known120,affine_gamma_known122,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches120,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node121 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node122 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node119 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known119 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known119 a) ((1 : Int),(2 : Int)) (affine_gamma_branches119 a) copies separate cover ceiling
    (affine_gamma_nonnegative119 a ha) (affine_gamma_window119 a ha world h B state)
    (affine_gamma_empty119 a ha) (affine_gamma_complete119 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches119,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known119,affine_gamma_known120,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known119,affine_gamma_known123,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches119,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node120 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node123 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node118 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known118 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known118 a) ((1 : Int),(2 : Int)) (affine_gamma_branches118 a) copies separate cover ceiling
    (affine_gamma_nonnegative118 a ha) (affine_gamma_window118 a ha world h B state)
    (affine_gamma_empty118 a ha) (affine_gamma_complete118 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches118,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches118,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node117 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known117 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known117 a) ((1 : Int),(1 : Int)) (affine_gamma_branches117 a) copies separate cover ceiling
    (affine_gamma_nonnegative117 a ha) (affine_gamma_window117 a ha world h B state)
    (affine_gamma_empty117 a ha) (affine_gamma_complete117 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches117,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known117,affine_gamma_known118,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known117,affine_gamma_known119,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known117,affine_gamma_known126,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known117,affine_gamma_known128,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known117,affine_gamma_known129,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches117,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · exact affine_gamma_node118 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node119 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node126 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node128 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node129 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node116 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known116 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known116 a) ((2 : Int),(2 : Int)) (affine_gamma_branches116 a) copies separate cover ceiling
    (affine_gamma_nonnegative116 a ha) (affine_gamma_window116 a ha world h B state)
    (affine_gamma_empty116 a ha) (affine_gamma_complete116 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches116,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches116,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node115 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known115 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known115 a) ((2 : Int),(2 : Int)) (affine_gamma_branches115 a) copies separate cover ceiling
    (affine_gamma_nonnegative115 a ha) (affine_gamma_window115 a ha world h B state)
    (affine_gamma_empty115 a ha) (affine_gamma_complete115 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches115,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches115,List.mem_cons,List.not_mem_nil,or_false] at member
include ha in
theorem affine_gamma_node114 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known114 a)) B) : Transition world h .gamma B := by
  exact affine_gamma_leaf114 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gamma_node113 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known113 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known113 a) ((4 : Int),(2 : Int)) (affine_gamma_branches113 a) copies separate cover ceiling
    (affine_gamma_nonnegative113 a ha) (affine_gamma_window113 a ha world h B state)
    (affine_gamma_empty113 a ha) (affine_gamma_complete113 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches113,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches113,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node112 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known112 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known112 a) ((4 : Int),(2 : Int)) (affine_gamma_branches112 a) copies separate cover ceiling
    (affine_gamma_nonnegative112 a ha) (affine_gamma_window112 a ha world h B state)
    (affine_gamma_empty112 a ha) (affine_gamma_complete112 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches112,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches112,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node111 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known111 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known111 a) ((3 : Int),(2 : Int)) (affine_gamma_branches111 a) copies separate cover ceiling
    (affine_gamma_nonnegative111 a ha) (affine_gamma_window111 a ha world h B state)
    (affine_gamma_empty111 a ha) (affine_gamma_complete111 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches111,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known111,affine_gamma_known112,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known111,affine_gamma_known113,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches111,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node112 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node113 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node110 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known110 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known110 a) ((4 : Int),(2 : Int)) (affine_gamma_branches110 a) copies separate cover ceiling
    (affine_gamma_nonnegative110 a ha) (affine_gamma_window110 a ha world h B state)
    (affine_gamma_empty110 a ha) (affine_gamma_complete110 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches110,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches110,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node109 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known109 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known109 a) ((4 : Int),(2 : Int)) (affine_gamma_branches109 a) copies separate cover ceiling
    (affine_gamma_nonnegative109 a ha) (affine_gamma_window109 a ha world h B state)
    (affine_gamma_empty109 a ha) (affine_gamma_complete109 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches109,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches109,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node108 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known108 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known108 a) ((3 : Int),(2 : Int)) (affine_gamma_branches108 a) copies separate cover ceiling
    (affine_gamma_nonnegative108 a ha) (affine_gamma_window108 a ha world h B state)
    (affine_gamma_empty108 a ha) (affine_gamma_complete108 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches108,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known108,affine_gamma_known109,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known108,affine_gamma_known110,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches108,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node109 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node110 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node107 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known107 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known107 a) ((1 : Int),(4 : Int)) (affine_gamma_branches107 a) copies separate cover ceiling
    (affine_gamma_nonnegative107 a ha) (affine_gamma_window107 a ha world h B state)
    (affine_gamma_empty107 a ha) (affine_gamma_complete107 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches107,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known107,affine_gamma_known108,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known107,affine_gamma_known111,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches107,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node108 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node111 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node106 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known106 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known106 a) ((2 : Int),(2 : Int)) (affine_gamma_branches106 a) copies separate cover ceiling
    (affine_gamma_nonnegative106 a ha) (affine_gamma_window106 a ha world h B state)
    (affine_gamma_empty106 a ha) (affine_gamma_complete106 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches106,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches106,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node105 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known105 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known105 a) ((2 : Int),(2 : Int)) (affine_gamma_branches105 a) copies separate cover ceiling
    (affine_gamma_nonnegative105 a ha) (affine_gamma_window105 a ha world h B state)
    (affine_gamma_empty105 a ha) (affine_gamma_complete105 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches105,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches105,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node104 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known104 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known104 a) ((3 : Int),(2 : Int)) (affine_gamma_branches104 a) copies separate cover ceiling
    (affine_gamma_nonnegative104 a ha) (affine_gamma_window104 a ha world h B state)
    (affine_gamma_empty104 a ha) (affine_gamma_complete104 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches104,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches104,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node103 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known103 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known103 a) ((3 : Int),(2 : Int)) (affine_gamma_branches103 a) copies separate cover ceiling
    (affine_gamma_nonnegative103 a ha) (affine_gamma_window103 a ha world h B state)
    (affine_gamma_empty103 a ha) (affine_gamma_complete103 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches103,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches103,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node102 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known102 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known102 a) ((2 : Int),(2 : Int)) (affine_gamma_branches102 a) copies separate cover ceiling
    (affine_gamma_nonnegative102 a ha) (affine_gamma_window102 a ha world h B state)
    (affine_gamma_empty102 a ha) (affine_gamma_complete102 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches102,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known102,affine_gamma_known103,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known102,affine_gamma_known104,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches102,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node103 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node104 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node101 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known101 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known101 a) ((1 : Int),(3 : Int)) (affine_gamma_branches101 a) copies separate cover ceiling
    (affine_gamma_nonnegative101 a ha) (affine_gamma_window101 a ha world h B state)
    (affine_gamma_empty101 a ha) (affine_gamma_complete101 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches101,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known101,affine_gamma_known102,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known101,affine_gamma_known105,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known101,affine_gamma_known106,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known101,affine_gamma_known107,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known101,affine_gamma_known114,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known101,affine_gamma_known115,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known101,affine_gamma_known116,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches101,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact affine_gamma_node102 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node105 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node106 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node107 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node114 a ha world h nextB nextState
    · exact affine_gamma_node115 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node116 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node100 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known100 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known100 a) ((2 : Int),(0 : Int)) (affine_gamma_branches100 a) copies separate cover ceiling
    (affine_gamma_nonnegative100 a ha) (affine_gamma_window100 a ha world h B state)
    (affine_gamma_empty100 a ha) (affine_gamma_complete100 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches100,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known100,affine_gamma_known101,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches100,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_gamma_node101 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_gamma_node099 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known099 a)) B) : Transition world h .gamma B := by
  exact affine_gamma_leaf099 a ha world h B state
include ha in
theorem affine_gamma_node098 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known098 a)) B) : Transition world h .gamma B := by
  exact affine_gamma_leaf098 a ha world h B state
include ha in
theorem affine_gamma_node097 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known097 a)) B) : Transition world h .gamma B := by
  exact affine_gamma_leaf097 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gamma_node096 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known096 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known096 a) ((4 : Int),(1 : Int)) (affine_gamma_branches096 a) copies separate cover ceiling
    (affine_gamma_nonnegative096 a ha) (affine_gamma_window096 a ha world h B state)
    (affine_gamma_empty096 a ha) (affine_gamma_complete096 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches096,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches096,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node095 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known095 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known095 a) ((4 : Int),(1 : Int)) (affine_gamma_branches095 a) copies separate cover ceiling
    (affine_gamma_nonnegative095 a ha) (affine_gamma_window095 a ha world h B state)
    (affine_gamma_empty095 a ha) (affine_gamma_complete095 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches095,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches095,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node094 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known094 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known094 a) ((3 : Int),(1 : Int)) (affine_gamma_branches094 a) copies separate cover ceiling
    (affine_gamma_nonnegative094 a ha) (affine_gamma_window094 a ha world h B state)
    (affine_gamma_empty094 a ha) (affine_gamma_complete094 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches094,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known094,affine_gamma_known095,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known094,affine_gamma_known096,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches094,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node095 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node096 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node093 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known093 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known093 a) ((4 : Int),(1 : Int)) (affine_gamma_branches093 a) copies separate cover ceiling
    (affine_gamma_nonnegative093 a ha) (affine_gamma_window093 a ha world h B state)
    (affine_gamma_empty093 a ha) (affine_gamma_complete093 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches093,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches093,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node092 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known092 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known092 a) ((4 : Int),(1 : Int)) (affine_gamma_branches092 a) copies separate cover ceiling
    (affine_gamma_nonnegative092 a ha) (affine_gamma_window092 a ha world h B state)
    (affine_gamma_empty092 a ha) (affine_gamma_complete092 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches092,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches092,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node091 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known091 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known091 a) ((3 : Int),(1 : Int)) (affine_gamma_branches091 a) copies separate cover ceiling
    (affine_gamma_nonnegative091 a ha) (affine_gamma_window091 a ha world h B state)
    (affine_gamma_empty091 a ha) (affine_gamma_complete091 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches091,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known091,affine_gamma_known092,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known091,affine_gamma_known093,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches091,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node092 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node093 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node090 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known090 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known090 a) ((1 : Int),(3 : Int)) (affine_gamma_branches090 a) copies separate cover ceiling
    (affine_gamma_nonnegative090 a ha) (affine_gamma_window090 a ha world h B state)
    (affine_gamma_empty090 a ha) (affine_gamma_complete090 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches090,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known090,affine_gamma_known091,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known090,affine_gamma_known094,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches090,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node091 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node094 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_gamma_node089 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known089 a)) B) : Transition world h .gamma B := by
  exact affine_gamma_leaf089 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gamma_node088 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known088 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known088 a) ((4 : Int),(3 : Int)) (affine_gamma_branches088 a) copies separate cover ceiling
    (affine_gamma_nonnegative088 a ha) (affine_gamma_window088 a ha world h B state)
    (affine_gamma_empty088 a ha) (affine_gamma_complete088 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches088,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches088,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node087 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known087 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known087 a) ((5 : Int),(1 : Int)) (affine_gamma_branches087 a) copies separate cover ceiling
    (affine_gamma_nonnegative087 a ha) (affine_gamma_window087 a ha world h B state)
    (affine_gamma_empty087 a ha) (affine_gamma_complete087 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches087,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known087,affine_gamma_known088,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches087,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_gamma_node088 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node086 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known086 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known086 a) ((5 : Int),(1 : Int)) (affine_gamma_branches086 a) copies separate cover ceiling
    (affine_gamma_nonnegative086 a ha) (affine_gamma_window086 a ha world h B state)
    (affine_gamma_empty086 a ha) (affine_gamma_complete086 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches086,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches086,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node085 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known085 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known085 a) ((4 : Int),(3 : Int)) (affine_gamma_branches085 a) copies separate cover ceiling
    (affine_gamma_nonnegative085 a ha) (affine_gamma_window085 a ha world h B state)
    (affine_gamma_empty085 a ha) (affine_gamma_complete085 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches085,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches085,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node084 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known084 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known084 a) ((5 : Int),(1 : Int)) (affine_gamma_branches084 a) copies separate cover ceiling
    (affine_gamma_nonnegative084 a ha) (affine_gamma_window084 a ha world h B state)
    (affine_gamma_empty084 a ha) (affine_gamma_complete084 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches084,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known084,affine_gamma_known085,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches084,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_gamma_node085 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node083 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known083 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known083 a) ((4 : Int),(4 : Int)) (affine_gamma_branches083 a) copies separate cover ceiling
    (affine_gamma_nonnegative083 a ha) (affine_gamma_window083 a ha world h B state)
    (affine_gamma_empty083 a ha) (affine_gamma_complete083 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches083,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches083,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node082 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known082 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known082 a) ((4 : Int),(4 : Int)) (affine_gamma_branches082 a) copies separate cover ceiling
    (affine_gamma_nonnegative082 a ha) (affine_gamma_window082 a ha world h B state)
    (affine_gamma_empty082 a ha) (affine_gamma_complete082 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches082,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches082,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node081 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known081 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known081 a) ((6 : Int),(1 : Int)) (affine_gamma_branches081 a) copies separate cover ceiling
    (affine_gamma_nonnegative081 a ha) (affine_gamma_window081 a ha world h B state)
    (affine_gamma_empty081 a ha) (affine_gamma_complete081 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches081,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known081,affine_gamma_known082,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known081,affine_gamma_known083,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches081,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node082 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node083 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node080 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known080 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known080 a) ((4 : Int),(4 : Int)) (affine_gamma_branches080 a) copies separate cover ceiling
    (affine_gamma_nonnegative080 a ha) (affine_gamma_window080 a ha world h B state)
    (affine_gamma_empty080 a ha) (affine_gamma_complete080 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches080,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches080,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node079 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known079 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known079 a) ((4 : Int),(4 : Int)) (affine_gamma_branches079 a) copies separate cover ceiling
    (affine_gamma_nonnegative079 a ha) (affine_gamma_window079 a ha world h B state)
    (affine_gamma_empty079 a ha) (affine_gamma_complete079 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches079,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches079,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node078 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known078 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known078 a) ((6 : Int),(1 : Int)) (affine_gamma_branches078 a) copies separate cover ceiling
    (affine_gamma_nonnegative078 a ha) (affine_gamma_window078 a ha world h B state)
    (affine_gamma_empty078 a ha) (affine_gamma_complete078 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches078,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known078,affine_gamma_known079,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known078,affine_gamma_known080,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches078,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node079 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node080 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node077 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known077 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known077 a) ((4 : Int),(3 : Int)) (affine_gamma_branches077 a) copies separate cover ceiling
    (affine_gamma_nonnegative077 a ha) (affine_gamma_window077 a ha world h B state)
    (affine_gamma_empty077 a ha) (affine_gamma_complete077 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches077,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known077,affine_gamma_known078,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known077,affine_gamma_known081,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches077,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node078 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node081 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_gamma_node076 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known076 a)) B) : Transition world h .gamma B := by
  exact affine_gamma_leaf076 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gamma_node075 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known075 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known075 a) ((4 : Int),(2 : Int)) (affine_gamma_branches075 a) copies separate cover ceiling
    (affine_gamma_nonnegative075 a ha) (affine_gamma_window075 a ha world h B state)
    (affine_gamma_empty075 a ha) (affine_gamma_complete075 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches075,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known075,affine_gamma_known076,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known075,affine_gamma_known077,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known075,affine_gamma_known084,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known075,affine_gamma_known086,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known075,affine_gamma_known087,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches075,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · exact affine_gamma_node076 a ha world h nextB nextState
    · exact affine_gamma_node077 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node084 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node086 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node087 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_gamma_node074 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known074 a)) B) : Transition world h .gamma B := by
  exact affine_gamma_leaf074 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gamma_node073 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known073 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known073 a) ((3 : Int),(1 : Int)) (affine_gamma_branches073 a) copies separate cover ceiling
    (affine_gamma_nonnegative073 a ha) (affine_gamma_window073 a ha world h B state)
    (affine_gamma_empty073 a ha) (affine_gamma_complete073 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches073,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known073,affine_gamma_known074,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known073,affine_gamma_known075,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches073,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node074 a ha world h nextB nextState
    · exact affine_gamma_node075 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node072 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known072 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known072 a) ((4 : Int),(3 : Int)) (affine_gamma_branches072 a) copies separate cover ceiling
    (affine_gamma_nonnegative072 a ha) (affine_gamma_window072 a ha world h B state)
    (affine_gamma_empty072 a ha) (affine_gamma_complete072 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches072,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches072,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node071 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known071 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known071 a) ((5 : Int),(1 : Int)) (affine_gamma_branches071 a) copies separate cover ceiling
    (affine_gamma_nonnegative071 a ha) (affine_gamma_window071 a ha world h B state)
    (affine_gamma_empty071 a ha) (affine_gamma_complete071 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches071,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known071,affine_gamma_known072,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches071,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_gamma_node072 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node070 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known070 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known070 a) ((5 : Int),(1 : Int)) (affine_gamma_branches070 a) copies separate cover ceiling
    (affine_gamma_nonnegative070 a ha) (affine_gamma_window070 a ha world h B state)
    (affine_gamma_empty070 a ha) (affine_gamma_complete070 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches070,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches070,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node069 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known069 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known069 a) ((4 : Int),(3 : Int)) (affine_gamma_branches069 a) copies separate cover ceiling
    (affine_gamma_nonnegative069 a ha) (affine_gamma_window069 a ha world h B state)
    (affine_gamma_empty069 a ha) (affine_gamma_complete069 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches069,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches069,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node068 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known068 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known068 a) ((5 : Int),(1 : Int)) (affine_gamma_branches068 a) copies separate cover ceiling
    (affine_gamma_nonnegative068 a ha) (affine_gamma_window068 a ha world h B state)
    (affine_gamma_empty068 a ha) (affine_gamma_complete068 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches068,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known068,affine_gamma_known069,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches068,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl
    · exact affine_gamma_node069 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node067 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known067 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known067 a) ((4 : Int),(4 : Int)) (affine_gamma_branches067 a) copies separate cover ceiling
    (affine_gamma_nonnegative067 a ha) (affine_gamma_window067 a ha world h B state)
    (affine_gamma_empty067 a ha) (affine_gamma_complete067 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches067,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches067,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node066 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known066 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known066 a) ((4 : Int),(4 : Int)) (affine_gamma_branches066 a) copies separate cover ceiling
    (affine_gamma_nonnegative066 a ha) (affine_gamma_window066 a ha world h B state)
    (affine_gamma_empty066 a ha) (affine_gamma_complete066 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches066,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches066,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node065 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known065 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known065 a) ((6 : Int),(1 : Int)) (affine_gamma_branches065 a) copies separate cover ceiling
    (affine_gamma_nonnegative065 a ha) (affine_gamma_window065 a ha world h B state)
    (affine_gamma_empty065 a ha) (affine_gamma_complete065 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches065,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known065,affine_gamma_known066,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known065,affine_gamma_known067,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches065,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node066 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node067 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node064 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known064 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known064 a) ((4 : Int),(4 : Int)) (affine_gamma_branches064 a) copies separate cover ceiling
    (affine_gamma_nonnegative064 a ha) (affine_gamma_window064 a ha world h B state)
    (affine_gamma_empty064 a ha) (affine_gamma_complete064 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches064,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches064,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node063 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known063 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known063 a) ((4 : Int),(4 : Int)) (affine_gamma_branches063 a) copies separate cover ceiling
    (affine_gamma_nonnegative063 a ha) (affine_gamma_window063 a ha world h B state)
    (affine_gamma_empty063 a ha) (affine_gamma_complete063 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches063,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches063,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node062 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known062 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known062 a) ((6 : Int),(1 : Int)) (affine_gamma_branches062 a) copies separate cover ceiling
    (affine_gamma_nonnegative062 a ha) (affine_gamma_window062 a ha world h B state)
    (affine_gamma_empty062 a ha) (affine_gamma_complete062 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches062,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known062,affine_gamma_known063,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known062,affine_gamma_known064,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches062,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node063 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node064 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node061 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known061 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known061 a) ((4 : Int),(3 : Int)) (affine_gamma_branches061 a) copies separate cover ceiling
    (affine_gamma_nonnegative061 a ha) (affine_gamma_window061 a ha world h B state)
    (affine_gamma_empty061 a ha) (affine_gamma_complete061 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches061,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known061,affine_gamma_known062,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known061,affine_gamma_known065,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches061,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node062 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node065 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_gamma_node060 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known060 a)) B) : Transition world h .gamma B := by
  exact affine_gamma_leaf060 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gamma_node059 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known059 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known059 a) ((4 : Int),(2 : Int)) (affine_gamma_branches059 a) copies separate cover ceiling
    (affine_gamma_nonnegative059 a ha) (affine_gamma_window059 a ha world h B state)
    (affine_gamma_empty059 a ha) (affine_gamma_complete059 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches059,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known059,affine_gamma_known060,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known059,affine_gamma_known061,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known059,affine_gamma_known068,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known059,affine_gamma_known070,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known059,affine_gamma_known071,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches059,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · exact affine_gamma_node060 a ha world h nextB nextState
    · exact affine_gamma_node061 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node068 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node070 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node071 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_gamma_node058 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known058 a)) B) : Transition world h .gamma B := by
  exact affine_gamma_leaf058 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gamma_node057 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known057 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known057 a) ((3 : Int),(1 : Int)) (affine_gamma_branches057 a) copies separate cover ceiling
    (affine_gamma_nonnegative057 a ha) (affine_gamma_window057 a ha world h B state)
    (affine_gamma_empty057 a ha) (affine_gamma_complete057 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches057,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known057,affine_gamma_known058,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known057,affine_gamma_known059,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches057,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node058 a ha world h nextB nextState
    · exact affine_gamma_node059 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node056 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known056 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known056 a) ((1 : Int),(3 : Int)) (affine_gamma_branches056 a) copies separate cover ceiling
    (affine_gamma_nonnegative056 a ha) (affine_gamma_window056 a ha world h B state)
    (affine_gamma_empty056 a ha) (affine_gamma_complete056 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches056,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known056,affine_gamma_known057,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known056,affine_gamma_known073,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches056,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node057 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node073 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node055 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known055 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known055 a) ((4 : Int),(1 : Int)) (affine_gamma_branches055 a) copies separate cover ceiling
    (affine_gamma_nonnegative055 a ha) (affine_gamma_window055 a ha world h B state)
    (affine_gamma_empty055 a ha) (affine_gamma_complete055 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches055,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches055,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node054 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known054 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known054 a) ((4 : Int),(2 : Int)) (affine_gamma_branches054 a) copies separate cover ceiling
    (affine_gamma_nonnegative054 a ha) (affine_gamma_window054 a ha world h B state)
    (affine_gamma_empty054 a ha) (affine_gamma_complete054 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches054,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches054,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node053 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known053 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known053 a) ((4 : Int),(2 : Int)) (affine_gamma_branches053 a) copies separate cover ceiling
    (affine_gamma_nonnegative053 a ha) (affine_gamma_window053 a ha world h B state)
    (affine_gamma_empty053 a ha) (affine_gamma_complete053 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches053,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches053,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node052 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known052 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known052 a) ((4 : Int),(1 : Int)) (affine_gamma_branches052 a) copies separate cover ceiling
    (affine_gamma_nonnegative052 a ha) (affine_gamma_window052 a ha world h B state)
    (affine_gamma_empty052 a ha) (affine_gamma_complete052 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches052,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known052,affine_gamma_known053,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known052,affine_gamma_known054,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches052,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node053 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node054 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node051 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known051 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known051 a) ((4 : Int),(1 : Int)) (affine_gamma_branches051 a) copies separate cover ceiling
    (affine_gamma_nonnegative051 a ha) (affine_gamma_window051 a ha world h B state)
    (affine_gamma_empty051 a ha) (affine_gamma_complete051 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches051,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches051,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node050 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known050 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known050 a) ((4 : Int),(0 : Int)) (affine_gamma_branches050 a) copies separate cover ceiling
    (affine_gamma_nonnegative050 a ha) (affine_gamma_window050 a ha world h B state)
    (affine_gamma_empty050 a ha) (affine_gamma_complete050 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches050,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known050,affine_gamma_known051,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known050,affine_gamma_known052,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known050,affine_gamma_known055,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches050,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_gamma_node051 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node052 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node055 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node049 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known049 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known049 a) ((4 : Int),(1 : Int)) (affine_gamma_branches049 a) copies separate cover ceiling
    (affine_gamma_nonnegative049 a ha) (affine_gamma_window049 a ha world h B state)
    (affine_gamma_empty049 a ha) (affine_gamma_complete049 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches049,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches049,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node048 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known048 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known048 a) ((4 : Int),(2 : Int)) (affine_gamma_branches048 a) copies separate cover ceiling
    (affine_gamma_nonnegative048 a ha) (affine_gamma_window048 a ha world h B state)
    (affine_gamma_empty048 a ha) (affine_gamma_complete048 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches048,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches048,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node047 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known047 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known047 a) ((4 : Int),(2 : Int)) (affine_gamma_branches047 a) copies separate cover ceiling
    (affine_gamma_nonnegative047 a ha) (affine_gamma_window047 a ha world h B state)
    (affine_gamma_empty047 a ha) (affine_gamma_complete047 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches047,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches047,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node046 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known046 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known046 a) ((4 : Int),(1 : Int)) (affine_gamma_branches046 a) copies separate cover ceiling
    (affine_gamma_nonnegative046 a ha) (affine_gamma_window046 a ha world h B state)
    (affine_gamma_empty046 a ha) (affine_gamma_complete046 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches046,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known046,affine_gamma_known047,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known046,affine_gamma_known048,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches046,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node047 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node048 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node045 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known045 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known045 a) ((4 : Int),(1 : Int)) (affine_gamma_branches045 a) copies separate cover ceiling
    (affine_gamma_nonnegative045 a ha) (affine_gamma_window045 a ha world h B state)
    (affine_gamma_empty045 a ha) (affine_gamma_complete045 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches045,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches045,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node044 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known044 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known044 a) ((4 : Int),(0 : Int)) (affine_gamma_branches044 a) copies separate cover ceiling
    (affine_gamma_nonnegative044 a ha) (affine_gamma_window044 a ha world h B state)
    (affine_gamma_empty044 a ha) (affine_gamma_complete044 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches044,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known044,affine_gamma_known045,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known044,affine_gamma_known046,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known044,affine_gamma_known049,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches044,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_gamma_node045 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node046 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node049 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node043 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known043 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known043 a) ((1 : Int),(3 : Int)) (affine_gamma_branches043 a) copies separate cover ceiling
    (affine_gamma_nonnegative043 a ha) (affine_gamma_window043 a ha world h B state)
    (affine_gamma_empty043 a ha) (affine_gamma_complete043 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches043,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known043,affine_gamma_known044,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known043,affine_gamma_known050,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches043,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node044 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node050 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node042 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known042 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known042 a) ((5 : Int),(1 : Int)) (affine_gamma_branches042 a) copies separate cover ceiling
    (affine_gamma_nonnegative042 a ha) (affine_gamma_window042 a ha world h B state)
    (affine_gamma_empty042 a ha) (affine_gamma_complete042 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches042,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches042,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node041 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known041 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known041 a) ((5 : Int),(1 : Int)) (affine_gamma_branches041 a) copies separate cover ceiling
    (affine_gamma_nonnegative041 a ha) (affine_gamma_window041 a ha world h B state)
    (affine_gamma_empty041 a ha) (affine_gamma_complete041 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches041,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches041,List.mem_cons,List.not_mem_nil,or_false] at member
include ha in
theorem affine_gamma_node040 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known040 a)) B) : Transition world h .gamma B := by
  exact affine_gamma_leaf040 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gamma_node039 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known039 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known039 a) ((7 : Int),(1 : Int)) (affine_gamma_branches039 a) copies separate cover ceiling
    (affine_gamma_nonnegative039 a ha) (affine_gamma_window039 a ha world h B state)
    (affine_gamma_empty039 a ha) (affine_gamma_complete039 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches039,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches039,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node038 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known038 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known038 a) ((7 : Int),(1 : Int)) (affine_gamma_branches038 a) copies separate cover ceiling
    (affine_gamma_nonnegative038 a ha) (affine_gamma_window038 a ha world h B state)
    (affine_gamma_empty038 a ha) (affine_gamma_complete038 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches038,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches038,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node037 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known037 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known037 a) ((6 : Int),(1 : Int)) (affine_gamma_branches037 a) copies separate cover ceiling
    (affine_gamma_nonnegative037 a ha) (affine_gamma_window037 a ha world h B state)
    (affine_gamma_empty037 a ha) (affine_gamma_complete037 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches037,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known037,affine_gamma_known038,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known037,affine_gamma_known039,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches037,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node038 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node039 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node036 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known036 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known036 a) ((7 : Int),(1 : Int)) (affine_gamma_branches036 a) copies separate cover ceiling
    (affine_gamma_nonnegative036 a ha) (affine_gamma_window036 a ha world h B state)
    (affine_gamma_empty036 a ha) (affine_gamma_complete036 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches036,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches036,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node035 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known035 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known035 a) ((7 : Int),(1 : Int)) (affine_gamma_branches035 a) copies separate cover ceiling
    (affine_gamma_nonnegative035 a ha) (affine_gamma_window035 a ha world h B state)
    (affine_gamma_empty035 a ha) (affine_gamma_complete035 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches035,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches035,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node034 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known034 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known034 a) ((6 : Int),(1 : Int)) (affine_gamma_branches034 a) copies separate cover ceiling
    (affine_gamma_nonnegative034 a ha) (affine_gamma_window034 a ha world h B state)
    (affine_gamma_empty034 a ha) (affine_gamma_complete034 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches034,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known034,affine_gamma_known035,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known034,affine_gamma_known036,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches034,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node035 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node036 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node033 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known033 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known033 a) ((4 : Int),(3 : Int)) (affine_gamma_branches033 a) copies separate cover ceiling
    (affine_gamma_nonnegative033 a ha) (affine_gamma_window033 a ha world h B state)
    (affine_gamma_empty033 a ha) (affine_gamma_complete033 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches033,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known033,affine_gamma_known034,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known033,affine_gamma_known037,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches033,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node034 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node037 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node032 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known032 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known032 a) ((5 : Int),(1 : Int)) (affine_gamma_branches032 a) copies separate cover ceiling
    (affine_gamma_nonnegative032 a ha) (affine_gamma_window032 a ha world h B state)
    (affine_gamma_empty032 a ha) (affine_gamma_complete032 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches032,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches032,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node031 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known031 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known031 a) ((5 : Int),(1 : Int)) (affine_gamma_branches031 a) copies separate cover ceiling
    (affine_gamma_nonnegative031 a ha) (affine_gamma_window031 a ha world h B state)
    (affine_gamma_empty031 a ha) (affine_gamma_complete031 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches031,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches031,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node030 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known030 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known030 a) ((6 : Int),(1 : Int)) (affine_gamma_branches030 a) copies separate cover ceiling
    (affine_gamma_nonnegative030 a ha) (affine_gamma_window030 a ha world h B state)
    (affine_gamma_empty030 a ha) (affine_gamma_complete030 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches030,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches030,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node029 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known029 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known029 a) ((6 : Int),(1 : Int)) (affine_gamma_branches029 a) copies separate cover ceiling
    (affine_gamma_nonnegative029 a ha) (affine_gamma_window029 a ha world h B state)
    (affine_gamma_empty029 a ha) (affine_gamma_complete029 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches029,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches029,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node028 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known028 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known028 a) ((5 : Int),(1 : Int)) (affine_gamma_branches028 a) copies separate cover ceiling
    (affine_gamma_nonnegative028 a ha) (affine_gamma_window028 a ha world h B state)
    (affine_gamma_empty028 a ha) (affine_gamma_complete028 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches028,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known028,affine_gamma_known029,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known028,affine_gamma_known030,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches028,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node029 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node030 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node027 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known027 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known027 a) ((4 : Int),(2 : Int)) (affine_gamma_branches027 a) copies separate cover ceiling
    (affine_gamma_nonnegative027 a ha) (affine_gamma_window027 a ha world h B state)
    (affine_gamma_empty027 a ha) (affine_gamma_complete027 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches027,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known027,affine_gamma_known028,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known027,affine_gamma_known031,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known027,affine_gamma_known032,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known027,affine_gamma_known033,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known027,affine_gamma_known040,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known027,affine_gamma_known041,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known027,affine_gamma_known042,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches027,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact affine_gamma_node028 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node031 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node032 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node033 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node040 a ha world h nextB nextState
    · exact affine_gamma_node041 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node042 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_gamma_node026 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known026 a)) B) : Transition world h .gamma B := by
  exact affine_gamma_leaf026 a ha world h B state
include ha in
theorem affine_gamma_node025 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known025 a)) B) : Transition world h .gamma B := by
  exact affine_gamma_leaf025 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gamma_node024 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known024 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known024 a) ((4 : Int),(0 : Int)) (affine_gamma_branches024 a) copies separate cover ceiling
    (affine_gamma_nonnegative024 a ha) (affine_gamma_window024 a ha world h B state)
    (affine_gamma_empty024 a ha) (affine_gamma_complete024 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches024,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known024,affine_gamma_known025,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known024,affine_gamma_known026,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known024,affine_gamma_known027,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches024,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_gamma_node025 a ha world h nextB nextState
    · exact affine_gamma_node026 a ha world h nextB nextState
    · exact affine_gamma_node027 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node023 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known023 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known023 a) ((5 : Int),(1 : Int)) (affine_gamma_branches023 a) copies separate cover ceiling
    (affine_gamma_nonnegative023 a ha) (affine_gamma_window023 a ha world h B state)
    (affine_gamma_empty023 a ha) (affine_gamma_complete023 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches023,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches023,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node022 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known022 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known022 a) ((5 : Int),(1 : Int)) (affine_gamma_branches022 a) copies separate cover ceiling
    (affine_gamma_nonnegative022 a ha) (affine_gamma_window022 a ha world h B state)
    (affine_gamma_empty022 a ha) (affine_gamma_complete022 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches022,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches022,List.mem_cons,List.not_mem_nil,or_false] at member
include ha in
theorem affine_gamma_node021 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known021 a)) B) : Transition world h .gamma B := by
  exact affine_gamma_leaf021 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gamma_node020 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known020 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known020 a) ((7 : Int),(1 : Int)) (affine_gamma_branches020 a) copies separate cover ceiling
    (affine_gamma_nonnegative020 a ha) (affine_gamma_window020 a ha world h B state)
    (affine_gamma_empty020 a ha) (affine_gamma_complete020 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches020,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches020,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node019 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known019 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known019 a) ((7 : Int),(1 : Int)) (affine_gamma_branches019 a) copies separate cover ceiling
    (affine_gamma_nonnegative019 a ha) (affine_gamma_window019 a ha world h B state)
    (affine_gamma_empty019 a ha) (affine_gamma_complete019 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches019,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches019,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node018 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known018 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known018 a) ((6 : Int),(1 : Int)) (affine_gamma_branches018 a) copies separate cover ceiling
    (affine_gamma_nonnegative018 a ha) (affine_gamma_window018 a ha world h B state)
    (affine_gamma_empty018 a ha) (affine_gamma_complete018 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches018,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known018,affine_gamma_known019,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known018,affine_gamma_known020,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches018,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node019 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node020 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node017 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known017 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known017 a) ((7 : Int),(1 : Int)) (affine_gamma_branches017 a) copies separate cover ceiling
    (affine_gamma_nonnegative017 a ha) (affine_gamma_window017 a ha world h B state)
    (affine_gamma_empty017 a ha) (affine_gamma_complete017 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches017,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches017,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node016 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known016 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known016 a) ((7 : Int),(1 : Int)) (affine_gamma_branches016 a) copies separate cover ceiling
    (affine_gamma_nonnegative016 a ha) (affine_gamma_window016 a ha world h B state)
    (affine_gamma_empty016 a ha) (affine_gamma_complete016 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches016,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches016,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node015 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known015 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known015 a) ((6 : Int),(1 : Int)) (affine_gamma_branches015 a) copies separate cover ceiling
    (affine_gamma_nonnegative015 a ha) (affine_gamma_window015 a ha world h B state)
    (affine_gamma_empty015 a ha) (affine_gamma_complete015 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches015,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known015,affine_gamma_known016,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known015,affine_gamma_known017,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches015,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node016 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node017 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node014 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known014 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known014 a) ((4 : Int),(3 : Int)) (affine_gamma_branches014 a) copies separate cover ceiling
    (affine_gamma_nonnegative014 a ha) (affine_gamma_window014 a ha world h B state)
    (affine_gamma_empty014 a ha) (affine_gamma_complete014 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches014,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known014,affine_gamma_known015,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known014,affine_gamma_known018,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches014,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node015 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node018 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node013 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known013 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known013 a) ((5 : Int),(1 : Int)) (affine_gamma_branches013 a) copies separate cover ceiling
    (affine_gamma_nonnegative013 a ha) (affine_gamma_window013 a ha world h B state)
    (affine_gamma_empty013 a ha) (affine_gamma_complete013 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches013,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches013,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node012 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known012 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known012 a) ((5 : Int),(1 : Int)) (affine_gamma_branches012 a) copies separate cover ceiling
    (affine_gamma_nonnegative012 a ha) (affine_gamma_window012 a ha world h B state)
    (affine_gamma_empty012 a ha) (affine_gamma_complete012 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches012,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches012,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node011 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known011 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known011 a) ((6 : Int),(1 : Int)) (affine_gamma_branches011 a) copies separate cover ceiling
    (affine_gamma_nonnegative011 a ha) (affine_gamma_window011 a ha world h B state)
    (affine_gamma_empty011 a ha) (affine_gamma_complete011 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches011,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches011,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node010 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known010 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known010 a) ((6 : Int),(1 : Int)) (affine_gamma_branches010 a) copies separate cover ceiling
    (affine_gamma_nonnegative010 a ha) (affine_gamma_window010 a ha world h B state)
    (affine_gamma_empty010 a ha) (affine_gamma_complete010 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches010,List.mem_cons,List.not_mem_nil,or_false] at member
  · intro branch member nextB nextState
    simp only [affine_gamma_branches010,List.mem_cons,List.not_mem_nil,or_false] at member
include ha copies separate cover ceiling in
theorem affine_gamma_node009 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known009 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known009 a) ((5 : Int),(1 : Int)) (affine_gamma_branches009 a) copies separate cover ceiling
    (affine_gamma_nonnegative009 a ha) (affine_gamma_window009 a ha world h B state)
    (affine_gamma_empty009 a ha) (affine_gamma_complete009 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches009,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known009,affine_gamma_known010,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known009,affine_gamma_known011,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches009,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node010 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node011 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node008 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known008 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known008 a) ((4 : Int),(2 : Int)) (affine_gamma_branches008 a) copies separate cover ceiling
    (affine_gamma_nonnegative008 a ha) (affine_gamma_window008 a ha world h B state)
    (affine_gamma_empty008 a ha) (affine_gamma_complete008 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches008,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known008,affine_gamma_known009,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known008,affine_gamma_known012,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known008,affine_gamma_known013,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known008,affine_gamma_known014,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known008,affine_gamma_known021,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known008,affine_gamma_known022,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known008,affine_gamma_known023,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches008,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact affine_gamma_node009 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node012 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node013 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node014 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node021 a ha world h nextB nextState
    · exact affine_gamma_node022 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node023 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_gamma_node007 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known007 a)) B) : Transition world h .gamma B := by
  exact affine_gamma_leaf007 a ha world h B state
include ha in
theorem affine_gamma_node006 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known006 a)) B) : Transition world h .gamma B := by
  exact affine_gamma_leaf006 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gamma_node005 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known005 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known005 a) ((4 : Int),(0 : Int)) (affine_gamma_branches005 a) copies separate cover ceiling
    (affine_gamma_nonnegative005 a ha) (affine_gamma_window005 a ha world h B state)
    (affine_gamma_empty005 a ha) (affine_gamma_complete005 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches005,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known005,affine_gamma_known006,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known005,affine_gamma_known007,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known005,affine_gamma_known008,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches005,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact affine_gamma_node006 a ha world h nextB nextState
    · exact affine_gamma_node007 a ha world h nextB nextState
    · exact affine_gamma_node008 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node004 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known004 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known004 a) ((1 : Int),(3 : Int)) (affine_gamma_branches004 a) copies separate cover ceiling
    (affine_gamma_nonnegative004 a ha) (affine_gamma_window004 a ha world h B state)
    (affine_gamma_empty004 a ha) (affine_gamma_complete004 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches004,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known004,affine_gamma_known005,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known004,affine_gamma_known024,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches004,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl
    · exact affine_gamma_node005 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node024 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node003 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known003 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known003 a) ((3 : Int),(0 : Int)) (affine_gamma_branches003 a) copies separate cover ceiling
    (affine_gamma_nonnegative003 a ha) (affine_gamma_window003 a ha world h B state)
    (affine_gamma_empty003 a ha) (affine_gamma_complete003 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches003,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known003,affine_gamma_known004,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known003,affine_gamma_known043,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known003,affine_gamma_known056,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known003,affine_gamma_known089,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known003,affine_gamma_known090,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches003,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · exact affine_gamma_node004 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node043 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node056 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node089 a ha world h nextB nextState
    · exact affine_gamma_node090 a ha world h copies separate cover ceiling nextB nextState
include ha copies separate cover ceiling in
theorem affine_gamma_node002 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known002 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known002 a) ((1 : Int),(1 : Int)) (affine_gamma_branches002 a) copies separate cover ceiling
    (affine_gamma_nonnegative002 a ha) (affine_gamma_window002 a ha world h B state)
    (affine_gamma_empty002 a ha) (affine_gamma_complete002 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches002,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known002,affine_gamma_known003,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known002,affine_gamma_known097,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known002,affine_gamma_known098,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known002,affine_gamma_known099,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known002,affine_gamma_known100,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches002,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · exact affine_gamma_node003 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node097 a ha world h nextB nextState
    · exact affine_gamma_node098 a ha world h nextB nextState
    · exact affine_gamma_node099 a ha world h nextB nextState
    · exact affine_gamma_node100 a ha world h copies separate cover ceiling nextB nextState
include ha in
theorem affine_gamma_node001 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known001 a)) B) : Transition world h .gamma B := by
  exact affine_gamma_leaf001 a ha world h B state
include ha copies separate cover ceiling in
theorem affine_gamma_node000 (B : Int → Int → Prop)
    (state : State world h (knownCells (affine_gamma_known000 a)) B) : Transition world h .gamma B := by
  apply replay_affine_step a (by omega) world h .gamma (affine_gamma_known000 a) ((0 : Int),(1 : Int)) (affine_gamma_branches000 a) copies separate cover ceiling
    (affine_gamma_nonnegative000 a ha) (affine_gamma_window000 a ha world h B state)
    (affine_gamma_empty000 a ha) (affine_gamma_complete000 a ha) ?_ ?_ B state
  · intro branch member
    simp only [affine_gamma_branches000,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known000,affine_gamma_known001,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known000,affine_gamma_known002,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known000,affine_gamma_known117,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known000,affine_gamma_known131,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known000,affine_gamma_known161,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
    · simp only [Branch.occupied,Branch.tile,knownCells,affine_gamma_known000,affine_gamma_known167,List.flatMap_cons,List.flatMap_nil,List.append_nil,List.append_assoc]
      exact ⟨by intros; assumption,by intros; assumption⟩
  · intro branch member nextB nextState
    simp only [affine_gamma_branches000,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl | rfl
    · exact affine_gamma_node001 a ha world h nextB nextState
    · exact affine_gamma_node002 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node117 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node131 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node161 a ha world h copies separate cover ceiling nextB nextState
    · exact affine_gamma_node167 a ha world h copies separate cover ceiling nextB nextState
end AffineGamma

theorem affine_gamma_seed_eq (a : Int) : SameCells (seed .gamma) (knownCells (affine_gamma_known000 a)) := by
  change SameCells (seed .gamma) (knownCells (affine_gamma_known000 (0 : Int)))
  decide

theorem affine_gamma_local (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (copies : ∀ t, world t → Copy a 1 1 0 t)
    (separate : DisjointWorld world) (cover : CoversWindow world h)
    (ceiling : SelectedBelow world h) (closed : TileClosed world B)
    (bounded : Below h B) (clean : Clean .gamma 0 0 B) : Transition world h .gamma B := by
  exact affine_gamma_node000 a ha world h copies separate cover ceiling B
    (state_congr (affine_gamma_seed_eq a) (seed_state world h .gamma B closed bounded clean))
#print axioms affine_gamma_local

end CornerCertificate

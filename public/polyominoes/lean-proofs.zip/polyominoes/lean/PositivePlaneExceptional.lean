import PositiveHierarchy

set_option maxRecDepth 10000
set_option maxHeartbeats 1000000

namespace PositivePlaneExceptional
open CrossUnits PolyominoFormal

inductive Kind where
  | A | B | C | D

inductive Piece where
  | AP | AN | AV | BH | BV | CH | CV | DP | DN | DZ | DV

def motif (b : Int) : Kind→Cross
  | .A => ⟨0,0,b-3,b,2,0⟩
  | .B => ⟨b-2,-2,0,2,b,b-3⟩
  | .C => ⟨b-1,1,2,0,b-3,b⟩
  | .D => ⟨1,3,b,b-3,0,2⟩

def placed (b k l : Int) (m : Kind) : Cross :=
  shift (4*k+l*b) (4*k-l*b) (motif b m)

def owner : Piece→Kind
  | .AP | .AN | .AV => .A
  | .BH | .BV => .B
  | .CH | .CV => .C
  | .DP | .DN | .DZ | .DV => .D

def offset : Piece→Int
  | .AN | .AV | .DN | .DV => 1
  | _ => 0

def lower (b : Int) : Piece→Int
  | .AP | .BH | .DP | .DZ => 0
  | .AN => 2*b-2
  | .AV => b
  | .BV => b-2
  | .CH => 1
  | .CV => b-1
  | .DN => 2*b-1
  | .DV => b+1

def upper (b : Int) : Piece→Int
  | .AP => b-3
  | .AN | .AV | .DN | .DV => 2*b-1
  | .BH => b-1
  | .BV => 2*b-3
  | .CH => b
  | .CV => 2*b-2
  | .DP => b-2
  | .DZ => 0

def value (b r : Int) : Piece→Int
  | .AP => 0
  | .AN => -b
  | .AV => b-r
  | .BH => -2
  | .BV => b-2-r
  | .CH | .DZ => 1
  | .CV => b-1-r
  | .DP => 3
  | .DN => 3-b
  | .DV => b+1-r

def pieceTile (b q k : Int) (p : Piece) : Cross :=
  placed b k (q+offset p) (owner p)

def delta (b q x y : Int) : Int := x-y-2*(q*b)

def Info (b q k : Int) (p : Piece) (x y : Int) : Prop :=
  lower b p≤delta b q x y ∧ delta b q x y≤upper b p ∧
  y+q*b=4*k+value b (delta b q x y) p

def World (b : Int) (t : Cross) : Prop :=
  ∃ k l m, t=placed b k l m

theorem info_world (b q k : Int) (p : Piece) : World b (pieceTile b q k p) :=
  ⟨k,q+offset p,owner p,rfl⟩

theorem info_bounds (b q k : Int) (p : Piece) (x y : Int) (hb : 5≤b)
    (hi : Info b q k p x y) : 0≤delta b q x y ∧ delta b q x y<2*b := by
  cases p
  all_goals dsimp [Info,lower,upper] at hi
  all_goals omega

theorem info_contains (b q k : Int) (p : Piece) (x y : Int) (hb : 5≤b)
    (hi : Info b q k p x y) : Contains (pieceTile b q k p) x y := by
  cases p
  all_goals dsimp [Info,lower,upper,value,delta,pieceTile,placed,offset,owner,motif,shift,Contains] at *
  all_goals simp only [Int.add_mul,Int.one_mul,Int.add_zero] at *
  all_goals omega

theorem contains_info (b k l : Int) (m : Kind) (x y : Int) (hb : 5≤b)
    (hit : Contains (placed b k l m) x y) :
    ∃ q p, placed b k l m=pieceTile b q k p ∧ Info b q k p x y := by
  cases m
  · by_cases hrow : y=4*k-l*b
    · by_cases hpos : 0≤x-y-2*(l*b)
      · refine ⟨l,.AP,?_,?_⟩
        · simp [pieceTile,offset,owner]
        · dsimp [Info,lower,upper,value,delta]
          dsimp [placed,motif,shift,Contains] at hit
          omega
      · refine ⟨l-1,.AN,?_,?_⟩
        · simp [pieceTile,offset,owner]
        · dsimp [Info,lower,upper,value,delta]
          simp only [Int.sub_mul,Int.one_mul]
          dsimp [placed,motif,shift,Contains] at hit
          omega
    · refine ⟨l-1,.AV,?_,?_⟩
      · simp [pieceTile,offset,owner]
      · dsimp [Info,lower,upper,value,delta]
        simp only [Int.sub_mul,Int.one_mul]
        dsimp [placed,motif,shift,Contains] at hit
        omega
  · by_cases hcol : x=4*k+l*b+b-2
    · refine ⟨l,.BV,?_,?_⟩
      · simp [pieceTile,offset,owner]
      · dsimp [Info,lower,upper,value,delta]
        dsimp [placed,motif,shift,Contains] at hit
        omega
    · refine ⟨l,.BH,?_,?_⟩
      · simp [pieceTile,offset,owner]
      · dsimp [Info,lower,upper,value,delta]
        dsimp [placed,motif,shift,Contains] at hit
        omega
  · by_cases hrow : y=4*k-l*b+1
    · refine ⟨l,.CH,?_,?_⟩
      · simp [pieceTile,offset,owner]
      · dsimp [Info,lower,upper,value,delta]
        dsimp [placed,motif,shift,Contains] at hit
        omega
    · refine ⟨l,.CV,?_,?_⟩
      · simp [pieceTile,offset,owner]
      · dsimp [Info,lower,upper,value,delta]
        dsimp [placed,motif,shift,Contains] at hit
        omega
  · by_cases hcol : x=4*k+l*b+1
    · by_cases hzero : x-y-2*(l*b)=0
      · refine ⟨l,.DZ,?_,?_⟩
        · simp [pieceTile,offset,owner]
        · dsimp [Info,lower,upper,value,delta]
          dsimp [placed,motif,shift,Contains] at hit
          omega
      · refine ⟨l-1,.DV,?_,?_⟩
        · simp [pieceTile,offset,owner]
        · dsimp [Info,lower,upper,value,delta]
          simp only [Int.sub_mul,Int.one_mul]
          dsimp [placed,motif,shift,Contains] at hit
          omega
    · by_cases hpos : 0≤x-y-2*(l*b)
      · refine ⟨l,.DP,?_,?_⟩
        · simp [pieceTile,offset,owner]
        · dsimp [Info,lower,upper,value,delta]
          dsimp [placed,motif,shift,Contains] at hit
          omega
      · refine ⟨l-1,.DN,?_,?_⟩
        · simp [pieceTile,offset,owner]
        · dsimp [Info,lower,upper,value,delta]
          simp only [Int.sub_mul,Int.one_mul]
          dsimp [placed,motif,shift,Contains] at hit
          omega

theorem info_unique (b q k l : Int) (p r : Piece) (x y : Int) (hb : 5≤b)
    (hp : Info b q k p x y) (hr : Info b q l r x y) :
    pieceTile b q k p=pieceTile b q l r := by
  cases p <;> cases r
  all_goals apply same_eq
  all_goals dsimp [Same,Info,lower,upper,value,delta,pieceTile,placed,offset,owner,motif,shift] at *
  all_goals try simp only [Int.add_mul,Int.one_mul,Int.add_zero,and_true] at *
  all_goals omega

theorem four_residues (z base : Int) : ∃ k,
    z=4*k+base ∨ z=4*k+base+1 ∨ z=4*k+base+2 ∨ z=4*k+base+3 := by
  have hb := PositiveHierarchy.div_bounds 4 (z-base) (by omega)
  refine ⟨(z-base)/4,?_⟩
  omega

theorem residue_cover (b r z : Int) (hb : 5≤b) (hr0 : 0≤r) (hr1 : r<2*b) :
    ∃ p k, lower b p≤r ∧ r≤upper b p ∧ z=4*k+value b r p := by
  by_cases h0 : r=0
  · obtain ⟨k,hk⟩ := four_residues z 0
    rcases hk with hk | hk | hk | hk
    · exact ⟨.AP,k,by dsimp [lower,upper,value]; omega⟩
    · exact ⟨.DZ,k,by dsimp [lower,upper,value]; omega⟩
    · exact ⟨.BH,k+1,by dsimp [lower,upper,value]; omega⟩
    · exact ⟨.DP,k,by dsimp [lower,upper,value]; omega⟩
  · by_cases hlow : r≤b-3
    · obtain ⟨k,hk⟩ := four_residues z 0
      rcases hk with hk | hk | hk | hk
      · exact ⟨.AP,k,by dsimp [lower,upper,value]; omega⟩
      · exact ⟨.CH,k,by dsimp [lower,upper,value]; omega⟩
      · exact ⟨.BH,k+1,by dsimp [lower,upper,value]; omega⟩
      · exact ⟨.DP,k,by dsimp [lower,upper,value]; omega⟩
    · by_cases hbm2 : r=b-2
      · obtain ⟨k,hk⟩ := four_residues z 0
        rcases hk with hk | hk | hk | hk
        · exact ⟨.BV,k,by dsimp [lower,upper,value]; omega⟩
        · exact ⟨.CH,k,by dsimp [lower,upper,value]; omega⟩
        · exact ⟨.BH,k+1,by dsimp [lower,upper,value]; omega⟩
        · exact ⟨.DP,k,by dsimp [lower,upper,value]; omega⟩
      · by_cases hbm1 : r=b-1
        · obtain ⟨k,hk⟩ := four_residues z (-2)
          rcases hk with hk | hk | hk | hk
          · exact ⟨.BH,k,by dsimp [lower,upper,value]; omega⟩
          · exact ⟨.BV,k,by dsimp [lower,upper,value]; omega⟩
          · exact ⟨.CV,k,by dsimp [lower,upper,value]; omega⟩
          · exact ⟨.CH,k,by dsimp [lower,upper,value]; omega⟩
        · by_cases hbe : r=b
          · obtain ⟨k,hk⟩ := four_residues z (-2)
            rcases hk with hk | hk | hk | hk
            · exact ⟨.BV,k,by dsimp [lower,upper,value]; omega⟩
            · exact ⟨.CV,k,by dsimp [lower,upper,value]; omega⟩
            · exact ⟨.AV,k,by dsimp [lower,upper,value]; omega⟩
            · exact ⟨.CH,k,by dsimp [lower,upper,value]; omega⟩
          · by_cases hhigh : r≤2*b-3
            · obtain ⟨k,hk⟩ := four_residues z (b-2-r)
              rcases hk with hk | hk | hk | hk
              · exact ⟨.BV,k,by dsimp [lower,upper,value]; omega⟩
              · exact ⟨.CV,k,by dsimp [lower,upper,value]; omega⟩
              · exact ⟨.AV,k,by dsimp [lower,upper,value]; omega⟩
              · exact ⟨.DV,k,by dsimp [lower,upper,value]; omega⟩
            · by_cases hend : r=2*b-2
              · obtain ⟨k,hk⟩ := four_residues z (-b)
                rcases hk with hk | hk | hk | hk
                · exact ⟨.AN,k,by dsimp [lower,upper,value]; omega⟩
                · exact ⟨.CV,k,by dsimp [lower,upper,value]; omega⟩
                · exact ⟨.AV,k,by dsimp [lower,upper,value]; omega⟩
                · exact ⟨.DV,k,by dsimp [lower,upper,value]; omega⟩
              · obtain ⟨k,hk⟩ := four_residues z (-b)
                rcases hk with hk | hk | hk | hk
                · exact ⟨.AN,k,by dsimp [lower,upper,value]; omega⟩
                · exact ⟨.AV,k,by dsimp [lower,upper,value]; omega⟩
                · exact ⟨.DV,k,by dsimp [lower,upper,value]; omega⟩
                · exact ⟨.DN,k,by dsimp [lower,upper,value]; omega⟩

theorem delta_block_unique (b q r x y : Int) (hb : 0<b)
    (hq : 0≤delta b q x y ∧ delta b q x y<2*b)
    (hr : 0≤delta b r x y ∧ delta b r x y<2*b) : q=r := by
  unfold delta at *
  by_cases hqr : q<r
  · have hm := Int.mul_le_mul_of_nonneg_right (c:=b) (show q+1≤r by omega) (by omega)
    simp only [Int.add_mul,Int.one_mul] at hm
    omega
  · by_cases hrq : r<q
    · have hm := Int.mul_le_mul_of_nonneg_right (c:=b) (show r+1≤q by omega) (by omega)
      simp only [Int.add_mul,Int.one_mul] at hm
      omega
    · omega

theorem cover_info (b x y : Int) (hb : 5≤b) : ∃ q k p, Info b q k p x y := by
  let q := (x-y)/(2*b)
  have hq := PositiveHierarchy.div_bounds (2*b) (x-y) (by omega)
  have hm : q*(2*b)=2*(q*b) := by simp [Int.mul_left_comm]
  have hδ : 0≤delta b q x y ∧ delta b q x y<2*b := by
    change q*(2*b)≤x-y ∧ x-y<q*(2*b)+2*b at hq
    rw [hm] at hq
    unfold delta
    omega
  obtain ⟨p,k,hp⟩ := residue_cover b (delta b q x y) (y+q*b) hb hδ.1 hδ.2
  exact ⟨q,k,p,hp⟩

def planeTiling (b : Int) (hb : 5≤b) : Tiling (b-3) b 2 0 Plane where
  world := World b
  copies := by
    rintro t ⟨k,l,m,rfl⟩
    apply (copy_shift _ _ _ _ _ _ _).mpr
    cases m
    all_goals simp [motif,Copy,Arms]
  inside := by intros; trivial
  cover := by
    intro x y _
    obtain ⟨q,k,p,hi⟩ := cover_info b x y hb
    exact ⟨pieceTile b q k p,info_world b q k p,info_contains b q k p x y hb hi⟩
  disjoint := by
    rintro t u x y ⟨k,l,m,rfl⟩ ⟨k',l',m',rfl⟩ hit hiu
    obtain ⟨q,p,ht,hp⟩ := contains_info b k l m x y hb hit
    obtain ⟨q',p',hu,hp'⟩ := contains_info b k' l' m' x y hb hiu
    have hq := delta_block_unique b q q' x y (by omega)
      (info_bounds b q k p x y hb hp) (info_bounds b q' k' p' x y hb hp')
    subst q'
    rw [ht,hu]
    exact info_unique b q k k' p p' x y hb hp hp'

theorem tiles_plane (a : Int) (ha : 2≤a) : Tiles a (a+3) 2 0 Plane := by
  have h := planeTiling (a+3) (by omega)
  have he : a+3-3=a := by omega
  rw [he] at h
  exact ⟨h⟩

#print axioms tiles_plane
end PositivePlaneExceptional

import LHalfPlaneAlternatingCountSmall
namespace PolyominoFormal.LHalfPlaneAlternating
open CrossUnits
set_option maxHeartbeats 300000

def LeftLongPattern {a b : Int} (T : Tiling a b 0 0 HalfPlane) : Prop :=
  T.world ⟨1,1,a,b,0,0⟩ ∨ T.world ⟨a+1,1,0,b,a,0⟩ ∨
  (a+b+2≤2*a ∧ T.world ⟨a+b+2,1,0,b,a,0⟩)

def RightLongPattern {a b : Int} (T : Tiling a b 0 0 HalfPlane) : Prop :=
  T.world ⟨2*a,1,0,b,a,0⟩ ∨ T.world ⟨a,1,a,b,0,0⟩ ∨
  (1≤a-b-1 ∧ T.world ⟨a-b-1,1,a,b,0,0⟩)

/-- Once the wall-dependent outer-short pair is excluded, the first
long bar has one of three exact placements. -/
theorem left_long_pattern_of_no_outer {a b : Int}
    (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (T : Tiling a b 0 0 HalfPlane) (bars : EightBars T)
    (noOuter : ¬(T.world ⟨1,1,b,a,0,0⟩ ∧ T.world ⟨2*b+2,1,0,a,b,0⟩)) :
    LeftLongPattern T := by
  obtain ⟨l,r,m,s,hl,hr,hm,hs,bound,first,second,dirs⟩ := first_two_bars_all ha hb hab T bars
  rcases hl with hl | hl
  · subst l
    rcases hr with hr | hr
    · subst r
      left; simpa only [Int.add_zero,Int.sub_zero,show a+b-a=b by omega] using first
    · subst r
      right; left
      simpa only [Int.add_comm,Int.sub_self,show a+b-a=b by omega] using first
  · subst l
    have d := dirs rfl
    rcases d with ⟨rzero,sm⟩
    subst r; subst s
    rcases hm with hm | hm
    · subst m
      right; right
      refine ⟨by omega,?_⟩
      simpa only [Int.sub_self,show a+b-a=b by omega,show b+2+a=a+b+2 by omega] using second
    · subst m
      exact False.elim (noOuter ⟨
        by simpa only [Int.add_zero,Int.sub_zero,show a+b-b=a by omega] using first,
        by simpa only [Int.sub_self,show a+b-b=a by omega,show b+2+b=2*b+2 by omega] using second⟩)

/-- The endpoint patterns force the same long tile from both directions.
There is no unproved tiling or orientation inference in this count. -/
theorem endpoint_patterns_force_delta_two {a b : Int}
    (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (T : Tiling a b 0 0 HalfPlane)
    (leftPattern : LeftLongPattern T) (rightPattern : RightLongPattern T) : a=b+2 := by
  rcases leftPattern with left | left | ⟨leftBound,left⟩
  all_goals rcases rightPattern with right | right | ⟨rightBound,right⟩
  all_goals
    have eq := T.disjoint _ _ (a+1) 1 left right
      (by left; dsimp; omega) (by left; dsimp; omega)
    have hx := congrArg Cross.x eq
    have he := congrArg Cross.east eq
    dsimp only at hx he
    omega

#print axioms left_long_pattern_of_no_outer
#print axioms endpoint_patterns_force_delta_two
end PolyominoFormal.LHalfPlaneAlternating

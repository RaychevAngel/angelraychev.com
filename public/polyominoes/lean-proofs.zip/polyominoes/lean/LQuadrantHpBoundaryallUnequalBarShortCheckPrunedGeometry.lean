import LQuadrantHpBoundaryallUnequalBarShortCheckPrunedArithmetic
import TilingCore
import TPlaneGeometry
import TilingSymmetry
import LHalfPlaneBoundaryTips
import LHalfPlaneAlternatingPairPruning
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PolyominoFormal.LRegion
open CrossUnits
def HP_boundaryall_unequal_bar_short_check_pruned_M (a b : Int) : Int := 4*(a+b+1)
def HP_boundaryall_unequal_bar_short_check_pruned_Box (a b x y : Int) : Prop := -HP_boundaryall_unequal_bar_short_check_pruned_M a b ≤ x ∧ 0≤y ∧ x≤HP_boundaryall_unequal_bar_short_check_pruned_M a b ∧ y≤HP_boundaryall_unequal_bar_short_check_pruned_M a b
def HP_boundaryall_unequal_bar_short_check_pruned_Inside (t : Cross) : Prop := 0≤t.y-t.south

theorem HP_boundaryall_unequal_bar_short_check_pruned_node005 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_bar_short_check_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_bar_short_check_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht2 : world (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b))
    (ht5 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht6 : world (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b))
    (ap1_5 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_6 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_3 : Apart (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b))
    (ap2_5 : Apart (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap2_6 : Apart (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap3_4 : Apart (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b))
    (ap3_5 : Apart (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap3_6 : Apart (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap4_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap4_6 : Apart (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap5_6 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) (0 : Int) a b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have in2 := inside (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht4
  have in5 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht5
  have in6 := inside (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) (0 : Int) a b) ht6
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have allowed2 := avoid (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht4
  have allowed5 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) (0 : Int) a b) ht6
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht6
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) (0 : Int) a b) ht1 ht6
  have pairAllowed2_3 := avoidPair (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) (0 : Int) a b) ht2 ht6
  have pairAllowed3_4 := avoidPair (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) (0 : Int) a b) ht3 ht6
  have pairAllowed4_5 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) (0 : Int) a b) ht4 ht6
  have pairAllowed5_6 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) (0 : Int) a b) ht5 ht6
  have support : HP_boundaryall_unequal_bar_short_check_pruned_Box a b (4 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n005_point a b (hb) ((by simpa only [HP_boundaryall_unequal_bar_short_check_pruned_Box,HP_boundaryall_unequal_bar_short_check_pruned_M] using absent)) (hstrict)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) (0 : Int) a b) (4 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n005_empty a b ((by simpa only [Contains] using occupied)) (hlong) (hb)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht5
  have pairAllowed6 := avoidPair t (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) (0 : Int) a b) ht ht6
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) (0 : Int) a b) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n005_o0 a b jx jy (hb) (hstrict) (hit) (sep3).2.1 (sep3).2.2.1 (sep6).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n005_o1 a b jx jy (ap1_4).2.1 (hstrict) (hb) (sep4).2.2.1 (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n005_o2 a b jx jy (ap1_4).2.1 (allowed) (hstrict) (insideT) (hit) (hb) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n005_o3 a b jx jy (insideT) (ap1_4).2.1 (hit) (sep4).2.2.1 (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n005_o4 a b jx jy (sep4).2.2.1 (ap1_4).2.1 (hit) (insideT) (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n005_o5 a b jx jy (insideT) (sep0).2.1 (hb) (hstrict) (sep2).2.1 (sep6).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n005_o6 a b jx jy (hb) (ap1_4).2.1 (sep3).2.1 (sep6).2.2.1 (hit) (insideT) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n005_o7 a b jx jy (allowed) (sep6).2.1 (hb) (hit) (hstrict) (insideT)

theorem HP_boundaryall_unequal_bar_short_check_pruned_node007 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_bar_short_check_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_bar_short_check_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht2 : world (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b))
    (ht5 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht6 : world (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)))
    (ht7 : world (Cross.mk ((4 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)))
    (ap0_7 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b))
    (ap1_5 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_6 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)))
    (ap1_7 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((4 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b))
    (ap2_5 : Apart (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap2_6 : Apart (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)))
    (ap2_7 : Apart (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)))
    (ap3_4 : Apart (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b))
    (ap3_5 : Apart (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap3_6 : Apart (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)))
    (ap3_7 : Apart (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)))
    (ap4_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap4_6 : Apart (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)))
    (ap4_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) (Cross.mk ((4 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)))
    (ap5_6 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)))
    (ap5_7 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)))
    (ap6_7 : Apart (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have in2 := inside (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht4
  have in5 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht5
  have in6 := inside (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)) ht6
  have in7 := inside (Cross.mk ((4 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) ht7
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have allowed2 := avoid (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht4
  have allowed5 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk ((4 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) ht7
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) ht0 ht7
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((4 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) ht1 ht7
  have pairAllowed2_3 := avoidPair (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) ht2 ht7
  have pairAllowed3_4 := avoidPair (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) ht3 ht7
  have pairAllowed4_5 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) (Cross.mk ((4 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) ht4 ht7
  have pairAllowed5_6 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) ht5 ht7
  have pairAllowed6_7 := avoidPair (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) ht6 ht7
  have support : HP_boundaryall_unequal_bar_short_check_pruned_Box a b (4 : Int) (4 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n007_point a b ((by simpa only [HP_boundaryall_unequal_bar_short_check_pruned_Box,HP_boundaryall_unequal_bar_short_check_pruned_M] using absent)) (hstrict) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (4 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (4 : Int) ∨ Contains (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (4 : Int) ∨ Contains (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (4 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) (4 : Int) (4 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (4 : Int) ∨ Contains (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)) (4 : Int) (4 : Int) ∨ Contains (Cross.mk ((4 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (4 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n007_empty a b (hlong) (hb) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (4 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht5
  have pairAllowed6 := avoidPair t (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)) ht ht6
  have pairAllowed7 := avoidPair t (Cross.mk ((4 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) ht ht7
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk ((4 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((4 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n007_o0 a b jx jy (hb) (hstrict) (hit) (sep3).2.1 (sep7).2.1 (sep7).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n007_o1 a b jx jy (sep4).2.2.1 (ap1_4).2.1 (hstrict) (hb) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n007_o2 a b jx jy (hstrict) (ap5_7).2.2.2 (hit) (allowed) (ap1_4).2.1 (insideT) (hb) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n007_o3 a b jx jy (hstrict) (sep6).2.2.1 (sep0).2.1 (ap5_7).2.2.2 (hit) (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n007_o4 a b jx jy (ap1_4).2.1 (hstrict) (hb) (sep4).2.2.1 (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n007_o5 a b jx jy (hit) (insideT) (hb) (hstrict) (sep7).2.2.2 (sep0).2.1 (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n007_o6 a b jx jy (ap1_4).2.1 (hb) (sep3).2.1 (insideT) (sep6).2.2.1 (hit) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n007_o7 a b jx jy (hit) (allowed) (insideT) (hstrict) (ap5_7).2.2.2 (sep6).2.1 (hb) (sep3).2.2.1

theorem HP_boundaryall_unequal_bar_short_check_pruned_node006 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_bar_short_check_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_bar_short_check_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht2 : world (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b))
    (ht5 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht6 : world (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b))
    (ap1_5 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_6 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b))
    (ap2_5 : Apart (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap2_6 : Apart (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)))
    (ap3_4 : Apart (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b))
    (ap3_5 : Apart (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap3_6 : Apart (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)))
    (ap4_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap4_6 : Apart (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)))
    (ap5_6 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have in2 := inside (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht4
  have in5 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht5
  have in6 := inside (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)) ht6
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have allowed2 := avoid (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht4
  have allowed5 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)) ht6
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)) ht0 ht6
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)) ht1 ht6
  have pairAllowed2_3 := avoidPair (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)) ht2 ht6
  have pairAllowed3_4 := avoidPair (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)) ht3 ht6
  have pairAllowed4_5 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)) ht4 ht6
  have pairAllowed5_6 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)) ht5 ht6
  have support : HP_boundaryall_unequal_bar_short_check_pruned_Box a b (4 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n006_point a b (hstrict) ((by simpa only [HP_boundaryall_unequal_bar_short_check_pruned_Box,HP_boundaryall_unequal_bar_short_check_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)) (4 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n006_empty a b ((by simpa only [Contains] using occupied)) (hlong) (hb)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht5
  have pairAllowed6 := avoidPair t (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)) ht ht6
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n006_o0 a b jx jy (sep6).2.2.1 (hstrict) (sep3).2.2.1 (hb) (sep2).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n006_o1 a b jx jy (sep4).2.2.1 (hstrict) (insideT) (hb) (ap1_4).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n006_o2 a b jx jy (hstrict) (insideT) (allowed) (ap1_4).2.1 (hit) (sep0).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n006_o3 a b jx jy (hit) (sep6).2.2.1 (insideT) (ap1_4).2.1 (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n006_o4 a b jx jy (ap1_4).2.1 (hstrict) (insideT) (hb) (sep4).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n006_o5 a b jx jy (hit) (sep6).2.2.1 (hstrict) (hb) ((by simpa only [Same,eq_comm] using absent)) (sep0).2.1 (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_boundaryall_unequal_bar_short_check_pruned_node007 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n006_o6 a b jx jy (ap1_4).2.1 (sep6).2.2.1 (hstrict) (sep3).2.1 (hit) (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n006_o7 a b jx jy (hstrict) (insideT) (sep3).2.2.1 (sep6).2.1 (hit) (hb) (allowed)

theorem HP_boundaryall_unequal_bar_short_check_pruned_node004 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_bar_short_check_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_bar_short_check_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht2 : world (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b))
    (ht5 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b))
    (ap1_5 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b))
    (ap2_5 : Apart (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap3_4 : Apart (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b))
    (ap3_5 : Apart (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap4_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have in2 := inside (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht4
  have in5 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have allowed2 := avoid (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht4
  have allowed5 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht5
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht5
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht5
  have pairAllowed2_3 := avoidPair (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2 ht5
  have pairAllowed3_4 := avoidPair (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht3 ht5
  have pairAllowed4_5 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht4 ht5
  have support : HP_boundaryall_unequal_bar_short_check_pruned_Box a b (3 : Int) ((3 : Int) + b) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n004_point a b (hb) ((by simpa only [HP_boundaryall_unequal_bar_short_check_pruned_Box,HP_boundaryall_unequal_bar_short_check_pruned_M] using absent)) (hstrict)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) ((3 : Int) + b) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) ((3 : Int) + b) ∨ Contains (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (3 : Int) ((3 : Int) + b) ∨ Contains (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (3 : Int) ((3 : Int) + b) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) (3 : Int) ((3 : Int) + b) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (3 : Int) ((3 : Int) + b)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n004_empty a b ((by simpa only [Contains] using occupied)) (hb) (ap1_4).2.1
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) ((3 : Int) + b) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht5
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n004_o0 a b jx jy (hstrict) (hb) (hit) (sep3).2.2.2 (sep4).2.1 (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n004_o1 a b jx jy (hb) (ap1_4).2.1 (allowed) (hstrict) (hit) (insideT) (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) (0 : Int) a b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n004_o2 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (sep4).2.1 (hb) (ap1_4).2.1 (sep1).2.1 (hstrict) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_boundaryall_unequal_bar_short_check_pruned_node005 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n004_o3 a b jx jy (hb) (sep0).2.2.1 (hstrict) (sep4).2.2.1 (sep1).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n004_o4 a b jx jy (hb) (hstrict) (allowed) (insideT) (hit) (ap1_4).2.1 (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) ((3 : Int) + b) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n004_o5 a b jx jy (hstrict) ((by simpa only [Same,eq_comm] using absent)) (sep0).2.1 (hb) (sep4).2.1 (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_boundaryall_unequal_bar_short_check_pruned_node006 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n004_o6 a b jx jy (hb) (ap1_4).2.1 (sep1).2.2.1 (hit) (hstrict) (sep4).2.1 (sep3).2.2.2
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n004_o7 a b jx jy (hb) (sep3).2.2.2 (hit) (sep4).2.2.1 (hstrict) (sep4).2.1

theorem HP_boundaryall_unequal_bar_short_check_pruned_node003 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_bar_short_check_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_bar_short_check_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht2 : world (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have in2 := inside (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have allowed2 := avoid (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht3 ht4
  have support : HP_boundaryall_unequal_bar_short_check_pruned_Box a b ((1 : Int) + b) (0 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n003_point a b (hstrict) ((by simpa only [HP_boundaryall_unequal_bar_short_check_pruned_Box,HP_boundaryall_unequal_bar_short_check_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((1 : Int) + b) (0 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ((1 : Int) + b) (0 : Int) ∨ Contains (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((1 : Int) + b) (0 : Int) ∨ Contains (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ((1 : Int) + b) (0 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ((1 : Int) + b) (0 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n003_empty a b ((by simpa only [Contains] using occupied)) (hlong) (hb)
  obtain ⟨t,ht,hit⟩ := cover ((1 : Int) + b) (0 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n003_o0 a b jx jy (hstrict) (hb) (insideT) (hit) (sep0).1 (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n003_o1 a b jx jy (hstrict) (allowed) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n003_o2 a b jx jy (hb) (allowed) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n003_o3 a b jx jy (sep3).2.2.1 (hstrict) (hb) (ap1_4).2.1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n003_o4 a b jx jy (allowed) (hit) (hstrict) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n003_o5 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hit) (insideT) (hstrict) (hb) (sep0).1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_boundaryall_unequal_bar_short_check_pruned_node004 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n003_o6 a b jx jy (insideT) (ap1_4).2.1 (sep4).2.2.1 (hb) (hstrict) (hit) (sep0).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n003_o7 a b jx jy (allowed) (hb) (insideT) (hit)

theorem HP_boundaryall_unequal_bar_short_check_pruned_node002 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_bar_short_check_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_bar_short_check_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht2 : world (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have in2 := inside (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have allowed2 := avoid (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have support : HP_boundaryall_unequal_bar_short_check_pruned_Box a b (2 : Int) ((2 : Int) + b) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n002_point a b (hlong) (hb) ((by simpa only [HP_boundaryall_unequal_bar_short_check_pruned_Box,HP_boundaryall_unequal_bar_short_check_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (2 : Int) ((2 : Int) + b) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (2 : Int) ((2 : Int) + b) ∨ Contains (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (2 : Int) ((2 : Int) + b) ∨ Contains (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (2 : Int) ((2 : Int) + b)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n002_empty a b (hb) (ap1_3).2.1 ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) ((2 : Int) + b) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n002_o0 a b jx jy (hlong) (ap1_3).2.1 (hb) (hit) (sep1).2.1 (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n002_o1 a b jx jy (hlong) (allowed) (hb) (ap1_3).2.1 (hit) (sep1).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n002_o2 a b jx jy (sep0).2.1 (hb) (sep1).2.2.1 (sep3).2.1 (hit) (ap1_3).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n002_o3 a b jx jy (sep0).2.1 (hb) (hit) (sep3).2.1 (hlong) (ap1_3).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n002_o4 a b jx jy (ap1_3).2.1 (insideT) (hit) (allowed) (sep1).2.2.1 (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n002_o5 a b jx jy (ap1_3).2.1 (hlong) (hit) (hb) (sep1).2.1 (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n002_o6 a b jx jy (sep2).2.2.1 (hlong) (sep1).2.1 (ap1_3).2.1 (hb) (sep3).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (2 : Int) ((2 : Int) + ((2 : Int) * b)) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n002_o7 a b jx jy (hb) (ap1_3).2.1 ((by simpa only [Same,eq_comm] using absent)) (hit) (sep2).2.2.2 (sep1).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_boundaryall_unequal_bar_short_check_pruned_node003 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)

theorem HP_boundaryall_unequal_bar_short_check_pruned_node008 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_bar_short_check_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_bar_short_check_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht2 : world (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have in2 := inside (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have allowed2 := avoid (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht2 ht3
  have support : HP_boundaryall_unequal_bar_short_check_pruned_Box a b (3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n008_point a b (hb) (hlong) ((by simpa only [HP_boundaryall_unequal_bar_short_check_pruned_Box,HP_boundaryall_unequal_bar_short_check_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n008_empty a b (hlong) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n008_o0 a b jx jy (hit) (sep1).2.2.1 (sep3).2.1 (sep2).2.1 (hb) (sep3).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n008_o1 a b jx jy (insideT) (hit) (sep1).2.2.1 (allowed) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n008_o2 a b jx jy (hb) (hit) (sep0).2.1 (sep1).2.2.1 (hlong) (insideT) (allowed)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n008_o3 a b jx jy (sep2).2.1 (hlong) (insideT) (hb) (sep0).2.1 (hit) (sep3).2.2.2
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n008_o4 a b jx jy (allowed) (sep1).2.2.1 (hit) (hb) (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n008_o5 a b jx jy (hstrict) (hb) (sep3).2.1 (insideT) (sep0).2.1 (sep2).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n008_o6 a b jx jy (sep0).2.1 (hlong) (hit) (sep1).2.2.1 (hb) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n008_o7 a b jx jy (hb) (sep3).2.1 (hlong) (hit) (sep1).2.2.1 (insideT) (allowed)

theorem HP_boundaryall_unequal_bar_short_check_pruned_node010 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_bar_short_check_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_bar_short_check_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht2 : world (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ht4 : world (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_4 : Apart (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap3_4 : Apart (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have in2 := inside (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3
  have in4 := inside (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have allowed2 := avoid (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht3 ht4
  have support : HP_boundaryall_unequal_bar_short_check_pruned_Box a b (3 : Int) (4 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n010_point a b ((by simpa only [HP_boundaryall_unequal_bar_short_check_pruned_Box,HP_boundaryall_unequal_bar_short_check_pruned_M] using absent)) (hb) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (4 : Int) ∨ Contains (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (4 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (4 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n010_empty a b (hb) ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (4 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n010_o0 a b jx jy (hit) (hb) (sep2).2.2.1 (hlong) (sep3).2.1 (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n010_o1 a b jx jy (hb) (hit) (hlong) (insideT) (sep1).2.2.1 (allowed)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n010_o2 a b jx jy (hlong) (sep1).2.2.1 (hb) (hit) (sep3).2.2.1 (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n010_o3 a b jx jy (sep2).2.1 (hit) (hlong) (sep4).2.2.1 (hb) (sep4).2.2.2
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n010_o4 a b jx jy (insideT) (hlong) (hit) (allowed) (sep1).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n010_o5 a b jx jy (sep0).2.1 (insideT) (hit) (sep2).2.1 (hlong) (hb) (sep3).2.2.2
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n010_o6 a b jx jy (sep2).2.1 (hlong) (sep1).2.2.1 (hit) (hb) (sep0).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n010_o7 a b jx jy (hit) (hb) (hlong) (sep2).2.2.1 (sep4).2.1 (sep1).2.1 (sep1).2.2.1

theorem HP_boundaryall_unequal_bar_short_check_pruned_node011 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_bar_short_check_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_bar_short_check_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht2 : world (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ht4 : world (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_4 : Apart (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have in2 := inside (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3
  have in4 := inside (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have allowed2 := avoid (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht3 ht4
  have support : HP_boundaryall_unequal_bar_short_check_pruned_Box a b (4 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n011_point a b (hlong) (hb) ((by simpa only [HP_boundaryall_unequal_bar_short_check_pruned_Box,HP_boundaryall_unequal_bar_short_check_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) (4 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n011_empty a b (hlong) (hb) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n011_o0 a b jx jy (hlong) (sep4).2.1 (sep3).2.1 (hb) (sep3).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n011_o1 a b jx jy (sep4).2.2.1 (hb) (hlong) (insideT) (ap1_4).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n011_o2 a b jx jy (allowed) (hlong) (hb) (hit) (insideT) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n011_o3 a b jx jy (hit) (sep4).2.2.1 (insideT) (hlong) (ap1_4).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n011_o4 a b jx jy (insideT) (sep4).2.2.1 (ap1_4).2.1 (hlong) (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n011_o5 a b jx jy (hb) (hit) (sep3).2.1 (sep2).2.1 (hlong) (insideT) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n011_o6 a b jx jy (sep4).2.1 (hit) (hlong) (ap1_4).2.1 (hb) (sep4).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n011_o7 a b jx jy (hlong) (sep3).2.1 (sep4).2.2.1 (insideT) (allowed) (hb) (hit)

theorem HP_boundaryall_unequal_bar_short_check_pruned_node009 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_bar_short_check_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_bar_short_check_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht2 : world (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have in2 := inside (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have allowed2 := avoid (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht3
  have support : HP_boundaryall_unequal_bar_short_check_pruned_Box a b (3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n009_point a b ((by simpa only [HP_boundaryall_unequal_bar_short_check_pruned_Box,HP_boundaryall_unequal_bar_short_check_pruned_M] using absent)) (hb) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n009_empty a b (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n009_o0 a b jx jy (sep2).2.2.1 (hit) (sep3).2.1 (sep2).2.1 (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n009_o1 a b jx jy (sep1).2.2.1 (insideT) (hit) (allowed) (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n009_o2 a b jx jy (allowed) (sep0).2.1 (hlong) (insideT) (hb) (hit) (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n009_o3 a b jx jy (sep0).2.1 ((by simpa only [Same,eq_comm] using absent)) (sep2).2.1 (hit) (hb) (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_boundaryall_unequal_bar_short_check_pruned_node010 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n009_o4 a b jx jy (sep1).2.2.1 (hlong) (allowed) (hb) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n009_o5 a b jx jy (sep3).2.2.2 (hlong) (sep2).2.1 (insideT) (sep0).2.1 (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n009_o6 a b jx jy (sep1).2.2.1 (hlong) (hb) (sep3).2.2.1 (sep0).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (3 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n009_o7 a b jx jy (hit) (insideT) (hb) (allowed) (sep3).2.1 ((by simpa only [Same,eq_comm] using absent)) (hlong)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_boundaryall_unequal_bar_short_check_pruned_node011 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)

theorem HP_boundaryall_unequal_bar_short_check_pruned_node013 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_bar_short_check_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_bar_short_check_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht2 : world (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ht4 : world (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_4 : Apart (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap3_4 : Apart (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have in2 := inside (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have in4 := inside (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have allowed2 := avoid (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have allowed4 := avoid (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3 ht4
  have support : HP_boundaryall_unequal_bar_short_check_pruned_Box a b (4 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n013_point a b (hlong) (hb) ((by simpa only [HP_boundaryall_unequal_bar_short_check_pruned_Box,HP_boundaryall_unequal_bar_short_check_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n013_empty a b (hb) (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n013_o0 a b jx jy (hb) (sep3).2.2.1 (hlong) (sep2).2.2.1 (hit) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n013_o1 a b jx jy (hit) (allowed) (hlong) (insideT) (sep1).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n013_o2 a b jx jy (sep3).2.2.1 (hlong) (hit) (sep4).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n013_o3 a b jx jy (hlong) (ap1_3).2.1 (insideT) (hit) (sep3).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n013_o4 a b jx jy (insideT) (allowed) (sep1).2.2.1 (hit) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n013_o5 a b jx jy (sep0).2.1 (hit) (hlong) (sep3).2.1 (insideT) (sep4).2.2.2 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n013_o6 a b jx jy (sep1).2.2.1 (sep3).2.1 (hb) (hit) (hlong) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n013_o7 a b jx jy (hlong) (hb) (allowed) (sep2).2.2.1 (sep3).2.2.1 (hit) (insideT)

theorem HP_boundaryall_unequal_bar_short_check_pruned_node012 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_bar_short_check_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_bar_short_check_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht2 : world (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have in2 := inside (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have allowed2 := avoid (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht3
  have support : HP_boundaryall_unequal_bar_short_check_pruned_Box a b (4 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n012_point a b (hb) ((by simpa only [HP_boundaryall_unequal_bar_short_check_pruned_Box,HP_boundaryall_unequal_bar_short_check_pruned_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (4 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n012_empty a b (hb) ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n012_o0 a b jx jy (sep3).2.1 (hlong) (hb) (sep2).2.2.1 (hit) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n012_o1 a b jx jy (hb) (hlong) (sep1).2.2.1 (allowed) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n012_o2 a b jx jy (hb) (hlong) (hit) (sep3).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n012_o3 a b jx jy (sep3).2.2.1 (hlong) (hb) (ap1_3).2.1 (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n012_o4 a b jx jy (hlong) (hb) (insideT) (hit) (allowed) (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n012_o5 a b jx jy (hb) (hit) (sep0).2.1 (hlong) (insideT) (sep3).2.1 ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_boundaryall_unequal_bar_short_check_pruned_node013 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n012_o6 a b jx jy (sep0).2.1 (hlong) (hb) (hit) (sep1).2.2.1 (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n012_o7 a b jx jy (insideT) (sep2).2.2.1 (hlong) (hit) (sep3).1 (hb)

theorem HP_boundaryall_unequal_bar_short_check_pruned_node001 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_bar_short_check_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_bar_short_check_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht2 : world (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have in2 := inside (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have allowed2 := avoid (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht2
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht2
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1 ht2
  have support : HP_boundaryall_unequal_bar_short_check_pruned_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n001_point a b (hb) (hlong) ((by simpa only [HP_boundaryall_unequal_bar_short_check_pruned_Box,HP_boundaryall_unequal_bar_short_check_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n001_empty a b (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht2
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n001_o0 a b jx jy (hlong) (hit) (hb) ((by simpa only [Same,eq_comm] using absent)) (sep2).2.2.1 (sep2).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_unequal_bar_short_check_pruned_node002 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n001_o1 a b jx jy (hb) (allowed) (hlong) (hit) (sep1).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n001_o2 a b jx jy (sep1).2.2.1 (sep0).2.1 (hlong) (insideT) (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n001_o3 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (sep2).2.1 (hb) (insideT) (sep0).2.1 (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_unequal_bar_short_check_pruned_node008 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n001_o4 a b jx jy (hlong) (allowed) (hb) (insideT) (hit) (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n001_o5 a b jx jy (hit) (hb) (sep0).2.1 (sep2).2.1 ((by simpa only [Same,eq_comm] using absent)) (hlong) (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_unequal_bar_short_check_pruned_node009 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n001_o6 a b jx jy (sep2).2.2.1 (hit) (hlong) (sep0).2.1 (hb) (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n001_o7 a b jx jy (hit) (insideT) ((by simpa only [Same,eq_comm] using absent)) (hlong) (hb) (sep2).2.2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_unequal_bar_short_check_pruned_node012 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)

theorem HP_boundaryall_unequal_bar_short_check_pruned_node014 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_bar_short_check_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_bar_short_check_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht2 : world (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have in2 := inside (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have allowed2 := avoid (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht2
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have support : HP_boundaryall_unequal_bar_short_check_pruned_Box a b (2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n014_point a b (hb) (hlong) ((by simpa only [HP_boundaryall_unequal_bar_short_check_pruned_Box,HP_boundaryall_unequal_bar_short_check_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (2 : Int) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) (2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n014_empty a b (hb) ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n014_o0 a b jx jy (hit) (sep1).2.1 (hstrict) (sep2).2.1 (sep2).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n014_o1 a b jx jy (hlong) (hb) (insideT) (hit) (sep1).2.2.1 (allowed)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n014_o2 a b jx jy (hit) (sep0).2.1 (sep1).2.2.1 (insideT) (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n014_o3 a b jx jy (hlong) (insideT) (hit) (sep2).2.2.2 (hb) (sep0).2.1 (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n014_o4 a b jx jy (sep1).2.2.1 (hit) (hlong) (insideT) (hb) (allowed)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n014_o5 a b jx jy (sep0).2.1 (hb) (hstrict) (insideT) (sep2).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n014_o6 a b jx jy (hlong) (hb) (hit) (sep0).2.2.1 (sep1).2.1 (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n014_o7 a b jx jy (hb) (hit) (sep2).2.1 (hstrict) (insideT)

theorem HP_boundaryall_unequal_bar_short_check_pruned_node016 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_bar_short_check_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_bar_short_check_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht2 : world (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have in2 := inside (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have allowed2 := avoid (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht2 ht3
  have support : HP_boundaryall_unequal_bar_short_check_pruned_Box a b (2 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n016_point a b (hb) ((by simpa only [HP_boundaryall_unequal_bar_short_check_pruned_Box,HP_boundaryall_unequal_bar_short_check_pruned_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (2 : Int) (3 : Int) ∨ Contains (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (2 : Int) (3 : Int) ∨ Contains (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (2 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n016_empty a b (hlong) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n016_o0 a b jx jy (sep1).2.1 (sep2).2.1 (sep0).1 (hit) (hlong) (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n016_o1 a b jx jy (hlong) (sep1).2.2.1 (allowed) (hb) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n016_o2 a b jx jy (hit) (sep0).2.1 (insideT) (hlong) (allowed) (sep1).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n016_o3 a b jx jy (hit) (hb) (sep1).2.1 (sep3).2.2.2 (sep3).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n016_o4 a b jx jy (allowed) (hb) (hlong) (sep1).2.2.1 (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n016_o5 a b jx jy (insideT) (hlong) (hb) (sep2).2.2.2 (sep0).2.1 (sep1).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n016_o6 a b jx jy (hit) (sep0).2.2.1 (hlong) (sep1).2.2.1 (hb) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n016_o7 a b jx jy (hlong) (allowed) (sep1).2.2.1 (sep3).2.1 (hit) (insideT) (hb)

theorem HP_boundaryall_unequal_bar_short_check_pruned_node017 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_bar_short_check_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_bar_short_check_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht2 : world (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have in2 := inside (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have allowed2 := avoid (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht3
  have support : HP_boundaryall_unequal_bar_short_check_pruned_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n017_point a b ((by simpa only [HP_boundaryall_unequal_bar_short_check_pruned_Box,HP_boundaryall_unequal_bar_short_check_pruned_M] using absent)) (hb) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n017_empty a b (hlong) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n017_o0 a b jx jy (sep2).2.2.1 (sep1).2.1 (hlong) (hit) (hb) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n017_o1 a b jx jy (allowed) (sep1).2.2.1 (hit) (insideT) (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n017_o2 a b jx jy (sep3).2.1 (hit) (hlong) (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n017_o3 a b jx jy (hit) (ap1_3).2.1 (hlong) (insideT) (sep3).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n017_o4 a b jx jy (hb) (insideT) (hit) (allowed) (sep1).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n017_o5 a b jx jy (insideT) (hlong) (hit) (sep2).2.1 (hb) (sep0).2.1 (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n017_o6 a b jx jy (hit) (hb) (hlong) (sep1).2.2.1 (sep0).2.2.1 (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n017_o7 a b jx jy (sep3).2.2.1 (sep2).2.1 (hlong) (insideT) (hit) (hb)

theorem HP_boundaryall_unequal_bar_short_check_pruned_node015 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_bar_short_check_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_bar_short_check_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht2 : world (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have in2 := inside (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have allowed2 := avoid (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht2
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have support : HP_boundaryall_unequal_bar_short_check_pruned_Box a b (2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n015_point a b (hb) (hlong) ((by simpa only [HP_boundaryall_unequal_bar_short_check_pruned_Box,HP_boundaryall_unequal_bar_short_check_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (2 : Int) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n015_empty a b (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n015_o0 a b jx jy (sep2).2.1 (hlong) (sep1).2.1 (hb) (sep2).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n015_o1 a b jx jy (hb) (hit) (hlong) (insideT) (allowed) (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n015_o2 a b jx jy (hit) (hb) (sep1).2.2.1 (insideT) (sep0).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n015_o3 a b jx jy (hit) (hlong) ((by simpa only [Same,eq_comm] using absent)) (sep2).2.2.1 (hb) (sep1).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_unequal_bar_short_check_pruned_node016 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n015_o4 a b jx jy (insideT) (sep1).2.2.1 (hlong) (allowed) (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n015_o5 a b jx jy (hb) (hit) (sep1).2.1 (insideT) (sep2).2.2.2 (sep0).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n015_o6 a b jx jy (hb) (hit) (hlong) (sep0).1 (sep1).2.1 (sep1).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n015_o7 a b jx jy (insideT) (hlong) (sep2).2.1 (hb) (hit) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_unequal_bar_short_check_pruned_node017 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)

theorem HP_boundaryall_unequal_bar_short_check_pruned_node019 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_bar_short_check_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_bar_short_check_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht2 : world (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ht3 : world (Cross.mk ((3 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk ((3 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have in2 := inside (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht2
  have in3 := inside (Cross.mk ((3 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have allowed2 := avoid (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht2
  have allowed3 := avoid (Cross.mk ((3 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk ((3 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht2 ht3
  have support : HP_boundaryall_unequal_bar_short_check_pruned_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n019_point a b ((by simpa only [HP_boundaryall_unequal_bar_short_check_pruned_Box,HP_boundaryall_unequal_bar_short_check_pruned_M] using absent)) (hb) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((3 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n019_empty a b (hb) (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((3 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((3 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n019_o0 a b jx jy (hlong) (hit) (hb) (sep2).2.1 (sep2).2.2.1 (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n019_o1 a b jx jy (hit) (sep1).2.2.1 (hb) (hlong) (allowed) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n019_o2 a b jx jy (insideT) (sep2).2.2.1 (hit) (allowed) (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n019_o3 a b jx jy (hb) (hit) (hstrict) (insideT) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n019_o4 a b jx jy (sep1).2.2.1 (allowed) (hlong) (insideT) (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n019_o5 a b jx jy (hb) (insideT) (sep0).2.1 (hlong) (hit) (sep3).2.2.2 (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n019_o6 a b jx jy (sep0).2.1 (hb) (hlong) (hit) (sep1).2.2.1 (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n019_o7 a b jx jy (hit) (hb) (insideT) (allowed) (sep2).2.2.1 (hlong)

theorem HP_boundaryall_unequal_bar_short_check_pruned_node018 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_bar_short_check_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_bar_short_check_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht2 : world (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have in2 := inside (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht2
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have allowed2 := avoid (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht2
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht2
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht2
  have support : HP_boundaryall_unequal_bar_short_check_pruned_Box a b (3 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n018_point a b (hlong) ((by simpa only [HP_boundaryall_unequal_bar_short_check_pruned_Box,HP_boundaryall_unequal_bar_short_check_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) (3 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n018_empty a b ((by simpa only [Contains] using occupied)) (hlong) (hb)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht ht2
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n018_o0 a b jx jy (sep2).2.1 (sep2).2.2.1 (hb) (sep0).2.2.1 (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n018_o1 a b jx jy (insideT) (sep1).2.2.1 (hit) (allowed) (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n018_o2 a b jx jy (insideT) (hb) (sep2).2.1 (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n018_o3 a b jx jy (hb) (hit) (hstrict) (insideT) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n018_o4 a b jx jy (hit) (hlong) (sep1).2.1 (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n018_o5 a b jx jy (insideT) (hlong) (sep2).2.1 ((by simpa only [Same,eq_comm] using absent)) (hb) (hit) (sep0).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_unequal_bar_short_check_pruned_node019 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n018_o6 a b jx jy (sep2).2.1 (hlong) (sep1).2.2.1 (sep0).2.2.1 (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n018_o7 a b jx jy (hit) (hb) (insideT) (sep2).2.2.1 (allowed) (hlong)

theorem HP_boundaryall_unequal_bar_short_check_pruned_node000 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_bar_short_check_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_bar_short_check_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht1
  have support : HP_boundaryall_unequal_bar_short_check_pruned_Box a b (2 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n000_point a b (hlong) (hb) ((by simpa only [HP_boundaryall_unequal_bar_short_check_pruned_Box,HP_boundaryall_unequal_bar_short_check_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (2 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (2 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n000_empty a b ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n000_o0 a b jx jy (sep0).2.2.1 (hit) (hb) ((by simpa only [Same,eq_comm] using absent)) (sep1).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_boundaryall_unequal_bar_short_check_pruned_node001 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n000_o1 a b jx jy (hb) (insideT) (hlong) (hit) (allowed) (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n000_o2 a b jx jy (hb) (hit) (insideT) (hlong) (sep0).2.1 (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + b) (1 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n000_o3 a b jx jy (hb) ((by simpa only [Same,eq_comm] using absent)) (hlong) (sep1).2.1 (sep0).2.1 (insideT) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_boundaryall_unequal_bar_short_check_pruned_node014 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n000_o4 a b jx jy (sep1).2.1 (hlong) (hb) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n000_o5 a b jx jy (insideT) (hlong) (hit) ((by simpa only [Same,eq_comm] using absent)) (sep1).2.1 (sep0).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_boundaryall_unequal_bar_short_check_pruned_node015 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n000_o6 a b jx jy (hit) (sep1).2.2.1 (hlong) (sep0).2.2.1 (sep1).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (2 : Int) ((1 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_bar_short_check_pruned_n000_o7 a b jx jy (insideT) (hit) (allowed) (hb) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_boundaryall_unequal_bar_short_check_pruned_node018 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)

theorem HP_boundaryall_unequal_bar_short_check_pruned_bounded_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_bar_short_check_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_bar_short_check_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (disjoint : ∀ t u x y, world t → world u → Contains t x y → Contains u x y → t=u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (anchor0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (anchor1 : world (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have sep : ∀ t u, world t → world u → t=u ∨ Apart t u := by
    intro t u ht hu
    by_cases eq : t=u
    · exact Or.inl eq
    · right
      apply TPlane.apart_of_no_common_nonnegative t u
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies t ht)
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies u hu)
      · intro x y hx hy; exact eq (disjoint t u x y ht hu hx hy)
  have rootap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases sep (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a) anchor0 anchor1 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  exact HP_boundaryall_unequal_bar_short_check_pruned_node000 a b ha hb hstrict hlong world copies inside cover sep avoid avoidPair anchor0 anchor1 rootap0_1

theorem HP_boundaryall_unequal_bar_short_check_pruned_anchored_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor0 : T.world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (anchor1 : T.world (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  have avoid : ∀ t, T.world t → ¬ForbiddenBoundaryTip a b t := by
    exact unequal_avoid_boundary_tips a b (by omega) (by omega) (by omega) T
  have avoidPair := avoid_same_boundary_bars a b (by omega) (by omega) (by omega) T
  apply HP_boundaryall_unequal_bar_short_check_pruned_bounded_obstruction a b ha hb hstrict hlong T.world T.copies ?_ ?_ T.disjoint avoid avoidPair anchor0 anchor1
  · intro t ht
    have nn := TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (T.copies t ht)
    exact T.inside t ht t.x (t.y-t.south) (by
      unfold Contains; unfold TPlane.Nonnegative at nn; right; omega)
  · intro x y h; exact T.cover x y h.2.1
theorem HP_boundaryall_unequal_bar_short_check_pruned_no_shifted_anchor (a b p : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor0 : T.world (shift p 0 (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int))))
    (anchor1 : T.world (shift p 0 (Cross.mk (1 : Int) ((1 : Int) + a) b (0 : Int) (0 : Int) a)))
    : False := by
  let U : Tiling a b 0 0 HalfPlane :=
    (T.translate (-p) 0).congr (by intro x y; simp only [HalfPlane,Int.sub_zero])
  apply HP_boundaryall_unequal_bar_short_check_pruned_anchored_obstruction a b ha hb hstrict hlong U
  · refine ⟨_,anchor0,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
  · refine ⟨_,anchor1,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
#print axioms HP_boundaryall_unequal_bar_short_check_pruned_no_shifted_anchor
#print axioms HP_boundaryall_unequal_bar_short_check_pruned_bounded_obstruction
end PolyominoFormal.LRegion

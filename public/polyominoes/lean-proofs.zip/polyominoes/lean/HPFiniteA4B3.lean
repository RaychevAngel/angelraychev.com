import HPFiniteA4B3Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
namespace THalfPlaneFinite
open CrossUnits PolyominoFormal

theorem hp4_3_node1170 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1170 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1170 ((8 : Int),(1 : Int)) hp4_3_branches1170 hp4_3_evidence1170 hp4_3_check1170 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1170,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1169 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1169 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1169 ((6 : Int),(1 : Int)) hp4_3_branches1169 hp4_3_evidence1169 hp4_3_check1169 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1169,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1168 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1168 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1168 ((6 : Int),(1 : Int)) hp4_3_branches1168 hp4_3_evidence1168 hp4_3_check1168 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1168,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1167 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1167 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1167 ((5 : Int),(1 : Int)) hp4_3_branches1167 hp4_3_evidence1167 hp4_3_check1167 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1167,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1166 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1166 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1166 ((7 : Int),(1 : Int)) hp4_3_branches1166 hp4_3_evidence1166 hp4_3_check1166 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1166,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node1167 T childKnown
  · exact hp4_3_node1168 T childKnown
  · exact hp4_3_node1169 T childKnown
  · exact hp4_3_node1170 T childKnown
theorem hp4_3_node1165 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1165 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1165 ((6 : Int),(1 : Int)) hp4_3_branches1165 hp4_3_evidence1165 hp4_3_check1165 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1165,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1164 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1164 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1164 ((6 : Int),(1 : Int)) hp4_3_branches1164 hp4_3_evidence1164 hp4_3_check1164 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1164,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1163 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1163 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1163 ((0 : Int),(2 : Int)) hp4_3_branches1163 hp4_3_evidence1163 hp4_3_check1163 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1163,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1162 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1162 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1162 ((2 : Int),(1 : Int)) hp4_3_branches1162 hp4_3_evidence1162 hp4_3_check1162 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1162,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1163 T childKnown
theorem hp4_3_node1161 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1161 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1161 ((3 : Int),(2 : Int)) hp4_3_branches1161 hp4_3_evidence1161 hp4_3_check1161 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1161,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1160 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1160 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1160 ((2 : Int),(2 : Int)) hp4_3_branches1160 hp4_3_evidence1160 hp4_3_check1160 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1160,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1159 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1159 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1159 ((3 : Int),(1 : Int)) hp4_3_branches1159 hp4_3_evidence1159 hp4_3_check1159 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1159,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node1160 T childKnown
  · exact hp4_3_node1161 T childKnown
  · exact hp4_3_node1162 T childKnown
theorem hp4_3_node1158 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1158 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1158 ((6 : Int),(1 : Int)) hp4_3_branches1158 hp4_3_evidence1158 hp4_3_check1158 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1158,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1159 T childKnown
theorem hp4_3_node1157 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1157 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1157 ((6 : Int),(1 : Int)) hp4_3_branches1157 hp4_3_evidence1157 hp4_3_check1157 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1157,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1156 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1156 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1156 ((5 : Int),(1 : Int)) hp4_3_branches1156 hp4_3_evidence1156 hp4_3_check1156 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1156,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node1157 T childKnown
  · exact hp4_3_node1158 T childKnown
  · exact hp4_3_node1164 T childKnown
  · exact hp4_3_node1165 T childKnown
theorem hp4_3_node1155 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1155 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1155 ((7 : Int),(1 : Int)) hp4_3_branches1155 hp4_3_evidence1155 hp4_3_check1155 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1155,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1154 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1154 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1154 ((7 : Int),(1 : Int)) hp4_3_branches1154 hp4_3_evidence1154 hp4_3_check1154 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1154,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1153 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1153 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1153 ((7 : Int),(0 : Int)) hp4_3_branches1153 hp4_3_evidence1153 hp4_3_check1153 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1153,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node1154 T childKnown
  · exact hp4_3_node1155 T childKnown
theorem hp4_3_node1152 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1152 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1152 ((5 : Int),(1 : Int)) hp4_3_branches1152 hp4_3_evidence1152 hp4_3_check1152 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1152,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1153 T childKnown
theorem hp4_3_node1151 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1151 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1151 ((0 : Int),(2 : Int)) hp4_3_branches1151 hp4_3_evidence1151 hp4_3_check1151 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1151,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1150 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1150 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1150 ((2 : Int),(1 : Int)) hp4_3_branches1150 hp4_3_evidence1150 hp4_3_check1150 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1150,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1151 T childKnown
theorem hp4_3_node1149 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1149 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1149 ((3 : Int),(2 : Int)) hp4_3_branches1149 hp4_3_evidence1149 hp4_3_check1149 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1149,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1148 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1148 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1148 ((2 : Int),(2 : Int)) hp4_3_branches1148 hp4_3_evidence1148 hp4_3_check1148 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1148,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1147 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1147 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1147 ((3 : Int),(1 : Int)) hp4_3_branches1147 hp4_3_evidence1147 hp4_3_check1147 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1147,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node1148 T childKnown
  · exact hp4_3_node1149 T childKnown
  · exact hp4_3_node1150 T childKnown
theorem hp4_3_node1146 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1146 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1146 ((7 : Int),(0 : Int)) hp4_3_branches1146 hp4_3_evidence1146 hp4_3_check1146 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1146,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1147 T childKnown
theorem hp4_3_node1145 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1145 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1145 ((5 : Int),(1 : Int)) hp4_3_branches1145 hp4_3_evidence1145 hp4_3_check1145 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1145,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1146 T childKnown
theorem hp4_3_node1144 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1144 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1144 ((5 : Int),(1 : Int)) hp4_3_branches1144 hp4_3_evidence1144 hp4_3_check1144 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1144,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1143 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1143 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1143 ((5 : Int),(1 : Int)) hp4_3_branches1143 hp4_3_evidence1143 hp4_3_check1143 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1143,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1142 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1142 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1142 ((6 : Int),(0 : Int)) hp4_3_branches1142 hp4_3_evidence1142 hp4_3_check1142 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1142,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node1143 T childKnown
  · exact hp4_3_node1144 T childKnown
  · exact hp4_3_node1145 T childKnown
  · exact hp4_3_node1152 T childKnown
  · exact hp4_3_node1156 T childKnown
  · exact hp4_3_node1166 T childKnown
theorem hp4_3_node1141 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1141 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1141 ((9 : Int),(1 : Int)) hp4_3_branches1141 hp4_3_evidence1141 hp4_3_check1141 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1141,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1140 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1140 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1140 ((7 : Int),(2 : Int)) hp4_3_branches1140 hp4_3_evidence1140 hp4_3_check1140 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1140,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1139 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1139 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1139 ((5 : Int),(2 : Int)) hp4_3_branches1139 hp4_3_evidence1139 hp4_3_check1139 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1139,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1138 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1138 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1138 ((8 : Int),(1 : Int)) hp4_3_branches1138 hp4_3_evidence1138 hp4_3_check1138 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1138,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node1139 T childKnown
  · exact hp4_3_node1140 T childKnown
  · exact hp4_3_node1141 T childKnown
theorem hp4_3_node1137 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1137 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1137 ((6 : Int),(0 : Int)) hp4_3_branches1137 hp4_3_evidence1137 hp4_3_check1137 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1137,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1138 T childKnown
theorem hp4_3_node1136 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1136 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1136 ((8 : Int),(1 : Int)) hp4_3_branches1136 hp4_3_evidence1136 hp4_3_check1136 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1136,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1135 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1135 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1135 ((8 : Int),(1 : Int)) hp4_3_branches1135 hp4_3_evidence1135 hp4_3_check1135 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1135,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1134 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1134 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1134 ((5 : Int),(2 : Int)) hp4_3_branches1134 hp4_3_evidence1134 hp4_3_check1134 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1134,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1133 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1133 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1133 ((4 : Int),(2 : Int)) hp4_3_branches1133 hp4_3_evidence1133 hp4_3_check1133 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1133,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node1134 T childKnown
  · exact hp4_3_node1135 T childKnown
  · exact hp4_3_node1136 T childKnown
theorem hp4_3_node1132 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1132 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1132 ((8 : Int),(1 : Int)) hp4_3_branches1132 hp4_3_evidence1132 hp4_3_check1132 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1132,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1131 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1131 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1131 ((4 : Int),(2 : Int)) hp4_3_branches1131 hp4_3_evidence1131 hp4_3_check1131 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1131,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1132 T childKnown
theorem hp4_3_node1130 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1130 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1130 ((0 : Int),(2 : Int)) hp4_3_branches1130 hp4_3_evidence1130 hp4_3_check1130 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1130,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1129 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1129 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1129 ((8 : Int),(1 : Int)) hp4_3_branches1129 hp4_3_evidence1129 hp4_3_check1129 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1129,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1128 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1128 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1128 ((8 : Int),(1 : Int)) hp4_3_branches1128 hp4_3_evidence1128 hp4_3_check1128 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1128,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1127 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1127 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1127 ((11 : Int),(1 : Int)) hp4_3_branches1127 hp4_3_evidence1127 hp4_3_check1127 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1127,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1126 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1126 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1126 ((11 : Int),(1 : Int)) hp4_3_branches1126 hp4_3_evidence1126 hp4_3_check1126 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1126,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1125 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1125 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1125 ((12 : Int),(0 : Int)) hp4_3_branches1125 hp4_3_evidence1125 hp4_3_check1125 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1125,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1124 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1124 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1124 ((12 : Int),(1 : Int)) hp4_3_branches1124 hp4_3_evidence1124 hp4_3_check1124 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1124,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1125 T childKnown
theorem hp4_3_node1123 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1123 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1123 ((11 : Int),(2 : Int)) hp4_3_branches1123 hp4_3_evidence1123 hp4_3_check1123 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1123,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node1124 T childKnown
  · exact hp4_3_node1126 T childKnown
  · exact hp4_3_node1127 T childKnown
theorem hp4_3_node1122 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1122 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1122 ((9 : Int),(1 : Int)) hp4_3_branches1122 hp4_3_evidence1122 hp4_3_check1122 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1122,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1123 T childKnown
theorem hp4_3_node1121 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1121 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1121 ((5 : Int),(2 : Int)) hp4_3_branches1121 hp4_3_evidence1121 hp4_3_check1121 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1121,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1122 T childKnown
theorem hp4_3_node1120 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1120 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1120 ((11 : Int),(1 : Int)) hp4_3_branches1120 hp4_3_evidence1120 hp4_3_check1120 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1120,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1119 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1119 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1119 ((11 : Int),(1 : Int)) hp4_3_branches1119 hp4_3_evidence1119 hp4_3_check1119 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1119,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1118 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1118 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1118 ((12 : Int),(0 : Int)) hp4_3_branches1118 hp4_3_evidence1118 hp4_3_check1118 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1118,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1117 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1117 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1117 ((12 : Int),(1 : Int)) hp4_3_branches1117 hp4_3_evidence1117 hp4_3_check1117 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1117,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1118 T childKnown
theorem hp4_3_node1116 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1116 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1116 ((11 : Int),(2 : Int)) hp4_3_branches1116 hp4_3_evidence1116 hp4_3_check1116 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1116,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node1117 T childKnown
  · exact hp4_3_node1119 T childKnown
  · exact hp4_3_node1120 T childKnown
theorem hp4_3_node1115 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1115 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1115 ((9 : Int),(1 : Int)) hp4_3_branches1115 hp4_3_evidence1115 hp4_3_check1115 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1115,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1116 T childKnown
theorem hp4_3_node1114 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1114 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1114 ((5 : Int),(2 : Int)) hp4_3_branches1114 hp4_3_evidence1114 hp4_3_check1114 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1114,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1115 T childKnown
theorem hp4_3_node1113 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1113 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1113 ((5 : Int),(2 : Int)) hp4_3_branches1113 hp4_3_evidence1113 hp4_3_check1113 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1113,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1112 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1112 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1112 ((4 : Int),(2 : Int)) hp4_3_branches1112 hp4_3_evidence1112 hp4_3_check1112 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1112,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node1113 T childKnown
  · exact hp4_3_node1114 T childKnown
  · exact hp4_3_node1121 T childKnown
  · exact hp4_3_node1128 T childKnown
  · exact hp4_3_node1129 T childKnown
theorem hp4_3_node1111 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1111 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1111 ((8 : Int),(1 : Int)) hp4_3_branches1111 hp4_3_evidence1111 hp4_3_check1111 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1111,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1110 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1110 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1110 ((8 : Int),(1 : Int)) hp4_3_branches1110 hp4_3_evidence1110 hp4_3_check1110 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1110,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1109 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1109 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1109 ((11 : Int),(1 : Int)) hp4_3_branches1109 hp4_3_evidence1109 hp4_3_check1109 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1109,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1108 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1108 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1108 ((11 : Int),(1 : Int)) hp4_3_branches1108 hp4_3_evidence1108 hp4_3_check1108 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1108,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1107 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1107 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1107 ((12 : Int),(0 : Int)) hp4_3_branches1107 hp4_3_evidence1107 hp4_3_check1107 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1107,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1106 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1106 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1106 ((12 : Int),(1 : Int)) hp4_3_branches1106 hp4_3_evidence1106 hp4_3_check1106 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1106,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1107 T childKnown
theorem hp4_3_node1105 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1105 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1105 ((11 : Int),(2 : Int)) hp4_3_branches1105 hp4_3_evidence1105 hp4_3_check1105 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1105,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node1106 T childKnown
  · exact hp4_3_node1108 T childKnown
  · exact hp4_3_node1109 T childKnown
theorem hp4_3_node1104 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1104 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1104 ((9 : Int),(1 : Int)) hp4_3_branches1104 hp4_3_evidence1104 hp4_3_check1104 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1104,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1105 T childKnown
theorem hp4_3_node1103 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1103 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1103 ((5 : Int),(2 : Int)) hp4_3_branches1103 hp4_3_evidence1103 hp4_3_check1103 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1103,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1104 T childKnown
theorem hp4_3_node1102 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1102 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1102 ((11 : Int),(1 : Int)) hp4_3_branches1102 hp4_3_evidence1102 hp4_3_check1102 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1102,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1101 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1101 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1101 ((11 : Int),(1 : Int)) hp4_3_branches1101 hp4_3_evidence1101 hp4_3_check1101 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1101,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1100 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1100 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1100 ((12 : Int),(0 : Int)) hp4_3_branches1100 hp4_3_evidence1100 hp4_3_check1100 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1100,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1099 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1099 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1099 ((12 : Int),(1 : Int)) hp4_3_branches1099 hp4_3_evidence1099 hp4_3_check1099 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1099,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1100 T childKnown
theorem hp4_3_node1098 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1098 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1098 ((11 : Int),(2 : Int)) hp4_3_branches1098 hp4_3_evidence1098 hp4_3_check1098 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1098,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node1099 T childKnown
  · exact hp4_3_node1101 T childKnown
  · exact hp4_3_node1102 T childKnown
theorem hp4_3_node1097 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1097 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1097 ((9 : Int),(1 : Int)) hp4_3_branches1097 hp4_3_evidence1097 hp4_3_check1097 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1097,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1098 T childKnown
theorem hp4_3_node1096 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1096 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1096 ((5 : Int),(2 : Int)) hp4_3_branches1096 hp4_3_evidence1096 hp4_3_check1096 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1096,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1097 T childKnown
theorem hp4_3_node1095 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1095 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1095 ((5 : Int),(2 : Int)) hp4_3_branches1095 hp4_3_evidence1095 hp4_3_check1095 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1095,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1094 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1094 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1094 ((4 : Int),(2 : Int)) hp4_3_branches1094 hp4_3_evidence1094 hp4_3_check1094 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1094,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node1095 T childKnown
  · exact hp4_3_node1096 T childKnown
  · exact hp4_3_node1103 T childKnown
  · exact hp4_3_node1110 T childKnown
  · exact hp4_3_node1111 T childKnown
theorem hp4_3_node1093 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1093 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1093 ((0 : Int),(2 : Int)) hp4_3_branches1093 hp4_3_evidence1093 hp4_3_check1093 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1093,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1094 T childKnown
theorem hp4_3_node1092 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1092 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1092 ((8 : Int),(1 : Int)) hp4_3_branches1092 hp4_3_evidence1092 hp4_3_check1092 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1092,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1091 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1091 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1091 ((8 : Int),(1 : Int)) hp4_3_branches1091 hp4_3_evidence1091 hp4_3_check1091 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1091,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1090 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1090 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1090 ((11 : Int),(1 : Int)) hp4_3_branches1090 hp4_3_evidence1090 hp4_3_check1090 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1090,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1089 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1089 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1089 ((11 : Int),(1 : Int)) hp4_3_branches1089 hp4_3_evidence1089 hp4_3_check1089 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1089,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1088 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1088 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1088 ((12 : Int),(0 : Int)) hp4_3_branches1088 hp4_3_evidence1088 hp4_3_check1088 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1088,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1087 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1087 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1087 ((12 : Int),(1 : Int)) hp4_3_branches1087 hp4_3_evidence1087 hp4_3_check1087 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1087,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1088 T childKnown
theorem hp4_3_node1086 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1086 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1086 ((11 : Int),(2 : Int)) hp4_3_branches1086 hp4_3_evidence1086 hp4_3_check1086 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1086,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node1087 T childKnown
  · exact hp4_3_node1089 T childKnown
  · exact hp4_3_node1090 T childKnown
theorem hp4_3_node1085 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1085 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1085 ((9 : Int),(1 : Int)) hp4_3_branches1085 hp4_3_evidence1085 hp4_3_check1085 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1085,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1086 T childKnown
theorem hp4_3_node1084 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1084 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1084 ((5 : Int),(2 : Int)) hp4_3_branches1084 hp4_3_evidence1084 hp4_3_check1084 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1084,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1085 T childKnown
theorem hp4_3_node1083 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1083 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1083 ((11 : Int),(1 : Int)) hp4_3_branches1083 hp4_3_evidence1083 hp4_3_check1083 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1083,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1082 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1082 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1082 ((11 : Int),(1 : Int)) hp4_3_branches1082 hp4_3_evidence1082 hp4_3_check1082 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1082,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1081 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1081 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1081 ((12 : Int),(0 : Int)) hp4_3_branches1081 hp4_3_evidence1081 hp4_3_check1081 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1081,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1080 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1080 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1080 ((12 : Int),(1 : Int)) hp4_3_branches1080 hp4_3_evidence1080 hp4_3_check1080 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1080,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1081 T childKnown
theorem hp4_3_node1079 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1079 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1079 ((11 : Int),(2 : Int)) hp4_3_branches1079 hp4_3_evidence1079 hp4_3_check1079 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1079,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node1080 T childKnown
  · exact hp4_3_node1082 T childKnown
  · exact hp4_3_node1083 T childKnown
theorem hp4_3_node1078 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1078 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1078 ((9 : Int),(1 : Int)) hp4_3_branches1078 hp4_3_evidence1078 hp4_3_check1078 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1078,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1079 T childKnown
theorem hp4_3_node1077 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1077 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1077 ((5 : Int),(2 : Int)) hp4_3_branches1077 hp4_3_evidence1077 hp4_3_check1077 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1077,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1078 T childKnown
theorem hp4_3_node1076 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1076 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1076 ((5 : Int),(2 : Int)) hp4_3_branches1076 hp4_3_evidence1076 hp4_3_check1076 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1076,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1075 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1075 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1075 ((4 : Int),(2 : Int)) hp4_3_branches1075 hp4_3_evidence1075 hp4_3_check1075 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1075,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node1076 T childKnown
  · exact hp4_3_node1077 T childKnown
  · exact hp4_3_node1084 T childKnown
  · exact hp4_3_node1091 T childKnown
  · exact hp4_3_node1092 T childKnown
theorem hp4_3_node1074 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1074 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1074 ((0 : Int),(2 : Int)) hp4_3_branches1074 hp4_3_evidence1074 hp4_3_check1074 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1074,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1075 T childKnown
theorem hp4_3_node1073 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1073 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1073 ((0 : Int),(1 : Int)) hp4_3_branches1073 hp4_3_evidence1073 hp4_3_check1073 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1073,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node1074 T childKnown
  · exact hp4_3_node1093 T childKnown
  · exact hp4_3_node1112 T childKnown
  · exact hp4_3_node1130 T childKnown
theorem hp4_3_node1072 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1072 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1072 ((0 : Int),(1 : Int)) hp4_3_branches1072 hp4_3_evidence1072 hp4_3_check1072 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1072,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1071 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1071 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1071 ((8 : Int),(1 : Int)) hp4_3_branches1071 hp4_3_evidence1071 hp4_3_check1071 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1071,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1070 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1070 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1070 ((8 : Int),(1 : Int)) hp4_3_branches1070 hp4_3_evidence1070 hp4_3_check1070 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1070,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1069 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1069 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1069 ((11 : Int),(1 : Int)) hp4_3_branches1069 hp4_3_evidence1069 hp4_3_check1069 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1069,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1068 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1068 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1068 ((11 : Int),(1 : Int)) hp4_3_branches1068 hp4_3_evidence1068 hp4_3_check1068 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1068,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1067 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1067 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1067 ((12 : Int),(0 : Int)) hp4_3_branches1067 hp4_3_evidence1067 hp4_3_check1067 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1067,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1066 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1066 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1066 ((12 : Int),(1 : Int)) hp4_3_branches1066 hp4_3_evidence1066 hp4_3_check1066 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1066,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1067 T childKnown
theorem hp4_3_node1065 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1065 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1065 ((11 : Int),(2 : Int)) hp4_3_branches1065 hp4_3_evidence1065 hp4_3_check1065 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1065,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node1066 T childKnown
  · exact hp4_3_node1068 T childKnown
  · exact hp4_3_node1069 T childKnown
theorem hp4_3_node1064 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1064 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1064 ((9 : Int),(1 : Int)) hp4_3_branches1064 hp4_3_evidence1064 hp4_3_check1064 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1064,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1065 T childKnown
theorem hp4_3_node1063 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1063 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1063 ((5 : Int),(2 : Int)) hp4_3_branches1063 hp4_3_evidence1063 hp4_3_check1063 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1063,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1064 T childKnown
theorem hp4_3_node1062 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1062 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1062 ((11 : Int),(1 : Int)) hp4_3_branches1062 hp4_3_evidence1062 hp4_3_check1062 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1062,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1061 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1061 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1061 ((11 : Int),(1 : Int)) hp4_3_branches1061 hp4_3_evidence1061 hp4_3_check1061 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1061,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1060 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1060 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1060 ((12 : Int),(0 : Int)) hp4_3_branches1060 hp4_3_evidence1060 hp4_3_check1060 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1060,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1059 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1059 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1059 ((12 : Int),(1 : Int)) hp4_3_branches1059 hp4_3_evidence1059 hp4_3_check1059 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1059,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1060 T childKnown
theorem hp4_3_node1058 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1058 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1058 ((11 : Int),(2 : Int)) hp4_3_branches1058 hp4_3_evidence1058 hp4_3_check1058 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1058,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node1059 T childKnown
  · exact hp4_3_node1061 T childKnown
  · exact hp4_3_node1062 T childKnown
theorem hp4_3_node1057 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1057 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1057 ((9 : Int),(1 : Int)) hp4_3_branches1057 hp4_3_evidence1057 hp4_3_check1057 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1057,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1058 T childKnown
theorem hp4_3_node1056 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1056 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1056 ((5 : Int),(2 : Int)) hp4_3_branches1056 hp4_3_evidence1056 hp4_3_check1056 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1056,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1057 T childKnown
theorem hp4_3_node1055 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1055 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1055 ((11 : Int),(1 : Int)) hp4_3_branches1055 hp4_3_evidence1055 hp4_3_check1055 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1055,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1054 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1054 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1054 ((11 : Int),(1 : Int)) hp4_3_branches1054 hp4_3_evidence1054 hp4_3_check1054 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1054,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1053 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1053 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1053 ((12 : Int),(0 : Int)) hp4_3_branches1053 hp4_3_evidence1053 hp4_3_check1053 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1053,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1052 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1052 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1052 ((12 : Int),(1 : Int)) hp4_3_branches1052 hp4_3_evidence1052 hp4_3_check1052 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1052,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1053 T childKnown
theorem hp4_3_node1051 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1051 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1051 ((11 : Int),(2 : Int)) hp4_3_branches1051 hp4_3_evidence1051 hp4_3_check1051 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1051,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node1052 T childKnown
  · exact hp4_3_node1054 T childKnown
  · exact hp4_3_node1055 T childKnown
theorem hp4_3_node1050 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1050 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1050 ((9 : Int),(1 : Int)) hp4_3_branches1050 hp4_3_evidence1050 hp4_3_check1050 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1050,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1051 T childKnown
theorem hp4_3_node1049 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1049 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1049 ((8 : Int),(1 : Int)) hp4_3_branches1049 hp4_3_evidence1049 hp4_3_check1049 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1049,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1048 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1048 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1048 ((6 : Int),(2 : Int)) hp4_3_branches1048 hp4_3_evidence1048 hp4_3_check1048 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1048,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1049 T childKnown
theorem hp4_3_node1047 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1047 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1047 ((8 : Int),(1 : Int)) hp4_3_branches1047 hp4_3_evidence1047 hp4_3_check1047 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1047,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1046 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1046 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1046 ((5 : Int),(2 : Int)) hp4_3_branches1046 hp4_3_evidence1046 hp4_3_check1046 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1046,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node1047 T childKnown
  · exact hp4_3_node1048 T childKnown
  · exact hp4_3_node1050 T childKnown
theorem hp4_3_node1045 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1045 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1045 ((4 : Int),(2 : Int)) hp4_3_branches1045 hp4_3_evidence1045 hp4_3_check1045 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1045,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node1046 T childKnown
  · exact hp4_3_node1056 T childKnown
  · exact hp4_3_node1063 T childKnown
  · exact hp4_3_node1070 T childKnown
  · exact hp4_3_node1071 T childKnown
theorem hp4_3_node1044 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1044 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1044 ((0 : Int),(1 : Int)) hp4_3_branches1044 hp4_3_evidence1044 hp4_3_check1044 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1044,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1043 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1043 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1043 ((0 : Int),(2 : Int)) hp4_3_branches1043 hp4_3_evidence1043 hp4_3_check1043 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1043,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node1044 T childKnown
  · exact hp4_3_node1045 T childKnown
  · exact hp4_3_node1072 T childKnown
theorem hp4_3_node1042 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1042 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1042 ((2 : Int),(2 : Int)) hp4_3_branches1042 hp4_3_evidence1042 hp4_3_check1042 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1042,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node1043 T childKnown
  · exact hp4_3_node1073 T childKnown
  · exact hp4_3_node1131 T childKnown
  · exact hp4_3_node1133 T childKnown
theorem hp4_3_node1041 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1041 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1041 ((6 : Int),(0 : Int)) hp4_3_branches1041 hp4_3_evidence1041 hp4_3_check1041 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1041,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1042 T childKnown
theorem hp4_3_node1040 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1040 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1040 ((3 : Int),(1 : Int)) hp4_3_branches1040 hp4_3_evidence1040 hp4_3_check1040 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1040,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1039 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1039 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1039 ((3 : Int),(1 : Int)) hp4_3_branches1039 hp4_3_evidence1039 hp4_3_check1039 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1039,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1038 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1038 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1038 ((3 : Int),(2 : Int)) hp4_3_branches1038 hp4_3_evidence1038 hp4_3_check1038 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1038,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node1039 T childKnown
  · exact hp4_3_node1040 T childKnown
theorem hp4_3_node1037 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1037 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1037 ((6 : Int),(2 : Int)) hp4_3_branches1037 hp4_3_evidence1037 hp4_3_check1037 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1037,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1036 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1036 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1036 ((8 : Int),(2 : Int)) hp4_3_branches1036 hp4_3_evidence1036 hp4_3_check1036 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1036,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1037 T childKnown
theorem hp4_3_node1035 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1035 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1035 ((8 : Int),(2 : Int)) hp4_3_branches1035 hp4_3_evidence1035 hp4_3_check1035 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1035,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1034 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1034 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1034 ((6 : Int),(2 : Int)) hp4_3_branches1034 hp4_3_evidence1034 hp4_3_check1034 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1034,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1033 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1033 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1033 ((9 : Int),(1 : Int)) hp4_3_branches1033 hp4_3_evidence1033 hp4_3_check1033 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1033,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node1034 T childKnown
  · exact hp4_3_node1035 T childKnown
  · exact hp4_3_node1036 T childKnown
theorem hp4_3_node1032 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1032 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1032 ((6 : Int),(0 : Int)) hp4_3_branches1032 hp4_3_evidence1032 hp4_3_check1032 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1032,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1033 T childKnown
theorem hp4_3_node1031 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1031 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1031 ((8 : Int),(1 : Int)) hp4_3_branches1031 hp4_3_evidence1031 hp4_3_check1031 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1031,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1030 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1030 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1030 ((8 : Int),(1 : Int)) hp4_3_branches1030 hp4_3_evidence1030 hp4_3_check1030 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1030,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1029 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1029 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1029 ((7 : Int),(1 : Int)) hp4_3_branches1029 hp4_3_evidence1029 hp4_3_check1029 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1029,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node1030 T childKnown
  · exact hp4_3_node1031 T childKnown
theorem hp4_3_node1028 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1028 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1028 ((9 : Int),(2 : Int)) hp4_3_branches1028 hp4_3_evidence1028 hp4_3_check1028 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1028,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1027 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1027 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1027 ((9 : Int),(2 : Int)) hp4_3_branches1027 hp4_3_evidence1027 hp4_3_check1027 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1027,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1026 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1026 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1026 ((10 : Int),(2 : Int)) hp4_3_branches1026 hp4_3_evidence1026 hp4_3_check1026 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1026,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1025 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1025 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1025 ((10 : Int),(1 : Int)) hp4_3_branches1025 hp4_3_evidence1025 hp4_3_check1025 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1025,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1026 T childKnown
theorem hp4_3_node1024 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1024 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1024 ((9 : Int),(1 : Int)) hp4_3_branches1024 hp4_3_evidence1024 hp4_3_check1024 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1024,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node1025 T childKnown
  · exact hp4_3_node1027 T childKnown
  · exact hp4_3_node1028 T childKnown
theorem hp4_3_node1023 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1023 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1023 ((7 : Int),(1 : Int)) hp4_3_branches1023 hp4_3_evidence1023 hp4_3_check1023 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1023,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1024 T childKnown
theorem hp4_3_node1022 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1022 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1022 ((8 : Int),(1 : Int)) hp4_3_branches1022 hp4_3_evidence1022 hp4_3_check1022 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1022,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1021 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1021 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1021 ((8 : Int),(1 : Int)) hp4_3_branches1021 hp4_3_evidence1021 hp4_3_check1021 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1021,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1020 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1020 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1020 ((8 : Int),(0 : Int)) hp4_3_branches1020 hp4_3_evidence1020 hp4_3_check1020 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1020,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node1021 T childKnown
  · exact hp4_3_node1022 T childKnown
theorem hp4_3_node1019 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1019 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1019 ((14 : Int),(1 : Int)) hp4_3_branches1019 hp4_3_evidence1019 hp4_3_check1019 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1019,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1018 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1018 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1018 ((14 : Int),(1 : Int)) hp4_3_branches1018 hp4_3_evidence1018 hp4_3_check1018 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1018,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1017 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1017 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1017 ((14 : Int),(1 : Int)) hp4_3_branches1017 hp4_3_evidence1017 hp4_3_check1017 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1017,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1016 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1016 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1016 ((13 : Int),(1 : Int)) hp4_3_branches1016 hp4_3_evidence1016 hp4_3_check1016 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1016,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node1017 T childKnown
  · exact hp4_3_node1018 T childKnown
  · exact hp4_3_node1019 T childKnown
theorem hp4_3_node1015 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1015 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1015 ((14 : Int),(1 : Int)) hp4_3_branches1015 hp4_3_evidence1015 hp4_3_check1015 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1015,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1014 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1014 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1014 ((14 : Int),(1 : Int)) hp4_3_branches1014 hp4_3_evidence1014 hp4_3_check1014 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1014,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1013 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1013 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1013 ((13 : Int),(1 : Int)) hp4_3_branches1013 hp4_3_evidence1013 hp4_3_check1013 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1013,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node1014 T childKnown
  · exact hp4_3_node1015 T childKnown
theorem hp4_3_node1012 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1012 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1012 ((13 : Int),(1 : Int)) hp4_3_branches1012 hp4_3_evidence1012 hp4_3_check1012 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1012,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1011 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1011 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1011 ((13 : Int),(1 : Int)) hp4_3_branches1011 hp4_3_evidence1011 hp4_3_check1011 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1011,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1010 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1010 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1010 ((13 : Int),(1 : Int)) hp4_3_branches1010 hp4_3_evidence1010 hp4_3_check1010 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1010,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1009 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1009 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1009 ((14 : Int),(0 : Int)) hp4_3_branches1009 hp4_3_evidence1009 hp4_3_check1009 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1009,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node1010 T childKnown
  · exact hp4_3_node1011 T childKnown
  · exact hp4_3_node1012 T childKnown
  · exact hp4_3_node1013 T childKnown
  · exact hp4_3_node1016 T childKnown
theorem hp4_3_node1008 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1008 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1008 ((9 : Int),(2 : Int)) hp4_3_branches1008 hp4_3_evidence1008 hp4_3_check1008 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1008,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1007 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1007 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1007 ((9 : Int),(2 : Int)) hp4_3_branches1007 hp4_3_evidence1007 hp4_3_check1007 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1007,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1006 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1006 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1006 ((10 : Int),(2 : Int)) hp4_3_branches1006 hp4_3_evidence1006 hp4_3_check1006 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1006,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1005 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1005 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1005 ((9 : Int),(2 : Int)) hp4_3_branches1005 hp4_3_evidence1005 hp4_3_check1005 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1005,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1006 T childKnown
theorem hp4_3_node1004 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1004 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1004 ((8 : Int),(2 : Int)) hp4_3_branches1004 hp4_3_evidence1004 hp4_3_check1004 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1004,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node1005 T childKnown
  · exact hp4_3_node1007 T childKnown
  · exact hp4_3_node1008 T childKnown
  · exact hp4_3_node1009 T childKnown
theorem hp4_3_node1003 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1003 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1003 ((8 : Int),(0 : Int)) hp4_3_branches1003 hp4_3_evidence1003 hp4_3_check1003 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1003,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1004 T childKnown
theorem hp4_3_node1002 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1002 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1002 ((7 : Int),(0 : Int)) hp4_3_branches1002 hp4_3_evidence1002 hp4_3_check1002 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1002,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node1003 T childKnown
  · exact hp4_3_node1020 T childKnown
  · exact hp4_3_node1023 T childKnown
  · exact hp4_3_node1029 T childKnown
theorem hp4_3_node1001 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1001 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1001 ((3 : Int),(1 : Int)) hp4_3_branches1001 hp4_3_evidence1001 hp4_3_check1001 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1001,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node1002 T childKnown
  · exact hp4_3_node1032 T childKnown
theorem hp4_3_node1000 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1000 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1000 ((3 : Int),(2 : Int)) hp4_3_branches1000 hp4_3_evidence1000 hp4_3_check1000 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1000,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node999 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected999 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected999 ((3 : Int),(1 : Int)) hp4_3_branches999 hp4_3_evidence999 hp4_3_check999 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches999,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node1000 T childKnown
theorem hp4_3_node998 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected998 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected998 ((0 : Int),(1 : Int)) hp4_3_branches998 hp4_3_evidence998 hp4_3_check998 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches998,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node997 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected997 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected997 ((4 : Int),(2 : Int)) hp4_3_branches997 hp4_3_evidence997 hp4_3_check997 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches997,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node996 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected996 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected996 ((4 : Int),(2 : Int)) hp4_3_branches996 hp4_3_evidence996 hp4_3_check996 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches996,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node995 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected995 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected995 ((3 : Int),(2 : Int)) hp4_3_branches995 hp4_3_evidence995 hp4_3_check995 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches995,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node996 T childKnown
  · exact hp4_3_node997 T childKnown
theorem hp4_3_node994 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected994 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected994 ((6 : Int),(0 : Int)) hp4_3_branches994 hp4_3_evidence994 hp4_3_check994 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches994,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node995 T childKnown
theorem hp4_3_node993 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected993 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected993 ((4 : Int),(2 : Int)) hp4_3_branches993 hp4_3_evidence993 hp4_3_check993 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches993,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node992 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected992 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected992 ((3 : Int),(2 : Int)) hp4_3_branches992 hp4_3_evidence992 hp4_3_check992 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches992,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node993 T childKnown
theorem hp4_3_node991 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected991 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected991 ((6 : Int),(2 : Int)) hp4_3_branches991 hp4_3_evidence991 hp4_3_check991 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches991,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node990 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected990 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected990 ((5 : Int),(2 : Int)) hp4_3_branches990 hp4_3_evidence990 hp4_3_check990 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches990,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node991 T childKnown
theorem hp4_3_node989 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected989 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected989 ((6 : Int),(0 : Int)) hp4_3_branches989 hp4_3_evidence989 hp4_3_check989 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches989,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node990 T childKnown
theorem hp4_3_node988 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected988 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected988 ((3 : Int),(2 : Int)) hp4_3_branches988 hp4_3_evidence988 hp4_3_check988 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches988,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node989 T childKnown
theorem hp4_3_node987 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected987 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected987 ((4 : Int),(1 : Int)) hp4_3_branches987 hp4_3_evidence987 hp4_3_check987 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches987,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node986 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected986 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected986 ((4 : Int),(1 : Int)) hp4_3_branches986 hp4_3_evidence986 hp4_3_check986 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches986,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node985 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected985 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected985 ((4 : Int),(2 : Int)) hp4_3_branches985 hp4_3_evidence985 hp4_3_check985 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches985,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node986 T childKnown
  · exact hp4_3_node987 T childKnown
theorem hp4_3_node984 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected984 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected984 ((11 : Int),(1 : Int)) hp4_3_branches984 hp4_3_evidence984 hp4_3_check984 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches984,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node983 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected983 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected983 ((11 : Int),(1 : Int)) hp4_3_branches983 hp4_3_evidence983 hp4_3_check983 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches983,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node982 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected982 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected982 ((12 : Int),(0 : Int)) hp4_3_branches982 hp4_3_evidence982 hp4_3_check982 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches982,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node981 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected981 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected981 ((12 : Int),(1 : Int)) hp4_3_branches981 hp4_3_evidence981 hp4_3_check981 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches981,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node982 T childKnown
theorem hp4_3_node980 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected980 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected980 ((11 : Int),(2 : Int)) hp4_3_branches980 hp4_3_evidence980 hp4_3_check980 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches980,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node981 T childKnown
  · exact hp4_3_node983 T childKnown
  · exact hp4_3_node984 T childKnown
theorem hp4_3_node979 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected979 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected979 ((9 : Int),(2 : Int)) hp4_3_branches979 hp4_3_evidence979 hp4_3_check979 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches979,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node980 T childKnown
theorem hp4_3_node978 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected978 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected978 ((9 : Int),(2 : Int)) hp4_3_branches978 hp4_3_evidence978 hp4_3_check978 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches978,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node977 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected977 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected977 ((12 : Int),(0 : Int)) hp4_3_branches977 hp4_3_evidence977 hp4_3_check977 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches977,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node976 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected976 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected976 ((11 : Int),(2 : Int)) hp4_3_branches976 hp4_3_evidence976 hp4_3_check976 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches976,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node975 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected975 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected975 ((12 : Int),(0 : Int)) hp4_3_branches975 hp4_3_evidence975 hp4_3_check975 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches975,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node974 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected974 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected974 ((12 : Int),(0 : Int)) hp4_3_branches974 hp4_3_evidence974 hp4_3_check974 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches974,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node973 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected973 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected973 ((12 : Int),(1 : Int)) hp4_3_branches973 hp4_3_evidence973 hp4_3_check973 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches973,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node974 T childKnown
theorem hp4_3_node972 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected972 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected972 ((11 : Int),(1 : Int)) hp4_3_branches972 hp4_3_evidence972 hp4_3_check972 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches972,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node973 T childKnown
  · exact hp4_3_node975 T childKnown
  · exact hp4_3_node976 T childKnown
  · exact hp4_3_node977 T childKnown
theorem hp4_3_node971 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected971 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected971 ((11 : Int),(1 : Int)) hp4_3_branches971 hp4_3_evidence971 hp4_3_check971 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches971,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node970 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected970 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected970 ((11 : Int),(1 : Int)) hp4_3_branches970 hp4_3_evidence970 hp4_3_check970 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches970,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node969 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected969 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected969 ((12 : Int),(0 : Int)) hp4_3_branches969 hp4_3_evidence969 hp4_3_check969 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches969,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node968 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected968 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected968 ((12 : Int),(1 : Int)) hp4_3_branches968 hp4_3_evidence968 hp4_3_check968 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches968,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node969 T childKnown
theorem hp4_3_node967 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected967 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected967 ((11 : Int),(2 : Int)) hp4_3_branches967 hp4_3_evidence967 hp4_3_check967 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches967,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node968 T childKnown
  · exact hp4_3_node970 T childKnown
  · exact hp4_3_node971 T childKnown
theorem hp4_3_node966 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected966 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected966 ((9 : Int),(2 : Int)) hp4_3_branches966 hp4_3_evidence966 hp4_3_check966 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches966,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node967 T childKnown
  · exact hp4_3_node972 T childKnown
theorem hp4_3_node965 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected965 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected965 ((12 : Int),(0 : Int)) hp4_3_branches965 hp4_3_evidence965 hp4_3_check965 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches965,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node964 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected964 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected964 ((11 : Int),(2 : Int)) hp4_3_branches964 hp4_3_evidence964 hp4_3_check964 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches964,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node963 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected963 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected963 ((12 : Int),(0 : Int)) hp4_3_branches963 hp4_3_evidence963 hp4_3_check963 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches963,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node962 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected962 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected962 ((12 : Int),(0 : Int)) hp4_3_branches962 hp4_3_evidence962 hp4_3_check962 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches962,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node961 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected961 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected961 ((12 : Int),(1 : Int)) hp4_3_branches961 hp4_3_evidence961 hp4_3_check961 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches961,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node962 T childKnown
theorem hp4_3_node960 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected960 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected960 ((11 : Int),(1 : Int)) hp4_3_branches960 hp4_3_evidence960 hp4_3_check960 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches960,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node961 T childKnown
  · exact hp4_3_node963 T childKnown
  · exact hp4_3_node964 T childKnown
  · exact hp4_3_node965 T childKnown
theorem hp4_3_node959 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected959 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected959 ((11 : Int),(1 : Int)) hp4_3_branches959 hp4_3_evidence959 hp4_3_check959 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches959,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node958 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected958 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected958 ((11 : Int),(1 : Int)) hp4_3_branches958 hp4_3_evidence958 hp4_3_check958 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches958,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node957 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected957 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected957 ((12 : Int),(0 : Int)) hp4_3_branches957 hp4_3_evidence957 hp4_3_check957 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches957,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node956 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected956 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected956 ((12 : Int),(1 : Int)) hp4_3_branches956 hp4_3_evidence956 hp4_3_check956 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches956,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node957 T childKnown
theorem hp4_3_node955 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected955 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected955 ((11 : Int),(2 : Int)) hp4_3_branches955 hp4_3_evidence955 hp4_3_check955 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches955,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node956 T childKnown
  · exact hp4_3_node958 T childKnown
  · exact hp4_3_node959 T childKnown
theorem hp4_3_node954 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected954 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected954 ((9 : Int),(2 : Int)) hp4_3_branches954 hp4_3_evidence954 hp4_3_check954 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches954,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node955 T childKnown
  · exact hp4_3_node960 T childKnown
theorem hp4_3_node953 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected953 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected953 ((7 : Int),(2 : Int)) hp4_3_branches953 hp4_3_evidence953 hp4_3_check953 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches953,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node954 T childKnown
  · exact hp4_3_node966 T childKnown
  · exact hp4_3_node978 T childKnown
  · exact hp4_3_node979 T childKnown
theorem hp4_3_node952 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected952 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected952 ((6 : Int),(0 : Int)) hp4_3_branches952 hp4_3_evidence952 hp4_3_check952 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches952,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node953 T childKnown
theorem hp4_3_node951 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected951 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected951 ((6 : Int),(0 : Int)) hp4_3_branches951 hp4_3_evidence951 hp4_3_check951 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches951,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node950 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected950 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected950 ((4 : Int),(1 : Int)) hp4_3_branches950 hp4_3_evidence950 hp4_3_check950 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches950,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node951 T childKnown
  · exact hp4_3_node952 T childKnown
theorem hp4_3_node949 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected949 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected949 ((3 : Int),(1 : Int)) hp4_3_branches949 hp4_3_evidence949 hp4_3_check949 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches949,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node950 T childKnown
  · exact hp4_3_node985 T childKnown
  · exact hp4_3_node988 T childKnown
  · exact hp4_3_node992 T childKnown
  · exact hp4_3_node994 T childKnown
theorem hp4_3_node948 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected948 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected948 ((0 : Int),(1 : Int)) hp4_3_branches948 hp4_3_evidence948 hp4_3_check948 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches948,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node947 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected947 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected947 ((0 : Int),(2 : Int)) hp4_3_branches947 hp4_3_evidence947 hp4_3_check947 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches947,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node948 T childKnown
  · exact hp4_3_node949 T childKnown
  · exact hp4_3_node998 T childKnown
theorem hp4_3_node946 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected946 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected946 ((0 : Int),(2 : Int)) hp4_3_branches946 hp4_3_evidence946 hp4_3_check946 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches946,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node945 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected945 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected945 ((0 : Int),(2 : Int)) hp4_3_branches945 hp4_3_evidence945 hp4_3_check945 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches945,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node944 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected944 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected944 ((0 : Int),(1 : Int)) hp4_3_branches944 hp4_3_evidence944 hp4_3_check944 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches944,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node945 T childKnown
  · exact hp4_3_node946 T childKnown
theorem hp4_3_node943 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected943 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected943 ((2 : Int),(1 : Int)) hp4_3_branches943 hp4_3_evidence943 hp4_3_check943 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches943,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node944 T childKnown
  · exact hp4_3_node947 T childKnown
  · exact hp4_3_node999 T childKnown
  · exact hp4_3_node1001 T childKnown
  · exact hp4_3_node1038 T childKnown
  · exact hp4_3_node1041 T childKnown
  · exact hp4_3_node1137 T childKnown
theorem hp4_3_node942 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected942 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected942 ((1 : Int),(1 : Int)) hp4_3_branches942 hp4_3_evidence942 hp4_3_check942 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches942,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node941 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected941 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected941 ((1 : Int),(1 : Int)) hp4_3_branches941 hp4_3_evidence941 hp4_3_check941 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches941,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node940 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected940 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected940 ((1 : Int),(0 : Int)) hp4_3_branches940 hp4_3_evidence940 hp4_3_check940 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches940,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node941 T childKnown
  · exact hp4_3_node942 T childKnown
theorem hp4_3_node939 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected939 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected939 ((7 : Int),(1 : Int)) hp4_3_branches939 hp4_3_evidence939 hp4_3_check939 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches939,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node938 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected938 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected938 ((7 : Int),(1 : Int)) hp4_3_branches938 hp4_3_evidence938 hp4_3_check938 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches938,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node937 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected937 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected937 ((7 : Int),(1 : Int)) hp4_3_branches937 hp4_3_evidence937 hp4_3_check937 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches937,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node936 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected936 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected936 ((6 : Int),(1 : Int)) hp4_3_branches936 hp4_3_evidence936 hp4_3_check936 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches936,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node937 T childKnown
  · exact hp4_3_node938 T childKnown
  · exact hp4_3_node939 T childKnown
theorem hp4_3_node935 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected935 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected935 ((7 : Int),(1 : Int)) hp4_3_branches935 hp4_3_evidence935 hp4_3_check935 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches935,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node934 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected934 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected934 ((7 : Int),(1 : Int)) hp4_3_branches934 hp4_3_evidence934 hp4_3_check934 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches934,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node933 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected933 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected933 ((6 : Int),(1 : Int)) hp4_3_branches933 hp4_3_evidence933 hp4_3_check933 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches933,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node934 T childKnown
  · exact hp4_3_node935 T childKnown
theorem hp4_3_node932 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected932 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected932 ((6 : Int),(1 : Int)) hp4_3_branches932 hp4_3_evidence932 hp4_3_check932 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches932,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node931 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected931 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected931 ((6 : Int),(1 : Int)) hp4_3_branches931 hp4_3_evidence931 hp4_3_check931 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches931,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node930 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected930 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected930 ((6 : Int),(1 : Int)) hp4_3_branches930 hp4_3_evidence930 hp4_3_check930 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches930,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node929 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected929 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected929 ((7 : Int),(0 : Int)) hp4_3_branches929 hp4_3_evidence929 hp4_3_check929 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches929,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node930 T childKnown
  · exact hp4_3_node931 T childKnown
  · exact hp4_3_node932 T childKnown
  · exact hp4_3_node933 T childKnown
  · exact hp4_3_node936 T childKnown
theorem hp4_3_node928 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected928 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected928 ((2 : Int),(2 : Int)) hp4_3_branches928 hp4_3_evidence928 hp4_3_check928 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches928,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node927 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected927 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected927 ((2 : Int),(2 : Int)) hp4_3_branches927 hp4_3_evidence927 hp4_3_check927 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches927,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node926 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected926 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected926 ((3 : Int),(2 : Int)) hp4_3_branches926 hp4_3_evidence926 hp4_3_check926 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches926,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node925 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected925 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected925 ((2 : Int),(2 : Int)) hp4_3_branches925 hp4_3_evidence925 hp4_3_check925 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches925,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node926 T childKnown
theorem hp4_3_node924 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected924 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected924 ((1 : Int),(2 : Int)) hp4_3_branches924 hp4_3_evidence924 hp4_3_check924 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches924,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node925 T childKnown
  · exact hp4_3_node927 T childKnown
  · exact hp4_3_node928 T childKnown
  · exact hp4_3_node929 T childKnown
theorem hp4_3_node923 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected923 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected923 ((1 : Int),(0 : Int)) hp4_3_branches923 hp4_3_evidence923 hp4_3_check923 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches923,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node924 T childKnown
theorem hp4_3_node922 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected922 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected922 ((1 : Int),(1 : Int)) hp4_3_branches922 hp4_3_evidence922 hp4_3_check922 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches922,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node921 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected921 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected921 ((1 : Int),(0 : Int)) hp4_3_branches921 hp4_3_evidence921 hp4_3_check921 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches921,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node922 T childKnown
theorem hp4_3_node920 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected920 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected920 ((7 : Int),(1 : Int)) hp4_3_branches920 hp4_3_evidence920 hp4_3_check920 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches920,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node919 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected919 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected919 ((5 : Int),(1 : Int)) hp4_3_branches919 hp4_3_evidence919 hp4_3_check919 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches919,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node918 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected918 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected918 ((5 : Int),(1 : Int)) hp4_3_branches918 hp4_3_evidence918 hp4_3_check918 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches918,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node917 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected917 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected917 ((4 : Int),(1 : Int)) hp4_3_branches917 hp4_3_evidence917 hp4_3_check917 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches917,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node916 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected916 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected916 ((6 : Int),(1 : Int)) hp4_3_branches916 hp4_3_evidence916 hp4_3_check916 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches916,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node917 T childKnown
  · exact hp4_3_node918 T childKnown
  · exact hp4_3_node919 T childKnown
  · exact hp4_3_node920 T childKnown
theorem hp4_3_node915 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected915 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected915 ((5 : Int),(1 : Int)) hp4_3_branches915 hp4_3_evidence915 hp4_3_check915 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches915,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node914 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected914 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected914 ((5 : Int),(1 : Int)) hp4_3_branches914 hp4_3_evidence914 hp4_3_check914 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches914,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node913 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected913 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected913 ((0 : Int),(2 : Int)) hp4_3_branches913 hp4_3_evidence913 hp4_3_check913 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches913,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node912 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected912 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected912 ((1 : Int),(1 : Int)) hp4_3_branches912 hp4_3_evidence912 hp4_3_check912 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches912,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node913 T childKnown
theorem hp4_3_node911 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected911 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected911 ((2 : Int),(2 : Int)) hp4_3_branches911 hp4_3_evidence911 hp4_3_check911 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches911,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node910 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected910 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected910 ((1 : Int),(2 : Int)) hp4_3_branches910 hp4_3_evidence910 hp4_3_check910 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches910,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node909 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected909 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected909 ((2 : Int),(1 : Int)) hp4_3_branches909 hp4_3_evidence909 hp4_3_check909 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches909,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node910 T childKnown
  · exact hp4_3_node911 T childKnown
  · exact hp4_3_node912 T childKnown
theorem hp4_3_node908 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected908 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected908 ((5 : Int),(1 : Int)) hp4_3_branches908 hp4_3_evidence908 hp4_3_check908 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches908,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node909 T childKnown
theorem hp4_3_node907 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected907 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected907 ((5 : Int),(1 : Int)) hp4_3_branches907 hp4_3_evidence907 hp4_3_check907 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches907,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node906 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected906 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected906 ((4 : Int),(1 : Int)) hp4_3_branches906 hp4_3_evidence906 hp4_3_check906 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches906,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node907 T childKnown
  · exact hp4_3_node908 T childKnown
  · exact hp4_3_node914 T childKnown
  · exact hp4_3_node915 T childKnown
theorem hp4_3_node905 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected905 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected905 ((6 : Int),(1 : Int)) hp4_3_branches905 hp4_3_evidence905 hp4_3_check905 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches905,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node904 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected904 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected904 ((6 : Int),(1 : Int)) hp4_3_branches904 hp4_3_evidence904 hp4_3_check904 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches904,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node903 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected903 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected903 ((6 : Int),(0 : Int)) hp4_3_branches903 hp4_3_evidence903 hp4_3_check903 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches903,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node904 T childKnown
  · exact hp4_3_node905 T childKnown
theorem hp4_3_node902 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected902 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected902 ((4 : Int),(1 : Int)) hp4_3_branches902 hp4_3_evidence902 hp4_3_check902 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches902,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node903 T childKnown
theorem hp4_3_node901 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected901 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected901 ((0 : Int),(2 : Int)) hp4_3_branches901 hp4_3_evidence901 hp4_3_check901 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches901,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node900 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected900 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected900 ((1 : Int),(1 : Int)) hp4_3_branches900 hp4_3_evidence900 hp4_3_check900 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches900,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node901 T childKnown
theorem hp4_3_node899 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected899 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected899 ((2 : Int),(2 : Int)) hp4_3_branches899 hp4_3_evidence899 hp4_3_check899 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches899,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node898 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected898 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected898 ((1 : Int),(2 : Int)) hp4_3_branches898 hp4_3_evidence898 hp4_3_check898 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches898,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node897 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected897 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected897 ((2 : Int),(1 : Int)) hp4_3_branches897 hp4_3_evidence897 hp4_3_check897 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches897,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node898 T childKnown
  · exact hp4_3_node899 T childKnown
  · exact hp4_3_node900 T childKnown
theorem hp4_3_node896 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected896 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected896 ((6 : Int),(0 : Int)) hp4_3_branches896 hp4_3_evidence896 hp4_3_check896 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches896,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node897 T childKnown
theorem hp4_3_node895 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected895 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected895 ((4 : Int),(1 : Int)) hp4_3_branches895 hp4_3_evidence895 hp4_3_check895 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches895,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node896 T childKnown
theorem hp4_3_node894 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected894 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected894 ((4 : Int),(1 : Int)) hp4_3_branches894 hp4_3_evidence894 hp4_3_check894 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches894,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node893 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected893 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected893 ((4 : Int),(1 : Int)) hp4_3_branches893 hp4_3_evidence893 hp4_3_check893 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches893,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node892 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected892 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected892 ((5 : Int),(0 : Int)) hp4_3_branches892 hp4_3_evidence892 hp4_3_check892 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches892,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node893 T childKnown
  · exact hp4_3_node894 T childKnown
  · exact hp4_3_node895 T childKnown
  · exact hp4_3_node902 T childKnown
  · exact hp4_3_node906 T childKnown
  · exact hp4_3_node916 T childKnown
theorem hp4_3_node891 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected891 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected891 ((8 : Int),(1 : Int)) hp4_3_branches891 hp4_3_evidence891 hp4_3_check891 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches891,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node890 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected890 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected890 ((6 : Int),(2 : Int)) hp4_3_branches890 hp4_3_evidence890 hp4_3_check890 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches890,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node889 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected889 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected889 ((4 : Int),(2 : Int)) hp4_3_branches889 hp4_3_evidence889 hp4_3_check889 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches889,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node888 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected888 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected888 ((7 : Int),(1 : Int)) hp4_3_branches888 hp4_3_evidence888 hp4_3_check888 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches888,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node889 T childKnown
  · exact hp4_3_node890 T childKnown
  · exact hp4_3_node891 T childKnown
theorem hp4_3_node887 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected887 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected887 ((5 : Int),(0 : Int)) hp4_3_branches887 hp4_3_evidence887 hp4_3_check887 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches887,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node888 T childKnown
theorem hp4_3_node886 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected886 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected886 ((7 : Int),(1 : Int)) hp4_3_branches886 hp4_3_evidence886 hp4_3_check886 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches886,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node885 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected885 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected885 ((7 : Int),(1 : Int)) hp4_3_branches885 hp4_3_evidence885 hp4_3_check885 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches885,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node884 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected884 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected884 ((4 : Int),(2 : Int)) hp4_3_branches884 hp4_3_evidence884 hp4_3_check884 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches884,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node883 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected883 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected883 ((3 : Int),(2 : Int)) hp4_3_branches883 hp4_3_evidence883 hp4_3_check883 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches883,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node884 T childKnown
  · exact hp4_3_node885 T childKnown
  · exact hp4_3_node886 T childKnown
theorem hp4_3_node882 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected882 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected882 ((7 : Int),(1 : Int)) hp4_3_branches882 hp4_3_evidence882 hp4_3_check882 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches882,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node881 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected881 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected881 ((3 : Int),(2 : Int)) hp4_3_branches881 hp4_3_evidence881 hp4_3_check881 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches881,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node882 T childKnown
theorem hp4_3_node880 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected880 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected880 ((7 : Int),(1 : Int)) hp4_3_branches880 hp4_3_evidence880 hp4_3_check880 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches880,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node879 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected879 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected879 ((7 : Int),(1 : Int)) hp4_3_branches879 hp4_3_evidence879 hp4_3_check879 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches879,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node878 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected878 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected878 ((10 : Int),(1 : Int)) hp4_3_branches878 hp4_3_evidence878 hp4_3_check878 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches878,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node877 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected877 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected877 ((10 : Int),(1 : Int)) hp4_3_branches877 hp4_3_evidence877 hp4_3_check877 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches877,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node876 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected876 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected876 ((11 : Int),(0 : Int)) hp4_3_branches876 hp4_3_evidence876 hp4_3_check876 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches876,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node875 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected875 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected875 ((11 : Int),(1 : Int)) hp4_3_branches875 hp4_3_evidence875 hp4_3_check875 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches875,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node876 T childKnown
theorem hp4_3_node874 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected874 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected874 ((10 : Int),(2 : Int)) hp4_3_branches874 hp4_3_evidence874 hp4_3_check874 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches874,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node875 T childKnown
  · exact hp4_3_node877 T childKnown
  · exact hp4_3_node878 T childKnown
theorem hp4_3_node873 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected873 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected873 ((8 : Int),(1 : Int)) hp4_3_branches873 hp4_3_evidence873 hp4_3_check873 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches873,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node874 T childKnown
theorem hp4_3_node872 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected872 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected872 ((4 : Int),(2 : Int)) hp4_3_branches872 hp4_3_evidence872 hp4_3_check872 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches872,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node873 T childKnown
theorem hp4_3_node871 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected871 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected871 ((10 : Int),(1 : Int)) hp4_3_branches871 hp4_3_evidence871 hp4_3_check871 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches871,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node870 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected870 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected870 ((10 : Int),(1 : Int)) hp4_3_branches870 hp4_3_evidence870 hp4_3_check870 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches870,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node869 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected869 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected869 ((11 : Int),(0 : Int)) hp4_3_branches869 hp4_3_evidence869 hp4_3_check869 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches869,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node868 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected868 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected868 ((11 : Int),(1 : Int)) hp4_3_branches868 hp4_3_evidence868 hp4_3_check868 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches868,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node869 T childKnown
theorem hp4_3_node867 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected867 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected867 ((10 : Int),(2 : Int)) hp4_3_branches867 hp4_3_evidence867 hp4_3_check867 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches867,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node868 T childKnown
  · exact hp4_3_node870 T childKnown
  · exact hp4_3_node871 T childKnown
theorem hp4_3_node866 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected866 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected866 ((8 : Int),(1 : Int)) hp4_3_branches866 hp4_3_evidence866 hp4_3_check866 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches866,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node867 T childKnown
theorem hp4_3_node865 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected865 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected865 ((4 : Int),(2 : Int)) hp4_3_branches865 hp4_3_evidence865 hp4_3_check865 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches865,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node866 T childKnown
theorem hp4_3_node864 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected864 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected864 ((4 : Int),(2 : Int)) hp4_3_branches864 hp4_3_evidence864 hp4_3_check864 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches864,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node863 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected863 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected863 ((3 : Int),(2 : Int)) hp4_3_branches863 hp4_3_evidence863 hp4_3_check863 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches863,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node864 T childKnown
  · exact hp4_3_node865 T childKnown
  · exact hp4_3_node872 T childKnown
  · exact hp4_3_node879 T childKnown
  · exact hp4_3_node880 T childKnown
theorem hp4_3_node862 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected862 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected862 ((7 : Int),(1 : Int)) hp4_3_branches862 hp4_3_evidence862 hp4_3_check862 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches862,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node861 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected861 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected861 ((7 : Int),(1 : Int)) hp4_3_branches861 hp4_3_evidence861 hp4_3_check861 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches861,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node860 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected860 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected860 ((10 : Int),(1 : Int)) hp4_3_branches860 hp4_3_evidence860 hp4_3_check860 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches860,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node859 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected859 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected859 ((10 : Int),(1 : Int)) hp4_3_branches859 hp4_3_evidence859 hp4_3_check859 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches859,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node858 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected858 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected858 ((11 : Int),(0 : Int)) hp4_3_branches858 hp4_3_evidence858 hp4_3_check858 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches858,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node857 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected857 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected857 ((11 : Int),(1 : Int)) hp4_3_branches857 hp4_3_evidence857 hp4_3_check857 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches857,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node858 T childKnown
theorem hp4_3_node856 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected856 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected856 ((10 : Int),(2 : Int)) hp4_3_branches856 hp4_3_evidence856 hp4_3_check856 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches856,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node857 T childKnown
  · exact hp4_3_node859 T childKnown
  · exact hp4_3_node860 T childKnown
theorem hp4_3_node855 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected855 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected855 ((8 : Int),(1 : Int)) hp4_3_branches855 hp4_3_evidence855 hp4_3_check855 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches855,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node856 T childKnown
theorem hp4_3_node854 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected854 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected854 ((4 : Int),(2 : Int)) hp4_3_branches854 hp4_3_evidence854 hp4_3_check854 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches854,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node855 T childKnown
theorem hp4_3_node853 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected853 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected853 ((10 : Int),(1 : Int)) hp4_3_branches853 hp4_3_evidence853 hp4_3_check853 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches853,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node852 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected852 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected852 ((10 : Int),(1 : Int)) hp4_3_branches852 hp4_3_evidence852 hp4_3_check852 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches852,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node851 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected851 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected851 ((11 : Int),(0 : Int)) hp4_3_branches851 hp4_3_evidence851 hp4_3_check851 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches851,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node850 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected850 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected850 ((11 : Int),(1 : Int)) hp4_3_branches850 hp4_3_evidence850 hp4_3_check850 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches850,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node851 T childKnown
theorem hp4_3_node849 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected849 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected849 ((10 : Int),(2 : Int)) hp4_3_branches849 hp4_3_evidence849 hp4_3_check849 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches849,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node850 T childKnown
  · exact hp4_3_node852 T childKnown
  · exact hp4_3_node853 T childKnown
theorem hp4_3_node848 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected848 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected848 ((8 : Int),(1 : Int)) hp4_3_branches848 hp4_3_evidence848 hp4_3_check848 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches848,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node849 T childKnown
theorem hp4_3_node847 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected847 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected847 ((4 : Int),(2 : Int)) hp4_3_branches847 hp4_3_evidence847 hp4_3_check847 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches847,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node848 T childKnown
theorem hp4_3_node846 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected846 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected846 ((10 : Int),(1 : Int)) hp4_3_branches846 hp4_3_evidence846 hp4_3_check846 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches846,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node845 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected845 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected845 ((10 : Int),(1 : Int)) hp4_3_branches845 hp4_3_evidence845 hp4_3_check845 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches845,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node844 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected844 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected844 ((11 : Int),(0 : Int)) hp4_3_branches844 hp4_3_evidence844 hp4_3_check844 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches844,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node843 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected843 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected843 ((11 : Int),(1 : Int)) hp4_3_branches843 hp4_3_evidence843 hp4_3_check843 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches843,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node844 T childKnown
theorem hp4_3_node842 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected842 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected842 ((10 : Int),(2 : Int)) hp4_3_branches842 hp4_3_evidence842 hp4_3_check842 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches842,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node843 T childKnown
  · exact hp4_3_node845 T childKnown
  · exact hp4_3_node846 T childKnown
theorem hp4_3_node841 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected841 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected841 ((8 : Int),(1 : Int)) hp4_3_branches841 hp4_3_evidence841 hp4_3_check841 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches841,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node842 T childKnown
theorem hp4_3_node840 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected840 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected840 ((7 : Int),(1 : Int)) hp4_3_branches840 hp4_3_evidence840 hp4_3_check840 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches840,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node839 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected839 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected839 ((5 : Int),(2 : Int)) hp4_3_branches839 hp4_3_evidence839 hp4_3_check839 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches839,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node840 T childKnown
theorem hp4_3_node838 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected838 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected838 ((7 : Int),(1 : Int)) hp4_3_branches838 hp4_3_evidence838 hp4_3_check838 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches838,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node837 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected837 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected837 ((4 : Int),(2 : Int)) hp4_3_branches837 hp4_3_evidence837 hp4_3_check837 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches837,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node838 T childKnown
  · exact hp4_3_node839 T childKnown
  · exact hp4_3_node841 T childKnown
theorem hp4_3_node836 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected836 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected836 ((3 : Int),(2 : Int)) hp4_3_branches836 hp4_3_evidence836 hp4_3_check836 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches836,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node837 T childKnown
  · exact hp4_3_node847 T childKnown
  · exact hp4_3_node854 T childKnown
  · exact hp4_3_node861 T childKnown
  · exact hp4_3_node862 T childKnown
theorem hp4_3_node835 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected835 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected835 ((1 : Int),(2 : Int)) hp4_3_branches835 hp4_3_evidence835 hp4_3_check835 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches835,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node836 T childKnown
  · exact hp4_3_node863 T childKnown
  · exact hp4_3_node881 T childKnown
  · exact hp4_3_node883 T childKnown
theorem hp4_3_node834 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected834 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected834 ((5 : Int),(0 : Int)) hp4_3_branches834 hp4_3_evidence834 hp4_3_check834 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches834,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node835 T childKnown
theorem hp4_3_node833 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected833 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected833 ((2 : Int),(1 : Int)) hp4_3_branches833 hp4_3_evidence833 hp4_3_check833 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches833,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node832 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected832 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected832 ((2 : Int),(1 : Int)) hp4_3_branches832 hp4_3_evidence832 hp4_3_check832 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches832,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node831 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected831 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected831 ((2 : Int),(2 : Int)) hp4_3_branches831 hp4_3_evidence831 hp4_3_check831 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches831,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node832 T childKnown
  · exact hp4_3_node833 T childKnown
theorem hp4_3_node830 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected830 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected830 ((5 : Int),(2 : Int)) hp4_3_branches830 hp4_3_evidence830 hp4_3_check830 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches830,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node829 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected829 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected829 ((7 : Int),(2 : Int)) hp4_3_branches829 hp4_3_evidence829 hp4_3_check829 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches829,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node830 T childKnown
theorem hp4_3_node828 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected828 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected828 ((7 : Int),(2 : Int)) hp4_3_branches828 hp4_3_evidence828 hp4_3_check828 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches828,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node827 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected827 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected827 ((5 : Int),(2 : Int)) hp4_3_branches827 hp4_3_evidence827 hp4_3_check827 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches827,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node826 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected826 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected826 ((8 : Int),(1 : Int)) hp4_3_branches826 hp4_3_evidence826 hp4_3_check826 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches826,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node827 T childKnown
  · exact hp4_3_node828 T childKnown
  · exact hp4_3_node829 T childKnown
theorem hp4_3_node825 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected825 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected825 ((5 : Int),(0 : Int)) hp4_3_branches825 hp4_3_evidence825 hp4_3_check825 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches825,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node826 T childKnown
theorem hp4_3_node824 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected824 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected824 ((7 : Int),(1 : Int)) hp4_3_branches824 hp4_3_evidence824 hp4_3_check824 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches824,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node823 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected823 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected823 ((7 : Int),(1 : Int)) hp4_3_branches823 hp4_3_evidence823 hp4_3_check823 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches823,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node822 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected822 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected822 ((6 : Int),(1 : Int)) hp4_3_branches822 hp4_3_evidence822 hp4_3_check822 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches822,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node823 T childKnown
  · exact hp4_3_node824 T childKnown
theorem hp4_3_node821 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected821 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected821 ((8 : Int),(2 : Int)) hp4_3_branches821 hp4_3_evidence821 hp4_3_check821 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches821,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node820 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected820 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected820 ((8 : Int),(2 : Int)) hp4_3_branches820 hp4_3_evidence820 hp4_3_check820 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches820,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node819 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected819 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected819 ((9 : Int),(2 : Int)) hp4_3_branches819 hp4_3_evidence819 hp4_3_check819 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches819,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node818 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected818 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected818 ((9 : Int),(1 : Int)) hp4_3_branches818 hp4_3_evidence818 hp4_3_check818 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches818,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node819 T childKnown
theorem hp4_3_node817 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected817 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected817 ((8 : Int),(1 : Int)) hp4_3_branches817 hp4_3_evidence817 hp4_3_check817 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches817,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node818 T childKnown
  · exact hp4_3_node820 T childKnown
  · exact hp4_3_node821 T childKnown
theorem hp4_3_node816 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected816 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected816 ((6 : Int),(1 : Int)) hp4_3_branches816 hp4_3_evidence816 hp4_3_check816 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches816,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node817 T childKnown
theorem hp4_3_node815 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected815 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected815 ((7 : Int),(1 : Int)) hp4_3_branches815 hp4_3_evidence815 hp4_3_check815 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches815,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node814 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected814 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected814 ((7 : Int),(1 : Int)) hp4_3_branches814 hp4_3_evidence814 hp4_3_check814 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches814,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node813 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected813 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected813 ((7 : Int),(0 : Int)) hp4_3_branches813 hp4_3_evidence813 hp4_3_check813 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches813,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node814 T childKnown
  · exact hp4_3_node815 T childKnown
theorem hp4_3_node812 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected812 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected812 ((13 : Int),(1 : Int)) hp4_3_branches812 hp4_3_evidence812 hp4_3_check812 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches812,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node811 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected811 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected811 ((13 : Int),(1 : Int)) hp4_3_branches811 hp4_3_evidence811 hp4_3_check811 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches811,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node810 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected810 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected810 ((13 : Int),(1 : Int)) hp4_3_branches810 hp4_3_evidence810 hp4_3_check810 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches810,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node809 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected809 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected809 ((12 : Int),(1 : Int)) hp4_3_branches809 hp4_3_evidence809 hp4_3_check809 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches809,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node810 T childKnown
  · exact hp4_3_node811 T childKnown
  · exact hp4_3_node812 T childKnown
theorem hp4_3_node808 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected808 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected808 ((13 : Int),(1 : Int)) hp4_3_branches808 hp4_3_evidence808 hp4_3_check808 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches808,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node807 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected807 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected807 ((13 : Int),(1 : Int)) hp4_3_branches807 hp4_3_evidence807 hp4_3_check807 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches807,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node806 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected806 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected806 ((12 : Int),(1 : Int)) hp4_3_branches806 hp4_3_evidence806 hp4_3_check806 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches806,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node807 T childKnown
  · exact hp4_3_node808 T childKnown
theorem hp4_3_node805 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected805 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected805 ((12 : Int),(1 : Int)) hp4_3_branches805 hp4_3_evidence805 hp4_3_check805 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches805,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node804 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected804 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected804 ((12 : Int),(1 : Int)) hp4_3_branches804 hp4_3_evidence804 hp4_3_check804 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches804,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node803 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected803 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected803 ((12 : Int),(1 : Int)) hp4_3_branches803 hp4_3_evidence803 hp4_3_check803 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches803,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node802 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected802 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected802 ((13 : Int),(0 : Int)) hp4_3_branches802 hp4_3_evidence802 hp4_3_check802 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches802,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node803 T childKnown
  · exact hp4_3_node804 T childKnown
  · exact hp4_3_node805 T childKnown
  · exact hp4_3_node806 T childKnown
  · exact hp4_3_node809 T childKnown
theorem hp4_3_node801 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected801 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected801 ((8 : Int),(2 : Int)) hp4_3_branches801 hp4_3_evidence801 hp4_3_check801 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches801,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node800 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected800 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected800 ((8 : Int),(2 : Int)) hp4_3_branches800 hp4_3_evidence800 hp4_3_check800 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches800,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node799 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected799 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected799 ((9 : Int),(2 : Int)) hp4_3_branches799 hp4_3_evidence799 hp4_3_check799 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches799,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node798 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected798 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected798 ((8 : Int),(2 : Int)) hp4_3_branches798 hp4_3_evidence798 hp4_3_check798 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches798,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node799 T childKnown
theorem hp4_3_node797 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected797 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected797 ((7 : Int),(2 : Int)) hp4_3_branches797 hp4_3_evidence797 hp4_3_check797 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches797,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node798 T childKnown
  · exact hp4_3_node800 T childKnown
  · exact hp4_3_node801 T childKnown
  · exact hp4_3_node802 T childKnown
theorem hp4_3_node796 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected796 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected796 ((7 : Int),(0 : Int)) hp4_3_branches796 hp4_3_evidence796 hp4_3_check796 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches796,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node797 T childKnown
theorem hp4_3_node795 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected795 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected795 ((6 : Int),(0 : Int)) hp4_3_branches795 hp4_3_evidence795 hp4_3_check795 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches795,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node796 T childKnown
  · exact hp4_3_node813 T childKnown
  · exact hp4_3_node816 T childKnown
  · exact hp4_3_node822 T childKnown
theorem hp4_3_node794 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected794 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected794 ((2 : Int),(1 : Int)) hp4_3_branches794 hp4_3_evidence794 hp4_3_check794 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches794,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node795 T childKnown
  · exact hp4_3_node825 T childKnown
theorem hp4_3_node793 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected793 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected793 ((2 : Int),(2 : Int)) hp4_3_branches793 hp4_3_evidence793 hp4_3_check793 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches793,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node792 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected792 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected792 ((2 : Int),(1 : Int)) hp4_3_branches792 hp4_3_evidence792 hp4_3_check792 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches792,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node793 T childKnown
theorem hp4_3_node791 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected791 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected791 ((3 : Int),(2 : Int)) hp4_3_branches791 hp4_3_evidence791 hp4_3_check791 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches791,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node790 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected790 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected790 ((3 : Int),(2 : Int)) hp4_3_branches790 hp4_3_evidence790 hp4_3_check790 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches790,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node789 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected789 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected789 ((2 : Int),(2 : Int)) hp4_3_branches789 hp4_3_evidence789 hp4_3_check789 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches789,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node790 T childKnown
  · exact hp4_3_node791 T childKnown
theorem hp4_3_node788 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected788 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected788 ((5 : Int),(0 : Int)) hp4_3_branches788 hp4_3_evidence788 hp4_3_check788 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches788,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node789 T childKnown
theorem hp4_3_node787 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected787 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected787 ((3 : Int),(2 : Int)) hp4_3_branches787 hp4_3_evidence787 hp4_3_check787 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches787,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node786 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected786 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected786 ((2 : Int),(2 : Int)) hp4_3_branches786 hp4_3_evidence786 hp4_3_check786 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches786,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node787 T childKnown
theorem hp4_3_node785 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected785 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected785 ((5 : Int),(2 : Int)) hp4_3_branches785 hp4_3_evidence785 hp4_3_check785 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches785,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node784 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected784 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected784 ((4 : Int),(2 : Int)) hp4_3_branches784 hp4_3_evidence784 hp4_3_check784 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches784,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node785 T childKnown
theorem hp4_3_node783 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected783 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected783 ((5 : Int),(0 : Int)) hp4_3_branches783 hp4_3_evidence783 hp4_3_check783 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches783,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node784 T childKnown
theorem hp4_3_node782 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected782 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected782 ((2 : Int),(2 : Int)) hp4_3_branches782 hp4_3_evidence782 hp4_3_check782 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches782,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node783 T childKnown
theorem hp4_3_node781 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected781 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected781 ((3 : Int),(1 : Int)) hp4_3_branches781 hp4_3_evidence781 hp4_3_check781 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches781,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node780 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected780 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected780 ((3 : Int),(1 : Int)) hp4_3_branches780 hp4_3_evidence780 hp4_3_check780 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches780,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node779 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected779 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected779 ((3 : Int),(2 : Int)) hp4_3_branches779 hp4_3_evidence779 hp4_3_check779 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches779,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node780 T childKnown
  · exact hp4_3_node781 T childKnown
theorem hp4_3_node778 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected778 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected778 ((10 : Int),(1 : Int)) hp4_3_branches778 hp4_3_evidence778 hp4_3_check778 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches778,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node777 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected777 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected777 ((10 : Int),(1 : Int)) hp4_3_branches777 hp4_3_evidence777 hp4_3_check777 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches777,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node776 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected776 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected776 ((11 : Int),(0 : Int)) hp4_3_branches776 hp4_3_evidence776 hp4_3_check776 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches776,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node775 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected775 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected775 ((11 : Int),(1 : Int)) hp4_3_branches775 hp4_3_evidence775 hp4_3_check775 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches775,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node776 T childKnown
theorem hp4_3_node774 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected774 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected774 ((10 : Int),(2 : Int)) hp4_3_branches774 hp4_3_evidence774 hp4_3_check774 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches774,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node775 T childKnown
  · exact hp4_3_node777 T childKnown
  · exact hp4_3_node778 T childKnown
theorem hp4_3_node773 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected773 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected773 ((8 : Int),(2 : Int)) hp4_3_branches773 hp4_3_evidence773 hp4_3_check773 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches773,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node774 T childKnown
theorem hp4_3_node772 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected772 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected772 ((8 : Int),(2 : Int)) hp4_3_branches772 hp4_3_evidence772 hp4_3_check772 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches772,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node771 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected771 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected771 ((11 : Int),(0 : Int)) hp4_3_branches771 hp4_3_evidence771 hp4_3_check771 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches771,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node770 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected770 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected770 ((10 : Int),(2 : Int)) hp4_3_branches770 hp4_3_evidence770 hp4_3_check770 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches770,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node769 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected769 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected769 ((11 : Int),(0 : Int)) hp4_3_branches769 hp4_3_evidence769 hp4_3_check769 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches769,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node768 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected768 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected768 ((11 : Int),(0 : Int)) hp4_3_branches768 hp4_3_evidence768 hp4_3_check768 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches768,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node767 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected767 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected767 ((11 : Int),(1 : Int)) hp4_3_branches767 hp4_3_evidence767 hp4_3_check767 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches767,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node768 T childKnown
theorem hp4_3_node766 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected766 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected766 ((10 : Int),(1 : Int)) hp4_3_branches766 hp4_3_evidence766 hp4_3_check766 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches766,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node767 T childKnown
  · exact hp4_3_node769 T childKnown
  · exact hp4_3_node770 T childKnown
  · exact hp4_3_node771 T childKnown
theorem hp4_3_node765 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected765 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected765 ((10 : Int),(1 : Int)) hp4_3_branches765 hp4_3_evidence765 hp4_3_check765 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches765,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node764 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected764 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected764 ((10 : Int),(1 : Int)) hp4_3_branches764 hp4_3_evidence764 hp4_3_check764 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches764,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node763 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected763 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected763 ((11 : Int),(0 : Int)) hp4_3_branches763 hp4_3_evidence763 hp4_3_check763 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches763,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node762 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected762 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected762 ((11 : Int),(1 : Int)) hp4_3_branches762 hp4_3_evidence762 hp4_3_check762 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches762,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node763 T childKnown
theorem hp4_3_node761 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected761 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected761 ((10 : Int),(2 : Int)) hp4_3_branches761 hp4_3_evidence761 hp4_3_check761 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches761,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node762 T childKnown
  · exact hp4_3_node764 T childKnown
  · exact hp4_3_node765 T childKnown
theorem hp4_3_node760 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected760 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected760 ((8 : Int),(2 : Int)) hp4_3_branches760 hp4_3_evidence760 hp4_3_check760 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches760,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node761 T childKnown
  · exact hp4_3_node766 T childKnown
theorem hp4_3_node759 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected759 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected759 ((11 : Int),(0 : Int)) hp4_3_branches759 hp4_3_evidence759 hp4_3_check759 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches759,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node758 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected758 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected758 ((10 : Int),(2 : Int)) hp4_3_branches758 hp4_3_evidence758 hp4_3_check758 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches758,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node757 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected757 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected757 ((11 : Int),(0 : Int)) hp4_3_branches757 hp4_3_evidence757 hp4_3_check757 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches757,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node756 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected756 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected756 ((11 : Int),(0 : Int)) hp4_3_branches756 hp4_3_evidence756 hp4_3_check756 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches756,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node755 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected755 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected755 ((11 : Int),(1 : Int)) hp4_3_branches755 hp4_3_evidence755 hp4_3_check755 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches755,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node756 T childKnown
theorem hp4_3_node754 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected754 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected754 ((10 : Int),(1 : Int)) hp4_3_branches754 hp4_3_evidence754 hp4_3_check754 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches754,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node755 T childKnown
  · exact hp4_3_node757 T childKnown
  · exact hp4_3_node758 T childKnown
  · exact hp4_3_node759 T childKnown
theorem hp4_3_node753 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected753 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected753 ((10 : Int),(1 : Int)) hp4_3_branches753 hp4_3_evidence753 hp4_3_check753 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches753,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node752 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected752 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected752 ((10 : Int),(1 : Int)) hp4_3_branches752 hp4_3_evidence752 hp4_3_check752 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches752,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node751 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected751 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected751 ((11 : Int),(0 : Int)) hp4_3_branches751 hp4_3_evidence751 hp4_3_check751 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches751,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node750 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected750 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected750 ((11 : Int),(1 : Int)) hp4_3_branches750 hp4_3_evidence750 hp4_3_check750 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches750,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node751 T childKnown
theorem hp4_3_node749 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected749 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected749 ((10 : Int),(2 : Int)) hp4_3_branches749 hp4_3_evidence749 hp4_3_check749 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches749,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node750 T childKnown
  · exact hp4_3_node752 T childKnown
  · exact hp4_3_node753 T childKnown
theorem hp4_3_node748 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected748 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected748 ((8 : Int),(2 : Int)) hp4_3_branches748 hp4_3_evidence748 hp4_3_check748 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches748,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node749 T childKnown
  · exact hp4_3_node754 T childKnown
theorem hp4_3_node747 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected747 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected747 ((6 : Int),(2 : Int)) hp4_3_branches747 hp4_3_evidence747 hp4_3_check747 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches747,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node748 T childKnown
  · exact hp4_3_node760 T childKnown
  · exact hp4_3_node772 T childKnown
  · exact hp4_3_node773 T childKnown
theorem hp4_3_node746 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected746 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected746 ((5 : Int),(0 : Int)) hp4_3_branches746 hp4_3_evidence746 hp4_3_check746 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches746,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node747 T childKnown
theorem hp4_3_node745 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected745 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected745 ((5 : Int),(0 : Int)) hp4_3_branches745 hp4_3_evidence745 hp4_3_check745 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches745,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node744 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected744 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected744 ((3 : Int),(1 : Int)) hp4_3_branches744 hp4_3_evidence744 hp4_3_check744 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches744,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node745 T childKnown
  · exact hp4_3_node746 T childKnown
theorem hp4_3_node743 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected743 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected743 ((2 : Int),(1 : Int)) hp4_3_branches743 hp4_3_evidence743 hp4_3_check743 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches743,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node744 T childKnown
  · exact hp4_3_node779 T childKnown
  · exact hp4_3_node782 T childKnown
  · exact hp4_3_node786 T childKnown
  · exact hp4_3_node788 T childKnown
theorem hp4_3_node742 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected742 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected742 ((2 : Int),(2 : Int)) hp4_3_branches742 hp4_3_evidence742 hp4_3_check742 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches742,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node741 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected741 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected741 ((2 : Int),(2 : Int)) hp4_3_branches741 hp4_3_evidence741 hp4_3_check741 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches741,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node740 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected740 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected740 ((2 : Int),(2 : Int)) hp4_3_branches740 hp4_3_evidence740 hp4_3_check740 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches740,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node739 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected739 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected739 ((2 : Int),(1 : Int)) hp4_3_branches739 hp4_3_evidence739 hp4_3_check739 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches739,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node740 T childKnown
  · exact hp4_3_node741 T childKnown
  · exact hp4_3_node742 T childKnown
theorem hp4_3_node738 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected738 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected738 ((1 : Int),(1 : Int)) hp4_3_branches738 hp4_3_evidence738 hp4_3_check738 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches738,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node739 T childKnown
  · exact hp4_3_node743 T childKnown
  · exact hp4_3_node792 T childKnown
  · exact hp4_3_node794 T childKnown
  · exact hp4_3_node831 T childKnown
  · exact hp4_3_node834 T childKnown
  · exact hp4_3_node887 T childKnown
theorem hp4_3_node737 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected737 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected737 ((6 : Int),(1 : Int)) hp4_3_branches737 hp4_3_evidence737 hp4_3_check737 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches737,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node736 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected736 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected736 ((4 : Int),(1 : Int)) hp4_3_branches736 hp4_3_evidence736 hp4_3_check736 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches736,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node735 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected735 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected735 ((4 : Int),(1 : Int)) hp4_3_branches735 hp4_3_evidence735 hp4_3_check735 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches735,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node734 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected734 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected734 ((3 : Int),(1 : Int)) hp4_3_branches734 hp4_3_evidence734 hp4_3_check734 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches734,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node733 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected733 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected733 ((5 : Int),(1 : Int)) hp4_3_branches733 hp4_3_evidence733 hp4_3_check733 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches733,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node734 T childKnown
  · exact hp4_3_node735 T childKnown
  · exact hp4_3_node736 T childKnown
  · exact hp4_3_node737 T childKnown
theorem hp4_3_node732 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected732 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected732 ((4 : Int),(1 : Int)) hp4_3_branches732 hp4_3_evidence732 hp4_3_check732 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches732,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node731 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected731 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected731 ((4 : Int),(1 : Int)) hp4_3_branches731 hp4_3_evidence731 hp4_3_check731 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches731,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node730 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected730 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected730 ((0 : Int),(2 : Int)) hp4_3_branches730 hp4_3_evidence730 hp4_3_check730 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches730,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node729 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected729 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected729 ((0 : Int),(1 : Int)) hp4_3_branches729 hp4_3_evidence729 hp4_3_check729 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches729,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node730 T childKnown
theorem hp4_3_node728 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected728 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected728 ((1 : Int),(2 : Int)) hp4_3_branches728 hp4_3_evidence728 hp4_3_check728 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches728,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node727 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected727 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected727 ((0 : Int),(2 : Int)) hp4_3_branches727 hp4_3_evidence727 hp4_3_check727 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches727,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node726 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected726 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected726 ((1 : Int),(1 : Int)) hp4_3_branches726 hp4_3_evidence726 hp4_3_check726 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches726,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node727 T childKnown
  · exact hp4_3_node728 T childKnown
  · exact hp4_3_node729 T childKnown
theorem hp4_3_node725 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected725 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected725 ((4 : Int),(1 : Int)) hp4_3_branches725 hp4_3_evidence725 hp4_3_check725 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches725,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node726 T childKnown
theorem hp4_3_node724 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected724 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected724 ((4 : Int),(1 : Int)) hp4_3_branches724 hp4_3_evidence724 hp4_3_check724 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches724,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node723 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected723 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected723 ((3 : Int),(1 : Int)) hp4_3_branches723 hp4_3_evidence723 hp4_3_check723 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches723,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node724 T childKnown
  · exact hp4_3_node725 T childKnown
  · exact hp4_3_node731 T childKnown
  · exact hp4_3_node732 T childKnown
theorem hp4_3_node722 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected722 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected722 ((5 : Int),(1 : Int)) hp4_3_branches722 hp4_3_evidence722 hp4_3_check722 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches722,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node721 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected721 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected721 ((5 : Int),(1 : Int)) hp4_3_branches721 hp4_3_evidence721 hp4_3_check721 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches721,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node720 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected720 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected720 ((5 : Int),(0 : Int)) hp4_3_branches720 hp4_3_evidence720 hp4_3_check720 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches720,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node721 T childKnown
  · exact hp4_3_node722 T childKnown
theorem hp4_3_node719 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected719 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected719 ((3 : Int),(1 : Int)) hp4_3_branches719 hp4_3_evidence719 hp4_3_check719 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches719,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node720 T childKnown
theorem hp4_3_node718 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected718 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected718 ((0 : Int),(2 : Int)) hp4_3_branches718 hp4_3_evidence718 hp4_3_check718 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches718,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node717 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected717 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected717 ((0 : Int),(1 : Int)) hp4_3_branches717 hp4_3_evidence717 hp4_3_check717 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches717,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node718 T childKnown
theorem hp4_3_node716 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected716 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected716 ((1 : Int),(2 : Int)) hp4_3_branches716 hp4_3_evidence716 hp4_3_check716 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches716,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node715 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected715 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected715 ((0 : Int),(2 : Int)) hp4_3_branches715 hp4_3_evidence715 hp4_3_check715 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches715,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node714 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected714 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected714 ((1 : Int),(1 : Int)) hp4_3_branches714 hp4_3_evidence714 hp4_3_check714 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches714,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node715 T childKnown
  · exact hp4_3_node716 T childKnown
  · exact hp4_3_node717 T childKnown
theorem hp4_3_node713 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected713 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected713 ((5 : Int),(0 : Int)) hp4_3_branches713 hp4_3_evidence713 hp4_3_check713 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches713,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node714 T childKnown
theorem hp4_3_node712 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected712 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected712 ((3 : Int),(1 : Int)) hp4_3_branches712 hp4_3_evidence712 hp4_3_check712 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches712,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node713 T childKnown
theorem hp4_3_node711 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected711 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected711 ((3 : Int),(1 : Int)) hp4_3_branches711 hp4_3_evidence711 hp4_3_check711 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches711,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node710 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected710 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected710 ((3 : Int),(1 : Int)) hp4_3_branches710 hp4_3_evidence710 hp4_3_check710 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches710,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node709 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected709 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected709 ((4 : Int),(0 : Int)) hp4_3_branches709 hp4_3_evidence709 hp4_3_check709 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches709,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node710 T childKnown
  · exact hp4_3_node711 T childKnown
  · exact hp4_3_node712 T childKnown
  · exact hp4_3_node719 T childKnown
  · exact hp4_3_node723 T childKnown
  · exact hp4_3_node733 T childKnown
theorem hp4_3_node708 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected708 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected708 ((7 : Int),(1 : Int)) hp4_3_branches708 hp4_3_evidence708 hp4_3_check708 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches708,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node707 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected707 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected707 ((5 : Int),(2 : Int)) hp4_3_branches707 hp4_3_evidence707 hp4_3_check707 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches707,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node706 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected706 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected706 ((3 : Int),(2 : Int)) hp4_3_branches706 hp4_3_evidence706 hp4_3_check706 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches706,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node705 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected705 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected705 ((6 : Int),(1 : Int)) hp4_3_branches705 hp4_3_evidence705 hp4_3_check705 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches705,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node706 T childKnown
  · exact hp4_3_node707 T childKnown
  · exact hp4_3_node708 T childKnown
theorem hp4_3_node704 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected704 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected704 ((4 : Int),(0 : Int)) hp4_3_branches704 hp4_3_evidence704 hp4_3_check704 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches704,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node705 T childKnown
theorem hp4_3_node703 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected703 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected703 ((6 : Int),(1 : Int)) hp4_3_branches703 hp4_3_evidence703 hp4_3_check703 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches703,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node702 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected702 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected702 ((6 : Int),(1 : Int)) hp4_3_branches702 hp4_3_evidence702 hp4_3_check702 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches702,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node701 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected701 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected701 ((3 : Int),(2 : Int)) hp4_3_branches701 hp4_3_evidence701 hp4_3_check701 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches701,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node700 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected700 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected700 ((2 : Int),(2 : Int)) hp4_3_branches700 hp4_3_evidence700 hp4_3_check700 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches700,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node701 T childKnown
  · exact hp4_3_node702 T childKnown
  · exact hp4_3_node703 T childKnown
theorem hp4_3_node699 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected699 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected699 ((6 : Int),(1 : Int)) hp4_3_branches699 hp4_3_evidence699 hp4_3_check699 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches699,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node698 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected698 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected698 ((2 : Int),(2 : Int)) hp4_3_branches698 hp4_3_evidence698 hp4_3_check698 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches698,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node699 T childKnown
theorem hp4_3_node697 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected697 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected697 ((6 : Int),(1 : Int)) hp4_3_branches697 hp4_3_evidence697 hp4_3_check697 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches697,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node696 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected696 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected696 ((6 : Int),(1 : Int)) hp4_3_branches696 hp4_3_evidence696 hp4_3_check696 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches696,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node695 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected695 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected695 ((9 : Int),(1 : Int)) hp4_3_branches695 hp4_3_evidence695 hp4_3_check695 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches695,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node694 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected694 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected694 ((9 : Int),(1 : Int)) hp4_3_branches694 hp4_3_evidence694 hp4_3_check694 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches694,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node693 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected693 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected693 ((10 : Int),(0 : Int)) hp4_3_branches693 hp4_3_evidence693 hp4_3_check693 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches693,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node692 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected692 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected692 ((10 : Int),(1 : Int)) hp4_3_branches692 hp4_3_evidence692 hp4_3_check692 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches692,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node693 T childKnown
theorem hp4_3_node691 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected691 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected691 ((9 : Int),(2 : Int)) hp4_3_branches691 hp4_3_evidence691 hp4_3_check691 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches691,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node692 T childKnown
  · exact hp4_3_node694 T childKnown
  · exact hp4_3_node695 T childKnown
theorem hp4_3_node690 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected690 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected690 ((7 : Int),(1 : Int)) hp4_3_branches690 hp4_3_evidence690 hp4_3_check690 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches690,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node691 T childKnown
theorem hp4_3_node689 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected689 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected689 ((3 : Int),(2 : Int)) hp4_3_branches689 hp4_3_evidence689 hp4_3_check689 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches689,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node690 T childKnown
theorem hp4_3_node688 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected688 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected688 ((9 : Int),(1 : Int)) hp4_3_branches688 hp4_3_evidence688 hp4_3_check688 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches688,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node687 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected687 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected687 ((9 : Int),(1 : Int)) hp4_3_branches687 hp4_3_evidence687 hp4_3_check687 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches687,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node686 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected686 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected686 ((10 : Int),(0 : Int)) hp4_3_branches686 hp4_3_evidence686 hp4_3_check686 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches686,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node685 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected685 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected685 ((10 : Int),(1 : Int)) hp4_3_branches685 hp4_3_evidence685 hp4_3_check685 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches685,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node686 T childKnown
theorem hp4_3_node684 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected684 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected684 ((9 : Int),(2 : Int)) hp4_3_branches684 hp4_3_evidence684 hp4_3_check684 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches684,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node685 T childKnown
  · exact hp4_3_node687 T childKnown
  · exact hp4_3_node688 T childKnown
theorem hp4_3_node683 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected683 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected683 ((7 : Int),(1 : Int)) hp4_3_branches683 hp4_3_evidence683 hp4_3_check683 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches683,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node684 T childKnown
theorem hp4_3_node682 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected682 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected682 ((3 : Int),(2 : Int)) hp4_3_branches682 hp4_3_evidence682 hp4_3_check682 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches682,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node683 T childKnown
theorem hp4_3_node681 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected681 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected681 ((3 : Int),(2 : Int)) hp4_3_branches681 hp4_3_evidence681 hp4_3_check681 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches681,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node680 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected680 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected680 ((2 : Int),(2 : Int)) hp4_3_branches680 hp4_3_evidence680 hp4_3_check680 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches680,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node681 T childKnown
  · exact hp4_3_node682 T childKnown
  · exact hp4_3_node689 T childKnown
  · exact hp4_3_node696 T childKnown
  · exact hp4_3_node697 T childKnown
theorem hp4_3_node679 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected679 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected679 ((6 : Int),(1 : Int)) hp4_3_branches679 hp4_3_evidence679 hp4_3_check679 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches679,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node678 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected678 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected678 ((6 : Int),(1 : Int)) hp4_3_branches678 hp4_3_evidence678 hp4_3_check678 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches678,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node677 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected677 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected677 ((9 : Int),(1 : Int)) hp4_3_branches677 hp4_3_evidence677 hp4_3_check677 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches677,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node676 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected676 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected676 ((9 : Int),(1 : Int)) hp4_3_branches676 hp4_3_evidence676 hp4_3_check676 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches676,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node675 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected675 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected675 ((10 : Int),(0 : Int)) hp4_3_branches675 hp4_3_evidence675 hp4_3_check675 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches675,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node674 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected674 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected674 ((10 : Int),(1 : Int)) hp4_3_branches674 hp4_3_evidence674 hp4_3_check674 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches674,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node675 T childKnown
theorem hp4_3_node673 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected673 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected673 ((9 : Int),(2 : Int)) hp4_3_branches673 hp4_3_evidence673 hp4_3_check673 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches673,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node674 T childKnown
  · exact hp4_3_node676 T childKnown
  · exact hp4_3_node677 T childKnown
theorem hp4_3_node672 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected672 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected672 ((7 : Int),(1 : Int)) hp4_3_branches672 hp4_3_evidence672 hp4_3_check672 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches672,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node673 T childKnown
theorem hp4_3_node671 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected671 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected671 ((3 : Int),(2 : Int)) hp4_3_branches671 hp4_3_evidence671 hp4_3_check671 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches671,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node672 T childKnown
theorem hp4_3_node670 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected670 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected670 ((9 : Int),(1 : Int)) hp4_3_branches670 hp4_3_evidence670 hp4_3_check670 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches670,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node669 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected669 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected669 ((9 : Int),(1 : Int)) hp4_3_branches669 hp4_3_evidence669 hp4_3_check669 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches669,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node668 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected668 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected668 ((10 : Int),(0 : Int)) hp4_3_branches668 hp4_3_evidence668 hp4_3_check668 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches668,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node667 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected667 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected667 ((10 : Int),(1 : Int)) hp4_3_branches667 hp4_3_evidence667 hp4_3_check667 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches667,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node668 T childKnown
theorem hp4_3_node666 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected666 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected666 ((9 : Int),(2 : Int)) hp4_3_branches666 hp4_3_evidence666 hp4_3_check666 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches666,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node667 T childKnown
  · exact hp4_3_node669 T childKnown
  · exact hp4_3_node670 T childKnown
theorem hp4_3_node665 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected665 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected665 ((7 : Int),(1 : Int)) hp4_3_branches665 hp4_3_evidence665 hp4_3_check665 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches665,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node666 T childKnown
theorem hp4_3_node664 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected664 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected664 ((3 : Int),(2 : Int)) hp4_3_branches664 hp4_3_evidence664 hp4_3_check664 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches664,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node665 T childKnown
theorem hp4_3_node663 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected663 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected663 ((9 : Int),(1 : Int)) hp4_3_branches663 hp4_3_evidence663 hp4_3_check663 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches663,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node662 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected662 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected662 ((9 : Int),(1 : Int)) hp4_3_branches662 hp4_3_evidence662 hp4_3_check662 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches662,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node661 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected661 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected661 ((10 : Int),(0 : Int)) hp4_3_branches661 hp4_3_evidence661 hp4_3_check661 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches661,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node660 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected660 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected660 ((10 : Int),(1 : Int)) hp4_3_branches660 hp4_3_evidence660 hp4_3_check660 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches660,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node661 T childKnown
theorem hp4_3_node659 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected659 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected659 ((9 : Int),(2 : Int)) hp4_3_branches659 hp4_3_evidence659 hp4_3_check659 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches659,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node660 T childKnown
  · exact hp4_3_node662 T childKnown
  · exact hp4_3_node663 T childKnown
theorem hp4_3_node658 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected658 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected658 ((7 : Int),(1 : Int)) hp4_3_branches658 hp4_3_evidence658 hp4_3_check658 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches658,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node659 T childKnown
theorem hp4_3_node657 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected657 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected657 ((6 : Int),(1 : Int)) hp4_3_branches657 hp4_3_evidence657 hp4_3_check657 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches657,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node656 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected656 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected656 ((4 : Int),(2 : Int)) hp4_3_branches656 hp4_3_evidence656 hp4_3_check656 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches656,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node657 T childKnown
theorem hp4_3_node655 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected655 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected655 ((6 : Int),(1 : Int)) hp4_3_branches655 hp4_3_evidence655 hp4_3_check655 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches655,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node654 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected654 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected654 ((3 : Int),(2 : Int)) hp4_3_branches654 hp4_3_evidence654 hp4_3_check654 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches654,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node655 T childKnown
  · exact hp4_3_node656 T childKnown
  · exact hp4_3_node658 T childKnown
theorem hp4_3_node653 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected653 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected653 ((2 : Int),(2 : Int)) hp4_3_branches653 hp4_3_evidence653 hp4_3_check653 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches653,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node654 T childKnown
  · exact hp4_3_node664 T childKnown
  · exact hp4_3_node671 T childKnown
  · exact hp4_3_node678 T childKnown
  · exact hp4_3_node679 T childKnown
theorem hp4_3_node652 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected652 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected652 ((0 : Int),(2 : Int)) hp4_3_branches652 hp4_3_evidence652 hp4_3_check652 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches652,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node653 T childKnown
  · exact hp4_3_node680 T childKnown
  · exact hp4_3_node698 T childKnown
  · exact hp4_3_node700 T childKnown
theorem hp4_3_node651 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected651 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected651 ((4 : Int),(0 : Int)) hp4_3_branches651 hp4_3_evidence651 hp4_3_check651 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches651,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node652 T childKnown
theorem hp4_3_node650 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected650 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected650 ((1 : Int),(1 : Int)) hp4_3_branches650 hp4_3_evidence650 hp4_3_check650 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches650,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node649 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected649 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected649 ((1 : Int),(1 : Int)) hp4_3_branches649 hp4_3_evidence649 hp4_3_check649 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches649,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node648 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected648 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected648 ((1 : Int),(2 : Int)) hp4_3_branches648 hp4_3_evidence648 hp4_3_check648 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches648,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node649 T childKnown
  · exact hp4_3_node650 T childKnown
theorem hp4_3_node647 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected647 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected647 ((4 : Int),(2 : Int)) hp4_3_branches647 hp4_3_evidence647 hp4_3_check647 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches647,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node646 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected646 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected646 ((6 : Int),(2 : Int)) hp4_3_branches646 hp4_3_evidence646 hp4_3_check646 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches646,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node647 T childKnown
theorem hp4_3_node645 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected645 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected645 ((6 : Int),(2 : Int)) hp4_3_branches645 hp4_3_evidence645 hp4_3_check645 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches645,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node644 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected644 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected644 ((4 : Int),(2 : Int)) hp4_3_branches644 hp4_3_evidence644 hp4_3_check644 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches644,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node643 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected643 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected643 ((7 : Int),(1 : Int)) hp4_3_branches643 hp4_3_evidence643 hp4_3_check643 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches643,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node644 T childKnown
  · exact hp4_3_node645 T childKnown
  · exact hp4_3_node646 T childKnown
theorem hp4_3_node642 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected642 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected642 ((4 : Int),(0 : Int)) hp4_3_branches642 hp4_3_evidence642 hp4_3_check642 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches642,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node643 T childKnown
theorem hp4_3_node641 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected641 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected641 ((6 : Int),(1 : Int)) hp4_3_branches641 hp4_3_evidence641 hp4_3_check641 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches641,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node640 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected640 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected640 ((6 : Int),(1 : Int)) hp4_3_branches640 hp4_3_evidence640 hp4_3_check640 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches640,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node639 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected639 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected639 ((5 : Int),(1 : Int)) hp4_3_branches639 hp4_3_evidence639 hp4_3_check639 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches639,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node640 T childKnown
  · exact hp4_3_node641 T childKnown
theorem hp4_3_node638 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected638 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected638 ((7 : Int),(2 : Int)) hp4_3_branches638 hp4_3_evidence638 hp4_3_check638 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches638,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node637 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected637 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected637 ((7 : Int),(2 : Int)) hp4_3_branches637 hp4_3_evidence637 hp4_3_check637 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches637,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node636 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected636 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected636 ((8 : Int),(2 : Int)) hp4_3_branches636 hp4_3_evidence636 hp4_3_check636 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches636,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node635 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected635 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected635 ((8 : Int),(1 : Int)) hp4_3_branches635 hp4_3_evidence635 hp4_3_check635 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches635,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node636 T childKnown
theorem hp4_3_node634 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected634 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected634 ((7 : Int),(1 : Int)) hp4_3_branches634 hp4_3_evidence634 hp4_3_check634 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches634,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node635 T childKnown
  · exact hp4_3_node637 T childKnown
  · exact hp4_3_node638 T childKnown
theorem hp4_3_node633 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected633 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected633 ((5 : Int),(1 : Int)) hp4_3_branches633 hp4_3_evidence633 hp4_3_check633 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches633,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node634 T childKnown
theorem hp4_3_node632 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected632 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected632 ((6 : Int),(1 : Int)) hp4_3_branches632 hp4_3_evidence632 hp4_3_check632 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches632,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node631 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected631 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected631 ((6 : Int),(1 : Int)) hp4_3_branches631 hp4_3_evidence631 hp4_3_check631 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches631,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node630 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected630 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected630 ((6 : Int),(0 : Int)) hp4_3_branches630 hp4_3_evidence630 hp4_3_check630 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches630,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node631 T childKnown
  · exact hp4_3_node632 T childKnown
theorem hp4_3_node629 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected629 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected629 ((12 : Int),(1 : Int)) hp4_3_branches629 hp4_3_evidence629 hp4_3_check629 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches629,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node628 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected628 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected628 ((12 : Int),(1 : Int)) hp4_3_branches628 hp4_3_evidence628 hp4_3_check628 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches628,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node627 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected627 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected627 ((12 : Int),(1 : Int)) hp4_3_branches627 hp4_3_evidence627 hp4_3_check627 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches627,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node626 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected626 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected626 ((11 : Int),(1 : Int)) hp4_3_branches626 hp4_3_evidence626 hp4_3_check626 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches626,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node627 T childKnown
  · exact hp4_3_node628 T childKnown
  · exact hp4_3_node629 T childKnown
theorem hp4_3_node625 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected625 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected625 ((12 : Int),(1 : Int)) hp4_3_branches625 hp4_3_evidence625 hp4_3_check625 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches625,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node624 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected624 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected624 ((12 : Int),(1 : Int)) hp4_3_branches624 hp4_3_evidence624 hp4_3_check624 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches624,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node623 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected623 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected623 ((11 : Int),(1 : Int)) hp4_3_branches623 hp4_3_evidence623 hp4_3_check623 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches623,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node624 T childKnown
  · exact hp4_3_node625 T childKnown
theorem hp4_3_node622 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected622 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected622 ((11 : Int),(1 : Int)) hp4_3_branches622 hp4_3_evidence622 hp4_3_check622 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches622,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node621 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected621 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected621 ((11 : Int),(1 : Int)) hp4_3_branches621 hp4_3_evidence621 hp4_3_check621 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches621,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node620 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected620 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected620 ((11 : Int),(1 : Int)) hp4_3_branches620 hp4_3_evidence620 hp4_3_check620 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches620,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node619 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected619 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected619 ((12 : Int),(0 : Int)) hp4_3_branches619 hp4_3_evidence619 hp4_3_check619 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches619,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node620 T childKnown
  · exact hp4_3_node621 T childKnown
  · exact hp4_3_node622 T childKnown
  · exact hp4_3_node623 T childKnown
  · exact hp4_3_node626 T childKnown
theorem hp4_3_node618 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected618 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected618 ((7 : Int),(2 : Int)) hp4_3_branches618 hp4_3_evidence618 hp4_3_check618 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches618,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node617 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected617 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected617 ((7 : Int),(2 : Int)) hp4_3_branches617 hp4_3_evidence617 hp4_3_check617 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches617,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node616 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected616 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected616 ((8 : Int),(2 : Int)) hp4_3_branches616 hp4_3_evidence616 hp4_3_check616 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches616,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node615 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected615 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected615 ((7 : Int),(2 : Int)) hp4_3_branches615 hp4_3_evidence615 hp4_3_check615 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches615,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node616 T childKnown
theorem hp4_3_node614 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected614 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected614 ((6 : Int),(2 : Int)) hp4_3_branches614 hp4_3_evidence614 hp4_3_check614 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches614,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node615 T childKnown
  · exact hp4_3_node617 T childKnown
  · exact hp4_3_node618 T childKnown
  · exact hp4_3_node619 T childKnown
theorem hp4_3_node613 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected613 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected613 ((6 : Int),(0 : Int)) hp4_3_branches613 hp4_3_evidence613 hp4_3_check613 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches613,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node614 T childKnown
theorem hp4_3_node612 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected612 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected612 ((5 : Int),(0 : Int)) hp4_3_branches612 hp4_3_evidence612 hp4_3_check612 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches612,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node613 T childKnown
  · exact hp4_3_node630 T childKnown
  · exact hp4_3_node633 T childKnown
  · exact hp4_3_node639 T childKnown
theorem hp4_3_node611 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected611 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected611 ((1 : Int),(1 : Int)) hp4_3_branches611 hp4_3_evidence611 hp4_3_check611 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches611,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node612 T childKnown
  · exact hp4_3_node642 T childKnown
theorem hp4_3_node610 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected610 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected610 ((1 : Int),(2 : Int)) hp4_3_branches610 hp4_3_evidence610 hp4_3_check610 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches610,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node609 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected609 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected609 ((1 : Int),(1 : Int)) hp4_3_branches609 hp4_3_evidence609 hp4_3_check609 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches609,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node610 T childKnown
theorem hp4_3_node608 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected608 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected608 ((2 : Int),(2 : Int)) hp4_3_branches608 hp4_3_evidence608 hp4_3_check608 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches608,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node607 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected607 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected607 ((2 : Int),(2 : Int)) hp4_3_branches607 hp4_3_evidence607 hp4_3_check607 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches607,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node606 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected606 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected606 ((1 : Int),(2 : Int)) hp4_3_branches606 hp4_3_evidence606 hp4_3_check606 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches606,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node607 T childKnown
  · exact hp4_3_node608 T childKnown
theorem hp4_3_node605 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected605 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected605 ((4 : Int),(0 : Int)) hp4_3_branches605 hp4_3_evidence605 hp4_3_check605 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches605,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node606 T childKnown
theorem hp4_3_node604 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected604 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected604 ((2 : Int),(2 : Int)) hp4_3_branches604 hp4_3_evidence604 hp4_3_check604 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches604,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node603 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected603 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected603 ((1 : Int),(2 : Int)) hp4_3_branches603 hp4_3_evidence603 hp4_3_check603 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches603,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node604 T childKnown
theorem hp4_3_node602 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected602 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected602 ((4 : Int),(2 : Int)) hp4_3_branches602 hp4_3_evidence602 hp4_3_check602 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches602,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node601 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected601 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected601 ((3 : Int),(2 : Int)) hp4_3_branches601 hp4_3_evidence601 hp4_3_check601 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches601,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node602 T childKnown
theorem hp4_3_node600 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected600 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected600 ((4 : Int),(0 : Int)) hp4_3_branches600 hp4_3_evidence600 hp4_3_check600 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches600,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node601 T childKnown
theorem hp4_3_node599 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected599 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected599 ((1 : Int),(2 : Int)) hp4_3_branches599 hp4_3_evidence599 hp4_3_check599 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches599,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node600 T childKnown
theorem hp4_3_node598 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected598 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected598 ((2 : Int),(1 : Int)) hp4_3_branches598 hp4_3_evidence598 hp4_3_check598 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches598,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node597 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected597 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected597 ((2 : Int),(1 : Int)) hp4_3_branches597 hp4_3_evidence597 hp4_3_check597 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches597,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node596 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected596 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected596 ((2 : Int),(2 : Int)) hp4_3_branches596 hp4_3_evidence596 hp4_3_check596 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches596,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node597 T childKnown
  · exact hp4_3_node598 T childKnown
theorem hp4_3_node595 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected595 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected595 ((9 : Int),(1 : Int)) hp4_3_branches595 hp4_3_evidence595 hp4_3_check595 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches595,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node594 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected594 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected594 ((9 : Int),(1 : Int)) hp4_3_branches594 hp4_3_evidence594 hp4_3_check594 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches594,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node593 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected593 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected593 ((10 : Int),(0 : Int)) hp4_3_branches593 hp4_3_evidence593 hp4_3_check593 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches593,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node592 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected592 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected592 ((10 : Int),(1 : Int)) hp4_3_branches592 hp4_3_evidence592 hp4_3_check592 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches592,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node593 T childKnown
theorem hp4_3_node591 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected591 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected591 ((9 : Int),(2 : Int)) hp4_3_branches591 hp4_3_evidence591 hp4_3_check591 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches591,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node592 T childKnown
  · exact hp4_3_node594 T childKnown
  · exact hp4_3_node595 T childKnown
theorem hp4_3_node590 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected590 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected590 ((7 : Int),(2 : Int)) hp4_3_branches590 hp4_3_evidence590 hp4_3_check590 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches590,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node591 T childKnown
theorem hp4_3_node589 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected589 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected589 ((7 : Int),(2 : Int)) hp4_3_branches589 hp4_3_evidence589 hp4_3_check589 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches589,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node588 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected588 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected588 ((10 : Int),(0 : Int)) hp4_3_branches588 hp4_3_evidence588 hp4_3_check588 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches588,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node587 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected587 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected587 ((9 : Int),(2 : Int)) hp4_3_branches587 hp4_3_evidence587 hp4_3_check587 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches587,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node586 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected586 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected586 ((10 : Int),(0 : Int)) hp4_3_branches586 hp4_3_evidence586 hp4_3_check586 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches586,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node585 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected585 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected585 ((10 : Int),(0 : Int)) hp4_3_branches585 hp4_3_evidence585 hp4_3_check585 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches585,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node584 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected584 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected584 ((10 : Int),(1 : Int)) hp4_3_branches584 hp4_3_evidence584 hp4_3_check584 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches584,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node585 T childKnown
theorem hp4_3_node583 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected583 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected583 ((9 : Int),(1 : Int)) hp4_3_branches583 hp4_3_evidence583 hp4_3_check583 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches583,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node584 T childKnown
  · exact hp4_3_node586 T childKnown
  · exact hp4_3_node587 T childKnown
  · exact hp4_3_node588 T childKnown
theorem hp4_3_node582 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected582 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected582 ((9 : Int),(1 : Int)) hp4_3_branches582 hp4_3_evidence582 hp4_3_check582 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches582,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node581 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected581 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected581 ((9 : Int),(1 : Int)) hp4_3_branches581 hp4_3_evidence581 hp4_3_check581 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches581,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node580 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected580 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected580 ((10 : Int),(0 : Int)) hp4_3_branches580 hp4_3_evidence580 hp4_3_check580 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches580,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node579 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected579 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected579 ((10 : Int),(1 : Int)) hp4_3_branches579 hp4_3_evidence579 hp4_3_check579 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches579,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node580 T childKnown
theorem hp4_3_node578 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected578 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected578 ((9 : Int),(2 : Int)) hp4_3_branches578 hp4_3_evidence578 hp4_3_check578 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches578,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node579 T childKnown
  · exact hp4_3_node581 T childKnown
  · exact hp4_3_node582 T childKnown
theorem hp4_3_node577 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected577 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected577 ((7 : Int),(2 : Int)) hp4_3_branches577 hp4_3_evidence577 hp4_3_check577 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches577,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node578 T childKnown
  · exact hp4_3_node583 T childKnown
theorem hp4_3_node576 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected576 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected576 ((10 : Int),(0 : Int)) hp4_3_branches576 hp4_3_evidence576 hp4_3_check576 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches576,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node575 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected575 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected575 ((9 : Int),(2 : Int)) hp4_3_branches575 hp4_3_evidence575 hp4_3_check575 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches575,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node574 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected574 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected574 ((10 : Int),(0 : Int)) hp4_3_branches574 hp4_3_evidence574 hp4_3_check574 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches574,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node573 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected573 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected573 ((10 : Int),(0 : Int)) hp4_3_branches573 hp4_3_evidence573 hp4_3_check573 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches573,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node572 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected572 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected572 ((10 : Int),(1 : Int)) hp4_3_branches572 hp4_3_evidence572 hp4_3_check572 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches572,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node573 T childKnown
theorem hp4_3_node571 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected571 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected571 ((9 : Int),(1 : Int)) hp4_3_branches571 hp4_3_evidence571 hp4_3_check571 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches571,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node572 T childKnown
  · exact hp4_3_node574 T childKnown
  · exact hp4_3_node575 T childKnown
  · exact hp4_3_node576 T childKnown
theorem hp4_3_node570 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected570 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected570 ((9 : Int),(1 : Int)) hp4_3_branches570 hp4_3_evidence570 hp4_3_check570 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches570,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node569 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected569 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected569 ((9 : Int),(1 : Int)) hp4_3_branches569 hp4_3_evidence569 hp4_3_check569 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches569,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node568 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected568 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected568 ((10 : Int),(0 : Int)) hp4_3_branches568 hp4_3_evidence568 hp4_3_check568 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches568,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node567 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected567 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected567 ((10 : Int),(1 : Int)) hp4_3_branches567 hp4_3_evidence567 hp4_3_check567 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches567,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node568 T childKnown
theorem hp4_3_node566 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected566 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected566 ((9 : Int),(2 : Int)) hp4_3_branches566 hp4_3_evidence566 hp4_3_check566 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches566,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node567 T childKnown
  · exact hp4_3_node569 T childKnown
  · exact hp4_3_node570 T childKnown
theorem hp4_3_node565 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected565 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected565 ((7 : Int),(2 : Int)) hp4_3_branches565 hp4_3_evidence565 hp4_3_check565 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches565,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node566 T childKnown
  · exact hp4_3_node571 T childKnown
theorem hp4_3_node564 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected564 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected564 ((5 : Int),(2 : Int)) hp4_3_branches564 hp4_3_evidence564 hp4_3_check564 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches564,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node565 T childKnown
  · exact hp4_3_node577 T childKnown
  · exact hp4_3_node589 T childKnown
  · exact hp4_3_node590 T childKnown
theorem hp4_3_node563 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected563 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected563 ((4 : Int),(0 : Int)) hp4_3_branches563 hp4_3_evidence563 hp4_3_check563 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches563,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node564 T childKnown
theorem hp4_3_node562 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected562 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected562 ((4 : Int),(0 : Int)) hp4_3_branches562 hp4_3_evidence562 hp4_3_check562 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches562,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node561 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected561 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected561 ((2 : Int),(1 : Int)) hp4_3_branches561 hp4_3_evidence561 hp4_3_check561 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches561,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node562 T childKnown
  · exact hp4_3_node563 T childKnown
theorem hp4_3_node560 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected560 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected560 ((1 : Int),(1 : Int)) hp4_3_branches560 hp4_3_evidence560 hp4_3_check560 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches560,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node561 T childKnown
  · exact hp4_3_node596 T childKnown
  · exact hp4_3_node599 T childKnown
  · exact hp4_3_node603 T childKnown
  · exact hp4_3_node605 T childKnown
theorem hp4_3_node559 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected559 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected559 ((1 : Int),(2 : Int)) hp4_3_branches559 hp4_3_evidence559 hp4_3_check559 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches559,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node558 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected558 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected558 ((1 : Int),(2 : Int)) hp4_3_branches558 hp4_3_evidence558 hp4_3_check558 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches558,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node557 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected557 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected557 ((1 : Int),(2 : Int)) hp4_3_branches557 hp4_3_evidence557 hp4_3_check557 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches557,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node556 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected556 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected556 ((1 : Int),(1 : Int)) hp4_3_branches556 hp4_3_evidence556 hp4_3_check556 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches556,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node557 T childKnown
  · exact hp4_3_node558 T childKnown
  · exact hp4_3_node559 T childKnown
theorem hp4_3_node555 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected555 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected555 ((0 : Int),(1 : Int)) hp4_3_branches555 hp4_3_evidence555 hp4_3_check555 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches555,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node556 T childKnown
  · exact hp4_3_node560 T childKnown
  · exact hp4_3_node609 T childKnown
  · exact hp4_3_node611 T childKnown
  · exact hp4_3_node648 T childKnown
  · exact hp4_3_node651 T childKnown
  · exact hp4_3_node704 T childKnown
theorem hp4_3_node554 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected554 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected554 ((2 : Int),(1 : Int)) hp4_3_branches554 hp4_3_evidence554 hp4_3_check554 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches554,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node553 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected553 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected553 ((2 : Int),(1 : Int)) hp4_3_branches553 hp4_3_evidence553 hp4_3_check553 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches553,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node552 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected552 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected552 ((1 : Int),(1 : Int)) hp4_3_branches552 hp4_3_evidence552 hp4_3_check552 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches552,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node553 T childKnown
  · exact hp4_3_node554 T childKnown
theorem hp4_3_node551 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected551 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected551 ((3 : Int),(2 : Int)) hp4_3_branches551 hp4_3_evidence551 hp4_3_check551 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches551,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node550 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected550 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected550 ((3 : Int),(2 : Int)) hp4_3_branches550 hp4_3_evidence550 hp4_3_check550 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches550,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node549 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected549 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected549 ((4 : Int),(2 : Int)) hp4_3_branches549 hp4_3_evidence549 hp4_3_check549 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches549,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node548 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected548 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected548 ((4 : Int),(1 : Int)) hp4_3_branches548 hp4_3_evidence548 hp4_3_check548 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches548,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node549 T childKnown
theorem hp4_3_node547 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected547 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected547 ((3 : Int),(1 : Int)) hp4_3_branches547 hp4_3_evidence547 hp4_3_check547 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches547,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node548 T childKnown
  · exact hp4_3_node550 T childKnown
  · exact hp4_3_node551 T childKnown
theorem hp4_3_node546 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected546 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected546 ((1 : Int),(1 : Int)) hp4_3_branches546 hp4_3_evidence546 hp4_3_check546 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches546,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node547 T childKnown
theorem hp4_3_node545 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected545 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected545 ((2 : Int),(1 : Int)) hp4_3_branches545 hp4_3_evidence545 hp4_3_check545 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches545,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node544 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected544 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected544 ((2 : Int),(1 : Int)) hp4_3_branches544 hp4_3_evidence544 hp4_3_check544 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches544,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node543 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected543 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected543 ((2 : Int),(0 : Int)) hp4_3_branches543 hp4_3_evidence543 hp4_3_check543 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches543,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node544 T childKnown
  · exact hp4_3_node545 T childKnown
theorem hp4_3_node542 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected542 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected542 ((8 : Int),(1 : Int)) hp4_3_branches542 hp4_3_evidence542 hp4_3_check542 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches542,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node541 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected541 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected541 ((8 : Int),(1 : Int)) hp4_3_branches541 hp4_3_evidence541 hp4_3_check541 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches541,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node540 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected540 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected540 ((8 : Int),(1 : Int)) hp4_3_branches540 hp4_3_evidence540 hp4_3_check540 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches540,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node539 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected539 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected539 ((7 : Int),(1 : Int)) hp4_3_branches539 hp4_3_evidence539 hp4_3_check539 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches539,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node540 T childKnown
  · exact hp4_3_node541 T childKnown
  · exact hp4_3_node542 T childKnown
theorem hp4_3_node538 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected538 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected538 ((8 : Int),(1 : Int)) hp4_3_branches538 hp4_3_evidence538 hp4_3_check538 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches538,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node537 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected537 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected537 ((8 : Int),(1 : Int)) hp4_3_branches537 hp4_3_evidence537 hp4_3_check537 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches537,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node536 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected536 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected536 ((7 : Int),(1 : Int)) hp4_3_branches536 hp4_3_evidence536 hp4_3_check536 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches536,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node537 T childKnown
  · exact hp4_3_node538 T childKnown
theorem hp4_3_node535 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected535 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected535 ((7 : Int),(1 : Int)) hp4_3_branches535 hp4_3_evidence535 hp4_3_check535 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches535,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node534 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected534 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected534 ((7 : Int),(1 : Int)) hp4_3_branches534 hp4_3_evidence534 hp4_3_check534 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches534,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node533 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected533 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected533 ((7 : Int),(1 : Int)) hp4_3_branches533 hp4_3_evidence533 hp4_3_check533 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches533,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node532 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected532 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected532 ((8 : Int),(0 : Int)) hp4_3_branches532 hp4_3_evidence532 hp4_3_check532 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches532,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node533 T childKnown
  · exact hp4_3_node534 T childKnown
  · exact hp4_3_node535 T childKnown
  · exact hp4_3_node536 T childKnown
  · exact hp4_3_node539 T childKnown
theorem hp4_3_node531 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected531 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected531 ((3 : Int),(2 : Int)) hp4_3_branches531 hp4_3_evidence531 hp4_3_check531 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches531,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node530 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected530 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected530 ((3 : Int),(2 : Int)) hp4_3_branches530 hp4_3_evidence530 hp4_3_check530 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches530,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node529 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected529 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected529 ((4 : Int),(2 : Int)) hp4_3_branches529 hp4_3_evidence529 hp4_3_check529 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches529,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node528 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected528 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected528 ((3 : Int),(2 : Int)) hp4_3_branches528 hp4_3_evidence528 hp4_3_check528 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches528,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node529 T childKnown
theorem hp4_3_node527 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected527 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected527 ((2 : Int),(2 : Int)) hp4_3_branches527 hp4_3_evidence527 hp4_3_check527 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches527,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node528 T childKnown
  · exact hp4_3_node530 T childKnown
  · exact hp4_3_node531 T childKnown
  · exact hp4_3_node532 T childKnown
theorem hp4_3_node526 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected526 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected526 ((2 : Int),(0 : Int)) hp4_3_branches526 hp4_3_evidence526 hp4_3_check526 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches526,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node527 T childKnown
theorem hp4_3_node525 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected525 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected525 ((1 : Int),(0 : Int)) hp4_3_branches525 hp4_3_evidence525 hp4_3_check525 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches525,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node526 T childKnown
  · exact hp4_3_node543 T childKnown
  · exact hp4_3_node546 T childKnown
  · exact hp4_3_node552 T childKnown
theorem hp4_3_node524 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected524 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected524 ((2 : Int),(1 : Int)) hp4_3_branches524 hp4_3_evidence524 hp4_3_check524 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches524,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node523 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected523 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected523 ((2 : Int),(1 : Int)) hp4_3_branches523 hp4_3_evidence523 hp4_3_check523 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches523,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node522 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected522 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected522 ((1 : Int),(1 : Int)) hp4_3_branches522 hp4_3_evidence522 hp4_3_check522 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches522,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node523 T childKnown
  · exact hp4_3_node524 T childKnown
theorem hp4_3_node521 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected521 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected521 ((3 : Int),(2 : Int)) hp4_3_branches521 hp4_3_evidence521 hp4_3_check521 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches521,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node520 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected520 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected520 ((3 : Int),(2 : Int)) hp4_3_branches520 hp4_3_evidence520 hp4_3_check520 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches520,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node519 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected519 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected519 ((4 : Int),(2 : Int)) hp4_3_branches519 hp4_3_evidence519 hp4_3_check519 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches519,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node518 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected518 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected518 ((4 : Int),(1 : Int)) hp4_3_branches518 hp4_3_evidence518 hp4_3_check518 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches518,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node519 T childKnown
theorem hp4_3_node517 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected517 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected517 ((3 : Int),(1 : Int)) hp4_3_branches517 hp4_3_evidence517 hp4_3_check517 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches517,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node518 T childKnown
  · exact hp4_3_node520 T childKnown
  · exact hp4_3_node521 T childKnown
theorem hp4_3_node516 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected516 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected516 ((1 : Int),(1 : Int)) hp4_3_branches516 hp4_3_evidence516 hp4_3_check516 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches516,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node517 T childKnown
theorem hp4_3_node515 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected515 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected515 ((2 : Int),(1 : Int)) hp4_3_branches515 hp4_3_evidence515 hp4_3_check515 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches515,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node514 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected514 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected514 ((2 : Int),(1 : Int)) hp4_3_branches514 hp4_3_evidence514 hp4_3_check514 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches514,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node513 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected513 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected513 ((2 : Int),(0 : Int)) hp4_3_branches513 hp4_3_evidence513 hp4_3_check513 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches513,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node514 T childKnown
  · exact hp4_3_node515 T childKnown
theorem hp4_3_node512 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected512 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected512 ((8 : Int),(1 : Int)) hp4_3_branches512 hp4_3_evidence512 hp4_3_check512 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches512,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node511 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected511 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected511 ((8 : Int),(1 : Int)) hp4_3_branches511 hp4_3_evidence511 hp4_3_check511 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches511,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node510 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected510 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected510 ((8 : Int),(1 : Int)) hp4_3_branches510 hp4_3_evidence510 hp4_3_check510 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches510,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node509 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected509 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected509 ((7 : Int),(1 : Int)) hp4_3_branches509 hp4_3_evidence509 hp4_3_check509 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches509,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node510 T childKnown
  · exact hp4_3_node511 T childKnown
  · exact hp4_3_node512 T childKnown
theorem hp4_3_node508 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected508 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected508 ((8 : Int),(1 : Int)) hp4_3_branches508 hp4_3_evidence508 hp4_3_check508 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches508,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node507 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected507 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected507 ((8 : Int),(1 : Int)) hp4_3_branches507 hp4_3_evidence507 hp4_3_check507 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches507,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node506 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected506 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected506 ((7 : Int),(1 : Int)) hp4_3_branches506 hp4_3_evidence506 hp4_3_check506 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches506,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node507 T childKnown
  · exact hp4_3_node508 T childKnown
theorem hp4_3_node505 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected505 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected505 ((7 : Int),(1 : Int)) hp4_3_branches505 hp4_3_evidence505 hp4_3_check505 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches505,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node504 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected504 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected504 ((7 : Int),(1 : Int)) hp4_3_branches504 hp4_3_evidence504 hp4_3_check504 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches504,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node503 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected503 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected503 ((7 : Int),(1 : Int)) hp4_3_branches503 hp4_3_evidence503 hp4_3_check503 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches503,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node502 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected502 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected502 ((8 : Int),(0 : Int)) hp4_3_branches502 hp4_3_evidence502 hp4_3_check502 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches502,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node503 T childKnown
  · exact hp4_3_node504 T childKnown
  · exact hp4_3_node505 T childKnown
  · exact hp4_3_node506 T childKnown
  · exact hp4_3_node509 T childKnown
theorem hp4_3_node501 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected501 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected501 ((3 : Int),(2 : Int)) hp4_3_branches501 hp4_3_evidence501 hp4_3_check501 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches501,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node500 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected500 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected500 ((3 : Int),(2 : Int)) hp4_3_branches500 hp4_3_evidence500 hp4_3_check500 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches500,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node499 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected499 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected499 ((4 : Int),(2 : Int)) hp4_3_branches499 hp4_3_evidence499 hp4_3_check499 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches499,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node498 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected498 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected498 ((3 : Int),(2 : Int)) hp4_3_branches498 hp4_3_evidence498 hp4_3_check498 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches498,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node499 T childKnown
theorem hp4_3_node497 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected497 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected497 ((2 : Int),(2 : Int)) hp4_3_branches497 hp4_3_evidence497 hp4_3_check497 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches497,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node498 T childKnown
  · exact hp4_3_node500 T childKnown
  · exact hp4_3_node501 T childKnown
  · exact hp4_3_node502 T childKnown
theorem hp4_3_node496 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected496 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected496 ((2 : Int),(0 : Int)) hp4_3_branches496 hp4_3_evidence496 hp4_3_check496 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches496,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node497 T childKnown
theorem hp4_3_node495 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected495 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected495 ((1 : Int),(0 : Int)) hp4_3_branches495 hp4_3_evidence495 hp4_3_check495 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches495,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node496 T childKnown
  · exact hp4_3_node513 T childKnown
  · exact hp4_3_node516 T childKnown
  · exact hp4_3_node522 T childKnown
theorem hp4_3_node494 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected494 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected494 ((5 : Int),(1 : Int)) hp4_3_branches494 hp4_3_evidence494 hp4_3_check494 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches494,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node493 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected493 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected493 ((3 : Int),(1 : Int)) hp4_3_branches493 hp4_3_evidence493 hp4_3_check493 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches493,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node492 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected492 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected492 ((3 : Int),(1 : Int)) hp4_3_branches492 hp4_3_evidence492 hp4_3_check492 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches492,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node491 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected491 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected491 ((2 : Int),(1 : Int)) hp4_3_branches491 hp4_3_evidence491 hp4_3_check491 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches491,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node490 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected490 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected490 ((4 : Int),(1 : Int)) hp4_3_branches490 hp4_3_evidence490 hp4_3_check490 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches490,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node491 T childKnown
  · exact hp4_3_node492 T childKnown
  · exact hp4_3_node493 T childKnown
  · exact hp4_3_node494 T childKnown
theorem hp4_3_node489 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected489 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected489 ((3 : Int),(1 : Int)) hp4_3_branches489 hp4_3_evidence489 hp4_3_check489 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches489,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node488 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected488 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected488 ((3 : Int),(1 : Int)) hp4_3_branches488 hp4_3_evidence488 hp4_3_check488 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches488,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node487 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected487 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected487 ((5 : Int),(2 : Int)) hp4_3_branches487 hp4_3_evidence487 hp4_3_check487 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches487,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node486 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected486 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected486 ((5 : Int),(2 : Int)) hp4_3_branches486 hp4_3_evidence486 hp4_3_check486 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches486,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node485 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected485 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected485 ((6 : Int),(2 : Int)) hp4_3_branches485 hp4_3_evidence485 hp4_3_check485 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches485,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node484 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected484 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected484 ((6 : Int),(1 : Int)) hp4_3_branches484 hp4_3_evidence484 hp4_3_check484 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches484,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node485 T childKnown
theorem hp4_3_node483 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected483 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected483 ((5 : Int),(1 : Int)) hp4_3_branches483 hp4_3_evidence483 hp4_3_check483 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches483,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node484 T childKnown
  · exact hp4_3_node486 T childKnown
  · exact hp4_3_node487 T childKnown
theorem hp4_3_node482 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected482 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected482 ((0 : Int),(2 : Int)) hp4_3_branches482 hp4_3_evidence482 hp4_3_check482 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches482,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node481 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected481 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected481 ((0 : Int),(2 : Int)) hp4_3_branches481 hp4_3_evidence481 hp4_3_check481 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches481,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node480 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected480 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected480 ((0 : Int),(1 : Int)) hp4_3_branches480 hp4_3_evidence480 hp4_3_check480 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches480,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node481 T childKnown
  · exact hp4_3_node482 T childKnown
  · exact hp4_3_node483 T childKnown
theorem hp4_3_node479 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected479 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected479 ((3 : Int),(1 : Int)) hp4_3_branches479 hp4_3_evidence479 hp4_3_check479 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches479,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node480 T childKnown
theorem hp4_3_node478 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected478 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected478 ((3 : Int),(1 : Int)) hp4_3_branches478 hp4_3_evidence478 hp4_3_check478 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches478,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node477 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected477 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected477 ((2 : Int),(1 : Int)) hp4_3_branches477 hp4_3_evidence477 hp4_3_check477 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches477,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node478 T childKnown
  · exact hp4_3_node479 T childKnown
  · exact hp4_3_node488 T childKnown
  · exact hp4_3_node489 T childKnown
theorem hp4_3_node476 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected476 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected476 ((4 : Int),(1 : Int)) hp4_3_branches476 hp4_3_evidence476 hp4_3_check476 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches476,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node475 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected475 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected475 ((4 : Int),(1 : Int)) hp4_3_branches475 hp4_3_evidence475 hp4_3_check475 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches475,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node474 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected474 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected474 ((4 : Int),(0 : Int)) hp4_3_branches474 hp4_3_evidence474 hp4_3_check474 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches474,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node475 T childKnown
  · exact hp4_3_node476 T childKnown
theorem hp4_3_node473 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected473 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected473 ((2 : Int),(1 : Int)) hp4_3_branches473 hp4_3_evidence473 hp4_3_check473 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches473,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node474 T childKnown
theorem hp4_3_node472 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected472 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected472 ((10 : Int),(1 : Int)) hp4_3_branches472 hp4_3_evidence472 hp4_3_check472 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches472,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node471 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected471 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected471 ((10 : Int),(1 : Int)) hp4_3_branches471 hp4_3_evidence471 hp4_3_check471 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches471,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node470 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected470 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected470 ((10 : Int),(1 : Int)) hp4_3_branches470 hp4_3_evidence470 hp4_3_check470 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches470,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node469 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected469 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected469 ((9 : Int),(1 : Int)) hp4_3_branches469 hp4_3_evidence469 hp4_3_check469 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches469,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node470 T childKnown
  · exact hp4_3_node471 T childKnown
  · exact hp4_3_node472 T childKnown
theorem hp4_3_node468 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected468 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected468 ((10 : Int),(1 : Int)) hp4_3_branches468 hp4_3_evidence468 hp4_3_check468 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches468,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node467 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected467 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected467 ((10 : Int),(1 : Int)) hp4_3_branches467 hp4_3_evidence467 hp4_3_check467 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches467,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node466 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected466 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected466 ((9 : Int),(1 : Int)) hp4_3_branches466 hp4_3_evidence466 hp4_3_check466 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches466,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node467 T childKnown
  · exact hp4_3_node468 T childKnown
theorem hp4_3_node465 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected465 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected465 ((9 : Int),(1 : Int)) hp4_3_branches465 hp4_3_evidence465 hp4_3_check465 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches465,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node464 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected464 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected464 ((9 : Int),(1 : Int)) hp4_3_branches464 hp4_3_evidence464 hp4_3_check464 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches464,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node463 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected463 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected463 ((9 : Int),(1 : Int)) hp4_3_branches463 hp4_3_evidence463 hp4_3_check463 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches463,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node462 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected462 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected462 ((10 : Int),(0 : Int)) hp4_3_branches462 hp4_3_evidence462 hp4_3_check462 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches462,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node463 T childKnown
  · exact hp4_3_node464 T childKnown
  · exact hp4_3_node465 T childKnown
  · exact hp4_3_node466 T childKnown
  · exact hp4_3_node469 T childKnown
theorem hp4_3_node461 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected461 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected461 ((5 : Int),(2 : Int)) hp4_3_branches461 hp4_3_evidence461 hp4_3_check461 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches461,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node460 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected460 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected460 ((5 : Int),(2 : Int)) hp4_3_branches460 hp4_3_evidence460 hp4_3_check460 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches460,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node459 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected459 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected459 ((4 : Int),(2 : Int)) hp4_3_branches459 hp4_3_evidence459 hp4_3_check459 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches459,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node460 T childKnown
  · exact hp4_3_node461 T childKnown
  · exact hp4_3_node462 T childKnown
theorem hp4_3_node458 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected458 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected458 ((0 : Int),(2 : Int)) hp4_3_branches458 hp4_3_evidence458 hp4_3_check458 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches458,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node457 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected457 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected457 ((0 : Int),(2 : Int)) hp4_3_branches457 hp4_3_evidence457 hp4_3_check457 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches457,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node456 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected456 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected456 ((0 : Int),(1 : Int)) hp4_3_branches456 hp4_3_evidence456 hp4_3_check456 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches456,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node457 T childKnown
  · exact hp4_3_node458 T childKnown
  · exact hp4_3_node459 T childKnown
theorem hp4_3_node455 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected455 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected455 ((4 : Int),(0 : Int)) hp4_3_branches455 hp4_3_evidence455 hp4_3_check455 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches455,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node456 T childKnown
theorem hp4_3_node454 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected454 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected454 ((2 : Int),(1 : Int)) hp4_3_branches454 hp4_3_evidence454 hp4_3_check454 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches454,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node455 T childKnown
theorem hp4_3_node453 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected453 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected453 ((2 : Int),(1 : Int)) hp4_3_branches453 hp4_3_evidence453 hp4_3_check453 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches453,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node452 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected452 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected452 ((2 : Int),(1 : Int)) hp4_3_branches452 hp4_3_evidence452 hp4_3_check452 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches452,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node451 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected451 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected451 ((3 : Int),(0 : Int)) hp4_3_branches451 hp4_3_evidence451 hp4_3_check451 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches451,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node452 T childKnown
  · exact hp4_3_node453 T childKnown
  · exact hp4_3_node454 T childKnown
  · exact hp4_3_node473 T childKnown
  · exact hp4_3_node477 T childKnown
  · exact hp4_3_node490 T childKnown
theorem hp4_3_node450 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected450 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected450 ((11 : Int),(1 : Int)) hp4_3_branches450 hp4_3_evidence450 hp4_3_check450 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches450,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node449 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected449 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected449 ((9 : Int),(1 : Int)) hp4_3_branches449 hp4_3_evidence449 hp4_3_check449 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches449,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node448 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected448 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected448 ((9 : Int),(1 : Int)) hp4_3_branches448 hp4_3_evidence448 hp4_3_check448 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches448,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node447 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected447 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected447 ((8 : Int),(1 : Int)) hp4_3_branches447 hp4_3_evidence447 hp4_3_check447 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches447,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node446 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected446 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected446 ((10 : Int),(1 : Int)) hp4_3_branches446 hp4_3_evidence446 hp4_3_check446 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches446,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node447 T childKnown
  · exact hp4_3_node448 T childKnown
  · exact hp4_3_node449 T childKnown
  · exact hp4_3_node450 T childKnown
theorem hp4_3_node445 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected445 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected445 ((9 : Int),(1 : Int)) hp4_3_branches445 hp4_3_evidence445 hp4_3_check445 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches445,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node444 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected444 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected444 ((9 : Int),(1 : Int)) hp4_3_branches444 hp4_3_evidence444 hp4_3_check444 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches444,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node443 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected443 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected443 ((2 : Int),(2 : Int)) hp4_3_branches443 hp4_3_evidence443 hp4_3_check443 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches443,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node442 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected442 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected442 ((5 : Int),(1 : Int)) hp4_3_branches442 hp4_3_evidence442 hp4_3_check442 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches442,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node443 T childKnown
theorem hp4_3_node441 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected441 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected441 ((6 : Int),(2 : Int)) hp4_3_branches441 hp4_3_evidence441 hp4_3_check441 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches441,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node440 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected440 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected440 ((5 : Int),(2 : Int)) hp4_3_branches440 hp4_3_evidence440 hp4_3_check440 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches440,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node439 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected439 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected439 ((6 : Int),(1 : Int)) hp4_3_branches439 hp4_3_evidence439 hp4_3_check439 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches439,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node440 T childKnown
  · exact hp4_3_node441 T childKnown
  · exact hp4_3_node442 T childKnown
theorem hp4_3_node438 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected438 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected438 ((9 : Int),(1 : Int)) hp4_3_branches438 hp4_3_evidence438 hp4_3_check438 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches438,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node439 T childKnown
theorem hp4_3_node437 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected437 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected437 ((9 : Int),(1 : Int)) hp4_3_branches437 hp4_3_evidence437 hp4_3_check437 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches437,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node436 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected436 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected436 ((8 : Int),(1 : Int)) hp4_3_branches436 hp4_3_evidence436 hp4_3_check436 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches436,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node437 T childKnown
  · exact hp4_3_node438 T childKnown
  · exact hp4_3_node444 T childKnown
  · exact hp4_3_node445 T childKnown
theorem hp4_3_node435 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected435 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected435 ((10 : Int),(1 : Int)) hp4_3_branches435 hp4_3_evidence435 hp4_3_check435 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches435,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node434 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected434 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected434 ((10 : Int),(1 : Int)) hp4_3_branches434 hp4_3_evidence434 hp4_3_check434 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches434,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node433 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected433 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected433 ((10 : Int),(0 : Int)) hp4_3_branches433 hp4_3_evidence433 hp4_3_check433 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches433,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node434 T childKnown
  · exact hp4_3_node435 T childKnown
theorem hp4_3_node432 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected432 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected432 ((8 : Int),(1 : Int)) hp4_3_branches432 hp4_3_evidence432 hp4_3_check432 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches432,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node433 T childKnown
theorem hp4_3_node431 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected431 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected431 ((2 : Int),(2 : Int)) hp4_3_branches431 hp4_3_evidence431 hp4_3_check431 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches431,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node430 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected430 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected430 ((5 : Int),(1 : Int)) hp4_3_branches430 hp4_3_evidence430 hp4_3_check430 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches430,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node431 T childKnown
theorem hp4_3_node429 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected429 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected429 ((6 : Int),(2 : Int)) hp4_3_branches429 hp4_3_evidence429 hp4_3_check429 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches429,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node428 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected428 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected428 ((5 : Int),(2 : Int)) hp4_3_branches428 hp4_3_evidence428 hp4_3_check428 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches428,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node427 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected427 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected427 ((6 : Int),(1 : Int)) hp4_3_branches427 hp4_3_evidence427 hp4_3_check427 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches427,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node428 T childKnown
  · exact hp4_3_node429 T childKnown
  · exact hp4_3_node430 T childKnown
theorem hp4_3_node426 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected426 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected426 ((10 : Int),(0 : Int)) hp4_3_branches426 hp4_3_evidence426 hp4_3_check426 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches426,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node427 T childKnown
theorem hp4_3_node425 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected425 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected425 ((8 : Int),(1 : Int)) hp4_3_branches425 hp4_3_evidence425 hp4_3_check425 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches425,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node426 T childKnown
theorem hp4_3_node424 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected424 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected424 ((8 : Int),(1 : Int)) hp4_3_branches424 hp4_3_evidence424 hp4_3_check424 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches424,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node423 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected423 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected423 ((8 : Int),(1 : Int)) hp4_3_branches423 hp4_3_evidence423 hp4_3_check423 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches423,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node422 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected422 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected422 ((9 : Int),(0 : Int)) hp4_3_branches422 hp4_3_evidence422 hp4_3_check422 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches422,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node423 T childKnown
  · exact hp4_3_node424 T childKnown
  · exact hp4_3_node425 T childKnown
  · exact hp4_3_node432 T childKnown
  · exact hp4_3_node436 T childKnown
  · exact hp4_3_node446 T childKnown
theorem hp4_3_node421 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected421 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected421 ((2 : Int),(1 : Int)) hp4_3_branches421 hp4_3_evidence421 hp4_3_check421 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches421,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node420 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected420 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected420 ((0 : Int),(1 : Int)) hp4_3_branches420 hp4_3_evidence420 hp4_3_check420 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches420,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node419 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected419 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected419 ((0 : Int),(1 : Int)) hp4_3_branches419 hp4_3_evidence419 hp4_3_check419 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches419,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node418 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected418 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected418 ((0 : Int),(1 : Int)) hp4_3_branches418 hp4_3_evidence418 hp4_3_check418 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches418,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node417 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected417 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected417 ((1 : Int),(1 : Int)) hp4_3_branches417 hp4_3_evidence417 hp4_3_check417 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches417,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node418 T childKnown
  · exact hp4_3_node419 T childKnown
  · exact hp4_3_node420 T childKnown
  · exact hp4_3_node421 T childKnown
theorem hp4_3_node416 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected416 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected416 ((1 : Int),(1 : Int)) hp4_3_branches416 hp4_3_evidence416 hp4_3_check416 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches416,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node415 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected415 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected415 ((1 : Int),(1 : Int)) hp4_3_branches415 hp4_3_evidence415 hp4_3_check415 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches415,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node414 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected414 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected414 ((0 : Int),(1 : Int)) hp4_3_branches414 hp4_3_evidence414 hp4_3_check414 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches414,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node415 T childKnown
  · exact hp4_3_node416 T childKnown
theorem hp4_3_node413 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected413 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected413 ((1 : Int),(1 : Int)) hp4_3_branches413 hp4_3_evidence413 hp4_3_check413 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches413,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node412 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected412 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected412 ((1 : Int),(1 : Int)) hp4_3_branches412 hp4_3_evidence412 hp4_3_check412 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches412,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node411 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected411 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected411 ((0 : Int),(1 : Int)) hp4_3_branches411 hp4_3_evidence411 hp4_3_check411 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches411,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node412 T childKnown
  · exact hp4_3_node413 T childKnown
theorem hp4_3_node410 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected410 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected410 ((4 : Int),(0 : Int)) hp4_3_branches410 hp4_3_evidence410 hp4_3_check410 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches410,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node411 T childKnown
theorem hp4_3_node409 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected409 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected409 ((2 : Int),(1 : Int)) hp4_3_branches409 hp4_3_evidence409 hp4_3_check409 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches409,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node408 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected408 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected408 ((0 : Int),(1 : Int)) hp4_3_branches408 hp4_3_evidence408 hp4_3_check408 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches408,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node407 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected407 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected407 ((1 : Int),(2 : Int)) hp4_3_branches407 hp4_3_evidence407 hp4_3_check407 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches407,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node406 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected406 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected406 ((5 : Int),(1 : Int)) hp4_3_branches406 hp4_3_evidence406 hp4_3_check406 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches406,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node405 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected405 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected405 ((5 : Int),(1 : Int)) hp4_3_branches405 hp4_3_evidence405 hp4_3_check405 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches405,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node404 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected404 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected404 ((4 : Int),(1 : Int)) hp4_3_branches404 hp4_3_evidence404 hp4_3_check404 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches404,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node405 T childKnown
  · exact hp4_3_node406 T childKnown
theorem hp4_3_node403 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected403 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected403 ((6 : Int),(2 : Int)) hp4_3_branches403 hp4_3_evidence403 hp4_3_check403 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches403,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node402 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected402 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected402 ((6 : Int),(2 : Int)) hp4_3_branches402 hp4_3_evidence402 hp4_3_check402 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches402,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node401 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected401 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected401 ((7 : Int),(2 : Int)) hp4_3_branches401 hp4_3_evidence401 hp4_3_check401 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches401,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node400 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected400 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected400 ((7 : Int),(1 : Int)) hp4_3_branches400 hp4_3_evidence400 hp4_3_check400 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches400,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node401 T childKnown
theorem hp4_3_node399 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected399 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected399 ((6 : Int),(1 : Int)) hp4_3_branches399 hp4_3_evidence399 hp4_3_check399 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches399,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node400 T childKnown
  · exact hp4_3_node402 T childKnown
  · exact hp4_3_node403 T childKnown
theorem hp4_3_node398 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected398 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected398 ((4 : Int),(1 : Int)) hp4_3_branches398 hp4_3_evidence398 hp4_3_check398 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches398,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node399 T childKnown
theorem hp4_3_node397 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected397 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected397 ((5 : Int),(1 : Int)) hp4_3_branches397 hp4_3_evidence397 hp4_3_check397 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches397,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node396 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected396 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected396 ((5 : Int),(1 : Int)) hp4_3_branches396 hp4_3_evidence396 hp4_3_check396 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches396,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node395 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected395 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected395 ((5 : Int),(0 : Int)) hp4_3_branches395 hp4_3_evidence395 hp4_3_check395 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches395,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node396 T childKnown
  · exact hp4_3_node397 T childKnown
theorem hp4_3_node394 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected394 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected394 ((11 : Int),(1 : Int)) hp4_3_branches394 hp4_3_evidence394 hp4_3_check394 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches394,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node393 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected393 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected393 ((11 : Int),(1 : Int)) hp4_3_branches393 hp4_3_evidence393 hp4_3_check393 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches393,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node392 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected392 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected392 ((11 : Int),(1 : Int)) hp4_3_branches392 hp4_3_evidence392 hp4_3_check392 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches392,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node391 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected391 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected391 ((10 : Int),(1 : Int)) hp4_3_branches391 hp4_3_evidence391 hp4_3_check391 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches391,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node392 T childKnown
  · exact hp4_3_node393 T childKnown
  · exact hp4_3_node394 T childKnown
theorem hp4_3_node390 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected390 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected390 ((11 : Int),(1 : Int)) hp4_3_branches390 hp4_3_evidence390 hp4_3_check390 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches390,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node389 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected389 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected389 ((11 : Int),(1 : Int)) hp4_3_branches389 hp4_3_evidence389 hp4_3_check389 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches389,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node388 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected388 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected388 ((10 : Int),(1 : Int)) hp4_3_branches388 hp4_3_evidence388 hp4_3_check388 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches388,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node389 T childKnown
  · exact hp4_3_node390 T childKnown
theorem hp4_3_node387 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected387 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected387 ((10 : Int),(1 : Int)) hp4_3_branches387 hp4_3_evidence387 hp4_3_check387 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches387,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node386 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected386 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected386 ((10 : Int),(1 : Int)) hp4_3_branches386 hp4_3_evidence386 hp4_3_check386 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches386,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node385 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected385 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected385 ((10 : Int),(1 : Int)) hp4_3_branches385 hp4_3_evidence385 hp4_3_check385 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches385,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node384 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected384 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected384 ((11 : Int),(0 : Int)) hp4_3_branches384 hp4_3_evidence384 hp4_3_check384 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches384,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node385 T childKnown
  · exact hp4_3_node386 T childKnown
  · exact hp4_3_node387 T childKnown
  · exact hp4_3_node388 T childKnown
  · exact hp4_3_node391 T childKnown
theorem hp4_3_node383 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected383 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected383 ((6 : Int),(2 : Int)) hp4_3_branches383 hp4_3_evidence383 hp4_3_check383 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches383,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node382 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected382 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected382 ((6 : Int),(2 : Int)) hp4_3_branches382 hp4_3_evidence382 hp4_3_check382 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches382,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node381 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected381 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected381 ((7 : Int),(2 : Int)) hp4_3_branches381 hp4_3_evidence381 hp4_3_check381 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches381,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node380 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected380 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected380 ((6 : Int),(2 : Int)) hp4_3_branches380 hp4_3_evidence380 hp4_3_check380 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches380,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node381 T childKnown
theorem hp4_3_node379 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected379 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected379 ((5 : Int),(2 : Int)) hp4_3_branches379 hp4_3_evidence379 hp4_3_check379 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches379,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node380 T childKnown
  · exact hp4_3_node382 T childKnown
  · exact hp4_3_node383 T childKnown
  · exact hp4_3_node384 T childKnown
theorem hp4_3_node378 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected378 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected378 ((5 : Int),(0 : Int)) hp4_3_branches378 hp4_3_evidence378 hp4_3_check378 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches378,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node379 T childKnown
theorem hp4_3_node377 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected377 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected377 ((4 : Int),(0 : Int)) hp4_3_branches377 hp4_3_evidence377 hp4_3_check377 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches377,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node378 T childKnown
  · exact hp4_3_node395 T childKnown
  · exact hp4_3_node398 T childKnown
  · exact hp4_3_node404 T childKnown
theorem hp4_3_node376 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected376 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected376 ((2 : Int),(2 : Int)) hp4_3_branches376 hp4_3_evidence376 hp4_3_check376 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches376,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node375 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected375 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected375 ((1 : Int),(2 : Int)) hp4_3_branches375 hp4_3_evidence375 hp4_3_check375 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches375,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node376 T childKnown
theorem hp4_3_node374 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected374 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected374 ((1 : Int),(2 : Int)) hp4_3_branches374 hp4_3_evidence374 hp4_3_check374 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches374,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node373 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected373 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected373 ((0 : Int),(2 : Int)) hp4_3_branches373 hp4_3_evidence373 hp4_3_check373 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches373,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node374 T childKnown
  · exact hp4_3_node375 T childKnown
  · exact hp4_3_node377 T childKnown
  · exact hp4_3_node407 T childKnown
theorem hp4_3_node372 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected372 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected372 ((0 : Int),(1 : Int)) hp4_3_branches372 hp4_3_evidence372 hp4_3_check372 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches372,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node371 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected371 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected371 ((3 : Int),(0 : Int)) hp4_3_branches371 hp4_3_evidence371 hp4_3_check371 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches371,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node372 T childKnown
  · exact hp4_3_node373 T childKnown
  · exact hp4_3_node408 T childKnown
  · exact hp4_3_node409 T childKnown
  · exact hp4_3_node410 T childKnown
  · exact hp4_3_node414 T childKnown
  · exact hp4_3_node417 T childKnown
  · exact hp4_3_node422 T childKnown
theorem hp4_3_node370 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected370 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected370 ((1 : Int),(1 : Int)) hp4_3_branches370 hp4_3_evidence370 hp4_3_check370 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches370,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node369 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected369 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected369 ((1 : Int),(1 : Int)) hp4_3_branches369 hp4_3_evidence369 hp4_3_check369 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches369,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node368 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected368 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected368 ((1 : Int),(0 : Int)) hp4_3_branches368 hp4_3_evidence368 hp4_3_check368 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches368,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node369 T childKnown
  · exact hp4_3_node370 T childKnown
theorem hp4_3_node367 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected367 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected367 ((4 : Int),(1 : Int)) hp4_3_branches367 hp4_3_evidence367 hp4_3_check367 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches367,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node366 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected366 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected366 ((2 : Int),(1 : Int)) hp4_3_branches366 hp4_3_evidence366 hp4_3_check366 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches366,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node365 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected365 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected365 ((2 : Int),(1 : Int)) hp4_3_branches365 hp4_3_evidence365 hp4_3_check365 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches365,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node364 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected364 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected364 ((1 : Int),(1 : Int)) hp4_3_branches364 hp4_3_evidence364 hp4_3_check364 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches364,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node363 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected363 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected363 ((3 : Int),(1 : Int)) hp4_3_branches363 hp4_3_evidence363 hp4_3_check363 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches363,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node364 T childKnown
  · exact hp4_3_node365 T childKnown
  · exact hp4_3_node366 T childKnown
  · exact hp4_3_node367 T childKnown
theorem hp4_3_node362 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected362 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected362 ((2 : Int),(1 : Int)) hp4_3_branches362 hp4_3_evidence362 hp4_3_check362 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches362,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node361 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected361 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected361 ((2 : Int),(1 : Int)) hp4_3_branches361 hp4_3_evidence361 hp4_3_check361 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches361,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node360 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected360 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected360 ((4 : Int),(2 : Int)) hp4_3_branches360 hp4_3_evidence360 hp4_3_check360 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches360,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node359 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected359 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected359 ((4 : Int),(2 : Int)) hp4_3_branches359 hp4_3_evidence359 hp4_3_check359 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches359,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node358 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected358 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected358 ((5 : Int),(2 : Int)) hp4_3_branches358 hp4_3_evidence358 hp4_3_check358 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches358,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node357 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected357 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected357 ((5 : Int),(1 : Int)) hp4_3_branches357 hp4_3_evidence357 hp4_3_check357 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches357,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node358 T childKnown
theorem hp4_3_node356 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected356 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected356 ((4 : Int),(1 : Int)) hp4_3_branches356 hp4_3_evidence356 hp4_3_check356 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches356,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node357 T childKnown
  · exact hp4_3_node359 T childKnown
  · exact hp4_3_node360 T childKnown
theorem hp4_3_node355 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected355 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected355 ((2 : Int),(1 : Int)) hp4_3_branches355 hp4_3_evidence355 hp4_3_check355 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches355,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node356 T childKnown
theorem hp4_3_node354 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected354 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected354 ((2 : Int),(1 : Int)) hp4_3_branches354 hp4_3_evidence354 hp4_3_check354 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches354,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node353 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected353 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected353 ((1 : Int),(1 : Int)) hp4_3_branches353 hp4_3_evidence353 hp4_3_check353 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches353,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node354 T childKnown
  · exact hp4_3_node355 T childKnown
  · exact hp4_3_node361 T childKnown
  · exact hp4_3_node362 T childKnown
theorem hp4_3_node352 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected352 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected352 ((3 : Int),(1 : Int)) hp4_3_branches352 hp4_3_evidence352 hp4_3_check352 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches352,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node351 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected351 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected351 ((3 : Int),(1 : Int)) hp4_3_branches351 hp4_3_evidence351 hp4_3_check351 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches351,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node350 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected350 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected350 ((3 : Int),(0 : Int)) hp4_3_branches350 hp4_3_evidence350 hp4_3_check350 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches350,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node351 T childKnown
  · exact hp4_3_node352 T childKnown
theorem hp4_3_node349 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected349 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected349 ((1 : Int),(1 : Int)) hp4_3_branches349 hp4_3_evidence349 hp4_3_check349 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches349,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node350 T childKnown
theorem hp4_3_node348 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected348 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected348 ((9 : Int),(1 : Int)) hp4_3_branches348 hp4_3_evidence348 hp4_3_check348 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches348,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node347 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected347 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected347 ((9 : Int),(1 : Int)) hp4_3_branches347 hp4_3_evidence347 hp4_3_check347 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches347,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node346 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected346 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected346 ((9 : Int),(1 : Int)) hp4_3_branches346 hp4_3_evidence346 hp4_3_check346 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches346,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node345 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected345 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected345 ((8 : Int),(1 : Int)) hp4_3_branches345 hp4_3_evidence345 hp4_3_check345 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches345,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node346 T childKnown
  · exact hp4_3_node347 T childKnown
  · exact hp4_3_node348 T childKnown
theorem hp4_3_node344 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected344 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected344 ((9 : Int),(1 : Int)) hp4_3_branches344 hp4_3_evidence344 hp4_3_check344 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches344,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node343 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected343 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected343 ((9 : Int),(1 : Int)) hp4_3_branches343 hp4_3_evidence343 hp4_3_check343 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches343,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node342 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected342 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected342 ((8 : Int),(1 : Int)) hp4_3_branches342 hp4_3_evidence342 hp4_3_check342 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches342,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node343 T childKnown
  · exact hp4_3_node344 T childKnown
theorem hp4_3_node341 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected341 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected341 ((8 : Int),(1 : Int)) hp4_3_branches341 hp4_3_evidence341 hp4_3_check341 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches341,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node340 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected340 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected340 ((8 : Int),(1 : Int)) hp4_3_branches340 hp4_3_evidence340 hp4_3_check340 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches340,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node339 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected339 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected339 ((8 : Int),(1 : Int)) hp4_3_branches339 hp4_3_evidence339 hp4_3_check339 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches339,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node338 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected338 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected338 ((9 : Int),(0 : Int)) hp4_3_branches338 hp4_3_evidence338 hp4_3_check338 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches338,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node339 T childKnown
  · exact hp4_3_node340 T childKnown
  · exact hp4_3_node341 T childKnown
  · exact hp4_3_node342 T childKnown
  · exact hp4_3_node345 T childKnown
theorem hp4_3_node337 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected337 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected337 ((4 : Int),(2 : Int)) hp4_3_branches337 hp4_3_evidence337 hp4_3_check337 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches337,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node336 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected336 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected336 ((4 : Int),(2 : Int)) hp4_3_branches336 hp4_3_evidence336 hp4_3_check336 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches336,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node335 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected335 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected335 ((3 : Int),(2 : Int)) hp4_3_branches335 hp4_3_evidence335 hp4_3_check335 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches335,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node336 T childKnown
  · exact hp4_3_node337 T childKnown
  · exact hp4_3_node338 T childKnown
theorem hp4_3_node334 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected334 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected334 ((3 : Int),(0 : Int)) hp4_3_branches334 hp4_3_evidence334 hp4_3_check334 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches334,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node335 T childKnown
theorem hp4_3_node333 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected333 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected333 ((1 : Int),(1 : Int)) hp4_3_branches333 hp4_3_evidence333 hp4_3_check333 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches333,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node334 T childKnown
theorem hp4_3_node332 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected332 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected332 ((1 : Int),(1 : Int)) hp4_3_branches332 hp4_3_evidence332 hp4_3_check332 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches332,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node331 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected331 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected331 ((1 : Int),(1 : Int)) hp4_3_branches331 hp4_3_evidence331 hp4_3_check331 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches331,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node330 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected330 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected330 ((2 : Int),(0 : Int)) hp4_3_branches330 hp4_3_evidence330 hp4_3_check330 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches330,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node331 T childKnown
  · exact hp4_3_node332 T childKnown
  · exact hp4_3_node333 T childKnown
  · exact hp4_3_node349 T childKnown
  · exact hp4_3_node353 T childKnown
  · exact hp4_3_node363 T childKnown
theorem hp4_3_node329 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected329 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected329 ((10 : Int),(1 : Int)) hp4_3_branches329 hp4_3_evidence329 hp4_3_check329 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches329,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node328 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected328 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected328 ((8 : Int),(1 : Int)) hp4_3_branches328 hp4_3_evidence328 hp4_3_check328 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches328,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node327 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected327 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected327 ((8 : Int),(1 : Int)) hp4_3_branches327 hp4_3_evidence327 hp4_3_check327 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches327,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node326 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected326 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected326 ((7 : Int),(1 : Int)) hp4_3_branches326 hp4_3_evidence326 hp4_3_check326 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches326,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node325 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected325 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected325 ((9 : Int),(1 : Int)) hp4_3_branches325 hp4_3_evidence325 hp4_3_check325 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches325,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node326 T childKnown
  · exact hp4_3_node327 T childKnown
  · exact hp4_3_node328 T childKnown
  · exact hp4_3_node329 T childKnown
theorem hp4_3_node324 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected324 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected324 ((8 : Int),(1 : Int)) hp4_3_branches324 hp4_3_evidence324 hp4_3_check324 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches324,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node323 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected323 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected323 ((8 : Int),(1 : Int)) hp4_3_branches323 hp4_3_evidence323 hp4_3_check323 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches323,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node322 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected322 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected322 ((1 : Int),(2 : Int)) hp4_3_branches322 hp4_3_evidence322 hp4_3_check322 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches322,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node321 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected321 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected321 ((4 : Int),(1 : Int)) hp4_3_branches321 hp4_3_evidence321 hp4_3_check321 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches321,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node322 T childKnown
theorem hp4_3_node320 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected320 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected320 ((5 : Int),(2 : Int)) hp4_3_branches320 hp4_3_evidence320 hp4_3_check320 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches320,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node319 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected319 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected319 ((4 : Int),(2 : Int)) hp4_3_branches319 hp4_3_evidence319 hp4_3_check319 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches319,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node318 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected318 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected318 ((5 : Int),(1 : Int)) hp4_3_branches318 hp4_3_evidence318 hp4_3_check318 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches318,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node319 T childKnown
  · exact hp4_3_node320 T childKnown
  · exact hp4_3_node321 T childKnown
theorem hp4_3_node317 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected317 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected317 ((8 : Int),(1 : Int)) hp4_3_branches317 hp4_3_evidence317 hp4_3_check317 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches317,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node318 T childKnown
theorem hp4_3_node316 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected316 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected316 ((8 : Int),(1 : Int)) hp4_3_branches316 hp4_3_evidence316 hp4_3_check316 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches316,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node315 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected315 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected315 ((7 : Int),(1 : Int)) hp4_3_branches315 hp4_3_evidence315 hp4_3_check315 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches315,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node316 T childKnown
  · exact hp4_3_node317 T childKnown
  · exact hp4_3_node323 T childKnown
  · exact hp4_3_node324 T childKnown
theorem hp4_3_node314 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected314 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected314 ((9 : Int),(1 : Int)) hp4_3_branches314 hp4_3_evidence314 hp4_3_check314 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches314,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node313 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected313 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected313 ((9 : Int),(1 : Int)) hp4_3_branches313 hp4_3_evidence313 hp4_3_check313 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches313,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node312 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected312 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected312 ((9 : Int),(0 : Int)) hp4_3_branches312 hp4_3_evidence312 hp4_3_check312 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches312,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node313 T childKnown
  · exact hp4_3_node314 T childKnown
theorem hp4_3_node311 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected311 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected311 ((7 : Int),(1 : Int)) hp4_3_branches311 hp4_3_evidence311 hp4_3_check311 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches311,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node312 T childKnown
theorem hp4_3_node310 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected310 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected310 ((1 : Int),(2 : Int)) hp4_3_branches310 hp4_3_evidence310 hp4_3_check310 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches310,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node309 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected309 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected309 ((4 : Int),(1 : Int)) hp4_3_branches309 hp4_3_evidence309 hp4_3_check309 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches309,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node310 T childKnown
theorem hp4_3_node308 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected308 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected308 ((5 : Int),(2 : Int)) hp4_3_branches308 hp4_3_evidence308 hp4_3_check308 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches308,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node307 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected307 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected307 ((4 : Int),(2 : Int)) hp4_3_branches307 hp4_3_evidence307 hp4_3_check307 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches307,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node306 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected306 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected306 ((5 : Int),(1 : Int)) hp4_3_branches306 hp4_3_evidence306 hp4_3_check306 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches306,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node307 T childKnown
  · exact hp4_3_node308 T childKnown
  · exact hp4_3_node309 T childKnown
theorem hp4_3_node305 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected305 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected305 ((9 : Int),(0 : Int)) hp4_3_branches305 hp4_3_evidence305 hp4_3_check305 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches305,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node306 T childKnown
theorem hp4_3_node304 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected304 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected304 ((7 : Int),(1 : Int)) hp4_3_branches304 hp4_3_evidence304 hp4_3_check304 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches304,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node305 T childKnown
theorem hp4_3_node303 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected303 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected303 ((7 : Int),(1 : Int)) hp4_3_branches303 hp4_3_evidence303 hp4_3_check303 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches303,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node302 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected302 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected302 ((7 : Int),(1 : Int)) hp4_3_branches302 hp4_3_evidence302 hp4_3_check302 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches302,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node301 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected301 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected301 ((8 : Int),(0 : Int)) hp4_3_branches301 hp4_3_evidence301 hp4_3_check301 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches301,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node302 T childKnown
  · exact hp4_3_node303 T childKnown
  · exact hp4_3_node304 T childKnown
  · exact hp4_3_node311 T childKnown
  · exact hp4_3_node315 T childKnown
  · exact hp4_3_node325 T childKnown
theorem hp4_3_node300 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected300 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected300 ((1 : Int),(1 : Int)) hp4_3_branches300 hp4_3_evidence300 hp4_3_check300 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches300,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node299 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected299 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected299 ((1 : Int),(1 : Int)) hp4_3_branches299 hp4_3_evidence299 hp4_3_check299 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches299,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node298 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected298 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected298 ((2 : Int),(1 : Int)) hp4_3_branches298 hp4_3_evidence298 hp4_3_check298 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches298,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node297 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected297 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected297 ((1 : Int),(1 : Int)) hp4_3_branches297 hp4_3_evidence297 hp4_3_check297 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches297,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node298 T childKnown
theorem hp4_3_node296 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected296 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected296 ((1 : Int),(1 : Int)) hp4_3_branches296 hp4_3_evidence296 hp4_3_check296 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches296,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node295 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected295 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected295 ((0 : Int),(1 : Int)) hp4_3_branches295 hp4_3_evidence295 hp4_3_check295 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches295,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node296 T childKnown
  · exact hp4_3_node297 T childKnown
  · exact hp4_3_node299 T childKnown
  · exact hp4_3_node300 T childKnown
theorem hp4_3_node294 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected294 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected294 ((1 : Int),(1 : Int)) hp4_3_branches294 hp4_3_evidence294 hp4_3_check294 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches294,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node293 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected293 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected293 ((1 : Int),(1 : Int)) hp4_3_branches293 hp4_3_evidence293 hp4_3_check293 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches293,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node292 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected292 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected292 ((0 : Int),(1 : Int)) hp4_3_branches292 hp4_3_evidence292 hp4_3_check292 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches292,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node293 T childKnown
  · exact hp4_3_node294 T childKnown
theorem hp4_3_node291 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected291 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected291 ((1 : Int),(1 : Int)) hp4_3_branches291 hp4_3_evidence291 hp4_3_check291 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches291,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node290 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected290 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected290 ((1 : Int),(1 : Int)) hp4_3_branches290 hp4_3_evidence290 hp4_3_check290 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches290,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node289 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected289 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected289 ((0 : Int),(1 : Int)) hp4_3_branches289 hp4_3_evidence289 hp4_3_check289 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches289,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node290 T childKnown
  · exact hp4_3_node291 T childKnown
theorem hp4_3_node288 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected288 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected288 ((3 : Int),(0 : Int)) hp4_3_branches288 hp4_3_evidence288 hp4_3_check288 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches288,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node289 T childKnown
theorem hp4_3_node287 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected287 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected287 ((1 : Int),(1 : Int)) hp4_3_branches287 hp4_3_evidence287 hp4_3_check287 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches287,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node286 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected286 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected286 ((0 : Int),(1 : Int)) hp4_3_branches286 hp4_3_evidence286 hp4_3_check286 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches286,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node285 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected285 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected285 ((1 : Int),(2 : Int)) hp4_3_branches285 hp4_3_evidence285 hp4_3_check285 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches285,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node284 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected284 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected284 ((4 : Int),(1 : Int)) hp4_3_branches284 hp4_3_evidence284 hp4_3_check284 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches284,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node283 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected283 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected283 ((4 : Int),(1 : Int)) hp4_3_branches283 hp4_3_evidence283 hp4_3_check283 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches283,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node282 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected282 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected282 ((3 : Int),(1 : Int)) hp4_3_branches282 hp4_3_evidence282 hp4_3_check282 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches282,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node283 T childKnown
  · exact hp4_3_node284 T childKnown
theorem hp4_3_node281 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected281 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected281 ((5 : Int),(2 : Int)) hp4_3_branches281 hp4_3_evidence281 hp4_3_check281 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches281,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node280 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected280 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected280 ((5 : Int),(2 : Int)) hp4_3_branches280 hp4_3_evidence280 hp4_3_check280 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches280,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node279 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected279 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected279 ((6 : Int),(2 : Int)) hp4_3_branches279 hp4_3_evidence279 hp4_3_check279 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches279,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node278 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected278 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected278 ((6 : Int),(1 : Int)) hp4_3_branches278 hp4_3_evidence278 hp4_3_check278 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches278,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node279 T childKnown
theorem hp4_3_node277 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected277 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected277 ((5 : Int),(1 : Int)) hp4_3_branches277 hp4_3_evidence277 hp4_3_check277 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches277,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node278 T childKnown
  · exact hp4_3_node280 T childKnown
  · exact hp4_3_node281 T childKnown
theorem hp4_3_node276 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected276 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected276 ((3 : Int),(1 : Int)) hp4_3_branches276 hp4_3_evidence276 hp4_3_check276 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches276,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node277 T childKnown
theorem hp4_3_node275 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected275 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected275 ((4 : Int),(1 : Int)) hp4_3_branches275 hp4_3_evidence275 hp4_3_check275 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches275,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node274 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected274 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected274 ((4 : Int),(1 : Int)) hp4_3_branches274 hp4_3_evidence274 hp4_3_check274 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches274,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node273 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected273 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected273 ((4 : Int),(0 : Int)) hp4_3_branches273 hp4_3_evidence273 hp4_3_check273 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches273,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node274 T childKnown
  · exact hp4_3_node275 T childKnown
theorem hp4_3_node272 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected272 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected272 ((10 : Int),(1 : Int)) hp4_3_branches272 hp4_3_evidence272 hp4_3_check272 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches272,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node271 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected271 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected271 ((10 : Int),(1 : Int)) hp4_3_branches271 hp4_3_evidence271 hp4_3_check271 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches271,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node270 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected270 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected270 ((10 : Int),(1 : Int)) hp4_3_branches270 hp4_3_evidence270 hp4_3_check270 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches270,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node269 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected269 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected269 ((9 : Int),(1 : Int)) hp4_3_branches269 hp4_3_evidence269 hp4_3_check269 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches269,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node270 T childKnown
  · exact hp4_3_node271 T childKnown
  · exact hp4_3_node272 T childKnown
theorem hp4_3_node268 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected268 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected268 ((10 : Int),(1 : Int)) hp4_3_branches268 hp4_3_evidence268 hp4_3_check268 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches268,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node267 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected267 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected267 ((10 : Int),(1 : Int)) hp4_3_branches267 hp4_3_evidence267 hp4_3_check267 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches267,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node266 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected266 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected266 ((9 : Int),(1 : Int)) hp4_3_branches266 hp4_3_evidence266 hp4_3_check266 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches266,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node267 T childKnown
  · exact hp4_3_node268 T childKnown
theorem hp4_3_node265 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected265 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected265 ((9 : Int),(1 : Int)) hp4_3_branches265 hp4_3_evidence265 hp4_3_check265 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches265,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node264 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected264 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected264 ((9 : Int),(1 : Int)) hp4_3_branches264 hp4_3_evidence264 hp4_3_check264 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches264,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node263 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected263 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected263 ((9 : Int),(1 : Int)) hp4_3_branches263 hp4_3_evidence263 hp4_3_check263 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches263,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node262 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected262 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected262 ((10 : Int),(0 : Int)) hp4_3_branches262 hp4_3_evidence262 hp4_3_check262 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches262,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node263 T childKnown
  · exact hp4_3_node264 T childKnown
  · exact hp4_3_node265 T childKnown
  · exact hp4_3_node266 T childKnown
  · exact hp4_3_node269 T childKnown
theorem hp4_3_node261 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected261 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected261 ((5 : Int),(2 : Int)) hp4_3_branches261 hp4_3_evidence261 hp4_3_check261 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches261,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node260 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected260 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected260 ((5 : Int),(2 : Int)) hp4_3_branches260 hp4_3_evidence260 hp4_3_check260 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches260,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node259 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected259 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected259 ((6 : Int),(2 : Int)) hp4_3_branches259 hp4_3_evidence259 hp4_3_check259 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches259,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node258 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected258 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected258 ((5 : Int),(2 : Int)) hp4_3_branches258 hp4_3_evidence258 hp4_3_check258 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches258,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node259 T childKnown
theorem hp4_3_node257 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected257 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected257 ((4 : Int),(2 : Int)) hp4_3_branches257 hp4_3_evidence257 hp4_3_check257 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches257,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node258 T childKnown
  · exact hp4_3_node260 T childKnown
  · exact hp4_3_node261 T childKnown
  · exact hp4_3_node262 T childKnown
theorem hp4_3_node256 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected256 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected256 ((4 : Int),(0 : Int)) hp4_3_branches256 hp4_3_evidence256 hp4_3_check256 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches256,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node257 T childKnown
theorem hp4_3_node255 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected255 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected255 ((3 : Int),(0 : Int)) hp4_3_branches255 hp4_3_evidence255 hp4_3_check255 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches255,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node256 T childKnown
  · exact hp4_3_node273 T childKnown
  · exact hp4_3_node276 T childKnown
  · exact hp4_3_node282 T childKnown
theorem hp4_3_node254 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected254 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected254 ((3 : Int),(1 : Int)) hp4_3_branches254 hp4_3_evidence254 hp4_3_check254 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches254,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node253 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected253 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected253 ((3 : Int),(1 : Int)) hp4_3_branches253 hp4_3_evidence253 hp4_3_check253 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches253,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node252 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected252 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected252 ((4 : Int),(1 : Int)) hp4_3_branches252 hp4_3_evidence252 hp4_3_check252 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches252,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node251 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected251 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected251 ((4 : Int),(1 : Int)) hp4_3_branches251 hp4_3_evidence251 hp4_3_check251 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches251,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node250 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected250 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected250 ((4 : Int),(0 : Int)) hp4_3_branches250 hp4_3_evidence250 hp4_3_check250 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches250,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node251 T childKnown
  · exact hp4_3_node252 T childKnown
theorem hp4_3_node249 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected249 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected249 ((10 : Int),(1 : Int)) hp4_3_branches249 hp4_3_evidence249 hp4_3_check249 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches249,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node248 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected248 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected248 ((10 : Int),(1 : Int)) hp4_3_branches248 hp4_3_evidence248 hp4_3_check248 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches248,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node247 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected247 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected247 ((10 : Int),(1 : Int)) hp4_3_branches247 hp4_3_evidence247 hp4_3_check247 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches247,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node246 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected246 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected246 ((9 : Int),(1 : Int)) hp4_3_branches246 hp4_3_evidence246 hp4_3_check246 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches246,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node247 T childKnown
  · exact hp4_3_node248 T childKnown
  · exact hp4_3_node249 T childKnown
theorem hp4_3_node245 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected245 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected245 ((10 : Int),(1 : Int)) hp4_3_branches245 hp4_3_evidence245 hp4_3_check245 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches245,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node244 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected244 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected244 ((10 : Int),(1 : Int)) hp4_3_branches244 hp4_3_evidence244 hp4_3_check244 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches244,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node243 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected243 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected243 ((9 : Int),(1 : Int)) hp4_3_branches243 hp4_3_evidence243 hp4_3_check243 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches243,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node244 T childKnown
  · exact hp4_3_node245 T childKnown
theorem hp4_3_node242 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected242 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected242 ((9 : Int),(1 : Int)) hp4_3_branches242 hp4_3_evidence242 hp4_3_check242 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches242,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node241 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected241 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected241 ((9 : Int),(1 : Int)) hp4_3_branches241 hp4_3_evidence241 hp4_3_check241 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches241,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node240 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected240 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected240 ((9 : Int),(1 : Int)) hp4_3_branches240 hp4_3_evidence240 hp4_3_check240 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches240,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node239 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected239 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected239 ((10 : Int),(0 : Int)) hp4_3_branches239 hp4_3_evidence239 hp4_3_check239 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches239,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node240 T childKnown
  · exact hp4_3_node241 T childKnown
  · exact hp4_3_node242 T childKnown
  · exact hp4_3_node243 T childKnown
  · exact hp4_3_node246 T childKnown
theorem hp4_3_node238 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected238 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected238 ((4 : Int),(2 : Int)) hp4_3_branches238 hp4_3_evidence238 hp4_3_check238 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches238,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node239 T childKnown
theorem hp4_3_node237 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected237 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected237 ((4 : Int),(0 : Int)) hp4_3_branches237 hp4_3_evidence237 hp4_3_check237 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches237,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node238 T childKnown
theorem hp4_3_node236 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected236 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected236 ((3 : Int),(0 : Int)) hp4_3_branches236 hp4_3_evidence236 hp4_3_check236 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches236,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node237 T childKnown
  · exact hp4_3_node250 T childKnown
  · exact hp4_3_node253 T childKnown
  · exact hp4_3_node254 T childKnown
theorem hp4_3_node235 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected235 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected235 ((1 : Int),(2 : Int)) hp4_3_branches235 hp4_3_evidence235 hp4_3_check235 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches235,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node236 T childKnown
theorem hp4_3_node234 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected234 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected234 ((1 : Int),(2 : Int)) hp4_3_branches234 hp4_3_evidence234 hp4_3_check234 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches234,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node233 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected233 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected233 ((0 : Int),(2 : Int)) hp4_3_branches233 hp4_3_evidence233 hp4_3_check233 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches233,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node234 T childKnown
  · exact hp4_3_node235 T childKnown
  · exact hp4_3_node255 T childKnown
  · exact hp4_3_node285 T childKnown
theorem hp4_3_node232 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected232 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected232 ((0 : Int),(1 : Int)) hp4_3_branches232 hp4_3_evidence232 hp4_3_check232 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches232,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node231 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected231 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected231 ((2 : Int),(0 : Int)) hp4_3_branches231 hp4_3_evidence231 hp4_3_check231 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches231,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node232 T childKnown
  · exact hp4_3_node233 T childKnown
  · exact hp4_3_node286 T childKnown
  · exact hp4_3_node287 T childKnown
  · exact hp4_3_node288 T childKnown
  · exact hp4_3_node292 T childKnown
  · exact hp4_3_node295 T childKnown
  · exact hp4_3_node301 T childKnown
theorem hp4_3_node230 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected230 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected230 ((3 : Int),(1 : Int)) hp4_3_branches230 hp4_3_evidence230 hp4_3_check230 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches230,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node229 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected229 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected229 ((1 : Int),(1 : Int)) hp4_3_branches229 hp4_3_evidence229 hp4_3_check229 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches229,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node228 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected228 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected228 ((1 : Int),(1 : Int)) hp4_3_branches228 hp4_3_evidence228 hp4_3_check228 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches228,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node227 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected227 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected227 ((0 : Int),(1 : Int)) hp4_3_branches227 hp4_3_evidence227 hp4_3_check227 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches227,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node226 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected226 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected226 ((2 : Int),(1 : Int)) hp4_3_branches226 hp4_3_evidence226 hp4_3_check226 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches226,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node227 T childKnown
  · exact hp4_3_node228 T childKnown
  · exact hp4_3_node229 T childKnown
  · exact hp4_3_node230 T childKnown
theorem hp4_3_node225 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected225 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected225 ((1 : Int),(1 : Int)) hp4_3_branches225 hp4_3_evidence225 hp4_3_check225 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches225,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node224 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected224 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected224 ((1 : Int),(1 : Int)) hp4_3_branches224 hp4_3_evidence224 hp4_3_check224 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches224,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node223 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected223 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected223 ((3 : Int),(2 : Int)) hp4_3_branches223 hp4_3_evidence223 hp4_3_check223 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches223,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node222 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected222 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected222 ((3 : Int),(2 : Int)) hp4_3_branches222 hp4_3_evidence222 hp4_3_check222 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches222,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node221 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected221 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected221 ((4 : Int),(2 : Int)) hp4_3_branches221 hp4_3_evidence221 hp4_3_check221 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches221,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node220 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected220 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected220 ((4 : Int),(1 : Int)) hp4_3_branches220 hp4_3_evidence220 hp4_3_check220 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches220,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node221 T childKnown
theorem hp4_3_node219 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected219 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected219 ((3 : Int),(1 : Int)) hp4_3_branches219 hp4_3_evidence219 hp4_3_check219 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches219,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node220 T childKnown
  · exact hp4_3_node222 T childKnown
  · exact hp4_3_node223 T childKnown
theorem hp4_3_node218 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected218 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected218 ((1 : Int),(1 : Int)) hp4_3_branches218 hp4_3_evidence218 hp4_3_check218 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches218,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node219 T childKnown
theorem hp4_3_node217 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected217 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected217 ((1 : Int),(1 : Int)) hp4_3_branches217 hp4_3_evidence217 hp4_3_check217 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches217,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node216 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected216 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected216 ((0 : Int),(1 : Int)) hp4_3_branches216 hp4_3_evidence216 hp4_3_check216 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches216,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node217 T childKnown
  · exact hp4_3_node218 T childKnown
  · exact hp4_3_node224 T childKnown
  · exact hp4_3_node225 T childKnown
theorem hp4_3_node215 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected215 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected215 ((2 : Int),(1 : Int)) hp4_3_branches215 hp4_3_evidence215 hp4_3_check215 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches215,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node214 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected214 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected214 ((2 : Int),(1 : Int)) hp4_3_branches214 hp4_3_evidence214 hp4_3_check214 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches214,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node213 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected213 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected213 ((2 : Int),(0 : Int)) hp4_3_branches213 hp4_3_evidence213 hp4_3_check213 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches213,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node214 T childKnown
  · exact hp4_3_node215 T childKnown
theorem hp4_3_node212 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected212 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected212 ((0 : Int),(1 : Int)) hp4_3_branches212 hp4_3_evidence212 hp4_3_check212 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches212,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node213 T childKnown
theorem hp4_3_node211 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected211 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected211 ((8 : Int),(1 : Int)) hp4_3_branches211 hp4_3_evidence211 hp4_3_check211 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches211,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node210 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected210 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected210 ((8 : Int),(1 : Int)) hp4_3_branches210 hp4_3_evidence210 hp4_3_check210 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches210,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node209 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected209 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected209 ((8 : Int),(1 : Int)) hp4_3_branches209 hp4_3_evidence209 hp4_3_check209 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches209,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node208 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected208 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected208 ((7 : Int),(1 : Int)) hp4_3_branches208 hp4_3_evidence208 hp4_3_check208 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches208,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node209 T childKnown
  · exact hp4_3_node210 T childKnown
  · exact hp4_3_node211 T childKnown
theorem hp4_3_node207 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected207 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected207 ((8 : Int),(1 : Int)) hp4_3_branches207 hp4_3_evidence207 hp4_3_check207 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches207,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node206 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected206 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected206 ((8 : Int),(1 : Int)) hp4_3_branches206 hp4_3_evidence206 hp4_3_check206 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches206,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node205 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected205 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected205 ((7 : Int),(1 : Int)) hp4_3_branches205 hp4_3_evidence205 hp4_3_check205 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches205,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node206 T childKnown
  · exact hp4_3_node207 T childKnown
theorem hp4_3_node204 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected204 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected204 ((7 : Int),(1 : Int)) hp4_3_branches204 hp4_3_evidence204 hp4_3_check204 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches204,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node203 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected203 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected203 ((7 : Int),(1 : Int)) hp4_3_branches203 hp4_3_evidence203 hp4_3_check203 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches203,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node202 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected202 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected202 ((7 : Int),(1 : Int)) hp4_3_branches202 hp4_3_evidence202 hp4_3_check202 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches202,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node201 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected201 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected201 ((8 : Int),(0 : Int)) hp4_3_branches201 hp4_3_evidence201 hp4_3_check201 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches201,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node202 T childKnown
  · exact hp4_3_node203 T childKnown
  · exact hp4_3_node204 T childKnown
  · exact hp4_3_node205 T childKnown
  · exact hp4_3_node208 T childKnown
theorem hp4_3_node200 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected200 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected200 ((3 : Int),(2 : Int)) hp4_3_branches200 hp4_3_evidence200 hp4_3_check200 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches200,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node199 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected199 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected199 ((3 : Int),(2 : Int)) hp4_3_branches199 hp4_3_evidence199 hp4_3_check199 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches199,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node198 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected198 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected198 ((2 : Int),(2 : Int)) hp4_3_branches198 hp4_3_evidence198 hp4_3_check198 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches198,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node199 T childKnown
  · exact hp4_3_node200 T childKnown
  · exact hp4_3_node201 T childKnown
theorem hp4_3_node197 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected197 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected197 ((2 : Int),(0 : Int)) hp4_3_branches197 hp4_3_evidence197 hp4_3_check197 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches197,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node198 T childKnown
theorem hp4_3_node196 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected196 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected196 ((0 : Int),(1 : Int)) hp4_3_branches196 hp4_3_evidence196 hp4_3_check196 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches196,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node197 T childKnown
theorem hp4_3_node195 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected195 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected195 ((0 : Int),(1 : Int)) hp4_3_branches195 hp4_3_evidence195 hp4_3_check195 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches195,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node194 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected194 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected194 ((0 : Int),(1 : Int)) hp4_3_branches194 hp4_3_evidence194 hp4_3_check194 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches194,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node193 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected193 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected193 ((1 : Int),(0 : Int)) hp4_3_branches193 hp4_3_evidence193 hp4_3_check193 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches193,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node194 T childKnown
  · exact hp4_3_node195 T childKnown
  · exact hp4_3_node196 T childKnown
  · exact hp4_3_node212 T childKnown
  · exact hp4_3_node216 T childKnown
  · exact hp4_3_node226 T childKnown
theorem hp4_3_node192 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected192 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected192 ((9 : Int),(1 : Int)) hp4_3_branches192 hp4_3_evidence192 hp4_3_check192 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches192,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node191 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected191 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected191 ((7 : Int),(1 : Int)) hp4_3_branches191 hp4_3_evidence191 hp4_3_check191 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches191,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node190 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected190 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected190 ((7 : Int),(1 : Int)) hp4_3_branches190 hp4_3_evidence190 hp4_3_check190 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches190,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node189 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected189 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected189 ((6 : Int),(1 : Int)) hp4_3_branches189 hp4_3_evidence189 hp4_3_check189 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches189,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node188 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected188 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected188 ((8 : Int),(1 : Int)) hp4_3_branches188 hp4_3_evidence188 hp4_3_check188 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches188,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node189 T childKnown
  · exact hp4_3_node190 T childKnown
  · exact hp4_3_node191 T childKnown
  · exact hp4_3_node192 T childKnown
theorem hp4_3_node187 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected187 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected187 ((7 : Int),(1 : Int)) hp4_3_branches187 hp4_3_evidence187 hp4_3_check187 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches187,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node186 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected186 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected186 ((7 : Int),(1 : Int)) hp4_3_branches186 hp4_3_evidence186 hp4_3_check186 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches186,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node185 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected185 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected185 ((0 : Int),(2 : Int)) hp4_3_branches185 hp4_3_evidence185 hp4_3_check185 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches185,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node184 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected184 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected184 ((3 : Int),(1 : Int)) hp4_3_branches184 hp4_3_evidence184 hp4_3_check184 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches184,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node185 T childKnown
theorem hp4_3_node183 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected183 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected183 ((4 : Int),(2 : Int)) hp4_3_branches183 hp4_3_evidence183 hp4_3_check183 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches183,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node182 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected182 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected182 ((3 : Int),(2 : Int)) hp4_3_branches182 hp4_3_evidence182 hp4_3_check182 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches182,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node181 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected181 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected181 ((4 : Int),(1 : Int)) hp4_3_branches181 hp4_3_evidence181 hp4_3_check181 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches181,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node182 T childKnown
  · exact hp4_3_node183 T childKnown
  · exact hp4_3_node184 T childKnown
theorem hp4_3_node180 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected180 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected180 ((7 : Int),(1 : Int)) hp4_3_branches180 hp4_3_evidence180 hp4_3_check180 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches180,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node181 T childKnown
theorem hp4_3_node179 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected179 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected179 ((7 : Int),(1 : Int)) hp4_3_branches179 hp4_3_evidence179 hp4_3_check179 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches179,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node178 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected178 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected178 ((6 : Int),(1 : Int)) hp4_3_branches178 hp4_3_evidence178 hp4_3_check178 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches178,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node179 T childKnown
  · exact hp4_3_node180 T childKnown
  · exact hp4_3_node186 T childKnown
  · exact hp4_3_node187 T childKnown
theorem hp4_3_node177 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected177 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected177 ((8 : Int),(1 : Int)) hp4_3_branches177 hp4_3_evidence177 hp4_3_check177 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches177,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node176 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected176 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected176 ((8 : Int),(1 : Int)) hp4_3_branches176 hp4_3_evidence176 hp4_3_check176 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches176,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node175 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected175 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected175 ((8 : Int),(0 : Int)) hp4_3_branches175 hp4_3_evidence175 hp4_3_check175 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches175,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node176 T childKnown
  · exact hp4_3_node177 T childKnown
theorem hp4_3_node174 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected174 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected174 ((6 : Int),(1 : Int)) hp4_3_branches174 hp4_3_evidence174 hp4_3_check174 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches174,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node175 T childKnown
theorem hp4_3_node173 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected173 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected173 ((0 : Int),(2 : Int)) hp4_3_branches173 hp4_3_evidence173 hp4_3_check173 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches173,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node172 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected172 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected172 ((3 : Int),(1 : Int)) hp4_3_branches172 hp4_3_evidence172 hp4_3_check172 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches172,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node173 T childKnown
theorem hp4_3_node171 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected171 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected171 ((4 : Int),(2 : Int)) hp4_3_branches171 hp4_3_evidence171 hp4_3_check171 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches171,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node170 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected170 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected170 ((3 : Int),(2 : Int)) hp4_3_branches170 hp4_3_evidence170 hp4_3_check170 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches170,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node169 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected169 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected169 ((4 : Int),(1 : Int)) hp4_3_branches169 hp4_3_evidence169 hp4_3_check169 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches169,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node170 T childKnown
  · exact hp4_3_node171 T childKnown
  · exact hp4_3_node172 T childKnown
theorem hp4_3_node168 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected168 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected168 ((8 : Int),(0 : Int)) hp4_3_branches168 hp4_3_evidence168 hp4_3_check168 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches168,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node169 T childKnown
theorem hp4_3_node167 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected167 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected167 ((6 : Int),(1 : Int)) hp4_3_branches167 hp4_3_evidence167 hp4_3_check167 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches167,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node168 T childKnown
theorem hp4_3_node166 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected166 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected166 ((6 : Int),(1 : Int)) hp4_3_branches166 hp4_3_evidence166 hp4_3_check166 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches166,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node165 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected165 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected165 ((6 : Int),(1 : Int)) hp4_3_branches165 hp4_3_evidence165 hp4_3_check165 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches165,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node164 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected164 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected164 ((7 : Int),(0 : Int)) hp4_3_branches164 hp4_3_evidence164 hp4_3_check164 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches164,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node165 T childKnown
  · exact hp4_3_node166 T childKnown
  · exact hp4_3_node167 T childKnown
  · exact hp4_3_node174 T childKnown
  · exact hp4_3_node178 T childKnown
  · exact hp4_3_node188 T childKnown
theorem hp4_3_node163 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected163 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected163 ((1 : Int),(1 : Int)) hp4_3_branches163 hp4_3_evidence163 hp4_3_check163 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches163,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node162 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected162 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected162 ((1 : Int),(1 : Int)) hp4_3_branches162 hp4_3_evidence162 hp4_3_check162 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches162,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node161 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected161 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected161 ((3 : Int),(2 : Int)) hp4_3_branches161 hp4_3_evidence161 hp4_3_check161 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches161,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node160 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected160 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected160 ((3 : Int),(2 : Int)) hp4_3_branches160 hp4_3_evidence160 hp4_3_check160 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches160,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node159 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected159 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected159 ((4 : Int),(2 : Int)) hp4_3_branches159 hp4_3_evidence159 hp4_3_check159 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches159,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node158 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected158 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected158 ((4 : Int),(1 : Int)) hp4_3_branches158 hp4_3_evidence158 hp4_3_check158 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches158,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node159 T childKnown
theorem hp4_3_node157 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected157 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected157 ((3 : Int),(1 : Int)) hp4_3_branches157 hp4_3_evidence157 hp4_3_check157 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches157,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node158 T childKnown
  · exact hp4_3_node160 T childKnown
  · exact hp4_3_node161 T childKnown
theorem hp4_3_node156 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected156 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected156 ((1 : Int),(1 : Int)) hp4_3_branches156 hp4_3_evidence156 hp4_3_check156 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches156,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node157 T childKnown
theorem hp4_3_node155 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected155 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected155 ((3 : Int),(2 : Int)) hp4_3_branches155 hp4_3_evidence155 hp4_3_check155 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches155,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node154 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected154 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected154 ((3 : Int),(2 : Int)) hp4_3_branches154 hp4_3_evidence154 hp4_3_check154 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches154,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node153 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected153 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected153 ((4 : Int),(2 : Int)) hp4_3_branches153 hp4_3_evidence153 hp4_3_check153 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches153,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node152 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected152 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected152 ((4 : Int),(1 : Int)) hp4_3_branches152 hp4_3_evidence152 hp4_3_check152 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches152,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node153 T childKnown
theorem hp4_3_node151 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected151 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected151 ((3 : Int),(1 : Int)) hp4_3_branches151 hp4_3_evidence151 hp4_3_check151 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches151,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node152 T childKnown
  · exact hp4_3_node154 T childKnown
  · exact hp4_3_node155 T childKnown
theorem hp4_3_node150 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected150 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected150 ((1 : Int),(1 : Int)) hp4_3_branches150 hp4_3_evidence150 hp4_3_check150 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches150,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node151 T childKnown
theorem hp4_3_node149 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected149 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected149 ((1 : Int),(1 : Int)) hp4_3_branches149 hp4_3_evidence149 hp4_3_check149 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches149,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node148 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected148 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected148 ((0 : Int),(1 : Int)) hp4_3_branches148 hp4_3_evidence148 hp4_3_check148 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches148,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node149 T childKnown
  · exact hp4_3_node150 T childKnown
  · exact hp4_3_node156 T childKnown
  · exact hp4_3_node162 T childKnown
  · exact hp4_3_node163 T childKnown
theorem hp4_3_node147 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected147 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected147 ((2 : Int),(1 : Int)) hp4_3_branches147 hp4_3_evidence147 hp4_3_check147 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches147,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node146 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected146 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected146 ((2 : Int),(1 : Int)) hp4_3_branches146 hp4_3_evidence146 hp4_3_check146 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches146,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node145 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected145 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected145 ((2 : Int),(0 : Int)) hp4_3_branches145 hp4_3_evidence145 hp4_3_check145 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches145,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node146 T childKnown
  · exact hp4_3_node147 T childKnown
theorem hp4_3_node144 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected144 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected144 ((2 : Int),(1 : Int)) hp4_3_branches144 hp4_3_evidence144 hp4_3_check144 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches144,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node143 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected143 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected143 ((2 : Int),(1 : Int)) hp4_3_branches143 hp4_3_evidence143 hp4_3_check143 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches143,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node142 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected142 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected142 ((2 : Int),(0 : Int)) hp4_3_branches142 hp4_3_evidence142 hp4_3_check142 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches142,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node143 T childKnown
  · exact hp4_3_node144 T childKnown
theorem hp4_3_node141 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected141 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected141 ((0 : Int),(1 : Int)) hp4_3_branches141 hp4_3_evidence141 hp4_3_check141 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches141,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node142 T childKnown
  · exact hp4_3_node145 T childKnown
theorem hp4_3_node140 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected140 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected140 ((8 : Int),(1 : Int)) hp4_3_branches140 hp4_3_evidence140 hp4_3_check140 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches140,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node139 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected139 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected139 ((8 : Int),(1 : Int)) hp4_3_branches139 hp4_3_evidence139 hp4_3_check139 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches139,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node138 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected138 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected138 ((8 : Int),(1 : Int)) hp4_3_branches138 hp4_3_evidence138 hp4_3_check138 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches138,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node137 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected137 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected137 ((7 : Int),(1 : Int)) hp4_3_branches137 hp4_3_evidence137 hp4_3_check137 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches137,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node138 T childKnown
  · exact hp4_3_node139 T childKnown
  · exact hp4_3_node140 T childKnown
theorem hp4_3_node136 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected136 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected136 ((8 : Int),(1 : Int)) hp4_3_branches136 hp4_3_evidence136 hp4_3_check136 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches136,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node135 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected135 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected135 ((8 : Int),(1 : Int)) hp4_3_branches135 hp4_3_evidence135 hp4_3_check135 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches135,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node134 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected134 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected134 ((7 : Int),(1 : Int)) hp4_3_branches134 hp4_3_evidence134 hp4_3_check134 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches134,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node135 T childKnown
  · exact hp4_3_node136 T childKnown
theorem hp4_3_node133 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected133 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected133 ((7 : Int),(1 : Int)) hp4_3_branches133 hp4_3_evidence133 hp4_3_check133 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches133,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node132 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected132 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected132 ((7 : Int),(1 : Int)) hp4_3_branches132 hp4_3_evidence132 hp4_3_check132 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches132,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node131 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected131 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected131 ((7 : Int),(1 : Int)) hp4_3_branches131 hp4_3_evidence131 hp4_3_check131 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches131,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node130 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected130 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected130 ((8 : Int),(0 : Int)) hp4_3_branches130 hp4_3_evidence130 hp4_3_check130 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches130,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node131 T childKnown
  · exact hp4_3_node132 T childKnown
  · exact hp4_3_node133 T childKnown
  · exact hp4_3_node134 T childKnown
  · exact hp4_3_node137 T childKnown
theorem hp4_3_node129 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected129 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected129 ((3 : Int),(2 : Int)) hp4_3_branches129 hp4_3_evidence129 hp4_3_check129 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches129,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node128 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected128 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected128 ((3 : Int),(2 : Int)) hp4_3_branches128 hp4_3_evidence128 hp4_3_check128 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches128,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node127 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected127 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected127 ((2 : Int),(2 : Int)) hp4_3_branches127 hp4_3_evidence127 hp4_3_check127 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches127,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node128 T childKnown
  · exact hp4_3_node129 T childKnown
  · exact hp4_3_node130 T childKnown
theorem hp4_3_node126 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected126 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected126 ((8 : Int),(1 : Int)) hp4_3_branches126 hp4_3_evidence126 hp4_3_check126 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches126,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node125 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected125 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected125 ((8 : Int),(1 : Int)) hp4_3_branches125 hp4_3_evidence125 hp4_3_check125 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches125,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node124 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected124 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected124 ((8 : Int),(1 : Int)) hp4_3_branches124 hp4_3_evidence124 hp4_3_check124 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches124,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node123 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected123 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected123 ((7 : Int),(1 : Int)) hp4_3_branches123 hp4_3_evidence123 hp4_3_check123 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches123,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node124 T childKnown
  · exact hp4_3_node125 T childKnown
  · exact hp4_3_node126 T childKnown
theorem hp4_3_node122 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected122 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected122 ((8 : Int),(1 : Int)) hp4_3_branches122 hp4_3_evidence122 hp4_3_check122 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches122,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node121 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected121 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected121 ((8 : Int),(1 : Int)) hp4_3_branches121 hp4_3_evidence121 hp4_3_check121 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches121,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node120 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected120 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected120 ((7 : Int),(1 : Int)) hp4_3_branches120 hp4_3_evidence120 hp4_3_check120 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches120,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node121 T childKnown
  · exact hp4_3_node122 T childKnown
theorem hp4_3_node119 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected119 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected119 ((7 : Int),(1 : Int)) hp4_3_branches119 hp4_3_evidence119 hp4_3_check119 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches119,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node118 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected118 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected118 ((7 : Int),(1 : Int)) hp4_3_branches118 hp4_3_evidence118 hp4_3_check118 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches118,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node117 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected117 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected117 ((7 : Int),(1 : Int)) hp4_3_branches117 hp4_3_evidence117 hp4_3_check117 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches117,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node116 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected116 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected116 ((8 : Int),(0 : Int)) hp4_3_branches116 hp4_3_evidence116 hp4_3_check116 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches116,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node117 T childKnown
  · exact hp4_3_node118 T childKnown
  · exact hp4_3_node119 T childKnown
  · exact hp4_3_node120 T childKnown
  · exact hp4_3_node123 T childKnown
theorem hp4_3_node115 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected115 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected115 ((3 : Int),(2 : Int)) hp4_3_branches115 hp4_3_evidence115 hp4_3_check115 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches115,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node114 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected114 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected114 ((3 : Int),(2 : Int)) hp4_3_branches114 hp4_3_evidence114 hp4_3_check114 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches114,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node113 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected113 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected113 ((2 : Int),(2 : Int)) hp4_3_branches113 hp4_3_evidence113 hp4_3_check113 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches113,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node114 T childKnown
  · exact hp4_3_node115 T childKnown
  · exact hp4_3_node116 T childKnown
theorem hp4_3_node112 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected112 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected112 ((0 : Int),(1 : Int)) hp4_3_branches112 hp4_3_evidence112 hp4_3_check112 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches112,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node113 T childKnown
  · exact hp4_3_node127 T childKnown
theorem hp4_3_node111 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected111 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected111 ((2 : Int),(0 : Int)) hp4_3_branches111 hp4_3_evidence111 hp4_3_check111 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches111,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node112 T childKnown
theorem hp4_3_node110 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected110 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected110 ((0 : Int),(1 : Int)) hp4_3_branches110 hp4_3_evidence110 hp4_3_check110 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches110,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node109 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected109 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected109 ((0 : Int),(1 : Int)) hp4_3_branches109 hp4_3_evidence109 hp4_3_check109 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches109,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node108 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected108 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected108 ((2 : Int),(1 : Int)) hp4_3_branches108 hp4_3_evidence108 hp4_3_check108 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches108,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node107 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected107 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected107 ((2 : Int),(1 : Int)) hp4_3_branches107 hp4_3_evidence107 hp4_3_check107 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches107,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node106 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected106 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected106 ((3 : Int),(1 : Int)) hp4_3_branches106 hp4_3_evidence106 hp4_3_check106 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches106,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node105 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected105 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected105 ((3 : Int),(1 : Int)) hp4_3_branches105 hp4_3_evidence105 hp4_3_check105 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches105,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node104 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected104 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected104 ((3 : Int),(0 : Int)) hp4_3_branches104 hp4_3_evidence104 hp4_3_check104 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches104,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node105 T childKnown
  · exact hp4_3_node106 T childKnown
theorem hp4_3_node103 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected103 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected103 ((9 : Int),(1 : Int)) hp4_3_branches103 hp4_3_evidence103 hp4_3_check103 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches103,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node102 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected102 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected102 ((9 : Int),(1 : Int)) hp4_3_branches102 hp4_3_evidence102 hp4_3_check102 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches102,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node101 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected101 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected101 ((9 : Int),(1 : Int)) hp4_3_branches101 hp4_3_evidence101 hp4_3_check101 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches101,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node100 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected100 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected100 ((8 : Int),(1 : Int)) hp4_3_branches100 hp4_3_evidence100 hp4_3_check100 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches100,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node101 T childKnown
  · exact hp4_3_node102 T childKnown
  · exact hp4_3_node103 T childKnown
theorem hp4_3_node99 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected99 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected99 ((9 : Int),(1 : Int)) hp4_3_branches99 hp4_3_evidence99 hp4_3_check99 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches99,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node98 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected98 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected98 ((9 : Int),(1 : Int)) hp4_3_branches98 hp4_3_evidence98 hp4_3_check98 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches98,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node97 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected97 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected97 ((8 : Int),(1 : Int)) hp4_3_branches97 hp4_3_evidence97 hp4_3_check97 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches97,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node98 T childKnown
  · exact hp4_3_node99 T childKnown
theorem hp4_3_node96 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected96 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected96 ((8 : Int),(1 : Int)) hp4_3_branches96 hp4_3_evidence96 hp4_3_check96 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches96,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node95 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected95 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected95 ((8 : Int),(1 : Int)) hp4_3_branches95 hp4_3_evidence95 hp4_3_check95 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches95,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node94 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected94 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected94 ((8 : Int),(1 : Int)) hp4_3_branches94 hp4_3_evidence94 hp4_3_check94 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches94,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node93 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected93 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected93 ((9 : Int),(0 : Int)) hp4_3_branches93 hp4_3_evidence93 hp4_3_check93 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches93,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node94 T childKnown
  · exact hp4_3_node95 T childKnown
  · exact hp4_3_node96 T childKnown
  · exact hp4_3_node97 T childKnown
  · exact hp4_3_node100 T childKnown
theorem hp4_3_node92 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected92 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected92 ((3 : Int),(2 : Int)) hp4_3_branches92 hp4_3_evidence92 hp4_3_check92 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches92,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node93 T childKnown
theorem hp4_3_node91 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected91 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected91 ((3 : Int),(0 : Int)) hp4_3_branches91 hp4_3_evidence91 hp4_3_check91 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches91,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node92 T childKnown
theorem hp4_3_node90 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected90 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected90 ((2 : Int),(0 : Int)) hp4_3_branches90 hp4_3_evidence90 hp4_3_check90 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches90,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node91 T childKnown
  · exact hp4_3_node104 T childKnown
  · exact hp4_3_node107 T childKnown
  · exact hp4_3_node108 T childKnown
theorem hp4_3_node89 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected89 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected89 ((3 : Int),(1 : Int)) hp4_3_branches89 hp4_3_evidence89 hp4_3_check89 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches89,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node88 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected88 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected88 ((3 : Int),(1 : Int)) hp4_3_branches88 hp4_3_evidence88 hp4_3_check88 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches88,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node87 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected87 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected87 ((2 : Int),(1 : Int)) hp4_3_branches87 hp4_3_evidence87 hp4_3_check87 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches87,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node88 T childKnown
  · exact hp4_3_node89 T childKnown
theorem hp4_3_node86 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected86 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected86 ((4 : Int),(2 : Int)) hp4_3_branches86 hp4_3_evidence86 hp4_3_check86 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches86,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node85 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected85 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected85 ((4 : Int),(2 : Int)) hp4_3_branches85 hp4_3_evidence85 hp4_3_check85 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches85,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node84 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected84 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected84 ((5 : Int),(2 : Int)) hp4_3_branches84 hp4_3_evidence84 hp4_3_check84 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches84,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node83 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected83 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected83 ((5 : Int),(1 : Int)) hp4_3_branches83 hp4_3_evidence83 hp4_3_check83 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches83,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node84 T childKnown
theorem hp4_3_node82 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected82 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected82 ((4 : Int),(1 : Int)) hp4_3_branches82 hp4_3_evidence82 hp4_3_check82 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches82,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node83 T childKnown
  · exact hp4_3_node85 T childKnown
  · exact hp4_3_node86 T childKnown
theorem hp4_3_node81 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected81 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected81 ((2 : Int),(1 : Int)) hp4_3_branches81 hp4_3_evidence81 hp4_3_check81 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches81,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node82 T childKnown
theorem hp4_3_node80 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected80 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected80 ((3 : Int),(1 : Int)) hp4_3_branches80 hp4_3_evidence80 hp4_3_check80 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches80,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node79 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected79 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected79 ((3 : Int),(1 : Int)) hp4_3_branches79 hp4_3_evidence79 hp4_3_check79 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches79,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node78 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected78 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected78 ((3 : Int),(0 : Int)) hp4_3_branches78 hp4_3_evidence78 hp4_3_check78 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches78,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node79 T childKnown
  · exact hp4_3_node80 T childKnown
theorem hp4_3_node77 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected77 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected77 ((9 : Int),(1 : Int)) hp4_3_branches77 hp4_3_evidence77 hp4_3_check77 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches77,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node76 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected76 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected76 ((9 : Int),(1 : Int)) hp4_3_branches76 hp4_3_evidence76 hp4_3_check76 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches76,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node75 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected75 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected75 ((9 : Int),(1 : Int)) hp4_3_branches75 hp4_3_evidence75 hp4_3_check75 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches75,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node74 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected74 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected74 ((8 : Int),(1 : Int)) hp4_3_branches74 hp4_3_evidence74 hp4_3_check74 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches74,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node75 T childKnown
  · exact hp4_3_node76 T childKnown
  · exact hp4_3_node77 T childKnown
theorem hp4_3_node73 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected73 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected73 ((9 : Int),(1 : Int)) hp4_3_branches73 hp4_3_evidence73 hp4_3_check73 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches73,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node72 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected72 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected72 ((9 : Int),(1 : Int)) hp4_3_branches72 hp4_3_evidence72 hp4_3_check72 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches72,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node71 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected71 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected71 ((8 : Int),(1 : Int)) hp4_3_branches71 hp4_3_evidence71 hp4_3_check71 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches71,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node72 T childKnown
  · exact hp4_3_node73 T childKnown
theorem hp4_3_node70 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected70 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected70 ((8 : Int),(1 : Int)) hp4_3_branches70 hp4_3_evidence70 hp4_3_check70 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches70,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node69 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected69 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected69 ((8 : Int),(1 : Int)) hp4_3_branches69 hp4_3_evidence69 hp4_3_check69 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches69,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node68 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected68 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected68 ((8 : Int),(1 : Int)) hp4_3_branches68 hp4_3_evidence68 hp4_3_check68 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches68,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node67 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected67 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected67 ((9 : Int),(0 : Int)) hp4_3_branches67 hp4_3_evidence67 hp4_3_check67 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches67,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node68 T childKnown
  · exact hp4_3_node69 T childKnown
  · exact hp4_3_node70 T childKnown
  · exact hp4_3_node71 T childKnown
  · exact hp4_3_node74 T childKnown
theorem hp4_3_node66 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected66 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected66 ((4 : Int),(2 : Int)) hp4_3_branches66 hp4_3_evidence66 hp4_3_check66 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches66,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node65 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected65 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected65 ((4 : Int),(2 : Int)) hp4_3_branches65 hp4_3_evidence65 hp4_3_check65 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches65,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node64 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected64 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected64 ((3 : Int),(2 : Int)) hp4_3_branches64 hp4_3_evidence64 hp4_3_check64 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches64,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node65 T childKnown
  · exact hp4_3_node66 T childKnown
  · exact hp4_3_node67 T childKnown
theorem hp4_3_node63 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected63 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected63 ((3 : Int),(0 : Int)) hp4_3_branches63 hp4_3_evidence63 hp4_3_check63 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches63,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node64 T childKnown
theorem hp4_3_node62 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected62 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected62 ((2 : Int),(0 : Int)) hp4_3_branches62 hp4_3_evidence62 hp4_3_check62 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches62,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node63 T childKnown
  · exact hp4_3_node78 T childKnown
  · exact hp4_3_node81 T childKnown
  · exact hp4_3_node87 T childKnown
theorem hp4_3_node61 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected61 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected61 ((3 : Int),(1 : Int)) hp4_3_branches61 hp4_3_evidence61 hp4_3_check61 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches61,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node60 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected60 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected60 ((3 : Int),(1 : Int)) hp4_3_branches60 hp4_3_evidence60 hp4_3_check60 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches60,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node59 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected59 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected59 ((2 : Int),(1 : Int)) hp4_3_branches59 hp4_3_evidence59 hp4_3_check59 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches59,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node60 T childKnown
  · exact hp4_3_node61 T childKnown
theorem hp4_3_node58 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected58 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected58 ((4 : Int),(2 : Int)) hp4_3_branches58 hp4_3_evidence58 hp4_3_check58 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches58,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node57 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected57 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected57 ((4 : Int),(2 : Int)) hp4_3_branches57 hp4_3_evidence57 hp4_3_check57 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches57,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node56 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected56 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected56 ((5 : Int),(2 : Int)) hp4_3_branches56 hp4_3_evidence56 hp4_3_check56 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches56,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node55 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected55 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected55 ((5 : Int),(1 : Int)) hp4_3_branches55 hp4_3_evidence55 hp4_3_check55 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches55,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node56 T childKnown
theorem hp4_3_node54 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected54 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected54 ((4 : Int),(1 : Int)) hp4_3_branches54 hp4_3_evidence54 hp4_3_check54 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches54,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node55 T childKnown
  · exact hp4_3_node57 T childKnown
  · exact hp4_3_node58 T childKnown
theorem hp4_3_node53 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected53 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected53 ((2 : Int),(1 : Int)) hp4_3_branches53 hp4_3_evidence53 hp4_3_check53 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches53,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node54 T childKnown
theorem hp4_3_node52 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected52 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected52 ((3 : Int),(1 : Int)) hp4_3_branches52 hp4_3_evidence52 hp4_3_check52 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches52,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node51 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected51 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected51 ((3 : Int),(1 : Int)) hp4_3_branches51 hp4_3_evidence51 hp4_3_check51 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches51,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node50 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected50 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected50 ((3 : Int),(0 : Int)) hp4_3_branches50 hp4_3_evidence50 hp4_3_check50 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches50,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node51 T childKnown
  · exact hp4_3_node52 T childKnown
theorem hp4_3_node49 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected49 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected49 ((9 : Int),(1 : Int)) hp4_3_branches49 hp4_3_evidence49 hp4_3_check49 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches49,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node48 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected48 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected48 ((9 : Int),(1 : Int)) hp4_3_branches48 hp4_3_evidence48 hp4_3_check48 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches48,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node47 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected47 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected47 ((9 : Int),(1 : Int)) hp4_3_branches47 hp4_3_evidence47 hp4_3_check47 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches47,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node46 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected46 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected46 ((8 : Int),(1 : Int)) hp4_3_branches46 hp4_3_evidence46 hp4_3_check46 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches46,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node47 T childKnown
  · exact hp4_3_node48 T childKnown
  · exact hp4_3_node49 T childKnown
theorem hp4_3_node45 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected45 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected45 ((9 : Int),(1 : Int)) hp4_3_branches45 hp4_3_evidence45 hp4_3_check45 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches45,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node44 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected44 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected44 ((9 : Int),(1 : Int)) hp4_3_branches44 hp4_3_evidence44 hp4_3_check44 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches44,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node43 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected43 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected43 ((8 : Int),(1 : Int)) hp4_3_branches43 hp4_3_evidence43 hp4_3_check43 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches43,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node44 T childKnown
  · exact hp4_3_node45 T childKnown
theorem hp4_3_node42 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected42 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected42 ((8 : Int),(1 : Int)) hp4_3_branches42 hp4_3_evidence42 hp4_3_check42 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches42,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node41 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected41 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected41 ((8 : Int),(1 : Int)) hp4_3_branches41 hp4_3_evidence41 hp4_3_check41 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches41,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node40 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected40 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected40 ((8 : Int),(1 : Int)) hp4_3_branches40 hp4_3_evidence40 hp4_3_check40 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches40,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node39 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected39 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected39 ((9 : Int),(0 : Int)) hp4_3_branches39 hp4_3_evidence39 hp4_3_check39 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches39,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node40 T childKnown
  · exact hp4_3_node41 T childKnown
  · exact hp4_3_node42 T childKnown
  · exact hp4_3_node43 T childKnown
  · exact hp4_3_node46 T childKnown
theorem hp4_3_node38 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected38 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected38 ((4 : Int),(2 : Int)) hp4_3_branches38 hp4_3_evidence38 hp4_3_check38 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches38,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node37 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected37 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected37 ((4 : Int),(2 : Int)) hp4_3_branches37 hp4_3_evidence37 hp4_3_check37 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches37,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node36 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected36 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected36 ((3 : Int),(2 : Int)) hp4_3_branches36 hp4_3_evidence36 hp4_3_check36 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches36,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node37 T childKnown
  · exact hp4_3_node38 T childKnown
  · exact hp4_3_node39 T childKnown
theorem hp4_3_node35 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected35 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected35 ((3 : Int),(0 : Int)) hp4_3_branches35 hp4_3_evidence35 hp4_3_check35 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches35,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node36 T childKnown
theorem hp4_3_node34 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected34 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected34 ((2 : Int),(0 : Int)) hp4_3_branches34 hp4_3_evidence34 hp4_3_check34 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches34,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node35 T childKnown
  · exact hp4_3_node50 T childKnown
  · exact hp4_3_node53 T childKnown
  · exact hp4_3_node59 T childKnown
theorem hp4_3_node33 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected33 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected33 ((3 : Int),(1 : Int)) hp4_3_branches33 hp4_3_evidence33 hp4_3_check33 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches33,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node32 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected32 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected32 ((3 : Int),(1 : Int)) hp4_3_branches32 hp4_3_evidence32 hp4_3_check32 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches32,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node31 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected31 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected31 ((2 : Int),(1 : Int)) hp4_3_branches31 hp4_3_evidence31 hp4_3_check31 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches31,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node32 T childKnown
  · exact hp4_3_node33 T childKnown
theorem hp4_3_node30 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected30 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected30 ((4 : Int),(2 : Int)) hp4_3_branches30 hp4_3_evidence30 hp4_3_check30 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches30,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node29 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected29 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected29 ((4 : Int),(2 : Int)) hp4_3_branches29 hp4_3_evidence29 hp4_3_check29 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches29,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node28 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected28 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected28 ((5 : Int),(2 : Int)) hp4_3_branches28 hp4_3_evidence28 hp4_3_check28 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches28,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node27 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected27 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected27 ((5 : Int),(1 : Int)) hp4_3_branches27 hp4_3_evidence27 hp4_3_check27 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches27,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node28 T childKnown
theorem hp4_3_node26 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected26 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected26 ((4 : Int),(1 : Int)) hp4_3_branches26 hp4_3_evidence26 hp4_3_check26 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches26,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node27 T childKnown
  · exact hp4_3_node29 T childKnown
  · exact hp4_3_node30 T childKnown
theorem hp4_3_node25 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected25 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected25 ((2 : Int),(1 : Int)) hp4_3_branches25 hp4_3_evidence25 hp4_3_check25 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches25,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node26 T childKnown
theorem hp4_3_node24 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected24 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected24 ((3 : Int),(1 : Int)) hp4_3_branches24 hp4_3_evidence24 hp4_3_check24 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches24,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node23 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected23 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected23 ((3 : Int),(1 : Int)) hp4_3_branches23 hp4_3_evidence23 hp4_3_check23 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches23,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node22 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected22 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected22 ((3 : Int),(0 : Int)) hp4_3_branches22 hp4_3_evidence22 hp4_3_check22 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches22,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node23 T childKnown
  · exact hp4_3_node24 T childKnown
theorem hp4_3_node21 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected21 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected21 ((9 : Int),(1 : Int)) hp4_3_branches21 hp4_3_evidence21 hp4_3_check21 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches21,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node20 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected20 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected20 ((9 : Int),(1 : Int)) hp4_3_branches20 hp4_3_evidence20 hp4_3_check20 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches20,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node19 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected19 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected19 ((9 : Int),(1 : Int)) hp4_3_branches19 hp4_3_evidence19 hp4_3_check19 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches19,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node18 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected18 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected18 ((8 : Int),(1 : Int)) hp4_3_branches18 hp4_3_evidence18 hp4_3_check18 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches18,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_3_node19 T childKnown
  · exact hp4_3_node20 T childKnown
  · exact hp4_3_node21 T childKnown
theorem hp4_3_node17 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected17 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected17 ((9 : Int),(1 : Int)) hp4_3_branches17 hp4_3_evidence17 hp4_3_check17 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches17,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node16 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected16 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected16 ((9 : Int),(1 : Int)) hp4_3_branches16 hp4_3_evidence16 hp4_3_check16 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches16,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node15 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected15 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected15 ((8 : Int),(1 : Int)) hp4_3_branches15 hp4_3_evidence15 hp4_3_check15 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches15,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_3_node16 T childKnown
  · exact hp4_3_node17 T childKnown
theorem hp4_3_node14 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected14 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected14 ((8 : Int),(1 : Int)) hp4_3_branches14 hp4_3_evidence14 hp4_3_check14 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches14,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node13 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected13 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected13 ((8 : Int),(1 : Int)) hp4_3_branches13 hp4_3_evidence13 hp4_3_check13 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches13,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node12 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected12 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected12 ((8 : Int),(1 : Int)) hp4_3_branches12 hp4_3_evidence12 hp4_3_check12 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches12,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node11 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected11 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected11 ((9 : Int),(0 : Int)) hp4_3_branches11 hp4_3_evidence11 hp4_3_check11 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches11,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node12 T childKnown
  · exact hp4_3_node13 T childKnown
  · exact hp4_3_node14 T childKnown
  · exact hp4_3_node15 T childKnown
  · exact hp4_3_node18 T childKnown
theorem hp4_3_node10 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected10 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected10 ((4 : Int),(2 : Int)) hp4_3_branches10 hp4_3_evidence10 hp4_3_check10 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches10,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node9 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected9 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected9 ((4 : Int),(2 : Int)) hp4_3_branches9 hp4_3_evidence9 hp4_3_check9 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches9,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node8 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected8 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected8 ((5 : Int),(2 : Int)) hp4_3_branches8 hp4_3_evidence8 hp4_3_check8 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches8,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node7 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected7 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected7 ((4 : Int),(2 : Int)) hp4_3_branches7 hp4_3_evidence7 hp4_3_check7 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches7,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node8 T childKnown
theorem hp4_3_node6 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected6 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected6 ((3 : Int),(2 : Int)) hp4_3_branches6 hp4_3_evidence6 hp4_3_check6 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches6,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node7 T childKnown
  · exact hp4_3_node9 T childKnown
  · exact hp4_3_node10 T childKnown
  · exact hp4_3_node11 T childKnown
theorem hp4_3_node5 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected5 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected5 ((3 : Int),(0 : Int)) hp4_3_branches5 hp4_3_evidence5 hp4_3_check5 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches5,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_3_node6 T childKnown
theorem hp4_3_node4 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected4 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected4 ((2 : Int),(0 : Int)) hp4_3_branches4 hp4_3_evidence4 hp4_3_check4 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches4,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node5 T childKnown
  · exact hp4_3_node22 T childKnown
  · exact hp4_3_node25 T childKnown
  · exact hp4_3_node31 T childKnown
theorem hp4_3_node3 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected3 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected3 ((0 : Int),(2 : Int)) hp4_3_branches3 hp4_3_evidence3 hp4_3_check3 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches3,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_3_node4 T childKnown
  · exact hp4_3_node34 T childKnown
  · exact hp4_3_node62 T childKnown
  · exact hp4_3_node90 T childKnown
theorem hp4_3_node2 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected2 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected2 ((0 : Int),(1 : Int)) hp4_3_branches2 hp4_3_evidence2 hp4_3_check2 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches2,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_3_node1 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected1 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected1 ((1 : Int),(0 : Int)) hp4_3_branches1 hp4_3_evidence1 hp4_3_check1 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches1,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node2 T childKnown
  · exact hp4_3_node3 T childKnown
  · exact hp4_3_node109 T childKnown
  · exact hp4_3_node110 T childKnown
  · exact hp4_3_node111 T childKnown
  · exact hp4_3_node141 T childKnown
  · exact hp4_3_node148 T childKnown
  · exact hp4_3_node164 T childKnown
theorem hp4_3_node0 (T : Tiling (4 : Int) (3 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_3_selected0 → T.world s) : False := by
  apply replay_step (4 : Int) (3 : Int) (by decide) (by decide) T hp4_3_selected0 ((0 : Int),(0 : Int)) hp4_3_branches0 hp4_3_evidence0 hp4_3_check0 ?_ known
  intro t member childKnown
  simp only [hp4_3_branches0,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_3_node1 T childKnown
  · exact hp4_3_node193 T childKnown
  · exact hp4_3_node231 T childKnown
  · exact hp4_3_node330 T childKnown
  · exact hp4_3_node368 T childKnown
  · exact hp4_3_node371 T childKnown
  · exact hp4_3_node451 T childKnown
  · exact hp4_3_node495 T childKnown
  · exact hp4_3_node525 T childKnown
  · exact hp4_3_node555 T childKnown
  · exact hp4_3_node709 T childKnown
  · exact hp4_3_node738 T childKnown
  · exact hp4_3_node892 T childKnown
  · exact hp4_3_node921 T childKnown
  · exact hp4_3_node923 T childKnown
  · exact hp4_3_node940 T childKnown
  · exact hp4_3_node943 T childKnown
  · exact hp4_3_node1142 T childKnown

theorem hp4_3_no_half_plane : ¬Tiles (4 : Int) (3 : Int) 1 0 HalfPlane := by
  rintro ⟨T⟩
  exact hp4_3_node0 T (by simp [hp4_3_selected0])
#print axioms hp4_3_no_half_plane

end THalfPlaneFinite

import THalfPlaneUnit
import THalfPlaneDeepGaps

namespace PolyominoFormal.TPlaneDeep
open CrossUnits CornerCertificate THalfPlaneStarters THalfPlaneGaps THalfPlaneDeepGaps

/-- An inward-pointing vertical starter meets its immediate neighbor. -/
theorem right_v_hits_next {a b c p h r : Int} {region : Region}
    (ha : c≤a) (hc : 1≤c) (long : a+c≤b) (hr : r=a ∨ r=c)
    (T : Tiling a b c 0 region)
    (anchor : T.world ⟨p,h+r,b,a+c-r,0,r⟩)
    {u : Cross} (hu : T.world u) (su : Starter a b c (p+1) h u) : False := by
  have stem : Contains ⟨p,h+r,b,a+c-r,0,r⟩ (p+1) (h+r) := by
    left; dsimp; omega
  have hit := starter_column (y:=h+r) (by omega) (by omega) hc su (by omega) (by omega) (by omega)
  have eq := T.disjoint _ u (p+1) (h+r) anchor hu stem hit
  have xp : u.x=p+1 := by rcases su with rfl | rfl | rfl | rfl | rfl | rfl <;> rfl
  have heq := congrArg Cross.x eq
  dsimp at heq
  omega

/-- Three or more starters cannot border a deep left wall. -/
theorem starters_deep_left {a b c L R h : Int} {region B : Region}
    (ha : c≤a) (hc : 1≤c) (long : a+c≤b) (three : L+2≤R)
    (T : Tiling a b c 0 region) (closed : TileClosed T.world B)
    (empty : ∀ x, L≤x → x≤R → ¬B x h)
    (wall : ∀ y, h≤y → y≤h+a → B (L-1) y)
    (choose : ∀ x, L≤x → x≤R → ∃ t, T.world t ∧ Starter a b c x h t) : False := by
  have chooseS : ∀ p, L≤p → p≤L+1 → ∃ t, T.world t ∧
      (t=⟨p,h+b,a,0,c,b⟩ ∨ t=⟨p,h+b,c,0,a,b⟩) := by
    intro p hp0 hp1
    obtain ⟨t,ht,st⟩ := choose p hp0 (by omega)
    obtain ⟨u,hu,su⟩ := choose (p+1) (by omega) (by omega)
    rcases st with rfl | rfl | rfl | rfl | rfl | rfl
    · exact False.elim (right_v_hits_next ha hc long (Or.inl rfl) T
        (by simpa only [show a+c-a=c by omega] using ht) hu su)
    · exact False.elim (right_v_hits_next ha hc long (Or.inr rfl) T
        (by simpa only [show a+c-c=a by omega] using ht) hu su)
    · exact False.elim (left_v_collides ha hc long (Or.inl rfl) hp0 (by omega) T closed
        (empty p hp0 (by omega)) wall choose (by simpa only [show a+c-a=c by omega] using ht))
    · exact False.elim (left_v_collides ha hc long (Or.inr rfl) hp0 (by omega) T closed
        (empty p hp0 (by omega)) wall choose (by simpa only [show a+c-c=a by omega] using ht))
    · exact ⟨_,ht,Or.inl rfl⟩
    · exact ⟨_,ht,Or.inr rfl⟩
  obtain ⟨t,ht,st⟩ := chooseS L (by omega) (by omega)
  obtain ⟨u,hu,su⟩ := chooseS (L+1) (by omega) (by omega)
  have hit : Contains t (L+1) (h+b) := by rcases st with rfl | rfl <;> left <;> dsimp <;> omega
  have hit' : Contains u (L+1) (h+b) := by rcases su with rfl | rfl <;> left <;> dsimp <;> omega
  have eq := T.disjoint t u (L+1) (h+b) ht hu hit hit'
  have tx : t.x=L := by rcases st with rfl | rfl <;> rfl
  have ux : u.x=L+1 := by rcases su with rfl | rfl <;> rfl
  have heq := congrArg Cross.x eq
  omega

/-- A horizontal bar and the starter immediately before it create a forbidden
short run one row higher. Both crossbar arms have length at least two. -/
theorem horizontal_after_starter {a b c q r h : Int} {region : Region}
    (ha : c≤a) (hc : 2≤c) (long : a+c≤b) (hr : r=a ∨ r=c)
    (T : Tiling a b c 0 region)
    (inside : ∀ x, q≤x → x≤q+r-1 → region x (h+1))
    (ht : T.world ⟨q+r,h,a+c-r,b,r,0⟩)
    {u : Cross} (hu : T.world u) (su : Starter a b c (q-1) h u) : False := by
  let t : Cross := ⟨q+r,h,a+c-r,b,r,0⟩
  let B : Region := fun x y => Contains t x y ∨ Contains u x y
  apply blocked_deep_run (L:=q) (R:=q+r-1) (h:=h+1) ha (by omega) long
    (by omega) (by omega) T B (pair_closed T ht hu) inside
  · intro x hx0 hx1
    rcases su with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals dsimp [B,t,Contains]; omega
  · intro x hx0 hx1
    left
    dsimp [t,Contains]
    omega
  · intro y hy0 hy1
    right
    exact starter_column (by omega) (by omega) (by omega) su (by omega) (by omega) (by omega)
  · intro y hy0 hy1
    left
    right
    dsimp [t]
    omega

/-- At the left end, the original straight deep wall serves the same role. -/
theorem horizontal_after_wall {a b c L r h : Int} {region C : Region}
    (ha : c≤a) (hc : 2≤c) (long : a+c≤b) (hr : r=a ∨ r=c)
    (T : Tiling a b c 0 region) (closed : TileClosed T.world C)
    (inside : ∀ x, L≤x → x≤L+r-1 → region x (h+1))
    (wall : ∀ y, h≤y → y≤h+a+1 → C (L-1) y)
    (straight : ∀ x, L≤x → x≤L+r-1 → ¬C x (h+1))
    (ht : T.world ⟨L+r,h,a+c-r,b,r,0⟩) : False := by
  let t : Cross := ⟨L+r,h,a+c-r,b,r,0⟩
  let B : Region := fun x y => Contains t x y ∨ C x y
  apply blocked_deep_run (L:=L) (R:=L+r-1) (h:=h+1) ha (by omega) long
    (by omega) (by omega) T B (union_closed (single_closed T ht) closed) inside
  · intro x hx0 hx1
    rintro (hit | hit)
    · dsimp [t,Contains] at hit; omega
    · exact straight x hx0 hx1 hit
  · intro x hx0 hx1
    left
    dsimp [t,Contains]
    omega
  · intro y hy0 hy1
    right
    exact wall y (by omega) (by omega)
  · intro y hy0 hy1
    left
    right
    dsimp [t]
    omega


/-- Any run of at least three cells with a full floor and a straight deep
left endpoint wall is impossible. The width has no upper bound. -/
theorem deep_left_run {a b c L R h : Int} {region : Region}
    (ha : c≤a) (hc : 2≤c) (long : a+c≤b) (three : L+2≤R)
    (T : Tiling a b c 0 region) (B C : Region)
    (closed : TileClosed T.world B) (wallClosed : TileClosed T.world C)
    (wallSubset : ∀ x y, C x y → B x y)
    (inside : ∀ x, L≤x → x≤R → region x h)
    (insideAbove : ∀ x, L≤x → x≤R → region x (h+1))
    (empty : ∀ x, L≤x → x≤R → ¬B x h)
    (floor : ∀ x, L≤x → x≤R → B x (h-1))
    (wall : ∀ y, h≤y → y≤h+a+1 → C (L-1) y)
    (straight : ∀ x, L≤x → x≤R → ¬C x (h+1))
    (right : B (R+1) h) : False := by
  have choose : ∀ p, L≤p → p≤R → ∃ t, T.world t ∧
      ((∃ q r, (r=a ∨ r=c) ∧ t=⟨q+r,h,a+c-r,b,r,0⟩ ∧
        L≤q ∧ q≤p ∧ p≤q+a+c ∧ q+a+c≤R) ∨ Starter a b c p h t) := by
    intro p hp0 hp1
    obtain ⟨t,ht,hit⟩ := T.cover p h (inside p hp0 hp1)
    have avoid : ∀ {x y}, B x y → ¬Contains t x y :=
      fun blocked => avoid_closed closed ht hit (empty p hp0 hp1) blocked
    refine ⟨t,ht,THalfPlaneUnit.run_forms (by omega) (by omega) (by omega) hp0 hp1
      (T.copies t ht) hit ?_ (avoid right) (avoid (floor p hp0 hp1)) ?_⟩
    · exact avoid (wallSubset _ _ (wall h (by omega) (by omega)))
    · intro hx0 hx1
      exact avoid (floor t.x hx0 hx1)
  have forbid : ∀ n : Nat, ∀ q r, (q-L).toNat=n → (r=a ∨ r=c) →
      L≤q → q+a+c≤R → T.world ⟨q+r,h,a+c-r,b,r,0⟩ → False := by
    intro n
    induction n using Nat.strongRecOn with
    | ind n ih =>
      intro q r hn hr hq0 hq1 ht
      by_cases first : q=L
      · subst q
        exact horizontal_after_wall ha hc long hr T wallClosed
          (fun x hx0 hx1 => insideAbove x hx0 (by omega)) wall
          (fun x hx0 hx1 => straight x hx0 (by omega)) ht
      · obtain ⟨u,hu,form⟩ := choose (q-1) (by omega) (by omega)
        rcases form with ⟨v,s,hs,eq,hv0,hv1,_,hv2⟩ | su
        · have hu' : T.world ⟨v+s,h,a+c-s,b,s,0⟩ := eq ▸ hu
          exact ih (v-L).toNat (by omega) v s rfl hs hv0 hv2 hu'
        · exact horizontal_after_starter ha hc long hr T
            (fun x hx0 hx1 => insideAbove x (by omega) (by omega)) ht hu su
  have starters : ∀ p, L≤p → p≤R → ∃ t, T.world t ∧ Starter a b c p h t := by
    intro p hp0 hp1
    obtain ⟨t,ht,form⟩ := choose p hp0 hp1
    rcases form with ⟨q,r,hr,eq,hq0,_,_,hq1⟩ | st
    · have ht' : T.world ⟨q+r,h,a+c-r,b,r,0⟩ := eq ▸ ht
      exact False.elim (forbid (q-L).toNat q r rfl hr hq0 hq1 ht')
    · exact ⟨t,ht,st⟩
  exact starters_deep_left ha (by omega) long three T closed empty
    (fun y hy0 hy1 => wallSubset _ _ (wall y hy0 (by omega))) starters



theorem mirrorX_closed {a b c : Int} {region C : Region}
    (T : Tiling a b c 0 region) (closed : TileClosed T.world C) :
    TileClosed T.mirrorX.world (fun x y => C (-x) y) := by
  rintro t ⟨u,hu,rfl⟩ x y hit blocked p q other
  exact closed u hu (-x) y ((mirrorX_hit u x y).1 hit) blocked (-p) q
    ((mirrorX_hit u p q).1 other)

/-- The new bar's own stem is the deep wall after reflecting the gap. -/
theorem horizontal_after_shallow_wall {a b c L r h : Int} {region C : Region}
    (ha : c≤a) (hc : 3≤c) (long : a+c≤b) (hr : r=a ∨ r=c)
    (T : Tiling a b c 0 region) (closed : TileClosed T.world C)
    (inside : ∀ x, L≤x → x≤L+r-1 → region x (h+1))
    (insideAbove : ∀ x, L≤x → x≤L+r-1 → region x (h+2))
    (wall : C (L-1) (h+1))
    (straight : ∀ x, L≤x → x≤L+r-1 → ¬C x (h+1))
    (ht : T.world ⟨L+r,h,a+c-r,b,r,0⟩) : False := by
  let t : Cross := ⟨L+r,h,a+c-r,b,r,0⟩
  let U := T.mirrorX
  have ht' : U.world (mirrorX t) := ⟨t,ht,rfl⟩
  let D : Region := Contains (mirrorX t)
  let B : Region := fun x y => D x y ∨ C (-x) y
  apply deep_left_run (L:= -(L+r)+1) (R:= -L) (h:=h+1) ha (by omega) long
    (by omega) U B D (union_closed (single_closed U ht') (mirrorX_closed T closed))
    (single_closed U ht') (fun _ _ member => Or.inl member)
  · intro x hx0 hx1
    exact inside (-x) (by omega) (by omega)
  · intro x hx0 hx1
    have ey : h+1+1=h+2 := by omega
    rw [ey]
    exact insideAbove (-x) (by omega) (by omega)
  · intro x hx0 hx1
    rintro (hit | hit)
    · dsimp [D,t,mirrorX,Contains] at hit; omega
    · exact straight (-x) (by omega) (by omega) hit
  · intro x hx0 hx1
    left
    dsimp [D,t,mirrorX,Contains]
    omega
  · intro y hy0 hy1
    dsimp [D,t,mirrorX,Contains]
    omega
  · intro x hx0 hx1
    dsimp [D,t,mirrorX,Contains]
    omega
  · right
    have ex : -(-L+1)=L-1 := by omega
    rw [ex]
    exact wall

theorem left_v_hits_previous {a b c p h r : Int} {region : Region}
    (ha : c≤a) (hc : 1≤c) (long : a+c≤b) (hr : r=a ∨ r=c)
    (T : Tiling a b c 0 region)
    (anchor : T.world ⟨p,h+r,0,a+c-r,b,r⟩)
    {u : Cross} (hu : T.world u) (su : Starter a b c (p-1) h u) : False := by
  have stem : Contains ⟨p,h+r,0,a+c-r,b,r⟩ (p-1) (h+r) := by
    left; dsimp; omega
  have hit := starter_column (y:=h+r) (by omega) (by omega) hc su (by omega) (by omega) (by omega)
  have eq := T.disjoint _ u (p-1) (h+r) anchor hu stem hit
  have xp : u.x=p-1 := by rcases su with rfl | rfl | rfl | rfl | rfl | rfl <;> rfl
  have heq := congrArg Cross.x eq
  dsimp at heq
  omega

theorem four_starters_impossible {a b c L R h : Int} {region : Region}
    (ha : c≤a) (hc : 1≤c) (long : a+c≤b) (four : L+3≤R)
    (T : Tiling a b c 0 region)
    (choose : ∀ x, L≤x → x≤R → ∃ t, T.world t ∧ Starter a b c x h t) : False := by
  have chooseS : ∀ p, L+1≤p → p≤L+2 → ∃ t, T.world t ∧
      (t=⟨p,h+b,a,0,c,b⟩ ∨ t=⟨p,h+b,c,0,a,b⟩) := by
    intro p hp0 hp1
    obtain ⟨t,ht,st⟩ := choose p (by omega) (by omega)
    obtain ⟨u,hu,su⟩ := choose (p+1) (by omega) (by omega)
    obtain ⟨v,hv,sv⟩ := choose (p-1) (by omega) (by omega)
    rcases st with rfl | rfl | rfl | rfl | rfl | rfl
    · exact False.elim (right_v_hits_next ha hc long (Or.inl rfl) T
        (by simpa only [show a+c-a=c by omega] using ht) hu su)
    · exact False.elim (right_v_hits_next ha hc long (Or.inr rfl) T
        (by simpa only [show a+c-c=a by omega] using ht) hu su)
    · exact False.elim (left_v_hits_previous ha hc long (Or.inl rfl) T
        (by simpa only [show a+c-a=c by omega] using ht) hv sv)
    · exact False.elim (left_v_hits_previous ha hc long (Or.inr rfl) T
        (by simpa only [show a+c-c=a by omega] using ht) hv sv)
    · exact ⟨_,ht,Or.inl rfl⟩
    · exact ⟨_,ht,Or.inr rfl⟩
  obtain ⟨t,ht,st⟩ := chooseS (L+1) (by omega) (by omega)
  obtain ⟨u,hu,su⟩ := chooseS (L+2) (by omega) (by omega)
  have hit : Contains t (L+2) (h+b) := by rcases st with rfl | rfl <;> left <;> dsimp <;> omega
  have hit' : Contains u (L+2) (h+b) := by rcases su with rfl | rfl <;> left <;> dsimp <;> omega
  have eq := T.disjoint t u (L+2) (h+b) ht hu hit hit'
  have tx : t.x=L+1 := by rcases st with rfl | rfl <;> rfl
  have ux : u.x=L+2 := by rcases su with rfl | rfl <;> rfl
  have heq := congrArg Cross.x eq
  omega

/-- With both crossbar arms at least three, a straight shallow wall suffices
for any run of width at least four. -/
theorem weak_left_run {a b c L R h : Int} {region : Region}
    (ha : c≤a) (hc : 3≤c) (long : a+c≤b) (four : L+3≤R)
    (T : Tiling a b c 0 region) (B C : Region)
    (closed : TileClosed T.world B) (wallClosed : TileClosed T.world C)
    (wallSubset : ∀ x y, C x y → B x y)
    (inside : ∀ x, L≤x → x≤R → region x h)
    (insideAbove : ∀ x, L≤x → x≤R → region x (h+1))
    (insideAbove2 : ∀ x, L≤x → x≤R → region x (h+2))
    (empty : ∀ x, L≤x → x≤R → ¬B x h)
    (floor : ∀ x, L≤x → x≤R → B x (h-1))
    (wall : ∀ y, h≤y → y≤h+1 → C (L-1) y)
    (straight : ∀ x, L≤x → x≤R → ¬C x (h+1))
    (right : B (R+1) h) : False := by
  have choose : ∀ p, L≤p → p≤R → ∃ t, T.world t ∧
      ((∃ q r, (r=a ∨ r=c) ∧ t=⟨q+r,h,a+c-r,b,r,0⟩ ∧
        L≤q ∧ q≤p ∧ p≤q+a+c ∧ q+a+c≤R) ∨ Starter a b c p h t) := by
    intro p hp0 hp1
    obtain ⟨t,ht,hit⟩ := T.cover p h (inside p hp0 hp1)
    have avoid : ∀ {x y}, B x y → ¬Contains t x y :=
      fun blocked => avoid_closed closed ht hit (empty p hp0 hp1) blocked
    refine ⟨t,ht,THalfPlaneUnit.run_forms (by omega) (by omega) (by omega) hp0 hp1
      (T.copies t ht) hit ?_ (avoid right) (avoid (floor p hp0 hp1)) ?_⟩
    · exact avoid (wallSubset _ _ (wall h (by omega) (by omega)))
    · intro hx0 hx1
      exact avoid (floor t.x hx0 hx1)
  have forbid : ∀ n : Nat, ∀ q r, (q-L).toNat=n → (r=a ∨ r=c) →
      L≤q → q+a+c≤R → T.world ⟨q+r,h,a+c-r,b,r,0⟩ → False := by
    intro n
    induction n using Nat.strongRecOn with
    | ind n ih =>
      intro q r hn hr hq0 hq1 ht
      by_cases first : q=L
      · subst q
        exact horizontal_after_shallow_wall ha hc long hr T wallClosed
          (fun x hx0 hx1 => insideAbove x hx0 (by omega))
          (fun x hx0 hx1 => insideAbove2 x hx0 (by omega)) (wall (h+1) (by omega) (by omega))
          (fun x hx0 hx1 => straight x hx0 (by omega)) ht
      · obtain ⟨u,hu,form⟩ := choose (q-1) (by omega) (by omega)
        rcases form with ⟨v,s,hs,eq,hv0,hv1,_,hv2⟩ | su
        · have hu' : T.world ⟨v+s,h,a+c-s,b,s,0⟩ := eq ▸ hu
          exact ih (v-L).toNat (by omega) v s rfl hs hv0 hv2 hu'
        · exact horizontal_after_starter ha (by omega) long hr T
            (fun x hx0 hx1 => insideAbove x (by omega) (by omega)) ht hu su
  have starters : ∀ p, L≤p → p≤R → ∃ t, T.world t ∧ Starter a b c p h t := by
    intro p hp0 hp1
    obtain ⟨t,ht,form⟩ := choose p hp0 hp1
    rcases form with ⟨q,r,hr,eq,hq0,_,_,hq1⟩ | st
    · have ht' : T.world ⟨q+r,h,a+c-r,b,r,0⟩ := eq ▸ ht
      exact False.elim (forbid (q-L).toNat q r rfl hr hq0 hq1 ht')
    · exact ⟨t,ht,st⟩
  exact four_starters_impossible ha (by omega) long four T starters

#print axioms deep_left_run
#print axioms weak_left_run
end PolyominoFormal.TPlaneDeep

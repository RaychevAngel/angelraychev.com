import LQuadrantHpOptimizedUnequalNestedShortBfiveDeltaTwoPrunedArithmeticDefs
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace LRegionArithmetic

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n334_o4 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n334_o5 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((jx + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n334_o6 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((jx + b) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h2 : (b = (5 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h7 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h8 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n334_o7 (a b jx jy : Int)
    (h0 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (¬ ((((4 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h2 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h3 : (b = (5 : Int)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n335_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((3 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n335_run_short (a b : Int)
    (h0 : (¬ ((((3 : Int) + b) - (4 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n335_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n335_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3386 a b) ∨ (fact_9fdb227ae99d_3387 a b) ∨ (fact_9fdb227ae99d_4499 a b) ∨ (fact_9fdb227ae99d_5586 a b) ∨ (fact_9fdb227ae99d_3862 a b) ∨ (fact_9fdb227ae99d_3474 a b) ∨ (fact_9fdb227ae99d_3475 a b) ∨ (fact_9fdb227ae99d_3476 a b) ∨ (fact_9fdb227ae99d_3388 a b) ∨ (fact_9fdb227ae99d_3869 a b) ∨ (fact_9fdb227ae99d_4192 a b) ∨ ((((5 : Int) ≥ (((-5 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((5 : Int) ≤ (((-5 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((5 : Int) ≥ ((-5 : Int) + ((-1 : Int) * a))) ∧ ((5 : Int) ≤ ((-5 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_3870 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n335_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3864 a b) ∨ (fact_9fdb227ae99d_3866 a b) ∨ (fact_9fdb227ae99d_5290 a b) ∨ (fact_9fdb227ae99d_5905 a b) ∨ (fact_9fdb227ae99d_4713 a b) ∨ (fact_9fdb227ae99d_4187 a b) ∨ (fact_9fdb227ae99d_4189 a b) ∨ (fact_9fdb227ae99d_4190 a b) ∨ (fact_9fdb227ae99d_3868 a b) ∨ (fact_9fdb227ae99d_4715 a b) ∨ ((((5 : Int) ≥ ((-4 : Int) - b)) ∧ ((5 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((-4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-4 : Int)) ∧ ((((3 : Int) + a) - a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((5 : Int) ≥ (((-5 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((5 : Int) ≤ (((-5 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((5 : Int) ≥ ((-5 : Int) + ((-1 : Int) * a))) ∧ ((5 : Int) ≤ ((-5 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_4717 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n335_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((3 : Int) + b)) ∧ ((fact_9fdb227ae99d_7838 a b) ∨ (fact_9fdb227ae99d_7886 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((3 : Int) + b)) ∧ (fact_9fdb227ae99d_7838 a b) ∧ (fact_9fdb227ae99d_7886 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((3 : Int) + b)) ∨ ((((3 : Int) + b) = ((4 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7838 a b) ∧ (fact_9fdb227ae99d_7886 a b) ∧ (((fact_9fdb227ae99d_3776 a b) ∨ (fact_9fdb227ae99d_3808 a b) ∨ (fact_9fdb227ae99d_5186 a b) ∨ (fact_9fdb227ae99d_5864 a b) ∨ (fact_9fdb227ae99d_4550 a b) ∨ (fact_9fdb227ae99d_3941 a b) ∨ (fact_9fdb227ae99d_3991 a b) ∨ (fact_9fdb227ae99d_4015 a b) ∨ (fact_9fdb227ae99d_3826 a b) ∨ (fact_9fdb227ae99d_4691 a b) ∨ (fact_9fdb227ae99d_4940 a b) ∨ (fact_9fdb227ae99d_5986 a b) ∨ (fact_9fdb227ae99d_4696 a b)) ∨ ((fact_9fdb227ae99d_4597 a b) ∨ (fact_9fdb227ae99d_4632 a b) ∨ (fact_9fdb227ae99d_5662 a b) ∨ (fact_9fdb227ae99d_6401 a b) ∨ (fact_9fdb227ae99d_5390 a b) ∨ (fact_9fdb227ae99d_4792 a b) ∨ (fact_9fdb227ae99d_4849 a b) ∨ (fact_9fdb227ae99d_4874 a b) ∨ (fact_9fdb227ae99d_4666 a b) ∨ (fact_9fdb227ae99d_5440 a b) ∨ (fact_9fdb227ae99d_5513 a b) ∨ ((((((-5 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((-5 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ ((((-5 : Int) + ((-1 : Int) * a)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((-5 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_5444 a b)))) ∨ ((fact_9fdb227ae99d_7838 a b) ∧ (fact_9fdb227ae99d_7886 a b) ∧ ((fact_9fdb227ae99d_3776 a b) ∨ (fact_9fdb227ae99d_3808 a b) ∨ (fact_9fdb227ae99d_5186 a b) ∨ (fact_9fdb227ae99d_5864 a b) ∨ (fact_9fdb227ae99d_4550 a b) ∨ (fact_9fdb227ae99d_3941 a b) ∨ (fact_9fdb227ae99d_3991 a b) ∨ (fact_9fdb227ae99d_4015 a b) ∨ (fact_9fdb227ae99d_3826 a b) ∨ (fact_9fdb227ae99d_4691 a b) ∨ (fact_9fdb227ae99d_4940 a b) ∨ (fact_9fdb227ae99d_5986 a b) ∨ (fact_9fdb227ae99d_4696 a b)) ∧ ((fact_9fdb227ae99d_4597 a b) ∨ (fact_9fdb227ae99d_4632 a b) ∨ (fact_9fdb227ae99d_5662 a b) ∨ (fact_9fdb227ae99d_6401 a b) ∨ (fact_9fdb227ae99d_5390 a b) ∨ (fact_9fdb227ae99d_4792 a b) ∨ (fact_9fdb227ae99d_4849 a b) ∨ (fact_9fdb227ae99d_4874 a b) ∨ (fact_9fdb227ae99d_4666 a b) ∨ (fact_9fdb227ae99d_5440 a b) ∨ (fact_9fdb227ae99d_5513 a b) ∨ ((((((-5 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((-5 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ ((((-5 : Int) + ((-1 : Int) * a)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((-5 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_5444 a b))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n335_run_empty (a b run_x : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (run_x ≤ ((3 : Int) + b)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((2 : Int) + a) < (((-5 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-5 : Int) + ((-1 : Int) * a)) + a) < ((2 : Int) + a)) ∨ ((3 : Int) > ((2 : Int) + b)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : ((4 : Int) ≤ run_x))
    (h6 : ((fact_9fdb227ae99d_2449 a b run_x) ∨ (fact_9fdb227ae99d_2450 a b run_x) ∨ (fact_9fdb227ae99d_3073 a b run_x) ∨ (fact_9fdb227ae99d_3572 a b run_x) ∨ (fact_9fdb227ae99d_2984 a b run_x) ∨ (fact_9fdb227ae99d_2539 a b run_x) ∨ (fact_9fdb227ae99d_2540 a b run_x) ∨ (fact_9fdb227ae99d_2541 a b run_x) ∨ (fact_9fdb227ae99d_2451 a b run_x) ∨ (fact_9fdb227ae99d_2985 a b run_x) ∨ (fact_9fdb227ae99d_3016 a b run_x) ∨ ((((5 : Int) ≥ (((-5 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((5 : Int) ≤ (((-5 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((5 : Int) ≥ ((-5 : Int) + ((-1 : Int) * a))) ∧ ((5 : Int) ≤ ((-5 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_2986 a b run_x)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n335_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((3 : Int) + b)))
    (h1 : (¬ ((fact_9fdb227ae99d_3175 a b run_x) ∨ (fact_9fdb227ae99d_3185 a b run_x) ∨ (fact_9fdb227ae99d_3728 a b run_x) ∨ (fact_9fdb227ae99d_5193 a b run_x) ∨ (fact_9fdb227ae99d_3487 a b run_x) ∨ (fact_9fdb227ae99d_3219 a b run_x) ∨ (fact_9fdb227ae99d_3235 a b run_x) ∨ (fact_9fdb227ae99d_3241 a b run_x) ∨ (fact_9fdb227ae99d_3194 a b run_x) ∨ (fact_9fdb227ae99d_3557 a b run_x) ∨ (fact_9fdb227ae99d_3580 a b run_x) ∨ ((((((-5 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((-5 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ ((((-5 : Int) + ((-1 : Int) * a)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((-5 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_3561 a b run_x))))
    (h2 : ((4 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n336_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≤ a)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n336_run_short (a b : Int)
    (h0 : (¬ ((a - (3 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n336_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n336_run_left (a b : Int)
    (h0 : (¬ ((((((0 : Int) - (0 : Int)) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (-(6 : Int))) ∧ ((0 : Int) ≥ (-(6 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((1 : Int) ≤ (-(6 : Int))) ∧ ((1 : Int) ≥ (-(6 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((2 : Int) + a) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-(6 : Int))) ∧ ((-1 : Int) ≥ (-(6 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-2 : Int) ≤ (-(6 : Int))) ∧ ((-2 : Int) ≥ (-(6 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((-3 : Int) - a) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-3 : Int) ≤ (-(6 : Int))) ∧ ((-3 : Int) ≥ (-(6 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((2 : Int) ≤ (-(6 : Int))) ∧ ((2 : Int) ≥ (-(6 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (-(6 : Int))) ∧ ((3 : Int) ≥ (-(6 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((-4 : Int) - b) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((-4 : Int) ≤ (-(6 : Int))) ∧ ((-4 : Int) ≥ (-(6 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((-5 : Int) - a) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((-5 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((-5 : Int) ≤ (-(6 : Int))) ∧ ((-5 : Int) ≥ (-(6 : Int))) ∧ ((((3 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n336_run_right (a b : Int)
    (h0 : (¬ ((((((0 : Int) - (0 : Int)) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (a + (1 : Int))) ∧ ((0 : Int) ≥ (a + (1 : Int)))) ∨ (((0 : Int) ≤ (-(6 : Int))) ∧ ((0 : Int) ≥ (-(6 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ (((1 : Int) ≤ (-(6 : Int))) ∧ ((1 : Int) ≥ (-(6 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (a + (1 : Int))) ∧ ((0 : Int) ≥ (a + (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ ((((2 : Int) + a) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (a + (1 : Int))) ∧ ((0 : Int) ≥ (a + (1 : Int)))) ∨ (((-1 : Int) ≤ (-(6 : Int))) ∧ ((-1 : Int) ≥ (-(6 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ (((-2 : Int) ≤ (-(6 : Int))) ∧ ((-2 : Int) ≥ (-(6 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((-3 : Int) - a) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ (((-3 : Int) ≤ (-(6 : Int))) ∧ ((-3 : Int) ≥ (-(6 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ (a + (1 : Int))) ∧ ((3 : Int) ≥ (a + (1 : Int)))) ∨ (((2 : Int) ≤ (-(6 : Int))) ∧ ((2 : Int) ≥ (-(6 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (-(6 : Int))) ∧ ((3 : Int) ≥ (-(6 : Int))) ∧ ((((4 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((-4 : Int) - b) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((-4 : Int) ≤ (-(6 : Int))) ∧ ((-4 : Int) ≥ (-(6 : Int))) ∧ ((((3 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((-5 : Int) - a) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((-5 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((-5 : Int) ≤ (-(6 : Int))) ∧ ((-5 : Int) ≥ (-(6 : Int))) ∧ ((((3 : Int) + b) - b) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n336_run_tall (a b : Int)
    (h0 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_9fdb227ae99d_7773 a b) ∨ (fact_9fdb227ae99d_7654 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_9fdb227ae99d_7773 a b) ∧ (fact_9fdb227ae99d_7654 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7773 a b) ∧ (fact_9fdb227ae99d_7654 a b) ∧ (((fact_9fdb227ae99d_4354 a b) ∨ (fact_9fdb227ae99d_4371 a b) ∨ (fact_9fdb227ae99d_5464 a b) ∨ (fact_9fdb227ae99d_6187 a b) ∨ (fact_9fdb227ae99d_5122 a b) ∨ (fact_9fdb227ae99d_4443 a b) ∨ (fact_9fdb227ae99d_4464 a b) ∨ (((((-3 : Int) - a) ≤ (-((6 : Int) + a))) ∧ ((-((6 : Int) + a)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-3 : Int) ≤ (-((6 : Int) + a))) ∧ ((-3 : Int) ≥ (-((6 : Int) + a))) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_4381 a b) ∨ (fact_9fdb227ae99d_5150 a b) ∨ (fact_9fdb227ae99d_5257 a b) ∨ (fact_9fdb227ae99d_5259 a b)) ∨ ((fact_9fdb227ae99d_3426 a b) ∨ (fact_9fdb227ae99d_3444 a b) ∨ (fact_9fdb227ae99d_4519 a b) ∨ (fact_9fdb227ae99d_5603 a b) ∨ (fact_9fdb227ae99d_3891 a b) ∨ (fact_9fdb227ae99d_3518 a b) ∨ (fact_9fdb227ae99d_3534 a b) ∨ (((((-3 : Int) - a) ≤ (-((6 : Int) + a))) ∧ ((-((6 : Int) + a)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ (((-3 : Int) ≤ (-((6 : Int) + a))) ∧ ((-3 : Int) ≥ (-((6 : Int) + a))) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3454 a b) ∨ (fact_9fdb227ae99d_4149 a b) ∨ (fact_9fdb227ae99d_4308 a b) ∨ (fact_9fdb227ae99d_4310 a b)))) ∨ ((fact_9fdb227ae99d_7773 a b) ∧ (fact_9fdb227ae99d_7654 a b) ∧ ((fact_9fdb227ae99d_4354 a b) ∨ (fact_9fdb227ae99d_4371 a b) ∨ (fact_9fdb227ae99d_5464 a b) ∨ (fact_9fdb227ae99d_6187 a b) ∨ (fact_9fdb227ae99d_5122 a b) ∨ (fact_9fdb227ae99d_4443 a b) ∨ (fact_9fdb227ae99d_4464 a b) ∨ (((((-3 : Int) - a) ≤ (-((6 : Int) + a))) ∧ ((-((6 : Int) + a)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-3 : Int) ≤ (-((6 : Int) + a))) ∧ ((-3 : Int) ≥ (-((6 : Int) + a))) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_4381 a b) ∨ (fact_9fdb227ae99d_5150 a b) ∨ (fact_9fdb227ae99d_5257 a b) ∨ (fact_9fdb227ae99d_5259 a b)) ∧ ((fact_9fdb227ae99d_3426 a b) ∨ (fact_9fdb227ae99d_3444 a b) ∨ (fact_9fdb227ae99d_4519 a b) ∨ (fact_9fdb227ae99d_5603 a b) ∨ (fact_9fdb227ae99d_3891 a b) ∨ (fact_9fdb227ae99d_3518 a b) ∨ (fact_9fdb227ae99d_3534 a b) ∨ (((((-3 : Int) - a) ≤ (-((6 : Int) + a))) ∧ ((-((6 : Int) + a)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ (((-3 : Int) ≤ (-((6 : Int) + a))) ∧ ((-3 : Int) ≥ (-((6 : Int) + a))) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3454 a b) ∨ (fact_9fdb227ae99d_4149 a b) ∨ (fact_9fdb227ae99d_4308 a b) ∨ (fact_9fdb227ae99d_4310 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n336_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (run_x ≤ a))
    (h5 : ((3 : Int) ≤ run_x))
    (h6 : (((((2 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (b = (5 : Int)))
    (h8 : ((((((0 : Int) - (0 : Int)) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((0 : Int) ≤ (-(6 : Int))) ∧ ((0 : Int) ≥ (-(6 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((1 : Int) ≤ (-(6 : Int))) ∧ ((1 : Int) ≥ (-(6 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ ((((1 : Int) + b + a) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ ((((2 : Int) + a) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ (-(6 : Int))) ∧ ((-1 : Int) ≥ (-(6 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ (-(6 : Int))) ∧ ((-2 : Int) ≥ (-(6 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ (((((-3 : Int) - a) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ (-(6 : Int))) ∧ ((-3 : Int) ≥ (-(6 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((2 : Int) ≤ (-(6 : Int))) ∧ ((2 : Int) ≥ (-(6 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (-(6 : Int))) ∧ ((3 : Int) ≥ (-(6 : Int))) ∧ ((((4 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((-4 : Int) - b) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a))) ∨ (((-4 : Int) ≤ (-(6 : Int))) ∧ ((-4 : Int) ≥ (-(6 : Int))) ∧ ((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((-5 : Int) - a) ≤ (-(6 : Int))) ∧ ((-(6 : Int)) ≤ ((-5 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b))) ∨ (((-5 : Int) ≤ (-(6 : Int))) ∧ ((-5 : Int) ≥ (-(6 : Int))) ∧ ((((3 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + (0 : Int)))))))
    (h9 : ((((2 : Int) + a) < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < ((2 : Int) + a)) ∨ ((2 : Int) > ((2 : Int) + b)) ∨ ((2 : Int) < ((2 : Int) - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n336_run_floor (a b run_x : Int)
    (h0 : ((3 : Int) ≤ run_x))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (¬ ((((((0 : Int) - (0 : Int)) ≤ (-((6 : Int) - (1 : Int)))) ∧ ((-((6 : Int) - (1 : Int))) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((0 : Int) ≤ (-((6 : Int) - (1 : Int)))) ∧ ((0 : Int) ≥ (-((6 : Int) - (1 : Int)))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (-((6 : Int) - (1 : Int)))) ∧ ((-((6 : Int) - (1 : Int))) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((1 : Int) ≤ (-((6 : Int) - (1 : Int)))) ∧ ((1 : Int) ≥ (-((6 : Int) - (1 : Int)))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (-((6 : Int) - (1 : Int)))) ∧ ((-((6 : Int) - (1 : Int))) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ ((((1 : Int) + b + a) ≤ (-((6 : Int) - (1 : Int)))) ∧ ((-((6 : Int) - (1 : Int))) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (-((6 : Int) - (1 : Int)))) ∧ ((-((6 : Int) - (1 : Int))) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (-((6 : Int) - (1 : Int)))) ∧ ((-((6 : Int) - (1 : Int))) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (-((6 : Int) - (1 : Int)))) ∧ ((-((6 : Int) - (1 : Int))) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ ((((2 : Int) + a) ≤ (-((6 : Int) - (1 : Int)))) ∧ ((-((6 : Int) - (1 : Int))) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ (-((6 : Int) - (1 : Int)))) ∧ ((-((6 : Int) - (1 : Int))) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ (-((6 : Int) - (1 : Int)))) ∧ ((-1 : Int) ≥ (-((6 : Int) - (1 : Int)))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-((6 : Int) - (1 : Int)))) ∧ ((-((6 : Int) - (1 : Int))) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ (-((6 : Int) - (1 : Int)))) ∧ ((-2 : Int) ≥ (-((6 : Int) - (1 : Int)))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ (((((-3 : Int) - a) ≤ (-((6 : Int) - (1 : Int)))) ∧ ((-((6 : Int) - (1 : Int))) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ (-((6 : Int) - (1 : Int)))) ∧ ((-3 : Int) ≥ (-((6 : Int) - (1 : Int)))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (-((6 : Int) - (1 : Int)))) ∧ ((-((6 : Int) - (1 : Int))) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((2 : Int) ≤ (-((6 : Int) - (1 : Int)))) ∧ ((2 : Int) ≥ (-((6 : Int) - (1 : Int)))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (-((6 : Int) - (1 : Int)))) ∧ ((-((6 : Int) - (1 : Int))) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (-((6 : Int) - (1 : Int)))) ∧ ((3 : Int) ≥ (-((6 : Int) - (1 : Int)))) ∧ ((((4 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((-4 : Int) - b) ≤ (-((6 : Int) - (1 : Int)))) ∧ ((-((6 : Int) - (1 : Int))) ≤ ((-4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a))) ∨ (((-4 : Int) ≤ (-((6 : Int) - (1 : Int)))) ∧ ((-4 : Int) ≥ (-((6 : Int) - (1 : Int)))) ∧ ((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((-5 : Int) - a) ≤ (-((6 : Int) - (1 : Int)))) ∧ ((-((6 : Int) - (1 : Int))) ≤ ((-5 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b))) ∨ (((-5 : Int) ≤ (-((6 : Int) - (1 : Int)))) ∧ ((-5 : Int) ≥ (-((6 : Int) - (1 : Int)))) ∧ ((((3 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h3 : (run_x ≤ a))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n337_point (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ (((4 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n337_empty (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((fact_9fdb227ae99d_2824 a b) ∨ (fact_9fdb227ae99d_2825 a b) ∨ (fact_9fdb227ae99d_3205 a b) ∨ (fact_9fdb227ae99d_3853 a b) ∨ (fact_9fdb227ae99d_3071 a b) ∨ (fact_9fdb227ae99d_2906 a b) ∨ (fact_9fdb227ae99d_2907 a b) ∨ (fact_9fdb227ae99d_2908 a b) ∨ (fact_9fdb227ae99d_2826 a b) ∨ (fact_9fdb227ae99d_3072 a b) ∨ (fact_9fdb227ae99d_3124 a b) ∨ ((((4 : Int) ≥ ((-5 : Int) - a)) ∧ ((4 : Int) ≤ ((-5 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ (((-5 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-5 : Int)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + b))))))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n337_o0 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h6 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n337_o1 (a b jx jy : Int)
    (h0 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n337_o2 (a b jx jy : Int)
    (h0 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h1 : (b = (5 : Int)))
    (h2 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n337_o3 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h2 : (b = (5 : Int)))
    (h3 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : ((jx < ((2 : Int) + a)) ∨ (((2 : Int) + a) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h9 : (a = (b + (2 : Int))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n337_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n337_o5 (a b jx jy : Int)
    (h0 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h1 : (((jx + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h2 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n337_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h2 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (b = (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h6 : (((jx + b) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n337_o7 (a b jx jy : Int)
    (h0 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h1 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (¬ ((((4 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n338_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((3 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n338_run_short (a b : Int)
    (h0 : (¬ ((((3 : Int) + b) - (4 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n338_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n338_run_left (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3386 a b) ∨ (fact_9fdb227ae99d_3387 a b) ∨ (fact_9fdb227ae99d_4499 a b) ∨ (fact_9fdb227ae99d_5586 a b) ∨ (fact_9fdb227ae99d_3862 a b) ∨ (fact_9fdb227ae99d_3474 a b) ∨ (fact_9fdb227ae99d_3475 a b) ∨ (fact_9fdb227ae99d_3476 a b) ∨ (fact_9fdb227ae99d_3388 a b) ∨ (fact_9fdb227ae99d_3869 a b) ∨ (fact_9fdb227ae99d_4192 a b) ∨ ((((5 : Int) ≥ ((-5 : Int) - a)) ∧ ((5 : Int) ≤ ((-5 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((-5 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-5 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_3870 a b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n338_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3864 a b) ∨ (fact_9fdb227ae99d_3866 a b) ∨ (fact_9fdb227ae99d_5290 a b) ∨ (fact_9fdb227ae99d_5905 a b) ∨ (fact_9fdb227ae99d_4713 a b) ∨ (fact_9fdb227ae99d_4187 a b) ∨ (fact_9fdb227ae99d_4189 a b) ∨ (fact_9fdb227ae99d_4190 a b) ∨ (fact_9fdb227ae99d_3868 a b) ∨ (fact_9fdb227ae99d_4715 a b) ∨ ((((5 : Int) ≥ ((-4 : Int) - b)) ∧ ((5 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((-4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-4 : Int)) ∧ ((((3 : Int) + a) - a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((-5 : Int) - a)) ∧ ((5 : Int) ≤ ((-5 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((-5 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-5 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_4717 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n338_run_tall (a b : Int)
    (h0 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((3 : Int) + b)) ∧ ((fact_9fdb227ae99d_7819 a b) ∨ (fact_9fdb227ae99d_7866 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((3 : Int) + b)) ∧ (fact_9fdb227ae99d_7819 a b) ∧ (fact_9fdb227ae99d_7866 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((3 : Int) + b)) ∨ ((((3 : Int) + b) = ((4 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7819 a b) ∧ (fact_9fdb227ae99d_7866 a b) ∧ (((fact_9fdb227ae99d_3776 a b) ∨ (fact_9fdb227ae99d_3808 a b) ∨ (fact_9fdb227ae99d_5186 a b) ∨ (fact_9fdb227ae99d_5864 a b) ∨ (fact_9fdb227ae99d_4550 a b) ∨ (fact_9fdb227ae99d_3941 a b) ∨ (fact_9fdb227ae99d_3991 a b) ∨ (fact_9fdb227ae99d_4015 a b) ∨ (fact_9fdb227ae99d_3826 a b) ∨ (fact_9fdb227ae99d_4691 a b) ∨ (fact_9fdb227ae99d_4940 a b) ∨ (fact_9fdb227ae99d_4055 a b) ∨ (fact_9fdb227ae99d_4696 a b)) ∨ ((fact_9fdb227ae99d_4597 a b) ∨ (fact_9fdb227ae99d_4632 a b) ∨ (fact_9fdb227ae99d_5662 a b) ∨ (fact_9fdb227ae99d_6401 a b) ∨ (fact_9fdb227ae99d_5390 a b) ∨ (fact_9fdb227ae99d_4792 a b) ∨ (fact_9fdb227ae99d_4849 a b) ∨ (fact_9fdb227ae99d_4874 a b) ∨ (fact_9fdb227ae99d_4666 a b) ∨ (fact_9fdb227ae99d_5440 a b) ∨ (fact_9fdb227ae99d_5513 a b) ∨ (((((-5 : Int) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((-5 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((-5 : Int) ≤ ((5 : Int) + a)) ∧ ((-5 : Int) ≥ ((5 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_5444 a b)))) ∨ ((fact_9fdb227ae99d_7819 a b) ∧ (fact_9fdb227ae99d_7866 a b) ∧ ((fact_9fdb227ae99d_3776 a b) ∨ (fact_9fdb227ae99d_3808 a b) ∨ (fact_9fdb227ae99d_5186 a b) ∨ (fact_9fdb227ae99d_5864 a b) ∨ (fact_9fdb227ae99d_4550 a b) ∨ (fact_9fdb227ae99d_3941 a b) ∨ (fact_9fdb227ae99d_3991 a b) ∨ (fact_9fdb227ae99d_4015 a b) ∨ (fact_9fdb227ae99d_3826 a b) ∨ (fact_9fdb227ae99d_4691 a b) ∨ (fact_9fdb227ae99d_4940 a b) ∨ (fact_9fdb227ae99d_4055 a b) ∨ (fact_9fdb227ae99d_4696 a b)) ∧ ((fact_9fdb227ae99d_4597 a b) ∨ (fact_9fdb227ae99d_4632 a b) ∨ (fact_9fdb227ae99d_5662 a b) ∨ (fact_9fdb227ae99d_6401 a b) ∨ (fact_9fdb227ae99d_5390 a b) ∨ (fact_9fdb227ae99d_4792 a b) ∨ (fact_9fdb227ae99d_4849 a b) ∨ (fact_9fdb227ae99d_4874 a b) ∨ (fact_9fdb227ae99d_4666 a b) ∨ (fact_9fdb227ae99d_5440 a b) ∨ (fact_9fdb227ae99d_5513 a b) ∨ (((((-5 : Int) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((-5 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((-5 : Int) ≤ ((5 : Int) + a)) ∧ ((-5 : Int) ≥ ((5 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_5444 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n338_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (run_x ≤ ((3 : Int) + b)))
    (h3 : ((fact_9fdb227ae99d_2449 a b run_x) ∨ (fact_9fdb227ae99d_2450 a b run_x) ∨ (fact_9fdb227ae99d_3073 a b run_x) ∨ (fact_9fdb227ae99d_3572 a b run_x) ∨ (fact_9fdb227ae99d_2984 a b run_x) ∨ (fact_9fdb227ae99d_2539 a b run_x) ∨ (fact_9fdb227ae99d_2540 a b run_x) ∨ (fact_9fdb227ae99d_2541 a b run_x) ∨ (fact_9fdb227ae99d_2451 a b run_x) ∨ (fact_9fdb227ae99d_2985 a b run_x) ∨ (fact_9fdb227ae99d_3016 a b run_x) ∨ ((((5 : Int) ≥ ((-5 : Int) - a)) ∧ ((5 : Int) ≤ ((-5 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((-5 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-5 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_2986 a b run_x)))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((4 : Int) ≤ run_x))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n338_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((3 : Int) + b)))
    (h1 : ((4 : Int) ≤ run_x))
    (h2 : (¬ ((fact_9fdb227ae99d_3175 a b run_x) ∨ (fact_9fdb227ae99d_3185 a b run_x) ∨ (fact_9fdb227ae99d_3728 a b run_x) ∨ (fact_9fdb227ae99d_5193 a b run_x) ∨ (fact_9fdb227ae99d_3487 a b run_x) ∨ (fact_9fdb227ae99d_3219 a b run_x) ∨ (fact_9fdb227ae99d_3235 a b run_x) ∨ (fact_9fdb227ae99d_3241 a b run_x) ∨ (fact_9fdb227ae99d_3194 a b run_x) ∨ (fact_9fdb227ae99d_3557 a b run_x) ∨ (fact_9fdb227ae99d_3580 a b run_x) ∨ (((((-5 : Int) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((-5 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((-5 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((-5 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_3561 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n339_run_four (a b : Int)
    (h0 : (¬ ((-5 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n339_run_short (a b : Int)
    (h0 : (¬ (((-5 : Int) - ((-2 : Int) + ((-1 : Int) * a))) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n339_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n339_run_left (a b : Int)
    (h0 : (¬ ((((((0 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((0 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + b + a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((1 : Int) + b + a)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ ((((2 : Int) + a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((2 : Int) + a)) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)))) ∨ (((((-3 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ (((2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≥ ((4 : Int) + a)) ∧ ((4 : Int) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((-4 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((-4 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-4 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((((-5 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((-5 : Int) + ((-1 : Int) * b)) + b)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ ((((-5 : Int) + ((-1 : Int) * b)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-5 : Int) + ((-1 : Int) * b))) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n339_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((((0 : Int) - (0 : Int)) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ ((-5 : Int) + (1 : Int))) ∧ ((0 : Int) ≥ ((-5 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ ((-5 : Int) + (1 : Int))) ∧ ((1 : Int) ≥ ((-5 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + b + a) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ ((1 : Int) + b + a)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ ((((2 : Int) + a) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ ((2 : Int) + a)) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ ((-5 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-5 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ ((-5 : Int) + (1 : Int))) ∧ ((-2 : Int) ≥ ((-5 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)))) ∨ (((((-3 : Int) - a) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ ((-5 : Int) + (1 : Int))) ∧ ((-3 : Int) ≥ ((-5 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ (((2 : Int) ≤ ((-5 : Int) + (1 : Int))) ∧ ((2 : Int) ≥ ((-5 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≥ ((4 : Int) + a)) ∧ ((4 : Int) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((-5 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((-5 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((-4 : Int) - b) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((-4 : Int) ≤ ((-5 : Int) + (1 : Int))) ∧ ((-4 : Int) ≥ ((-5 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((((-5 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ (((-5 : Int) + ((-1 : Int) * b)) + b)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ ((((-5 : Int) + ((-1 : Int) * b)) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ ((-5 : Int) + ((-1 : Int) * b))) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n339_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((((-5 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7928 a b) ∨ (fact_9fdb227ae99d_7771 a b))) ∨ (((-5 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + (2 : Int))) ∧ (fact_9fdb227ae99d_7928 a b) ∧ (fact_9fdb227ae99d_7771 a b)) ∨ ((-5 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + (4 : Int))) ∨ (((-5 : Int) = (((-2 : Int) + ((-1 : Int) * a)) + (1 : Int))) ∧ (fact_9fdb227ae99d_7928 a b) ∧ (fact_9fdb227ae99d_7771 a b) ∧ (((((((0 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((4 : Int) + a)) ∧ ((0 : Int) ≥ ((4 : Int) + a))) ∨ (((0 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((0 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ ((4 : Int) + a)) ∧ ((1 : Int) ≥ ((4 : Int) + a))) ∨ (((1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) + a)) ∧ ((0 : Int) ≥ ((4 : Int) + a))) ∨ ((((1 : Int) + b + a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + a)) ∧ ((1 : Int) ≥ ((4 : Int) + a))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ ((((2 : Int) + a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) + a)) ∧ ((0 : Int) ≥ ((4 : Int) + a))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + a)) ∧ ((1 : Int) ≥ ((4 : Int) + a))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (((((-3 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((-3 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) + a))) ∨ (((2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((-4 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((-4 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-4 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((((-5 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((-5 : Int) + ((-1 : Int) * b)) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) + a))) ∨ ((((-5 : Int) + ((-1 : Int) * b)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-5 : Int) + ((-1 : Int) * b))) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + a))))) ∨ ((fact_9fdb227ae99d_4081 a b) ∨ (fact_9fdb227ae99d_4109 a b) ∨ (fact_9fdb227ae99d_5315 a b) ∨ (fact_9fdb227ae99d_5930 a b) ∨ (fact_9fdb227ae99d_4744 a b) ∨ (fact_9fdb227ae99d_4242 a b) ∨ (fact_9fdb227ae99d_4274 a b) ∨ (((((-3 : Int) - a) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((-3 : Int) ≤ ((-5 : Int) + (1 : Int))) ∧ ((-3 : Int) ≥ ((-5 : Int) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_4123 a b) ∨ (fact_9fdb227ae99d_5014 a b) ∨ (fact_9fdb227ae99d_5098 a b) ∨ (fact_9fdb227ae99d_6172 a b)))) ∨ ((fact_9fdb227ae99d_7928 a b) ∧ (fact_9fdb227ae99d_7771 a b) ∧ ((((((0 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((4 : Int) + a)) ∧ ((0 : Int) ≥ ((4 : Int) + a))) ∨ (((0 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((0 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ ((4 : Int) + a)) ∧ ((1 : Int) ≥ ((4 : Int) + a))) ∨ (((1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) + a)) ∧ ((0 : Int) ≥ ((4 : Int) + a))) ∨ ((((1 : Int) + b + a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + a)) ∧ ((1 : Int) ≥ ((4 : Int) + a))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ ((((2 : Int) + a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) + a)) ∧ ((0 : Int) ≥ ((4 : Int) + a))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + a)) ∧ ((1 : Int) ≥ ((4 : Int) + a))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (((((-3 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((-3 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) + a))) ∨ (((2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (((((-4 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((-4 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-4 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((((-5 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((-5 : Int) + ((-1 : Int) * b)) + b)) ∧ ((3 : Int) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) + a))) ∨ ((((-5 : Int) + ((-1 : Int) * b)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-5 : Int) + ((-1 : Int) * b))) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + a))))) ∧ ((fact_9fdb227ae99d_4081 a b) ∨ (fact_9fdb227ae99d_4109 a b) ∨ (fact_9fdb227ae99d_5315 a b) ∨ (fact_9fdb227ae99d_5930 a b) ∨ (fact_9fdb227ae99d_4744 a b) ∨ (fact_9fdb227ae99d_4242 a b) ∨ (fact_9fdb227ae99d_4274 a b) ∨ (((((-3 : Int) - a) ≤ ((-5 : Int) + (1 : Int))) ∧ (((-5 : Int) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((-3 : Int) ≤ ((-5 : Int) + (1 : Int))) ∧ ((-3 : Int) ≥ ((-5 : Int) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_4123 a b) ∨ (fact_9fdb227ae99d_5014 a b) ∨ (fact_9fdb227ae99d_5098 a b) ∨ (fact_9fdb227ae99d_6172 a b))))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n339_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((-5 : Int) ≥ run_x))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (((-2 : Int) + ((-1 : Int) * a)) ≤ run_x))
    (h7 : ((fact_9fdb227ae99d_2367 a b run_x) ∨ (fact_9fdb227ae99d_2384 a b run_x) ∨ (fact_9fdb227ae99d_3040 a b run_x) ∨ (fact_9fdb227ae99d_3481 a b run_x) ∨ (fact_9fdb227ae99d_2928 a b run_x) ∨ (fact_9fdb227ae99d_2466 a b run_x) ∨ (fact_9fdb227ae99d_2477 a b run_x) ∨ (fact_9fdb227ae99d_2483 a b run_x) ∨ (fact_9fdb227ae99d_2398 a b run_x) ∨ (fact_9fdb227ae99d_2948 a b run_x) ∨ (((((-4 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-4 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((-4 : Int) ≤ run_x) ∧ ((-4 : Int) ≥ run_x) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((((-5 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((-5 : Int) + ((-1 : Int) * b)) + b)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ ((((-5 : Int) + ((-1 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((-5 : Int) + ((-1 : Int) * b))) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a))))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n339_run_floor (a b run_x : Int)
    (h0 : (((-2 : Int) + ((-1 : Int) * a)) ≤ run_x))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (¬ ((fact_9fdb227ae99d_3179 a b run_x) ∨ (fact_9fdb227ae99d_3189 a b run_x) ∨ (fact_9fdb227ae99d_3731 a b run_x) ∨ (fact_9fdb227ae99d_5196 a b run_x) ∨ (fact_9fdb227ae99d_3490 a b run_x) ∨ (fact_9fdb227ae99d_3222 a b run_x) ∨ (fact_9fdb227ae99d_3237 a b run_x) ∨ (fact_9fdb227ae99d_3244 a b run_x) ∨ (fact_9fdb227ae99d_3197 a b run_x) ∨ (fact_9fdb227ae99d_3559 a b run_x) ∨ (((((-4 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((-4 : Int) ≤ run_x) ∧ ((-4 : Int) ≥ run_x) ∧ ((((3 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((((-5 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((-5 : Int) + ((-1 : Int) * b)) + b)) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ ((((-5 : Int) + ((-1 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((-5 : Int) + ((-1 : Int) * b))) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a)))))))
    (h3 : ((-5 : Int) ≥ run_x))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n340_point (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ (((4 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n340_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_2824 a b) ∨ (fact_9fdb227ae99d_2825 a b) ∨ (fact_9fdb227ae99d_3205 a b) ∨ (fact_9fdb227ae99d_3853 a b) ∨ (fact_9fdb227ae99d_3071 a b) ∨ (fact_9fdb227ae99d_2906 a b) ∨ (fact_9fdb227ae99d_2907 a b) ∨ (fact_9fdb227ae99d_2908 a b) ∨ (fact_9fdb227ae99d_2826 a b) ∨ (fact_9fdb227ae99d_3072 a b) ∨ ((((4 : Int) ≥ ((-4 : Int) - a)) ∧ ((4 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ (((-4 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-4 : Int)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + b))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n340_o0 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n340_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (((jx + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) + a)) ∨ (((4 : Int) + a) < jy)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n340_o2 (a b jx jy : Int)
    (h0 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n340_o3 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((jx < ((2 : Int) + a)) ∨ (((2 : Int) + a) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h6 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n340_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h3 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b = (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n340_o5 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h6 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : (((jx + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h8 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n340_o6 (a b jx jy : Int)
    (h0 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + a) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - (0 : Int)))))
    (h1 : (b = (5 : Int)))
    (h2 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n340_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (¬ ((((4 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h3 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h4 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n341_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((3 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n341_run_short (a b : Int)
    (h0 : (¬ ((((3 : Int) + b) - (4 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n341_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n341_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3386 a b) ∨ (fact_9fdb227ae99d_3387 a b) ∨ (fact_9fdb227ae99d_4499 a b) ∨ (fact_9fdb227ae99d_5586 a b) ∨ (fact_9fdb227ae99d_3862 a b) ∨ (fact_9fdb227ae99d_3474 a b) ∨ (fact_9fdb227ae99d_3475 a b) ∨ (fact_9fdb227ae99d_3476 a b) ∨ (fact_9fdb227ae99d_3388 a b) ∨ (fact_9fdb227ae99d_3869 a b) ∨ ((((5 : Int) ≥ ((-4 : Int) - a)) ∧ ((5 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((-4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_3870 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n341_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3864 a b) ∨ (fact_9fdb227ae99d_3866 a b) ∨ (fact_9fdb227ae99d_5290 a b) ∨ (fact_9fdb227ae99d_5905 a b) ∨ (fact_9fdb227ae99d_4713 a b) ∨ (fact_9fdb227ae99d_4187 a b) ∨ (fact_9fdb227ae99d_4189 a b) ∨ (fact_9fdb227ae99d_4190 a b) ∨ (fact_9fdb227ae99d_3868 a b) ∨ (fact_9fdb227ae99d_4715 a b) ∨ ((((5 : Int) ≥ ((-4 : Int) - a)) ∧ ((5 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((-4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_4717 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n341_run_tall (a b : Int)
    (h0 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((3 : Int) + b)) ∧ ((fact_9fdb227ae99d_7751 a b) ∨ (fact_9fdb227ae99d_7792 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((3 : Int) + b)) ∧ (fact_9fdb227ae99d_7751 a b) ∧ (fact_9fdb227ae99d_7792 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((3 : Int) + b)) ∨ ((((3 : Int) + b) = ((4 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7751 a b) ∧ (fact_9fdb227ae99d_7792 a b) ∧ (((fact_9fdb227ae99d_3776 a b) ∨ (fact_9fdb227ae99d_3808 a b) ∨ (fact_9fdb227ae99d_5186 a b) ∨ (fact_9fdb227ae99d_5864 a b) ∨ (fact_9fdb227ae99d_4550 a b) ∨ (fact_9fdb227ae99d_3941 a b) ∨ (fact_9fdb227ae99d_3991 a b) ∨ (fact_9fdb227ae99d_4015 a b) ∨ (fact_9fdb227ae99d_3826 a b) ∨ (fact_9fdb227ae99d_4691 a b) ∨ (fact_9fdb227ae99d_4048 a b) ∨ (fact_9fdb227ae99d_4696 a b)) ∨ ((fact_9fdb227ae99d_4597 a b) ∨ (fact_9fdb227ae99d_4632 a b) ∨ (fact_9fdb227ae99d_5662 a b) ∨ (fact_9fdb227ae99d_6401 a b) ∨ (fact_9fdb227ae99d_5390 a b) ∨ (fact_9fdb227ae99d_4792 a b) ∨ (fact_9fdb227ae99d_4849 a b) ∨ (fact_9fdb227ae99d_4874 a b) ∨ (fact_9fdb227ae99d_4666 a b) ∨ (fact_9fdb227ae99d_5440 a b) ∨ (((((-4 : Int) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((-4 : Int) ≤ ((5 : Int) + a)) ∧ ((-4 : Int) ≥ ((5 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_5444 a b)))) ∨ ((fact_9fdb227ae99d_7751 a b) ∧ (fact_9fdb227ae99d_7792 a b) ∧ ((fact_9fdb227ae99d_3776 a b) ∨ (fact_9fdb227ae99d_3808 a b) ∨ (fact_9fdb227ae99d_5186 a b) ∨ (fact_9fdb227ae99d_5864 a b) ∨ (fact_9fdb227ae99d_4550 a b) ∨ (fact_9fdb227ae99d_3941 a b) ∨ (fact_9fdb227ae99d_3991 a b) ∨ (fact_9fdb227ae99d_4015 a b) ∨ (fact_9fdb227ae99d_3826 a b) ∨ (fact_9fdb227ae99d_4691 a b) ∨ (fact_9fdb227ae99d_4048 a b) ∨ (fact_9fdb227ae99d_4696 a b)) ∧ ((fact_9fdb227ae99d_4597 a b) ∨ (fact_9fdb227ae99d_4632 a b) ∨ (fact_9fdb227ae99d_5662 a b) ∨ (fact_9fdb227ae99d_6401 a b) ∨ (fact_9fdb227ae99d_5390 a b) ∨ (fact_9fdb227ae99d_4792 a b) ∨ (fact_9fdb227ae99d_4849 a b) ∨ (fact_9fdb227ae99d_4874 a b) ∨ (fact_9fdb227ae99d_4666 a b) ∨ (fact_9fdb227ae99d_5440 a b) ∨ (((((-4 : Int) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((-4 : Int) ≤ ((5 : Int) + a)) ∧ ((-4 : Int) ≥ ((5 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_5444 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n341_run_empty (a b run_x : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (run_x ≤ ((3 : Int) + b)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((4 : Int) ≤ run_x))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((fact_9fdb227ae99d_2449 a b run_x) ∨ (fact_9fdb227ae99d_2450 a b run_x) ∨ (fact_9fdb227ae99d_3073 a b run_x) ∨ (fact_9fdb227ae99d_3572 a b run_x) ∨ (fact_9fdb227ae99d_2984 a b run_x) ∨ (fact_9fdb227ae99d_2539 a b run_x) ∨ (fact_9fdb227ae99d_2540 a b run_x) ∨ (fact_9fdb227ae99d_2541 a b run_x) ∨ (fact_9fdb227ae99d_2451 a b run_x) ∨ (fact_9fdb227ae99d_2985 a b run_x) ∨ ((((5 : Int) ≥ ((-4 : Int) - a)) ∧ ((5 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((-4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_2986 a b run_x)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n341_run_floor (a b run_x : Int)
    (h0 : ((4 : Int) ≤ run_x))
    (h1 : (run_x ≤ ((3 : Int) + b)))
    (h2 : (¬ ((fact_9fdb227ae99d_3175 a b run_x) ∨ (fact_9fdb227ae99d_3185 a b run_x) ∨ (fact_9fdb227ae99d_3728 a b run_x) ∨ (fact_9fdb227ae99d_5193 a b run_x) ∨ (fact_9fdb227ae99d_3487 a b run_x) ∨ (fact_9fdb227ae99d_3219 a b run_x) ∨ (fact_9fdb227ae99d_3235 a b run_x) ∨ (fact_9fdb227ae99d_3241 a b run_x) ∨ (fact_9fdb227ae99d_3194 a b run_x) ∨ (fact_9fdb227ae99d_3557 a b run_x) ∨ (((((-4 : Int) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((-4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((-4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ (fact_9fdb227ae99d_3561 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n342_run_four (a b : Int)
    (h0 : (¬ ((-4 : Int) ≥ ((-3 : Int) + ((-1 : Int) * b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n342_run_short (a b : Int)
    (h0 : (¬ (((-4 : Int) - ((-3 : Int) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n342_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n342_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5687 a b) ∨ (fact_9fdb227ae99d_5700 a b) ∨ (fact_9fdb227ae99d_6368 a b) ∨ (fact_9fdb227ae99d_6964 a b) ∨ (fact_9fdb227ae99d_5994 a b) ∨ (fact_9fdb227ae99d_5762 a b) ∨ (fact_9fdb227ae99d_5771 a b) ∨ (((((-3 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_5707 a b) ∨ (fact_9fdb227ae99d_6118 a b) ∨ (fact_9fdb227ae99d_6986 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n342_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3416 a b) ∨ (fact_9fdb227ae99d_3434 a b) ∨ (fact_9fdb227ae99d_4509 a b) ∨ (fact_9fdb227ae99d_5593 a b) ∨ (fact_9fdb227ae99d_3881 a b) ∨ (fact_9fdb227ae99d_3509 a b) ∨ (fact_9fdb227ae99d_3526 a b) ∨ (((((-3 : Int) - a) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-3 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3448 a b) ∨ (fact_9fdb227ae99d_4143 a b) ∨ (fact_9fdb227ae99d_5729 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n342_run_tall (a b : Int)
    (h0 : (¬ ((((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7871 a b) ∨ (fact_9fdb227ae99d_7652 a b))) ∨ (((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (2 : Int))) ∧ (fact_9fdb227ae99d_7871 a b) ∧ (fact_9fdb227ae99d_7652 a b)) ∨ ((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (4 : Int))) ∨ (((-4 : Int) = (((-3 : Int) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_9fdb227ae99d_7871 a b) ∧ (fact_9fdb227ae99d_7652 a b) ∧ (((fact_9fdb227ae99d_6035 a b) ∨ (fact_9fdb227ae99d_6073 a b) ∨ (fact_9fdb227ae99d_6835 a b) ∨ (fact_9fdb227ae99d_7047 a b) ∨ (fact_9fdb227ae99d_6601 a b) ∨ (fact_9fdb227ae99d_6245 a b) ∨ (fact_9fdb227ae99d_6279 a b) ∨ (fact_9fdb227ae99d_6295 a b) ∨ (fact_9fdb227ae99d_6097 a b) ∨ (fact_9fdb227ae99d_6647 a b) ∨ (fact_9fdb227ae99d_7111 a b)) ∨ ((fact_9fdb227ae99d_4075 a b) ∨ (fact_9fdb227ae99d_4103 a b) ∨ (fact_9fdb227ae99d_5309 a b) ∨ (fact_9fdb227ae99d_5924 a b) ∨ (fact_9fdb227ae99d_4738 a b) ∨ (fact_9fdb227ae99d_4236 a b) ∨ (fact_9fdb227ae99d_4266 a b) ∨ (fact_9fdb227ae99d_4286 a b) ∨ (fact_9fdb227ae99d_4117 a b) ∨ (fact_9fdb227ae99d_5010 a b) ∨ (fact_9fdb227ae99d_6168 a b)))) ∨ ((fact_9fdb227ae99d_7871 a b) ∧ (fact_9fdb227ae99d_7652 a b) ∧ ((fact_9fdb227ae99d_6035 a b) ∨ (fact_9fdb227ae99d_6073 a b) ∨ (fact_9fdb227ae99d_6835 a b) ∨ (fact_9fdb227ae99d_7047 a b) ∨ (fact_9fdb227ae99d_6601 a b) ∨ (fact_9fdb227ae99d_6245 a b) ∨ (fact_9fdb227ae99d_6279 a b) ∨ (fact_9fdb227ae99d_6295 a b) ∨ (fact_9fdb227ae99d_6097 a b) ∨ (fact_9fdb227ae99d_6647 a b) ∨ (fact_9fdb227ae99d_7111 a b)) ∧ ((fact_9fdb227ae99d_4075 a b) ∨ (fact_9fdb227ae99d_4103 a b) ∨ (fact_9fdb227ae99d_5309 a b) ∨ (fact_9fdb227ae99d_5924 a b) ∨ (fact_9fdb227ae99d_4738 a b) ∨ (fact_9fdb227ae99d_4236 a b) ∨ (fact_9fdb227ae99d_4266 a b) ∨ (fact_9fdb227ae99d_4286 a b) ∨ (fact_9fdb227ae99d_4117 a b) ∨ (fact_9fdb227ae99d_5010 a b) ∨ (fact_9fdb227ae99d_6168 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n342_run_empty (a b run_x : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (((-3 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h2 : ((-4 : Int) ≥ run_x))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((fact_9fdb227ae99d_2367 a b run_x) ∨ (fact_9fdb227ae99d_2384 a b run_x) ∨ (fact_9fdb227ae99d_3040 a b run_x) ∨ (fact_9fdb227ae99d_3481 a b run_x) ∨ (fact_9fdb227ae99d_2928 a b run_x) ∨ (fact_9fdb227ae99d_2466 a b run_x) ∨ (fact_9fdb227ae99d_2477 a b run_x) ∨ (fact_9fdb227ae99d_2483 a b run_x) ∨ (fact_9fdb227ae99d_2398 a b run_x) ∨ (fact_9fdb227ae99d_2948 a b run_x) ∨ (fact_9fdb227ae99d_3616 a b run_x)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n342_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3179 a b run_x) ∨ (fact_9fdb227ae99d_3189 a b run_x) ∨ (fact_9fdb227ae99d_3731 a b run_x) ∨ (fact_9fdb227ae99d_5196 a b run_x) ∨ (fact_9fdb227ae99d_3490 a b run_x) ∨ (fact_9fdb227ae99d_3222 a b run_x) ∨ (fact_9fdb227ae99d_3237 a b run_x) ∨ (fact_9fdb227ae99d_3244 a b run_x) ∨ (fact_9fdb227ae99d_3197 a b run_x) ∨ (fact_9fdb227ae99d_3559 a b run_x) ∨ (fact_9fdb227ae99d_5363 a b run_x))))
    (h1 : ((-4 : Int) ≥ run_x))
    (h2 : (((-3 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n343_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≤ ((2 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n343_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + b) - (3 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n343_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n343_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3365 a b) ∨ (fact_9fdb227ae99d_3372 a b) ∨ (fact_9fdb227ae99d_4407 a b) ∨ (fact_9fdb227ae99d_5546 a b) ∨ (fact_9fdb227ae99d_3735 a b) ∨ (fact_9fdb227ae99d_3397 a b) ∨ (fact_9fdb227ae99d_3407 a b) ∨ (((((-3 : Int) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3376 a b) ∨ (fact_9fdb227ae99d_3740 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n343_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3752 a b) ∨ (fact_9fdb227ae99d_3784 a b) ∨ (fact_9fdb227ae99d_5162 a b) ∨ (fact_9fdb227ae99d_5840 a b) ∨ (fact_9fdb227ae99d_4535 a b) ∨ (fact_9fdb227ae99d_3921 a b) ∨ (fact_9fdb227ae99d_3968 a b) ∨ (((((-3 : Int) - a) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((-3 : Int) ≥ (((2 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3812 a b) ∨ (fact_9fdb227ae99d_4558 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n343_run_tall (a b : Int)
    (h0 : (¬ (((((3 : Int) + (3 : Int)) ≤ ((2 : Int) + b)) ∧ ((fact_9fdb227ae99d_7470 a b) ∨ (fact_9fdb227ae99d_7578 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ ((2 : Int) + b)) ∧ (fact_9fdb227ae99d_7470 a b) ∧ (fact_9fdb227ae99d_7578 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ ((2 : Int) + b)) ∨ ((((2 : Int) + b) = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7470 a b) ∧ (fact_9fdb227ae99d_7578 a b) ∧ (((fact_9fdb227ae99d_3761 a b) ∨ (fact_9fdb227ae99d_3793 a b) ∨ (fact_9fdb227ae99d_5171 a b) ∨ (fact_9fdb227ae99d_5849 a b) ∨ (fact_9fdb227ae99d_4542 a b) ∨ (fact_9fdb227ae99d_3931 a b) ∨ (fact_9fdb227ae99d_3979 a b) ∨ (fact_9fdb227ae99d_4005 a b) ∨ (fact_9fdb227ae99d_3814 a b) ∨ (fact_9fdb227ae99d_4561 a b)) ∨ ((fact_9fdb227ae99d_4576 a b) ∨ (fact_9fdb227ae99d_4611 a b) ∨ (fact_9fdb227ae99d_5642 a b) ∨ (fact_9fdb227ae99d_6383 a b) ∨ (fact_9fdb227ae99d_5379 a b) ∨ (fact_9fdb227ae99d_4784 a b) ∨ (fact_9fdb227ae99d_4828 a b) ∨ (fact_9fdb227ae99d_4866 a b) ∨ (fact_9fdb227ae99d_4641 a b) ∨ (fact_9fdb227ae99d_5399 a b)))) ∨ ((fact_9fdb227ae99d_7470 a b) ∧ (fact_9fdb227ae99d_7578 a b) ∧ ((fact_9fdb227ae99d_3761 a b) ∨ (fact_9fdb227ae99d_3793 a b) ∨ (fact_9fdb227ae99d_5171 a b) ∨ (fact_9fdb227ae99d_5849 a b) ∨ (fact_9fdb227ae99d_4542 a b) ∨ (fact_9fdb227ae99d_3931 a b) ∨ (fact_9fdb227ae99d_3979 a b) ∨ (fact_9fdb227ae99d_4005 a b) ∨ (fact_9fdb227ae99d_3814 a b) ∨ (fact_9fdb227ae99d_4561 a b)) ∧ ((fact_9fdb227ae99d_4576 a b) ∨ (fact_9fdb227ae99d_4611 a b) ∨ (fact_9fdb227ae99d_5642 a b) ∨ (fact_9fdb227ae99d_6383 a b) ∨ (fact_9fdb227ae99d_5379 a b) ∨ (fact_9fdb227ae99d_4784 a b) ∨ (fact_9fdb227ae99d_4828 a b) ∨ (fact_9fdb227ae99d_4866 a b) ∨ (fact_9fdb227ae99d_4641 a b) ∨ (fact_9fdb227ae99d_5399 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n343_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((fact_9fdb227ae99d_2368 a b run_x) ∨ (fact_9fdb227ae99d_2385 a b run_x) ∨ (fact_9fdb227ae99d_3041 a b run_x) ∨ (fact_9fdb227ae99d_3482 a b run_x) ∨ (fact_9fdb227ae99d_2929 a b run_x) ∨ (fact_9fdb227ae99d_2467 a b run_x) ∨ (fact_9fdb227ae99d_2478 a b run_x) ∨ (fact_9fdb227ae99d_2484 a b run_x) ∨ (fact_9fdb227ae99d_2399 a b run_x) ∨ (fact_9fdb227ae99d_2932 a b run_x)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (run_x ≤ ((2 : Int) + b)))
    (h4 : (b = (5 : Int)))
    (h5 : ((3 : Int) ≤ run_x))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n343_run_floor (a b run_x : Int)
    (h0 : ((3 : Int) ≤ run_x))
    (h1 : (run_x ≤ ((2 : Int) + b)))
    (h2 : (¬ ((fact_9fdb227ae99d_3180 a b run_x) ∨ (fact_9fdb227ae99d_3190 a b run_x) ∨ (fact_9fdb227ae99d_3732 a b run_x) ∨ (fact_9fdb227ae99d_5197 a b run_x) ∨ (fact_9fdb227ae99d_3491 a b run_x) ∨ (fact_9fdb227ae99d_3223 a b run_x) ∨ (fact_9fdb227ae99d_3238 a b run_x) ∨ (fact_9fdb227ae99d_3245 a b run_x) ∨ (fact_9fdb227ae99d_3198 a b run_x) ∨ (fact_9fdb227ae99d_3494 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n344_point (a b : Int)
    (h0 : (¬ (((-1 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ (((3 : Int) + b) ≥ (0 : Int)) ∧ ((-1 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ (((3 : Int) + b) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n344_empty (a b : Int)
    (h0 : (((((-1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-1 : Int) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((3 : Int) + b)) ∧ ((0 : Int) ≥ ((3 : Int) + b))) ∨ (((0 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((0 : Int) + a)))) ∨ ((((-1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((-1 : Int) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ ((3 : Int) + b)) ∧ ((1 : Int) ≥ ((3 : Int) + b))) ∨ (((1 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((1 : Int) + a)))) ∨ ((((-1 : Int) ≥ (((1 : Int) + b + a) - a)) ∧ ((-1 : Int) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) + b)) ∧ ((0 : Int) ≥ ((3 : Int) + b))) ∨ (((-1 : Int) ≥ ((1 : Int) + b + a)) ∧ ((-1 : Int) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((-1 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - b)) ∧ ((-1 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + b)) ∧ ((1 : Int) ≥ ((3 : Int) + b))) ∨ (((-1 : Int) ≥ ((2 : Int) + ((2 : Int) * b))) ∧ ((-1 : Int) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((1 : Int) + a)))) ∨ ((((-1 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((-1 : Int) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + b)) ∧ ((2 : Int) ≥ ((3 : Int) + b))) ∨ (((-1 : Int) ≥ ((2 : Int) + a)) ∧ ((-1 : Int) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((2 : Int) + b)))) ∨ ((((-1 : Int) ≥ ((-1 : Int) - b)) ∧ ((-1 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) + b)) ∧ ((0 : Int) ≥ ((3 : Int) + b))) ∨ (((-1 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((0 : Int) + a)))) ∨ ((((-1 : Int) ≥ ((-2 : Int) - b)) ∧ ((-1 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + b)) ∧ ((1 : Int) ≥ ((3 : Int) + b))) ∨ (((-2 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-2 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((1 : Int) + a)))) ∨ ((((-1 : Int) ≥ ((-3 : Int) - a)) ∧ ((-1 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + b)) ∧ ((2 : Int) ≥ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((2 : Int) + b)))) ∨ ((((-1 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((-1 : Int) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≥ ((3 : Int) + b))) ∨ (((2 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (2 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((3 : Int) + a)))) ∨ ((((-1 : Int) ≥ ((3 : Int) - b)) ∧ ((-1 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (3 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int)))))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + a))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n344_o0 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ (jy ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (jy + b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h4 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h5 : (b = (5 : Int)))
    (h6 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((jx < ((3 : Int) - b)) ∨ (((3 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - (0 : Int)))))
    (h9 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n344_o1 (a b jx jy : Int)
    (h0 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h1 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - a))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ (jy ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - a) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (jy + (0 : Int))))))
    (h9 : ((jx < ((3 : Int) - b)) ∨ (((3 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n344_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : ((jx < ((3 : Int) - b)) ∨ (((3 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - b))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - b) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (jy + (0 : Int))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - b))))
    (h7 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h8 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - b))))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n344_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((jx < ((3 : Int) - b)) ∨ (((3 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h8 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h9 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h10 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (jy + a)))))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n344_o4 (a b jx jy : Int)
    (h0 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h1 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - a))))
    (h2 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : ((jx < ((3 : Int) - b)) ∨ (((3 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h7 : (fact_9fdb227ae99d_2922 a b jy))
    (h8 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - a) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (jy + (0 : Int))))))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (b = (5 : Int)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n344_o5 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (jy + b)))))
    (h1 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((3 : Int) - b)) ∨ (((3 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - (0 : Int)))))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h9 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h10 : (b = (5 : Int)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n344_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h2 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (b = (5 : Int)))
    (h4 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ (jy ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (jy + a)))))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n344_o7 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ (jy ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - b) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (jy + (0 : Int))))))
    (h1 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - b))))
    (h2 : (b = (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jx < ((3 : Int) - b)) ∨ (((3 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - b))))
    (h8 : ((jy - b) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n345_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((4 : Int) ≤ ((1 : Int) + a))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n345_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((1 : Int) + a) - (4 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n345_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n345_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3368 a b) ∨ (fact_9fdb227ae99d_3375 a b) ∨ (fact_9fdb227ae99d_4410 a b) ∨ (fact_9fdb227ae99d_5549 a b) ∨ (fact_9fdb227ae99d_3737 a b) ∨ (fact_9fdb227ae99d_3399 a b) ∨ (fact_9fdb227ae99d_3409 a b) ∨ (((((-3 : Int) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3377 a b) ∨ (fact_9fdb227ae99d_3378 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n345_run_right (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3749 a b) ∨ (fact_9fdb227ae99d_3781 a b) ∨ (fact_9fdb227ae99d_5159 a b) ∨ (fact_9fdb227ae99d_5837 a b) ∨ (fact_9fdb227ae99d_4532 a b) ∨ (fact_9fdb227ae99d_3918 a b) ∨ (fact_9fdb227ae99d_3965 a b) ∨ (((((-3 : Int) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((-3 : Int) ≥ (((1 : Int) + a) + (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3811 a b) ∨ (fact_9fdb227ae99d_3829 a b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n345_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_9fdb227ae99d_7464 a b) ∨ (fact_9fdb227ae99d_7570 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ (fact_9fdb227ae99d_7464 a b) ∧ (fact_9fdb227ae99d_7570 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = ((4 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7464 a b) ∧ (fact_9fdb227ae99d_7570 a b) ∧ (((fact_9fdb227ae99d_3773 a b) ∨ (fact_9fdb227ae99d_3805 a b) ∨ (fact_9fdb227ae99d_5183 a b) ∨ (fact_9fdb227ae99d_5861 a b) ∨ (fact_9fdb227ae99d_4548 a b) ∨ (fact_9fdb227ae99d_3938 a b) ∨ (fact_9fdb227ae99d_3987 a b) ∨ (fact_9fdb227ae99d_4013 a b) ∨ (fact_9fdb227ae99d_3823 a b) ∨ (fact_9fdb227ae99d_3836 a b)) ∨ ((fact_9fdb227ae99d_4569 a b) ∨ (fact_9fdb227ae99d_4604 a b) ∨ (fact_9fdb227ae99d_5636 a b) ∨ (fact_9fdb227ae99d_6377 a b) ∨ (fact_9fdb227ae99d_5373 a b) ∨ (fact_9fdb227ae99d_4776 a b) ∨ (fact_9fdb227ae99d_4818 a b) ∨ (fact_9fdb227ae99d_4856 a b) ∨ (fact_9fdb227ae99d_4637 a b) ∨ (fact_9fdb227ae99d_4677 a b)))) ∨ ((fact_9fdb227ae99d_7464 a b) ∧ (fact_9fdb227ae99d_7570 a b) ∧ ((fact_9fdb227ae99d_3773 a b) ∨ (fact_9fdb227ae99d_3805 a b) ∨ (fact_9fdb227ae99d_5183 a b) ∨ (fact_9fdb227ae99d_5861 a b) ∨ (fact_9fdb227ae99d_4548 a b) ∨ (fact_9fdb227ae99d_3938 a b) ∨ (fact_9fdb227ae99d_3987 a b) ∨ (fact_9fdb227ae99d_4013 a b) ∨ (fact_9fdb227ae99d_3823 a b) ∨ (fact_9fdb227ae99d_3836 a b)) ∧ ((fact_9fdb227ae99d_4569 a b) ∨ (fact_9fdb227ae99d_4604 a b) ∨ (fact_9fdb227ae99d_5636 a b) ∨ (fact_9fdb227ae99d_6377 a b) ∨ (fact_9fdb227ae99d_5373 a b) ∨ (fact_9fdb227ae99d_4776 a b) ∨ (fact_9fdb227ae99d_4818 a b) ∨ (fact_9fdb227ae99d_4856 a b) ∨ (fact_9fdb227ae99d_4637 a b) ∨ (fact_9fdb227ae99d_4677 a b))))))
    (h3 : (a > b))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n345_run_empty (a b run_x : Int)
    (h0 : ((4 : Int) ≤ run_x))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (b = (5 : Int)))
    (h3 : (run_x ≤ ((1 : Int) + a)))
    (h4 : ((fact_9fdb227ae99d_2368 a b run_x) ∨ (fact_9fdb227ae99d_2385 a b run_x) ∨ (fact_9fdb227ae99d_3041 a b run_x) ∨ (fact_9fdb227ae99d_3482 a b run_x) ∨ (fact_9fdb227ae99d_2929 a b run_x) ∨ (fact_9fdb227ae99d_2467 a b run_x) ∨ (fact_9fdb227ae99d_2478 a b run_x) ∨ (fact_9fdb227ae99d_2484 a b run_x) ∨ (fact_9fdb227ae99d_2399 a b run_x) ∨ (fact_9fdb227ae99d_2402 a b run_x)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n345_run_floor (a b run_x : Int)
    (h0 : ((4 : Int) ≤ run_x))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (¬ ((fact_9fdb227ae99d_3180 a b run_x) ∨ (fact_9fdb227ae99d_3190 a b run_x) ∨ (fact_9fdb227ae99d_3732 a b run_x) ∨ (fact_9fdb227ae99d_5197 a b run_x) ∨ (fact_9fdb227ae99d_3491 a b run_x) ∨ (fact_9fdb227ae99d_3223 a b run_x) ∨ (fact_9fdb227ae99d_3238 a b run_x) ∨ (fact_9fdb227ae99d_3245 a b run_x) ∨ (fact_9fdb227ae99d_3198 a b run_x) ∨ (fact_9fdb227ae99d_3201 a b run_x))))
    (h3 : (run_x ≤ ((1 : Int) + a)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n346_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((3 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n346_run_short (a b : Int)
    (h0 : (¬ ((((3 : Int) + b) - (4 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n346_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n346_run_left (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3383 a b) ∨ (fact_9fdb227ae99d_3384 a b) ∨ (fact_9fdb227ae99d_4498 a b) ∨ (fact_9fdb227ae99d_5585 a b) ∨ (fact_9fdb227ae99d_3854 a b) ∨ (fact_9fdb227ae99d_3471 a b) ∨ (fact_9fdb227ae99d_3473 a b) ∨ ((((4 : Int) ≥ ((-3 : Int) - a)) ∧ ((4 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((-3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3385 a b) ∨ (fact_9fdb227ae99d_3861 a b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n346_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3856 a b) ∨ (fact_9fdb227ae99d_3858 a b) ∨ (fact_9fdb227ae99d_5288 a b) ∨ (fact_9fdb227ae99d_5903 a b) ∨ (fact_9fdb227ae99d_4709 a b) ∨ ((((4 : Int) ≥ ((-1 : Int) - b)) ∧ ((4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_4185 a b) ∨ ((((4 : Int) ≥ ((-3 : Int) - a)) ∧ ((4 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((3 : Int) + b) + (1 : Int)))) ∨ (((-3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3860 a b) ∨ (fact_9fdb227ae99d_4711 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n346_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((3 : Int) + b)) ∧ ((fact_9fdb227ae99d_7476 a b) ∨ (fact_9fdb227ae99d_7585 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((3 : Int) + b)) ∧ (fact_9fdb227ae99d_7476 a b) ∧ (fact_9fdb227ae99d_7585 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((3 : Int) + b)) ∨ ((((3 : Int) + b) = ((4 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7476 a b) ∧ (fact_9fdb227ae99d_7585 a b) ∧ (((fact_9fdb227ae99d_3765 a b) ∨ (fact_9fdb227ae99d_3797 a b) ∨ (fact_9fdb227ae99d_5175 a b) ∨ (fact_9fdb227ae99d_5853 a b) ∨ (fact_9fdb227ae99d_4544 a b) ∨ (fact_9fdb227ae99d_3934 a b) ∨ (fact_9fdb227ae99d_3983 a b) ∨ (fact_9fdb227ae99d_4007 a b) ∨ (fact_9fdb227ae99d_3817 a b) ∨ (fact_9fdb227ae99d_4684 a b)) ∨ ((fact_9fdb227ae99d_4593 a b) ∨ (fact_9fdb227ae99d_4628 a b) ∨ (fact_9fdb227ae99d_5658 a b) ∨ (fact_9fdb227ae99d_6397 a b) ∨ (fact_9fdb227ae99d_5386 a b) ∨ (fact_9fdb227ae99d_4788 a b) ∨ (fact_9fdb227ae99d_4843 a b) ∨ (fact_9fdb227ae99d_4872 a b) ∨ (fact_9fdb227ae99d_4657 a b) ∨ (fact_9fdb227ae99d_5436 a b)))) ∨ ((fact_9fdb227ae99d_7476 a b) ∧ (fact_9fdb227ae99d_7585 a b) ∧ ((fact_9fdb227ae99d_3765 a b) ∨ (fact_9fdb227ae99d_3797 a b) ∨ (fact_9fdb227ae99d_5175 a b) ∨ (fact_9fdb227ae99d_5853 a b) ∨ (fact_9fdb227ae99d_4544 a b) ∨ (fact_9fdb227ae99d_3934 a b) ∨ (fact_9fdb227ae99d_3983 a b) ∨ (fact_9fdb227ae99d_4007 a b) ∨ (fact_9fdb227ae99d_3817 a b) ∨ (fact_9fdb227ae99d_4684 a b)) ∧ ((fact_9fdb227ae99d_4593 a b) ∨ (fact_9fdb227ae99d_4628 a b) ∨ (fact_9fdb227ae99d_5658 a b) ∨ (fact_9fdb227ae99d_6397 a b) ∨ (fact_9fdb227ae99d_5386 a b) ∨ (fact_9fdb227ae99d_4788 a b) ∨ (fact_9fdb227ae99d_4843 a b) ∨ (fact_9fdb227ae99d_4872 a b) ∨ (fact_9fdb227ae99d_4657 a b) ∨ (fact_9fdb227ae99d_5436 a b))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n346_run_empty (a b run_x : Int)
    (h0 : ((4 : Int) ≤ run_x))
    (h1 : (b = (5 : Int)))
    (h2 : ((fact_9fdb227ae99d_2446 a b run_x) ∨ (fact_9fdb227ae99d_2447 a b run_x) ∨ (fact_9fdb227ae99d_3070 a b run_x) ∨ (fact_9fdb227ae99d_3571 a b run_x) ∨ (fact_9fdb227ae99d_2982 a b run_x) ∨ (fact_9fdb227ae99d_2536 a b run_x) ∨ (fact_9fdb227ae99d_2538 a b run_x) ∨ ((((4 : Int) ≥ ((-3 : Int) - a)) ∧ ((4 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_2448 a b run_x) ∨ (fact_9fdb227ae99d_2983 a b run_x)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (run_x ≤ ((3 : Int) + b)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n346_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3174 a b run_x) ∨ (fact_9fdb227ae99d_3184 a b run_x) ∨ (fact_9fdb227ae99d_3727 a b run_x) ∨ (fact_9fdb227ae99d_5192 a b run_x) ∨ (fact_9fdb227ae99d_3486 a b run_x) ∨ (fact_9fdb227ae99d_3218 a b run_x) ∨ (fact_9fdb227ae99d_3234 a b run_x) ∨ (((((-3 : Int) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3193 a b run_x) ∨ (fact_9fdb227ae99d_3556 a b run_x))))
    (h1 : (run_x ≤ ((3 : Int) + b)))
    (h2 : ((4 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n347_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≤ a)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n347_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((a - (3 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n347_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n347_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3381 a b) ∨ (fact_9fdb227ae99d_3382 a b) ∨ (fact_9fdb227ae99d_4497 a b) ∨ (fact_9fdb227ae99d_5584 a b) ∨ (fact_9fdb227ae99d_3851 a b) ∨ (fact_9fdb227ae99d_3467 a b) ∨ (fact_9fdb227ae99d_3469 a b) ∨ ((((3 : Int) ≥ ((-3 : Int) - a)) ∧ ((3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3852 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n347_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3067 a b) ∨ (fact_9fdb227ae99d_3068 a b) ∨ (fact_9fdb227ae99d_3569 a b) ∨ (fact_9fdb227ae99d_4707 a b) ∨ (fact_9fdb227ae99d_3300 a b) ∨ (fact_9fdb227ae99d_3121 a b) ∨ (fact_9fdb227ae99d_3123 a b) ∨ ((((3 : Int) ≥ ((-3 : Int) - a)) ∧ ((3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ (((-3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3301 a b))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n347_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_9fdb227ae99d_7366 a b) ∨ (fact_9fdb227ae99d_7292 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_9fdb227ae99d_7366 a b) ∧ (fact_9fdb227ae99d_7292 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7366 a b) ∧ (fact_9fdb227ae99d_7292 a b) ∧ (((fact_9fdb227ae99d_3756 a b) ∨ (fact_9fdb227ae99d_3788 a b) ∨ (fact_9fdb227ae99d_5166 a b) ∨ (fact_9fdb227ae99d_5844 a b) ∨ (fact_9fdb227ae99d_4538 a b) ∨ (fact_9fdb227ae99d_3926 a b) ∨ (fact_9fdb227ae99d_3973 a b) ∨ (fact_9fdb227ae99d_3998 a b) ∨ (fact_9fdb227ae99d_4649 a b)) ∨ ((fact_9fdb227ae99d_3268 a b) ∨ (fact_9fdb227ae99d_3274 a b) ∨ (fact_9fdb227ae99d_4193 a b) ∨ (fact_9fdb227ae99d_5365 a b) ∨ (fact_9fdb227ae99d_3618 a b) ∨ (fact_9fdb227ae99d_3304 a b) ∨ (fact_9fdb227ae99d_3309 a b) ∨ (fact_9fdb227ae99d_3314 a b) ∨ (fact_9fdb227ae99d_3650 a b)))) ∨ ((fact_9fdb227ae99d_7366 a b) ∧ (fact_9fdb227ae99d_7292 a b) ∧ ((fact_9fdb227ae99d_3756 a b) ∨ (fact_9fdb227ae99d_3788 a b) ∨ (fact_9fdb227ae99d_5166 a b) ∨ (fact_9fdb227ae99d_5844 a b) ∨ (fact_9fdb227ae99d_4538 a b) ∨ (fact_9fdb227ae99d_3926 a b) ∨ (fact_9fdb227ae99d_3973 a b) ∨ (fact_9fdb227ae99d_3998 a b) ∨ (fact_9fdb227ae99d_4649 a b)) ∧ ((fact_9fdb227ae99d_3268 a b) ∨ (fact_9fdb227ae99d_3274 a b) ∨ (fact_9fdb227ae99d_4193 a b) ∨ (fact_9fdb227ae99d_5365 a b) ∨ (fact_9fdb227ae99d_3618 a b) ∨ (fact_9fdb227ae99d_3304 a b) ∨ (fact_9fdb227ae99d_3309 a b) ∨ (fact_9fdb227ae99d_3314 a b) ∨ (fact_9fdb227ae99d_3650 a b))))))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a > b))
    (h6 : (a ≥ b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n347_run_empty (a b run_x : Int)
    (h0 : ((3 : Int) ≤ run_x))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (run_x ≤ a))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((fact_9fdb227ae99d_2444 a b run_x) ∨ (fact_9fdb227ae99d_2445 a b run_x) ∨ (fact_9fdb227ae99d_3064 a b run_x) ∨ (fact_9fdb227ae99d_3570 a b run_x) ∨ (fact_9fdb227ae99d_2980 a b run_x) ∨ (fact_9fdb227ae99d_2532 a b run_x) ∨ (fact_9fdb227ae99d_2534 a b run_x) ∨ ((((3 : Int) ≥ ((-3 : Int) - a)) ∧ ((3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_2981 a b run_x)))
    (h6 : (b = (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n347_run_floor (a b run_x : Int)
    (h0 : ((3 : Int) ≤ run_x))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (run_x ≤ a))
    (h3 : (¬ ((fact_9fdb227ae99d_3173 a b run_x) ∨ (fact_9fdb227ae99d_3183 a b run_x) ∨ (fact_9fdb227ae99d_3726 a b run_x) ∨ (fact_9fdb227ae99d_5191 a b run_x) ∨ (fact_9fdb227ae99d_3485 a b run_x) ∨ (fact_9fdb227ae99d_3217 a b run_x) ∨ (fact_9fdb227ae99d_3233 a b run_x) ∨ (((((-3 : Int) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3549 a b run_x))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n348_run_four (a b : Int)
    (h0 : (¬ ((-3 : Int) ≥ ((-2 : Int) + ((-1 : Int) * b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n348_run_short (a b : Int)
    (h0 : (¬ (((-3 : Int) - ((-2 : Int) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n348_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n348_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5685 a b) ∨ (fact_9fdb227ae99d_5698 a b) ∨ (fact_9fdb227ae99d_6366 a b) ∨ (fact_9fdb227ae99d_6962 a b) ∨ (fact_9fdb227ae99d_5992 a b) ∨ (((((-1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_6980 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n348_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3413 a b) ∨ (fact_9fdb227ae99d_3431 a b) ∨ (fact_9fdb227ae99d_4506 a b) ∨ (fact_9fdb227ae99d_5590 a b) ∨ (fact_9fdb227ae99d_3878 a b) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ ((-3 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-3 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ ((-3 : Int) + (1 : Int))) ∧ ((-2 : Int) ≥ ((-3 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_5724 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n348_run_tall (a b : Int)
    (h0 : (¬ ((((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7504 a b) ∨ (fact_9fdb227ae99d_7305 a b))) ∨ (((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) + (2 : Int))) ∧ (fact_9fdb227ae99d_7504 a b) ∧ (fact_9fdb227ae99d_7305 a b)) ∨ ((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) + (4 : Int))) ∨ (((-3 : Int) = (((-2 : Int) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_9fdb227ae99d_7504 a b) ∧ (fact_9fdb227ae99d_7305 a b) ∧ (((fact_9fdb227ae99d_6025 a b) ∨ (fact_9fdb227ae99d_6063 a b) ∨ (fact_9fdb227ae99d_6825 a b) ∨ (fact_9fdb227ae99d_7037 a b) ∨ (fact_9fdb227ae99d_6591 a b) ∨ (fact_9fdb227ae99d_6234 a b) ∨ (((((-2 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_7088 a b)) ∨ ((fact_9fdb227ae99d_4067 a b) ∨ (fact_9fdb227ae99d_4095 a b) ∨ (fact_9fdb227ae99d_5301 a b) ∨ (fact_9fdb227ae99d_5916 a b) ∨ (fact_9fdb227ae99d_4730 a b) ∨ (fact_9fdb227ae99d_4227 a b) ∨ (fact_9fdb227ae99d_4258 a b) ∨ (fact_9fdb227ae99d_6158 a b)))) ∨ ((fact_9fdb227ae99d_7504 a b) ∧ (fact_9fdb227ae99d_7305 a b) ∧ ((fact_9fdb227ae99d_6025 a b) ∨ (fact_9fdb227ae99d_6063 a b) ∨ (fact_9fdb227ae99d_6825 a b) ∨ (fact_9fdb227ae99d_7037 a b) ∨ (fact_9fdb227ae99d_6591 a b) ∨ (fact_9fdb227ae99d_6234 a b) ∨ (((((-2 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_7088 a b)) ∧ ((fact_9fdb227ae99d_4067 a b) ∨ (fact_9fdb227ae99d_4095 a b) ∨ (fact_9fdb227ae99d_5301 a b) ∨ (fact_9fdb227ae99d_5916 a b) ∨ (fact_9fdb227ae99d_4730 a b) ∨ (fact_9fdb227ae99d_4227 a b) ∨ (fact_9fdb227ae99d_4258 a b) ∨ (fact_9fdb227ae99d_6158 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n348_run_empty (a b run_x : Int)
    (h0 : ((-3 : Int) ≥ run_x))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((fact_9fdb227ae99d_2366 a b run_x) ∨ (fact_9fdb227ae99d_2383 a b run_x) ∨ (fact_9fdb227ae99d_3039 a b run_x) ∨ (fact_9fdb227ae99d_3480 a b run_x) ∨ (fact_9fdb227ae99d_2927 a b run_x) ∨ (fact_9fdb227ae99d_2465 a b run_x) ∨ (fact_9fdb227ae99d_2476 a b run_x) ∨ (fact_9fdb227ae99d_3611 a b run_x)))
    (h5 : (((-2 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n348_run_floor (a b run_x : Int)
    (h0 : ((-3 : Int) ≥ run_x))
    (h1 : (¬ ((fact_9fdb227ae99d_3178 a b run_x) ∨ (fact_9fdb227ae99d_3188 a b run_x) ∨ (fact_9fdb227ae99d_3730 a b run_x) ∨ (fact_9fdb227ae99d_5195 a b run_x) ∨ (fact_9fdb227ae99d_3489 a b run_x) ∨ (fact_9fdb227ae99d_3221 a b run_x) ∨ (fact_9fdb227ae99d_3236 a b run_x) ∨ (fact_9fdb227ae99d_5355 a b run_x))))
    (h2 : (((-2 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n349_point (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((-3 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((-3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n349_empty (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (((((-3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (0 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + a)))) ∨ ((((-3 : Int) ≥ (((1 : Int) + b + a) - a)) ∧ ((-3 : Int) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-3 : Int) ≥ ((1 : Int) + b + a)) ∧ ((-3 : Int) ≤ ((1 : Int) + b + a)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + b)))) ∨ ((((-3 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - b)) ∧ ((-3 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≥ ((2 : Int) + ((2 : Int) * b))) ∧ ((-3 : Int) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + a)))) ∨ ((((-3 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((-3 : Int) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≥ ((2 : Int) + a)) ∧ ((-3 : Int) ≤ ((2 : Int) + a)) ∧ ((1 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-1 : Int) - b)) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((-2 : Int) - b)) ∧ ((-3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≥ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-2 : Int)) ∧ ((1 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (0 : Int)))))))
    (h3 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + a))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((-2 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-2 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (((1 : Int) + a) - a)) ∨ ((1 : Int) > (((1 : Int) + a) + (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n349_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h2 : (b = (5 : Int)))
    (h3 : (¬ (((jx = ((-3 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n349_o1 (a b jx jy : Int)
    (h0 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n349_o2 (a b jx jy : Int)
    (h0 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (fact_9fdb227ae99d_2924 a b jy))
    (h2 : (¬ ((((-3 : Int) = jx) ∧ (jy = ((1 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h3 : (b = (5 : Int)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n349_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((jx + (0 : Int)) < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < (jx - b)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (b = (5 : Int)))
    (h7 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n349_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_2922 a b jy))
    (h1 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - a))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n349_o5 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (¬ ((((-3 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (((jx + (0 : Int)) < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < (jx - a)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h9 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n349_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (b = (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h6 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (¬ (((jx = ((-3 : Int) + ((-1 : Int) * b))) ∧ ((1 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n349_o7 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h2 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n350_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((-3 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((-3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n350_empty (a b : Int)
    (h0 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + a))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((((2 : Int) + a) + (0 : Int)) < ((-3 : Int) + ((-1 : Int) * a))) ∨ (((-3 : Int) + ((-1 : Int) * a)) < (((2 : Int) + a) - a)) ∨ ((2 : Int) < ((1 : Int) - (0 : Int))) ∨ ((2 : Int) > ((1 : Int) + b))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : ((fact_9fdb227ae99d_2869 a b) ∨ (fact_9fdb227ae99d_2871 a b) ∨ (fact_9fdb227ae99d_3261 a b) ∨ (fact_9fdb227ae99d_4168 a b) ∨ (fact_9fdb227ae99d_3100 a b) ∨ ((((-3 : Int) ≥ ((-1 : Int) - b)) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((-2 : Int) - b)) ∧ ((-3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((1 : Int) + a)) ∧ ((2 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-2 : Int)) ∧ ((2 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((-3 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((-3 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-3 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + b))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n350_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h4 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((jx + a) < ((-3 : Int) + ((-1 : Int) * a))) ∨ (((-3 : Int) + ((-1 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h7 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n350_o1 (a b jx jy : Int)
    (h0 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (fact_9fdb227ae99d_2923 a b jy))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - a))))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n350_o2 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (((jx + (0 : Int)) < ((-3 : Int) + ((-1 : Int) * a))) ∨ (((-3 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h4 : (b = (5 : Int)))
    (h5 : (¬ ((((-3 : Int) = jx) ∧ (jy = ((2 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n350_o3 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h2 : ((jx < (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h5 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n350_o4 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_2922 a b jy))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - a))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n350_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h4 : (((jx + (0 : Int)) < ((-3 : Int) + ((-1 : Int) * a))) ∨ (((-3 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h5 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : ((jx < (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n350_o6 (a b jx jy : Int)
    (h0 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (¬ (((jx = ((-3 : Int) + ((-1 : Int) * b))) ∧ ((2 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n350_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n351_run_four (a b : Int)
    (h0 : (¬ ((2 : Int) ≤ ((-1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n351_run_short (a b : Int)
    (h0 : (¬ ((((-1 : Int) + a) - (2 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n351_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n351_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((((0 : Int) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((2 : Int) + a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-3 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-3 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((2 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n351_run_right (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ ((((((0 : Int) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ (((0 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ (((1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ ((((2 : Int) + a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + a) - a) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-3 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-3 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((2 : Int) + b) - b) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n351_run_tall (a b : Int)
    (h0 : (¬ (((((2 : Int) + (3 : Int)) ≤ ((-1 : Int) + a)) ∧ ((fact_9fdb227ae99d_7692 a b) ∨ (fact_9fdb227ae99d_7770 a b))) ∨ ((((2 : Int) + (2 : Int)) ≤ ((-1 : Int) + a)) ∧ (fact_9fdb227ae99d_7692 a b) ∧ (fact_9fdb227ae99d_7770 a b)) ∨ (((2 : Int) + (4 : Int)) ≤ ((-1 : Int) + a)) ∨ ((((-1 : Int) + a) = ((2 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7692 a b) ∧ (fact_9fdb227ae99d_7770 a b) ∧ (((fact_9fdb227ae99d_6017 a b) ∨ (fact_9fdb227ae99d_6055 a b) ∨ (fact_9fdb227ae99d_6817 a b) ∨ (fact_9fdb227ae99d_7029 a b) ∨ (fact_9fdb227ae99d_6583 a b) ∨ (((((-1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_6696 a b) ∨ (fact_9fdb227ae99d_7077 a b) ∨ (fact_9fdb227ae99d_6711 a b)) ∨ ((fact_9fdb227ae99d_6743 a b) ∨ (fact_9fdb227ae99d_6747 a b) ∨ (fact_9fdb227ae99d_6997 a b) ∨ (fact_9fdb227ae99d_7156 a b) ∨ (fact_9fdb227ae99d_6926 a b) ∨ (((((-1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_6971 a b) ∨ (fact_9fdb227ae99d_7166 a b) ∨ (fact_9fdb227ae99d_6973 a b)))) ∨ ((fact_9fdb227ae99d_7692 a b) ∧ (fact_9fdb227ae99d_7770 a b) ∧ ((fact_9fdb227ae99d_6017 a b) ∨ (fact_9fdb227ae99d_6055 a b) ∨ (fact_9fdb227ae99d_6817 a b) ∨ (fact_9fdb227ae99d_7029 a b) ∨ (fact_9fdb227ae99d_6583 a b) ∨ (((((-1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_6696 a b) ∨ (fact_9fdb227ae99d_7077 a b) ∨ (fact_9fdb227ae99d_6711 a b)) ∧ ((fact_9fdb227ae99d_6743 a b) ∨ (fact_9fdb227ae99d_6747 a b) ∨ (fact_9fdb227ae99d_6997 a b) ∨ (fact_9fdb227ae99d_7156 a b) ∨ (fact_9fdb227ae99d_6926 a b) ∨ (((((-1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_6971 a b) ∨ (fact_9fdb227ae99d_7166 a b) ∨ (fact_9fdb227ae99d_6973 a b))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a > b))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n351_run_empty (a b run_x : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (run_x ≤ ((-1 : Int) + a)))
    (h3 : (a > b))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((2 : Int) ≤ run_x))
    (h7 : ((fact_9fdb227ae99d_3628 a b run_x) ∨ (fact_9fdb227ae99d_3637 a b run_x) ∨ (fact_9fdb227ae99d_5036 a b run_x) ∨ (fact_9fdb227ae99d_5789 a b run_x) ∨ (fact_9fdb227ae99d_4411 a b run_x) ∨ (((((-1 : Int) - b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b))) ∨ (((-3 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-3 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((2 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + b) + (0 : Int)))))))
    (h8 : (a ≥ b))
    (h9 : (b ≥ (3 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n351_run_floor (a b run_x : Int)
    (h0 : ((2 : Int) ≤ run_x))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (¬ ((fact_9fdb227ae99d_5411 a b run_x) ∨ (fact_9fdb227ae99d_5414 a b run_x) ∨ (fact_9fdb227ae99d_5989 a b run_x) ∨ (fact_9fdb227ae99d_6842 a b run_x) ∨ (fact_9fdb227ae99d_5795 a b run_x) ∨ (((((-1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((1 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b))) ∨ (((-3 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((2 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + b) + (0 : Int))))))))
    (h3 : (run_x ≤ ((-1 : Int) + a)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n352_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((-3 : Int) ≥ ((-2 : Int) + ((-1 : Int) * b)))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n352_run_short (a b : Int)
    (h0 : (¬ (((-3 : Int) - ((-2 : Int) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n352_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n352_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_5685 a b) ∨ (fact_9fdb227ae99d_5698 a b) ∨ (fact_9fdb227ae99d_6366 a b) ∨ (fact_9fdb227ae99d_6962 a b) ∨ (fact_9fdb227ae99d_5992 a b) ∨ (((((-1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) + a)) ∧ ((3 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_6980 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n352_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3413 a b) ∨ (fact_9fdb227ae99d_3431 a b) ∨ (fact_9fdb227ae99d_4506 a b) ∨ (fact_9fdb227ae99d_5590 a b) ∨ (fact_9fdb227ae99d_3878 a b) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ ((-3 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-3 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) + a)) ∧ ((3 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ ((-3 : Int) + (1 : Int))) ∧ ((-2 : Int) ≥ ((-3 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_5724 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n352_run_tall (a b : Int)
    (h0 : (¬ ((((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7728 a b) ∨ (fact_9fdb227ae99d_7426 a b))) ∨ (((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) + (2 : Int))) ∧ (fact_9fdb227ae99d_7728 a b) ∧ (fact_9fdb227ae99d_7426 a b)) ∨ ((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) + (4 : Int))) ∨ (((-3 : Int) = (((-2 : Int) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_9fdb227ae99d_7728 a b) ∧ (fact_9fdb227ae99d_7426 a b) ∧ (((fact_9fdb227ae99d_6025 a b) ∨ (fact_9fdb227ae99d_6063 a b) ∨ (fact_9fdb227ae99d_6825 a b) ∨ (fact_9fdb227ae99d_7037 a b) ∨ (fact_9fdb227ae99d_6591 a b) ∨ (fact_9fdb227ae99d_6234 a b) ∨ (((((-2 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_7088 a b)) ∨ ((fact_9fdb227ae99d_4067 a b) ∨ (fact_9fdb227ae99d_4095 a b) ∨ (fact_9fdb227ae99d_5301 a b) ∨ (fact_9fdb227ae99d_5916 a b) ∨ (fact_9fdb227ae99d_4730 a b) ∨ (fact_9fdb227ae99d_4227 a b) ∨ (fact_9fdb227ae99d_5071 a b) ∨ (fact_9fdb227ae99d_6147 a b) ∨ (fact_9fdb227ae99d_6158 a b)))) ∨ ((fact_9fdb227ae99d_7728 a b) ∧ (fact_9fdb227ae99d_7426 a b) ∧ ((fact_9fdb227ae99d_6025 a b) ∨ (fact_9fdb227ae99d_6063 a b) ∨ (fact_9fdb227ae99d_6825 a b) ∨ (fact_9fdb227ae99d_7037 a b) ∨ (fact_9fdb227ae99d_6591 a b) ∨ (fact_9fdb227ae99d_6234 a b) ∨ (((((-2 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_7088 a b)) ∧ ((fact_9fdb227ae99d_4067 a b) ∨ (fact_9fdb227ae99d_4095 a b) ∨ (fact_9fdb227ae99d_5301 a b) ∨ (fact_9fdb227ae99d_5916 a b) ∨ (fact_9fdb227ae99d_4730 a b) ∨ (fact_9fdb227ae99d_4227 a b) ∨ (fact_9fdb227ae99d_5071 a b) ∨ (fact_9fdb227ae99d_6147 a b) ∨ (fact_9fdb227ae99d_6158 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n352_run_empty (a b run_x : Int)
    (h0 : ((fact_9fdb227ae99d_2366 a b run_x) ∨ (fact_9fdb227ae99d_2383 a b run_x) ∨ (fact_9fdb227ae99d_3039 a b run_x) ∨ (fact_9fdb227ae99d_3480 a b run_x) ∨ (fact_9fdb227ae99d_2927 a b run_x) ∨ (fact_9fdb227ae99d_2465 a b run_x) ∨ (fact_9fdb227ae99d_3000 a b run_x) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3611 a b run_x)))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((-2 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((-3 : Int) ≥ run_x))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n352_run_floor (a b run_x : Int)
    (h0 : ((-3 : Int) ≥ run_x))
    (h1 : (((-2 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h2 : (¬ ((fact_9fdb227ae99d_3178 a b run_x) ∨ (fact_9fdb227ae99d_3188 a b run_x) ∨ (fact_9fdb227ae99d_3730 a b run_x) ∨ (fact_9fdb227ae99d_5195 a b run_x) ∨ (fact_9fdb227ae99d_3489 a b run_x) ∨ (fact_9fdb227ae99d_3221 a b run_x) ∨ (fact_9fdb227ae99d_3573 a b run_x) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_5355 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n353_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((1 : Int) ≤ b)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n353_run_short (a b : Int)
    (h0 : (¬ ((b - (1 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n353_run_nonnegative (a b : Int)
    (h0 : (¬ ((1 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n353_run_left (a b : Int)
    (h0 : (¬ ((((((0 : Int) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (-(4 : Int))) ∧ ((0 : Int) ≥ (-(4 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((1 : Int) ≤ (-(4 : Int))) ∧ ((1 : Int) ≥ (-(4 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ ((((2 : Int) + a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-(4 : Int))) ∧ ((-1 : Int) ≥ (-(4 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (-(4 : Int))) ∧ ((-2 : Int) ≥ (-(4 : Int))) ∧ ((((1 : Int) + a) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-3 : Int) ≤ (-(4 : Int))) ∧ ((-3 : Int) ≥ (-(4 : Int))) ∧ ((((1 : Int) + b) - b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int))))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n353_run_right (a b : Int)
    (h0 : (¬ ((((((0 : Int) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ (((0 : Int) ≤ (-(4 : Int))) ∧ ((0 : Int) ≥ (-(4 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (b + (1 : Int))) ∧ ((1 : Int) ≥ (b + (1 : Int)))) ∨ (((1 : Int) ≤ (-(4 : Int))) ∧ ((1 : Int) ≥ (-(4 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (b + (1 : Int))) ∧ ((1 : Int) ≥ (b + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (b + (1 : Int))) ∧ ((2 : Int) ≥ (b + (1 : Int)))) ∨ ((((2 : Int) + a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ (((-1 : Int) ≤ (-(4 : Int))) ∧ ((-1 : Int) ≥ (-(4 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (-(4 : Int))) ∧ ((-2 : Int) ≥ (-(4 : Int))) ∧ ((((1 : Int) + a) - a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-3 : Int) ≤ (-(4 : Int))) ∧ ((-3 : Int) ≥ (-(4 : Int))) ∧ ((((1 : Int) + b) - b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n353_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ (((((1 : Int) + (3 : Int)) ≤ b) ∧ ((fact_9fdb227ae99d_7328 a b) ∨ (fact_9fdb227ae99d_7272 a b))) ∨ ((((1 : Int) + (2 : Int)) ≤ b) ∧ (fact_9fdb227ae99d_7328 a b) ∧ (fact_9fdb227ae99d_7272 a b)) ∨ (((1 : Int) + (4 : Int)) ≤ b) ∨ ((b = ((1 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7328 a b) ∧ (fact_9fdb227ae99d_7272 a b) ∧ (((fact_9fdb227ae99d_4344 a b) ∨ (fact_9fdb227ae99d_4361 a b) ∨ (fact_9fdb227ae99d_5454 a b) ∨ (fact_9fdb227ae99d_6177 a b) ∨ (fact_9fdb227ae99d_5112 a b) ∨ (((((-1 : Int) - b) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_5218 a b) ∨ (fact_9fdb227ae99d_5229 a b)) ∨ ((fact_9fdb227ae99d_3421 a b) ∨ (fact_9fdb227ae99d_3439 a b) ∨ (fact_9fdb227ae99d_4514 a b) ∨ (fact_9fdb227ae99d_5598 a b) ∨ (fact_9fdb227ae99d_3886 a b) ∨ (((((-1 : Int) - b) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_4276 a b) ∨ (fact_9fdb227ae99d_4291 a b)))) ∨ ((fact_9fdb227ae99d_7328 a b) ∧ (fact_9fdb227ae99d_7272 a b) ∧ ((fact_9fdb227ae99d_4344 a b) ∨ (fact_9fdb227ae99d_4361 a b) ∨ (fact_9fdb227ae99d_5454 a b) ∨ (fact_9fdb227ae99d_6177 a b) ∨ (fact_9fdb227ae99d_5112 a b) ∨ (((((-1 : Int) - b) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_5218 a b) ∨ (fact_9fdb227ae99d_5229 a b)) ∧ ((fact_9fdb227ae99d_3421 a b) ∨ (fact_9fdb227ae99d_3439 a b) ∨ (fact_9fdb227ae99d_4514 a b) ∨ (fact_9fdb227ae99d_5598 a b) ∨ (fact_9fdb227ae99d_3886 a b) ∨ (((((-1 : Int) - b) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (fact_9fdb227ae99d_4276 a b) ∨ (fact_9fdb227ae99d_4291 a b))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n353_run_empty (a b run_x : Int)
    (h0 : ((1 : Int) ≤ run_x))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((-3 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-3 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (((1 : Int) + b) - b)) ∨ ((1 : Int) > (((1 : Int) + b) + (0 : Int)))))
    (h4 : (run_x ≤ b))
    (h5 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + a))))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : ((((2 : Int) + a) < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + b) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h8 : (b = (5 : Int)))
    (h9 : ((fact_9fdb227ae99d_2588 a b run_x) ∨ (fact_9fdb227ae99d_2593 a b run_x) ∨ (fact_9fdb227ae99d_3154 a b run_x) ∨ (fact_9fdb227ae99d_3674 a b run_x) ∨ (fact_9fdb227ae99d_3032 a b run_x) ∨ (((((-1 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ (-(4 : Int))) ∧ ((-1 : Int) ≥ (-(4 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (-(4 : Int))) ∧ ((-2 : Int) ≥ (-(4 : Int))) ∧ ((((1 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b))) ∨ (((-3 : Int) ≤ (-(4 : Int))) ∧ ((-3 : Int) ≥ (-(4 : Int))) ∧ ((((1 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + b) + (0 : Int)))))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n353_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ b))
    (h1 : (¬ ((fact_9fdb227ae99d_3321 a b run_x) ∨ (fact_9fdb227ae99d_3325 a b run_x) ∨ (fact_9fdb227ae99d_4336 a b run_x) ∨ (fact_9fdb227ae99d_5470 a b run_x) ∨ (fact_9fdb227ae99d_3678 a b run_x) ∨ (((((-1 : Int) - b) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-((4 : Int) - (1 : Int))) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-1 : Int) ≥ (-((4 : Int) - (1 : Int)))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-((4 : Int) - (1 : Int))) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-2 : Int) ≥ (-((4 : Int) - (1 : Int)))) ∧ ((((1 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-((4 : Int) - (1 : Int))) ≤ ((-3 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b))) ∨ (((-3 : Int) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-3 : Int) ≥ (-((4 : Int) - (1 : Int)))) ∧ ((((1 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + b) + (0 : Int))))))))
    (h2 : ((1 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n354_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((2 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n354_empty (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : ((fact_9fdb227ae99d_2817 a b) ∨ (fact_9fdb227ae99d_2818 a b) ∨ (fact_9fdb227ae99d_3202 a b) ∨ (fact_9fdb227ae99d_3848 a b) ∨ (fact_9fdb227ae99d_3060 a b) ∨ (fact_9fdb227ae99d_2895 a b) ∨ ((((2 : Int) ≥ ((-2 : Int) - b)) ∧ ((2 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) + a)) ∧ ((3 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-2 : Int)) ∧ ((3 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((2 : Int) ≥ ((-3 : Int) - a)) ∧ ((2 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-3 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n354_o0 (a b jx jy : Int)
    (h0 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h1 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h2 : (b = (5 : Int)))
    (h3 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n354_o1 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ ((((2 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h7 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n354_o2 (a b jx jy : Int)
    (h0 : ((((2 : Int) ≥ (jx - a)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n354_o3 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((((2 : Int) ≥ (jx - b)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h2 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (b = (5 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (¬ (((jx = ((2 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n354_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (¬ ((((2 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h4 : ((((2 : Int) ≥ (jx - b)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n354_o5 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((2 : Int) + a)) ∨ (((2 : Int) + a) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h5 : ((((2 : Int) ≥ (jx - a)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h6 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n354_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (¬ ((((2 : Int) = jx) ∧ ((3 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : (b = (5 : Int)))
    (h6 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n354_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ ((((2 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b = (5 : Int)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h7 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n355_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ (((3 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n355_empty (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((fact_9fdb227ae99d_2819 a b) ∨ (fact_9fdb227ae99d_2821 a b) ∨ (fact_9fdb227ae99d_3203 a b) ∨ (fact_9fdb227ae99d_3849 a b) ∨ (fact_9fdb227ae99d_3065 a b) ∨ (fact_9fdb227ae99d_2900 a b) ∨ ((((3 : Int) ≥ ((-2 : Int) - b)) ∧ ((3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) + a)) ∧ ((3 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-2 : Int)) ∧ ((3 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((3 : Int) ≥ ((-3 : Int) - a)) ∧ ((3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-3 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3069 a b)))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n355_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h5 : (b = (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n355_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - a))))
    (h4 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n355_o2 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n355_o3 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ (((jx = ((3 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h5 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n355_o4 (a b jx jy : Int)
    (h0 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n355_o5 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((jx + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h7 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a = (b + (2 : Int))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n355_o6 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h2 : (b = (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((jy + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h6 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n355_o7 (a b jx jy : Int)
    (h0 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b = (5 : Int)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (¬ ((((3 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n356_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((3 : Int) ≤ ((2 : Int) + b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n356_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + b) - (3 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n356_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n356_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3364 a b) ∨ (fact_9fdb227ae99d_3371 a b) ∨ (fact_9fdb227ae99d_4406 a b) ∨ (fact_9fdb227ae99d_5545 a b) ∨ (fact_9fdb227ae99d_3734 a b) ∨ (fact_9fdb227ae99d_3396 a b) ∨ (((((-2 : Int) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) + a)) ∧ ((4 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((-2 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3816 a b) ∨ (fact_9fdb227ae99d_3739 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n356_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3751 a b) ∨ (fact_9fdb227ae99d_3783 a b) ∨ (fact_9fdb227ae99d_5161 a b) ∨ (fact_9fdb227ae99d_5839 a b) ∨ (fact_9fdb227ae99d_4534 a b) ∨ (fact_9fdb227ae99d_3920 a b) ∨ (((((-2 : Int) - b) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) + a)) ∧ ((4 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((-2 : Int) ≥ (((2 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((-3 : Int) ≥ (((2 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_4643 a b) ∨ (fact_9fdb227ae99d_4557 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n356_run_tall (a b : Int)
    (h0 : (¬ (((((3 : Int) + (3 : Int)) ≤ ((2 : Int) + b)) ∧ ((fact_9fdb227ae99d_7493 a b) ∨ (fact_9fdb227ae99d_7608 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ ((2 : Int) + b)) ∧ (fact_9fdb227ae99d_7493 a b) ∧ (fact_9fdb227ae99d_7608 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ ((2 : Int) + b)) ∨ ((((2 : Int) + b) = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7493 a b) ∧ (fact_9fdb227ae99d_7608 a b) ∧ (((fact_9fdb227ae99d_3759 a b) ∨ (fact_9fdb227ae99d_3791 a b) ∨ (fact_9fdb227ae99d_5169 a b) ∨ (fact_9fdb227ae99d_5847 a b) ∨ (fact_9fdb227ae99d_4540 a b) ∨ (fact_9fdb227ae99d_3929 a b) ∨ (fact_9fdb227ae99d_4840 a b) ∨ (fact_9fdb227ae99d_4001 a b) ∨ (fact_9fdb227ae99d_4654 a b) ∨ (fact_9fdb227ae99d_4559 a b)) ∨ ((fact_9fdb227ae99d_4574 a b) ∨ (fact_9fdb227ae99d_4609 a b) ∨ (fact_9fdb227ae99d_5640 a b) ∨ (fact_9fdb227ae99d_6381 a b) ∨ (fact_9fdb227ae99d_5377 a b) ∨ (fact_9fdb227ae99d_4782 a b) ∨ (fact_9fdb227ae99d_5490 a b) ∨ (fact_9fdb227ae99d_4862 a b) ∨ (fact_9fdb227ae99d_5420 a b) ∨ (fact_9fdb227ae99d_5397 a b)))) ∨ ((fact_9fdb227ae99d_7493 a b) ∧ (fact_9fdb227ae99d_7608 a b) ∧ ((fact_9fdb227ae99d_3759 a b) ∨ (fact_9fdb227ae99d_3791 a b) ∨ (fact_9fdb227ae99d_5169 a b) ∨ (fact_9fdb227ae99d_5847 a b) ∨ (fact_9fdb227ae99d_4540 a b) ∨ (fact_9fdb227ae99d_3929 a b) ∨ (fact_9fdb227ae99d_4840 a b) ∨ (fact_9fdb227ae99d_4001 a b) ∨ (fact_9fdb227ae99d_4654 a b) ∨ (fact_9fdb227ae99d_4559 a b)) ∧ ((fact_9fdb227ae99d_4574 a b) ∨ (fact_9fdb227ae99d_4609 a b) ∨ (fact_9fdb227ae99d_5640 a b) ∨ (fact_9fdb227ae99d_6381 a b) ∨ (fact_9fdb227ae99d_5377 a b) ∨ (fact_9fdb227ae99d_4782 a b) ∨ (fact_9fdb227ae99d_5490 a b) ∨ (fact_9fdb227ae99d_4862 a b) ∨ (fact_9fdb227ae99d_5420 a b) ∨ (fact_9fdb227ae99d_5397 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n356_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((3 : Int) ≤ run_x))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((fact_9fdb227ae99d_2367 a b run_x) ∨ (fact_9fdb227ae99d_2384 a b run_x) ∨ (fact_9fdb227ae99d_3040 a b run_x) ∨ (fact_9fdb227ae99d_3481 a b run_x) ∨ (fact_9fdb227ae99d_2928 a b run_x) ∨ (fact_9fdb227ae99d_2466 a b run_x) ∨ (fact_9fdb227ae99d_3001 a b run_x) ∨ (fact_9fdb227ae99d_2482 a b run_x) ∨ (fact_9fdb227ae99d_2944 a b run_x) ∨ (fact_9fdb227ae99d_2931 a b run_x)))
    (h5 : (b = (5 : Int)))
    (h6 : (run_x ≤ ((2 : Int) + b)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n356_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3179 a b run_x) ∨ (fact_9fdb227ae99d_3189 a b run_x) ∨ (fact_9fdb227ae99d_3731 a b run_x) ∨ (fact_9fdb227ae99d_5196 a b run_x) ∨ (fact_9fdb227ae99d_3490 a b run_x) ∨ (fact_9fdb227ae99d_3222 a b run_x) ∨ (fact_9fdb227ae99d_3574 a b run_x) ∨ (fact_9fdb227ae99d_3243 a b run_x) ∨ (fact_9fdb227ae99d_3551 a b run_x) ∨ (fact_9fdb227ae99d_3493 a b run_x))))
    (h1 : ((3 : Int) ≤ run_x))
    (h2 : (run_x ≤ ((2 : Int) + b)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n357_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n357_run_short (a b : Int)
    (h0 : (¬ ((((1 : Int) + a) - (4 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n357_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n357_run_left (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3366 a b) ∨ (fact_9fdb227ae99d_3373 a b) ∨ (fact_9fdb227ae99d_4408 a b) ∨ (fact_9fdb227ae99d_5547 a b) ∨ (fact_9fdb227ae99d_3736 a b) ∨ (fact_9fdb227ae99d_3398 a b) ∨ (((((-2 : Int) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) + a)) ∧ ((3 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((-2 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3825 a b) ∨ (fact_9fdb227ae99d_3833 a b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n357_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3748 a b) ∨ (fact_9fdb227ae99d_3780 a b) ∨ (fact_9fdb227ae99d_5158 a b) ∨ (fact_9fdb227ae99d_5836 a b) ∨ (fact_9fdb227ae99d_4531 a b) ∨ (fact_9fdb227ae99d_3917 a b) ∨ (((((-2 : Int) - b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) + a)) ∧ ((3 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((-2 : Int) ≥ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((-3 : Int) ≥ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_4639 a b) ∨ (fact_9fdb227ae99d_4674 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n357_run_tall (a b : Int)
    (h0 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_9fdb227ae99d_7498 a b) ∨ (fact_9fdb227ae99d_7603 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ (fact_9fdb227ae99d_7498 a b) ∧ (fact_9fdb227ae99d_7603 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = ((4 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7498 a b) ∧ (fact_9fdb227ae99d_7603 a b) ∧ (((fact_9fdb227ae99d_3769 a b) ∨ (fact_9fdb227ae99d_3801 a b) ∨ (fact_9fdb227ae99d_5179 a b) ∨ (fact_9fdb227ae99d_5857 a b) ∨ (fact_9fdb227ae99d_4546 a b) ∨ (fact_9fdb227ae99d_3936 a b) ∨ (fact_9fdb227ae99d_4846 a b) ∨ (fact_9fdb227ae99d_4009 a b) ∨ (fact_9fdb227ae99d_4663 a b) ∨ (fact_9fdb227ae99d_4688 a b)) ∨ ((fact_9fdb227ae99d_4565 a b) ∨ (fact_9fdb227ae99d_4600 a b) ∨ (fact_9fdb227ae99d_5632 a b) ∨ (fact_9fdb227ae99d_6373 a b) ∨ (fact_9fdb227ae99d_5371 a b) ∨ (fact_9fdb227ae99d_4774 a b) ∨ (fact_9fdb227ae99d_5486 a b) ∨ (fact_9fdb227ae99d_4852 a b) ∨ (fact_9fdb227ae99d_5417 a b) ∨ (fact_9fdb227ae99d_5428 a b)))) ∨ ((fact_9fdb227ae99d_7498 a b) ∧ (fact_9fdb227ae99d_7603 a b) ∧ ((fact_9fdb227ae99d_3769 a b) ∨ (fact_9fdb227ae99d_3801 a b) ∨ (fact_9fdb227ae99d_5179 a b) ∨ (fact_9fdb227ae99d_5857 a b) ∨ (fact_9fdb227ae99d_4546 a b) ∨ (fact_9fdb227ae99d_3936 a b) ∨ (fact_9fdb227ae99d_4846 a b) ∨ (fact_9fdb227ae99d_4009 a b) ∨ (fact_9fdb227ae99d_4663 a b) ∨ (fact_9fdb227ae99d_4688 a b)) ∧ ((fact_9fdb227ae99d_4565 a b) ∨ (fact_9fdb227ae99d_4600 a b) ∨ (fact_9fdb227ae99d_5632 a b) ∨ (fact_9fdb227ae99d_6373 a b) ∨ (fact_9fdb227ae99d_5371 a b) ∨ (fact_9fdb227ae99d_4774 a b) ∨ (fact_9fdb227ae99d_5486 a b) ∨ (fact_9fdb227ae99d_4852 a b) ∨ (fact_9fdb227ae99d_5417 a b) ∨ (fact_9fdb227ae99d_5428 a b))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n357_run_empty (a b run_x : Int)
    (h0 : (run_x ≤ ((1 : Int) + a)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : ((fact_9fdb227ae99d_2366 a b run_x) ∨ (fact_9fdb227ae99d_2383 a b run_x) ∨ (fact_9fdb227ae99d_3039 a b run_x) ∨ (fact_9fdb227ae99d_3480 a b run_x) ∨ (fact_9fdb227ae99d_2927 a b run_x) ∨ (fact_9fdb227ae99d_2465 a b run_x) ∨ (fact_9fdb227ae99d_3000 a b run_x) ∨ (fact_9fdb227ae99d_2481 a b run_x) ∨ (fact_9fdb227ae99d_2943 a b run_x) ∨ (fact_9fdb227ae99d_2947 a b run_x)))
    (h5 : (b = (5 : Int)))
    (h6 : ((4 : Int) ≤ run_x))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n357_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((1 : Int) + a)))
    (h1 : (¬ ((fact_9fdb227ae99d_3178 a b run_x) ∨ (fact_9fdb227ae99d_3188 a b run_x) ∨ (fact_9fdb227ae99d_3730 a b run_x) ∨ (fact_9fdb227ae99d_5195 a b run_x) ∨ (fact_9fdb227ae99d_3489 a b run_x) ∨ (fact_9fdb227ae99d_3221 a b run_x) ∨ (fact_9fdb227ae99d_3573 a b run_x) ∨ (fact_9fdb227ae99d_3242 a b run_x) ∨ (fact_9fdb227ae99d_3550 a b run_x) ∨ (fact_9fdb227ae99d_3558 a b run_x))))
    (h2 : ((4 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n358_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((2 : Int) ≤ ((1 : Int) + b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n358_run_short (a b : Int)
    (h0 : (¬ ((((1 : Int) + b) - (2 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n358_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n358_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3363 a b) ∨ (fact_9fdb227ae99d_3370 a b) ∨ (fact_9fdb227ae99d_4405 a b) ∨ (fact_9fdb227ae99d_5544 a b) ∨ (fact_9fdb227ae99d_3733 a b) ∨ (fact_9fdb227ae99d_3395 a b) ∨ (((((-2 : Int) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) + a)) ∧ ((4 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((-2 : Int) ≥ ((2 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((2 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3738 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n358_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3750 a b) ∨ (fact_9fdb227ae99d_3782 a b) ∨ (fact_9fdb227ae99d_5160 a b) ∨ (fact_9fdb227ae99d_5838 a b) ∨ (fact_9fdb227ae99d_4533 a b) ∨ (fact_9fdb227ae99d_3919 a b) ∨ (((((-2 : Int) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) + a)) ∧ ((4 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((-2 : Int) ≥ (((1 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((-3 : Int) ≥ (((1 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_4552 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n358_run_tall (a b : Int)
    (h0 : (¬ (((((2 : Int) + (3 : Int)) ≤ ((1 : Int) + b)) ∧ ((fact_9fdb227ae99d_7377 a b) ∨ (fact_9fdb227ae99d_7445 a b))) ∨ ((((2 : Int) + (2 : Int)) ≤ ((1 : Int) + b)) ∧ (fact_9fdb227ae99d_7377 a b) ∧ (fact_9fdb227ae99d_7445 a b)) ∨ (((2 : Int) + (4 : Int)) ≤ ((1 : Int) + b)) ∨ ((((1 : Int) + b) = ((2 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7377 a b) ∧ (fact_9fdb227ae99d_7445 a b) ∧ (((fact_9fdb227ae99d_3754 a b) ∨ (fact_9fdb227ae99d_3786 a b) ∨ (fact_9fdb227ae99d_5164 a b) ∨ (fact_9fdb227ae99d_5842 a b) ∨ (fact_9fdb227ae99d_4536 a b) ∨ (fact_9fdb227ae99d_3923 a b) ∨ (fact_9fdb227ae99d_4836 a b) ∨ (fact_9fdb227ae99d_3993 a b) ∨ (fact_9fdb227ae99d_4553 a b)) ∨ ((fact_9fdb227ae99d_4571 a b) ∨ (fact_9fdb227ae99d_4606 a b) ∨ (fact_9fdb227ae99d_5638 a b) ∨ (fact_9fdb227ae99d_6379 a b) ∨ (fact_9fdb227ae99d_5375 a b) ∨ (fact_9fdb227ae99d_4779 a b) ∨ (fact_9fdb227ae99d_5488 a b) ∨ (fact_9fdb227ae99d_4858 a b) ∨ (fact_9fdb227ae99d_5393 a b)))) ∨ ((fact_9fdb227ae99d_7377 a b) ∧ (fact_9fdb227ae99d_7445 a b) ∧ ((fact_9fdb227ae99d_3754 a b) ∨ (fact_9fdb227ae99d_3786 a b) ∨ (fact_9fdb227ae99d_5164 a b) ∨ (fact_9fdb227ae99d_5842 a b) ∨ (fact_9fdb227ae99d_4536 a b) ∨ (fact_9fdb227ae99d_3923 a b) ∨ (fact_9fdb227ae99d_4836 a b) ∨ (fact_9fdb227ae99d_3993 a b) ∨ (fact_9fdb227ae99d_4553 a b)) ∧ ((fact_9fdb227ae99d_4571 a b) ∨ (fact_9fdb227ae99d_4606 a b) ∨ (fact_9fdb227ae99d_5638 a b) ∨ (fact_9fdb227ae99d_6379 a b) ∨ (fact_9fdb227ae99d_5375 a b) ∨ (fact_9fdb227ae99d_4779 a b) ∨ (fact_9fdb227ae99d_5488 a b) ∨ (fact_9fdb227ae99d_4858 a b) ∨ (fact_9fdb227ae99d_5393 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n358_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((2 : Int) ≤ run_x))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (run_x ≤ ((1 : Int) + b)))
    (h5 : (b = (5 : Int)))
    (h6 : ((fact_9fdb227ae99d_2367 a b run_x) ∨ (fact_9fdb227ae99d_2384 a b run_x) ∨ (fact_9fdb227ae99d_3040 a b run_x) ∨ (fact_9fdb227ae99d_3481 a b run_x) ∨ (fact_9fdb227ae99d_2928 a b run_x) ∨ (fact_9fdb227ae99d_2466 a b run_x) ∨ (fact_9fdb227ae99d_3001 a b run_x) ∨ (fact_9fdb227ae99d_2482 a b run_x) ∨ (fact_9fdb227ae99d_2930 a b run_x)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n358_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3179 a b run_x) ∨ (fact_9fdb227ae99d_3189 a b run_x) ∨ (fact_9fdb227ae99d_3731 a b run_x) ∨ (fact_9fdb227ae99d_5196 a b run_x) ∨ (fact_9fdb227ae99d_3490 a b run_x) ∨ (fact_9fdb227ae99d_3222 a b run_x) ∨ (fact_9fdb227ae99d_3574 a b run_x) ∨ (fact_9fdb227ae99d_3243 a b run_x) ∨ (fact_9fdb227ae99d_3492 a b run_x))))
    (h1 : (run_x ≤ ((1 : Int) + b)))
    (h2 : ((2 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n359_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_0 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n359_empty (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a ≥ b))
    (h2 : ((fact_9fdb227ae99d_3050 a b) ∨ (fact_9fdb227ae99d_3052 a b) ∨ (fact_9fdb227ae99d_3562 a b) ∨ (fact_9fdb227ae99d_4700 a b) ∨ (fact_9fdb227ae99d_3284 a b) ∨ (fact_9fdb227ae99d_3113 a b) ∨ (fact_9fdb227ae99d_3343 a b) ∨ ((((0 : Int) ≥ ((-3 : Int) - a)) ∧ ((0 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≥ ((1 : Int) + a))) ∨ (((-3 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (-3 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((1 : Int) + b)))) ∨ ((((0 : Int) ≥ ((2 : Int) - b)) ∧ ((0 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((2 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((((3 : Int) + a) - a) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int)))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n359_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_1604 a b jx jy))
    (h4 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h5 : (((jx + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h9 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n359_o1 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_1609 a b jx jy))
    (h5 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - a))))
    (h8 : ((jy - a) ≥ (0 : Int)))
    (h9 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - a))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n359_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_1613 a b jx jy))
    (h2 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - b))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - b))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n359_o3 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (fact_9fdb227ae99d_1616 a b jx jy))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n359_o4 (a b jx jy : Int)
    (h0 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - a))))
    (h2 : (fact_9fdb227ae99d_1617 a b jx jy))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - a))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n359_o5 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (fact_9fdb227ae99d_1612 a b jx jy))
    (h2 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (((jx + (0 : Int)) < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < (jx - a)) ∨ (jy < ((1 : Int) + a)) ∨ (((1 : Int) + a) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n359_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h8 : (fact_9fdb227ae99d_1608 a b jx jy))
    (h9 : (((jx + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n359_o7 (a b jx jy : Int)
    (h0 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - b))))
    (h1 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - b))))
    (h3 : (fact_9fdb227ae99d_1605 a b jx jy))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jy - b) ≥ (0 : Int)))
    (h8 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n360_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((-4 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((-4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b = (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n360_empty (a b : Int)
    (h0 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + a))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((fact_9fdb227ae99d_2874 a b) ∨ (fact_9fdb227ae99d_2877 a b) ∨ (fact_9fdb227ae99d_3263 a b) ∨ (fact_9fdb227ae99d_4170 a b) ∨ (fact_9fdb227ae99d_3105 a b) ∨ ((((-4 : Int) ≥ ((-1 : Int) - b)) ∧ ((-4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + a)))) ∨ ((((-4 : Int) ≥ ((-2 : Int) - b)) ∧ ((-4 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((1 : Int) + a)) ∧ ((2 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-2 : Int)) ∧ ((2 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((-4 : Int) ≥ ((-3 : Int) - a)) ∧ ((-4 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-3 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_2880 a b)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n360_o0 (a b jx jy : Int)
    (h0 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (¬ (((jx = ((-4 : Int) + ((-1 : Int) * a))) ∧ ((2 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n360_o1 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (fact_9fdb227ae99d_2923 a b jy))
    (h2 : (b = (5 : Int)))
    (h3 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - a))))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n360_o2 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (¬ ((((-4 : Int) = jx) ∧ (jy = ((2 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n360_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h3 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h4 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n360_o4 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (fact_9fdb227ae99d_2922 a b jy))
    (h6 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - a))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n360_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((jx < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h4 : (¬ ((((-4 : Int) = jx) ∧ ((2 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h6 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n360_o6 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h3 : (¬ (((jx = ((-4 : Int) + ((-1 : Int) * b))) ∧ ((2 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (b = (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((-3 : Int) > (jx + b)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n360_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n361_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((-4 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((-4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n361_empty (a b : Int)
    (h0 : (((((2 : Int) + a) + (0 : Int)) < ((-4 : Int) + ((-1 : Int) * a))) ∨ (((-4 : Int) + ((-1 : Int) * a)) < (((2 : Int) + a) - a)) ∨ ((2 : Int) < ((2 : Int) - (0 : Int))) ∨ ((2 : Int) > ((2 : Int) + b))))
    (h1 : ((fact_9fdb227ae99d_2875 a b) ∨ (fact_9fdb227ae99d_2878 a b) ∨ (fact_9fdb227ae99d_3264 a b) ∨ (fact_9fdb227ae99d_4171 a b) ∨ (fact_9fdb227ae99d_3106 a b) ∨ (fact_9fdb227ae99d_2966 a b) ∨ ((((-4 : Int) ≥ ((-2 : Int) - b)) ∧ ((-4 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) + a)) ∧ ((3 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-2 : Int)) ∧ ((3 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((-4 : Int) ≥ ((-3 : Int) - a)) ∧ ((-4 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-3 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_2881 a b) ∨ (fact_9fdb227ae99d_4397 a b)))
    (h2 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + a))))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n361_o0 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h5 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (((jx + a) < ((-4 : Int) + ((-1 : Int) * a))) ∨ (((-4 : Int) + ((-1 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n361_o1 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_9fdb227ae99d_2923 a b jy))
    (h7 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - a))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n361_o2 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (b = (5 : Int)))
    (h2 : (((jx + (0 : Int)) < ((-4 : Int) + ((-1 : Int) * a))) ∨ (((-4 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h3 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - b))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n361_o3 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n361_o4 (a b jx jy : Int)
    (h0 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - a))))
    (h1 : (fact_9fdb227ae99d_2922 a b jy))
    (h2 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n361_o5 (a b jx jy : Int)
    (h0 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h2 : (b = (5 : Int)))
    (h3 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((jx + (0 : Int)) < ((-4 : Int) + ((-1 : Int) * a))) ∨ (((-4 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n361_o6 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ (((jx = ((-4 : Int) + ((-1 : Int) * b))) ∧ ((3 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h5 : (((-3 : Int) > (jx + b)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h6 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h7 : (b = (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n361_o7 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h5 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n362_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((-4 : Int) ≥ ((-3 : Int) + ((-1 : Int) * b)))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n362_run_short (a b : Int)
    (h0 : (¬ (((-4 : Int) - ((-3 : Int) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n362_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n362_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5687 a b) ∨ (fact_9fdb227ae99d_5700 a b) ∨ (fact_9fdb227ae99d_6368 a b) ∨ (fact_9fdb227ae99d_6964 a b) ∨ (fact_9fdb227ae99d_5994 a b) ∨ (fact_9fdb227ae99d_5762 a b) ∨ (((((-2 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) + a)) ∧ ((4 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((4 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_5707 a b) ∨ (fact_9fdb227ae99d_6981 a b) ∨ (fact_9fdb227ae99d_6986 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n362_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3416 a b) ∨ (fact_9fdb227ae99d_3434 a b) ∨ (fact_9fdb227ae99d_4509 a b) ∨ (fact_9fdb227ae99d_5593 a b) ∨ (fact_9fdb227ae99d_3881 a b) ∨ (fact_9fdb227ae99d_3509 a b) ∨ (((((-2 : Int) - b) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) + a)) ∧ ((4 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-2 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-3 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3448 a b) ∨ (fact_9fdb227ae99d_5726 a b) ∨ (fact_9fdb227ae99d_5729 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n362_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ ((((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7900 a b) ∨ (fact_9fdb227ae99d_7678 a b))) ∨ (((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (2 : Int))) ∧ (fact_9fdb227ae99d_7900 a b) ∧ (fact_9fdb227ae99d_7678 a b)) ∨ ((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (4 : Int))) ∨ (((-4 : Int) = (((-3 : Int) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_9fdb227ae99d_7900 a b) ∧ (fact_9fdb227ae99d_7678 a b) ∧ (((fact_9fdb227ae99d_6035 a b) ∨ (fact_9fdb227ae99d_6073 a b) ∨ (fact_9fdb227ae99d_6835 a b) ∨ (fact_9fdb227ae99d_7047 a b) ∨ (fact_9fdb227ae99d_6601 a b) ∨ (fact_9fdb227ae99d_6245 a b) ∨ (fact_9fdb227ae99d_6707 a b) ∨ (fact_9fdb227ae99d_6293 a b) ∨ (fact_9fdb227ae99d_6097 a b) ∨ (fact_9fdb227ae99d_7099 a b) ∨ (fact_9fdb227ae99d_7111 a b)) ∨ ((fact_9fdb227ae99d_4075 a b) ∨ (fact_9fdb227ae99d_4103 a b) ∨ (fact_9fdb227ae99d_5309 a b) ∨ (fact_9fdb227ae99d_5924 a b) ∨ (fact_9fdb227ae99d_4738 a b) ∨ (fact_9fdb227ae99d_4236 a b) ∨ (fact_9fdb227ae99d_5077 a b) ∨ (fact_9fdb227ae99d_4284 a b) ∨ (fact_9fdb227ae99d_4117 a b) ∨ (fact_9fdb227ae99d_6162 a b) ∨ (fact_9fdb227ae99d_6168 a b)))) ∨ ((fact_9fdb227ae99d_7900 a b) ∧ (fact_9fdb227ae99d_7678 a b) ∧ ((fact_9fdb227ae99d_6035 a b) ∨ (fact_9fdb227ae99d_6073 a b) ∨ (fact_9fdb227ae99d_6835 a b) ∨ (fact_9fdb227ae99d_7047 a b) ∨ (fact_9fdb227ae99d_6601 a b) ∨ (fact_9fdb227ae99d_6245 a b) ∨ (fact_9fdb227ae99d_6707 a b) ∨ (fact_9fdb227ae99d_6293 a b) ∨ (fact_9fdb227ae99d_6097 a b) ∨ (fact_9fdb227ae99d_7099 a b) ∨ (fact_9fdb227ae99d_7111 a b)) ∧ ((fact_9fdb227ae99d_4075 a b) ∨ (fact_9fdb227ae99d_4103 a b) ∨ (fact_9fdb227ae99d_5309 a b) ∨ (fact_9fdb227ae99d_5924 a b) ∨ (fact_9fdb227ae99d_4738 a b) ∨ (fact_9fdb227ae99d_4236 a b) ∨ (fact_9fdb227ae99d_5077 a b) ∨ (fact_9fdb227ae99d_4284 a b) ∨ (fact_9fdb227ae99d_4117 a b) ∨ (fact_9fdb227ae99d_6162 a b) ∨ (fact_9fdb227ae99d_6168 a b))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n362_run_empty (a b run_x : Int)
    (h0 : ((fact_9fdb227ae99d_2367 a b run_x) ∨ (fact_9fdb227ae99d_2384 a b run_x) ∨ (fact_9fdb227ae99d_3040 a b run_x) ∨ (fact_9fdb227ae99d_3481 a b run_x) ∨ (fact_9fdb227ae99d_2928 a b run_x) ∨ (fact_9fdb227ae99d_2466 a b run_x) ∨ (fact_9fdb227ae99d_3001 a b run_x) ∨ (fact_9fdb227ae99d_2482 a b run_x) ∨ (fact_9fdb227ae99d_2398 a b run_x) ∨ (fact_9fdb227ae99d_3613 a b run_x) ∨ (fact_9fdb227ae99d_3616 a b run_x)))
    (h1 : ((-4 : Int) ≥ run_x))
    (h2 : (((-3 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n362_run_floor (a b run_x : Int)
    (h0 : (((-3 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h1 : (¬ ((fact_9fdb227ae99d_3179 a b run_x) ∨ (fact_9fdb227ae99d_3189 a b run_x) ∨ (fact_9fdb227ae99d_3731 a b run_x) ∨ (fact_9fdb227ae99d_5196 a b run_x) ∨ (fact_9fdb227ae99d_3490 a b run_x) ∨ (fact_9fdb227ae99d_3222 a b run_x) ∨ (fact_9fdb227ae99d_3574 a b run_x) ∨ (fact_9fdb227ae99d_3243 a b run_x) ∨ (fact_9fdb227ae99d_3197 a b run_x) ∨ (fact_9fdb227ae99d_5360 a b run_x) ∨ (fact_9fdb227ae99d_5363 a b run_x))))
    (h2 : ((-4 : Int) ≥ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n363_run_four (a b : Int)
    (h0 : (¬ ((2 : Int) ≤ ((-1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n363_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((-1 : Int) + a) - (2 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

end LRegionArithmetic

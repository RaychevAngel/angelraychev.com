import LQuadrantHpOptimizedUnequalNestedShortBfiveDeltaTwoPrunedArithmeticDefs
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace LRegionArithmetic

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n475_o2 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - b))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (fact_9fdb227ae99d_1613 a b jx jy))
    (h5 : ((jx < ((3 : Int) - b)) ∨ (((3 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - b))))
    (h6 : (a ≥ b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a > b))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n475_o3 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : (fact_9fdb227ae99d_1616 a b jx jy))
    (h5 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n475_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : ((jx < ((3 : Int) - b)) ∨ (((3 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h7 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h8 : (fact_9fdb227ae99d_1617 a b jx jy))
    (h9 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - a))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n475_o5 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1612 a b jx jy))
    (h1 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((jx < ((3 : Int) - b)) ∨ (((3 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - (0 : Int)))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n475_o6 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_1608 a b jx jy))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : (b = (5 : Int)))
    (h5 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n475_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - b))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (fact_9fdb227ae99d_1605 a b jx jy))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b = (5 : Int)))
    (h7 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h8 : ((jx < ((3 : Int) - b)) ∨ (((3 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - b))))
    (h9 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n476_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n476_run_short (a b : Int)
    (h0 : (¬ ((((1 : Int) + a) - (4 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n476_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n476_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3368 a b) ∨ (fact_9fdb227ae99d_3375 a b) ∨ (fact_9fdb227ae99d_4410 a b) ∨ (fact_9fdb227ae99d_5549 a b) ∨ (fact_9fdb227ae99d_3737 a b) ∨ (fact_9fdb227ae99d_3394 a b) ∨ (fact_9fdb227ae99d_3409 a b) ∨ (((((-3 : Int) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) + a)) ∧ ((5 : Int) ≤ ((2 : Int) + a))) ∨ (((-3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3377 a b) ∨ (((((-4 : Int) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((-4 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((-4 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3378 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n476_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3749 a b) ∨ (fact_9fdb227ae99d_3781 a b) ∨ (fact_9fdb227ae99d_5159 a b) ∨ (fact_9fdb227ae99d_5837 a b) ∨ (fact_9fdb227ae99d_4532 a b) ∨ (fact_9fdb227ae99d_3897 a b) ∨ (fact_9fdb227ae99d_3965 a b) ∨ (((((-3 : Int) - b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) + a)) ∧ ((5 : Int) ≤ ((2 : Int) + a))) ∨ (((-3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((-3 : Int) ≥ (((1 : Int) + a) + (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3811 a b) ∨ (((((-4 : Int) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((-4 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((-4 : Int) ≥ (((1 : Int) + a) + (1 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3829 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n476_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_9fdb227ae99d_7611 a b) ∨ (fact_9fdb227ae99d_7701 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ (fact_9fdb227ae99d_7611 a b) ∧ (fact_9fdb227ae99d_7701 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = ((4 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7611 a b) ∧ (fact_9fdb227ae99d_7701 a b) ∧ (((fact_9fdb227ae99d_3773 a b) ∨ (fact_9fdb227ae99d_3805 a b) ∨ (fact_9fdb227ae99d_5183 a b) ∨ (fact_9fdb227ae99d_5861 a b) ∨ (fact_9fdb227ae99d_4548 a b) ∨ (fact_9fdb227ae99d_3913 a b) ∨ (fact_9fdb227ae99d_3987 a b) ∨ (fact_9fdb227ae99d_4913 a b) ∨ (fact_9fdb227ae99d_3823 a b) ∨ (fact_9fdb227ae99d_4045 a b) ∨ (fact_9fdb227ae99d_3836 a b)) ∨ ((fact_9fdb227ae99d_4569 a b) ∨ (fact_9fdb227ae99d_4604 a b) ∨ (fact_9fdb227ae99d_5636 a b) ∨ (fact_9fdb227ae99d_6377 a b) ∨ (fact_9fdb227ae99d_5373 a b) ∨ (fact_9fdb227ae99d_4755 a b) ∨ (fact_9fdb227ae99d_4818 a b) ∨ (fact_9fdb227ae99d_5495 a b) ∨ (fact_9fdb227ae99d_4637 a b) ∨ (fact_9fdb227ae99d_4921 a b) ∨ (fact_9fdb227ae99d_4677 a b)))) ∨ ((fact_9fdb227ae99d_7611 a b) ∧ (fact_9fdb227ae99d_7701 a b) ∧ ((fact_9fdb227ae99d_3773 a b) ∨ (fact_9fdb227ae99d_3805 a b) ∨ (fact_9fdb227ae99d_5183 a b) ∨ (fact_9fdb227ae99d_5861 a b) ∨ (fact_9fdb227ae99d_4548 a b) ∨ (fact_9fdb227ae99d_3913 a b) ∨ (fact_9fdb227ae99d_3987 a b) ∨ (fact_9fdb227ae99d_4913 a b) ∨ (fact_9fdb227ae99d_3823 a b) ∨ (fact_9fdb227ae99d_4045 a b) ∨ (fact_9fdb227ae99d_3836 a b)) ∧ ((fact_9fdb227ae99d_4569 a b) ∨ (fact_9fdb227ae99d_4604 a b) ∨ (fact_9fdb227ae99d_5636 a b) ∨ (fact_9fdb227ae99d_6377 a b) ∨ (fact_9fdb227ae99d_5373 a b) ∨ (fact_9fdb227ae99d_4755 a b) ∨ (fact_9fdb227ae99d_4818 a b) ∨ (fact_9fdb227ae99d_5495 a b) ∨ (fact_9fdb227ae99d_4637 a b) ∨ (fact_9fdb227ae99d_4921 a b) ∨ (fact_9fdb227ae99d_4677 a b))))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n476_run_empty (a b run_x : Int)
    (h0 : ((4 : Int) ≤ run_x))
    (h1 : (run_x ≤ ((1 : Int) + a)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((fact_9fdb227ae99d_2368 a b run_x) ∨ (fact_9fdb227ae99d_2385 a b run_x) ∨ (fact_9fdb227ae99d_3041 a b run_x) ∨ (fact_9fdb227ae99d_3482 a b run_x) ∨ (fact_9fdb227ae99d_2929 a b run_x) ∨ (fact_9fdb227ae99d_2463 a b run_x) ∨ (fact_9fdb227ae99d_2478 a b run_x) ∨ (fact_9fdb227ae99d_3005 a b run_x) ∨ (fact_9fdb227ae99d_2399 a b run_x) ∨ (fact_9fdb227ae99d_2495 a b run_x) ∨ (fact_9fdb227ae99d_2402 a b run_x)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n476_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3180 a b run_x) ∨ (fact_9fdb227ae99d_3190 a b run_x) ∨ (fact_9fdb227ae99d_3732 a b run_x) ∨ (fact_9fdb227ae99d_5197 a b run_x) ∨ (fact_9fdb227ae99d_3491 a b run_x) ∨ (fact_9fdb227ae99d_3216 a b run_x) ∨ (fact_9fdb227ae99d_3238 a b run_x) ∨ (fact_9fdb227ae99d_3577 a b run_x) ∨ (fact_9fdb227ae99d_3198 a b run_x) ∨ (fact_9fdb227ae99d_3252 a b run_x) ∨ (fact_9fdb227ae99d_3201 a b run_x))))
    (h1 : ((4 : Int) ≤ run_x))
    (h2 : (run_x ≤ ((1 : Int) + a)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n477_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((4 : Int) ≤ ((1 : Int) + a))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n477_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((1 : Int) + a) - (4 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n477_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n477_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3383 a b) ∨ (fact_9fdb227ae99d_3384 a b) ∨ (fact_9fdb227ae99d_4498 a b) ∨ (fact_9fdb227ae99d_5585 a b) ∨ (fact_9fdb227ae99d_3854 a b) ∨ (fact_9fdb227ae99d_3470 a b) ∨ (fact_9fdb227ae99d_3473 a b) ∨ ((((4 : Int) ≥ ((-3 : Int) - b)) ∧ ((4 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((-3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3385 a b) ∨ ((((4 : Int) ≥ ((-4 : Int) - a)) ∧ ((4 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((-4 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-4 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3861 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n477_run_right (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (¬ ((fact_9fdb227ae99d_3855 a b) ∨ (fact_9fdb227ae99d_3857 a b) ∨ (fact_9fdb227ae99d_5287 a b) ∨ (fact_9fdb227ae99d_5902 a b) ∨ (fact_9fdb227ae99d_4708 a b) ∨ (fact_9fdb227ae99d_4182 a b) ∨ (fact_9fdb227ae99d_4184 a b) ∨ ((((4 : Int) ≥ ((-3 : Int) - b)) ∧ ((4 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((-3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3859 a b) ∨ ((((4 : Int) ≥ ((-4 : Int) - a)) ∧ ((4 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-4 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-4 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_4710 a b))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n477_run_tall (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_9fdb227ae99d_7629 a b) ∨ (fact_9fdb227ae99d_7725 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ (fact_9fdb227ae99d_7629 a b) ∧ (fact_9fdb227ae99d_7725 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = ((4 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7629 a b) ∧ (fact_9fdb227ae99d_7725 a b) ∧ (((fact_9fdb227ae99d_3765 a b) ∨ (fact_9fdb227ae99d_3797 a b) ∨ (fact_9fdb227ae99d_5175 a b) ∨ (fact_9fdb227ae99d_5853 a b) ∨ (fact_9fdb227ae99d_4544 a b) ∨ (fact_9fdb227ae99d_3909 a b) ∨ (fact_9fdb227ae99d_3983 a b) ∨ (fact_9fdb227ae99d_4905 a b) ∨ (fact_9fdb227ae99d_3817 a b) ∨ (fact_9fdb227ae99d_4043 a b) ∨ (fact_9fdb227ae99d_4684 a b)) ∨ ((fact_9fdb227ae99d_4592 a b) ∨ (fact_9fdb227ae99d_4627 a b) ∨ (fact_9fdb227ae99d_5657 a b) ∨ (fact_9fdb227ae99d_6396 a b) ∨ (fact_9fdb227ae99d_5385 a b) ∨ (fact_9fdb227ae99d_4767 a b) ∨ (fact_9fdb227ae99d_4842 a b) ∨ (fact_9fdb227ae99d_5506 a b) ∨ (fact_9fdb227ae99d_4656 a b) ∨ (fact_9fdb227ae99d_4931 a b) ∨ (fact_9fdb227ae99d_5435 a b)))) ∨ ((fact_9fdb227ae99d_7629 a b) ∧ (fact_9fdb227ae99d_7725 a b) ∧ ((fact_9fdb227ae99d_3765 a b) ∨ (fact_9fdb227ae99d_3797 a b) ∨ (fact_9fdb227ae99d_5175 a b) ∨ (fact_9fdb227ae99d_5853 a b) ∨ (fact_9fdb227ae99d_4544 a b) ∨ (fact_9fdb227ae99d_3909 a b) ∨ (fact_9fdb227ae99d_3983 a b) ∨ (fact_9fdb227ae99d_4905 a b) ∨ (fact_9fdb227ae99d_3817 a b) ∨ (fact_9fdb227ae99d_4043 a b) ∨ (fact_9fdb227ae99d_4684 a b)) ∧ ((fact_9fdb227ae99d_4592 a b) ∨ (fact_9fdb227ae99d_4627 a b) ∨ (fact_9fdb227ae99d_5657 a b) ∨ (fact_9fdb227ae99d_6396 a b) ∨ (fact_9fdb227ae99d_5385 a b) ∨ (fact_9fdb227ae99d_4767 a b) ∨ (fact_9fdb227ae99d_4842 a b) ∨ (fact_9fdb227ae99d_5506 a b) ∨ (fact_9fdb227ae99d_4656 a b) ∨ (fact_9fdb227ae99d_4931 a b) ∨ (fact_9fdb227ae99d_5435 a b))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n477_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (run_x ≤ ((1 : Int) + a)))
    (h4 : ((4 : Int) ≤ run_x))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : ((fact_9fdb227ae99d_2446 a b run_x) ∨ (fact_9fdb227ae99d_2447 a b run_x) ∨ (fact_9fdb227ae99d_3070 a b run_x) ∨ (fact_9fdb227ae99d_3571 a b run_x) ∨ (fact_9fdb227ae99d_2982 a b run_x) ∨ (fact_9fdb227ae99d_2535 a b run_x) ∨ (fact_9fdb227ae99d_2538 a b run_x) ∨ ((((4 : Int) ≥ ((-3 : Int) - b)) ∧ ((4 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((-3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_2448 a b run_x) ∨ ((((4 : Int) ≥ ((-4 : Int) - a)) ∧ ((4 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-4 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-4 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_2983 a b run_x)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n477_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3174 a b run_x) ∨ (fact_9fdb227ae99d_3184 a b run_x) ∨ (fact_9fdb227ae99d_3727 a b run_x) ∨ (fact_9fdb227ae99d_5192 a b run_x) ∨ (fact_9fdb227ae99d_3486 a b run_x) ∨ (fact_9fdb227ae99d_3212 a b run_x) ∨ (fact_9fdb227ae99d_3234 a b run_x) ∨ (((((-3 : Int) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((-3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3193 a b run_x) ∨ (((((-4 : Int) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-4 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((-4 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3556 a b run_x))))
    (h1 : (run_x ≤ ((1 : Int) + a)))
    (h2 : ((4 : Int) ≤ run_x))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n478_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((-4 : Int) ≥ ((-3 : Int) + ((-1 : Int) * b)))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n478_run_short (a b : Int)
    (h0 : (¬ (((-4 : Int) - ((-3 : Int) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n478_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n478_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_5686 a b) ∨ (fact_9fdb227ae99d_5699 a b) ∨ (fact_9fdb227ae99d_6367 a b) ∨ (fact_9fdb227ae99d_6963 a b) ∨ (fact_9fdb227ae99d_5993 a b) ∨ (((((-1 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)))) ∨ (((((-3 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) + a)) ∧ ((3 : Int) ≤ ((2 : Int) + a))) ∨ (((-3 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_5706 a b) ∨ (fact_9fdb227ae99d_6985 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n478_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3415 a b) ∨ (fact_9fdb227ae99d_3433 a b) ∨ (fact_9fdb227ae99d_4508 a b) ∨ (fact_9fdb227ae99d_5592 a b) ∨ (fact_9fdb227ae99d_3880 a b) ∨ (((((-1 : Int) - a) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-2 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)))) ∨ (((((-3 : Int) - b) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) + a)) ∧ ((3 : Int) ≤ ((2 : Int) + a))) ∨ (((-3 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-3 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3447 a b) ∨ (fact_9fdb227ae99d_5728 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n478_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ ((((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7786 a b) ∨ (fact_9fdb227ae99d_7530 a b))) ∨ (((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (2 : Int))) ∧ (fact_9fdb227ae99d_7786 a b) ∧ (fact_9fdb227ae99d_7530 a b)) ∨ ((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (4 : Int))) ∨ (((-4 : Int) = (((-3 : Int) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_9fdb227ae99d_7786 a b) ∧ (fact_9fdb227ae99d_7530 a b) ∧ (((fact_9fdb227ae99d_6033 a b) ∨ (fact_9fdb227ae99d_6071 a b) ∨ (fact_9fdb227ae99d_6833 a b) ∨ (fact_9fdb227ae99d_7045 a b) ∨ (fact_9fdb227ae99d_6599 a b) ∨ (fact_9fdb227ae99d_6212 a b) ∨ (fact_9fdb227ae99d_6277 a b) ∨ (fact_9fdb227ae99d_6726 a b) ∨ (fact_9fdb227ae99d_6095 a b) ∨ (fact_9fdb227ae99d_7109 a b)) ∨ ((fact_9fdb227ae99d_4073 a b) ∨ (fact_9fdb227ae99d_4101 a b) ∨ (fact_9fdb227ae99d_5307 a b) ∨ (fact_9fdb227ae99d_5922 a b) ∨ (fact_9fdb227ae99d_4736 a b) ∨ (fact_9fdb227ae99d_4210 a b) ∨ (fact_9fdb227ae99d_4264 a b) ∨ (fact_9fdb227ae99d_5086 a b) ∨ (fact_9fdb227ae99d_4115 a b) ∨ (fact_9fdb227ae99d_6166 a b)))) ∨ ((fact_9fdb227ae99d_7786 a b) ∧ (fact_9fdb227ae99d_7530 a b) ∧ ((fact_9fdb227ae99d_6033 a b) ∨ (fact_9fdb227ae99d_6071 a b) ∨ (fact_9fdb227ae99d_6833 a b) ∨ (fact_9fdb227ae99d_7045 a b) ∨ (fact_9fdb227ae99d_6599 a b) ∨ (fact_9fdb227ae99d_6212 a b) ∨ (fact_9fdb227ae99d_6277 a b) ∨ (fact_9fdb227ae99d_6726 a b) ∨ (fact_9fdb227ae99d_6095 a b) ∨ (fact_9fdb227ae99d_7109 a b)) ∧ ((fact_9fdb227ae99d_4073 a b) ∨ (fact_9fdb227ae99d_4101 a b) ∨ (fact_9fdb227ae99d_5307 a b) ∨ (fact_9fdb227ae99d_5922 a b) ∨ (fact_9fdb227ae99d_4736 a b) ∨ (fact_9fdb227ae99d_4210 a b) ∨ (fact_9fdb227ae99d_4264 a b) ∨ (fact_9fdb227ae99d_5086 a b) ∨ (fact_9fdb227ae99d_4115 a b) ∨ (fact_9fdb227ae99d_6166 a b))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n478_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : ((-4 : Int) ≥ run_x))
    (h3 : (((-3 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((fact_9fdb227ae99d_2366 a b run_x) ∨ (fact_9fdb227ae99d_2383 a b run_x) ∨ (fact_9fdb227ae99d_3039 a b run_x) ∨ (fact_9fdb227ae99d_3480 a b run_x) ∨ (fact_9fdb227ae99d_2927 a b run_x) ∨ (fact_9fdb227ae99d_2461 a b run_x) ∨ (fact_9fdb227ae99d_2476 a b run_x) ∨ (fact_9fdb227ae99d_3002 a b run_x) ∨ (fact_9fdb227ae99d_2397 a b run_x) ∨ (fact_9fdb227ae99d_3615 a b run_x)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n478_run_floor (a b run_x : Int)
    (h0 : (((-3 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h1 : ((-4 : Int) ≥ run_x))
    (h2 : (¬ ((fact_9fdb227ae99d_3178 a b run_x) ∨ (fact_9fdb227ae99d_3188 a b run_x) ∨ (fact_9fdb227ae99d_3730 a b run_x) ∨ (fact_9fdb227ae99d_5195 a b run_x) ∨ (fact_9fdb227ae99d_3489 a b run_x) ∨ (fact_9fdb227ae99d_3214 a b run_x) ∨ (fact_9fdb227ae99d_3236 a b run_x) ∨ (fact_9fdb227ae99d_3575 a b run_x) ∨ (fact_9fdb227ae99d_3196 a b run_x) ∨ (fact_9fdb227ae99d_5362 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n479_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≤ a)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n479_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((a - (3 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n479_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n479_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3381 a b) ∨ (fact_9fdb227ae99d_3382 a b) ∨ (fact_9fdb227ae99d_4497 a b) ∨ (fact_9fdb227ae99d_5584 a b) ∨ (fact_9fdb227ae99d_3851 a b) ∨ (fact_9fdb227ae99d_3466 a b) ∨ (fact_9fdb227ae99d_3469 a b) ∨ ((((3 : Int) ≥ ((-3 : Int) - b)) ∧ ((3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((-3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3852 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n479_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3067 a b) ∨ (fact_9fdb227ae99d_3068 a b) ∨ (fact_9fdb227ae99d_3569 a b) ∨ (fact_9fdb227ae99d_4707 a b) ∨ (fact_9fdb227ae99d_3300 a b) ∨ (fact_9fdb227ae99d_3120 a b) ∨ (fact_9fdb227ae99d_3123 a b) ∨ ((((3 : Int) ≥ ((-3 : Int) - b)) ∧ ((3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((-3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3301 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n479_run_tall (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a > b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_9fdb227ae99d_7381 a b) ∨ (fact_9fdb227ae99d_7296 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_9fdb227ae99d_7381 a b) ∧ (fact_9fdb227ae99d_7296 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7381 a b) ∧ (fact_9fdb227ae99d_7296 a b) ∧ (((fact_9fdb227ae99d_3756 a b) ∨ (fact_9fdb227ae99d_3788 a b) ∨ (fact_9fdb227ae99d_5166 a b) ∨ (fact_9fdb227ae99d_5844 a b) ∨ (fact_9fdb227ae99d_4538 a b) ∨ (fact_9fdb227ae99d_3903 a b) ∨ (fact_9fdb227ae99d_3973 a b) ∨ (fact_9fdb227ae99d_4899 a b) ∨ (fact_9fdb227ae99d_4649 a b)) ∨ ((fact_9fdb227ae99d_3268 a b) ∨ (fact_9fdb227ae99d_3274 a b) ∨ (fact_9fdb227ae99d_4193 a b) ∨ (fact_9fdb227ae99d_5365 a b) ∨ (fact_9fdb227ae99d_3618 a b) ∨ (fact_9fdb227ae99d_3302 a b) ∨ (fact_9fdb227ae99d_3309 a b) ∨ (fact_9fdb227ae99d_3709 a b) ∨ (fact_9fdb227ae99d_3650 a b)))) ∨ ((fact_9fdb227ae99d_7381 a b) ∧ (fact_9fdb227ae99d_7296 a b) ∧ ((fact_9fdb227ae99d_3756 a b) ∨ (fact_9fdb227ae99d_3788 a b) ∨ (fact_9fdb227ae99d_5166 a b) ∨ (fact_9fdb227ae99d_5844 a b) ∨ (fact_9fdb227ae99d_4538 a b) ∨ (fact_9fdb227ae99d_3903 a b) ∨ (fact_9fdb227ae99d_3973 a b) ∨ (fact_9fdb227ae99d_4899 a b) ∨ (fact_9fdb227ae99d_4649 a b)) ∧ ((fact_9fdb227ae99d_3268 a b) ∨ (fact_9fdb227ae99d_3274 a b) ∨ (fact_9fdb227ae99d_4193 a b) ∨ (fact_9fdb227ae99d_5365 a b) ∨ (fact_9fdb227ae99d_3618 a b) ∨ (fact_9fdb227ae99d_3302 a b) ∨ (fact_9fdb227ae99d_3309 a b) ∨ (fact_9fdb227ae99d_3709 a b) ∨ (fact_9fdb227ae99d_3650 a b))))))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n479_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((fact_9fdb227ae99d_2444 a b run_x) ∨ (fact_9fdb227ae99d_2445 a b run_x) ∨ (fact_9fdb227ae99d_3064 a b run_x) ∨ (fact_9fdb227ae99d_3570 a b run_x) ∨ (fact_9fdb227ae99d_2980 a b run_x) ∨ (fact_9fdb227ae99d_2531 a b run_x) ∨ (fact_9fdb227ae99d_2534 a b run_x) ∨ ((((3 : Int) ≥ ((-3 : Int) - b)) ∧ ((3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((-3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_2981 a b run_x)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((3 : Int) ≤ run_x))
    (h6 : (b = (5 : Int)))
    (h7 : (run_x ≤ a))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n479_run_floor (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (run_x ≤ a))
    (h2 : (¬ ((fact_9fdb227ae99d_3173 a b run_x) ∨ (fact_9fdb227ae99d_3183 a b run_x) ∨ (fact_9fdb227ae99d_3726 a b run_x) ∨ (fact_9fdb227ae99d_5191 a b run_x) ∨ (fact_9fdb227ae99d_3485 a b run_x) ∨ (fact_9fdb227ae99d_3211 a b run_x) ∨ (fact_9fdb227ae99d_3233 a b run_x) ∨ (((((-3 : Int) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((-3 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3549 a b run_x))))
    (h3 : ((3 : Int) ≤ run_x))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n480_point (a b : Int)
    (h0 : (¬ (((2 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n480_empty (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b = (5 : Int)))
    (h2 : ((fact_9fdb227ae99d_2817 a b) ∨ (fact_9fdb227ae99d_2818 a b) ∨ (fact_9fdb227ae99d_3202 a b) ∨ (fact_9fdb227ae99d_3848 a b) ∨ (fact_9fdb227ae99d_3060 a b) ∨ (fact_9fdb227ae99d_2894 a b) ∨ (fact_9fdb227ae99d_2897 a b) ∨ ((((2 : Int) ≥ ((-3 : Int) - a)) ∧ ((2 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-3 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n480_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h5 : (b = (5 : Int)))
    (h6 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n480_o1 (a b jx jy : Int)
    (h0 : (¬ ((((2 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n480_o2 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : ((((2 : Int) ≥ (jx - a)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n480_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((2 : Int) ≥ (jx - b)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h4 : (b = (5 : Int)))
    (h5 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (¬ (((jx = ((2 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n480_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((((2 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h6 : ((((2 : Int) ≥ (jx - b)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n480_o5 (a b jx jy : Int)
    (h0 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((((2 : Int) ≥ (jx - a)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((jx < ((2 : Int) + a)) ∨ (((2 : Int) + a) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h7 : (b = (5 : Int)))
    (h8 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n480_o6 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : (¬ ((((2 : Int) = jx) ∧ ((3 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b = (5 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n480_o7 (a b jx jy : Int)
    (h0 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h1 : (¬ ((((2 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b = (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jy - b) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n481_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ (((3 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n481_empty (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((fact_9fdb227ae99d_2819 a b) ∨ (fact_9fdb227ae99d_2821 a b) ∨ (fact_9fdb227ae99d_3203 a b) ∨ (fact_9fdb227ae99d_3849 a b) ∨ (fact_9fdb227ae99d_3065 a b) ∨ (fact_9fdb227ae99d_2898 a b) ∨ (fact_9fdb227ae99d_2904 a b) ∨ ((((3 : Int) ≥ ((-3 : Int) - a)) ∧ ((3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-3 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3069 a b)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n481_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h2 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b = (5 : Int)))
    (h5 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n481_o1 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h3 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - a))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n481_o2 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n481_o3 (a b jx jy : Int)
    (h0 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (¬ (((jx = ((3 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h8 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n481_o4 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h5 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n481_o5 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (((jx + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h9 : (b = (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n481_o6 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((jy + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n481_o7 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ ((((3 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h3 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n482_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((3 : Int) ≤ ((2 : Int) + b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n482_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + b) - (3 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n482_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n482_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3364 a b) ∨ (fact_9fdb227ae99d_3371 a b) ∨ (fact_9fdb227ae99d_4406 a b) ∨ (fact_9fdb227ae99d_5545 a b) ∨ (fact_9fdb227ae99d_3734 a b) ∨ (fact_9fdb227ae99d_3391 a b) ∨ (fact_9fdb227ae99d_3406 a b) ∨ (((((-3 : Int) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3816 a b) ∨ (fact_9fdb227ae99d_3739 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n482_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3751 a b) ∨ (fact_9fdb227ae99d_3783 a b) ∨ (fact_9fdb227ae99d_5161 a b) ∨ (fact_9fdb227ae99d_5839 a b) ∨ (fact_9fdb227ae99d_4534 a b) ∨ (fact_9fdb227ae99d_3899 a b) ∨ (fact_9fdb227ae99d_3967 a b) ∨ (((((-3 : Int) - a) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((-3 : Int) ≥ (((2 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_4643 a b) ∨ (fact_9fdb227ae99d_4557 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n482_run_tall (a b : Int)
    (h0 : (¬ (((((3 : Int) + (3 : Int)) ≤ ((2 : Int) + b)) ∧ ((fact_9fdb227ae99d_7480 a b) ∨ (fact_9fdb227ae99d_7595 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ ((2 : Int) + b)) ∧ (fact_9fdb227ae99d_7480 a b) ∧ (fact_9fdb227ae99d_7595 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ ((2 : Int) + b)) ∨ ((((2 : Int) + b) = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7480 a b) ∧ (fact_9fdb227ae99d_7595 a b) ∧ (((fact_9fdb227ae99d_3759 a b) ∨ (fact_9fdb227ae99d_3791 a b) ∨ (fact_9fdb227ae99d_5169 a b) ∨ (fact_9fdb227ae99d_5847 a b) ∨ (fact_9fdb227ae99d_4540 a b) ∨ (fact_9fdb227ae99d_3905 a b) ∨ (fact_9fdb227ae99d_3977 a b) ∨ (fact_9fdb227ae99d_4003 a b) ∨ (fact_9fdb227ae99d_4654 a b) ∨ (fact_9fdb227ae99d_4559 a b)) ∨ ((fact_9fdb227ae99d_4574 a b) ∨ (fact_9fdb227ae99d_4609 a b) ∨ (fact_9fdb227ae99d_5640 a b) ∨ (fact_9fdb227ae99d_6381 a b) ∨ (fact_9fdb227ae99d_5377 a b) ∨ (fact_9fdb227ae99d_4759 a b) ∨ (fact_9fdb227ae99d_4826 a b) ∨ (fact_9fdb227ae99d_4864 a b) ∨ (fact_9fdb227ae99d_5420 a b) ∨ (fact_9fdb227ae99d_5397 a b)))) ∨ ((fact_9fdb227ae99d_7480 a b) ∧ (fact_9fdb227ae99d_7595 a b) ∧ ((fact_9fdb227ae99d_3759 a b) ∨ (fact_9fdb227ae99d_3791 a b) ∨ (fact_9fdb227ae99d_5169 a b) ∨ (fact_9fdb227ae99d_5847 a b) ∨ (fact_9fdb227ae99d_4540 a b) ∨ (fact_9fdb227ae99d_3905 a b) ∨ (fact_9fdb227ae99d_3977 a b) ∨ (fact_9fdb227ae99d_4003 a b) ∨ (fact_9fdb227ae99d_4654 a b) ∨ (fact_9fdb227ae99d_4559 a b)) ∧ ((fact_9fdb227ae99d_4574 a b) ∨ (fact_9fdb227ae99d_4609 a b) ∨ (fact_9fdb227ae99d_5640 a b) ∨ (fact_9fdb227ae99d_6381 a b) ∨ (fact_9fdb227ae99d_5377 a b) ∨ (fact_9fdb227ae99d_4759 a b) ∨ (fact_9fdb227ae99d_4826 a b) ∨ (fact_9fdb227ae99d_4864 a b) ∨ (fact_9fdb227ae99d_5420 a b) ∨ (fact_9fdb227ae99d_5397 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n482_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((3 : Int) ≤ run_x))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((fact_9fdb227ae99d_2367 a b run_x) ∨ (fact_9fdb227ae99d_2384 a b run_x) ∨ (fact_9fdb227ae99d_3040 a b run_x) ∨ (fact_9fdb227ae99d_3481 a b run_x) ∨ (fact_9fdb227ae99d_2928 a b run_x) ∨ (fact_9fdb227ae99d_2462 a b run_x) ∨ (fact_9fdb227ae99d_2477 a b run_x) ∨ (fact_9fdb227ae99d_2483 a b run_x) ∨ (fact_9fdb227ae99d_2944 a b run_x) ∨ (fact_9fdb227ae99d_2931 a b run_x)))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (run_x ≤ ((2 : Int) + b)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n482_run_floor (a b run_x : Int)
    (h0 : ((3 : Int) ≤ run_x))
    (h1 : (run_x ≤ ((2 : Int) + b)))
    (h2 : (¬ ((fact_9fdb227ae99d_3179 a b run_x) ∨ (fact_9fdb227ae99d_3189 a b run_x) ∨ (fact_9fdb227ae99d_3731 a b run_x) ∨ (fact_9fdb227ae99d_5196 a b run_x) ∨ (fact_9fdb227ae99d_3490 a b run_x) ∨ (fact_9fdb227ae99d_3215 a b run_x) ∨ (fact_9fdb227ae99d_3237 a b run_x) ∨ (fact_9fdb227ae99d_3244 a b run_x) ∨ (fact_9fdb227ae99d_3551 a b run_x) ∨ (fact_9fdb227ae99d_3493 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n483_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n483_run_short (a b : Int)
    (h0 : (¬ ((((1 : Int) + a) - (4 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n483_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n483_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3366 a b) ∨ (fact_9fdb227ae99d_3373 a b) ∨ (fact_9fdb227ae99d_4408 a b) ∨ (fact_9fdb227ae99d_5547 a b) ∨ (fact_9fdb227ae99d_3736 a b) ∨ (fact_9fdb227ae99d_3393 a b) ∨ (fact_9fdb227ae99d_3408 a b) ∨ (((((-3 : Int) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3825 a b) ∨ (fact_9fdb227ae99d_3833 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n483_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3748 a b) ∨ (fact_9fdb227ae99d_3780 a b) ∨ (fact_9fdb227ae99d_5158 a b) ∨ (fact_9fdb227ae99d_5836 a b) ∨ (fact_9fdb227ae99d_4531 a b) ∨ (fact_9fdb227ae99d_3896 a b) ∨ (fact_9fdb227ae99d_3964 a b) ∨ (((((-3 : Int) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((-3 : Int) ≥ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_4639 a b) ∨ (fact_9fdb227ae99d_4674 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n483_run_tall (a b : Int)
    (h0 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_9fdb227ae99d_7486 a b) ∨ (fact_9fdb227ae99d_7589 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ (fact_9fdb227ae99d_7486 a b) ∧ (fact_9fdb227ae99d_7589 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = ((4 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7486 a b) ∧ (fact_9fdb227ae99d_7589 a b) ∧ (((fact_9fdb227ae99d_3769 a b) ∨ (fact_9fdb227ae99d_3801 a b) ∨ (fact_9fdb227ae99d_5179 a b) ∨ (fact_9fdb227ae99d_5857 a b) ∨ (fact_9fdb227ae99d_4546 a b) ∨ (fact_9fdb227ae99d_3911 a b) ∨ (fact_9fdb227ae99d_3985 a b) ∨ (fact_9fdb227ae99d_4011 a b) ∨ (fact_9fdb227ae99d_4663 a b) ∨ (fact_9fdb227ae99d_4688 a b)) ∨ ((fact_9fdb227ae99d_4565 a b) ∨ (fact_9fdb227ae99d_4600 a b) ∨ (fact_9fdb227ae99d_5632 a b) ∨ (fact_9fdb227ae99d_6373 a b) ∨ (fact_9fdb227ae99d_5371 a b) ∨ (fact_9fdb227ae99d_4753 a b) ∨ (fact_9fdb227ae99d_4816 a b) ∨ (fact_9fdb227ae99d_4854 a b) ∨ (fact_9fdb227ae99d_5417 a b) ∨ (fact_9fdb227ae99d_5428 a b)))) ∨ ((fact_9fdb227ae99d_7486 a b) ∧ (fact_9fdb227ae99d_7589 a b) ∧ ((fact_9fdb227ae99d_3769 a b) ∨ (fact_9fdb227ae99d_3801 a b) ∨ (fact_9fdb227ae99d_5179 a b) ∨ (fact_9fdb227ae99d_5857 a b) ∨ (fact_9fdb227ae99d_4546 a b) ∨ (fact_9fdb227ae99d_3911 a b) ∨ (fact_9fdb227ae99d_3985 a b) ∨ (fact_9fdb227ae99d_4011 a b) ∨ (fact_9fdb227ae99d_4663 a b) ∨ (fact_9fdb227ae99d_4688 a b)) ∧ ((fact_9fdb227ae99d_4565 a b) ∨ (fact_9fdb227ae99d_4600 a b) ∨ (fact_9fdb227ae99d_5632 a b) ∨ (fact_9fdb227ae99d_6373 a b) ∨ (fact_9fdb227ae99d_5371 a b) ∨ (fact_9fdb227ae99d_4753 a b) ∨ (fact_9fdb227ae99d_4816 a b) ∨ (fact_9fdb227ae99d_4854 a b) ∨ (fact_9fdb227ae99d_5417 a b) ∨ (fact_9fdb227ae99d_5428 a b))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n483_run_empty (a b run_x : Int)
    (h0 : ((fact_9fdb227ae99d_2366 a b run_x) ∨ (fact_9fdb227ae99d_2383 a b run_x) ∨ (fact_9fdb227ae99d_3039 a b run_x) ∨ (fact_9fdb227ae99d_3480 a b run_x) ∨ (fact_9fdb227ae99d_2927 a b run_x) ∨ (fact_9fdb227ae99d_2461 a b run_x) ∨ (fact_9fdb227ae99d_2476 a b run_x) ∨ (((((-3 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ run_x) ∧ ((-3 : Int) ≥ run_x) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_2943 a b run_x) ∨ (fact_9fdb227ae99d_2947 a b run_x)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (b = (5 : Int)))
    (h3 : ((4 : Int) ≤ run_x))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (run_x ≤ ((1 : Int) + a)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n483_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3178 a b run_x) ∨ (fact_9fdb227ae99d_3188 a b run_x) ∨ (fact_9fdb227ae99d_3730 a b run_x) ∨ (fact_9fdb227ae99d_5195 a b run_x) ∨ (fact_9fdb227ae99d_3489 a b run_x) ∨ (fact_9fdb227ae99d_3214 a b run_x) ∨ (fact_9fdb227ae99d_3236 a b run_x) ∨ (((((-3 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-3 : Int) ≤ run_x) ∧ ((-3 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3550 a b run_x) ∨ (fact_9fdb227ae99d_3558 a b run_x))))
    (h1 : (run_x ≤ ((1 : Int) + a)))
    (h2 : ((4 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n484_run_four (a b : Int)
    (h0 : (¬ ((2 : Int) ≤ ((1 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n484_run_short (a b : Int)
    (h0 : (¬ ((((1 : Int) + b) - (2 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n484_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n484_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3363 a b) ∨ (fact_9fdb227ae99d_3370 a b) ∨ (fact_9fdb227ae99d_4405 a b) ∨ (fact_9fdb227ae99d_5544 a b) ∨ (fact_9fdb227ae99d_3733 a b) ∨ (fact_9fdb227ae99d_3390 a b) ∨ (fact_9fdb227ae99d_3405 a b) ∨ (((((-3 : Int) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((2 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3738 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n484_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3750 a b) ∨ (fact_9fdb227ae99d_3782 a b) ∨ (fact_9fdb227ae99d_5160 a b) ∨ (fact_9fdb227ae99d_5838 a b) ∨ (fact_9fdb227ae99d_4533 a b) ∨ (fact_9fdb227ae99d_3898 a b) ∨ (fact_9fdb227ae99d_3966 a b) ∨ (((((-3 : Int) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((-3 : Int) ≥ (((1 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_4552 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n484_run_tall (a b : Int)
    (h0 : (¬ (((((2 : Int) + (3 : Int)) ≤ ((1 : Int) + b)) ∧ ((fact_9fdb227ae99d_7358 a b) ∨ (fact_9fdb227ae99d_7429 a b))) ∨ ((((2 : Int) + (2 : Int)) ≤ ((1 : Int) + b)) ∧ (fact_9fdb227ae99d_7358 a b) ∧ (fact_9fdb227ae99d_7429 a b)) ∨ (((2 : Int) + (4 : Int)) ≤ ((1 : Int) + b)) ∨ ((((1 : Int) + b) = ((2 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7358 a b) ∧ (fact_9fdb227ae99d_7429 a b) ∧ (((fact_9fdb227ae99d_3754 a b) ∨ (fact_9fdb227ae99d_3786 a b) ∨ (fact_9fdb227ae99d_5164 a b) ∨ (fact_9fdb227ae99d_5842 a b) ∨ (fact_9fdb227ae99d_4536 a b) ∨ (fact_9fdb227ae99d_3901 a b) ∨ (fact_9fdb227ae99d_3969 a b) ∨ (fact_9fdb227ae99d_3995 a b) ∨ (fact_9fdb227ae99d_4553 a b)) ∨ ((fact_9fdb227ae99d_4571 a b) ∨ (fact_9fdb227ae99d_4606 a b) ∨ (fact_9fdb227ae99d_5638 a b) ∨ (fact_9fdb227ae99d_6379 a b) ∨ (fact_9fdb227ae99d_5375 a b) ∨ (fact_9fdb227ae99d_4757 a b) ∨ (fact_9fdb227ae99d_4822 a b) ∨ (fact_9fdb227ae99d_4860 a b) ∨ (fact_9fdb227ae99d_5393 a b)))) ∨ ((fact_9fdb227ae99d_7358 a b) ∧ (fact_9fdb227ae99d_7429 a b) ∧ ((fact_9fdb227ae99d_3754 a b) ∨ (fact_9fdb227ae99d_3786 a b) ∨ (fact_9fdb227ae99d_5164 a b) ∨ (fact_9fdb227ae99d_5842 a b) ∨ (fact_9fdb227ae99d_4536 a b) ∨ (fact_9fdb227ae99d_3901 a b) ∨ (fact_9fdb227ae99d_3969 a b) ∨ (fact_9fdb227ae99d_3995 a b) ∨ (fact_9fdb227ae99d_4553 a b)) ∧ ((fact_9fdb227ae99d_4571 a b) ∨ (fact_9fdb227ae99d_4606 a b) ∨ (fact_9fdb227ae99d_5638 a b) ∨ (fact_9fdb227ae99d_6379 a b) ∨ (fact_9fdb227ae99d_5375 a b) ∨ (fact_9fdb227ae99d_4757 a b) ∨ (fact_9fdb227ae99d_4822 a b) ∨ (fact_9fdb227ae99d_4860 a b) ∨ (fact_9fdb227ae99d_5393 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n484_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((fact_9fdb227ae99d_2367 a b run_x) ∨ (fact_9fdb227ae99d_2384 a b run_x) ∨ (fact_9fdb227ae99d_3040 a b run_x) ∨ (fact_9fdb227ae99d_3481 a b run_x) ∨ (fact_9fdb227ae99d_2928 a b run_x) ∨ (fact_9fdb227ae99d_2462 a b run_x) ∨ (fact_9fdb227ae99d_2477 a b run_x) ∨ (fact_9fdb227ae99d_2483 a b run_x) ∨ (fact_9fdb227ae99d_2930 a b run_x)))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (run_x ≤ ((1 : Int) + b)))
    (h6 : ((2 : Int) ≤ run_x))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n484_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3179 a b run_x) ∨ (fact_9fdb227ae99d_3189 a b run_x) ∨ (fact_9fdb227ae99d_3731 a b run_x) ∨ (fact_9fdb227ae99d_5196 a b run_x) ∨ (fact_9fdb227ae99d_3490 a b run_x) ∨ (fact_9fdb227ae99d_3215 a b run_x) ∨ (fact_9fdb227ae99d_3237 a b run_x) ∨ (fact_9fdb227ae99d_3244 a b run_x) ∨ (fact_9fdb227ae99d_3492 a b run_x))))
    (h1 : (run_x ≤ ((1 : Int) + b)))
    (h2 : ((2 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n485_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (fact_9fdb227ae99d_29 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n485_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_3086 a b) ∨ (fact_9fdb227ae99d_3087 a b) ∨ (fact_9fdb227ae99d_3593 a b) ∨ (fact_9fdb227ae99d_5028 a b) ∨ (fact_9fdb227ae99d_3330 a b) ∨ (fact_9fdb227ae99d_3125 a b) ∨ (fact_9fdb227ae99d_3128 a b) ∨ (fact_9fdb227ae99d_3129 a b) ∨ (fact_9fdb227ae99d_3332 a b)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((2 : Int) + ((2 : Int) * b)) < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < ((2 : Int) + ((2 : Int) * b))) ∨ ((1 : Int) > ((1 : Int) + a)) ∨ ((1 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n485_o0 (a b jx jy : Int)
    (h0 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h1 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b = (5 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (fact_9fdb227ae99d_1974 a b jx jy))
    (h8 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n485_o1 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_1977 a b jx jy))
    (h2 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - a))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n485_o2 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - b))))
    (h5 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - b))))
    (h6 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h7 : ((jy - b) ≥ (0 : Int)))
    (h8 : (fact_9fdb227ae99d_1979 a b jx jy))
    (h9 : (a ≥ (5 : Int)))
    (h10 : ((jx < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((((2 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h11 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n485_o3 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1980 a b jx jy))
    (h1 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h4 : (b = (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n485_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (fact_9fdb227ae99d_1981 a b jx jy))
    (h6 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n485_o5 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h8 : (b = (5 : Int)))
    (h9 : (fact_9fdb227ae99d_1978 a b jx jy))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n485_o6 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (fact_9fdb227ae99d_1976 a b jx jy))
    (h3 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n485_o7 (a b jx jy : Int)
    (h0 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - b))))
    (h1 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - b))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_1975 a b jx jy))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (b = (5 : Int)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n486_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b = (5 : Int)))
    (h2 : (¬ (((3 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n486_empty (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((fact_9fdb227ae99d_2820 a b) ∨ (fact_9fdb227ae99d_2822 a b) ∨ (fact_9fdb227ae99d_3204 a b) ∨ (fact_9fdb227ae99d_3850 a b) ∨ (fact_9fdb227ae99d_3066 a b) ∨ (fact_9fdb227ae99d_2899 a b) ∨ (fact_9fdb227ae99d_2905 a b) ∨ ((((3 : Int) ≥ ((-3 : Int) - a)) ∧ ((3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-3 : Int)) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_2823 a b)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n486_o0 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h5 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n486_o1 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (¬ ((((3 : Int) = jx) ∧ (jy = ((4 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h7 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n486_o2 (a b jx jy : Int)
    (h0 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h1 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n486_o3 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h3 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h4 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (¬ (((jx = ((3 : Int) + b)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n486_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ ((((3 : Int) = jx) ∧ (jy = ((4 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n486_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((jx + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h7 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h8 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h9 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n486_o6 (a b jx jy : Int)
    (h0 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h1 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h2 : (b = (5 : Int)))
    (h3 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (¬ ((((3 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n486_o7 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (¬ ((((3 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n487_point (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (¬ (((-4 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((-4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n487_empty (a b : Int)
    (h0 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((((2 : Int) + a) < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < ((2 : Int) + a)) ∨ ((2 : Int) > ((2 : Int) + b)) ∨ ((2 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : ((fact_9fdb227ae99d_2875 a b) ∨ (fact_9fdb227ae99d_2878 a b) ∨ (fact_9fdb227ae99d_3264 a b) ∨ (fact_9fdb227ae99d_4171 a b) ∨ (fact_9fdb227ae99d_3106 a b) ∨ (fact_9fdb227ae99d_2964 a b) ∨ (fact_9fdb227ae99d_2968 a b) ∨ ((((-4 : Int) ≥ ((-3 : Int) - a)) ∧ ((-4 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-3 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_2881 a b) ∨ (fact_9fdb227ae99d_3108 a b)))
    (h5 : (b = (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n487_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (¬ (((jx = ((-4 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h7 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h8 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n487_o1 (a b jx jy : Int)
    (h0 : ((jx < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h1 : (¬ ((((-4 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n487_o2 (a b jx jy : Int)
    (h0 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (b = (5 : Int)))
    (h2 : (¬ ((((-4 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h3 : ((jx < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n487_o3 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h2 : ((jx < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : (b = (5 : Int)))
    (h4 : (¬ ((((-4 : Int) = jx) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n487_o4 (a b jx jy : Int)
    (h0 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (¬ ((((-4 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b = (5 : Int)))
    (h5 : ((jx < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n487_o5 (a b jx jy : Int)
    (h0 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h1 : (b = (5 : Int)))
    (h2 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h7 : (¬ ((((-4 : Int) = jx) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n487_o6 (a b jx jy : Int)
    (h0 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h3 : (b = (5 : Int)))
    (h4 : (¬ (((jx = ((-4 : Int) + ((-1 : Int) * b))) ∧ ((3 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((-3 : Int) > (jx + b)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n487_o7 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n488_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_29 a b))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n488_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_3086 a b) ∨ (fact_9fdb227ae99d_3087 a b) ∨ (fact_9fdb227ae99d_3593 a b) ∨ (fact_9fdb227ae99d_5028 a b) ∨ (fact_9fdb227ae99d_3330 a b) ∨ (fact_9fdb227ae99d_3125 a b) ∨ (fact_9fdb227ae99d_3128 a b) ∨ (fact_9fdb227ae99d_3129 a b) ∨ (fact_9fdb227ae99d_3088 a b) ∨ (fact_9fdb227ae99d_3333 a b) ∨ (fact_9fdb227ae99d_5157 a b)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n488_o0 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h5 : (fact_9fdb227ae99d_1974 a b jx jy))
    (h6 : ((jx < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n488_o1 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + b + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_1977 a b jx jy))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n488_o2 (a b jx jy : Int)
    (h0 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + ((2 : Int) * b))) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_1979 a b jx jy))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - b))))
    (h9 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n488_o3 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1980 a b jx jy))
    (h1 : (b = (5 : Int)))
    (h2 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((jx + (0 : Int)) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - b)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h5 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h9 : (fact_9fdb227ae99d_107 a b))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n488_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + b + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h2 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_1981 a b jx jy))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n488_o5 (a b jx jy : Int)
    (h0 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h1 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h2 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (fact_9fdb227ae99d_1978 a b jx jy))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n488_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (fact_9fdb227ae99d_1976 a b jx jy))
    (h5 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n488_o7 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_7277 a b jx jy))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_1975 a b jx jy))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h6 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - b))))
    (h7 : (fact_9fdb227ae99d_2925 a b jy))
    (h8 : ((jy - b) ≥ (0 : Int)))
    (h9 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h10 : (a ≥ (5 : Int)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n489_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((1 : Int) + a) ≤ (b + a))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n489_run_short (a b : Int)
    (h0 : (¬ (((b + a) - ((1 : Int) + a)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n489_run_nonnegative (a b : Int)
    (h0 : (¬ (((1 : Int) + a) ≥ (0 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n489_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3842 a b) ∨ (fact_9fdb227ae99d_3843 a b) ∨ (fact_9fdb227ae99d_5285 a b) ∨ (fact_9fdb227ae99d_5899 a b) ∨ (fact_9fdb227ae99d_4702 a b) ∨ (fact_9fdb227ae99d_4173 a b) ∨ (fact_9fdb227ae99d_4175 a b) ∨ (fact_9fdb227ae99d_4176 a b) ∨ (fact_9fdb227ae99d_3844 a b) ∨ (fact_9fdb227ae99d_4703 a b) ∨ (fact_9fdb227ae99d_6128 a b) ∨ (fact_9fdb227ae99d_5345 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n489_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3287 a b) ∨ (fact_9fdb227ae99d_3288 a b) ∨ (fact_9fdb227ae99d_4317 a b) ∨ (fact_9fdb227ae99d_5448 a b) ∨ (fact_9fdb227ae99d_3664 a b) ∨ (fact_9fdb227ae99d_3340 a b) ∨ (fact_9fdb227ae99d_3344 a b) ∨ (fact_9fdb227ae99d_3345 a b) ∨ (fact_9fdb227ae99d_3289 a b) ∨ (fact_9fdb227ae99d_3665 a b) ∨ (fact_9fdb227ae99d_5583 a b) ∨ (fact_9fdb227ae99d_4399 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n489_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ ((((((1 : Int) + a) + (3 : Int)) ≤ (b + a)) ∧ ((fact_9fdb227ae99d_7829 a b) ∨ (fact_9fdb227ae99d_7759 a b))) ∨ (((((1 : Int) + a) + (2 : Int)) ≤ (b + a)) ∧ (fact_9fdb227ae99d_7829 a b) ∧ (fact_9fdb227ae99d_7759 a b)) ∨ ((((1 : Int) + a) + (4 : Int)) ≤ (b + a)) ∨ (((b + a) = (((1 : Int) + a) + (1 : Int))) ∧ (fact_9fdb227ae99d_7829 a b) ∧ (fact_9fdb227ae99d_7759 a b) ∧ (((fact_9fdb227ae99d_4587 a b) ∨ (fact_9fdb227ae99d_4622 a b) ∨ (fact_9fdb227ae99d_5652 a b) ∨ (fact_9fdb227ae99d_6391 a b) ∨ (fact_9fdb227ae99d_5381 a b) ∨ (fact_9fdb227ae99d_4763 a b) ∨ (fact_9fdb227ae99d_4832 a b) ∨ (fact_9fdb227ae99d_4868 a b) ∨ (fact_9fdb227ae99d_4645 a b) ∨ (fact_9fdb227ae99d_5431 a b) ∨ (fact_9fdb227ae99d_6559 a b) ∨ (fact_9fdb227ae99d_5752 a b)) ∨ ((fact_9fdb227ae99d_3630 a b) ∨ (fact_9fdb227ae99d_3639 a b) ∨ (fact_9fdb227ae99d_5038 a b) ∨ (fact_9fdb227ae99d_5791 a b) ∨ (fact_9fdb227ae99d_4413 a b) ∨ (fact_9fdb227ae99d_3682 a b) ∨ (fact_9fdb227ae99d_3692 a b) ∨ (fact_9fdb227ae99d_3698 a b) ∨ (fact_9fdb227ae99d_3646 a b) ∨ (fact_9fdb227ae99d_4493 a b) ∨ (fact_9fdb227ae99d_5825 a b) ∨ (fact_9fdb227ae99d_5128 a b)))) ∨ ((fact_9fdb227ae99d_7829 a b) ∧ (fact_9fdb227ae99d_7759 a b) ∧ ((fact_9fdb227ae99d_4587 a b) ∨ (fact_9fdb227ae99d_4622 a b) ∨ (fact_9fdb227ae99d_5652 a b) ∨ (fact_9fdb227ae99d_6391 a b) ∨ (fact_9fdb227ae99d_5381 a b) ∨ (fact_9fdb227ae99d_4763 a b) ∨ (fact_9fdb227ae99d_4832 a b) ∨ (fact_9fdb227ae99d_4868 a b) ∨ (fact_9fdb227ae99d_4645 a b) ∨ (fact_9fdb227ae99d_5431 a b) ∨ (fact_9fdb227ae99d_6559 a b) ∨ (fact_9fdb227ae99d_5752 a b)) ∧ ((fact_9fdb227ae99d_3630 a b) ∨ (fact_9fdb227ae99d_3639 a b) ∨ (fact_9fdb227ae99d_5038 a b) ∨ (fact_9fdb227ae99d_5791 a b) ∨ (fact_9fdb227ae99d_4413 a b) ∨ (fact_9fdb227ae99d_3682 a b) ∨ (fact_9fdb227ae99d_3692 a b) ∨ (fact_9fdb227ae99d_3698 a b) ∨ (fact_9fdb227ae99d_3646 a b) ∨ (fact_9fdb227ae99d_4493 a b) ∨ (fact_9fdb227ae99d_5825 a b) ∨ (fact_9fdb227ae99d_5128 a b))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n489_run_empty (a b run_x : Int)
    (h0 : (run_x ≤ (b + a)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (fact_9fdb227ae99d_3207 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((fact_9fdb227ae99d_2416 a b run_x) ∨ (fact_9fdb227ae99d_2417 a b run_x) ∨ (fact_9fdb227ae99d_3049 a b run_x) ∨ (fact_9fdb227ae99d_3564 a b run_x) ∨ (fact_9fdb227ae99d_2972 a b run_x) ∨ (fact_9fdb227ae99d_2518 a b run_x) ∨ (fact_9fdb227ae99d_2520 a b run_x) ∨ (fact_9fdb227ae99d_2521 a b run_x) ∨ (fact_9fdb227ae99d_2418 a b run_x) ∨ (fact_9fdb227ae99d_2973 a b run_x) ∨ (fact_9fdb227ae99d_3663 a b run_x) ∨ (fact_9fdb227ae99d_3110 a b run_x)))
    (h5 : (((1 : Int) + a) ≤ run_x))
    (h6 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n489_run_floor (a b run_x : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (¬ ((fact_9fdb227ae99d_3171 a b run_x) ∨ (fact_9fdb227ae99d_3181 a b run_x) ∨ (fact_9fdb227ae99d_3724 a b run_x) ∨ (fact_9fdb227ae99d_5189 a b run_x) ∨ (fact_9fdb227ae99d_3483 a b run_x) ∨ (fact_9fdb227ae99d_3209 a b run_x) ∨ (fact_9fdb227ae99d_3232 a b run_x) ∨ (fact_9fdb227ae99d_3240 a b run_x) ∨ (fact_9fdb227ae99d_3191 a b run_x) ∨ (fact_9fdb227ae99d_3554 a b run_x) ∨ (fact_9fdb227ae99d_5357 a b run_x) ∨ (fact_9fdb227ae99d_3895 a b run_x))))
    (h5 : (((1 : Int) + a) ≤ run_x))
    (h6 : (run_x ≤ (b + a)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n490_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_1 a b))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n490_empty (a b : Int)
    (h0 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : ((fact_9fdb227ae99d_3051 a b) ∨ (fact_9fdb227ae99d_3053 a b) ∨ (fact_9fdb227ae99d_3563 a b) ∨ (fact_9fdb227ae99d_4701 a b) ∨ (fact_9fdb227ae99d_3285 a b) ∨ (fact_9fdb227ae99d_3112 a b) ∨ ((((0 : Int) ≥ ((-2 : Int) - b)) ∧ ((0 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + b)) ∧ ((1 : Int) ≥ ((3 : Int) + b))) ∨ (((-2 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (-2 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((1 : Int) + a)))) ∨ ((((0 : Int) ≥ ((-3 : Int) - a)) ∧ ((0 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + b)) ∧ ((2 : Int) ≥ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3055 a b) ∨ (fact_9fdb227ae99d_3292 a b) ∨ (fact_9fdb227ae99d_5105 a b) ∨ ((((0 : Int) ≥ ((-1 : Int) - a)) ∧ ((0 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (-1 : Int)) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int)))))))
    (h3 : (fact_9fdb227ae99d_3478 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n490_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h7 : (fact_9fdb227ae99d_1606 a b jx jy))
    (h8 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n490_o1 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1611 a b jx jy))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - a))))
    (h3 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h4 : (fact_9fdb227ae99d_2923 a b jy))
    (h5 : (b = (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (¬ ((((0 : Int) = jx) ∧ (jy = ((3 : Int) + b + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n490_o2 (a b jx jy : Int)
    (h0 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - b))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (¬ ((((0 : Int) = jx) ∧ (jy = ((3 : Int) + ((2 : Int) * b))) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h7 : (fact_9fdb227ae99d_1615 a b jx jy))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n490_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_1618 a b jx jy))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h6 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h9 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n490_o4 (a b jx jy : Int)
    (h0 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (fact_9fdb227ae99d_2922 a b jy))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_1619 a b jx jy))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (¬ ((((0 : Int) = jx) ∧ (jy = ((3 : Int) + b + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h10 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - a))))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n490_o5 (a b jx jy : Int)
    (h0 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (fact_9fdb227ae99d_1614 a b jx jy))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n490_o6 (a b jx jy : Int)
    (h0 : (((jx + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h7 : (b = (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (fact_9fdb227ae99d_1610 a b jx jy))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n490_o7 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (¬ ((((0 : Int) = jx) ∧ (jy = ((3 : Int) + ((2 : Int) * b))) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h8 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - b))))
    (h9 : (fact_9fdb227ae99d_1607 a b jx jy))
    (h10 : (fact_9fdb227ae99d_2925 a b jy))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n491_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (fact_9fdb227ae99d_2 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n491_empty (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((fact_9fdb227ae99d_3061 a b) ∨ (fact_9fdb227ae99d_3062 a b) ∨ (fact_9fdb227ae99d_3567 a b) ∨ (fact_9fdb227ae99d_4706 a b) ∨ (fact_9fdb227ae99d_3298 a b) ∨ (fact_9fdb227ae99d_3118 a b) ∨ ((((2 : Int) ≥ ((-2 : Int) - b)) ∧ ((2 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + a)) ∧ ((1 : Int) ≥ ((4 : Int) + a))) ∨ (((-2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-2 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((1 : Int) + a)))) ∨ ((((2 : Int) ≥ ((-3 : Int) - a)) ∧ ((2 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((-3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3063 a b) ∨ (fact_9fdb227ae99d_3299 a b) ∨ (fact_9fdb227ae99d_5106 a b) ∨ ((((2 : Int) ≥ ((-1 : Int) - a)) ∧ ((2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-1 : Int)) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3568 a b)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n491_o0 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h2 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + b) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - (0 : Int)))))
    (h3 : (b = (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (fact_9fdb227ae99d_1672 a b jx jy))
    (h6 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n491_o1 (a b jx jy : Int)
    (h0 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - a))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((jx + b) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < jy)))
    (h6 : (fact_9fdb227ae99d_1675 a b jx jy))
    (h7 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - a))))
    (h8 : ((jy - a) ≥ (0 : Int)))
    (h9 : (a = (b + (2 : Int))))
    (h10 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n491_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - b))))
    (h2 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (b = (5 : Int)))
    (h4 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - b))))
    (h5 : (fact_9fdb227ae99d_1677 a b jx jy))
    (h6 : (a ≥ b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a > b))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n491_o3 (a b jx jy : Int)
    (h0 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h1 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + b + a) - a)) ∨ ((((3 : Int) + b + a) + (0 : Int)) < jy)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_1678 a b jx jy))
    (h5 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a = (b + (2 : Int))))
    (h10 : (((jx + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jx - b)) ∨ (jy < ((4 : Int) + a)) ∨ (((4 : Int) + a) < jy)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n491_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (((jx + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jx - b)) ∨ (jy < ((4 : Int) + a)) ∨ (((4 : Int) + a) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - a))))
    (h5 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - a))))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (fact_9fdb227ae99d_1679 a b jx jy))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n491_o5 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h3 : (fact_9fdb227ae99d_1676 a b jx jy))
    (h4 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + b + a) - a)) ∨ ((((3 : Int) + b + a) + (0 : Int)) < jy)))
    (h5 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n491_o6 (a b jx jy : Int)
    (h0 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + a) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - (0 : Int)))))
    (h1 : (b = (5 : Int)))
    (h2 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + b + a) - a)) ∨ ((((3 : Int) + b + a) + (0 : Int)) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (fact_9fdb227ae99d_1674 a b jx jy))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n491_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (fact_9fdb227ae99d_1673 a b jx jy))
    (h4 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - b))))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (b = (5 : Int)))
    (h7 : (fact_9fdb227ae99d_2925 a b jy))
    (h8 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - b))))
    (h11 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n492_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ (((-4 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((-4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n492_empty (a b : Int)
    (h0 : (¬ (((((3 : Int) + ((2 : Int) * b)) = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((((3 : Int) + ((2 : Int) * b)) = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h1 : ((fact_9fdb227ae99d_2876 a b) ∨ (fact_9fdb227ae99d_2879 a b) ∨ (fact_9fdb227ae99d_3265 a b) ∨ (fact_9fdb227ae99d_4172 a b) ∨ (fact_9fdb227ae99d_3107 a b) ∨ (fact_9fdb227ae99d_2965 a b) ∨ (fact_9fdb227ae99d_2969 a b) ∨ (fact_9fdb227ae99d_2970 a b) ∨ (fact_9fdb227ae99d_2882 a b) ∨ (fact_9fdb227ae99d_3109 a b) ∨ (fact_9fdb227ae99d_4398 a b) ∨ ((((-4 : Int) ≥ ((-1 : Int) - a)) ∧ ((-4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) + ((2 : Int) * b))) ∧ ((4 : Int) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-1 : Int)) ∧ ((4 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) - b)) ∧ ((4 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ ((((-4 : Int) ≥ ((0 : Int) - a)) ∧ ((-4 : Int) ≤ ((0 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + ((2 : Int) * b))) ∧ ((4 : Int) ≤ ((3 : Int) + ((2 : Int) * b)))) ∨ (((0 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (0 : Int)) ∧ ((4 : Int) ≥ (((3 : Int) + ((2 : Int) * b)) - b)) ∧ ((4 : Int) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int)))))))
    (h2 : ((((2 : Int) + a) < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < ((2 : Int) + a)) ∨ ((3 : Int) > ((2 : Int) + b)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : (b = (5 : Int)))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n492_o0 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((-4 : Int) + ((-1 : Int) * a))) ∨ (((-4 : Int) + ((-1 : Int) * a)) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h6 : (b = (5 : Int)))
    (h7 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n492_o1 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int)) ∨ (((0 : Int) + a) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((0 : Int) - (0 : Int)))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h7 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h8 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n492_o2 (a b jx jy : Int)
    (h0 : (¬ ((((-4 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (((jx + (0 : Int)) < ((-4 : Int) + ((-1 : Int) * a))) ∨ (((-4 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n492_o3 (a b jx jy : Int)
    (h0 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jy - (0 : Int)))))
    (h1 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h2 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h6 : (b = (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n492_o4 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - b)) ∨ (jy < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < jy)))
    (h1 : (((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int)) ∨ (((0 : Int) + a) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((0 : Int) - (0 : Int)))))
    (h2 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h7 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : ((jy - a) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n492_o5 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((jx + (0 : Int)) < ((-4 : Int) + ((-1 : Int) * a))) ∨ (((-4 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h8 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n492_o6 (a b jx jy : Int)
    (h0 : (¬ (((jx = ((-4 : Int) + ((-1 : Int) * b))) ∧ ((4 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((-3 : Int) > (jx + b)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h3 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n492_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (fact_9fdb227ae99d_2925 a b jy))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n493_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((3 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n493_run_short (a b : Int)
    (h0 : (¬ ((((3 : Int) + b) - (4 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n493_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n493_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_5690 a b) ∨ (fact_9fdb227ae99d_5703 a b) ∨ (fact_9fdb227ae99d_6371 a b) ∨ (fact_9fdb227ae99d_6967 a b) ∨ (fact_9fdb227ae99d_5996 a b) ∨ (fact_9fdb227ae99d_5759 a b) ∨ (fact_9fdb227ae99d_5773 a b) ∨ (fact_9fdb227ae99d_5778 a b) ∨ (fact_9fdb227ae99d_5709 a b) ∨ (fact_9fdb227ae99d_6120 a b) ∨ (fact_9fdb227ae99d_6983 a b) ∨ (((((-1 : Int) - a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (((((0 : Int) - a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + ((2 : Int) * b)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b)))) ∨ (((0 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6310 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n493_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_6040 a b) ∨ (fact_9fdb227ae99d_6078 a b) ∨ (fact_9fdb227ae99d_6840 a b) ∨ (fact_9fdb227ae99d_7052 a b) ∨ (fact_9fdb227ae99d_6606 a b) ∨ (fact_9fdb227ae99d_6219 a b) ∨ (fact_9fdb227ae99d_6285 a b) ∨ (fact_9fdb227ae99d_6299 a b) ∨ (fact_9fdb227ae99d_6102 a b) ∨ (fact_9fdb227ae99d_6652 a b) ∨ (fact_9fdb227ae99d_7103 a b) ∨ (((((-1 : Int) - a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (((((0 : Int) - a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + ((2 : Int) * b)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b)))) ∨ (((0 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6738 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n493_run_tall (a b : Int)
    (h0 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((3 : Int) + b)) ∧ (((fact_9fdb227ae99d_6032 a b) ∨ (fact_9fdb227ae99d_6070 a b) ∨ (fact_9fdb227ae99d_6832 a b) ∨ (fact_9fdb227ae99d_7044 a b) ∨ (fact_9fdb227ae99d_6598 a b) ∨ (fact_9fdb227ae99d_6211 a b) ∨ (fact_9fdb227ae99d_6276 a b) ∨ (fact_9fdb227ae99d_6290 a b) ∨ (fact_9fdb227ae99d_6094 a b) ∨ (fact_9fdb227ae99d_6646 a b) ∨ (fact_9fdb227ae99d_7098 a b) ∨ (fact_9fdb227ae99d_7059 a b) ∨ (fact_9fdb227ae99d_7054 a b) ∨ (fact_9fdb227ae99d_6737 a b)) ∨ ((fact_9fdb227ae99d_6619 a b) ∨ (fact_9fdb227ae99d_6623 a b) ∨ (fact_9fdb227ae99d_6991 a b) ∨ (fact_9fdb227ae99d_7152 a b) ∨ (fact_9fdb227ae99d_6911 a b) ∨ (fact_9fdb227ae99d_6684 a b) ∨ (fact_9fdb227ae99d_6704 a b) ∨ (fact_9fdb227ae99d_6716 a b) ∨ (fact_9fdb227ae99d_6627 a b) ∨ (fact_9fdb227ae99d_6915 a b) ∨ (fact_9fdb227ae99d_7163 a b) ∨ (fact_9fdb227ae99d_7159 a b) ∨ (fact_9fdb227ae99d_7153 a b) ∨ (fact_9fdb227ae99d_6933 a b)))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((3 : Int) + b)) ∧ ((fact_9fdb227ae99d_6032 a b) ∨ (fact_9fdb227ae99d_6070 a b) ∨ (fact_9fdb227ae99d_6832 a b) ∨ (fact_9fdb227ae99d_7044 a b) ∨ (fact_9fdb227ae99d_6598 a b) ∨ (fact_9fdb227ae99d_6211 a b) ∨ (fact_9fdb227ae99d_6276 a b) ∨ (fact_9fdb227ae99d_6290 a b) ∨ (fact_9fdb227ae99d_6094 a b) ∨ (fact_9fdb227ae99d_6646 a b) ∨ (fact_9fdb227ae99d_7098 a b) ∨ (fact_9fdb227ae99d_7059 a b) ∨ (fact_9fdb227ae99d_7054 a b) ∨ (fact_9fdb227ae99d_6737 a b)) ∧ ((fact_9fdb227ae99d_6619 a b) ∨ (fact_9fdb227ae99d_6623 a b) ∨ (fact_9fdb227ae99d_6991 a b) ∨ (fact_9fdb227ae99d_7152 a b) ∨ (fact_9fdb227ae99d_6911 a b) ∨ (fact_9fdb227ae99d_6684 a b) ∨ (fact_9fdb227ae99d_6704 a b) ∨ (fact_9fdb227ae99d_6716 a b) ∨ (fact_9fdb227ae99d_6627 a b) ∨ (fact_9fdb227ae99d_6915 a b) ∨ (fact_9fdb227ae99d_7163 a b) ∨ (fact_9fdb227ae99d_7159 a b) ∨ (fact_9fdb227ae99d_7153 a b) ∨ (fact_9fdb227ae99d_6933 a b))) ∨ (((4 : Int) + (4 : Int)) ≤ ((3 : Int) + b)) ∨ ((((3 : Int) + b) = ((4 : Int) + (1 : Int))) ∧ ((fact_9fdb227ae99d_6032 a b) ∨ (fact_9fdb227ae99d_6070 a b) ∨ (fact_9fdb227ae99d_6832 a b) ∨ (fact_9fdb227ae99d_7044 a b) ∨ (fact_9fdb227ae99d_6598 a b) ∨ (fact_9fdb227ae99d_6211 a b) ∨ (fact_9fdb227ae99d_6276 a b) ∨ (fact_9fdb227ae99d_6290 a b) ∨ (fact_9fdb227ae99d_6094 a b) ∨ (fact_9fdb227ae99d_6646 a b) ∨ (fact_9fdb227ae99d_7098 a b) ∨ (fact_9fdb227ae99d_7059 a b) ∨ (fact_9fdb227ae99d_7054 a b) ∨ (fact_9fdb227ae99d_6737 a b)) ∧ ((fact_9fdb227ae99d_6619 a b) ∨ (fact_9fdb227ae99d_6623 a b) ∨ (fact_9fdb227ae99d_6991 a b) ∨ (fact_9fdb227ae99d_7152 a b) ∨ (fact_9fdb227ae99d_6911 a b) ∨ (fact_9fdb227ae99d_6684 a b) ∨ (fact_9fdb227ae99d_6704 a b) ∨ (fact_9fdb227ae99d_6716 a b) ∨ (fact_9fdb227ae99d_6627 a b) ∨ (fact_9fdb227ae99d_6915 a b) ∨ (fact_9fdb227ae99d_7163 a b) ∨ (fact_9fdb227ae99d_7159 a b) ∨ (fact_9fdb227ae99d_7153 a b) ∨ (fact_9fdb227ae99d_6933 a b)) ∧ (((fact_9fdb227ae99d_6030 a b) ∨ (fact_9fdb227ae99d_6068 a b) ∨ (fact_9fdb227ae99d_6830 a b) ∨ (fact_9fdb227ae99d_7042 a b) ∨ (fact_9fdb227ae99d_6596 a b) ∨ (fact_9fdb227ae99d_6209 a b) ∨ (fact_9fdb227ae99d_6274 a b) ∨ (fact_9fdb227ae99d_6289 a b) ∨ (fact_9fdb227ae99d_6092 a b) ∨ (fact_9fdb227ae99d_6645 a b) ∨ (fact_9fdb227ae99d_7096 a b) ∨ (fact_9fdb227ae99d_7058 a b) ∨ (((((0 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-3 : Int) + ((-1 : Int) * a)) + a) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + ((2 : Int) * b)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b)))) ∨ (((0 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((0 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6735 a b)) ∨ ((fact_9fdb227ae99d_6617 a b) ∨ (fact_9fdb227ae99d_6621 a b) ∨ (fact_9fdb227ae99d_6989 a b) ∨ (fact_9fdb227ae99d_7150 a b) ∨ (fact_9fdb227ae99d_6909 a b) ∨ (fact_9fdb227ae99d_6682 a b) ∨ (fact_9fdb227ae99d_6702 a b) ∨ (fact_9fdb227ae99d_6715 a b) ∨ (fact_9fdb227ae99d_6625 a b) ∨ (fact_9fdb227ae99d_6913 a b) ∨ (fact_9fdb227ae99d_7161 a b) ∨ (fact_9fdb227ae99d_7158 a b) ∨ (((((0 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-3 : Int) + ((-1 : Int) * a)) + a) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + ((2 : Int) * b)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b)))) ∨ (((0 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((0 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6931 a b)))) ∨ (((fact_9fdb227ae99d_6032 a b) ∨ (fact_9fdb227ae99d_6070 a b) ∨ (fact_9fdb227ae99d_6832 a b) ∨ (fact_9fdb227ae99d_7044 a b) ∨ (fact_9fdb227ae99d_6598 a b) ∨ (fact_9fdb227ae99d_6211 a b) ∨ (fact_9fdb227ae99d_6276 a b) ∨ (fact_9fdb227ae99d_6290 a b) ∨ (fact_9fdb227ae99d_6094 a b) ∨ (fact_9fdb227ae99d_6646 a b) ∨ (fact_9fdb227ae99d_7098 a b) ∨ (fact_9fdb227ae99d_7059 a b) ∨ (fact_9fdb227ae99d_7054 a b) ∨ (fact_9fdb227ae99d_6737 a b)) ∧ ((fact_9fdb227ae99d_6619 a b) ∨ (fact_9fdb227ae99d_6623 a b) ∨ (fact_9fdb227ae99d_6991 a b) ∨ (fact_9fdb227ae99d_7152 a b) ∨ (fact_9fdb227ae99d_6911 a b) ∨ (fact_9fdb227ae99d_6684 a b) ∨ (fact_9fdb227ae99d_6704 a b) ∨ (fact_9fdb227ae99d_6716 a b) ∨ (fact_9fdb227ae99d_6627 a b) ∨ (fact_9fdb227ae99d_6915 a b) ∨ (fact_9fdb227ae99d_7163 a b) ∨ (fact_9fdb227ae99d_7159 a b) ∨ (fact_9fdb227ae99d_7153 a b) ∨ (fact_9fdb227ae99d_6933 a b)) ∧ ((fact_9fdb227ae99d_6030 a b) ∨ (fact_9fdb227ae99d_6068 a b) ∨ (fact_9fdb227ae99d_6830 a b) ∨ (fact_9fdb227ae99d_7042 a b) ∨ (fact_9fdb227ae99d_6596 a b) ∨ (fact_9fdb227ae99d_6209 a b) ∨ (fact_9fdb227ae99d_6274 a b) ∨ (fact_9fdb227ae99d_6289 a b) ∨ (fact_9fdb227ae99d_6092 a b) ∨ (fact_9fdb227ae99d_6645 a b) ∨ (fact_9fdb227ae99d_7096 a b) ∨ (fact_9fdb227ae99d_7058 a b) ∨ (((((0 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-3 : Int) + ((-1 : Int) * a)) + a) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + ((2 : Int) * b)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b)))) ∨ (((0 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((0 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6735 a b)) ∧ ((fact_9fdb227ae99d_6617 a b) ∨ (fact_9fdb227ae99d_6621 a b) ∨ (fact_9fdb227ae99d_6989 a b) ∨ (fact_9fdb227ae99d_7150 a b) ∨ (fact_9fdb227ae99d_6909 a b) ∨ (fact_9fdb227ae99d_6682 a b) ∨ (fact_9fdb227ae99d_6702 a b) ∨ (fact_9fdb227ae99d_6715 a b) ∨ (fact_9fdb227ae99d_6625 a b) ∨ (fact_9fdb227ae99d_6913 a b) ∨ (fact_9fdb227ae99d_7161 a b) ∨ (fact_9fdb227ae99d_7158 a b) ∨ (((((0 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-3 : Int) + ((-1 : Int) * a)) + a) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + ((2 : Int) * b)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b)))) ∨ (((0 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((0 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6931 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n493_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((fact_9fdb227ae99d_3629 a b run_x) ∨ (fact_9fdb227ae99d_3638 a b run_x) ∨ (fact_9fdb227ae99d_5037 a b run_x) ∨ (fact_9fdb227ae99d_5790 a b run_x) ∨ (fact_9fdb227ae99d_4412 a b run_x) ∨ (fact_9fdb227ae99d_3681 a b run_x) ∨ (fact_9fdb227ae99d_3691 a b run_x) ∨ (fact_9fdb227ae99d_3697 a b run_x) ∨ (fact_9fdb227ae99d_3645 a b run_x) ∨ (fact_9fdb227ae99d_4492 a b run_x) ∨ (fact_9fdb227ae99d_5824 a b run_x) ∨ (((((-1 : Int) - a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (((((0 : Int) - a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + ((2 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + ((2 : Int) * b)))) ∨ (((0 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + ((2 : Int) * b)) - b) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (fact_9fdb227ae99d_4526 a b run_x)))
    (h3 : (b = (5 : Int)))
    (h4 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h5 : ((4 : Int) ≤ run_x))
    (h6 : (fact_9fdb227ae99d_3478 a b))
    (h7 : (a ≥ b))
    (h8 : (run_x ≤ ((3 : Int) + b)))
    (h9 : ((((2 : Int) + a) < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < ((2 : Int) + a)) ∨ ((2 : Int) > ((2 : Int) + b)) ∨ ((2 : Int) < ((2 : Int) - (0 : Int)))))
    (h10 : (fact_9fdb227ae99d_107 a b))
    (h11 : ((((2 : Int) + a) < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < ((2 : Int) + a)) ∨ ((3 : Int) > ((2 : Int) + b)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n493_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((3 : Int) + b)))
    (h1 : (¬ ((fact_9fdb227ae99d_5412 a b run_x) ∨ (fact_9fdb227ae99d_5415 a b run_x) ∨ (fact_9fdb227ae99d_5990 a b run_x) ∨ (fact_9fdb227ae99d_6843 a b run_x) ∨ (fact_9fdb227ae99d_5796 a b run_x) ∨ (fact_9fdb227ae99d_5483 a b run_x) ∨ (fact_9fdb227ae99d_5485 a b run_x) ∨ (fact_9fdb227ae99d_5492 a b run_x) ∨ (fact_9fdb227ae99d_5416 a b run_x) ∨ (fact_9fdb227ae99d_5806 a b run_x) ∨ (fact_9fdb227ae99d_6898 a b run_x) ∨ (((((-1 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (((((0 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + ((2 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + ((2 : Int) * b)))) ∨ (((0 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((0 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((3 : Int) + ((2 : Int) * b)) - b) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (fact_9fdb227ae99d_5813 a b run_x))))
    (h2 : ((4 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n494_run_four (a b : Int)
    (h0 : (¬ ((-4 : Int) ≥ ((-3 : Int) + ((-1 : Int) * b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n494_run_short (a b : Int)
    (h0 : (¬ (((-4 : Int) - ((-3 : Int) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n494_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n494_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_5688 a b) ∨ (fact_9fdb227ae99d_5701 a b) ∨ (fact_9fdb227ae99d_6369 a b) ∨ (fact_9fdb227ae99d_6965 a b) ∨ (fact_9fdb227ae99d_5995 a b) ∨ (((((-1 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ (fact_9fdb227ae99d_5772 a b) ∨ (fact_9fdb227ae99d_5777 a b) ∨ (fact_9fdb227ae99d_5708 a b) ∨ (fact_9fdb227ae99d_6119 a b) ∨ (fact_9fdb227ae99d_6982 a b) ∨ (((((-1 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((5 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) - b)) ∧ ((5 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (((((0 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((0 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≤ ((3 : Int) + ((2 : Int) * b)))) ∨ (((0 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((0 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + ((2 : Int) * b)) - b)) ∧ ((5 : Int) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6987 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n494_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3417 a b) ∨ (fact_9fdb227ae99d_3435 a b) ∨ (fact_9fdb227ae99d_4510 a b) ∨ (fact_9fdb227ae99d_5594 a b) ∨ (fact_9fdb227ae99d_3882 a b) ∨ (fact_9fdb227ae99d_3499 a b) ∨ (fact_9fdb227ae99d_3527 a b) ∨ (fact_9fdb227ae99d_3536 a b) ∨ (fact_9fdb227ae99d_3449 a b) ∨ (fact_9fdb227ae99d_4144 a b) ∨ (fact_9fdb227ae99d_5727 a b) ∨ (((((-1 : Int) - a) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((5 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) - b)) ∧ ((5 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (((((0 : Int) - a) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((0 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≤ ((3 : Int) + ((2 : Int) * b)))) ∨ (((0 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((0 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + ((2 : Int) * b)) - b)) ∧ ((5 : Int) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (fact_9fdb227ae99d_5730 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n494_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ ((((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (3 : Int))) ∧ (((fact_9fdb227ae99d_6038 a b) ∨ (fact_9fdb227ae99d_6076 a b) ∨ (fact_9fdb227ae99d_6838 a b) ∨ (fact_9fdb227ae99d_7050 a b) ∨ (fact_9fdb227ae99d_6604 a b) ∨ (fact_9fdb227ae99d_6217 a b) ∨ (fact_9fdb227ae99d_6282 a b) ∨ (fact_9fdb227ae99d_6298 a b) ∨ (fact_9fdb227ae99d_6100 a b) ∨ (fact_9fdb227ae99d_6650 a b) ∨ (fact_9fdb227ae99d_7102 a b) ∨ (fact_9fdb227ae99d_7061 a b) ∨ (fact_9fdb227ae99d_7055 a b) ∨ (fact_9fdb227ae99d_7114 a b)) ∨ (fact_9fdb227ae99d_7925 a b))) ∨ (((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (2 : Int))) ∧ ((fact_9fdb227ae99d_6038 a b) ∨ (fact_9fdb227ae99d_6076 a b) ∨ (fact_9fdb227ae99d_6838 a b) ∨ (fact_9fdb227ae99d_7050 a b) ∨ (fact_9fdb227ae99d_6604 a b) ∨ (fact_9fdb227ae99d_6217 a b) ∨ (fact_9fdb227ae99d_6282 a b) ∨ (fact_9fdb227ae99d_6298 a b) ∨ (fact_9fdb227ae99d_6100 a b) ∨ (fact_9fdb227ae99d_6650 a b) ∨ (fact_9fdb227ae99d_7102 a b) ∨ (fact_9fdb227ae99d_7061 a b) ∨ (fact_9fdb227ae99d_7055 a b) ∨ (fact_9fdb227ae99d_7114 a b)) ∧ (fact_9fdb227ae99d_7925 a b)) ∨ ((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (4 : Int))) ∨ (((-4 : Int) = (((-3 : Int) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((fact_9fdb227ae99d_6038 a b) ∨ (fact_9fdb227ae99d_6076 a b) ∨ (fact_9fdb227ae99d_6838 a b) ∨ (fact_9fdb227ae99d_7050 a b) ∨ (fact_9fdb227ae99d_6604 a b) ∨ (fact_9fdb227ae99d_6217 a b) ∨ (fact_9fdb227ae99d_6282 a b) ∨ (fact_9fdb227ae99d_6298 a b) ∨ (fact_9fdb227ae99d_6100 a b) ∨ (fact_9fdb227ae99d_6650 a b) ∨ (fact_9fdb227ae99d_7102 a b) ∨ (fact_9fdb227ae99d_7061 a b) ∨ (fact_9fdb227ae99d_7055 a b) ∨ (fact_9fdb227ae99d_7114 a b)) ∧ (fact_9fdb227ae99d_7925 a b) ∧ (((fact_9fdb227ae99d_6037 a b) ∨ (fact_9fdb227ae99d_6075 a b) ∨ (fact_9fdb227ae99d_6837 a b) ∨ (fact_9fdb227ae99d_7049 a b) ∨ (fact_9fdb227ae99d_6603 a b) ∨ (fact_9fdb227ae99d_6216 a b) ∨ (fact_9fdb227ae99d_6281 a b) ∨ (fact_9fdb227ae99d_6297 a b) ∨ (fact_9fdb227ae99d_6099 a b) ∨ (fact_9fdb227ae99d_6649 a b) ∨ (fact_9fdb227ae99d_7101 a b) ∨ (fact_9fdb227ae99d_7060 a b) ∨ (((((0 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + ((2 : Int) * b)))) ∨ (((0 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((0 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (fact_9fdb227ae99d_7113 a b)) ∨ ((fact_9fdb227ae99d_4077 a b) ∨ (fact_9fdb227ae99d_4105 a b) ∨ (fact_9fdb227ae99d_5311 a b) ∨ (fact_9fdb227ae99d_5926 a b) ∨ (fact_9fdb227ae99d_4740 a b) ∨ (fact_9fdb227ae99d_4214 a b) ∨ (fact_9fdb227ae99d_4268 a b) ∨ (fact_9fdb227ae99d_4288 a b) ∨ (fact_9fdb227ae99d_4119 a b) ∨ (fact_9fdb227ae99d_5012 a b) ∨ (fact_9fdb227ae99d_6164 a b) ∨ (fact_9fdb227ae99d_5998 a b) ∨ (((((0 : Int) - a) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + ((2 : Int) * b)))) ∨ (((0 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((0 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6170 a b)))) ∨ (((fact_9fdb227ae99d_6038 a b) ∨ (fact_9fdb227ae99d_6076 a b) ∨ (fact_9fdb227ae99d_6838 a b) ∨ (fact_9fdb227ae99d_7050 a b) ∨ (fact_9fdb227ae99d_6604 a b) ∨ (fact_9fdb227ae99d_6217 a b) ∨ (fact_9fdb227ae99d_6282 a b) ∨ (fact_9fdb227ae99d_6298 a b) ∨ (fact_9fdb227ae99d_6100 a b) ∨ (fact_9fdb227ae99d_6650 a b) ∨ (fact_9fdb227ae99d_7102 a b) ∨ (fact_9fdb227ae99d_7061 a b) ∨ (fact_9fdb227ae99d_7055 a b) ∨ (fact_9fdb227ae99d_7114 a b)) ∧ (fact_9fdb227ae99d_7925 a b) ∧ ((fact_9fdb227ae99d_6037 a b) ∨ (fact_9fdb227ae99d_6075 a b) ∨ (fact_9fdb227ae99d_6837 a b) ∨ (fact_9fdb227ae99d_7049 a b) ∨ (fact_9fdb227ae99d_6603 a b) ∨ (fact_9fdb227ae99d_6216 a b) ∨ (fact_9fdb227ae99d_6281 a b) ∨ (fact_9fdb227ae99d_6297 a b) ∨ (fact_9fdb227ae99d_6099 a b) ∨ (fact_9fdb227ae99d_6649 a b) ∨ (fact_9fdb227ae99d_7101 a b) ∨ (fact_9fdb227ae99d_7060 a b) ∨ (((((0 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + ((2 : Int) * b)))) ∨ (((0 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((0 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (fact_9fdb227ae99d_7113 a b)) ∧ ((fact_9fdb227ae99d_4077 a b) ∨ (fact_9fdb227ae99d_4105 a b) ∨ (fact_9fdb227ae99d_5311 a b) ∨ (fact_9fdb227ae99d_5926 a b) ∨ (fact_9fdb227ae99d_4740 a b) ∨ (fact_9fdb227ae99d_4214 a b) ∨ (fact_9fdb227ae99d_4268 a b) ∨ (fact_9fdb227ae99d_4288 a b) ∨ (fact_9fdb227ae99d_4119 a b) ∨ (fact_9fdb227ae99d_5012 a b) ∨ (fact_9fdb227ae99d_6164 a b) ∨ (fact_9fdb227ae99d_5998 a b) ∨ (((((0 : Int) - a) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + ((2 : Int) * b)))) ∨ (((0 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((0 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6170 a b))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n494_run_empty (a b run_x : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (((-3 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((fact_9fdb227ae99d_2368 a b run_x) ∨ (fact_9fdb227ae99d_2385 a b run_x) ∨ (fact_9fdb227ae99d_3041 a b run_x) ∨ (fact_9fdb227ae99d_3482 a b run_x) ∨ (fact_9fdb227ae99d_2929 a b run_x) ∨ (fact_9fdb227ae99d_2463 a b run_x) ∨ (fact_9fdb227ae99d_2478 a b run_x) ∨ (fact_9fdb227ae99d_2484 a b run_x) ∨ (fact_9fdb227ae99d_2399 a b run_x) ∨ (fact_9fdb227ae99d_2949 a b run_x) ∨ (fact_9fdb227ae99d_3614 a b run_x) ∨ (((((-1 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ run_x) ∧ ((-1 : Int) ≥ run_x) ∧ ((5 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) - b)) ∧ ((5 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (((((0 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≤ ((3 : Int) + ((2 : Int) * b)))) ∨ (((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x) ∧ ((5 : Int) ≥ (((3 : Int) + ((2 : Int) * b)) - b)) ∧ ((5 : Int) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3617 a b run_x)))
    (h6 : ((-4 : Int) ≥ run_x))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n494_run_floor (a b run_x : Int)
    (h0 : ((-4 : Int) ≥ run_x))
    (h1 : (¬ ((fact_9fdb227ae99d_3180 a b run_x) ∨ (fact_9fdb227ae99d_3190 a b run_x) ∨ (fact_9fdb227ae99d_3732 a b run_x) ∨ (fact_9fdb227ae99d_5197 a b run_x) ∨ (fact_9fdb227ae99d_3491 a b run_x) ∨ (fact_9fdb227ae99d_3216 a b run_x) ∨ (fact_9fdb227ae99d_3238 a b run_x) ∨ (fact_9fdb227ae99d_3245 a b run_x) ∨ (fact_9fdb227ae99d_3198 a b run_x) ∨ (fact_9fdb227ae99d_3560 a b run_x) ∨ (fact_9fdb227ae99d_5361 a b run_x) ∨ (((((-1 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ run_x) ∧ ((-1 : Int) ≥ run_x) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (((((0 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b)))) ∨ (((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x) ∧ ((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (fact_9fdb227ae99d_5364 a b run_x))))
    (h2 : (((-3 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n495_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (¬ (((-4 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((-4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n495_empty (a b : Int)
    (h0 : ((((2 : Int) + a) < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < ((2 : Int) + a)) ∨ ((3 : Int) > ((2 : Int) + b)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : (b = (5 : Int)))
    (h2 : ((fact_9fdb227ae99d_2876 a b) ∨ (fact_9fdb227ae99d_2879 a b) ∨ (fact_9fdb227ae99d_3265 a b) ∨ (fact_9fdb227ae99d_4172 a b) ∨ (fact_9fdb227ae99d_3107 a b) ∨ (fact_9fdb227ae99d_2965 a b) ∨ (fact_9fdb227ae99d_2969 a b) ∨ (fact_9fdb227ae99d_2970 a b) ∨ (fact_9fdb227ae99d_2882 a b) ∨ (fact_9fdb227ae99d_3109 a b) ∨ (fact_9fdb227ae99d_4398 a b) ∨ ((((-4 : Int) ≥ ((-1 : Int) - a)) ∧ ((-4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) + ((2 : Int) * b))) ∧ ((4 : Int) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-1 : Int)) ∧ ((4 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) - b)) ∧ ((4 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3266 a b)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((((3 : Int) + b + a) - a) ≥ (0 : Int)))
    (h5 : (fact_9fdb227ae99d_3208 a b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n495_o0 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((jx < ((-4 : Int) + ((-1 : Int) * a))) ∨ (((-4 : Int) + ((-1 : Int) * a)) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h8 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n495_o1 (a b jx jy : Int)
    (h0 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n495_o2 (a b jx jy : Int)
    (h0 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (¬ ((((-4 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b = (5 : Int)))
    (h6 : (((jx + (0 : Int)) < ((-4 : Int) + ((-1 : Int) * a))) ∨ (((-4 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h7 : ((jy - b) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n495_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h5 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jy - (0 : Int)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n495_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jy - a))))
    (h7 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n495_o5 (a b jx jy : Int)
    (h0 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h5 : (((jx + (0 : Int)) < ((-4 : Int) + ((-1 : Int) * a))) ∨ (((-4 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h6 : (b = (5 : Int)))
    (h7 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n495_o6 (a b jx jy : Int)
    (h0 : (((-3 : Int) > (jx + b)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h7 : (¬ (((jx = ((-4 : Int) + ((-1 : Int) * b))) ∧ ((4 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n495_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b = (5 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n496_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((3 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n496_run_short (a b : Int)
    (h0 : (¬ ((((3 : Int) + b) - (4 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n496_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n496_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5690 a b) ∨ (fact_9fdb227ae99d_5703 a b) ∨ (fact_9fdb227ae99d_6371 a b) ∨ (fact_9fdb227ae99d_6967 a b) ∨ (fact_9fdb227ae99d_5996 a b) ∨ (fact_9fdb227ae99d_5759 a b) ∨ (fact_9fdb227ae99d_5773 a b) ∨ (fact_9fdb227ae99d_5778 a b) ∨ (fact_9fdb227ae99d_5709 a b) ∨ (fact_9fdb227ae99d_6120 a b) ∨ (fact_9fdb227ae99d_6983 a b) ∨ (((((-1 : Int) - a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6451 a b) ∨ (fact_9fdb227ae99d_6310 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n496_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_6040 a b) ∨ (fact_9fdb227ae99d_6078 a b) ∨ (fact_9fdb227ae99d_6840 a b) ∨ (fact_9fdb227ae99d_7052 a b) ∨ (fact_9fdb227ae99d_6606 a b) ∨ (fact_9fdb227ae99d_6219 a b) ∨ (fact_9fdb227ae99d_6285 a b) ∨ (fact_9fdb227ae99d_6299 a b) ∨ (fact_9fdb227ae99d_6102 a b) ∨ (fact_9fdb227ae99d_6652 a b) ∨ (fact_9fdb227ae99d_7103 a b) ∨ (((((-1 : Int) - a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (((((0 : Int) - b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + b + a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b + a) - a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6738 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n496_run_tall (a b : Int)
    (h0 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((3 : Int) + b)) ∧ (((fact_9fdb227ae99d_6032 a b) ∨ (fact_9fdb227ae99d_6070 a b) ∨ (fact_9fdb227ae99d_6832 a b) ∨ (fact_9fdb227ae99d_7044 a b) ∨ (fact_9fdb227ae99d_6598 a b) ∨ (fact_9fdb227ae99d_6211 a b) ∨ (fact_9fdb227ae99d_6276 a b) ∨ (fact_9fdb227ae99d_6290 a b) ∨ (fact_9fdb227ae99d_6094 a b) ∨ (fact_9fdb227ae99d_6646 a b) ∨ (fact_9fdb227ae99d_7098 a b) ∨ (fact_9fdb227ae99d_7059 a b) ∨ (fact_9fdb227ae99d_6866 a b) ∨ (fact_9fdb227ae99d_6737 a b)) ∨ ((fact_9fdb227ae99d_6619 a b) ∨ (fact_9fdb227ae99d_6623 a b) ∨ (fact_9fdb227ae99d_6991 a b) ∨ (fact_9fdb227ae99d_7152 a b) ∨ (fact_9fdb227ae99d_6911 a b) ∨ (fact_9fdb227ae99d_6684 a b) ∨ (fact_9fdb227ae99d_6704 a b) ∨ (fact_9fdb227ae99d_6716 a b) ∨ (fact_9fdb227ae99d_6627 a b) ∨ (fact_9fdb227ae99d_6915 a b) ∨ (fact_9fdb227ae99d_7163 a b) ∨ (fact_9fdb227ae99d_7159 a b) ∨ (fact_9fdb227ae99d_6994 a b) ∨ (fact_9fdb227ae99d_6933 a b)))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((3 : Int) + b)) ∧ ((fact_9fdb227ae99d_6032 a b) ∨ (fact_9fdb227ae99d_6070 a b) ∨ (fact_9fdb227ae99d_6832 a b) ∨ (fact_9fdb227ae99d_7044 a b) ∨ (fact_9fdb227ae99d_6598 a b) ∨ (fact_9fdb227ae99d_6211 a b) ∨ (fact_9fdb227ae99d_6276 a b) ∨ (fact_9fdb227ae99d_6290 a b) ∨ (fact_9fdb227ae99d_6094 a b) ∨ (fact_9fdb227ae99d_6646 a b) ∨ (fact_9fdb227ae99d_7098 a b) ∨ (fact_9fdb227ae99d_7059 a b) ∨ (fact_9fdb227ae99d_6866 a b) ∨ (fact_9fdb227ae99d_6737 a b)) ∧ ((fact_9fdb227ae99d_6619 a b) ∨ (fact_9fdb227ae99d_6623 a b) ∨ (fact_9fdb227ae99d_6991 a b) ∨ (fact_9fdb227ae99d_7152 a b) ∨ (fact_9fdb227ae99d_6911 a b) ∨ (fact_9fdb227ae99d_6684 a b) ∨ (fact_9fdb227ae99d_6704 a b) ∨ (fact_9fdb227ae99d_6716 a b) ∨ (fact_9fdb227ae99d_6627 a b) ∨ (fact_9fdb227ae99d_6915 a b) ∨ (fact_9fdb227ae99d_7163 a b) ∨ (fact_9fdb227ae99d_7159 a b) ∨ (fact_9fdb227ae99d_6994 a b) ∨ (fact_9fdb227ae99d_6933 a b))) ∨ (((4 : Int) + (4 : Int)) ≤ ((3 : Int) + b)) ∨ ((((3 : Int) + b) = ((4 : Int) + (1 : Int))) ∧ ((fact_9fdb227ae99d_6032 a b) ∨ (fact_9fdb227ae99d_6070 a b) ∨ (fact_9fdb227ae99d_6832 a b) ∨ (fact_9fdb227ae99d_7044 a b) ∨ (fact_9fdb227ae99d_6598 a b) ∨ (fact_9fdb227ae99d_6211 a b) ∨ (fact_9fdb227ae99d_6276 a b) ∨ (fact_9fdb227ae99d_6290 a b) ∨ (fact_9fdb227ae99d_6094 a b) ∨ (fact_9fdb227ae99d_6646 a b) ∨ (fact_9fdb227ae99d_7098 a b) ∨ (fact_9fdb227ae99d_7059 a b) ∨ (fact_9fdb227ae99d_6866 a b) ∨ (fact_9fdb227ae99d_6737 a b)) ∧ ((fact_9fdb227ae99d_6619 a b) ∨ (fact_9fdb227ae99d_6623 a b) ∨ (fact_9fdb227ae99d_6991 a b) ∨ (fact_9fdb227ae99d_7152 a b) ∨ (fact_9fdb227ae99d_6911 a b) ∨ (fact_9fdb227ae99d_6684 a b) ∨ (fact_9fdb227ae99d_6704 a b) ∨ (fact_9fdb227ae99d_6716 a b) ∨ (fact_9fdb227ae99d_6627 a b) ∨ (fact_9fdb227ae99d_6915 a b) ∨ (fact_9fdb227ae99d_7163 a b) ∨ (fact_9fdb227ae99d_7159 a b) ∨ (fact_9fdb227ae99d_6994 a b) ∨ (fact_9fdb227ae99d_6933 a b)) ∧ (((fact_9fdb227ae99d_6030 a b) ∨ (fact_9fdb227ae99d_6068 a b) ∨ (fact_9fdb227ae99d_6830 a b) ∨ (fact_9fdb227ae99d_7042 a b) ∨ (fact_9fdb227ae99d_6596 a b) ∨ (fact_9fdb227ae99d_6209 a b) ∨ (fact_9fdb227ae99d_6274 a b) ∨ (fact_9fdb227ae99d_6289 a b) ∨ (fact_9fdb227ae99d_6092 a b) ∨ (fact_9fdb227ae99d_6645 a b) ∨ (fact_9fdb227ae99d_7096 a b) ∨ (fact_9fdb227ae99d_7058 a b) ∨ (fact_9fdb227ae99d_6865 a b) ∨ (fact_9fdb227ae99d_6735 a b)) ∨ ((fact_9fdb227ae99d_6617 a b) ∨ (fact_9fdb227ae99d_6621 a b) ∨ (fact_9fdb227ae99d_6989 a b) ∨ (fact_9fdb227ae99d_7150 a b) ∨ (fact_9fdb227ae99d_6909 a b) ∨ (fact_9fdb227ae99d_6682 a b) ∨ (fact_9fdb227ae99d_6702 a b) ∨ (fact_9fdb227ae99d_6715 a b) ∨ (fact_9fdb227ae99d_6625 a b) ∨ (fact_9fdb227ae99d_6913 a b) ∨ (fact_9fdb227ae99d_7161 a b) ∨ (fact_9fdb227ae99d_7158 a b) ∨ (fact_9fdb227ae99d_6992 a b) ∨ (fact_9fdb227ae99d_6931 a b)))) ∨ (((fact_9fdb227ae99d_6032 a b) ∨ (fact_9fdb227ae99d_6070 a b) ∨ (fact_9fdb227ae99d_6832 a b) ∨ (fact_9fdb227ae99d_7044 a b) ∨ (fact_9fdb227ae99d_6598 a b) ∨ (fact_9fdb227ae99d_6211 a b) ∨ (fact_9fdb227ae99d_6276 a b) ∨ (fact_9fdb227ae99d_6290 a b) ∨ (fact_9fdb227ae99d_6094 a b) ∨ (fact_9fdb227ae99d_6646 a b) ∨ (fact_9fdb227ae99d_7098 a b) ∨ (fact_9fdb227ae99d_7059 a b) ∨ (fact_9fdb227ae99d_6866 a b) ∨ (fact_9fdb227ae99d_6737 a b)) ∧ ((fact_9fdb227ae99d_6619 a b) ∨ (fact_9fdb227ae99d_6623 a b) ∨ (fact_9fdb227ae99d_6991 a b) ∨ (fact_9fdb227ae99d_7152 a b) ∨ (fact_9fdb227ae99d_6911 a b) ∨ (fact_9fdb227ae99d_6684 a b) ∨ (fact_9fdb227ae99d_6704 a b) ∨ (fact_9fdb227ae99d_6716 a b) ∨ (fact_9fdb227ae99d_6627 a b) ∨ (fact_9fdb227ae99d_6915 a b) ∨ (fact_9fdb227ae99d_7163 a b) ∨ (fact_9fdb227ae99d_7159 a b) ∨ (fact_9fdb227ae99d_6994 a b) ∨ (fact_9fdb227ae99d_6933 a b)) ∧ ((fact_9fdb227ae99d_6030 a b) ∨ (fact_9fdb227ae99d_6068 a b) ∨ (fact_9fdb227ae99d_6830 a b) ∨ (fact_9fdb227ae99d_7042 a b) ∨ (fact_9fdb227ae99d_6596 a b) ∨ (fact_9fdb227ae99d_6209 a b) ∨ (fact_9fdb227ae99d_6274 a b) ∨ (fact_9fdb227ae99d_6289 a b) ∨ (fact_9fdb227ae99d_6092 a b) ∨ (fact_9fdb227ae99d_6645 a b) ∨ (fact_9fdb227ae99d_7096 a b) ∨ (fact_9fdb227ae99d_7058 a b) ∨ (fact_9fdb227ae99d_6865 a b) ∨ (fact_9fdb227ae99d_6735 a b)) ∧ ((fact_9fdb227ae99d_6617 a b) ∨ (fact_9fdb227ae99d_6621 a b) ∨ (fact_9fdb227ae99d_6989 a b) ∨ (fact_9fdb227ae99d_7150 a b) ∨ (fact_9fdb227ae99d_6909 a b) ∨ (fact_9fdb227ae99d_6682 a b) ∨ (fact_9fdb227ae99d_6702 a b) ∨ (fact_9fdb227ae99d_6715 a b) ∨ (fact_9fdb227ae99d_6625 a b) ∨ (fact_9fdb227ae99d_6913 a b) ∨ (fact_9fdb227ae99d_7161 a b) ∨ (fact_9fdb227ae99d_7158 a b) ∨ (fact_9fdb227ae99d_6992 a b) ∨ (fact_9fdb227ae99d_6931 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n496_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (run_x ≤ ((3 : Int) + b)))
    (h3 : (a ≥ b))
    (h4 : ((4 : Int) ≤ run_x))
    (h5 : ((((2 : Int) + a) < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < ((2 : Int) + a)) ∨ ((3 : Int) > ((2 : Int) + b)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h6 : (fact_9fdb227ae99d_3478 a b))
    (h7 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h8 : ((fact_9fdb227ae99d_3629 a b run_x) ∨ (fact_9fdb227ae99d_3638 a b run_x) ∨ (fact_9fdb227ae99d_5037 a b run_x) ∨ (fact_9fdb227ae99d_5790 a b run_x) ∨ (fact_9fdb227ae99d_4412 a b run_x) ∨ (fact_9fdb227ae99d_3681 a b run_x) ∨ (fact_9fdb227ae99d_3691 a b run_x) ∨ (fact_9fdb227ae99d_3697 a b run_x) ∨ (fact_9fdb227ae99d_3645 a b run_x) ∨ (fact_9fdb227ae99d_4492 a b run_x) ∨ (fact_9fdb227ae99d_5824 a b run_x) ∨ (((((-1 : Int) - a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (fact_9fdb227ae99d_5101 a b run_x) ∨ (fact_9fdb227ae99d_4526 a b run_x)))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (fact_9fdb227ae99d_107 a b))
    (h11 : ((((2 : Int) + a) < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < ((2 : Int) + a)) ∨ ((2 : Int) > ((2 : Int) + b)) ∨ ((2 : Int) < ((2 : Int) - (0 : Int)))))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n496_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5412 a b run_x) ∨ (fact_9fdb227ae99d_5415 a b run_x) ∨ (fact_9fdb227ae99d_5990 a b run_x) ∨ (fact_9fdb227ae99d_6843 a b run_x) ∨ (fact_9fdb227ae99d_5796 a b run_x) ∨ (fact_9fdb227ae99d_5483 a b run_x) ∨ (fact_9fdb227ae99d_5485 a b run_x) ∨ (fact_9fdb227ae99d_5492 a b run_x) ∨ (fact_9fdb227ae99d_5416 a b run_x) ∨ (fact_9fdb227ae99d_5806 a b run_x) ∨ (fact_9fdb227ae99d_6898 a b run_x) ∨ (((((-1 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6041 a b run_x) ∨ (fact_9fdb227ae99d_5813 a b run_x))))
    (h1 : (run_x ≤ ((3 : Int) + b)))
    (h2 : ((4 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n497_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((-4 : Int) ≥ ((-3 : Int) + ((-1 : Int) * b)))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n497_run_short (a b : Int)
    (h0 : (¬ (((-4 : Int) - ((-3 : Int) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n497_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n497_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5688 a b) ∨ (fact_9fdb227ae99d_5701 a b) ∨ (fact_9fdb227ae99d_6369 a b) ∨ (fact_9fdb227ae99d_6965 a b) ∨ (fact_9fdb227ae99d_5995 a b) ∨ (((((-1 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ (fact_9fdb227ae99d_5772 a b) ∨ (fact_9fdb227ae99d_5777 a b) ∨ (fact_9fdb227ae99d_5708 a b) ∨ (fact_9fdb227ae99d_6119 a b) ∨ (fact_9fdb227ae99d_6982 a b) ∨ (((((-1 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((5 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) - b)) ∧ ((5 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (((((0 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((0 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + b + a)) ∧ ((5 : Int) ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((0 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + b + a) - a)) ∧ ((5 : Int) ≤ (((3 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6987 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n497_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3417 a b) ∨ (fact_9fdb227ae99d_3435 a b) ∨ (fact_9fdb227ae99d_4510 a b) ∨ (fact_9fdb227ae99d_5594 a b) ∨ (fact_9fdb227ae99d_3882 a b) ∨ (fact_9fdb227ae99d_3499 a b) ∨ (fact_9fdb227ae99d_3527 a b) ∨ (fact_9fdb227ae99d_3536 a b) ∨ (fact_9fdb227ae99d_3449 a b) ∨ (fact_9fdb227ae99d_4144 a b) ∨ (fact_9fdb227ae99d_5727 a b) ∨ (((((-1 : Int) - a) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((5 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) - b)) ∧ ((5 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (fact_9fdb227ae99d_4529 a b) ∨ (fact_9fdb227ae99d_5730 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n497_run_tall (a b : Int)
    (h0 : (¬ ((((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (3 : Int))) ∧ (((fact_9fdb227ae99d_6038 a b) ∨ (fact_9fdb227ae99d_6076 a b) ∨ (fact_9fdb227ae99d_6838 a b) ∨ (fact_9fdb227ae99d_7050 a b) ∨ (fact_9fdb227ae99d_6604 a b) ∨ (fact_9fdb227ae99d_6217 a b) ∨ (fact_9fdb227ae99d_6282 a b) ∨ (fact_9fdb227ae99d_6298 a b) ∨ (fact_9fdb227ae99d_6100 a b) ∨ (fact_9fdb227ae99d_6650 a b) ∨ (fact_9fdb227ae99d_7102 a b) ∨ (fact_9fdb227ae99d_7061 a b) ∨ (fact_9fdb227ae99d_6868 a b) ∨ (fact_9fdb227ae99d_7114 a b)) ∨ (fact_9fdb227ae99d_7924 a b))) ∨ (((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (2 : Int))) ∧ ((fact_9fdb227ae99d_6038 a b) ∨ (fact_9fdb227ae99d_6076 a b) ∨ (fact_9fdb227ae99d_6838 a b) ∨ (fact_9fdb227ae99d_7050 a b) ∨ (fact_9fdb227ae99d_6604 a b) ∨ (fact_9fdb227ae99d_6217 a b) ∨ (fact_9fdb227ae99d_6282 a b) ∨ (fact_9fdb227ae99d_6298 a b) ∨ (fact_9fdb227ae99d_6100 a b) ∨ (fact_9fdb227ae99d_6650 a b) ∨ (fact_9fdb227ae99d_7102 a b) ∨ (fact_9fdb227ae99d_7061 a b) ∨ (fact_9fdb227ae99d_6868 a b) ∨ (fact_9fdb227ae99d_7114 a b)) ∧ (fact_9fdb227ae99d_7924 a b)) ∨ ((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (4 : Int))) ∨ (((-4 : Int) = (((-3 : Int) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((fact_9fdb227ae99d_6038 a b) ∨ (fact_9fdb227ae99d_6076 a b) ∨ (fact_9fdb227ae99d_6838 a b) ∨ (fact_9fdb227ae99d_7050 a b) ∨ (fact_9fdb227ae99d_6604 a b) ∨ (fact_9fdb227ae99d_6217 a b) ∨ (fact_9fdb227ae99d_6282 a b) ∨ (fact_9fdb227ae99d_6298 a b) ∨ (fact_9fdb227ae99d_6100 a b) ∨ (fact_9fdb227ae99d_6650 a b) ∨ (fact_9fdb227ae99d_7102 a b) ∨ (fact_9fdb227ae99d_7061 a b) ∨ (fact_9fdb227ae99d_6868 a b) ∨ (fact_9fdb227ae99d_7114 a b)) ∧ (fact_9fdb227ae99d_7924 a b) ∧ (((fact_9fdb227ae99d_6037 a b) ∨ (fact_9fdb227ae99d_6075 a b) ∨ (fact_9fdb227ae99d_6837 a b) ∨ (fact_9fdb227ae99d_7049 a b) ∨ (fact_9fdb227ae99d_6603 a b) ∨ (fact_9fdb227ae99d_6216 a b) ∨ (fact_9fdb227ae99d_6281 a b) ∨ (fact_9fdb227ae99d_6297 a b) ∨ (fact_9fdb227ae99d_6099 a b) ∨ (fact_9fdb227ae99d_6649 a b) ∨ (fact_9fdb227ae99d_7101 a b) ∨ (fact_9fdb227ae99d_7060 a b) ∨ (fact_9fdb227ae99d_6867 a b) ∨ (fact_9fdb227ae99d_7113 a b)) ∨ ((fact_9fdb227ae99d_4077 a b) ∨ (fact_9fdb227ae99d_4105 a b) ∨ (fact_9fdb227ae99d_5311 a b) ∨ (fact_9fdb227ae99d_5926 a b) ∨ (fact_9fdb227ae99d_4740 a b) ∨ (fact_9fdb227ae99d_4214 a b) ∨ (fact_9fdb227ae99d_4268 a b) ∨ (fact_9fdb227ae99d_4288 a b) ∨ (fact_9fdb227ae99d_4119 a b) ∨ (fact_9fdb227ae99d_5012 a b) ∨ (fact_9fdb227ae99d_6164 a b) ∨ (fact_9fdb227ae99d_5998 a b) ∨ (fact_9fdb227ae99d_5341 a b) ∨ (fact_9fdb227ae99d_6170 a b)))) ∨ (((fact_9fdb227ae99d_6038 a b) ∨ (fact_9fdb227ae99d_6076 a b) ∨ (fact_9fdb227ae99d_6838 a b) ∨ (fact_9fdb227ae99d_7050 a b) ∨ (fact_9fdb227ae99d_6604 a b) ∨ (fact_9fdb227ae99d_6217 a b) ∨ (fact_9fdb227ae99d_6282 a b) ∨ (fact_9fdb227ae99d_6298 a b) ∨ (fact_9fdb227ae99d_6100 a b) ∨ (fact_9fdb227ae99d_6650 a b) ∨ (fact_9fdb227ae99d_7102 a b) ∨ (fact_9fdb227ae99d_7061 a b) ∨ (fact_9fdb227ae99d_6868 a b) ∨ (fact_9fdb227ae99d_7114 a b)) ∧ (fact_9fdb227ae99d_7924 a b) ∧ ((fact_9fdb227ae99d_6037 a b) ∨ (fact_9fdb227ae99d_6075 a b) ∨ (fact_9fdb227ae99d_6837 a b) ∨ (fact_9fdb227ae99d_7049 a b) ∨ (fact_9fdb227ae99d_6603 a b) ∨ (fact_9fdb227ae99d_6216 a b) ∨ (fact_9fdb227ae99d_6281 a b) ∨ (fact_9fdb227ae99d_6297 a b) ∨ (fact_9fdb227ae99d_6099 a b) ∨ (fact_9fdb227ae99d_6649 a b) ∨ (fact_9fdb227ae99d_7101 a b) ∨ (fact_9fdb227ae99d_7060 a b) ∨ (fact_9fdb227ae99d_6867 a b) ∨ (fact_9fdb227ae99d_7113 a b)) ∧ ((fact_9fdb227ae99d_4077 a b) ∨ (fact_9fdb227ae99d_4105 a b) ∨ (fact_9fdb227ae99d_5311 a b) ∨ (fact_9fdb227ae99d_5926 a b) ∨ (fact_9fdb227ae99d_4740 a b) ∨ (fact_9fdb227ae99d_4214 a b) ∨ (fact_9fdb227ae99d_4268 a b) ∨ (fact_9fdb227ae99d_4288 a b) ∨ (fact_9fdb227ae99d_4119 a b) ∨ (fact_9fdb227ae99d_5012 a b) ∨ (fact_9fdb227ae99d_6164 a b) ∨ (fact_9fdb227ae99d_5998 a b) ∨ (fact_9fdb227ae99d_5341 a b) ∨ (fact_9fdb227ae99d_6170 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n497_run_empty (a b run_x : Int)
    (h0 : ((-4 : Int) ≥ run_x))
    (h1 : (((-3 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((fact_9fdb227ae99d_2368 a b run_x) ∨ (fact_9fdb227ae99d_2385 a b run_x) ∨ (fact_9fdb227ae99d_3041 a b run_x) ∨ (fact_9fdb227ae99d_3482 a b run_x) ∨ (fact_9fdb227ae99d_2929 a b run_x) ∨ (fact_9fdb227ae99d_2463 a b run_x) ∨ (fact_9fdb227ae99d_2478 a b run_x) ∨ (fact_9fdb227ae99d_2484 a b run_x) ∨ (fact_9fdb227ae99d_2399 a b run_x) ∨ (fact_9fdb227ae99d_2949 a b run_x) ∨ (fact_9fdb227ae99d_3614 a b run_x) ∨ (((((-1 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((1 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ run_x) ∧ ((-1 : Int) ≥ run_x) ∧ ((5 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) - b)) ∧ ((5 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3048 a b run_x) ∨ (fact_9fdb227ae99d_3617 a b run_x)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n497_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3180 a b run_x) ∨ (fact_9fdb227ae99d_3190 a b run_x) ∨ (fact_9fdb227ae99d_3732 a b run_x) ∨ (fact_9fdb227ae99d_5197 a b run_x) ∨ (fact_9fdb227ae99d_3491 a b run_x) ∨ (fact_9fdb227ae99d_3216 a b run_x) ∨ (fact_9fdb227ae99d_3238 a b run_x) ∨ (fact_9fdb227ae99d_3245 a b run_x) ∨ (fact_9fdb227ae99d_3198 a b run_x) ∨ (fact_9fdb227ae99d_3560 a b run_x) ∨ (fact_9fdb227ae99d_5361 a b run_x) ∨ (((((-1 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ run_x) ∧ ((-1 : Int) ≥ run_x) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3779 a b run_x) ∨ (fact_9fdb227ae99d_5364 a b run_x))))
    (h1 : ((-4 : Int) ≥ run_x))
    (h2 : (((-3 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n498_run_four (a b : Int)
    (h0 : (¬ (((2 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * b)))))
    (h1 : (((3 : Int) < ((0 : Int) - (0 : Int))) ∨ ((3 : Int) > ((0 : Int) + a)) ∨ ((((4 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (((4 : Int) + a) - a))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n498_run_short (a b : Int)
    (h0 : (a > b))
    (h1 : (¬ ((((2 : Int) + ((2 : Int) * b)) - ((2 : Int) + a)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n498_run_nonnegative (a b : Int)
    (h0 : (¬ (((2 : Int) + a) ≥ (0 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n498_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3845 a b) ∨ (fact_9fdb227ae99d_3846 a b) ∨ (fact_9fdb227ae99d_5286 a b) ∨ (fact_9fdb227ae99d_5900 a b) ∨ (fact_9fdb227ae99d_4704 a b) ∨ (fact_9fdb227ae99d_4180 a b) ∨ ((((1 : Int) ≥ ((-2 : Int) - b)) ∧ ((1 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + a) - (1 : Int)))) ∨ (((-2 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-2 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((1 : Int) ≥ ((-3 : Int) - a)) ∧ ((1 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + a) - (1 : Int)))) ∨ (((-3 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3847 a b) ∨ (fact_9fdb227ae99d_4705 a b) ∨ (fact_9fdb227ae99d_6129 a b) ∨ ((((1 : Int) ≥ ((-1 : Int) - a)) ∧ ((1 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-1 : Int)) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (fact_9fdb227ae99d_5901 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n498_run_right (a b : Int)
    (h0 : (¬ (((((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ ((((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((1 : Int) ≥ (((1 : Int) + b + a) - a)) ∧ ((1 : Int) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((1 : Int) ≥ ((1 : Int) + b + a)) ∧ ((1 : Int) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((1 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - b)) ∧ ((1 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((1 : Int) ≥ ((2 : Int) + ((2 : Int) * b))) ∧ ((1 : Int) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((1 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((1 : Int) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((1 : Int) ≥ ((2 : Int) + a)) ∧ ((1 : Int) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ ((((1 : Int) ≥ ((-1 : Int) - a)) ∧ ((1 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((-1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((1 : Int) ≥ ((-2 : Int) - b)) ∧ ((1 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((-2 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-2 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((1 : Int) ≥ ((-3 : Int) - a)) ∧ ((1 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((-3 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ ((((1 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((2 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (2 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ ((((1 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((((4 : Int) + a) - a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((1 : Int) ≥ (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((1 : Int) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((1 : Int) ≥ ((-4 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ ((((1 : Int) ≥ ((-1 : Int) - a)) ∧ ((1 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-1 : Int)) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ ((((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + a)) ∧ (((3 : Int) + ((2 : Int) * b)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b)))) ∨ (((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int)) ∧ ((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n498_run_tall (a b : Int)
    (h0 : (((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int)) ∨ (((0 : Int) + a) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((0 : Int) - (0 : Int)))))
    (h1 : (a > b))
    (h2 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h3 : (¬ ((((((2 : Int) + a) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((fact_9fdb227ae99d_7920 a b) ∨ (fact_9fdb227ae99d_7941 a b))) ∨ (((((2 : Int) + a) + (2 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (fact_9fdb227ae99d_7920 a b) ∧ (fact_9fdb227ae99d_7941 a b)) ∨ ((((2 : Int) + a) + (4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∨ ((((2 : Int) + ((2 : Int) * b)) = (((2 : Int) + a) + (1 : Int))) ∧ (fact_9fdb227ae99d_7920 a b) ∧ (fact_9fdb227ae99d_7941 a b) ∧ (((fact_9fdb227ae99d_4589 a b) ∨ (fact_9fdb227ae99d_4624 a b) ∨ (fact_9fdb227ae99d_5654 a b) ∨ (fact_9fdb227ae99d_6393 a b) ∨ (fact_9fdb227ae99d_5383 a b) ∨ (fact_9fdb227ae99d_4765 a b) ∨ (fact_9fdb227ae99d_4834 a b) ∨ (fact_9fdb227ae99d_4870 a b) ∨ (fact_9fdb227ae99d_4647 a b) ∨ (fact_9fdb227ae99d_5433 a b) ∨ (fact_9fdb227ae99d_6561 a b) ∨ (((((-1 : Int) - a) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ ((1 : Int) + a)) ∧ ((-1 : Int) ≥ ((1 : Int) + a)) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6449 a b)) ∨ ((((((0 : Int) - (0 : Int)) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((0 : Int) ≤ ((1 : Int) + a)) ∧ ((0 : Int) ≥ ((1 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((1 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≥ ((1 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ ((((2 : Int) + a) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((-1 : Int) ≤ ((1 : Int) + a)) ∧ ((-1 : Int) ≥ ((1 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((-2 : Int) ≤ ((1 : Int) + a)) ∧ ((-2 : Int) ≥ ((1 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((-3 : Int) - a) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((-3 : Int) ≤ ((1 : Int) + a)) ∧ ((-3 : Int) ≥ ((1 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((2 : Int) ≤ ((1 : Int) + a)) ∧ ((2 : Int) ≥ ((1 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((1 : Int) + a)) ∧ ((3 : Int) ≥ ((1 : Int) + a)) ∧ ((((4 : Int) + a) - a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((-4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ ((1 : Int) + a)) ∧ ((-1 : Int) ≥ ((1 : Int) + a)) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((0 : Int) + a)) ∧ (((3 : Int) + ((2 : Int) * b)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b)))) ∨ (((0 : Int) ≤ ((1 : Int) + a)) ∧ ((0 : Int) ≥ ((1 : Int) + a)) ∧ ((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int)))))))) ∨ ((fact_9fdb227ae99d_7920 a b) ∧ (fact_9fdb227ae99d_7941 a b) ∧ ((fact_9fdb227ae99d_4589 a b) ∨ (fact_9fdb227ae99d_4624 a b) ∨ (fact_9fdb227ae99d_5654 a b) ∨ (fact_9fdb227ae99d_6393 a b) ∨ (fact_9fdb227ae99d_5383 a b) ∨ (fact_9fdb227ae99d_4765 a b) ∨ (fact_9fdb227ae99d_4834 a b) ∨ (fact_9fdb227ae99d_4870 a b) ∨ (fact_9fdb227ae99d_4647 a b) ∨ (fact_9fdb227ae99d_5433 a b) ∨ (fact_9fdb227ae99d_6561 a b) ∨ (((((-1 : Int) - a) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ ((1 : Int) + a)) ∧ ((-1 : Int) ≥ ((1 : Int) + a)) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6449 a b)) ∧ ((((((0 : Int) - (0 : Int)) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((0 : Int) ≤ ((1 : Int) + a)) ∧ ((0 : Int) ≥ ((1 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((1 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≥ ((1 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ ((((2 : Int) + a) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((-1 : Int) ≤ ((1 : Int) + a)) ∧ ((-1 : Int) ≥ ((1 : Int) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((-2 : Int) ≤ ((1 : Int) + a)) ∧ ((-2 : Int) ≥ ((1 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((-3 : Int) - a) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((-3 : Int) ≤ ((1 : Int) + a)) ∧ ((-3 : Int) ≥ ((1 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ (((2 : Int) ≤ ((1 : Int) + a)) ∧ ((2 : Int) ≥ ((1 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((3 : Int) + b)) ∧ (((4 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((3 : Int) ≤ ((1 : Int) + a)) ∧ ((3 : Int) ≥ ((1 : Int) + a)) ∧ ((((4 : Int) + a) - a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((((-4 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int)))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ ((1 : Int) + a)) ∧ ((-1 : Int) ≥ ((1 : Int) + a)) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((0 : Int) + a)) ∧ (((3 : Int) + ((2 : Int) * b)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b)))) ∨ (((0 : Int) ≤ ((1 : Int) + a)) ∧ ((0 : Int) ≥ ((1 : Int) + a)) ∧ ((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))))))))))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n498_run_empty (a b run_x : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((((1 : Int) + ((2 : Int) * b)) - b) ≥ (0 : Int)))
    (h2 : (((2 : Int) + a) ≤ run_x))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_3478 a b))
    (h6 : ((((2 : Int) + a) < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < ((2 : Int) + a)) ∨ ((2 : Int) > ((2 : Int) + b)) ∨ ((2 : Int) < ((2 : Int) - (0 : Int)))))
    (h7 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h8 : ((fact_9fdb227ae99d_2431 a b run_x) ∨ (fact_9fdb227ae99d_2432 a b run_x) ∨ (fact_9fdb227ae99d_3059 a b run_x) ∨ (fact_9fdb227ae99d_3565 a b run_x) ∨ (fact_9fdb227ae99d_2974 a b run_x) ∨ (fact_9fdb227ae99d_2529 a b run_x) ∨ ((((1 : Int) ≥ ((-2 : Int) - b)) ∧ ((1 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-2 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ ((((1 : Int) ≥ ((-3 : Int) - a)) ∧ ((1 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_2433 a b run_x) ∨ (fact_9fdb227ae99d_2975 a b run_x) ∨ (fact_9fdb227ae99d_3666 a b run_x) ∨ ((((1 : Int) ≥ ((-1 : Int) - a)) ∧ ((1 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (-1 : Int)) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3566 a b run_x)))
    (h9 : (fact_9fdb227ae99d_107 a b))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n498_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h1 : (((2 : Int) + a) ≤ run_x))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (¬ ((fact_9fdb227ae99d_3172 a b run_x) ∨ (fact_9fdb227ae99d_3182 a b run_x) ∨ (fact_9fdb227ae99d_3725 a b run_x) ∨ (fact_9fdb227ae99d_5190 a b run_x) ∨ (fact_9fdb227ae99d_3484 a b run_x) ∨ (fact_9fdb227ae99d_3210 a b run_x) ∨ (((((-2 : Int) - b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((-2 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ (((((-3 : Int) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3192 a b run_x) ∨ (fact_9fdb227ae99d_3555 a b run_x) ∨ (fact_9fdb227ae99d_5358 a b run_x) ∨ (((((-1 : Int) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((1 : Int) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (fact_9fdb227ae99d_5261 a b run_x))))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (b = (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n499_point (a b : Int)
    (h0 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_1 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n499_empty (a b : Int)
    (h0 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h1 : ((fact_9fdb227ae99d_3051 a b) ∨ (fact_9fdb227ae99d_3053 a b) ∨ (fact_9fdb227ae99d_3563 a b) ∨ (fact_9fdb227ae99d_4701 a b) ∨ (fact_9fdb227ae99d_3285 a b) ∨ (fact_9fdb227ae99d_3112 a b) ∨ ((((0 : Int) ≥ ((-2 : Int) - b)) ∧ ((0 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + b)) ∧ ((1 : Int) ≥ ((3 : Int) + b))) ∨ (((-2 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (-2 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((1 : Int) + a)))) ∨ ((((0 : Int) ≥ ((-3 : Int) - a)) ∧ ((0 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + b)) ∧ ((2 : Int) ≥ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3055 a b) ∨ (fact_9fdb227ae99d_3292 a b) ∨ (fact_9fdb227ae99d_5105 a b) ∨ (fact_9fdb227ae99d_3598 a b)))
    (h2 : (fact_9fdb227ae99d_3206 a b))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n499_o0 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (fact_9fdb227ae99d_1606 a b jx jy))
    (h2 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h3 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n499_o1 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_2923 a b jy))
    (h3 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - a))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (¬ ((((0 : Int) = jx) ∧ (jy = ((3 : Int) + b + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h8 : (b = (5 : Int)))
    (h9 : (fact_9fdb227ae99d_1611 a b jx jy))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n499_o2 (a b jx jy : Int)
    (h0 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - b))))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (((jx + (0 : Int)) < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < (jx - a)) ∨ (jy < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < jy)))
    (h4 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (fact_9fdb227ae99d_1615 a b jx jy))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((jy - b) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n499_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h5 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h8 : (fact_9fdb227ae99d_1618 a b jx jy))
    (h9 : (fact_9fdb227ae99d_107 a b))
    (h10 : (b = (5 : Int)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n499_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_1619 a b jx jy))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (¬ ((((0 : Int) = jx) ∧ (jy = ((3 : Int) + b + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h4 : (fact_9fdb227ae99d_2922 a b jy))
    (h5 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - a))))
    (h6 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - a))))
    (h9 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h10 : ((jy - a) ≥ (0 : Int)))
    (h11 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - a))))
    (h12 : (b = (5 : Int)))
    (h13 : (a ≥ b))
    (h14 : (a > b))
    (h15 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n499_o5 (a b jx jy : Int)
    (h0 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h1 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_1614 a b jx jy))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n499_o6 (a b jx jy : Int)
    (h0 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_1610 a b jx jy))
    (h3 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h9 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n499_o7 (a b jx jy : Int)
    (h0 : (¬ ((((0 : Int) = jx) ∧ (jy = ((3 : Int) + ((2 : Int) * b))) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h1 : (fact_9fdb227ae99d_1607 a b jx jy))
    (h2 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - b))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h5 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : (fact_9fdb227ae99d_107 a b))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n500_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_2 a b))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n500_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_3061 a b) ∨ (fact_9fdb227ae99d_3062 a b) ∨ (fact_9fdb227ae99d_3567 a b) ∨ (fact_9fdb227ae99d_4706 a b) ∨ (fact_9fdb227ae99d_3298 a b) ∨ (fact_9fdb227ae99d_3118 a b) ∨ ((((2 : Int) ≥ ((-2 : Int) - b)) ∧ ((2 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + a)) ∧ ((1 : Int) ≥ ((4 : Int) + a))) ∨ (((-2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-2 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((1 : Int) + a)))) ∨ ((((2 : Int) ≥ ((-3 : Int) - a)) ∧ ((2 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((-3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3063 a b) ∨ (fact_9fdb227ae99d_3299 a b) ∨ (fact_9fdb227ae99d_5106 a b) ∨ (fact_9fdb227ae99d_3599 a b) ∨ (fact_9fdb227ae99d_3568 a b)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n500_o0 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (fact_9fdb227ae99d_1672 a b jx jy))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h5 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((1 : Int) + b + a)) ∨ (((1 : Int) + b + a) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + b) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - (0 : Int)))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n500_o1 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (((-3 : Int) > jx) ∨ ((-3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - a))))
    (h4 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - a))))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - a))))
    (h8 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h9 : (fact_9fdb227ae99d_1675 a b jx jy))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n500_o2 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (fact_9fdb227ae99d_1677 a b jx jy))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - b))))
    (h4 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - b))))
    (h5 : (b = (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a > b))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n500_o3 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h1 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h2 : (fact_9fdb227ae99d_1678 a b jx jy))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h8 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h9 : (b = (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n500_o4 (a b jx jy : Int)
    (h0 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - a))))
    (h1 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (fact_9fdb227ae99d_1679 a b jx jy))
    (h7 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - a))))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n500_o5 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (((jx + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jx - a)) ∨ (jy < ((4 : Int) + a)) ∨ (((4 : Int) + a) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (fact_9fdb227ae99d_1676 a b jx jy))
    (h6 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h7 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (b = (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n500_o6 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h1 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + a) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - (0 : Int)))))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_9fdb227ae99d_1674 a b jx jy))
    (h5 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n500_o7 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + b + a) - a)) ∨ ((((3 : Int) + b + a) + (0 : Int)) < jy)))
    (h3 : (fact_9fdb227ae99d_1673 a b jx jy))
    (h4 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b + a)) ∨ (((3 : Int) + b + a) < (jy - b))))
    (h5 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - b))))
    (h8 : ((jy - b) ≥ (0 : Int)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n501_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (¬ (((-4 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((-4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n501_empty (a b : Int)
    (h0 : (fact_9fdb227ae99d_3208 a b))
    (h1 : ((((2 : Int) + a) < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < ((2 : Int) + a)) ∨ ((3 : Int) > ((2 : Int) + b)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : ((fact_9fdb227ae99d_2876 a b) ∨ (fact_9fdb227ae99d_2879 a b) ∨ (fact_9fdb227ae99d_3265 a b) ∨ (fact_9fdb227ae99d_4172 a b) ∨ (fact_9fdb227ae99d_3107 a b) ∨ (fact_9fdb227ae99d_2965 a b) ∨ (fact_9fdb227ae99d_2969 a b) ∨ (fact_9fdb227ae99d_2970 a b) ∨ (fact_9fdb227ae99d_2882 a b) ∨ (fact_9fdb227ae99d_3109 a b) ∨ (fact_9fdb227ae99d_4398 a b) ∨ ((((-4 : Int) ≥ ((-1 : Int) - b)) ∧ ((-4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) + b + a)) ∧ ((4 : Int) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-1 : Int)) ∧ ((4 : Int) ≥ (((1 : Int) + b + a) - a)) ∧ ((4 : Int) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3266 a b)))
    (h3 : ((((3 : Int) + b + a) - a) ≥ (0 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n501_o0 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h9 : ((jx < ((-4 : Int) + ((-1 : Int) * a))) ∨ (((-4 : Int) + ((-1 : Int) * a)) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n501_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + b + a) - a)) ∨ ((((3 : Int) + b + a) + (0 : Int)) < jy)))
    (h5 : (fact_9fdb227ae99d_2923 a b jy))
    (h6 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n501_o2 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (((jx + (0 : Int)) < ((-4 : Int) + ((-1 : Int) * a))) ∨ (((-4 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h2 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (¬ ((((-4 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h5 : (b = (5 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jy - b) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n501_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h3 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h4 : (¬ ((((-4 : Int) = jx) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : (b = (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n501_o4 (a b jx jy : Int)
    (h0 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h5 : (b = (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (¬ ((((-4 : Int) = jx) ∧ (jy = ((4 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n501_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h2 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h3 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b = (5 : Int)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (((jx + (0 : Int)) < ((-4 : Int) + ((-1 : Int) * a))) ∨ (((-4 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n501_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h3 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (¬ (((jx = ((-4 : Int) + ((-1 : Int) * b))) ∧ ((4 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : (((-3 : Int) > (jx + b)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n501_o7 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (fact_9fdb227ae99d_2925 a b jy))
    (h6 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n502_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((4 : Int) ≤ ((3 : Int) + b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n502_run_short (a b : Int)
    (h0 : (¬ ((((3 : Int) + b) - (4 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n502_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n502_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5690 a b) ∨ (fact_9fdb227ae99d_5703 a b) ∨ (fact_9fdb227ae99d_6371 a b) ∨ (fact_9fdb227ae99d_6967 a b) ∨ (fact_9fdb227ae99d_5996 a b) ∨ (fact_9fdb227ae99d_5759 a b) ∨ (fact_9fdb227ae99d_5773 a b) ∨ (fact_9fdb227ae99d_5778 a b) ∨ (fact_9fdb227ae99d_5709 a b) ∨ (fact_9fdb227ae99d_6120 a b) ∨ (fact_9fdb227ae99d_6983 a b) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + b + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6451 a b) ∨ (fact_9fdb227ae99d_6310 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n502_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_6040 a b) ∨ (fact_9fdb227ae99d_6078 a b) ∨ (fact_9fdb227ae99d_6840 a b) ∨ (fact_9fdb227ae99d_7052 a b) ∨ (fact_9fdb227ae99d_6606 a b) ∨ (fact_9fdb227ae99d_6219 a b) ∨ (fact_9fdb227ae99d_6285 a b) ∨ (fact_9fdb227ae99d_6299 a b) ∨ (fact_9fdb227ae99d_6102 a b) ∨ (fact_9fdb227ae99d_6652 a b) ∨ (fact_9fdb227ae99d_7103 a b) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + b + a) - a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (((((0 : Int) - b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + b + a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b + a) - a) ≤ (((3 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6738 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n502_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((3 : Int) + b)) ∧ (((fact_9fdb227ae99d_6032 a b) ∨ (fact_9fdb227ae99d_6070 a b) ∨ (fact_9fdb227ae99d_6832 a b) ∨ (fact_9fdb227ae99d_7044 a b) ∨ (fact_9fdb227ae99d_6598 a b) ∨ (fact_9fdb227ae99d_6211 a b) ∨ (fact_9fdb227ae99d_6276 a b) ∨ (fact_9fdb227ae99d_6290 a b) ∨ (fact_9fdb227ae99d_6094 a b) ∨ (fact_9fdb227ae99d_6646 a b) ∨ (fact_9fdb227ae99d_7098 a b) ∨ (fact_9fdb227ae99d_6886 a b) ∨ (fact_9fdb227ae99d_6866 a b) ∨ (fact_9fdb227ae99d_6737 a b)) ∨ ((fact_9fdb227ae99d_6619 a b) ∨ (fact_9fdb227ae99d_6623 a b) ∨ (fact_9fdb227ae99d_6991 a b) ∨ (fact_9fdb227ae99d_7152 a b) ∨ (fact_9fdb227ae99d_6911 a b) ∨ (fact_9fdb227ae99d_6684 a b) ∨ (fact_9fdb227ae99d_6704 a b) ∨ (fact_9fdb227ae99d_6716 a b) ∨ (fact_9fdb227ae99d_6627 a b) ∨ (fact_9fdb227ae99d_6915 a b) ∨ (fact_9fdb227ae99d_7163 a b) ∨ (fact_9fdb227ae99d_7003 a b) ∨ (fact_9fdb227ae99d_6994 a b) ∨ (fact_9fdb227ae99d_6933 a b)))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((3 : Int) + b)) ∧ ((fact_9fdb227ae99d_6032 a b) ∨ (fact_9fdb227ae99d_6070 a b) ∨ (fact_9fdb227ae99d_6832 a b) ∨ (fact_9fdb227ae99d_7044 a b) ∨ (fact_9fdb227ae99d_6598 a b) ∨ (fact_9fdb227ae99d_6211 a b) ∨ (fact_9fdb227ae99d_6276 a b) ∨ (fact_9fdb227ae99d_6290 a b) ∨ (fact_9fdb227ae99d_6094 a b) ∨ (fact_9fdb227ae99d_6646 a b) ∨ (fact_9fdb227ae99d_7098 a b) ∨ (fact_9fdb227ae99d_6886 a b) ∨ (fact_9fdb227ae99d_6866 a b) ∨ (fact_9fdb227ae99d_6737 a b)) ∧ ((fact_9fdb227ae99d_6619 a b) ∨ (fact_9fdb227ae99d_6623 a b) ∨ (fact_9fdb227ae99d_6991 a b) ∨ (fact_9fdb227ae99d_7152 a b) ∨ (fact_9fdb227ae99d_6911 a b) ∨ (fact_9fdb227ae99d_6684 a b) ∨ (fact_9fdb227ae99d_6704 a b) ∨ (fact_9fdb227ae99d_6716 a b) ∨ (fact_9fdb227ae99d_6627 a b) ∨ (fact_9fdb227ae99d_6915 a b) ∨ (fact_9fdb227ae99d_7163 a b) ∨ (fact_9fdb227ae99d_7003 a b) ∨ (fact_9fdb227ae99d_6994 a b) ∨ (fact_9fdb227ae99d_6933 a b))) ∨ (((4 : Int) + (4 : Int)) ≤ ((3 : Int) + b)) ∨ ((((3 : Int) + b) = ((4 : Int) + (1 : Int))) ∧ ((fact_9fdb227ae99d_6032 a b) ∨ (fact_9fdb227ae99d_6070 a b) ∨ (fact_9fdb227ae99d_6832 a b) ∨ (fact_9fdb227ae99d_7044 a b) ∨ (fact_9fdb227ae99d_6598 a b) ∨ (fact_9fdb227ae99d_6211 a b) ∨ (fact_9fdb227ae99d_6276 a b) ∨ (fact_9fdb227ae99d_6290 a b) ∨ (fact_9fdb227ae99d_6094 a b) ∨ (fact_9fdb227ae99d_6646 a b) ∨ (fact_9fdb227ae99d_7098 a b) ∨ (fact_9fdb227ae99d_6886 a b) ∨ (fact_9fdb227ae99d_6866 a b) ∨ (fact_9fdb227ae99d_6737 a b)) ∧ ((fact_9fdb227ae99d_6619 a b) ∨ (fact_9fdb227ae99d_6623 a b) ∨ (fact_9fdb227ae99d_6991 a b) ∨ (fact_9fdb227ae99d_7152 a b) ∨ (fact_9fdb227ae99d_6911 a b) ∨ (fact_9fdb227ae99d_6684 a b) ∨ (fact_9fdb227ae99d_6704 a b) ∨ (fact_9fdb227ae99d_6716 a b) ∨ (fact_9fdb227ae99d_6627 a b) ∨ (fact_9fdb227ae99d_6915 a b) ∨ (fact_9fdb227ae99d_7163 a b) ∨ (fact_9fdb227ae99d_7003 a b) ∨ (fact_9fdb227ae99d_6994 a b) ∨ (fact_9fdb227ae99d_6933 a b)) ∧ (((fact_9fdb227ae99d_6030 a b) ∨ (fact_9fdb227ae99d_6068 a b) ∨ (fact_9fdb227ae99d_6830 a b) ∨ (fact_9fdb227ae99d_7042 a b) ∨ (fact_9fdb227ae99d_6596 a b) ∨ (fact_9fdb227ae99d_6209 a b) ∨ (fact_9fdb227ae99d_6274 a b) ∨ (fact_9fdb227ae99d_6289 a b) ∨ (fact_9fdb227ae99d_6092 a b) ∨ (fact_9fdb227ae99d_6645 a b) ∨ (fact_9fdb227ae99d_7096 a b) ∨ (fact_9fdb227ae99d_6885 a b) ∨ (fact_9fdb227ae99d_6865 a b) ∨ (fact_9fdb227ae99d_6735 a b)) ∨ ((fact_9fdb227ae99d_6617 a b) ∨ (fact_9fdb227ae99d_6621 a b) ∨ (fact_9fdb227ae99d_6989 a b) ∨ (fact_9fdb227ae99d_7150 a b) ∨ (fact_9fdb227ae99d_6909 a b) ∨ (fact_9fdb227ae99d_6682 a b) ∨ (fact_9fdb227ae99d_6702 a b) ∨ (fact_9fdb227ae99d_6715 a b) ∨ (fact_9fdb227ae99d_6625 a b) ∨ (fact_9fdb227ae99d_6913 a b) ∨ (fact_9fdb227ae99d_7161 a b) ∨ (fact_9fdb227ae99d_7001 a b) ∨ (fact_9fdb227ae99d_6992 a b) ∨ (fact_9fdb227ae99d_6931 a b)))) ∨ (((fact_9fdb227ae99d_6032 a b) ∨ (fact_9fdb227ae99d_6070 a b) ∨ (fact_9fdb227ae99d_6832 a b) ∨ (fact_9fdb227ae99d_7044 a b) ∨ (fact_9fdb227ae99d_6598 a b) ∨ (fact_9fdb227ae99d_6211 a b) ∨ (fact_9fdb227ae99d_6276 a b) ∨ (fact_9fdb227ae99d_6290 a b) ∨ (fact_9fdb227ae99d_6094 a b) ∨ (fact_9fdb227ae99d_6646 a b) ∨ (fact_9fdb227ae99d_7098 a b) ∨ (fact_9fdb227ae99d_6886 a b) ∨ (fact_9fdb227ae99d_6866 a b) ∨ (fact_9fdb227ae99d_6737 a b)) ∧ ((fact_9fdb227ae99d_6619 a b) ∨ (fact_9fdb227ae99d_6623 a b) ∨ (fact_9fdb227ae99d_6991 a b) ∨ (fact_9fdb227ae99d_7152 a b) ∨ (fact_9fdb227ae99d_6911 a b) ∨ (fact_9fdb227ae99d_6684 a b) ∨ (fact_9fdb227ae99d_6704 a b) ∨ (fact_9fdb227ae99d_6716 a b) ∨ (fact_9fdb227ae99d_6627 a b) ∨ (fact_9fdb227ae99d_6915 a b) ∨ (fact_9fdb227ae99d_7163 a b) ∨ (fact_9fdb227ae99d_7003 a b) ∨ (fact_9fdb227ae99d_6994 a b) ∨ (fact_9fdb227ae99d_6933 a b)) ∧ ((fact_9fdb227ae99d_6030 a b) ∨ (fact_9fdb227ae99d_6068 a b) ∨ (fact_9fdb227ae99d_6830 a b) ∨ (fact_9fdb227ae99d_7042 a b) ∨ (fact_9fdb227ae99d_6596 a b) ∨ (fact_9fdb227ae99d_6209 a b) ∨ (fact_9fdb227ae99d_6274 a b) ∨ (fact_9fdb227ae99d_6289 a b) ∨ (fact_9fdb227ae99d_6092 a b) ∨ (fact_9fdb227ae99d_6645 a b) ∨ (fact_9fdb227ae99d_7096 a b) ∨ (fact_9fdb227ae99d_6885 a b) ∨ (fact_9fdb227ae99d_6865 a b) ∨ (fact_9fdb227ae99d_6735 a b)) ∧ ((fact_9fdb227ae99d_6617 a b) ∨ (fact_9fdb227ae99d_6621 a b) ∨ (fact_9fdb227ae99d_6989 a b) ∨ (fact_9fdb227ae99d_7150 a b) ∨ (fact_9fdb227ae99d_6909 a b) ∨ (fact_9fdb227ae99d_6682 a b) ∨ (fact_9fdb227ae99d_6702 a b) ∨ (fact_9fdb227ae99d_6715 a b) ∨ (fact_9fdb227ae99d_6625 a b) ∨ (fact_9fdb227ae99d_6913 a b) ∨ (fact_9fdb227ae99d_7161 a b) ∨ (fact_9fdb227ae99d_7001 a b) ∨ (fact_9fdb227ae99d_6992 a b) ∨ (fact_9fdb227ae99d_6931 a b))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n502_run_empty (a b run_x : Int)
    (h0 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_3206 a b))
    (h3 : (a ≥ b))
    (h4 : ((((2 : Int) + a) < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < ((2 : Int) + a)) ∨ ((3 : Int) > ((2 : Int) + b)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : ((fact_9fdb227ae99d_3629 a b run_x) ∨ (fact_9fdb227ae99d_3638 a b run_x) ∨ (fact_9fdb227ae99d_5037 a b run_x) ∨ (fact_9fdb227ae99d_5790 a b run_x) ∨ (fact_9fdb227ae99d_4412 a b run_x) ∨ (fact_9fdb227ae99d_3681 a b run_x) ∨ (fact_9fdb227ae99d_3691 a b run_x) ∨ (fact_9fdb227ae99d_3697 a b run_x) ∨ (fact_9fdb227ae99d_3645 a b run_x) ∨ (fact_9fdb227ae99d_4492 a b run_x) ∨ (fact_9fdb227ae99d_5824 a b run_x) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((-3 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + b + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_5101 a b run_x) ∨ (fact_9fdb227ae99d_4526 a b run_x)))
    (h6 : (run_x ≤ ((3 : Int) + b)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ (5 : Int)))
    (h10 : ((((2 : Int) + a) < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < ((2 : Int) + a)) ∨ ((2 : Int) > ((2 : Int) + b)) ∨ ((2 : Int) < ((2 : Int) - (0 : Int)))))
    (h11 : ((4 : Int) ≤ run_x))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n502_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((3 : Int) + b)))
    (h1 : ((4 : Int) ≤ run_x))
    (h2 : (¬ ((fact_9fdb227ae99d_5412 a b run_x) ∨ (fact_9fdb227ae99d_5415 a b run_x) ∨ (fact_9fdb227ae99d_5990 a b run_x) ∨ (fact_9fdb227ae99d_6843 a b run_x) ∨ (fact_9fdb227ae99d_5796 a b run_x) ∨ (fact_9fdb227ae99d_5483 a b run_x) ∨ (fact_9fdb227ae99d_5485 a b run_x) ∨ (fact_9fdb227ae99d_5492 a b run_x) ∨ (fact_9fdb227ae99d_5416 a b run_x) ∨ (fact_9fdb227ae99d_5806 a b run_x) ∨ (fact_9fdb227ae99d_6898 a b run_x) ∨ (((((-1 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((1 : Int) + b + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6041 a b run_x) ∨ (fact_9fdb227ae99d_5813 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n503_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (fact_9fdb227ae99d_31 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : ((((3 : Int) + b + a) - a) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n503_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_3093 a b) ∨ (fact_9fdb227ae99d_3095 a b) ∨ (fact_9fdb227ae99d_3596 a b) ∨ (fact_9fdb227ae99d_5032 a b) ∨ (fact_9fdb227ae99d_3335 a b) ∨ (fact_9fdb227ae99d_3134 a b) ∨ (fact_9fdb227ae99d_3137 a b) ∨ ((((-2 : Int) ≥ ((-3 : Int) - a)) ∧ ((-2 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≥ ((4 : Int) + b))) ∨ (((-3 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3097 a b) ∨ (fact_9fdb227ae99d_3337 a b) ∨ ((((-2 : Int) ≥ (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((-2 : Int) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + b))) ∨ (((-2 : Int) ≥ ((-4 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + b)))) ∨ ((((-2 : Int) ≥ ((-1 : Int) - b)) ∧ ((-2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + b + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((1 : Int) + b + a))) ∨ (((-1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-1 : Int)) ∧ ((((1 : Int) + b + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((1 : Int) + b + a) + (0 : Int))))) ∨ ((((-2 : Int) ≥ ((0 : Int) - b)) ∧ ((-2 : Int) ≤ ((0 : Int) + (0 : Int))) ∧ (((3 : Int) + b + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + b + a))) ∨ (((0 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (0 : Int)) ∧ ((((3 : Int) + b + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + b + a) + (0 : Int))))) ∨ ((((-2 : Int) ≥ ((-4 : Int) - b)) ∧ ((-2 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((4 : Int) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≥ ((4 : Int) + b))) ∨ (((-4 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-4 : Int)) ∧ (((4 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) + a))))))
    (h1 : (((((2 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((((3 : Int) + b + a) - a) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_9fdb227ae99d_3208 a b))
    (h5 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

end LRegionArithmetic

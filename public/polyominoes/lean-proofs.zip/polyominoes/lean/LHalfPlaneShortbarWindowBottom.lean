import LHalfPlaneBoundaryPairPruning
import TPlaneGeometry

namespace PolyominoFormal.LRegion
open CrossUnits
set_option maxHeartbeats 10000000
set_option linter.unusedVariables false

/-- A tile seen between two complete short floor bars and their side walls
cannot cross their floor unless it is one of those bars. -/
theorem short_window_bottom (a b x y : Int) (t : Cross)
    (hb : 0≤b) (ha : 0≤a) (nn : TPlane.Nonnegative t)
    (window : 0≤x ∧ 0≤y ∧ x≤2*b+1 ∧ y≤a)
    (hit : Contains t x y)
    (left : Apart t ⟨0,0,b,a,0,0⟩)
    (right : Apart t ⟨2*b+1,0,0,a,b,0⟩) : 1≤t.y-t.south := by
  unfold TPlane.Nonnegative at nn
  unfold Contains at hit
  unfold Apart at left right
  dsimp only at left right
  omega

end PolyominoFormal.LRegion

import LQuadrantHpAlternatingUnequalBarLongFixed53PrunedArithmeticDefs
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace LRegionArithmetic

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n075_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((15 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((15 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n075_empty (a b : Int)
    (h0 : (((((15 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((15 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (13 : Int)) ∧ ((2 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((17 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((17 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (8 : Int))) ∨ (((17 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (17 : Int)) ∧ ((2 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((8 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((14 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((14 : Int) + (5 : Int))) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int))) ∨ (((14 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (14 : Int)) ∧ ((2 : Int) ≥ ((4 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((20 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((20 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((20 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (20 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n075_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((14 : Int) > (jx + a)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jy)))
    (h2 : ((jx < ((20 : Int) - (5 : Int))) ∨ (((20 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n075_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h2 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n075_o2 (a b jx jy : Int)
    (h0 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < ((20 : Int) - (5 : Int))) ∨ (((20 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h2 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n075_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h3 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h4 : (((20 : Int) > (jx + (0 : Int))) ∨ ((20 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n075_o4 (a b jx jy : Int)
    (h0 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n075_o5 (a b jx jy : Int)
    (h0 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((14 : Int) > (jx + (0 : Int))) ∨ ((14 : Int) < (jx - a)) ∨ (jy < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jy)))
    (h5 : (((20 : Int) > (jx + (0 : Int))) ∨ ((20 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h6 : ((jx < ((20 : Int) - (5 : Int))) ∨ (((20 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n075_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((14 : Int) > (jx + b)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jy)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h4 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n075_o7 (a b jx jy : Int)
    (h0 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < ((20 : Int) - (5 : Int))) ∨ (((20 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h2 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n076_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((9 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((9 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n076_empty (a b : Int)
    (h0 : (((((9 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((9 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((9 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (13 : Int)) ∧ ((2 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((11 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n076_o0 (a b jx jy : Int)
    (h0 : (((10 : Int) > (jx + a)) ∨ ((10 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h1 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (¬ ((((4 : Int) = jx) ∧ ((2 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (b = (3 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a = (5 : Int)))
    (h8 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n076_o1 (a b jx jy : Int)
    (h0 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h4 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n076_o2 (a b jx jy : Int)
    (h0 : (b = (3 : Int)))
    (h1 : (a = (5 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((9 : Int) ≥ (jx - a)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (¬ ((((9 : Int) = jx) ∧ ((5 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n076_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((9 : Int) ≥ (jx - b)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h2 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : (((10 : Int) > (jx + (0 : Int))) ∨ ((10 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n076_o4 (a b jx jy : Int)
    (h0 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((9 : Int) ≥ (jx - b)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n076_o5 (a b jx jy : Int)
    (h0 : (((10 : Int) > (jx + (0 : Int))) ∨ ((10 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a = (5 : Int)))
    (h5 : ((((9 : Int) ≥ (jx - a)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (¬ ((((9 : Int) = jx) ∧ ((2 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int))))))
    (h8 : (b = (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n076_o6 (a b jx jy : Int)
    (h0 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h1 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b = (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n076_o7 (a b jx jy : Int)
    (h0 : (((10 : Int) > (jx + a)) ∨ ((10 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h5 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n077_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((9 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((9 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n077_empty (a b : Int)
    (h0 : (((((9 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-13 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (23 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (24 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((9 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (10 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((9 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (13 : Int)) ∧ ((3 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int))) ∨ (((11 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((4 : Int) + (5 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (4 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n077_o0 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h1 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((10 : Int) > (jx + a)) ∨ ((10 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n077_o1 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h3 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n077_o2 (a b jx jy : Int)
    (h0 : ((((9 : Int) ≥ (jx - a)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h2 : (a = (5 : Int)))
    (h3 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h4 : (¬ ((((9 : Int) = jx) ∧ ((6 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b)))))
    (h5 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jy - b) ≥ (0 : Int)))
    (h8 : (b = (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n077_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((10 : Int) > (jx + (0 : Int))) ∨ ((10 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((9 : Int) ≥ (jx - b)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h4 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n077_o4 (a b jx jy : Int)
    (h0 : ((((9 : Int) ≥ (jx - b)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h3 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n077_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((10 : Int) > (jx + (0 : Int))) ∨ ((10 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h3 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((9 : Int) ≥ (jx - a)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h6 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n077_o6 (a b jx jy : Int)
    (h0 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h1 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : (b = (3 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n077_o7 (a b jx jy : Int)
    (h0 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (((10 : Int) > (jx + a)) ∨ ((10 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n078_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((5 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((5 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n078_empty (a b : Int)
    (h0 : (((((5 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-13 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (23 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (24 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((5 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (10 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((5 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (13 : Int)) ∧ ((3 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int))) ∨ (((11 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + (5 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((9 : Int) + (0 : Int))) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (6 : Int))) ∨ (((9 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (9 : Int)) ∧ ((3 : Int) ≥ ((6 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n078_o0 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h4 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + b)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n078_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h2 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n078_o2 (a b jx jy : Int)
    (h0 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h4 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h5 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n078_o3 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h2 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - b)) ∨ (jy < ((6 : Int) - (3 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n078_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h3 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n078_o5 (a b jx jy : Int)
    (h0 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (3 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h1 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h6 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n078_o6 (a b jx jy : Int)
    (h0 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h1 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((4 : Int) > (jx + b)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h4 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n078_o7 (a b jx jy : Int)
    (h0 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h5 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n079_point (a b : Int)
    (h0 : (¬ (((8 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((8 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n079_empty (a b : Int)
    (h0 : (((((8 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((8 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((8 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (13 : Int)) ∧ ((2 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((11 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((9 : Int) + (0 : Int))) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (5 : Int))) ∨ (((9 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (9 : Int)) ∧ ((2 : Int) ≥ ((5 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n079_o0 (a b jx jy : Int)
    (h0 : (a = (5 : Int)))
    (h1 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h2 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h3 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (b = (3 : Int)))
    (h7 : (¬ ((((3 : Int) = jx) ∧ ((2 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n079_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n079_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((((8 : Int) ≥ (jx - a)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n079_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h2 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - b)) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((8 : Int) ≥ (jx - b)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n079_o4 (a b jx jy : Int)
    (h0 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((8 : Int) ≥ (jx - b)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n079_o5 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((8 : Int) ≥ (jx - a)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h2 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - a)) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n079_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h2 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n079_o7 (a b jx jy : Int)
    (h0 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < ((10 : Int) - (3 : Int))) ∨ (((10 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n080_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((4 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((4 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n080_empty (a b : Int)
    (h0 : (((((4 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-13 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (23 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (24 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((4 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((4 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (10 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((4 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (13 : Int)) ∧ ((3 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((4 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int))) ∨ (((11 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((4 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((9 : Int) + (0 : Int))) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ (((9 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (9 : Int)) ∧ ((3 : Int) ≥ ((5 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + (0 : Int))))) ∨ ((((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + (5 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n080_o0 (a b jx jy : Int)
    (h0 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n080_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n080_o2 (a b jx jy : Int)
    (h0 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n080_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h2 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - b)) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n080_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n080_o5 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h2 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - a)) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h3 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n080_o6 (a b jx jy : Int)
    (h0 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h4 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n080_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h3 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h4 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n081_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((9 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((6 : Int) ≥ (0 : Int)) ∧ ((9 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((6 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n081_empty (a b : Int)
    (h0 : (((((9 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-13 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-12 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (-1 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (0 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (11 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (12 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (23 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (24 : Int)) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (1 : Int)) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((9 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((9 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (10 : Int)) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((9 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((9 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (13 : Int)) ∧ ((6 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((6 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (7 : Int))) ∨ (((11 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (11 : Int)) ∧ ((6 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((6 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((9 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((9 : Int) ≤ ((9 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ (((9 : Int) ≤ (9 : Int)) ∧ ((9 : Int) ≤ (9 : Int)) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n081_o0 (a b jx jy : Int)
    (h0 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + a)) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - (0 : Int))) ∧ ((6 : Int) ≤ (jy + b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((10 : Int) > (jx + a)) ∨ ((10 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h4 : (a = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((9 : Int) > jx) ∨ ((9 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h7 : (¬ ((((4 : Int) = jx) ∧ ((6 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h8 : (b = (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n081_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + b)) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - a)) ∧ ((6 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h3 : (b = (3 : Int)))
    (h4 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h7 : (((9 : Int) > jx) ∨ ((9 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n081_o2 (a b jx jy : Int)
    (h0 : (((9 : Int) > jx) ∨ ((9 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (((10 : Int) > (jx + (0 : Int))) ∨ ((10 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h4 : ((((9 : Int) ≥ (jx - a)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - b)) ∧ ((6 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n081_o3 (a b jx jy : Int)
    (h0 : (((9 : Int) > jx) ∨ ((9 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h1 : (((10 : Int) > (jx + (0 : Int))) ∨ ((10 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h2 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((((9 : Int) ≥ (jx - b)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - (0 : Int))) ∧ ((6 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n081_o4 (a b jx jy : Int)
    (h0 : (((10 : Int) > (jx + (0 : Int))) ∨ ((10 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((9 : Int) ≥ (jx - b)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - a)) ∧ ((6 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (((9 : Int) > jx) ∨ ((9 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n081_o5 (a b jx jy : Int)
    (h0 : ((((9 : Int) ≥ (jx - a)) ∧ ((9 : Int) ≤ (jx + (0 : Int))) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - (0 : Int))) ∧ ((6 : Int) ≤ (jy + b)))))
    (h1 : (((9 : Int) > jx) ∨ ((9 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((10 : Int) > (jx + (0 : Int))) ∨ ((10 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h5 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + b)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n081_o6 (a b jx jy : Int)
    (h0 : (((9 : Int) > jx) ∨ ((9 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + b)) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - (0 : Int))) ∧ ((6 : Int) ≤ (jy + a)))))
    (h3 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : (b = (3 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((10 : Int) > (jx + b)) ∨ ((10 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h8 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n081_o7 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b = (3 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((10 : Int) > (jx + a)) ∨ ((10 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h4 : ((jx < ((11 : Int) - (5 : Int))) ∨ (((11 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (a = (5 : Int)))
    (h7 : (¬ ((((4 : Int) = jx) ∧ ((6 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b)))))
    (h8 : ((((9 : Int) ≥ (jx - (0 : Int))) ∧ ((9 : Int) ≤ (jx + a)) ∧ ((6 : Int) ≥ jy) ∧ ((6 : Int) ≤ jy)) ∨ (((9 : Int) ≥ jx) ∧ ((9 : Int) ≤ jx) ∧ ((6 : Int) ≥ (jy - b)) ∧ ((6 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n082_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((8 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((8 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n082_empty (a b : Int)
    (h0 : (((((8 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-13 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (23 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (24 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((8 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (10 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((8 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (13 : Int)) ∧ ((3 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int))) ∨ (((11 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((9 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((9 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (9 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (3 : Int))))) ∨ ((((8 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((4 : Int) + (5 : Int))) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (6 : Int))) ∨ (((4 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (4 : Int)) ∧ ((3 : Int) ≥ ((6 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n082_o0 (a b jx jy : Int)
    (h0 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h4 : (a = (5 : Int)))
    (h5 : (b = (3 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + b)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h8 : (((9 : Int) > (jx + a)) ∨ ((9 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h9 : (¬ ((((3 : Int) = jx) ∧ ((3 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n082_o1 (a b jx jy : Int)
    (h0 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n082_o2 (a b jx jy : Int)
    (h0 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h4 : ((((8 : Int) ≥ (jx - a)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n082_o3 (a b jx jy : Int)
    (h0 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h3 : ((((8 : Int) ≥ (jx - b)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h4 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n082_o4 (a b jx jy : Int)
    (h0 : ((((8 : Int) ≥ (jx - b)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n082_o5 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + b)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h1 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h2 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((8 : Int) ≥ (jx - a)) ∧ ((8 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n082_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (b = (3 : Int)))
    (h5 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h6 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n082_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h2 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h3 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((8 : Int) ≥ (jx - (0 : Int))) ∧ ((8 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((8 : Int) ≥ jx) ∧ ((8 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n083_point (a b : Int)
    (h0 : (¬ (((3 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n083_empty (a b : Int)
    (h0 : (((((3 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((3 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (13 : Int)) ∧ ((2 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((3 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((11 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ (((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + (5 : Int))) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int))) ∨ (((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((2 : Int) ≥ ((6 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + (3 : Int))))) ∨ ((((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + (5 : Int))) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ (((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int)) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n083_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h2 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h3 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h4 : (((jx + a) < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n083_o1 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (3 : Int)) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n083_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (3 : Int)) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n083_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h2 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h5 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n083_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n083_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((jx + (0 : Int)) < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < (jx - a)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h4 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n083_o6 (a b jx jy : Int)
    (h0 : (((jx + b) < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h1 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h2 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n083_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + (5 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h3 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n084_point (a b : Int)
    (h0 : (¬ (((5 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((5 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n084_empty (a b : Int)
    (h0 : (((((5 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-13 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (23 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (24 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((5 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (10 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((5 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (13 : Int)) ∧ ((3 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int))) ∨ (((11 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((9 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((9 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (9 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (3 : Int))))) ∨ ((((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + (5 : Int))) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (6 : Int))) ∨ (((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((3 : Int) ≥ ((6 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n084_o0 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + b)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h1 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h2 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (3 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n084_o1 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h1 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n084_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h4 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n084_o3 (a b jx jy : Int)
    (h0 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h1 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n084_o4 (a b jx jy : Int)
    (h0 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h3 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n084_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : (((9 : Int) > (jx + (0 : Int))) ∨ ((9 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h3 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + b)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h4 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n084_o6 (a b jx jy : Int)
    (h0 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((4 : Int) > (jx + b)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (3 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n084_o7 (a b jx jy : Int)
    (h0 : ((jx < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h1 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + (5 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h2 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n085_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((12 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((12 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n085_empty (a b : Int)
    (h0 : (((((12 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((12 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (-13 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (-12 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((12 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (-1 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (0 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((12 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (11 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (12 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((12 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (23 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (24 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (1 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((12 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (10 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((12 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (13 : Int)) ∧ ((4 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((12 : Int) ≥ ((11 : Int) - (3 : Int))) ∧ ((12 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (11 : Int)) ∧ ((4 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((9 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n085_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((12 : Int) ≥ (jx - (0 : Int))) ∧ ((12 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h2 : (((13 : Int) > (jx + a)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h3 : (((11 : Int) > (jx + a)) ∨ ((11 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h6 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n085_o1 (a b jx jy : Int)
    (h0 : (¬ ((((12 : Int) = jx) ∧ ((9 : Int) = jy) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a)))))
    (h1 : (a = (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((12 : Int) ≥ (jx - (0 : Int))) ∧ ((12 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - a))))
    (h5 : (b = (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n085_o2 (a b jx jy : Int)
    (h0 : (b = (3 : Int)))
    (h1 : (((11 : Int) > (jx + (0 : Int))) ∨ ((11 : Int) < (jx - a)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h5 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((((12 : Int) ≥ (jx - a)) ∧ ((12 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n085_o3 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h2 : ((((12 : Int) ≥ (jx - b)) ∧ ((12 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((11 : Int) > (jx + (0 : Int))) ∨ ((11 : Int) < (jx - b)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h6 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - b)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n085_o4 (a b jx jy : Int)
    (h0 : ((((12 : Int) ≥ (jx - b)) ∧ ((12 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a = (5 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((jx + (0 : Int)) < ((11 : Int) - (3 : Int))) ∨ (((11 : Int) + (0 : Int)) < (jx - b)) ∨ ((9 : Int) > jy) ∨ ((9 : Int) < jy)))
    (h6 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n085_o5 (a b jx jy : Int)
    (h0 : ((((12 : Int) ≥ (jx - a)) ∧ ((12 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h1 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h2 : (((11 : Int) > (jx + (0 : Int))) ∨ ((11 : Int) < (jx - a)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n085_o6 (a b jx jy : Int)
    (h0 : ((((12 : Int) ≥ (jx - (0 : Int))) ∧ ((12 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((13 : Int) > (jx + b)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h3 : (((11 : Int) > (jx + b)) ∨ ((11 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n085_o7 (a b jx jy : Int)
    (h0 : (b = (3 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ ((((12 : Int) = jx) ∧ ((7 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b)))))
    (h3 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - b))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (a = (5 : Int)))
    (h6 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h7 : (((11 : Int) > (jx + a)) ∨ ((11 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h8 : ((((12 : Int) ≥ (jx - (0 : Int))) ∧ ((12 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n086_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((13 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((7 : Int) ≥ (0 : Int)) ∧ ((13 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((7 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n086_empty (a b : Int)
    (h0 : (((((13 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((13 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (-13 : Int)) ∧ ((7 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((13 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((13 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (-12 : Int)) ∧ ((7 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((13 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((13 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (-1 : Int)) ∧ ((7 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((13 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((13 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (0 : Int)) ∧ ((7 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((13 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((13 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (11 : Int)) ∧ ((7 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((13 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((13 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (12 : Int)) ∧ ((7 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((13 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((13 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (23 : Int)) ∧ ((7 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((13 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((13 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (24 : Int)) ∧ ((7 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((13 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((13 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (1 : Int)) ∧ ((7 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((13 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((13 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (10 : Int)) ∧ ((7 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((13 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((13 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (13 : Int)) ∧ ((7 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((7 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((13 : Int) ≥ ((11 : Int) - (3 : Int))) ∧ ((13 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (11 : Int)) ∧ ((7 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((7 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((13 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((13 : Int) ≤ ((12 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (12 : Int)) ∧ ((7 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((7 : Int) ≤ ((9 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n086_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((13 : Int) ≥ (jx - (0 : Int))) ∧ ((13 : Int) ≤ (jx + a)) ∧ ((7 : Int) ≥ jy) ∧ ((7 : Int) ≤ jy)) ∨ (((13 : Int) ≥ jx) ∧ ((13 : Int) ≤ jx) ∧ ((7 : Int) ≥ (jy - (0 : Int))) ∧ ((7 : Int) ≤ (jy + b)))))
    (h2 : (((13 : Int) > jx) ∨ ((13 : Int) < jx) ∨ ((jy + b) < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + b)) ∨ ((9 : Int) < (jy - (0 : Int)))))
    (h5 : (((12 : Int) > (jx + a)) ∨ ((12 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h6 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n086_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((13 : Int) ≥ (jx - (0 : Int))) ∧ ((13 : Int) ≤ (jx + b)) ∧ ((7 : Int) ≥ jy) ∧ ((7 : Int) ≤ jy)) ∨ (((13 : Int) ≥ jx) ∧ ((13 : Int) ≤ jx) ∧ ((7 : Int) ≥ (jy - a)) ∧ ((7 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (((12 : Int) > (jx + b)) ∨ ((12 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h3 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - a))))
    (h4 : (((13 : Int) > jx) ∨ ((13 : Int) < jx) ∨ ((jy + (0 : Int)) < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < (jy - a))))
    (h5 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n086_o2 (a b jx jy : Int)
    (h0 : ((((13 : Int) ≥ (jx - a)) ∧ ((13 : Int) ≤ (jx + (0 : Int))) ∧ ((7 : Int) ≥ jy) ∧ ((7 : Int) ≤ jy)) ∨ (((13 : Int) ≥ jx) ∧ ((13 : Int) ≤ jx) ∧ ((7 : Int) ≥ (jy - b)) ∧ ((7 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (((12 : Int) > (jx + (0 : Int))) ∨ ((12 : Int) < (jx - a)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h3 : (a = (5 : Int)))
    (h4 : (¬ ((((18 : Int) = jx) ∧ ((7 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b)))))
    (h5 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - b))))
    (h6 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (3 : Int)))
    (h9 : (((13 : Int) > jx) ∨ ((13 : Int) < jx) ∨ ((jy + (0 : Int)) < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < (jy - b))))
    (h10 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n086_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (3 : Int)))
    (h3 : (((12 : Int) > (jx + (0 : Int))) ∨ ((12 : Int) < (jx - b)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h4 : (a = (5 : Int)))
    (h5 : (¬ ((((16 : Int) = jx) ∧ ((7 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : (((13 : Int) > jx) ∨ ((13 : Int) < jx) ∨ ((jy + a) < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < (jy - (0 : Int)))))
    (h7 : ((((13 : Int) ≥ (jx - b)) ∧ ((13 : Int) ≤ (jx + (0 : Int))) ∧ ((7 : Int) ≥ jy) ∧ ((7 : Int) ≤ jy)) ∨ (((13 : Int) ≥ jx) ∧ ((13 : Int) ≤ jx) ∧ ((7 : Int) ≥ (jy - (0 : Int))) ∧ ((7 : Int) ≤ (jy + a)))))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + a)) ∨ ((9 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n086_o4 (a b jx jy : Int)
    (h0 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ ((((0 : Int) = a) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ ((((0 : Int) = b) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = b)))))))
    (h1 : (b = (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - a))))
    (h4 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : ((((13 : Int) ≥ (jx - b)) ∧ ((13 : Int) ≤ (jx + (0 : Int))) ∧ ((7 : Int) ≥ jy) ∧ ((7 : Int) ≤ jy)) ∨ (((13 : Int) ≥ jx) ∧ ((13 : Int) ≤ jx) ∧ ((7 : Int) ≥ (jy - a)) ∧ ((7 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n086_o5 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (b = (3 : Int)))
    (h2 : (a = (5 : Int)))
    (h3 : (((12 : Int) > (jx + (0 : Int))) ∨ ((12 : Int) < (jx - a)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((13 : Int) ≥ (jx - a)) ∧ ((13 : Int) ≤ (jx + (0 : Int))) ∧ ((7 : Int) ≥ jy) ∧ ((7 : Int) ≤ jy)) ∨ (((13 : Int) ≥ jx) ∧ ((13 : Int) ≤ jx) ∧ ((7 : Int) ≥ (jy - (0 : Int))) ∧ ((7 : Int) ≤ (jy + b)))))
    (h6 : (¬ ((((18 : Int) = jx) ∧ ((7 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int))))))
    (h7 : (((13 : Int) > jx) ∨ ((13 : Int) < jx) ∨ ((jy + b) < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < (jy - (0 : Int)))))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n086_o6 (a b jx jy : Int)
    (h0 : ((((13 : Int) ≥ (jx - (0 : Int))) ∧ ((13 : Int) ≤ (jx + b)) ∧ ((7 : Int) ≥ jy) ∧ ((7 : Int) ≤ jy)) ∨ (((13 : Int) ≥ jx) ∧ ((13 : Int) ≤ jx) ∧ ((7 : Int) ≥ (jy - (0 : Int))) ∧ ((7 : Int) ≤ (jy + a)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((12 : Int) > (jx + b)) ∨ ((12 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h4 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + a)) ∨ ((9 : Int) < (jy - (0 : Int)))))
    (h5 : (((13 : Int) > jx) ∨ ((13 : Int) < jx) ∨ ((jy + a) < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n086_o7 (a b jx jy : Int)
    (h0 : ((((13 : Int) ≥ (jx - (0 : Int))) ∧ ((13 : Int) ≤ (jx + a)) ∧ ((7 : Int) ≥ jy) ∧ ((7 : Int) ≤ jy)) ∨ (((13 : Int) ≥ jx) ∧ ((13 : Int) ≤ jx) ∧ ((7 : Int) ≥ (jy - b)) ∧ ((7 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (((12 : Int) > (jx + a)) ∨ ((12 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h2 : (((13 : Int) > jx) ∨ ((13 : Int) < jx) ∨ ((jy + (0 : Int)) < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < (jy - b))))
    (h3 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - b))))
    (h4 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n087_point (a b : Int)
    (h0 : (¬ (((14 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((5 : Int) ≥ (0 : Int)) ∧ ((14 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((5 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n087_empty (a b : Int)
    (h0 : (((((14 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-13 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-12 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-1 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (0 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (23 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (24 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (1 : Int)) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (10 : Int)) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((14 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (13 : Int)) ∧ ((5 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((5 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((5 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (7 : Int))) ∨ (((18 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (18 : Int)) ∧ ((5 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((5 : Int) ≤ ((7 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n087_o0 (a b jx jy : Int)
    (h0 : (a = (5 : Int)))
    (h1 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + b)))))
    (h2 : (¬ ((((14 : Int) = jx) ∧ ((2 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : (b = (3 : Int)))
    (h4 : (((13 : Int) > (jx + a)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + b)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n087_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h4 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - a)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n087_o2 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (((18 : Int) > (jx + (0 : Int))) ∨ ((18 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (3 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h4 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h5 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - b)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h6 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h7 : (a = (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n087_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + a)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h4 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (5 : Int)) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h5 : (((18 : Int) > (jx + (0 : Int))) ∨ ((18 : Int) < (jx - b)) ∨ (jy < ((7 : Int) - (3 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h6 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n087_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ ((((0 : Int) = a) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ ((((0 : Int) = b) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = b)))))))
    (h3 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h4 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - a)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n087_o5 (a b jx jy : Int)
    (h0 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (5 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((18 : Int) > (jx + (0 : Int))) ∨ ((18 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (3 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h4 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + b)))))
    (h5 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + b)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n087_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (5 : Int)) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h3 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + a)))))
    (h4 : (((13 : Int) > (jx + b)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h5 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n087_o7 (a b jx jy : Int)
    (h0 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - b)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (((18 : Int) > (jx + a)) ∨ ((18 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (3 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (((13 : Int) > (jx + a)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h6 : (a = (5 : Int)))
    (h7 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h8 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n088_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((14 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((14 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n088_empty (a b : Int)
    (h0 : (((((14 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-13 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-1 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (0 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (23 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (24 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (10 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((14 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (13 : Int)) ∧ ((1 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((1 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((1 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (7 : Int))) ∨ (((18 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (18 : Int)) ∧ ((1 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((1 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((14 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((14 : Int) + (5 : Int))) ∧ ((2 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (2 : Int))) ∨ (((14 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (14 : Int)) ∧ ((1 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n088_o0 (a b jx jy : Int)
    (h0 : (((13 : Int) > (jx + a)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((14 : Int) > jx) ∨ ((14 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n088_o1 (a b jx jy : Int)
    (h0 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n088_o2 (a b jx jy : Int)
    (h0 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n088_o3 (a b jx jy : Int)
    (h0 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((14 : Int) > jx) ∨ ((14 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h5 : (b = (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n088_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n088_o5 (a b jx jy : Int)
    (h0 : (((14 : Int) > jx) ∨ ((14 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a = (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n088_o6 (a b jx jy : Int)
    (h0 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((14 : Int) > jx) ∨ ((14 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h4 : (((13 : Int) > (jx + b)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n088_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n089_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((13 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((8 : Int) ≥ (0 : Int)) ∧ ((13 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((8 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n089_empty (a b : Int)
    (h0 : (((((13 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((13 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (-13 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((13 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((13 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (-12 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((13 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((13 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (-1 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((13 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((13 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (0 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((13 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((13 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (11 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((13 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((13 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (12 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((13 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((13 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (23 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((13 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((13 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (24 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((13 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((13 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (1 : Int)) ∧ ((8 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((13 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((13 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (10 : Int)) ∧ ((8 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((13 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((13 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (13 : Int)) ∧ ((8 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((13 : Int) ≥ ((11 : Int) - (3 : Int))) ∧ ((13 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (11 : Int)) ∧ ((8 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((13 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((13 : Int) ≤ ((12 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (12 : Int)) ∧ ((8 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((13 : Int) ≥ ((16 : Int) - (3 : Int))) ∧ ((13 : Int) ≤ ((16 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (7 : Int))) ∨ (((16 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (16 : Int)) ∧ ((8 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((7 : Int) + (5 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n089_o0 (a b jx jy : Int)
    (h0 : (((12 : Int) > (jx + a)) ∨ ((12 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((13 : Int) ≥ (jx - (0 : Int))) ∧ ((13 : Int) ≤ (jx + a)) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((13 : Int) ≥ jx) ∧ ((13 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - (0 : Int))) ∧ ((8 : Int) ≤ (jy + b)))))
    (h3 : (((16 : Int) > (jx + a)) ∨ ((16 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (5 : Int)) < jy)))
    (h4 : (((13 : Int) > jx) ∨ ((13 : Int) < jx) ∨ ((jy + b) < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < (jy - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n089_o1 (a b jx jy : Int)
    (h0 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - a))))
    (h1 : ((((13 : Int) ≥ (jx - (0 : Int))) ∧ ((13 : Int) ≤ (jx + b)) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((13 : Int) ≥ jx) ∧ ((13 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - a)) ∧ ((8 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (((12 : Int) > (jx + b)) ∨ ((12 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jx < ((16 : Int) - (3 : Int))) ∨ (((16 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n089_o2 (a b jx jy : Int)
    (h0 : ((((13 : Int) ≥ (jx - a)) ∧ ((13 : Int) ≤ (jx + (0 : Int))) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((13 : Int) ≥ jx) ∧ ((13 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - b)) ∧ ((8 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - b))))
    (h2 : (((16 : Int) > (jx + (0 : Int))) ∨ ((16 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (5 : Int)) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((16 : Int) - (3 : Int))) ∨ (((16 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n089_o3 (a b jx jy : Int)
    (h0 : ((jx < ((16 : Int) - (3 : Int))) ∨ (((16 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h1 : (((12 : Int) > (jx + (0 : Int))) ∨ ((12 : Int) < (jx - b)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h2 : ((((13 : Int) ≥ (jx - b)) ∧ ((13 : Int) ≤ (jx + (0 : Int))) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((13 : Int) ≥ jx) ∧ ((13 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - (0 : Int))) ∧ ((8 : Int) ≤ (jy + a)))))
    (h3 : (((16 : Int) > (jx + (0 : Int))) ∨ ((16 : Int) < (jx - b)) ∨ (jy < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (5 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n089_o4 (a b jx jy : Int)
    (h0 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ ((((0 : Int) = a) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ ((((0 : Int) = b) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = b)))))))
    (h1 : ((((13 : Int) ≥ (jx - b)) ∧ ((13 : Int) ≤ (jx + (0 : Int))) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((13 : Int) ≥ jx) ∧ ((13 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - a)) ∧ ((8 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h3 : (((13 : Int) > jx) ∨ ((13 : Int) < jx) ∨ ((jy + (0 : Int)) < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < (jy - a))))
    (h4 : (((16 : Int) > (jx + (0 : Int))) ∨ ((16 : Int) < (jx - b)) ∨ (jy < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (5 : Int)) < jy)))
    (h5 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - a))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n089_o5 (a b jx jy : Int)
    (h0 : ((jx < ((16 : Int) - (3 : Int))) ∨ (((16 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + b)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h1 : ((((13 : Int) ≥ (jx - a)) ∧ ((13 : Int) ≤ (jx + (0 : Int))) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((13 : Int) ≥ jx) ∧ ((13 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - (0 : Int))) ∧ ((8 : Int) ≤ (jy + b)))))
    (h2 : (((16 : Int) > (jx + (0 : Int))) ∨ ((16 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (5 : Int)) < jy)))
    (h3 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + b)) ∨ ((9 : Int) < (jy - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n089_o6 (a b jx jy : Int)
    (h0 : (((12 : Int) > (jx + b)) ∨ ((12 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h1 : (((13 : Int) > jx) ∨ ((13 : Int) < jx) ∨ ((jy + a) < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < (jy - (0 : Int)))))
    (h2 : ((((13 : Int) ≥ (jx - (0 : Int))) ∧ ((13 : Int) ≤ (jx + b)) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((13 : Int) ≥ jx) ∧ ((13 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - (0 : Int))) ∧ ((8 : Int) ≤ (jy + a)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((16 : Int) > (jx + b)) ∨ ((16 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (5 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n089_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((13 : Int) ≥ (jx - (0 : Int))) ∧ ((13 : Int) ≤ (jx + a)) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((13 : Int) ≥ jx) ∧ ((13 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - b)) ∧ ((8 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (((12 : Int) > (jx + a)) ∨ ((12 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h5 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - b))))
    (h6 : (((13 : Int) > jx) ∨ ((13 : Int) < jx) ∨ ((jy + (0 : Int)) < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n090_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((13 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((8 : Int) ≥ (0 : Int)) ∧ ((13 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((8 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n090_empty (a b : Int)
    (h0 : (((((13 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((13 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (-13 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((13 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((13 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (-12 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((13 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((13 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (-1 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((13 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((13 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (0 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((13 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((13 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (11 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((13 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((13 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (12 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((13 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((13 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (23 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((13 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((13 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (24 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((13 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((13 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (1 : Int)) ∧ ((8 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((13 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((13 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (10 : Int)) ∧ ((8 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((13 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((13 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (13 : Int)) ∧ ((8 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((13 : Int) ≥ ((11 : Int) - (3 : Int))) ∧ ((13 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (11 : Int)) ∧ ((8 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((13 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((13 : Int) ≤ ((12 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (12 : Int)) ∧ ((8 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((13 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((13 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (7 : Int))) ∨ (((18 : Int) ≤ (13 : Int)) ∧ ((13 : Int) ≤ (18 : Int)) ∧ ((8 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((7 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n090_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + b)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h2 : (((12 : Int) > (jx + a)) ∨ ((12 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h3 : ((((13 : Int) ≥ (jx - (0 : Int))) ∧ ((13 : Int) ≤ (jx + a)) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((13 : Int) ≥ jx) ∧ ((13 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - (0 : Int))) ∧ ((8 : Int) ≤ (jy + b)))))
    (h4 : (((18 : Int) > (jx + a)) ∨ ((18 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n090_o1 (a b jx jy : Int)
    (h0 : (((13 : Int) > jx) ∨ ((13 : Int) < jx) ∨ ((jy + (0 : Int)) < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < (jy - a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((13 : Int) ≥ (jx - (0 : Int))) ∧ ((13 : Int) ≤ (jx + b)) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((13 : Int) ≥ jx) ∧ ((13 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - a)) ∧ ((8 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - a))))
    (h4 : (((12 : Int) > (jx + b)) ∨ ((12 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h5 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n090_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h2 : ((((13 : Int) ≥ (jx - a)) ∧ ((13 : Int) ≤ (jx + (0 : Int))) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((13 : Int) ≥ jx) ∧ ((13 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - b)) ∧ ((8 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - b))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (((13 : Int) > jx) ∨ ((13 : Int) < jx) ∨ ((jy + (0 : Int)) < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < (jy - b))))
    (h6 : (((18 : Int) > (jx + (0 : Int))) ∨ ((18 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n090_o3 (a b jx jy : Int)
    (h0 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h1 : (¬ ((((16 : Int) = jx) ∧ ((8 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : (a = (5 : Int)))
    (h3 : (((12 : Int) > (jx + (0 : Int))) ∨ ((12 : Int) < (jx - b)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h4 : (b = (3 : Int)))
    (h5 : ((((13 : Int) ≥ (jx - b)) ∧ ((13 : Int) ≤ (jx + (0 : Int))) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((13 : Int) ≥ jx) ∧ ((13 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - (0 : Int))) ∧ ((8 : Int) ≤ (jy + a)))))
    (h6 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n090_o4 (a b jx jy : Int)
    (h0 : (((18 : Int) > (jx + (0 : Int))) ∨ ((18 : Int) < (jx - b)) ∨ (jy < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (3 : Int)) < jy)))
    (h1 : (((13 : Int) > jx) ∨ ((13 : Int) < jx) ∨ ((jy + (0 : Int)) < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < (jy - a))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((13 : Int) ≥ (jx - b)) ∧ ((13 : Int) ≤ (jx + (0 : Int))) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((13 : Int) ≥ jx) ∧ ((13 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - a)) ∧ ((8 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n090_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((18 : Int) > (jx + (0 : Int))) ∨ ((18 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (3 : Int)) < jy)))
    (h2 : ((((13 : Int) ≥ (jx - a)) ∧ ((13 : Int) ≤ (jx + (0 : Int))) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((13 : Int) ≥ jx) ∧ ((13 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - (0 : Int))) ∧ ((8 : Int) ≤ (jy + b)))))
    (h3 : (((12 : Int) > (jx + (0 : Int))) ∨ ((12 : Int) < (jx - a)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h4 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + b)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n090_o6 (a b jx jy : Int)
    (h0 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + a)) ∨ ((9 : Int) < (jy - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h3 : ((((13 : Int) ≥ (jx - (0 : Int))) ∧ ((13 : Int) ≤ (jx + b)) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((13 : Int) ≥ jx) ∧ ((13 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - (0 : Int))) ∧ ((8 : Int) ≤ (jy + a)))))
    (h4 : (((12 : Int) > (jx + b)) ∨ ((12 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n090_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((13 : Int) > jx) ∨ ((13 : Int) < jx) ∨ ((jy + (0 : Int)) < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < (jy - b))))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h3 : ((((13 : Int) ≥ (jx - (0 : Int))) ∧ ((13 : Int) ≤ (jx + a)) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((13 : Int) ≥ jx) ∧ ((13 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - b)) ∧ ((8 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (((12 : Int) > (jx + a)) ∨ ((12 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h6 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n091_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((17 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((8 : Int) ≥ (0 : Int)) ∧ ((17 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((8 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n091_empty (a b : Int)
    (h0 : (((((17 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((17 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (17 : Int)) ∧ ((17 : Int) ≤ (-13 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((17 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((17 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (17 : Int)) ∧ ((17 : Int) ≤ (-12 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((17 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((17 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (17 : Int)) ∧ ((17 : Int) ≤ (-1 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((17 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((17 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (17 : Int)) ∧ ((17 : Int) ≤ (0 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((17 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((17 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (17 : Int)) ∧ ((17 : Int) ≤ (11 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((17 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((17 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (17 : Int)) ∧ ((17 : Int) ≤ (12 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((17 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((17 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (17 : Int)) ∧ ((17 : Int) ≤ (23 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((17 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((17 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (17 : Int)) ∧ ((17 : Int) ≤ (24 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((17 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((17 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (17 : Int)) ∧ ((17 : Int) ≤ (1 : Int)) ∧ ((8 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((17 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((17 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (17 : Int)) ∧ ((17 : Int) ≤ (10 : Int)) ∧ ((8 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((17 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((17 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (17 : Int)) ∧ ((17 : Int) ≤ (13 : Int)) ∧ ((8 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((17 : Int) ≥ ((11 : Int) - (3 : Int))) ∧ ((17 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (17 : Int)) ∧ ((17 : Int) ≤ (11 : Int)) ∧ ((8 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((17 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((17 : Int) ≤ ((12 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (17 : Int)) ∧ ((17 : Int) ≤ (12 : Int)) ∧ ((8 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((17 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((17 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (7 : Int))) ∨ (((18 : Int) ≤ (17 : Int)) ∧ ((17 : Int) ≤ (18 : Int)) ∧ ((8 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((7 : Int) + (3 : Int))))) ∨ ((((17 : Int) ≥ ((16 : Int) - (3 : Int))) ∧ ((17 : Int) ≤ ((16 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (8 : Int))) ∨ (((16 : Int) ≤ (17 : Int)) ∧ ((17 : Int) ≤ (16 : Int)) ∧ ((8 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((8 : Int) + (5 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n091_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((17 : Int) ≥ (jx - (0 : Int))) ∧ ((17 : Int) ≤ (jx + a)) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((17 : Int) ≥ jx) ∧ ((17 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - (0 : Int))) ∧ ((8 : Int) ≤ (jy + b)))))
    (h2 : (((18 : Int) > (jx + a)) ∨ ((18 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (3 : Int)) < jy)))
    (h3 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + b)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h4 : (((jx + a) < ((16 : Int) - (3 : Int))) ∨ (((16 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ ((8 : Int) > jy) ∨ ((8 : Int) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n091_o1 (a b jx jy : Int)
    (h0 : (b = (3 : Int)))
    (h1 : ((((17 : Int) ≥ (jx - (0 : Int))) ∧ ((17 : Int) ≤ (jx + b)) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((17 : Int) ≥ jx) ∧ ((17 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - a)) ∧ ((8 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h4 : (a = (5 : Int)))
    (h5 : (((jx + b) < ((16 : Int) - (3 : Int))) ∨ (((16 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ ((8 : Int) > jy) ∨ ((8 : Int) < jy)))
    (h6 : (¬ ((((17 : Int) = jx) ∧ ((13 : Int) = jy) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n091_o2 (a b jx jy : Int)
    (h0 : (b = (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((17 : Int) ≥ (jx - a)) ∧ ((17 : Int) ≤ (jx + (0 : Int))) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((17 : Int) ≥ jx) ∧ ((17 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - b)) ∧ ((8 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (((18 : Int) > (jx + (0 : Int))) ∨ ((18 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (3 : Int)) < jy)))
    (h4 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((16 : Int) > (jx + (0 : Int))) ∨ ((16 : Int) < (jx - a)) ∨ (jy < ((8 : Int) - (0 : Int))) ∨ (((8 : Int) + (5 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n091_o3 (a b jx jy : Int)
    (h0 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((jx + (0 : Int)) < ((16 : Int) - (3 : Int))) ∨ (((16 : Int) + (0 : Int)) < (jx - b)) ∨ ((8 : Int) > jy) ∨ ((8 : Int) < jy)))
    (h3 : (((18 : Int) > (jx + (0 : Int))) ∨ ((18 : Int) < (jx - b)) ∨ (jy < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (3 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((17 : Int) ≥ (jx - b)) ∧ ((17 : Int) ≤ (jx + (0 : Int))) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((17 : Int) ≥ jx) ∧ ((17 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - (0 : Int))) ∧ ((8 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n091_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h2 : ((((17 : Int) ≥ (jx - b)) ∧ ((17 : Int) ≤ (jx + (0 : Int))) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((17 : Int) ≥ jx) ∧ ((17 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - a)) ∧ ((8 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (((18 : Int) > (jx + (0 : Int))) ∨ ((18 : Int) < (jx - b)) ∨ (jy < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (3 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((16 : Int) > (jx + (0 : Int))) ∨ ((16 : Int) < (jx - b)) ∨ (jy < ((8 : Int) - (0 : Int))) ∨ (((8 : Int) + (5 : Int)) < jy)))
    (h6 : (a = (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n091_o5 (a b jx jy : Int)
    (h0 : ((((17 : Int) ≥ (jx - a)) ∧ ((17 : Int) ≤ (jx + (0 : Int))) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((17 : Int) ≥ jx) ∧ ((17 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - (0 : Int))) ∧ ((8 : Int) ≤ (jy + b)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + b)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h3 : (((16 : Int) > (jx + (0 : Int))) ∨ ((16 : Int) < (jx - a)) ∨ (jy < ((8 : Int) - (0 : Int))) ∨ (((8 : Int) + (5 : Int)) < jy)))
    (h4 : (((18 : Int) > (jx + (0 : Int))) ∨ ((18 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n091_o6 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h2 : ((((17 : Int) ≥ (jx - (0 : Int))) ∧ ((17 : Int) ≤ (jx + b)) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((17 : Int) ≥ jx) ∧ ((17 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - (0 : Int))) ∧ ((8 : Int) ≤ (jy + a)))))
    (h3 : (((jx + b) < ((16 : Int) - (3 : Int))) ∨ (((16 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ ((8 : Int) > jy) ∨ ((8 : Int) < jy)))
    (h4 : (((18 : Int) > (jx + b)) ∨ ((18 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n091_o7 (a b jx jy : Int)
    (h0 : (b = (3 : Int)))
    (h1 : (¬ ((((17 : Int) = jx) ∧ ((11 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b)))))
    (h2 : ((((17 : Int) ≥ (jx - (0 : Int))) ∧ ((17 : Int) ≤ (jx + a)) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((17 : Int) ≥ jx) ∧ ((17 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - b)) ∧ ((8 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h4 : (a = (5 : Int)))
    (h5 : (((jx + a) < ((16 : Int) - (3 : Int))) ∨ (((16 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ ((8 : Int) > jy) ∨ ((8 : Int) < jy)))
    (h6 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n092_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((14 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((14 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n092_empty (a b : Int)
    (h0 : (((((14 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-13 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-1 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (0 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (23 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (24 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (10 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((14 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (13 : Int)) ∧ ((1 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((1 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((1 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (7 : Int))) ∨ (((18 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (18 : Int)) ∧ ((1 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((7 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((16 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((16 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (8 : Int))) ∨ (((16 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (16 : Int)) ∧ ((1 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((8 : Int) + (5 : Int))))) ∨ ((((14 : Int) ≥ ((17 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((17 : Int) + (3 : Int))) ∧ ((13 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (13 : Int))) ∨ (((17 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (17 : Int)) ∧ ((1 : Int) ≥ ((13 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((13 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n092_o0 (a b jx jy : Int)
    (h0 : (b = (3 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h6 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (5 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h7 : (((13 : Int) > (jx + a)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h8 : (¬ ((((14 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n092_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h4 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n092_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h5 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n092_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (¬ ((((17 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a = (5 : Int)))
    (h4 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (5 : Int)) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (b = (3 : Int)))
    (h7 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h8 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - b)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n092_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ ((((0 : Int) = a) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ ((((0 : Int) = b) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = b)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n092_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h3 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h4 : (¬ ((((19 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : (a = (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (b = (3 : Int)))
    (h8 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (5 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n092_o6 (a b jx jy : Int)
    (h0 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (5 : Int)) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h1 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((13 : Int) > (jx + b)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h6 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n092_o7 (a b jx jy : Int)
    (h0 : (b = (3 : Int)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h3 : (¬ ((((14 : Int) = jx) ∧ ((4 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b)))))
    (h4 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a = (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n093_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((14 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((5 : Int) ≥ (0 : Int)) ∧ ((14 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((5 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n093_empty (a b : Int)
    (h0 : (((((14 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-13 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-12 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-1 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (0 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (23 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (24 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (1 : Int)) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (10 : Int)) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((14 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (13 : Int)) ∧ ((5 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((5 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((5 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (7 : Int))) ∨ (((18 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (18 : Int)) ∧ ((5 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((7 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((16 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((16 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (8 : Int))) ∨ (((16 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (16 : Int)) ∧ ((5 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((8 : Int) + (5 : Int))))) ∨ ((((14 : Int) ≥ ((17 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((17 : Int) + (3 : Int))) ∧ ((13 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (13 : Int))) ∨ (((17 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (17 : Int)) ∧ ((5 : Int) ≥ ((13 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((13 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((14 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((14 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ (((14 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (14 : Int)) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n093_o0 (a b jx jy : Int)
    (h0 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((13 : Int) > (jx + a)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h4 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + b)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h5 : (((14 : Int) > jx) ∨ ((14 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n093_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h3 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - a)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n093_o2 (a b jx jy : Int)
    (h0 : (¬ ((((19 : Int) = jx) ∧ ((5 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (3 : Int)))
    (h3 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - b)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (5 : Int)))
    (h7 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h8 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n093_o3 (a b jx jy : Int)
    (h0 : (b = (3 : Int)))
    (h1 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + a)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((14 : Int) > jx) ∨ ((14 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h6 : (((17 : Int) > jx) ∨ ((17 : Int) < jx) ∨ ((jy + a) < ((13 : Int) - (5 : Int))) ∨ (((13 : Int) + (0 : Int)) < (jy - (0 : Int)))))
    (h7 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - b)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n093_o4 (a b jx jy : Int)
    (h0 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - a)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ ((((0 : Int) = a) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ ((((0 : Int) = b) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = b)))))))
    (h4 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n093_o5 (a b jx jy : Int)
    (h0 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + b)))))
    (h1 : (((14 : Int) > jx) ∨ ((14 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h2 : (b = (3 : Int)))
    (h3 : (a = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (¬ ((((19 : Int) = jx) ∧ ((5 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n093_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h2 : (((14 : Int) > jx) ∨ ((14 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + a)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((13 : Int) > (jx + b)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n093_o7 (a b jx jy : Int)
    (h0 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h1 : (a = (5 : Int)))
    (h2 : (((14 : Int) > jx) ∨ ((14 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < (jy - b))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - b)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (((13 : Int) > (jx + a)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n094_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((15 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((15 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n094_empty (a b : Int)
    (h0 : (((((15 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((15 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (13 : Int)) ∧ ((2 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((18 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (18 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((16 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((16 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (8 : Int))) ∨ (((16 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (16 : Int)) ∧ ((2 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((8 : Int) + (5 : Int))))) ∨ ((((15 : Int) ≥ ((17 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((17 : Int) + (3 : Int))) ∧ ((13 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (13 : Int))) ∨ (((17 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (17 : Int)) ∧ ((2 : Int) ≥ ((13 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((13 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((14 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((14 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((14 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (14 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((19 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((19 : Int) + (0 : Int))) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (5 : Int))) ∨ (((19 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (19 : Int)) ∧ ((2 : Int) ≥ ((5 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n094_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h4 : (((14 : Int) > (jx + a)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h5 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h6 : (((19 : Int) > (jx + a)) ∨ ((19 : Int) < (jx - (0 : Int))) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n094_o1 (a b jx jy : Int)
    (h0 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n094_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h4 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n094_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h2 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h3 : (((19 : Int) > (jx + (0 : Int))) ∨ ((19 : Int) < (jx - b)) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n094_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n094_o5 (a b jx jy : Int)
    (h0 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h4 : (((14 : Int) > (jx + (0 : Int))) ∨ ((14 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h5 : (((19 : Int) > (jx + (0 : Int))) ∨ ((19 : Int) < (jx - a)) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n094_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h2 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((14 : Int) > (jx + b)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n094_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h3 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h4 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n095_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((15 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((15 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n095_empty (a b : Int)
    (h0 : (((((15 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((15 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (13 : Int)) ∧ ((2 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((18 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (18 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((16 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((16 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (8 : Int))) ∨ (((16 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (16 : Int)) ∧ ((2 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((8 : Int) + (5 : Int))))) ∨ ((((15 : Int) ≥ ((17 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((17 : Int) + (3 : Int))) ∧ ((13 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (13 : Int))) ∨ (((17 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (17 : Int)) ∧ ((2 : Int) ≥ ((13 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((13 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((14 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((14 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((14 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (14 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((19 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((19 : Int) + (0 : Int))) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (5 : Int))) ∨ (((19 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (19 : Int)) ∧ ((2 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n095_o0 (a b jx jy : Int)
    (h0 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((14 : Int) > (jx + a)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h5 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n095_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n095_o2 (a b jx jy : Int)
    (h0 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h1 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n095_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h2 : (b = (3 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n095_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n095_o5 (a b jx jy : Int)
    (h0 : (((14 : Int) > (jx + (0 : Int))) ∨ ((14 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h1 : (a = (5 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (¬ ((((20 : Int) = jx) ∧ ((2 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : (b = (3 : Int)))
    (h6 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h7 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n095_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h2 : (((14 : Int) > (jx + b)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n095_o7 (a b jx jy : Int)
    (h0 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n096_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((15 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((15 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n096_empty (a b : Int)
    (h0 : (((((15 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-13 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (23 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (24 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (10 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((15 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (13 : Int)) ∧ ((3 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int))) ∨ (((18 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (18 : Int)) ∧ ((3 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((16 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((16 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (8 : Int))) ∨ (((16 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (16 : Int)) ∧ ((3 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((8 : Int) + (5 : Int))))) ∨ ((((15 : Int) ≥ ((17 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((17 : Int) + (3 : Int))) ∧ ((13 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (13 : Int))) ∨ (((17 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (17 : Int)) ∧ ((3 : Int) ≥ ((13 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((13 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((14 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((14 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((14 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (14 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((19 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((19 : Int) + (0 : Int))) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ (((19 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (19 : Int)) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((20 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((20 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((20 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (20 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n096_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((14 : Int) > (jx + a)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h4 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h5 : ((jx < ((20 : Int) - (5 : Int))) ∨ (((20 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n096_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n096_o2 (a b jx jy : Int)
    (h0 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h3 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((20 : Int) - (5 : Int))) ∨ (((20 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n096_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h4 : (((20 : Int) > (jx + (0 : Int))) ∨ ((20 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n096_o4 (a b jx jy : Int)
    (h0 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n096_o5 (a b jx jy : Int)
    (h0 : (((20 : Int) > (jx + (0 : Int))) ∨ ((20 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h3 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h4 : ((jx < ((20 : Int) - (5 : Int))) ∨ (((20 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n096_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h2 : (((14 : Int) > (jx + b)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h3 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n096_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h3 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h4 : ((jx < ((20 : Int) - (5 : Int))) ∨ (((20 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n097_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((14 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((14 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n097_empty (a b : Int)
    (h0 : (((((14 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((14 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (13 : Int)) ∧ ((2 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((18 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (18 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((16 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((16 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (8 : Int))) ∨ (((16 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (16 : Int)) ∧ ((2 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((8 : Int) + (5 : Int))))) ∨ ((((14 : Int) ≥ ((17 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((17 : Int) + (3 : Int))) ∧ ((13 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (13 : Int))) ∨ (((17 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (17 : Int)) ∧ ((2 : Int) ≥ ((13 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((13 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((17 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((17 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((17 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (17 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n097_o0 (a b jx jy : Int)
    (h0 : ((jx < ((17 : Int) - (3 : Int))) ∨ (((17 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h1 : (((13 : Int) > (jx + a)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h2 : (((17 : Int) > (jx + a)) ∨ ((17 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h6 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n097_o1 (a b jx jy : Int)
    (h0 : ((jx < ((17 : Int) - (3 : Int))) ∨ (((17 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h1 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n097_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h2 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n097_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - b)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((17 : Int) > (jx + (0 : Int))) ∨ ((17 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h5 : ((jx < ((17 : Int) - (3 : Int))) ∨ (((17 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h6 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n097_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((jx < ((17 : Int) - (3 : Int))) ∨ (((17 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h2 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n097_o5 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((17 : Int) > (jx + (0 : Int))) ∨ ((17 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h3 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h4 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h5 : ((jx < ((17 : Int) - (3 : Int))) ∨ (((17 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n097_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((17 : Int) > (jx + b)) ∨ ((17 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((13 : Int) > (jx + b)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h5 : ((jx < ((17 : Int) - (3 : Int))) ∨ (((17 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h6 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n097_o7 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((17 : Int) > (jx + a)) ∨ ((17 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n098_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((14 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((14 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n098_empty (a b : Int)
    (h0 : (((((14 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((14 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (13 : Int)) ∧ ((2 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((18 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (18 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((16 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((16 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (8 : Int))) ∨ (((16 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (16 : Int)) ∧ ((2 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((8 : Int) + (5 : Int))))) ∨ ((((14 : Int) ≥ ((17 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((17 : Int) + (3 : Int))) ∧ ((13 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (13 : Int))) ∨ (((17 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (17 : Int)) ∧ ((2 : Int) ≥ ((13 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((13 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((19 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((19 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((19 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (19 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n098_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((13 : Int) > (jx + a)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h2 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h3 : (((19 : Int) > (jx + a)) ∨ ((19 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n098_o1 (a b jx jy : Int)
    (h0 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h2 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n098_o2 (a b jx jy : Int)
    (h0 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n098_o3 (a b jx jy : Int)
    (h0 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h1 : (((19 : Int) > (jx + (0 : Int))) ∨ ((19 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h2 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n098_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h3 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h4 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n098_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h4 : (((19 : Int) > (jx + (0 : Int))) ∨ ((19 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h5 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h6 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n098_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h4 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h5 : (((13 : Int) > (jx + b)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n098_o7 (a b jx jy : Int)
    (h0 : (¬ ((((14 : Int) = jx) ∧ ((5 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (b = (3 : Int)))
    (h4 : (a = (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h7 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n099_point (a b : Int)
    (h0 : (¬ (((15 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((15 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n099_empty (a b : Int)
    (h0 : (((((15 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((15 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (13 : Int)) ∧ ((2 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((18 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (18 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((16 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((16 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (8 : Int))) ∨ (((16 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (16 : Int)) ∧ ((2 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((8 : Int) + (5 : Int))))) ∨ ((((15 : Int) ≥ ((17 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((17 : Int) + (3 : Int))) ∧ ((13 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (13 : Int))) ∨ (((17 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (17 : Int)) ∧ ((2 : Int) ≥ ((13 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((13 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((19 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((19 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((19 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (19 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((14 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((14 : Int) + (5 : Int))) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (5 : Int))) ∨ (((14 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (14 : Int)) ∧ ((2 : Int) ≥ ((5 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n099_o0 (a b jx jy : Int)
    (h0 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h1 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((19 : Int) > (jx + a)) ∨ ((19 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((14 : Int) > (jx + a)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n099_o1 (a b jx jy : Int)
    (h0 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n099_o2 (a b jx jy : Int)
    (h0 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h3 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n099_o3 (a b jx jy : Int)
    (h0 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((19 : Int) > (jx + (0 : Int))) ∨ ((19 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h3 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n099_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n099_o5 (a b jx jy : Int)
    (h0 : (((19 : Int) > (jx + (0 : Int))) ∨ ((19 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h1 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h2 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h3 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n099_o6 (a b jx jy : Int)
    (h0 : (((14 : Int) > (jx + b)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h3 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n099_o7 (a b jx jy : Int)
    (h0 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

end LRegionArithmetic

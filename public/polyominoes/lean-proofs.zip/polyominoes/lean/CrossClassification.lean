import PlaneObstructions
import LongCrossObstruction
import CoreBoundaryObstructions

namespace PolyominoFormal
namespace CrossClassification

theorem adjacent_no_plane (c d : Int) (hc : 2≤c) (hd : 2≤d) :
    ¬Tiles 1 1 c d Plane := by
  rintro ⟨T⟩
  by_cases order : c≤d
  · exact adjacent_units_no_plane c d hc order ⟨T⟩
  · exact adjacent_units_no_plane d c hd (by omega)
      ⟨T.reflectParameters.rotateParameters.rotateParameters.rotateParameters⟩

theorem one_no_plane (a c d : Int) (ha : 2≤a) (hc : 2≤c) (hd : 2≤d) :
    ¬Tiles a 1 c d Plane := by
  rintro ⟨T⟩
  by_cases order : a≤c
  · exact one_unit_no_plane a c d ha order hd ⟨T⟩
  · exact one_unit_no_plane c a d hc (by omega) hd
      ⟨T.rotateParameters.rotateParameters.reflectParameters⟩

theorem unit_north_no_plane (a c d : Int) (ha : 1≤a) (hc : 1≤c)
    (hd : 2≤d) (notOpposite : ¬(a=1 ∧ c=1)) : ¬Tiles a 1 c d Plane := by
  rintro ⟨T⟩
  by_cases aOne : a=1
  · subst a
    exact adjacent_no_plane c d (by omega) hd ⟨T⟩
  by_cases cOne : c=1
  · subst c
    exact adjacent_no_plane d a hd (by omega) ⟨T.rotateParameters⟩
  · exact one_no_plane a c d (by omega) (by omega) hd ⟨T⟩

/-- The complete necessary plane criterion for four positive arms. -/
theorem plane_requires_opposite_units {a b c d : Int}
    (ha : 1≤a) (hb : 1≤b) (hc : 1≤c) (hd : 1≤d)
    (tiled : Tiles a b c d Plane) : (a=1 ∧ c=1) ∨ (b=1 ∧ d=1) := by
  apply Classical.byContradiction
  intro absent
  obtain ⟨T⟩ := tiled
  by_cases aOne : a=1
  · subst a
    exact unit_north_no_plane d b c hd hb (by omega) (by omega)
      ⟨T.rotateParameters.rotateParameters.rotateParameters⟩
  by_cases bOne : b=1
  · subst b
    exact unit_north_no_plane a c d ha hc (by omega) (by omega) ⟨T⟩
  by_cases cOne : c=1
  · subst c
    exact unit_north_no_plane b d a hb hd (by omega) (by omega) ⟨T.rotateParameters⟩
  by_cases dOne : d=1
  · subst d
    exact unit_north_no_plane c a b hc ha (by omega) (by omega)
      ⟨T.rotateParameters.rotateParameters⟩
  · exact LongCrossObstruction.all_long_no_plane (by omega) (by omega) (by omega) (by omega) ⟨T⟩

#print axioms plane_requires_opposite_units
end CrossClassification
end PolyominoFormal

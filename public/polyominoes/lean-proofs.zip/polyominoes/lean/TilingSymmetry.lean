import TilingCore

namespace PolyominoFormal
open CrossUnits

/-- Transport a tiling through an exact congruence of cells and placed tiles. -/
def Tiling.map {a b c d : Int} {R : Region} (T : Tiling a b c d R)
    (f : Cross → Cross) (gx gy : Int → Int → Int)
    (hit : ∀ t x y, Contains (f t) x y ↔ Contains t (gx x y) (gy x y))
    (copy : ∀ t, Copy a b c d t → Copy a b c d (f t)) :
    Tiling a b c d (fun x y => R (gx x y) (gy x y)) where
  world t := ∃ u, T.world u ∧ f u=t
  copies := by rintro t ⟨u,hu,rfl⟩; exact copy u (T.copies u hu)
  inside := by
    rintro t ⟨u,hu,rfl⟩ x y hc
    exact T.inside u hu _ _ ((hit u x y).1 hc)
  cover := by
    intro x y hc
    obtain ⟨t,ht,hh⟩ := T.cover _ _ hc
    exact ⟨f t,⟨t,ht,rfl⟩,(hit t x y).2 hh⟩
  disjoint := by
    rintro t u x y ⟨t',ht',rfl⟩ ⟨u',hu',rfl⟩ hc hd
    exact congrArg f (T.disjoint t' u' _ _ ht' hu'
      ((hit t' x y).1 hc) ((hit u' x y).1 hd))

def mirrorX (t : Cross) : Cross := ⟨-t.x,t.y,t.west,t.north,t.east,t.south⟩
def mirrorY (t : Cross) : Cross := ⟨t.x,-t.y,t.east,t.south,t.west,t.north⟩
def transpose (t : Cross) : Cross := ⟨t.y,t.x,t.north,t.east,t.south,t.west⟩

theorem mirrorX_hit (t : Cross) (x y : Int) :
    Contains (mirrorX t) x y ↔ Contains t (-x) y := by
  unfold Contains mirrorX; dsimp; omega
theorem mirrorY_hit (t : Cross) (x y : Int) :
    Contains (mirrorY t) x y ↔ Contains t x (-y) := by
  unfold Contains mirrorY; dsimp; omega
theorem transpose_hit (t : Cross) (x y : Int) :
    Contains (transpose t) x y ↔ Contains t y x := by
  unfold Contains transpose; dsimp; omega

theorem mirrorX_copy (a b c d : Int) (t : Cross) (h : Copy a b c d t) :
    Copy a b c d (mirrorX t) := by
  rcases h with h | h | h | h | h | h | h | h
  all_goals rcases h with ⟨he,hn,hw,hs⟩
  all_goals simp [Copy, Arms, mirrorX, he, hn, hw, hs]
theorem mirrorY_copy (a b c d : Int) (t : Cross) (h : Copy a b c d t) :
    Copy a b c d (mirrorY t) := by
  rcases h with h | h | h | h | h | h | h | h
  all_goals rcases h with ⟨he,hn,hw,hs⟩
  all_goals simp [Copy, Arms, mirrorY, he, hn, hw, hs]
theorem transpose_copy (a b c d : Int) (t : Cross) (h : Copy a b c d t) :
    Copy a b c d (transpose t) := by
  rcases h with h | h | h | h | h | h | h | h
  all_goals rcases h with ⟨he,hn,hw,hs⟩
  all_goals simp [Copy, Arms, transpose, he, hn, hw, hs]

def Tiling.mirrorX {a b c d : Int} {R : Region} (T : Tiling a b c d R) :
    Tiling a b c d (fun x y => R (-x) y) :=
  T.map PolyominoFormal.mirrorX (fun x _ => -x) (fun _ y => y)
    mirrorX_hit (mirrorX_copy a b c d)
def Tiling.mirrorY {a b c d : Int} {R : Region} (T : Tiling a b c d R) :
    Tiling a b c d (fun x y => R x (-y)) :=
  T.map PolyominoFormal.mirrorY (fun x _ => x) (fun _ y => -y)
    mirrorY_hit (mirrorY_copy a b c d)
def Tiling.transpose {a b c d : Int} {R : Region} (T : Tiling a b c d R) :
    Tiling a b c d (fun x y => R y x) :=
  T.map PolyominoFormal.transpose (fun _ y => y) (fun x _ => x)
    transpose_hit (transpose_copy a b c d)

theorem normalize_plane {a b c d : Int} (T : Tiling a b c d Plane) :
    ∃ U : Tiling a b c d Plane, U.world ⟨0,0,a,b,c,d⟩ := by
  obtain ⟨t,ht,_⟩ := T.cover 0 0 True.intro
  let V := (T.translate (-t.x) (-t.y)).congr (by intro x y; rfl)
  have anchor : V.world ⟨0,0,t.east,t.north,t.west,t.south⟩ := by
    refine ⟨t,ht,?_⟩
    apply CrossUnits.same_eq
    unfold Same shift
    dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
  have oriented := T.copies t ht
  rcases oriented with h | h | h | h | h | h | h | h
  all_goals rcases h with ⟨he,hn,hw,hs⟩
  · exact ⟨V,by simpa only [he,hn,hw,hs] using anchor⟩
  · refine ⟨V.transpose.mirrorX,?_⟩
    exact ⟨_,⟨_,anchor,rfl⟩,by simp only [mirrorX,transpose,he,hn,hw,hs] <;> rfl⟩
  · refine ⟨V.mirrorX.mirrorY,?_⟩
    exact ⟨_,⟨_,anchor,rfl⟩,by simp only [mirrorY,mirrorX,he,hn,hw,hs] <;> rfl⟩
  · refine ⟨V.transpose.mirrorY,?_⟩
    exact ⟨_,⟨_,anchor,rfl⟩,by simp only [mirrorY,transpose,he,hn,hw,hs] <;> rfl⟩
  · refine ⟨V.transpose.mirrorX.mirrorY,?_⟩
    exact ⟨_,⟨_,⟨_,anchor,rfl⟩,rfl⟩,by simp only [mirrorY,mirrorX,transpose,he,hn,hw,hs] <;> rfl⟩
  · refine ⟨V.mirrorX,?_⟩
    exact ⟨_,anchor,by simp only [mirrorX,he,hn,hw,hs] <;> rfl⟩
  · refine ⟨V.transpose,?_⟩
    exact ⟨_,anchor,by simp only [transpose,he,hn,hw,hs] <;> rfl⟩
  · refine ⟨V.mirrorY,?_⟩
    exact ⟨_,anchor,by simp only [mirrorY,he,hn,hw,hs] <;> rfl⟩

#print axioms normalize_plane

theorem copy_rotate_parameters (a b c d : Int) (t : Cross) :
    Copy a b c d t ↔ Copy b c d a t := by
  simp only [Copy, or_assoc, or_comm, or_left_comm]

theorem copy_reflect_parameters (a b c d : Int) (t : Cross) :
    Copy a b c d t ↔ Copy a d c b t := by
  simp only [Copy, or_assoc, or_comm, or_left_comm]

def Tiling.rotateParameters {a b c d : Int} {R : Region} (T : Tiling a b c d R) :
    Tiling b c d a R where
  world := T.world
  copies t ht := (copy_rotate_parameters a b c d t).1 (T.copies t ht)
  inside := T.inside
  cover := T.cover
  disjoint := T.disjoint

def Tiling.reflectParameters {a b c d : Int} {R : Region} (T : Tiling a b c d R) :
    Tiling a d c b R where
  world := T.world
  copies t ht := (copy_reflect_parameters a b c d t).1 (T.copies t ht)
  inside := T.inside
  cover := T.cover
  disjoint := T.disjoint

end PolyominoFormal

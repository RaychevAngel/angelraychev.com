import LQuadrantHpOptimizedUnequalMixedNonexceptionDeltaTwoPrunedArithmeticDefs
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace LRegionArithmetic

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n028_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((5 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((5 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n028_empty (a b : Int)
    (h0 : ((fact_366edf150095_2905 a b) ∨ (fact_366edf150095_2577 a b) ∨ (fact_366edf150095_4066 a b) ∨ (fact_366edf150095_4071 a b) ∨ (fact_366edf150095_2580 a b) ∨ (fact_366edf150095_3180 a b) ∨ ((((5 : Int) ≥ ((2 : Int) - b)) ∧ ((5 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) + a)) ∧ ((4 : Int) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((4 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_2586 a b)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n028_o0 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h3 : (¬ ((((5 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n028_o1 (a b jx jy : Int)
    (h0 : (¬ ((((5 : Int) = jx) ∧ (jy = ((4 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n028_o2 (a b jx jy : Int)
    (h0 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (fact_366edf150095_2954 a b jy))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n028_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h2 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (¬ (((jx = ((5 : Int) + b)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h6 : (((jx + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jx - b)) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h7 : (((jx + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jx - b)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n028_o4 (a b jx jy : Int)
    (h0 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (¬ ((((5 : Int) = jx) ∧ (jy = ((4 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h5 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n028_o5 (a b jx jy : Int)
    (h0 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h1 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (¬ (((jx = ((5 : Int) + a)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n028_o6 (a b jx jy : Int)
    (h0 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h3 : (((4 : Int) > (jx + b)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h4 : (¬ ((((5 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n028_o7 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h1 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (¬ ((((5 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h3 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h4 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n029_point (a b : Int)
    (h0 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (fact_366edf150095_4 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n029_empty (a b : Int)
    (h0 : ((fact_366edf150095_3226 a b) ∨ (fact_366edf150095_3132 a b) ∨ (fact_366edf150095_4222 a b) ∨ (fact_366edf150095_4311 a b) ∨ (fact_366edf150095_3140 a b) ∨ (fact_366edf150095_3357 a b) ∨ (fact_366edf150095_3396 a b) ∨ (fact_366edf150095_3149 a b) ∨ (fact_366edf150095_3154 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((5 : Int) + a)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ ((5 : Int) + b)) ∧ ((5 : Int) ≥ ((5 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((2 : Int) * a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : ((((1 : Int) + ((2 : Int) * a)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n029_o0 (a b jx jy : Int)
    (h0 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h1 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h2 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h3 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (fact_366edf150095_1828 a b jx jy))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n029_o1 (a b jx jy : Int)
    (h0 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (fact_366edf150095_1835 a b jx jy))
    (h2 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n029_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (fact_366edf150095_2954 a b jy))
    (h4 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h5 : (fact_366edf150095_1855 a b jx jy))
    (h6 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n029_o3 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - b)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (fact_366edf150095_1870 a b jx jy))
    (h3 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h4 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (((jx + (0 : Int)) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n029_o4 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1871 a b jx jy))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n029_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - a)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((jx + (0 : Int)) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h4 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h5 : (fact_366edf150095_1854 a b jx jy))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (a ≥ b))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n029_o6 (a b jx jy : Int)
    (h0 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (fact_366edf150095_1834 a b jx jy))
    (h3 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n029_o7 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (fact_366edf150095_1829 a b jx jy))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (((jx + a) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : (fact_366edf150095_2955 a b jy))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n030_point (a b : Int)
    (h0 : (¬ (((6 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((6 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n030_empty (a b : Int)
    (h0 : ((fact_366edf150095_2908 a b) ∨ (fact_366edf150095_2588 a b) ∨ (fact_366edf150095_4081 a b) ∨ (fact_366edf150095_4086 a b) ∨ (fact_366edf150095_2591 a b) ∨ (fact_366edf150095_3193 a b) ∨ ((((6 : Int) ≥ ((2 : Int) - b)) ∧ ((6 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) + a)) ∧ ((4 : Int) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((4 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_2595 a b) ∨ (fact_366edf150095_2596 a b) ∨ (fact_366edf150095_3203 a b)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n030_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (¬ ((((6 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h4 : (((5 : Int) > (jx + a)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h5 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n030_o1 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((jx + b) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) + a)) ∨ (((4 : Int) + a) < jy)))
    (h3 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n030_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (fact_366edf150095_2954 a b jy))
    (h4 : (a = (b + (2 : Int))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (((jx + (0 : Int)) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : ((((6 : Int) ≥ (jx - a)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n030_o3 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((6 : Int) ≥ (jx - b)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h3 : (¬ (((jx = ((6 : Int) + b)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n030_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((6 : Int) ≥ (jx - b)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n030_o5 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((6 : Int) ≥ (jx - a)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h3 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - a)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (¬ (((jx = ((6 : Int) + a)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n030_o6 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h2 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((jy + a) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - (0 : Int)))))
    (h3 : (((5 : Int) > (jx + b)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n030_o7 (a b jx jy : Int)
    (h0 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (¬ ((((6 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h4 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n031_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (fact_366edf150095_4 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n031_empty (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : ((fact_366edf150095_3226 a b) ∨ (fact_366edf150095_3132 a b) ∨ (fact_366edf150095_4222 a b) ∨ (fact_366edf150095_4311 a b) ∨ (fact_366edf150095_3140 a b) ∨ (fact_366edf150095_3357 a b) ∨ (fact_366edf150095_3396 a b) ∨ (fact_366edf150095_3149 a b) ∨ (fact_366edf150095_3154 a b) ∨ (fact_366edf150095_3416 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((6 : Int) ≤ ((5 : Int) + b)) ∧ ((6 : Int) ≥ ((5 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b))))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((((2 : Int) * a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((1 : Int) + ((2 : Int) * a)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n031_o0 (a b jx jy : Int)
    (h0 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (fact_366edf150095_1828 a b jx jy))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((jx + a) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (((jx + a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - (0 : Int))) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n031_o1 (a b jx jy : Int)
    (h0 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (fact_366edf150095_1835 a b jx jy))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n031_o2 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - a)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jy)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (fact_366edf150095_1855 a b jx jy))
    (h5 : (fact_366edf150095_2954 a b jy))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (a ≥ b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n031_o3 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - b)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (((jx + (0 : Int)) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : (fact_366edf150095_1870 a b jx jy))
    (h5 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h6 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n031_o4 (a b jx jy : Int)
    (h0 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_366edf150095_1871 a b jx jy))
    (h3 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a > b))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n031_o5 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (fact_366edf150095_1854 a b jx jy))
    (h2 : (((jx + (0 : Int)) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h3 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - a)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h5 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h9 : (a ≥ b))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n031_o6 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : (fact_366edf150095_1834 a b jx jy))
    (h5 : (¬ ((((((jy = (0 : Int)) ∧ ((3 : Int) = (0 : Int)) ∧ (a = b) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (((4 : Int) = ((jx + a) + (1 : Int))) ∨ (jx = (((4 : Int) + a) + (1 : Int)))) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ (((jy = (0 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = (b + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = b) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((4 : Int) = (jx + (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a)) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a) ∧ ((4 : Int) = (jx - (1 : Int))) ∧ (b = a) ∧ ((0 : Int) = (0 : Int))))) ∨ (((3 : Int) = (0 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (jy = (b + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = b) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int)) ∧ (jx = ((4 : Int) + (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a)) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a) ∧ (jx = ((4 : Int) - (1 : Int))) ∧ (b = a) ∧ ((0 : Int) = (0 : Int))))))) ∨ (((3 : Int) = jy) ∧ (a = a) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (((4 : Int) = ((jx + b) + (1 : Int))) ∨ ((((4 : Int) + b) + (1 : Int)) = jx)) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b) ∧ (b = (0 : Int)) ∧ ((0 : Int) = b))))) ∨ (((jy = (0 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = (a + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = a) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((4 : Int) = (jx + (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = b)) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a) ∧ ((4 : Int) = (jx - (1 : Int))) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))) ∨ (((3 : Int) = (0 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (jy = (a + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = a) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int)) ∧ (jx = ((4 : Int) + (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = b)) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a) ∧ (jx = ((4 : Int) - (1 : Int))) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))) ∨ (((jy = (0 : Int)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = (1 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((4 : Int) = (jx + (1 : Int))) ∧ (b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b) ∧ ((4 : Int) = (jx - (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ (((3 : Int) = (0 : Int)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ (jy = (1 : Int)) ∧ (a = b) ∧ ((0 : Int) = (0 : Int)) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int)) ∧ (jx = ((4 : Int) + (1 : Int))) ∧ (b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b) ∧ (jx = ((4 : Int) - (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a))))))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (((jx + b) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h9 : (a ≥ b))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h5
  clear h5
  left
  left
  left
  left
  refine ⟨?_,?_,?_,?_,?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n031_o7 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1829 a b jx jy))
    (h1 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (fact_366edf150095_2955 a b jy))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (((jx + a) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n032_run_four (a b : Int)
    (h0 : (¬ ((6 : Int) ≤ ((5 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n032_run_short (a b : Int)
    (h0 : (¬ ((((5 : Int) + b) - (6 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n032_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n032_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_3506 a b) ∨ (fact_366edf150095_3455 a b) ∨ (fact_366edf150095_5782 a b) ∨ (fact_366edf150095_5790 a b) ∨ (fact_366edf150095_3463 a b) ∨ (fact_366edf150095_3701 a b) ∨ (((((2 : Int) - b) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) + a)) ∧ ((5 : Int) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3470 a b) ∨ (fact_366edf150095_3472 a b) ∨ (fact_366edf150095_4040 a b) ∨ (fact_366edf150095_3710 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n032_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_4130 a b) ∨ (fact_366edf150095_3725 a b) ∨ (fact_366edf150095_5876 a b) ∨ (fact_366edf150095_5959 a b) ∨ (fact_366edf150095_3806 a b) ∨ (fact_366edf150095_4239 a b) ∨ (((((2 : Int) - b) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) + a)) ∧ ((5 : Int) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3925 a b) ∨ (fact_366edf150095_3976 a b) ∨ (fact_366edf150095_4983 a b) ∨ (fact_366edf150095_4395 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n032_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((((6 : Int) + (3 : Int)) ≤ ((5 : Int) + b)) ∧ ((fact_366edf150095_7467 a b) ∨ (fact_366edf150095_7537 a b))) ∨ ((((6 : Int) + (2 : Int)) ≤ ((5 : Int) + b)) ∧ (fact_366edf150095_7467 a b) ∧ (fact_366edf150095_7537 a b)) ∨ (((6 : Int) + (4 : Int)) ≤ ((5 : Int) + b)) ∨ ((((5 : Int) + b) = ((6 : Int) + (1 : Int))) ∧ (fact_366edf150095_7467 a b) ∧ (fact_366edf150095_7537 a b) ∧ (((fact_366edf150095_4175 a b) ∨ (fact_366edf150095_3770 a b) ∨ (fact_366edf150095_5921 a b) ∨ (fact_366edf150095_6004 a b) ∨ (fact_366edf150095_3851 a b) ∨ (fact_366edf150095_4284 a b) ∨ (((((2 : Int) - b) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3951 a b) ∨ (fact_366edf150095_4006 a b) ∨ (fact_366edf150095_5009 a b) ∨ (fact_366edf150095_4398 a b)) ∨ ((fact_366edf150095_5153 a b) ∨ (fact_366edf150095_4447 a b) ∨ (fact_366edf150095_6372 a b) ∨ (fact_366edf150095_6460 a b) ∨ (fact_366edf150095_4531 a b) ∨ (fact_366edf150095_5281 a b) ∨ (((((2 : Int) - b) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4717 a b) ∨ (fact_366edf150095_4866 a b) ∨ (fact_366edf150095_5674 a b) ∨ (fact_366edf150095_5412 a b)))) ∨ ((fact_366edf150095_7467 a b) ∧ (fact_366edf150095_7537 a b) ∧ ((fact_366edf150095_4175 a b) ∨ (fact_366edf150095_3770 a b) ∨ (fact_366edf150095_5921 a b) ∨ (fact_366edf150095_6004 a b) ∨ (fact_366edf150095_3851 a b) ∨ (fact_366edf150095_4284 a b) ∨ (((((2 : Int) - b) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3951 a b) ∨ (fact_366edf150095_4006 a b) ∨ (fact_366edf150095_5009 a b) ∨ (fact_366edf150095_4398 a b)) ∧ ((fact_366edf150095_5153 a b) ∨ (fact_366edf150095_4447 a b) ∨ (fact_366edf150095_6372 a b) ∨ (fact_366edf150095_6460 a b) ∨ (fact_366edf150095_4531 a b) ∨ (fact_366edf150095_5281 a b) ∨ (((((2 : Int) - b) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4717 a b) ∨ (fact_366edf150095_4866 a b) ∨ (fact_366edf150095_5674 a b) ∨ (fact_366edf150095_5412 a b))))))
    (h3 : (a ≥ b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n032_run_empty (a b run_x : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((6 : Int) ≤ run_x))
    (h3 : (run_x ≤ ((5 : Int) + b)))
    (h4 : ((fact_366edf150095_2377 a b run_x) ∨ (fact_366edf150095_2312 a b run_x) ∨ (fact_366edf150095_3520 a b run_x) ∨ (fact_366edf150095_3535 a b run_x) ∨ (fact_366edf150095_2317 a b run_x) ∨ (fact_366edf150095_2959 a b run_x) ∨ (((((2 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((2 : Int) + a)) ∧ ((5 : Int) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x) ∧ ((5 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_2325 a b run_x) ∨ (fact_366edf150095_2335 a b run_x) ∨ (fact_366edf150095_3016 a b run_x) ∨ (fact_366edf150095_2976 a b run_x)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n032_run_floor (a b run_x : Int)
    (h0 : ((6 : Int) ≤ run_x))
    (h1 : (run_x ≤ ((5 : Int) + b)))
    (h2 : (¬ ((fact_366edf150095_3351 a b run_x) ∨ (fact_366edf150095_3300 a b run_x) ∨ (fact_366edf150095_5215 a b run_x) ∨ (fact_366edf150095_5225 a b run_x) ∨ (fact_366edf150095_3310 a b run_x) ∨ (fact_366edf150095_3530 a b run_x) ∨ (((((2 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x) ∧ ((((2 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3324 a b run_x) ∨ (fact_366edf150095_3335 a b run_x) ∨ (fact_366edf150095_3600 a b run_x) ∨ (fact_366edf150095_3556 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n033_point (a b : Int)
    (h0 : (fact_366edf150095_4 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n033_empty (a b : Int)
    (h0 : ((fact_366edf150095_3226 a b) ∨ (fact_366edf150095_3132 a b) ∨ (fact_366edf150095_4222 a b) ∨ (fact_366edf150095_4311 a b) ∨ (fact_366edf150095_3140 a b) ∨ (fact_366edf150095_3357 a b) ∨ (fact_366edf150095_3396 a b) ∨ (fact_366edf150095_3149 a b) ∨ (fact_366edf150095_3154 a b) ∨ (fact_366edf150095_3416 a b) ∨ ((((((6 : Int) + a) - a) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ (((6 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ ((((6 : Int) + a) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b))))))
    (h1 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((((1 : Int) + ((2 : Int) * a)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h4 : ((((2 : Int) * a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n033_o0 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h4 : (((jx + a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - (0 : Int))) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h5 : (fact_366edf150095_1828 a b jx jy))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n033_o1 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (fact_366edf150095_1835 a b jx jy))
    (h2 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n033_o2 (a b jx jy : Int)
    (h0 : (fact_366edf150095_2954 a b jy))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (fact_366edf150095_1855 a b jx jy))
    (h5 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h8 : (a ≥ b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n033_o3 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h2 : (fact_366edf150095_1870 a b jx jy))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((jx + (0 : Int)) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h6 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - b)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h9 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h10 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h11 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h12 : (a ≥ (5 : Int)))
    (h13 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h14 : (a ≥ b))
    (h15 : (b ≥ (3 : Int)))
    (h16 : (a > b))
    (h17 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n033_o4 (a b jx jy : Int)
    (h0 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (fact_366edf150095_1871 a b jx jy))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (a ≥ b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a > b))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n033_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (((jx + (0 : Int)) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (fact_366edf150095_1854 a b jx jy))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - a)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n033_o6 (a b jx jy : Int)
    (h0 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h3 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h4 : (a = (b + (2 : Int))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (fact_366edf150095_1834 a b jx jy))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n033_o7 (a b jx jy : Int)
    (h0 : (fact_366edf150095_2955 a b jy))
    (h1 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (((jx + a) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (fact_366edf150095_1829 a b jx jy))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n034_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n034_run_short (a b : Int)
    (h0 : (¬ ((((1 : Int) + a) - (4 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n034_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n034_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3514 a b) ∨ (fact_366edf150095_3489 a b) ∨ (fact_366edf150095_5822 a b) ∨ (fact_366edf150095_5825 a b) ∨ (fact_366edf150095_3492 a b) ∨ (fact_366edf150095_4098 a b) ∨ ((((7 : Int) ≥ ((2 : Int) - b)) ∧ ((7 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3495 a b) ∨ ((((7 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a)))) ∨ ((((7 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((5 : Int) + b)) ∧ (((4 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((5 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (5 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4107 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n034_run_right (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (¬ (((((7 : Int) ≥ ((-1 : Int) - a)) ∧ ((7 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((7 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((0 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((7 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((7 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((7 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((7 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((7 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((7 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((7 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((7 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((7 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((1 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((7 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((7 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((7 : Int) ≥ ((2 : Int) * a)) ∧ ((7 : Int) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((7 : Int) ≥ ((2 : Int) - b)) ∧ ((7 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((7 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((3 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ ((((7 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((4 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ ((((7 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((5 : Int) + b)) ∧ (((4 : Int) + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a))) ∨ (((5 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (5 : Int)) ∧ ((((4 : Int) + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))))) ∨ ((((7 : Int) ≥ ((6 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((6 : Int) + a)) ∧ (((4 : Int) + b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + b))) ∨ (((6 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (6 : Int)) ∧ ((((4 : Int) + b) - b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n034_run_tall (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h2 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_366edf150095_7473 a b) ∨ (fact_366edf150095_7539 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ (fact_366edf150095_7473 a b) ∧ (fact_366edf150095_7539 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = ((4 : Int) + (1 : Int))) ∧ (fact_366edf150095_7473 a b) ∧ (fact_366edf150095_7539 a b) ∧ (((fact_366edf150095_4180 a b) ∨ (fact_366edf150095_3775 a b) ∨ (fact_366edf150095_5926 a b) ∨ (fact_366edf150095_6009 a b) ∨ (fact_366edf150095_3856 a b) ∨ (fact_366edf150095_4289 a b) ∨ (((((2 : Int) - b) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((7 : Int) + a)) ∧ ((2 : Int) ≥ ((7 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3956 a b) ∨ (fact_366edf150095_4010 a b) ∨ (fact_366edf150095_5013 a b) ∨ (fact_366edf150095_5046 a b)) ∨ ((fact_366edf150095_5186 a b) ∨ (fact_366edf150095_4480 a b) ∨ (fact_366edf150095_6405 a b) ∨ (fact_366edf150095_6493 a b) ∨ (fact_366edf150095_4564 a b) ∨ (fact_366edf150095_5314 a b) ∨ (((((2 : Int) - b) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((7 : Int) + a)) ∧ ((2 : Int) ≥ ((7 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((3 : Int) ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≥ ((7 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((4 : Int) ≤ ((7 : Int) + a)) ∧ ((4 : Int) ≥ ((7 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_366edf150095_5683 a b) ∨ (fact_366edf150095_5727 a b)))) ∨ ((fact_366edf150095_7473 a b) ∧ (fact_366edf150095_7539 a b) ∧ ((fact_366edf150095_4180 a b) ∨ (fact_366edf150095_3775 a b) ∨ (fact_366edf150095_5926 a b) ∨ (fact_366edf150095_6009 a b) ∨ (fact_366edf150095_3856 a b) ∨ (fact_366edf150095_4289 a b) ∨ (((((2 : Int) - b) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((7 : Int) + a)) ∧ ((2 : Int) ≥ ((7 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3956 a b) ∨ (fact_366edf150095_4010 a b) ∨ (fact_366edf150095_5013 a b) ∨ (fact_366edf150095_5046 a b)) ∧ ((fact_366edf150095_5186 a b) ∨ (fact_366edf150095_4480 a b) ∨ (fact_366edf150095_6405 a b) ∨ (fact_366edf150095_6493 a b) ∨ (fact_366edf150095_4564 a b) ∨ (fact_366edf150095_5314 a b) ∨ (((((2 : Int) - b) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((7 : Int) + a)) ∧ ((2 : Int) ≥ ((7 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((3 : Int) ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≥ ((7 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((4 : Int) ≤ ((7 : Int) + a)) ∧ ((4 : Int) ≥ ((7 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_366edf150095_5683 a b) ∨ (fact_366edf150095_5727 a b))))))
    (h3 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ (((1 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  apply h2
  clear h2
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n034_run_empty (a b run_x : Int)
    (h0 : ((4 : Int) ≤ run_x))
    (h1 : (a = (b + (2 : Int))))
    (h2 : ((fact_366edf150095_2382 a b run_x) ∨ (fact_366edf150095_2352 a b run_x) ∨ (fact_366edf150095_3625 a b run_x) ∨ (fact_366edf150095_3626 a b run_x) ∨ (fact_366edf150095_2353 a b run_x) ∨ (fact_366edf150095_3052 a b run_x) ∨ ((((7 : Int) ≥ ((2 : Int) - b)) ∧ ((7 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_2355 a b run_x) ∨ ((((7 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ ((((7 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((5 : Int) + b)) ∧ (((4 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a))) ∨ (((5 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (5 : Int)) ∧ ((((4 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3056 a b run_x)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (run_x ≤ ((1 : Int) + a)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n034_run_floor (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((4 : Int) ≤ run_x))
    (h2 : (¬ ((fact_366edf150095_3346 a b run_x) ∨ (fact_366edf150095_3295 a b run_x) ∨ (fact_366edf150095_5210 a b run_x) ∨ (fact_366edf150095_5220 a b run_x) ∨ (fact_366edf150095_3305 a b run_x) ∨ (fact_366edf150095_3525 a b run_x) ∨ (((((2 : Int) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3320 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ (((4 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a))) ∨ (((5 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((((4 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3605 a b run_x))))
    (h3 : (run_x ≤ ((1 : Int) + a)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n035_run_four (a b : Int)
    (h0 : (¬ (((4 : Int) + a) ≤ ((-1 : Int) + ((2 : Int) * a)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n035_run_short (a b : Int)
    (h0 : (¬ ((((-1 : Int) + ((2 : Int) * a)) - ((4 : Int) + a)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n035_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n035_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_4124 a b) ∨ (fact_366edf150095_3719 a b) ∨ (fact_366edf150095_5870 a b) ∨ (fact_366edf150095_5953 a b) ∨ (fact_366edf150095_3800 a b) ∨ (fact_366edf150095_4233 a b) ∨ (fact_366edf150095_4679 a b) ∨ (fact_366edf150095_3923 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + a) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + a)))) ∨ ((((((5 : Int) + b) - b) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int))) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int))) ∨ ((((5 : Int) + b) ≤ (((4 : Int) + a) - (1 : Int))) ∧ ((((4 : Int) + a) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((2 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + a)))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n035_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5847 a b) ∨ (fact_366edf150095_5832 a b) ∨ (fact_366edf150095_6955 a b) ∨ (fact_366edf150095_6958 a b) ∨ (fact_366edf150095_5835 a b) ∨ (fact_366edf150095_6130 a b) ∨ (fact_366edf150095_6162 a b) ∨ (fact_366edf150095_5839 a b) ∨ (fact_366edf150095_5842 a b) ∨ ((((((5 : Int) + b) - b) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int))) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int))) ∨ ((((5 : Int) + b) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((2 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + a)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n035_run_tall (a b : Int)
    (h0 : (¬ ((((((4 : Int) + a) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ ((fact_366edf150095_7431 a b) ∨ (fact_366edf150095_7618 a b))) ∨ (((((4 : Int) + a) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ (fact_366edf150095_7431 a b) ∧ (fact_366edf150095_7618 a b)) ∨ ((((4 : Int) + a) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∨ ((((-1 : Int) + ((2 : Int) * a)) = (((4 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7431 a b) ∧ (fact_366edf150095_7618 a b) ∧ (((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5490 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_4850 a b) ∨ (fact_366edf150095_5397 a b)) ∨ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6690 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6173 a b) ∨ (fact_366edf150095_6669 a b)))) ∨ ((fact_366edf150095_7431 a b) ∧ (fact_366edf150095_7618 a b) ∧ ((fact_366edf150095_5138 a b) ∨ (fact_366edf150095_4432 a b) ∨ (fact_366edf150095_6357 a b) ∨ (fact_366edf150095_6445 a b) ∨ (fact_366edf150095_4516 a b) ∨ (fact_366edf150095_5266 a b) ∨ (fact_366edf150095_5490 a b) ∨ (fact_366edf150095_4707 a b) ∨ (fact_366edf150095_4850 a b) ∨ (fact_366edf150095_5397 a b)) ∧ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6690 a b) ∨ (fact_366edf150095_6163 a b) ∨ (fact_366edf150095_6173 a b) ∨ (fact_366edf150095_6669 a b))))))
    (h1 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    : False := by
  apply h0
  clear h0
  by_cases split0 : ((((4 : Int) + a) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a)))
  · left
    refine ⟨?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · left
      right
      right
      right
      right
      right
      right
      right
      right
      right
      right
      refine ⟨?_,?_,?_,?_⟩
      · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · by_cases split1 : ((((4 : Int) + a) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a)))
    · right
      left
      refine ⟨?_,?_,?_⟩
      · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · right
        right
        right
        right
        right
        right
        right
        right
        right
        right
        refine ⟨?_,?_,?_,?_⟩
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · right
        right
        right
        right
        right
        left
        right
        refine ⟨?_,?_,?_,?_⟩
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · right
      right
      right
      left
      refine ⟨?_,?_,?_,?_⟩
      · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · right
        right
        right
        right
        right
        right
        right
        right
        right
        right
        refine ⟨?_,?_,?_,?_⟩
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · right
        right
        right
        right
        right
        left
        right
        refine ⟨?_,?_,?_,?_⟩
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
      · left
        right
        right
        right
        right
        right
        right
        right
        right
        right
        right
        refine ⟨?_,?_,?_,?_⟩
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
        · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n035_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h2 : (((4 : Int) + a) ≤ run_x))
    (h3 : ((fact_366edf150095_2374 a b run_x) ∨ (fact_366edf150095_2309 a b run_x) ∨ (fact_366edf150095_3517 a b run_x) ∨ (fact_366edf150095_3532 a b run_x) ∨ (fact_366edf150095_2314 a b run_x) ∨ (fact_366edf150095_2956 a b run_x) ∨ (fact_366edf150095_2987 a b run_x) ∨ (fact_366edf150095_2323 a b run_x) ∨ (fact_366edf150095_2333 a b run_x) ∨ ((((((5 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((5 : Int) + b) + (0 : Int))) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int))) ∨ ((((5 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + b)) ∧ ((2 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + a))))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n035_run_floor (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (((4 : Int) + a) ≤ run_x))
    (h2 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h3 : (¬ ((fact_366edf150095_3348 a b run_x) ∨ (fact_366edf150095_3297 a b run_x) ∨ (fact_366edf150095_5212 a b run_x) ∨ (fact_366edf150095_5222 a b run_x) ∨ (fact_366edf150095_3307 a b run_x) ∨ (fact_366edf150095_3527 a b run_x) ∨ (fact_366edf150095_3567 a b run_x) ∨ (fact_366edf150095_3322 a b run_x) ∨ (fact_366edf150095_3333 a b run_x) ∨ ((((((5 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((5 : Int) + b) + (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((5 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + b)) ∧ (((4 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((4 : Int) + a)))))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n036_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_366edf150095_10 a b))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n036_empty (a b : Int)
    (h0 : ((fact_366edf150095_3232 a b) ∨ (fact_366edf150095_3166 a b) ∨ (fact_366edf150095_5092 a b) ∨ (fact_366edf150095_5094 a b) ∨ (fact_366edf150095_3168 a b) ∨ (fact_366edf150095_3423 a b) ∨ ((((3 : Int) ≥ ((2 : Int) - b)) ∧ ((3 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + a) - a) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3170 a b) ∨ ((((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≥ ((3 : Int) + b))) ∨ (((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((3 : Int) + a)))) ∨ ((((3 : Int) ≥ ((5 : Int) - b)) ∧ ((3 : Int) ≤ ((5 : Int) + (0 : Int))) ∧ (((4 : Int) + a) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ ((4 : Int) + a))) ∨ (((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((((4 : Int) + a) - a) ≤ ((3 : Int) + b)) ∧ (((3 : Int) + b) ≤ (((4 : Int) + a) + (0 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((1 : Int) + ((2 : Int) * a)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n036_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((5 : Int) > (jx + a)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (((jx + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h6 : (((jx + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jx - (0 : Int))) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h7 : (fact_366edf150095_1798 a b jx jy))
    (h8 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h9 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n036_o1 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - a))))
    (h3 : (fact_366edf150095_1803 a b jx jy))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jx < ((5 : Int) - b)) ∨ (((5 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h8 : (a ≥ b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n036_o2 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - b)) ∨ (((5 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - b))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (fact_366edf150095_1807 a b jx jy))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - b))))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n036_o3 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h1 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (fact_366edf150095_1810 a b jx jy))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n036_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : ((jx < ((5 : Int) - b)) ∨ (((5 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - a))))
    (h6 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - a))))
    (h7 : (fact_366edf150095_1811 a b jx jy))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n036_o5 (a b jx jy : Int)
    (h0 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (fact_366edf150095_1806 a b jx jy))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n036_o6 (a b jx jy : Int)
    (h0 : (((jx + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h1 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (((jx + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jx - (0 : Int))) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h4 : (fact_366edf150095_1802 a b jx jy))
    (h5 : (((5 : Int) > (jx + b)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n036_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((5 : Int) - b)) ∨ (((5 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jy - b))))
    (h2 : (fact_366edf150095_1799 a b jx jy))
    (h3 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - b))))
    (h4 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n037_point (a b : Int)
    (h0 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (fact_366edf150095_4 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n037_empty (a b : Int)
    (h0 : ((((2 : Int) * a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : ((fact_366edf150095_3226 a b) ∨ (fact_366edf150095_3132 a b) ∨ (fact_366edf150095_4222 a b) ∨ (fact_366edf150095_4311 a b) ∨ (fact_366edf150095_3140 a b) ∨ (fact_366edf150095_3357 a b) ∨ (fact_366edf150095_3396 a b) ∨ (fact_366edf150095_3149 a b) ∨ (fact_366edf150095_3154 a b) ∨ ((((((5 : Int) + a) - a) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ ((((5 : Int) + a) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h5 : ((((1 : Int) + ((2 : Int) * a)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n037_o0 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1828 a b jx jy))
    (h1 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h2 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h6 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n037_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_366edf150095_1835 a b jx jy))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n037_o2 (a b jx jy : Int)
    (h0 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (fact_366edf150095_2954 a b jy))
    (h3 : (fact_366edf150095_1855 a b jx jy))
    (h4 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n037_o3 (a b jx jy : Int)
    (h0 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h3 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - b)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h4 : ((jx < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h5 : ((jx < ((2 : Int) * a)) ∨ (((2 : Int) * a) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h6 : ((jx < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h7 : (fact_366edf150095_1870 a b jx jy))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h10 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h13 : (a ≥ (5 : Int)))
    (h14 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h15 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h16 : (a ≥ b))
    (h17 : (b ≥ (3 : Int)))
    (h18 : (a > b))
    (h19 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n037_o4 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (fact_366edf150095_1871 a b jx jy))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n037_o5 (a b jx jy : Int)
    (h0 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - a)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (fact_366edf150095_1854 a b jx jy))
    (h7 : (((jx + (0 : Int)) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n037_o6 (a b jx jy : Int)
    (h0 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (fact_366edf150095_1834 a b jx jy))
    (h3 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n037_o7 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1829 a b jx jy))
    (h1 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (((jx + a) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_366edf150095_2955 a b jy))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n038_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_366edf150095_4 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n038_empty (a b : Int)
    (h0 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : ((((1 : Int) + ((2 : Int) * a)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h2 : ((((2 : Int) * a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : ((fact_366edf150095_3226 a b) ∨ (fact_366edf150095_3132 a b) ∨ (fact_366edf150095_4222 a b) ∨ (fact_366edf150095_4311 a b) ∨ (fact_366edf150095_3140 a b) ∨ (fact_366edf150095_3357 a b) ∨ (fact_366edf150095_3396 a b) ∨ (fact_366edf150095_3149 a b) ∨ (fact_366edf150095_3154 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ ((5 : Int) + b)) ∧ ((5 : Int) ≥ ((5 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + a))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n038_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h2 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h3 : (fact_366edf150095_1828 a b jx jy))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n038_o1 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_366edf150095_1835 a b jx jy))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n038_o2 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1855 a b jx jy))
    (h1 : (fact_366edf150095_2954 a b jy))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n038_o3 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h3 : (fact_366edf150095_1870 a b jx jy))
    (h4 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - b)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h5 : ((jx < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n038_o4 (a b jx jy : Int)
    (h0 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_366edf150095_1871 a b jx jy))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n038_o5 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((jx + (0 : Int)) < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h3 : ((jx < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h4 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : ((jx < ((2 : Int) * a)) ∨ (((2 : Int) * a) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - a)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h8 : (fact_366edf150095_1854 a b jx jy))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n038_o6 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (fact_366edf150095_1834 a b jx jy))
    (h3 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n038_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (fact_366edf150095_1829 a b jx jy))
    (h2 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h3 : (fact_366edf150095_2955 a b jy))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n039_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n039_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((1 : Int) + a) - (4 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n039_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n039_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3512 a b) ∨ (fact_366edf150095_3482 a b) ∨ (fact_366edf150095_5817 a b) ∨ (fact_366edf150095_5819 a b) ∨ (fact_366edf150095_3484 a b) ∨ (fact_366edf150095_4084 a b) ∨ ((((6 : Int) ≥ ((2 : Int) - b)) ∧ ((6 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3487 a b) ∨ (fact_366edf150095_4095 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n039_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (¬ ((fact_366edf150095_4209 a b) ∨ (fact_366edf150095_4090 a b) ∨ (fact_366edf150095_6120 a b) ∨ (fact_366edf150095_6121 a b) ∨ (fact_366edf150095_4091 a b) ∨ (fact_366edf150095_5103 a b) ∨ ((((6 : Int) ≥ ((2 : Int) - b)) ∧ ((6 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ ((((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_366edf150095_5105 a b))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n039_run_tall (a b : Int)
    (h0 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h1 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_366edf150095_7369 a b) ∨ (fact_366edf150095_7432 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ (fact_366edf150095_7369 a b) ∧ (fact_366edf150095_7432 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = ((4 : Int) + (1 : Int))) ∧ (fact_366edf150095_7369 a b) ∧ (fact_366edf150095_7432 a b) ∧ (((fact_366edf150095_4165 a b) ∨ (fact_366edf150095_3760 a b) ∨ (fact_366edf150095_5911 a b) ∨ (fact_366edf150095_5994 a b) ∨ (fact_366edf150095_3841 a b) ∨ (fact_366edf150095_4274 a b) ∨ (((((2 : Int) - b) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3944 a b) ∨ (fact_366edf150095_3993 a b) ∨ (fact_366edf150095_4995 a b)) ∨ ((fact_366edf150095_5180 a b) ∨ (fact_366edf150095_4474 a b) ∨ (fact_366edf150095_6399 a b) ∨ (fact_366edf150095_6487 a b) ∨ (fact_366edf150095_4558 a b) ∨ (fact_366edf150095_5308 a b) ∨ (((((2 : Int) - b) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_4897 a b) ∨ (fact_366edf150095_5677 a b)))) ∨ ((fact_366edf150095_7369 a b) ∧ (fact_366edf150095_7432 a b) ∧ ((fact_366edf150095_4165 a b) ∨ (fact_366edf150095_3760 a b) ∨ (fact_366edf150095_5911 a b) ∨ (fact_366edf150095_5994 a b) ∨ (fact_366edf150095_3841 a b) ∨ (fact_366edf150095_4274 a b) ∨ (((((2 : Int) - b) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3944 a b) ∨ (fact_366edf150095_3993 a b) ∨ (fact_366edf150095_4995 a b)) ∧ ((fact_366edf150095_5180 a b) ∨ (fact_366edf150095_4474 a b) ∨ (fact_366edf150095_6399 a b) ∨ (fact_366edf150095_6487 a b) ∨ (fact_366edf150095_4558 a b) ∨ (fact_366edf150095_5308 a b) ∨ (((((2 : Int) - b) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_4897 a b) ∨ (fact_366edf150095_5677 a b))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ b))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n039_run_empty (a b run_x : Int)
    (h0 : (run_x ≤ ((1 : Int) + a)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((fact_366edf150095_2381 a b run_x) ∨ (fact_366edf150095_2347 a b run_x) ∨ (fact_366edf150095_3622 a b run_x) ∨ (fact_366edf150095_3623 a b run_x) ∨ (fact_366edf150095_2348 a b run_x) ∨ (fact_366edf150095_3045 a b run_x) ∨ ((((6 : Int) ≥ ((2 : Int) - b)) ∧ ((6 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_2350 a b run_x) ∨ (fact_366edf150095_2351 a b run_x) ∨ (fact_366edf150095_3051 a b run_x)))
    (h4 : ((4 : Int) ≤ run_x))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n039_run_floor (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((fact_366edf150095_3345 a b run_x) ∨ (fact_366edf150095_3294 a b run_x) ∨ (fact_366edf150095_5209 a b run_x) ∨ (fact_366edf150095_5219 a b run_x) ∨ (fact_366edf150095_3304 a b run_x) ∨ (fact_366edf150095_3524 a b run_x) ∨ (((((2 : Int) - b) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3319 a b run_x) ∨ (fact_366edf150095_3328 a b run_x) ∨ (fact_366edf150095_3596 a b run_x))))
    (h2 : ((4 : Int) ≤ run_x))
    (h3 : (run_x ≤ ((1 : Int) + a)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n040_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≤ a)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n040_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((a - (3 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n040_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n040_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3509 a b) ∨ (fact_366edf150095_3476 a b) ∨ (fact_366edf150095_5811 a b) ∨ (fact_366edf150095_5813 a b) ∨ (fact_366edf150095_3478 a b) ∨ (fact_366edf150095_4068 a b) ∨ ((((5 : Int) ≥ ((2 : Int) - b)) ∧ ((5 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_4078 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n040_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (¬ ((fact_366edf150095_3235 a b) ∨ (fact_366edf150095_3183 a b) ∨ (fact_366edf150095_5098 a b) ∨ (fact_366edf150095_5100 a b) ∨ (fact_366edf150095_3184 a b) ∨ (fact_366edf150095_3430 a b) ∨ ((((5 : Int) ≥ ((2 : Int) - b)) ∧ ((5 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3431 a b))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n040_run_tall (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_366edf150095_7337 a b) ∨ (fact_366edf150095_7311 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_366edf150095_7337 a b) ∧ (fact_366edf150095_7311 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_366edf150095_7337 a b) ∧ (fact_366edf150095_7311 a b) ∧ (((fact_366edf150095_4150 a b) ∨ (fact_366edf150095_3745 a b) ∨ (fact_366edf150095_5896 a b) ∨ (fact_366edf150095_5979 a b) ∨ (fact_366edf150095_3826 a b) ∨ (fact_366edf150095_4259 a b) ∨ (fact_366edf150095_4686 a b) ∨ (fact_366edf150095_3933 a b) ∨ (fact_366edf150095_4877 a b)) ∨ ((fact_366edf150095_3440 a b) ∨ (fact_366edf150095_3364 a b) ∨ (fact_366edf150095_5236 a b) ∨ (fact_366edf150095_5331 a b) ∨ (fact_366edf150095_3375 a b) ∨ (fact_366edf150095_3632 a b) ∨ (fact_366edf150095_3663 a b) ∨ (fact_366edf150095_3397 a b) ∨ (fact_366edf150095_3678 a b)))) ∨ ((fact_366edf150095_7337 a b) ∧ (fact_366edf150095_7311 a b) ∧ ((fact_366edf150095_4150 a b) ∨ (fact_366edf150095_3745 a b) ∨ (fact_366edf150095_5896 a b) ∨ (fact_366edf150095_5979 a b) ∨ (fact_366edf150095_3826 a b) ∨ (fact_366edf150095_4259 a b) ∨ (fact_366edf150095_4686 a b) ∨ (fact_366edf150095_3933 a b) ∨ (fact_366edf150095_4877 a b)) ∧ ((fact_366edf150095_3440 a b) ∨ (fact_366edf150095_3364 a b) ∨ (fact_366edf150095_5236 a b) ∨ (fact_366edf150095_5331 a b) ∨ (fact_366edf150095_3375 a b) ∨ (fact_366edf150095_3632 a b) ∨ (fact_366edf150095_3663 a b) ∨ (fact_366edf150095_3397 a b) ∨ (fact_366edf150095_3678 a b))))))
    (h2 : (a > b))
    (h3 : (a = (b + (2 : Int))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n040_run_empty (a b run_x : Int)
    (h0 : ((3 : Int) ≤ run_x))
    (h1 : ((fact_366edf150095_2380 a b run_x) ∨ (fact_366edf150095_2344 a b run_x) ∨ (fact_366edf150095_3619 a b run_x) ∨ (fact_366edf150095_3620 a b run_x) ∨ (fact_366edf150095_2345 a b run_x) ∨ (fact_366edf150095_3040 a b run_x) ∨ ((((5 : Int) ≥ ((2 : Int) - b)) ∧ ((5 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3043 a b run_x)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (run_x ≤ a))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n040_run_floor (a b run_x : Int)
    (h0 : ((3 : Int) ≤ run_x))
    (h1 : (¬ ((fact_366edf150095_3344 a b run_x) ∨ (fact_366edf150095_3293 a b run_x) ∨ (fact_366edf150095_5208 a b run_x) ∨ (fact_366edf150095_5218 a b run_x) ∨ (fact_366edf150095_3303 a b run_x) ∨ (fact_366edf150095_3523 a b run_x) ∨ (((((2 : Int) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3582 a b run_x))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (run_x ≤ a))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n041_point (a b : Int)
    (h0 : (¬ (((4 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n041_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((((4 : Int) ≥ ((-1 : Int) - a)) ∧ ((4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + b)))) ∨ ((((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + b)))) ∨ ((((4 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((4 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((4 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + b)))) ∨ ((((4 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((4 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((4 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + b)))) ∨ ((((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + b)))) ∨ ((((4 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((4 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((4 : Int) ≥ ((2 : Int) * a)) ∧ ((4 : Int) ≤ ((2 : Int) * a)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + a)))) ∨ ((((4 : Int) ≥ ((2 : Int) - b)) ∧ ((4 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((2 : Int) + a)) ∧ ((2 : Int) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) + a)) ∧ ((2 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((2 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((2 : Int) + a) + (0 : Int)))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n041_o0 (a b jx jy : Int)
    (h0 : (¬ ((((4 : Int) = jx) ∧ ((2 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n041_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - a))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h4 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n041_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - b))))
    (h2 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n041_o3 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (¬ (((jx = ((4 : Int) + b)) ∧ ((2 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n041_o4 (a b jx jy : Int)
    (h0 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n041_o5 (a b jx jy : Int)
    (h0 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h1 : (¬ (((jx = ((4 : Int) + a)) ∧ ((2 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n041_o6 (a b jx jy : Int)
    (h0 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h4 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n041_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((((4 : Int) = jx) ∧ (jy = ((2 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h2 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n042_point (a b : Int)
    (h0 : (¬ (((5 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((5 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n042_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((fact_366edf150095_2904 a b) ∨ (fact_366edf150095_2576 a b) ∨ (fact_366edf150095_4065 a b) ∨ (fact_366edf150095_4070 a b) ∨ (fact_366edf150095_2579 a b) ∨ (fact_366edf150095_3179 a b) ∨ ((((5 : Int) ≥ ((2 : Int) - b)) ∧ ((5 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) + a)) ∧ ((3 : Int) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((3 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≥ ((2 : Int) + a)) ∧ ((3 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n042_o0 (a b jx jy : Int)
    (h0 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h3 : (¬ ((((5 : Int) = jx) ∧ ((3 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n042_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h2 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - a))))
    (h3 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n042_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (fact_366edf150095_2954 a b jy))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - b))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n042_o3 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (¬ (((jx = ((5 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n042_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - a))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n042_o5 (a b jx jy : Int)
    (h0 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h3 : (¬ (((jx = ((5 : Int) + a)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n042_o6 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h2 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((4 : Int) > (jx + b)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n042_o7 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_366edf150095_2955 a b jy))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (¬ ((((5 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n043_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ (4 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n043_run_short (a b : Int)
    (h0 : (¬ (((4 : Int) - (4 : Int)) < b)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n043_run_nonnegative (a b : Int)
    (h0 : (¬ (((-1 : Int) + ((-1 : Int) * a)) ≤ (0 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n043_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_6069 a b) ∨ (fact_366edf150095_5858 a b) ∨ (fact_366edf150095_6972 a b) ∨ (fact_366edf150095_6976 a b) ∨ (fact_366edf150095_5860 a b) ∨ (fact_366edf150095_6207 a b) ∨ (((((2 : Int) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_6291 a b) ∨ (fact_366edf150095_5862 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ (((5 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n043_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_6068 a b) ∨ (fact_366edf150095_5857 a b) ∨ (fact_366edf150095_6971 a b) ∨ (fact_366edf150095_6975 a b) ∨ (fact_366edf150095_5859 a b) ∨ (fact_366edf150095_6206 a b) ∨ (((((2 : Int) - b) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((4 : Int) + (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) + (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_6290 a b) ∨ (fact_366edf150095_5861 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ (((5 : Int) ≤ ((4 : Int) + (1 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n043_run_tall (a b : Int)
    (h0 : (¬ ((((4 : Int) ≥ ((4 : Int) + (3 : Int))) ∧ ((fact_366edf150095_7633 a b) ∨ (fact_366edf150095_7631 a b))) ∨ (((4 : Int) ≥ ((4 : Int) + (2 : Int))) ∧ (fact_366edf150095_7633 a b) ∧ (fact_366edf150095_7631 a b)) ∨ ((4 : Int) ≥ ((4 : Int) + (4 : Int))) ∨ (((4 : Int) = ((4 : Int) + (1 : Int))) ∧ (fact_366edf150095_7633 a b) ∧ (fact_366edf150095_7631 a b) ∧ (((fact_366edf150095_6579 a b) ∨ (fact_366edf150095_6221 a b) ∨ (fact_366edf150095_7076 a b) ∨ (fact_366edf150095_7110 a b) ∨ (fact_366edf150095_6251 a b) ∨ (fact_366edf150095_6765 a b) ∨ (fact_366edf150095_6812 a b) ∨ (fact_366edf150095_6818 a b) ∨ (fact_366edf150095_6303 a b) ∨ (fact_366edf150095_6317 a b)) ∨ ((fact_366edf150095_6574 a b) ∨ (fact_366edf150095_6216 a b) ∨ (fact_366edf150095_7071 a b) ∨ (fact_366edf150095_7105 a b) ∨ (fact_366edf150095_6246 a b) ∨ (fact_366edf150095_6760 a b) ∨ (fact_366edf150095_6810 a b) ∨ (fact_366edf150095_6814 a b) ∨ (fact_366edf150095_6297 a b) ∨ (fact_366edf150095_6314 a b)))) ∨ ((fact_366edf150095_7633 a b) ∧ (fact_366edf150095_7631 a b) ∧ ((fact_366edf150095_6579 a b) ∨ (fact_366edf150095_6221 a b) ∨ (fact_366edf150095_7076 a b) ∨ (fact_366edf150095_7110 a b) ∨ (fact_366edf150095_6251 a b) ∨ (fact_366edf150095_6765 a b) ∨ (fact_366edf150095_6812 a b) ∨ (fact_366edf150095_6818 a b) ∨ (fact_366edf150095_6303 a b) ∨ (fact_366edf150095_6317 a b)) ∧ ((fact_366edf150095_6574 a b) ∨ (fact_366edf150095_6216 a b) ∨ (fact_366edf150095_7071 a b) ∨ (fact_366edf150095_7105 a b) ∨ (fact_366edf150095_6246 a b) ∨ (fact_366edf150095_6760 a b) ∨ (fact_366edf150095_6810 a b) ∨ (fact_366edf150095_6814 a b) ∨ (fact_366edf150095_6297 a b) ∨ (fact_366edf150095_6314 a b))))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a > b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n043_run_empty (a b run_x : Int)
    (h0 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : ((fact_366edf150095_4214 a b run_x) ∨ (fact_366edf150095_4199 a b run_x) ∨ (fact_366edf150095_6128 a b run_x) ∨ (fact_366edf150095_6134 a b run_x) ∨ (fact_366edf150095_4202 a b run_x) ∨ (fact_366edf150095_5115 a b run_x) ∨ (((((2 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x) ∧ ((((2 : Int) + a) - a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5204 a b run_x) ∨ (fact_366edf150095_4207 a b run_x) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-1 : Int) + ((-1 : Int) * a))))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + b))))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (a ≥ b))
    (h4 : ((4 : Int) ≥ run_x))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a > b))
    (h7 : ((4 : Int) ≤ run_x))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n043_run_floor (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((4 : Int) ≥ run_x))
    (h2 : (¬ ((fact_366edf150095_5848 a b run_x) ∨ (fact_366edf150095_5833 a b run_x) ∨ (fact_366edf150095_6956 a b run_x) ∨ (fact_366edf150095_6959 a b run_x) ∨ (fact_366edf150095_5836 a b run_x) ∨ (fact_366edf150095_6131 a b run_x) ∨ (((((2 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((2 : Int) + a))) ∨ (fact_366edf150095_660 a run_x)) ∨ (fact_366edf150095_6169 a b run_x) ∨ (fact_366edf150095_5843 a b run_x) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((3 : Int) ≥ (-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((3 : Int) + b)))))))
    (h3 : ((4 : Int) ≤ run_x))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n044_run_four (a b : Int)
    (h0 : (¬ ((5 : Int) ≤ ((4 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n044_run_short (a b : Int)
    (h0 : (¬ ((((4 : Int) + b) - (5 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n044_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n044_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3503 a b) ∨ (fact_366edf150095_3452 a b) ∨ (fact_366edf150095_5779 a b) ∨ (fact_366edf150095_5787 a b) ∨ (fact_366edf150095_3460 a b) ∨ (fact_366edf150095_3698 a b) ∨ (((((2 : Int) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) + a)) ∧ ((4 : Int) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≥ ((2 : Int) + a)) ∧ ((4 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3707 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n044_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4125 a b) ∨ (fact_366edf150095_3720 a b) ∨ (fact_366edf150095_5871 a b) ∨ (fact_366edf150095_5954 a b) ∨ (fact_366edf150095_3801 a b) ∨ (fact_366edf150095_4234 a b) ∨ (((((2 : Int) - b) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) + a)) ∧ ((4 : Int) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≥ ((2 : Int) + a)) ∧ ((4 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_4386 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n044_run_tall (a b : Int)
    (h0 : (¬ (((((5 : Int) + (3 : Int)) ≤ ((4 : Int) + b)) ∧ ((fact_366edf150095_7385 a b) ∨ (fact_366edf150095_7446 a b))) ∨ ((((5 : Int) + (2 : Int)) ≤ ((4 : Int) + b)) ∧ (fact_366edf150095_7385 a b) ∧ (fact_366edf150095_7446 a b)) ∨ (((5 : Int) + (4 : Int)) ≤ ((4 : Int) + b)) ∨ ((((4 : Int) + b) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7385 a b) ∧ (fact_366edf150095_7446 a b) ∧ (((fact_366edf150095_4158 a b) ∨ (fact_366edf150095_3753 a b) ∨ (fact_366edf150095_5904 a b) ∨ (fact_366edf150095_5987 a b) ∨ (fact_366edf150095_3834 a b) ∨ (fact_366edf150095_4267 a b) ∨ (fact_366edf150095_4691 a b) ∨ (fact_366edf150095_4752 a b) ∨ (fact_366edf150095_3978 a b) ∨ (fact_366edf150095_4388 a b)) ∨ ((fact_366edf150095_5142 a b) ∨ (fact_366edf150095_4436 a b) ∨ (fact_366edf150095_6361 a b) ∨ (fact_366edf150095_6449 a b) ∨ (fact_366edf150095_4520 a b) ∨ (fact_366edf150095_5270 a b) ∨ (((((2 : Int) - b) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5501 a b) ∨ (fact_366edf150095_4852 a b) ∨ (fact_366edf150095_5399 a b)))) ∨ ((fact_366edf150095_7385 a b) ∧ (fact_366edf150095_7446 a b) ∧ ((fact_366edf150095_4158 a b) ∨ (fact_366edf150095_3753 a b) ∨ (fact_366edf150095_5904 a b) ∨ (fact_366edf150095_5987 a b) ∨ (fact_366edf150095_3834 a b) ∨ (fact_366edf150095_4267 a b) ∨ (fact_366edf150095_4691 a b) ∨ (fact_366edf150095_4752 a b) ∨ (fact_366edf150095_3978 a b) ∨ (fact_366edf150095_4388 a b)) ∧ ((fact_366edf150095_5142 a b) ∨ (fact_366edf150095_4436 a b) ∨ (fact_366edf150095_6361 a b) ∨ (fact_366edf150095_6449 a b) ∨ (fact_366edf150095_4520 a b) ∨ (fact_366edf150095_5270 a b) ∨ (((((2 : Int) - b) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5501 a b) ∨ (fact_366edf150095_4852 a b) ∨ (fact_366edf150095_5399 a b))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (a > b))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n044_run_empty (a b run_x : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((5 : Int) ≤ run_x))
    (h4 : (run_x ≤ ((4 : Int) + b)))
    (h5 : ((fact_366edf150095_2376 a b run_x) ∨ (fact_366edf150095_2311 a b run_x) ∨ (fact_366edf150095_3519 a b run_x) ∨ (fact_366edf150095_3534 a b run_x) ∨ (fact_366edf150095_2316 a b run_x) ∨ (fact_366edf150095_2958 a b run_x) ∨ (fact_366edf150095_2988 a b run_x) ∨ (fact_366edf150095_2993 a b run_x) ∨ (fact_366edf150095_2329 a b run_x) ∨ (fact_366edf150095_2972 a b run_x)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n044_run_floor (a b run_x : Int)
    (h0 : ((5 : Int) ≤ run_x))
    (h1 : (run_x ≤ ((4 : Int) + b)))
    (h2 : (¬ ((fact_366edf150095_3350 a b run_x) ∨ (fact_366edf150095_3299 a b run_x) ∨ (fact_366edf150095_5214 a b run_x) ∨ (fact_366edf150095_5224 a b run_x) ∨ (fact_366edf150095_3309 a b run_x) ∨ (fact_366edf150095_3529 a b run_x) ∨ (fact_366edf150095_3568 a b run_x) ∨ (fact_366edf150095_3571 a b run_x) ∨ (fact_366edf150095_3329 a b run_x) ∨ (fact_366edf150095_3552 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n045_point (a b : Int)
    (h0 : (fact_366edf150095_2 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n045_empty (a b : Int)
    (h0 : (a ≥ b))
    (h1 : ((fact_366edf150095_3224 a b) ∨ (fact_366edf150095_3130 a b) ∨ (fact_366edf150095_4220 a b) ∨ (fact_366edf150095_4309 a b) ∨ (fact_366edf150095_3138 a b) ∨ (fact_366edf150095_3355 a b) ∨ (((((2 : Int) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((2 : Int) + a)) ∧ ((2 : Int) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a)) ∧ ((2 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) + a)) ∧ ((2 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((2 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3152 a b) ∨ ((((((5 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ ((((5 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + b))))))
    (h2 : ((((-1 : Int) + (0 : Int)) < (((1 : Int) + ((2 : Int) * a)) - a)) ∨ ((((1 : Int) + ((2 : Int) * a)) + (0 : Int)) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h3 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n045_o0 (a b jx jy : Int)
    (h0 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (fact_366edf150095_1822 a b jx jy))
    (h3 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n045_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h2 : (fact_366edf150095_1825 a b jx jy))
    (h3 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n045_o2 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1851 a b jx jy))
    (h1 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n045_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((jx + (0 : Int)) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h2 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < (jx - b)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h3 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h4 : (fact_366edf150095_1866 a b jx jy))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h8 : (a ≥ b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n045_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h3 : (fact_366edf150095_1867 a b jx jy))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n045_o5 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h1 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h6 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < (jx - a)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h7 : (fact_366edf150095_1850 a b jx jy))
    (h8 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h9 : ((jx < ((5 : Int) + a)) ∨ (((5 : Int) + a) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h10 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h11 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h12 : (a ≥ (5 : Int)))
    (h13 : (a = (b + (2 : Int))))
    (h14 : (b ≥ (3 : Int)))
    (h15 : (a ≥ b))
    (h16 : (a > b))
    (h17 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n045_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (fact_366edf150095_1824 a b jx jy))
    (h5 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h6 : (a ≥ b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n045_o7 (a b jx jy : Int)
    (h0 : (((jx + a) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h1 : (fact_366edf150095_1823 a b jx jy))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n046_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ (4 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n046_run_short (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((4 : Int) - (4 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n046_run_nonnegative (a b : Int)
    (h0 : (¬ (((-1 : Int) + ((-1 : Int) * a)) ≤ (0 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n046_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_6069 a b) ∨ (fact_366edf150095_5858 a b) ∨ (fact_366edf150095_6972 a b) ∨ (fact_366edf150095_6976 a b) ∨ (fact_366edf150095_5860 a b) ∨ (fact_366edf150095_6207 a b) ∨ (((((2 : Int) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_6291 a b) ∨ (fact_366edf150095_5862 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ (((3 : Int) + b) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + b))) ∨ (((5 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n046_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_6068 a b) ∨ (fact_366edf150095_5857 a b) ∨ (fact_366edf150095_6971 a b) ∨ (fact_366edf150095_6975 a b) ∨ (fact_366edf150095_5859 a b) ∨ (fact_366edf150095_6206 a b) ∨ (((((2 : Int) - b) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((4 : Int) + (1 : Int))) ∧ ((2 : Int) ≥ ((4 : Int) + (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_6290 a b) ∨ (fact_366edf150095_5861 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ ((4 : Int) + (1 : Int))) ∧ (((4 : Int) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ (((3 : Int) + b) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + b))) ∨ (((5 : Int) ≤ ((4 : Int) + (1 : Int))) ∧ ((5 : Int) ≥ ((4 : Int) + (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n046_run_tall (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (¬ ((((4 : Int) ≥ ((4 : Int) + (3 : Int))) ∧ ((fact_366edf150095_7645 a b) ∨ (fact_366edf150095_7642 a b))) ∨ (((4 : Int) ≥ ((4 : Int) + (2 : Int))) ∧ (fact_366edf150095_7645 a b) ∧ (fact_366edf150095_7642 a b)) ∨ ((4 : Int) ≥ ((4 : Int) + (4 : Int))) ∨ (((4 : Int) = ((4 : Int) + (1 : Int))) ∧ (fact_366edf150095_7645 a b) ∧ (fact_366edf150095_7642 a b) ∧ (((fact_366edf150095_6579 a b) ∨ (fact_366edf150095_6221 a b) ∨ (fact_366edf150095_7076 a b) ∨ (fact_366edf150095_7110 a b) ∨ (fact_366edf150095_6251 a b) ∨ (fact_366edf150095_6765 a b) ∨ (fact_366edf150095_6812 a b) ∨ (fact_366edf150095_6818 a b) ∨ (fact_366edf150095_6303 a b) ∨ (fact_366edf150095_6857 a b)) ∨ ((fact_366edf150095_6574 a b) ∨ (fact_366edf150095_6216 a b) ∨ (fact_366edf150095_7071 a b) ∨ (fact_366edf150095_7105 a b) ∨ (fact_366edf150095_6246 a b) ∨ (fact_366edf150095_6760 a b) ∨ (fact_366edf150095_6810 a b) ∨ (fact_366edf150095_6814 a b) ∨ (fact_366edf150095_6297 a b) ∨ (fact_366edf150095_6854 a b)))) ∨ ((fact_366edf150095_7645 a b) ∧ (fact_366edf150095_7642 a b) ∧ ((fact_366edf150095_6579 a b) ∨ (fact_366edf150095_6221 a b) ∨ (fact_366edf150095_7076 a b) ∨ (fact_366edf150095_7110 a b) ∨ (fact_366edf150095_6251 a b) ∨ (fact_366edf150095_6765 a b) ∨ (fact_366edf150095_6812 a b) ∨ (fact_366edf150095_6818 a b) ∨ (fact_366edf150095_6303 a b) ∨ (fact_366edf150095_6857 a b)) ∧ ((fact_366edf150095_6574 a b) ∨ (fact_366edf150095_6216 a b) ∨ (fact_366edf150095_7071 a b) ∨ (fact_366edf150095_7105 a b) ∨ (fact_366edf150095_6246 a b) ∨ (fact_366edf150095_6760 a b) ∨ (fact_366edf150095_6810 a b) ∨ (fact_366edf150095_6814 a b) ∨ (fact_366edf150095_6297 a b) ∨ (fact_366edf150095_6854 a b))))))
    (h5 : (a > b))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h4
  clear h4
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n046_run_empty (a b run_x : Int)
    (h0 : ((4 : Int) ≥ run_x))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ (((1 : Int) + a) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a > b))
    (h6 : ((4 : Int) ≤ run_x))
    (h7 : ((fact_366edf150095_4214 a b run_x) ∨ (fact_366edf150095_4199 a b run_x) ∨ (fact_366edf150095_6128 a b run_x) ∨ (fact_366edf150095_6134 a b run_x) ∨ (fact_366edf150095_4202 a b run_x) ∨ (fact_366edf150095_5115 a b run_x) ∨ (((((2 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x) ∧ ((((2 : Int) + a) - a) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5204 a b run_x) ∨ (fact_366edf150095_4207 a b run_x) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ (((3 : Int) + b) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + b))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ ((((3 : Int) + b) - b) ≤ (-((-1 : Int) + ((-1 : Int) * a)))) ∧ ((-((-1 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + b) + (0 : Int)))))))
    (h8 : (a ≥ b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n046_run_floor (a b run_x : Int)
    (h0 : ((4 : Int) ≥ run_x))
    (h1 : (¬ ((fact_366edf150095_5848 a b run_x) ∨ (fact_366edf150095_5833 a b run_x) ∨ (fact_366edf150095_6956 a b run_x) ∨ (fact_366edf150095_6959 a b run_x) ∨ (fact_366edf150095_5836 a b run_x) ∨ (fact_366edf150095_6131 a b run_x) ∨ (((((2 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((2 : Int) + a))) ∨ (fact_366edf150095_660 a run_x)) ∨ (fact_366edf150095_6169 a b run_x) ∨ (fact_366edf150095_5843 a b run_x) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ (((3 : Int) + b) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((3 : Int) + b))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ ((((3 : Int) + b) - b) ≤ (-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h2 : ((4 : Int) ≤ run_x))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n047_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ ((-1 : Int) + ((2 : Int) * a)))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n047_run_short (a b : Int)
    (h0 : (¬ ((((-1 : Int) + ((2 : Int) * a)) - ((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n047_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n047_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_6948 a b) ∨ (fact_366edf150095_6920 a b) ∨ (fact_366edf150095_7262 a b) ∨ (fact_366edf150095_7264 a b) ∨ (fact_366edf150095_6922 a b) ∨ (fact_366edf150095_6973 a b) ∨ (((((2 : Int) - b) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((2 : Int) + a)) ∧ ((2 : Int) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((3 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) + a)) ∧ ((2 : Int) ≤ ((2 : Int) + a))) ∨ (fact_366edf150095_2432 a b)) ∨ ((((((4 : Int) + b) - b) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ ((((4 : Int) + b) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + a)))))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((1 : Int) + ((2 : Int) * a)) < (((4 : Int) + b) - b)) ∨ ((((4 : Int) + b) + (0 : Int)) < ((1 : Int) + ((2 : Int) * a))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n047_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_5847 a b) ∨ (fact_366edf150095_5832 a b) ∨ (fact_366edf150095_6955 a b) ∨ (fact_366edf150095_6958 a b) ∨ (fact_366edf150095_5835 a b) ∨ (fact_366edf150095_6130 a b) ∨ (fact_366edf150095_6162 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) + a)) ∧ ((2 : Int) ≤ ((2 : Int) + a))) ∨ (fact_366edf150095_668 a)) ∨ ((((((4 : Int) + b) - b) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ (((4 : Int) + b) + (0 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ ((((4 : Int) + b) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + a)))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n047_run_tall (a b : Int)
    (h0 : (¬ ((((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ ((fact_366edf150095_7686 a b) ∨ (fact_366edf150095_7524 a b))) ∨ (((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ (fact_366edf150095_7686 a b) ∧ (fact_366edf150095_7524 a b)) ∨ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∨ ((((-1 : Int) + ((2 : Int) * a)) = (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_366edf150095_7686 a b) ∧ (fact_366edf150095_7524 a b) ∧ (((fact_366edf150095_7021 a b) ∨ (fact_366edf150095_6977 a b) ∨ (fact_366edf150095_7279 a b) ∨ (fact_366edf150095_7283 a b) ∨ (fact_366edf150095_6981 a b) ∨ (fact_366edf150095_7093 a b) ∨ (((((2 : Int) - b) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_7155 a b) ∨ (fact_366edf150095_7142 a b)) ∨ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6690 a b) ∨ (fact_366edf150095_6692 a b) ∨ (fact_366edf150095_6664 a b)))) ∨ ((fact_366edf150095_7686 a b) ∧ (fact_366edf150095_7524 a b) ∧ ((fact_366edf150095_7021 a b) ∨ (fact_366edf150095_6977 a b) ∨ (fact_366edf150095_7279 a b) ∨ (fact_366edf150095_7283 a b) ∨ (fact_366edf150095_6981 a b) ∨ (fact_366edf150095_7093 a b) ∨ (((((2 : Int) - b) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_7155 a b) ∨ (fact_366edf150095_7142 a b)) ∧ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6690 a b) ∨ (fact_366edf150095_6692 a b) ∨ (fact_366edf150095_6664 a b))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a > b))
    (h4 : (a ≥ b))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  left
  refine ⟨?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n047_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((fact_366edf150095_2374 a b run_x) ∨ (fact_366edf150095_2309 a b run_x) ∨ (fact_366edf150095_3517 a b run_x) ∨ (fact_366edf150095_3532 a b run_x) ∨ (fact_366edf150095_2314 a b run_x) ∨ (fact_366edf150095_2956 a b run_x) ∨ (fact_366edf150095_2987 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) + a)) ∧ ((2 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((2 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((((4 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + b) + (0 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ ((((4 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + a))))))
    (h3 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h4 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n047_run_floor (a b run_x : Int)
    (h0 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h1 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h2 : (¬ ((fact_366edf150095_3348 a b run_x) ∨ (fact_366edf150095_3297 a b run_x) ∨ (fact_366edf150095_5212 a b run_x) ∨ (fact_366edf150095_5222 a b run_x) ∨ (fact_366edf150095_3307 a b run_x) ∨ (fact_366edf150095_3527 a b run_x) ∨ (fact_366edf150095_3567 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((((2 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((((4 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((4 : Int) + b) + (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((4 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ (((2 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n048_point (a b : Int)
    (h0 : (¬ (((4 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n048_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((fact_366edf150095_2902 a b) ∨ (fact_366edf150095_2571 a b) ∨ (fact_366edf150095_4058 a b) ∨ (fact_366edf150095_4061 a b) ∨ (fact_366edf150095_2573 a b) ∨ (fact_366edf150095_3172 a b) ∨ (fact_366edf150095_3178 a b) ∨ ((((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≥ ((2 : Int) + a)) ∧ ((3 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((4 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((4 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≥ ((4 : Int) + a)) ∧ ((4 : Int) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n048_o0 (a b jx jy : Int)
    (h0 : (((jx + a) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h1 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n048_o1 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - a))))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n048_o2 (a b jx jy : Int)
    (h0 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h4 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (fact_366edf150095_2954 a b jy))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n048_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (¬ (((jx = ((4 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h3 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jx < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n048_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - a))))
    (h3 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n048_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h2 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((4 : Int) + a)) ∨ (((4 : Int) + a) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h5 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n048_o6 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h4 : ((jx < (((4 : Int) + a) - a)) ∨ ((((4 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n048_o7 (a b jx jy : Int)
    (h0 : (fact_366edf150095_2955 a b jy))
    (h1 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (¬ ((((4 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((jx + a) < ((4 : Int) + a)) ∨ (((4 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n049_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)))))
    (h1 : ((((2 : Int) * a) < (((4 : Int) + b) - b)) ∨ ((((4 : Int) + b) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n049_run_short (a b : Int)
    (h0 : (¬ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (4 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n049_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n049_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_3500 a b) ∨ (fact_366edf150095_3449 a b) ∨ (fact_366edf150095_5776 a b) ∨ (fact_366edf150095_5784 a b) ∨ (fact_366edf150095_3457 a b) ∨ (fact_366edf150095_3695 a b) ∨ (fact_366edf150095_3921 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≥ ((2 : Int) + a)) ∧ ((4 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((((4 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ ((((4 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3705 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n049_run_right (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (¬ ((fact_366edf150095_6962 a b) ∨ (fact_366edf150095_6950 a b) ∨ (fact_366edf150095_7267 a b) ∨ (fact_366edf150095_7269 a b) ∨ (fact_366edf150095_6952 a b) ∨ (fact_366edf150095_7008 a b) ∨ (fact_366edf150095_7039 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≥ ((2 : Int) + a)) ∧ ((4 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((((4 : Int) + a) - a) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ ((((4 : Int) + a) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_7019 a b))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n049_run_tall (a b : Int)
    (h0 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) ∧ ((fact_366edf150095_7403 a b) ∨ (fact_366edf150095_7757 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) ∧ (fact_366edf150095_7403 a b) ∧ (fact_366edf150095_7757 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) ∨ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) = ((4 : Int) + (1 : Int))) ∧ (fact_366edf150095_7403 a b) ∧ (fact_366edf150095_7757 a b) ∧ (((fact_366edf150095_4144 a b) ∨ (fact_366edf150095_3739 a b) ∨ (fact_366edf150095_5890 a b) ∨ (fact_366edf150095_5973 a b) ∨ (fact_366edf150095_3820 a b) ∨ (fact_366edf150095_4253 a b) ∨ (fact_366edf150095_4683 a b) ∨ (fact_366edf150095_4737 a b) ∨ (fact_366edf150095_4349 a b) ∨ (fact_366edf150095_4376 a b)) ∨ ((fact_366edf150095_7056 a b) ∨ (fact_366edf150095_7025 a b) ∨ (fact_366edf150095_7289 a b) ∨ (fact_366edf150095_7294 a b) ∨ (fact_366edf150095_7030 a b) ∨ (fact_366edf150095_7184 a b) ∨ (fact_366edf150095_7209 a b) ∨ (fact_366edf150095_7212 a b) ∨ (fact_366edf150095_7196 a b) ∨ (fact_366edf150095_7200 a b)))) ∨ ((fact_366edf150095_7403 a b) ∧ (fact_366edf150095_7757 a b) ∧ ((fact_366edf150095_4144 a b) ∨ (fact_366edf150095_3739 a b) ∨ (fact_366edf150095_5890 a b) ∨ (fact_366edf150095_5973 a b) ∨ (fact_366edf150095_3820 a b) ∨ (fact_366edf150095_4253 a b) ∨ (fact_366edf150095_4683 a b) ∨ (fact_366edf150095_4737 a b) ∨ (fact_366edf150095_4349 a b) ∨ (fact_366edf150095_4376 a b)) ∧ ((fact_366edf150095_7056 a b) ∨ (fact_366edf150095_7025 a b) ∨ (fact_366edf150095_7289 a b) ∨ (fact_366edf150095_7294 a b) ∨ (fact_366edf150095_7030 a b) ∨ (fact_366edf150095_7184 a b) ∨ (fact_366edf150095_7209 a b) ∨ (fact_366edf150095_7212 a b) ∨ (fact_366edf150095_7196 a b) ∨ (fact_366edf150095_7200 a b))))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a > b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n049_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((4 : Int) ≤ run_x))
    (h2 : ((fact_366edf150095_2376 a b run_x) ∨ (fact_366edf150095_2311 a b run_x) ∨ (fact_366edf150095_3519 a b run_x) ∨ (fact_366edf150095_3534 a b run_x) ∨ (fact_366edf150095_2316 a b run_x) ∨ (fact_366edf150095_2958 a b run_x) ∨ (fact_366edf150095_2988 a b run_x) ∨ (fact_366edf150095_2993 a b run_x) ∨ (fact_366edf150095_2967 a b run_x) ∨ (fact_366edf150095_2969 a b run_x)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n049_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))))
    (h1 : ((4 : Int) ≤ run_x))
    (h2 : (¬ ((fact_366edf150095_3350 a b run_x) ∨ (fact_366edf150095_3299 a b run_x) ∨ (fact_366edf150095_5214 a b run_x) ∨ (fact_366edf150095_5224 a b run_x) ∨ (fact_366edf150095_3309 a b run_x) ∨ (fact_366edf150095_3529 a b run_x) ∨ (fact_366edf150095_3568 a b run_x) ∨ (fact_366edf150095_3571 a b run_x) ∨ (fact_366edf150095_3547 a b run_x) ∨ (fact_366edf150095_3549 a b run_x))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n050_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≤ a)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n050_run_short (a b : Int)
    (h0 : (¬ ((a - (3 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n050_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n050_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_3509 a b) ∨ (fact_366edf150095_3476 a b) ∨ (fact_366edf150095_5811 a b) ∨ (fact_366edf150095_5813 a b) ∨ (fact_366edf150095_3478 a b) ∨ (fact_366edf150095_4068 a b) ∨ ((((5 : Int) ≥ ((2 : Int) - b)) ∧ ((5 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_4078 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n050_run_right (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (¬ ((fact_366edf150095_3235 a b) ∨ (fact_366edf150095_3183 a b) ∨ (fact_366edf150095_5098 a b) ∨ (fact_366edf150095_5100 a b) ∨ (fact_366edf150095_3184 a b) ∨ (fact_366edf150095_3430 a b) ∨ ((((5 : Int) ≥ ((2 : Int) - b)) ∧ ((5 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)) ∧ (((2 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ (((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3431 a b))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n050_run_tall (a b : Int)
    (h0 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_366edf150095_7406 a b) ∨ (fact_366edf150095_7356 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_366edf150095_7406 a b) ∧ (fact_366edf150095_7356 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_366edf150095_7406 a b) ∧ (fact_366edf150095_7356 a b) ∧ (((fact_366edf150095_4150 a b) ∨ (fact_366edf150095_3745 a b) ∨ (fact_366edf150095_5896 a b) ∨ (fact_366edf150095_5979 a b) ∨ (fact_366edf150095_3826 a b) ∨ (fact_366edf150095_4259 a b) ∨ (fact_366edf150095_4686 a b) ∨ (fact_366edf150095_4744 a b) ∨ (fact_366edf150095_4353 a b) ∨ (fact_366edf150095_4877 a b)) ∨ ((fact_366edf150095_3440 a b) ∨ (fact_366edf150095_3364 a b) ∨ (fact_366edf150095_5236 a b) ∨ (fact_366edf150095_5331 a b) ∨ (fact_366edf150095_3375 a b) ∨ (fact_366edf150095_3632 a b) ∨ (fact_366edf150095_3663 a b) ∨ (fact_366edf150095_3669 a b) ∨ (fact_366edf150095_3649 a b) ∨ (fact_366edf150095_3678 a b)))) ∨ ((fact_366edf150095_7406 a b) ∧ (fact_366edf150095_7356 a b) ∧ ((fact_366edf150095_4150 a b) ∨ (fact_366edf150095_3745 a b) ∨ (fact_366edf150095_5896 a b) ∨ (fact_366edf150095_5979 a b) ∨ (fact_366edf150095_3826 a b) ∨ (fact_366edf150095_4259 a b) ∨ (fact_366edf150095_4686 a b) ∨ (fact_366edf150095_4744 a b) ∨ (fact_366edf150095_4353 a b) ∨ (fact_366edf150095_4877 a b)) ∧ ((fact_366edf150095_3440 a b) ∨ (fact_366edf150095_3364 a b) ∨ (fact_366edf150095_5236 a b) ∨ (fact_366edf150095_5331 a b) ∨ (fact_366edf150095_3375 a b) ∨ (fact_366edf150095_3632 a b) ∨ (fact_366edf150095_3663 a b) ∨ (fact_366edf150095_3669 a b) ∨ (fact_366edf150095_3649 a b) ∨ (fact_366edf150095_3678 a b))))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n050_run_empty (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (run_x ≤ a))
    (h2 : ((fact_366edf150095_2380 a b run_x) ∨ (fact_366edf150095_2344 a b run_x) ∨ (fact_366edf150095_3619 a b run_x) ∨ (fact_366edf150095_3620 a b run_x) ∨ (fact_366edf150095_2345 a b run_x) ∨ (fact_366edf150095_3040 a b run_x) ∨ ((((5 : Int) ≥ ((2 : Int) - b)) ∧ ((5 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3042 a b run_x) ∨ ((((5 : Int) ≥ (((4 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((4 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((5 : Int) ≥ ((4 : Int) + a)) ∧ ((5 : Int) ≤ ((4 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3043 a b run_x)))
    (h3 : ((3 : Int) ≤ run_x))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n050_run_floor (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (run_x ≤ a))
    (h2 : (¬ ((fact_366edf150095_3344 a b run_x) ∨ (fact_366edf150095_3293 a b run_x) ∨ (fact_366edf150095_5208 a b run_x) ∨ (fact_366edf150095_5218 a b run_x) ∨ (fact_366edf150095_3303 a b run_x) ∨ (fact_366edf150095_3523 a b run_x) ∨ (((((2 : Int) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3570 a b run_x) ∨ ((((((4 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((4 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ ((((4 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_366edf150095_3582 a b run_x))))
    (h3 : ((3 : Int) ≤ run_x))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n051_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((2 : Int) ≤ ((1 : Int) + b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n051_run_short (a b : Int)
    (h0 : (¬ ((((1 : Int) + b) - (2 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n051_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n051_run_left (a b : Int)
    (h0 : (¬ (((((5 : Int) ≥ ((-1 : Int) - a)) ∧ ((5 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((5 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((5 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((5 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((5 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((5 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((5 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((5 : Int) ≥ ((2 : Int) * a)) ∧ ((5 : Int) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((5 : Int) ≥ ((2 : Int) - b)) ∧ ((5 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)) ∧ (((2 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((((2 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n051_run_right (a b : Int)
    (h0 : (¬ (((((5 : Int) ≥ ((-1 : Int) - a)) ∧ ((5 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((5 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((5 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((5 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((5 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((5 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((5 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((5 : Int) ≥ ((2 : Int) * a)) ∧ ((5 : Int) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((5 : Int) ≥ ((2 : Int) - b)) ∧ ((5 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + a) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)) ∧ (((2 : Int) + a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)) ∧ (((2 : Int) + b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((((2 : Int) + b) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n051_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h2 : (a > b))
    (h3 : (¬ (((((2 : Int) + (3 : Int)) ≤ ((1 : Int) + b)) ∧ ((fact_366edf150095_7346 a b) ∨ (fact_366edf150095_7362 a b))) ∨ ((((2 : Int) + (2 : Int)) ≤ ((1 : Int) + b)) ∧ (fact_366edf150095_7346 a b) ∧ (fact_366edf150095_7362 a b)) ∨ (((2 : Int) + (4 : Int)) ≤ ((1 : Int) + b)) ∨ ((((1 : Int) + b) = ((2 : Int) + (1 : Int))) ∧ (fact_366edf150095_7346 a b) ∧ (fact_366edf150095_7362 a b) ∧ (((fact_366edf150095_4149 a b) ∨ (fact_366edf150095_3744 a b) ∨ (fact_366edf150095_5895 a b) ∨ (fact_366edf150095_5978 a b) ∨ (fact_366edf150095_3825 a b) ∨ (fact_366edf150095_4258 a b) ∨ (((((2 : Int) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4743 a b) ∨ (fact_366edf150095_4876 a b)) ∨ ((fact_366edf150095_5176 a b) ∨ (fact_366edf150095_4470 a b) ∨ (fact_366edf150095_6395 a b) ∨ (fact_366edf150095_6483 a b) ∨ (fact_366edf150095_4554 a b) ∨ (fact_366edf150095_5304 a b) ∨ (((((2 : Int) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5507 a b) ∨ (fact_366edf150095_5597 a b)))) ∨ ((fact_366edf150095_7346 a b) ∧ (fact_366edf150095_7362 a b) ∧ ((fact_366edf150095_4149 a b) ∨ (fact_366edf150095_3744 a b) ∨ (fact_366edf150095_5895 a b) ∨ (fact_366edf150095_5978 a b) ∨ (fact_366edf150095_3825 a b) ∨ (fact_366edf150095_4258 a b) ∨ (((((2 : Int) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4743 a b) ∨ (fact_366edf150095_4876 a b)) ∧ ((fact_366edf150095_5176 a b) ∨ (fact_366edf150095_4470 a b) ∨ (fact_366edf150095_6395 a b) ∨ (fact_366edf150095_6483 a b) ∨ (fact_366edf150095_4554 a b) ∨ (fact_366edf150095_5304 a b) ∨ (((((2 : Int) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((5 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5507 a b) ∨ (fact_366edf150095_5597 a b))))))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    : False := by
  apply h3
  clear h3
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n051_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((fact_366edf150095_2380 a b run_x) ∨ (fact_366edf150095_2344 a b run_x) ∨ (fact_366edf150095_3619 a b run_x) ∨ (fact_366edf150095_3620 a b run_x) ∨ (fact_366edf150095_2345 a b run_x) ∨ (fact_366edf150095_3040 a b run_x) ∨ ((((5 : Int) ≥ ((2 : Int) - b)) ∧ ((5 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3042 a b run_x) ∨ ((((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)) ∧ (((2 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b))) ∨ (((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((((2 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + b) + (0 : Int)))))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (run_x ≤ ((1 : Int) + b)))
    (h4 : ((2 : Int) ≤ run_x))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n051_run_floor (a b run_x : Int)
    (h0 : ((2 : Int) ≤ run_x))
    (h1 : (run_x ≤ ((1 : Int) + b)))
    (h2 : (¬ ((fact_366edf150095_3344 a b run_x) ∨ (fact_366edf150095_3293 a b run_x) ∨ (fact_366edf150095_5208 a b run_x) ∨ (fact_366edf150095_5218 a b run_x) ∨ (fact_366edf150095_3303 a b run_x) ∨ (fact_366edf150095_3523 a b run_x) ∨ (((((2 : Int) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3570 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a)) ∧ (((2 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((2 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + b) + (0 : Int))))))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n052_run_four (a b : Int)
    (h0 : (¬ (((2 : Int) + a) ≤ ((-1 : Int) + ((2 : Int) * a)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n052_run_short (a b : Int)
    (h0 : (¬ ((((-1 : Int) + ((2 : Int) * a)) - ((2 : Int) + a)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n052_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n052_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4120 a b) ∨ (fact_366edf150095_3715 a b) ∨ (fact_366edf150095_5866 a b) ∨ (fact_366edf150095_5949 a b) ∨ (fact_366edf150095_3796 a b) ∨ (fact_366edf150095_4229 a b) ∨ (((((2 : Int) - b) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((2 : Int) + a)) ∧ ((2 : Int) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + a) - (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((((3 : Int) + b) - b) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + b) ≤ (((2 : Int) + a) - (1 : Int))) ∧ ((((2 : Int) + a) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + a)))))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n052_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_5847 a b) ∨ (fact_366edf150095_5832 a b) ∨ (fact_366edf150095_6955 a b) ∨ (fact_366edf150095_6958 a b) ∨ (fact_366edf150095_5835 a b) ∨ (fact_366edf150095_6130 a b) ∨ (fact_366edf150095_6162 a b) ∨ ((((((3 : Int) + b) - b) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + b) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + a)))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n052_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (¬ ((((((2 : Int) + a) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ ((fact_366edf150095_7325 a b) ∨ (fact_366edf150095_7376 a b))) ∨ (((((2 : Int) + a) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ (fact_366edf150095_7325 a b) ∧ (fact_366edf150095_7376 a b)) ∨ ((((2 : Int) + a) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∨ ((((-1 : Int) + ((2 : Int) * a)) = (((2 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7325 a b) ∧ (fact_366edf150095_7376 a b) ∧ (((fact_366edf150095_5126 a b) ∨ (fact_366edf150095_4420 a b) ∨ (fact_366edf150095_6345 a b) ∨ (fact_366edf150095_6433 a b) ∨ (fact_366edf150095_4504 a b) ∨ (fact_366edf150095_5254 a b) ∨ (fact_366edf150095_5488 a b) ∨ (fact_366edf150095_5362 a b)) ∨ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6690 a b) ∨ (fact_366edf150095_6658 a b)))) ∨ ((fact_366edf150095_7325 a b) ∧ (fact_366edf150095_7376 a b) ∧ ((fact_366edf150095_5126 a b) ∨ (fact_366edf150095_4420 a b) ∨ (fact_366edf150095_6345 a b) ∨ (fact_366edf150095_6433 a b) ∨ (fact_366edf150095_4504 a b) ∨ (fact_366edf150095_5254 a b) ∨ (fact_366edf150095_5488 a b) ∨ (fact_366edf150095_5362 a b)) ∧ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6690 a b) ∨ (fact_366edf150095_6658 a b))))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n052_run_empty (a b run_x : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (((2 : Int) + a) ≤ run_x))
    (h2 : ((fact_366edf150095_2374 a b run_x) ∨ (fact_366edf150095_2309 a b run_x) ∨ (fact_366edf150095_3517 a b run_x) ∨ (fact_366edf150095_3532 a b run_x) ∨ (fact_366edf150095_2314 a b run_x) ∨ (fact_366edf150095_2956 a b run_x) ∨ (fact_366edf150095_2987 a b run_x) ∨ ((((((3 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + (0 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + a))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n052_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (¬ ((fact_366edf150095_3348 a b run_x) ∨ (fact_366edf150095_3297 a b run_x) ∨ (fact_366edf150095_5212 a b run_x) ∨ (fact_366edf150095_5222 a b run_x) ∨ (fact_366edf150095_3307 a b run_x) ∨ (fact_366edf150095_3527 a b run_x) ∨ (fact_366edf150095_3567 a b run_x) ∨ ((((((3 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ (((2 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))))))
    (h3 : (((2 : Int) + a) ≤ run_x))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n053_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((3 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((3 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n053_empty (a b : Int)
    (h0 : ((fact_366edf150095_2892 a b) ∨ (fact_366edf150095_2569 a b) ∨ (fact_366edf150095_4056 a b) ∨ (fact_366edf150095_4057 a b) ∨ (fact_366edf150095_2570 a b) ∨ (fact_366edf150095_3165 a b) ∨ ((((3 : Int) ≥ ((2 : Int) - b)) ∧ ((3 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) + a)) ∧ ((3 : Int) ≤ ((2 : Int) + a))) ∨ (((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((3 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n053_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : (((jx + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h3 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h4 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n053_o1 (a b jx jy : Int)
    (h0 : (¬ ((((3 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h3 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n053_o2 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (fact_366edf150095_2954 a b jy))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n053_o3 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h1 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (¬ (((jx = ((3 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n053_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (¬ ((((3 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n053_o5 (a b jx jy : Int)
    (h0 : ((jx < ((3 : Int) + a)) ∨ (((3 : Int) + a) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h3 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h7 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n053_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h3 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h4 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : (¬ ((((3 : Int) = jx) ∧ ((3 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : (a ≥ b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n053_o7 (a b jx jy : Int)
    (h0 : (((jx + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h1 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (¬ ((((3 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_366edf150095_2955 a b jy))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n054_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((4 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n054_empty (a b : Int)
    (h0 : ((fact_366edf150095_2902 a b) ∨ (fact_366edf150095_2571 a b) ∨ (fact_366edf150095_4058 a b) ∨ (fact_366edf150095_4061 a b) ∨ (fact_366edf150095_2573 a b) ∨ (fact_366edf150095_3172 a b) ∨ (fact_366edf150095_3178 a b) ∨ (fact_366edf150095_3174 a b) ∨ ((((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n054_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h3 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h4 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((jx + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n054_o1 (a b jx jy : Int)
    (h0 : (((jx + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) + a)) ∨ (((3 : Int) + a) < jy)))
    (h1 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n054_o2 (a b jx jy : Int)
    (h0 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - b))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (fact_366edf150095_2954 a b jy))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n054_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h2 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (¬ (((jx = ((4 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n054_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n054_o5 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (((jx + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h6 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n054_o6 (a b jx jy : Int)
    (h0 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n054_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((jx + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h4 : (fact_366edf150095_2955 a b jy))
    (h5 : (¬ ((((4 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n055_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((2 : Int) * a) < (((4 : Int) + b) - b)) ∨ ((((4 : Int) + b) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (¬ ((4 : Int) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n055_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (4 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n055_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n055_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3500 a b) ∨ (fact_366edf150095_3449 a b) ∨ (fact_366edf150095_5776 a b) ∨ (fact_366edf150095_5784 a b) ∨ (fact_366edf150095_3457 a b) ∨ (fact_366edf150095_3695 a b) ∨ (fact_366edf150095_3921 a b) ∨ (fact_366edf150095_3703 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3705 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n055_run_right (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ ((fact_366edf150095_6962 a b) ∨ (fact_366edf150095_6950 a b) ∨ (fact_366edf150095_7267 a b) ∨ (fact_366edf150095_7269 a b) ∨ (fact_366edf150095_6952 a b) ∨ (fact_366edf150095_7008 a b) ∨ (fact_366edf150095_7039 a b) ∨ (fact_366edf150095_7018 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (fact_366edf150095_2534 a b)) ∨ (fact_366edf150095_7019 a b))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n055_run_tall (a b : Int)
    (h0 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) ∧ ((fact_366edf150095_7401 a b) ∨ (fact_366edf150095_7755 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) ∧ (fact_366edf150095_7401 a b) ∧ (fact_366edf150095_7755 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) ∨ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) = ((4 : Int) + (1 : Int))) ∧ (fact_366edf150095_7401 a b) ∧ (fact_366edf150095_7755 a b) ∧ (((fact_366edf150095_4144 a b) ∨ (fact_366edf150095_3739 a b) ∨ (fact_366edf150095_5890 a b) ∨ (fact_366edf150095_5973 a b) ∨ (fact_366edf150095_3820 a b) ∨ (fact_366edf150095_4253 a b) ∨ (fact_366edf150095_4683 a b) ∨ (fact_366edf150095_4327 a b) ∨ (fact_366edf150095_4739 a b) ∨ (fact_366edf150095_4376 a b)) ∨ ((fact_366edf150095_7056 a b) ∨ (fact_366edf150095_7025 a b) ∨ (fact_366edf150095_7289 a b) ∨ (fact_366edf150095_7294 a b) ∨ (fact_366edf150095_7030 a b) ∨ (fact_366edf150095_7184 a b) ∨ (fact_366edf150095_7209 a b) ∨ (fact_366edf150095_7189 a b) ∨ (fact_366edf150095_7214 a b) ∨ (fact_366edf150095_7200 a b)))) ∨ ((fact_366edf150095_7401 a b) ∧ (fact_366edf150095_7755 a b) ∧ ((fact_366edf150095_4144 a b) ∨ (fact_366edf150095_3739 a b) ∨ (fact_366edf150095_5890 a b) ∨ (fact_366edf150095_5973 a b) ∨ (fact_366edf150095_3820 a b) ∨ (fact_366edf150095_4253 a b) ∨ (fact_366edf150095_4683 a b) ∨ (fact_366edf150095_4327 a b) ∨ (fact_366edf150095_4739 a b) ∨ (fact_366edf150095_4376 a b)) ∧ ((fact_366edf150095_7056 a b) ∨ (fact_366edf150095_7025 a b) ∨ (fact_366edf150095_7289 a b) ∨ (fact_366edf150095_7294 a b) ∨ (fact_366edf150095_7030 a b) ∨ (fact_366edf150095_7184 a b) ∨ (fact_366edf150095_7209 a b) ∨ (fact_366edf150095_7189 a b) ∨ (fact_366edf150095_7214 a b) ∨ (fact_366edf150095_7200 a b))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a > b))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

end LRegionArithmetic

import LHalfPlaneLongCorner
import LHalfPlaneAlternatingTipLocal
import LHalfPlaneAlternatingLongTipLocal
import LHalfPlaneLocal

namespace PolyominoFormal.LHalfPlaneAlternating
open CrossUnits THalfPlaneStarters THalfPlaneGaps
set_option maxHeartbeats 300000

def Base (a b : Int) : Region := fun x y =>
  (Contains ⟨-1,0,0,b,a,0⟩ x y ∨ Contains ⟨0,0,a,b,0,0⟩ x y) ∨
  (Contains ⟨2*a+1,0,0,b,a,0⟩ x y ∨ Contains ⟨2*a+2,0,a,b,0,0⟩ x y)

theorem base_closed {a b : Int} (T : Tiling a b 0 0 HalfPlane)
    (h0 : T.world ⟨-1,0,0,b,a,0⟩) (h1 : T.world ⟨0,0,a,b,0,0⟩)
    (h2 : T.world ⟨2*a+1,0,0,b,a,0⟩) (h3 : T.world ⟨2*a+2,0,a,b,0,0⟩) :
    CornerCertificate.TileClosed T.world (Base a b) :=
  union_closed (pair_closed T h0 h1) (pair_closed T h2 h3)

/-- A tile meeting the low interior gap cannot cross its occupied floor.
The four bars supply enough floor to include every possible tile junction. -/
theorem gap_tile_above_floor {a b x y : Int} (ha : 1≤a) (hb : 0≤b) (hab : b≤a)
    (hx : 1≤x ∧ x≤2*a) (hy : 1≤y)
    (T : Tiling a b 0 0 HalfPlane)
    (h0 : T.world ⟨-1,0,0,b,a,0⟩) (h1 : T.world ⟨0,0,a,b,0,0⟩)
    (h2 : T.world ⟨2*a+1,0,0,b,a,0⟩) (h3 : T.world ⟨2*a+2,0,a,b,0,0⟩)
    {t : Cross} (ht : T.world t) (hit : Contains t x y) : 1≤t.y-t.south := by
  have nn := TPlane.copy_nonnegative (by omega) hb (by omega) (by omega) (T.copies t ht)
  have reach : t.x-a≤x ∧ x≤t.x+a := by
    have cp := T.copies t ht
    rcases cp with cp | cp | cp | cp | cp | cp | cp | cp
    all_goals rcases cp with ⟨he,hn,hw,hs⟩
    all_goals unfold Contains at hit; omega
  have empty : ¬Base a b x y := by dsimp [Base,Contains]; omega
  have avoid : ∀{z w}, Base a b z w → ¬Contains t z w :=
    fun h => avoid_closed (base_closed T h0 h1 h2 h3) ht hit empty h
  have floor : Base a b t.x 0 := by dsimp [Base,Contains]; omega
  have inside : 0≤t.y-t.south := T.inside t ht t.x (t.y-t.south) (by
    unfold Contains; unfold TPlane.Nonnegative at nn; right; omega)
  apply Classical.byContradiction
  intro notAbove
  apply avoid floor
  right
  unfold TPlane.Nonnegative at nn
  omega

theorem low_tile_above_floor {a b x y : Int} (ha : 1≤a) (hb : 0≤b) (hab : b≤a)
    (hx : 1≤x ∧ x≤2*a) (hy : 1≤y ∧ y≤b)
    (T : Tiling a b 0 0 HalfPlane)
    (h0 : T.world ⟨-1,0,0,b,a,0⟩) (h1 : T.world ⟨0,0,a,b,0,0⟩)
    (h2 : T.world ⟨2*a+1,0,0,b,a,0⟩) (h3 : T.world ⟨2*a+2,0,a,b,0,0⟩)
    {t : Cross} (ht : T.world t) (hit : Contains t x y) : 1≤t.y-t.south :=
  gap_tile_above_floor ha hb hab hx hy.1 T h0 h1 h2 h3 ht hit

theorem no_right_short_starter {a b p : Int} (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (hp : 1≤p ∧ p≤2*a-1) (T : Tiling a b 0 0 HalfPlane)
    (h0 : T.world ⟨-1,0,0,b,a,0⟩) (h1 : T.world ⟨0,0,a,b,0,0⟩)
    (h2 : T.world ⟨2*a+1,0,0,b,a,0⟩) (h3 : T.world ⟨2*a+2,0,a,b,0,0⟩)
    (anchor : T.world ⟨p,b+1,a,0,0,b⟩) : False := by
  let V := T.translate (-p) (-1)
  let W : Cross → Prop := fun t => V.world t ∧ 0≤t.y-t.south
  have copy : ∀t,W t→Copy a b 0 0 t := fun t ht => V.copies t ht.1
  have separate : ∀t u,W t→W u→t=u ∨ Apart t u := by
    intro t u ht hu
    by_cases eq : t=u
    · exact Or.inl eq
    · right
      apply TPlane.apart_of_no_common_nonnegative t u
        (TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copy t ht))
        (TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copy u hu))
      intro x y h h'
      exact eq (V.disjoint t u x y ht.1 hu.1 h h')
  have coverage : ∀x y,(x=1 ∧ (y=b-1 ∨ y=b-2)) → ∃t,W t ∧ Contains t x y := by
    intro x y query
    obtain ⟨t,ht,hit⟩ := T.cover (x+p) (y+1) (by unfold HalfPlane; omega)
    have above := low_tile_above_floor (by omega) (by omega) (by omega)
      (by omega : 1≤x+p ∧ x+p≤2*a) (by omega : 1≤y+1 ∧ y+1≤b)
      T h0 h1 h2 h3 ht hit
    refine ⟨shift (-p) (-1) t,⟨⟨t,ht,rfl⟩,?_⟩,?_⟩
    · dsimp [shift]; omega
    · apply (contains_shift _ _ _ _ _).2
      have xx : x - -p = x+p := by omega
      have yy : y - -1 = y+1 := by omega
      simpa only [xx,yy] using hit
  have initial : W ⟨0,b,a,0,0,b⟩ := by
    refine ⟨⟨_,anchor,?_⟩,by dsimp; omega⟩
    apply same_eq; dsimp [Same,shift]; omega
  exact local_short_tip_node000 a b (by omega) hb hab ha W copy
    (fun _ ht => ht.2) coverage separate initial

#print axioms no_right_short_starter

theorem no_left_short_starter {a b p : Int} (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (hp : 2≤p ∧ p≤2*a) (T : Tiling a b 0 0 HalfPlane)
    (h0 : T.world ⟨-1,0,0,b,a,0⟩) (h1 : T.world ⟨0,0,a,b,0,0⟩)
    (h2 : T.world ⟨2*a+1,0,0,b,a,0⟩) (h3 : T.world ⟨2*a+2,0,a,b,0,0⟩)
    (anchor : T.world ⟨p,b+1,0,0,a,b⟩) : False := by
  let U : Tiling a b 0 0 HalfPlane :=
    (T.mirrorX.translate (2*a+1) 0).congr (by intro x y; simp only [HalfPlane,Int.sub_zero])
  have member (t : Cross) (ht : T.world t) :
      U.world ⟨2*a+1-t.x,t.y,t.west,t.north,t.east,t.south⟩ := by
    refine ⟨mirrorX t,⟨t,ht,rfl⟩,?_⟩
    apply same_eq; dsimp [Same,shift,mirrorX]; omega
  apply no_right_short_starter ha hb hab (p:=2*a+1-p) (by omega) U
  · have h := member _ h3
    have e : 2*a+1-(2*a+2) = -1 := by omega
    simpa only [e] using h
  · have h := member _ h2
    have e : 2*a+1-(2*a+1) = 0 := by omega
    simpa only [e] using h
  · have h := member _ h1
    have e : 2*a+1-0 = 2*a+1 := by omega
    simpa only [e] using h
  · have h := member _ h0
    have e : 2*a+1-(-1) = 2*a+2 := by omega
    simpa only [e] using h
  · exact member _ anchor

#print axioms no_left_short_starter

theorem no_right_long_starter {a b p : Int} (ha : 5≤a) (hb : 4≤b) (hab : b<a)
    (hp : 1≤p ∧ p≤2*a-4) (T : Tiling a b 0 0 HalfPlane)
    (h0 : T.world ⟨-1,0,0,b,a,0⟩) (h1 : T.world ⟨0,0,a,b,0,0⟩)
    (h2 : T.world ⟨2*a+1,0,0,b,a,0⟩) (h3 : T.world ⟨2*a+2,0,a,b,0,0⟩)
    (anchor : T.world ⟨p,a+1,b,0,0,a⟩) : False := by
  let V := T.translate (-p) (-1)
  let W : Cross → Prop := fun t =>
    V.world t ∧ 0≤t.y-t.south ∧ ¬LRegion.ForbiddenShortTip a b t
  have copy : ∀t,W t→Copy a b 0 0 t := fun t ht => V.copies t ht.1
  have separate : ∀t u,W t→W u→t=u ∨ Apart t u := by
    intro t u ht hu
    by_cases eq : t=u
    · exact Or.inl eq
    · right
      apply TPlane.apart_of_no_common_nonnegative t u
        (TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copy t ht))
        (TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copy u hu))
      intro x y h h'
      exact eq (V.disjoint t u x y ht.1 hu.1 h h')
  have coverage : ∀x y,(1≤x ∧ x≤3 ∧ ((0≤y ∧ y≤3) ∨ y=b+1 ∨ y=b+2)) →
      ∃t,W t ∧ Contains t x y := by
    intro x y query
    obtain ⟨t,ht,hit⟩ := T.cover (x+p) (y+1) (by unfold HalfPlane; omega)
    have above := gap_tile_above_floor (by omega) (by omega) (by omega)
      (by omega : 1≤x+p ∧ x+p≤2*a) (by omega : 1≤y+1) T h0 h1 h2 h3 ht hit
    refine ⟨shift (-p) (-1) t,⟨⟨t,ht,rfl⟩,?_,?_⟩,?_⟩
    · dsimp [shift]; omega
    · intro forbidden
      rcases t with ⟨tx,ty,e,n,w,s⟩
      rcases forbidden with ⟨jy,hn,hs,arms⟩
      dsimp only [shift] at jy hn hs arms
      have ty' : ty=b+1 := by omega
      subst ty; subst n; subst s
      rcases arms with ⟨he,hw⟩ | ⟨he,hw⟩
      · subst e; subst w
        have center : tx=x+p := by unfold Contains at hit; dsimp only at hit; omega
        exact no_right_short_starter ha (by omega) hab (by omega) T h0 h1 h2 h3 ht
      · subst e; subst w
        have center : tx=x+p := by unfold Contains at hit; dsimp only at hit; omega
        exact no_left_short_starter ha (by omega) hab (by omega) T h0 h1 h2 h3 ht
    · apply (contains_shift _ _ _ _ _).2
      have xx : x - -p = x+p := by omega
      have yy : y - -1 = y+1 := by omega
      simpa only [xx,yy] using hit
  have initial : W ⟨0,a,b,0,0,a⟩ := by
    refine ⟨⟨_,anchor,?_⟩,by dsimp; omega,?_⟩
    · apply same_eq; dsimp [Same,shift]; omega
    · intro bad; have h := bad.1; dsimp at h; omega
  exact local_long_tip_node000 a b (by omega) (by omega) hab ha W copy
    (fun _ ht => ht.2.1) coverage separate (fun _ ht => ht.2.2) initial

#print axioms no_right_long_starter

def EarlyHorizontal {a b : Int} (T : Tiling a b 0 0 HalfPlane) : Prop :=
  ∃q l r,(l=a ∨ l=b) ∧ (r=0 ∨ r=l) ∧ 1≤q ∧ q≤3 ∧ q+l≤2*a ∧
    T.world ⟨q+r,1,l-r,a+b-l,r,0⟩

theorem early_horizontal {a b : Int} (ha : 5≤a) (hb : 4≤b) (hab : b<a)
    (T : Tiling a b 0 0 HalfPlane)
    (h0 : T.world ⟨-1,0,0,b,a,0⟩) (h1 : T.world ⟨0,0,a,b,0,0⟩)
    (h2 : T.world ⟨2*a+1,0,0,b,a,0⟩) (h3 : T.world ⟨2*a+2,0,a,b,0,0⟩) :
    EarlyHorizontal T := by
  have closed := base_closed T h0 h1 h2 h3
  have choose : ∀p,2≤p → p≤3 → EarlyHorizontal T ∨ T.world ⟨p,a+1,0,0,b,a⟩ := by
    intro p hp0 hp1
    obtain ⟨t,ht,hit⟩ := T.cover p 1 (by unfold HalfPlane; omega)
    have empty : ¬Base a b p 1 := by dsimp [Base,Contains]; omega
    have avoid : ∀{x y},Base a b x y → ¬Contains t x y :=
      fun h => avoid_closed closed ht hit empty h
    have form := LHalfPlaneLocal.run_forms (L:=1) (R:=2*a) (by omega) (by omega)
      (by omega) (by omega) (T.copies t ht) hit
      (avoid (by dsimp [Base,Contains]; omega))
      (avoid (by dsimp [Base,Contains]; omega))
      (avoid (by dsimp [Base,Contains]; omega))
      (by intro h h'; apply avoid; dsimp [Base,Contains]; omega)
    rcases form with ⟨q,l,r,hl,hr,eq,hq0,hq1,hq2,hq3⟩ | st
    · left
      refine ⟨q,l,r,hl,hr,hq0,by omega,hq3,?_⟩
      simpa only [eq] using ht
    · rcases st with (eq | eq) | (eq | eq)
      · subst t
        exact False.elim (no_right_long_starter (p:=p) ha hb hab (by omega) T h0 h1 h2 h3
          (by simpa only [Int.add_comm] using ht))
      · right
        simpa only [eq,Int.add_comm] using ht
      · subst t
        exact False.elim (no_right_short_starter (p:=p) ha (by omega) hab (by omega) T h0 h1 h2 h3
          (by simpa only [Int.add_comm] using ht))
      · subst t
        exact False.elim (no_left_short_starter (p:=p) ha (by omega) hab (by omega) T h0 h1 h2 h3
          (by simpa only [Int.add_comm] using ht))
  rcases choose 2 (by omega) (by omega) with result | left2
  · exact result
  rcases choose 3 (by omega) (by omega) with result | left3
  · exact result
  have eq := T.disjoint _ _ 2 (a+1) left2 left3
    (by left; dsimp; omega) (by left; dsimp; omega)
  have contradiction := congrArg Cross.x eq
  dsimp only at contradiction
  omega

#print axioms early_horizontal

/-- The reflected long-tip obstruction covers the other interior direction. -/
theorem no_left_long_starter {a b p : Int} (ha : 5≤a) (hb : 4≤b) (hab : b<a)
    (hp : 5≤p ∧ p≤2*a) (T : Tiling a b 0 0 HalfPlane)
    (h0 : T.world ⟨-1,0,0,b,a,0⟩) (h1 : T.world ⟨0,0,a,b,0,0⟩)
    (h2 : T.world ⟨2*a+1,0,0,b,a,0⟩) (h3 : T.world ⟨2*a+2,0,a,b,0,0⟩)
    (anchor : T.world ⟨p,a+1,0,0,b,a⟩) : False := by
  let U : Tiling a b 0 0 HalfPlane :=
    (T.mirrorX.translate (2*a+1) 0).congr (by intro x y; simp only [HalfPlane,Int.sub_zero])
  have member (t : Cross) (ht : T.world t) :
      U.world ⟨2*a+1-t.x,t.y,t.west,t.north,t.east,t.south⟩ := by
    refine ⟨mirrorX t,⟨t,ht,rfl⟩,?_⟩
    apply same_eq; dsimp [Same,shift,mirrorX]; omega
  apply no_right_long_starter ha hb hab (p:=2*a+1-p) (by omega) U
  · have h := member _ h3
    have e : 2*a+1-(2*a+2) = -1 := by omega
    simpa only [e] using h
  · have h := member _ h2
    have e : 2*a+1-(2*a+1) = 0 := by omega
    simpa only [e] using h
  · have h := member _ h1
    have e : 2*a+1-0 = 2*a+1 := by omega
    simpa only [e] using h
  · have h := member _ h0
    have e : 2*a+1-(-1) = 2*a+2 := by omega
    simpa only [e] using h
  · exact member _ anchor

#print axioms no_left_long_starter

/-- Consecutive upward short bars cannot have the same orientation: the
next row is a length-b run trapped between two walls of height a>b. -/
theorem no_same_short_bars {a b p h : Int} (hb : 3≤b) (hab : b<a)
    (T : Tiling a b 0 0 HalfPlane)
    (left : T.world ⟨p,h,b,a,0,0⟩)
    (right : T.world ⟨p+b+1,h,b,a,0,0⟩) : False := by
  let B : Region := fun x y => Contains ⟨p,h,b,a,0,0⟩ x y ∨
    Contains ⟨p+b+1,h,b,a,0,0⟩ x y
  have hnonneg : 0≤h := T.inside _ left p h (by left; dsimp; omega)
  apply LHalfPlaneLocal.blocked_short_tall_run (L:=p+1) (R:=p+b) (h:=h+1)
    (by omega) (by omega) (by omega) (by omega) T B (pair_closed T left right)
  · intro x hx0 hx1; unfold HalfPlane; omega
  · intro x hx0 hx1; dsimp [B,Contains]; omega
  · intro x hx0 hx1; dsimp [B,Contains]; omega
  · dsimp [B,Contains]; omega
  · dsimp [B,Contains]; omega
  · dsimp [B,Contains]; omega
  · dsimp [B,Contains]; omega

#print axioms no_same_short_bars

/-- A left-pointing long tip close to the left wall traps cell (2,1). -/
theorem no_near_left_long_starter {a b p : Int} (ha : 5≤a) (hb : 4≤b) (hab : b<a)
    (hp : 3≤p ∧ p≤b+1) (T : Tiling a b 0 0 HalfPlane)
    (h0 : T.world ⟨-1,0,0,b,a,0⟩) (h1 : T.world ⟨0,0,a,b,0,0⟩)
    (h2 : T.world ⟨2*a+1,0,0,b,a,0⟩) (h3 : T.world ⟨2*a+2,0,a,b,0,0⟩)
    (anchor : T.world ⟨p,a+1,0,0,b,a⟩) : False := by
  let B : Region := fun x y => Base a b x y ∨ Contains ⟨p,a+1,0,0,b,a⟩ x y
  have closed : CornerCertificate.TileClosed T.world B :=
    union_closed (base_closed T h0 h1 h2 h3) (single_closed T anchor)
  obtain ⟨t,ht,hit⟩ := T.cover 2 1 (by unfold HalfPlane; omega)
  have empty : ¬B 2 1 := by dsimp [B,Base,Contains]; omega
  have avoid : ∀{x y},B x y → ¬Contains t x y :=
    fun blocked => avoid_closed closed ht hit empty blocked
  have form := LHalfPlaneLocal.run_forms (L:=1) (R:=p-1)
    (by omega) (by omega) (by omega) (by omega) (T.copies t ht) hit
    (avoid (by dsimp [B,Base,Contains]; omega))
    (avoid (by dsimp [B,Base,Contains]; omega))
    (avoid (by dsimp [B,Base,Contains]; omega))
    (by intro hx0 hx1; apply avoid; dsimp [B,Base,Contains]; omega)
  rcases form with ⟨q,l,r,hl,hr,eq,hq0,hq1,hq2,hq3⟩ | (eq|eq) | (eq|eq)
  · omega
  · have no := avoid (x:=2) (y:=a+1) (by dsimp [B,Base,Contains]; omega)
    apply no; rw [eq]; dsimp [Contains]; omega
  · have no := avoid (x:=2) (y:=a+1) (by dsimp [B,Base,Contains]; omega)
    apply no; rw [eq]; dsimp [Contains]; omega
  · subst t
    exact no_right_short_starter (p:=2) ha (by omega) hab (by omega) T h0 h1 h2 h3
      (by simpa only [Int.add_comm] using ht)
  · subst t
    exact no_left_short_starter (p:=2) ha (by omega) hab (by omega) T h0 h1 h2 h3
      (by simpa only [Int.add_comm] using ht)

theorem no_left_long_starter_extended {a b p : Int} (ha : 5≤a) (hb : 4≤b) (hab : b<a)
    (hp : 3≤p ∧ p≤2*a) (T : Tiling a b 0 0 HalfPlane)
    (h0 : T.world ⟨-1,0,0,b,a,0⟩) (h1 : T.world ⟨0,0,a,b,0,0⟩)
    (h2 : T.world ⟨2*a+1,0,0,b,a,0⟩) (h3 : T.world ⟨2*a+2,0,a,b,0,0⟩)
    (anchor : T.world ⟨p,a+1,0,0,b,a⟩) : False := by
  by_cases h : 5≤p
  · exact no_left_long_starter ha hb hab ⟨h,hp.2⟩ T h0 h1 h2 h3 anchor
  · exact no_near_left_long_starter ha hb hab (by omega) T h0 h1 h2 h3 anchor

#print axioms no_left_long_starter_extended

/-- Both endpoint configurations are excluded by the independent long-boundary
corner obstruction; hence every short tip starting in the pocket is forbidden. -/
theorem no_short_starter {a b p : Int} (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (hp : 1≤p ∧ p≤2*a) (T : Tiling a b 0 0 HalfPlane)
    (h0 : T.world ⟨-1,0,0,b,a,0⟩) (h1 : T.world ⟨0,0,a,b,0,0⟩)
    (h2 : T.world ⟨2*a+1,0,0,b,a,0⟩) (h3 : T.world ⟨2*a+2,0,a,b,0,0⟩)
    {t : Cross} (ht : T.world t) (st : LHalfPlaneLocal.Tip a b p 1 t) : False := by
  rcases st with eq | eq
  · subst t
    by_cases last : p=2*a
    · subst p
      apply LRegion.long_corner_left_impossible a b (2*a+1) ha hb hab T h2
      simpa only [show 2*a+1-1=2*a by omega,show 1+b=b+1 by omega] using ht
    · exact no_right_short_starter (p:=p) ha hb hab (by omega) T h0 h1 h2 h3
        (by simpa only [Int.add_comm] using ht)
  · subst t
    by_cases first : p=1
    · subst p
      apply LRegion.long_corner_right_impossible a b 0 ha hb hab T h1
      simpa only [Int.zero_add,Int.add_comm] using ht
    · exact no_left_short_starter (p:=p) ha hb hab (by omega) T h0 h1 h2 h3
        (by simpa only [Int.add_comm] using ht)

/-- Cell (1,1) now also excludes the long tip at x=2. -/
theorem no_near_left_long_starter_strong {a b p : Int} (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (hp : 2≤p ∧ p≤b+1) (T : Tiling a b 0 0 HalfPlane)
    (h0 : T.world ⟨-1,0,0,b,a,0⟩) (h1 : T.world ⟨0,0,a,b,0,0⟩)
    (h2 : T.world ⟨2*a+1,0,0,b,a,0⟩) (h3 : T.world ⟨2*a+2,0,a,b,0,0⟩)
    (anchor : T.world ⟨p,a+1,0,0,b,a⟩) : False := by
  let B : Region := fun x y => Base a b x y ∨ Contains ⟨p,a+1,0,0,b,a⟩ x y
  have closed : CornerCertificate.TileClosed T.world B :=
    union_closed (base_closed T h0 h1 h2 h3) (single_closed T anchor)
  obtain ⟨t,ht,hit⟩ := T.cover 1 1 (by unfold HalfPlane; omega)
  have empty : ¬B 1 1 := by dsimp [B,Base,Contains]; omega
  have avoid : ∀{x y},B x y → ¬Contains t x y :=
    fun blocked => avoid_closed closed ht hit empty blocked
  have form := LHalfPlaneLocal.run_forms (L:=1) (R:=p-1)
    (by omega) (by omega) (by omega) (by omega) (T.copies t ht) hit
    (avoid (by dsimp [B,Base,Contains]; omega))
    (avoid (by dsimp [B,Base,Contains]; omega))
    (avoid (by dsimp [B,Base,Contains]; omega))
    (by intro hx0 hx1; apply avoid; dsimp [B,Base,Contains]; omega)
  rcases form with ⟨q,l,r,hl,hr,eq,hq0,hq1,hq2,hq3⟩ | (eq|eq) | st
  · omega
  · have no := avoid (x:=1) (y:=a+1) (by dsimp [B,Base,Contains]; omega)
    apply no; rw [eq]; dsimp [Contains]; omega
  · have no := avoid (x:=1) (y:=a+1) (by dsimp [B,Base,Contains]; omega)
    apply no; rw [eq]; dsimp [Contains]; omega
  · exact no_short_starter ha hb hab (by omega) T h0 h1 h2 h3 ht st

#print axioms no_short_starter
#print axioms no_near_left_long_starter_strong
end PolyominoFormal.LHalfPlaneAlternating

import LQuadrantHpUnequalTipShortGeometry
namespace PolyominoFormal.LHalfPlaneAlternating
open CrossUnits LRegion
set_option linter.unusedVariables false
theorem local_short_tip_node001 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_unequal_tip_short_Inside t)
    (cover : ∀ x y, (x=1 ∧ (y=b-1 ∨ y=b-2)) → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) b a (0 : Int) (0 : Int) b))
    (ht1 : world (Cross.mk ((1 : Int) + a) ((-1 : Int) + b) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) b a (0 : Int) (0 : Int) b) (Cross.mk ((1 : Int) + a) ((-1 : Int) + b) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) b a (0 : Int) (0 : Int) b) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) ((-1 : Int) + b) (0 : Int) b a (0 : Int)) ht1
  have support : HP_unequal_tip_short_Box a b (1 : Int) ((-2 : Int) + b) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_unequal_tip_short_n001_point a b (hlong) (hb) ((by simpa only [HP_unequal_tip_short_Box,HP_unequal_tip_short_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) b a (0 : Int) (0 : Int) b) (1 : Int) ((-2 : Int) + b) ∨ Contains (Cross.mk ((1 : Int) + a) ((-1 : Int) + b) (0 : Int) b a (0 : Int)) (1 : Int) ((-2 : Int) + b)) := by
    intro occupied
    exact LRegionArithmetic.HP_unequal_tip_short_n001_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (1 : Int) ((-2 : Int) + b) (by omega)
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) b a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (0 : Int) b a (0 : Int) (0 : Int) b) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) ((-1 : Int) + b) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) ((-1 : Int) + b) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_unequal_tip_short_n001_o0 a b jx jy (insideT) (hit) (hlong) (sep1).2.2.1 (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_unequal_tip_short_n001_o1 a b jx jy (insideT) (hit) (hstrict) (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_unequal_tip_short_n001_o2 a b jx jy (hlong) (insideT) (hit) (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_unequal_tip_short_n001_o3 a b jx jy (hit) (sep1).2.2.1 (insideT) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_unequal_tip_short_n001_o4 a b jx jy (hit) (insideT) (hstrict) (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_unequal_tip_short_n001_o5 a b jx jy (hlong) (sep1).2.2.1 (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_unequal_tip_short_n001_o6 a b jx jy (hit) (sep0).2.1 (hstrict) (insideT) (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_unequal_tip_short_n001_o7 a b jx jy (insideT) (hlong) (sep1).2.1 (hit)

theorem local_short_tip_node000 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_unequal_tip_short_Inside t)
    (cover : ∀ x y, (x=1 ∧ (y=b-1 ∨ y=b-2)) → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) b a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) b a (0 : Int) (0 : Int) b) ht0
  have support : HP_unequal_tip_short_Box a b (1 : Int) ((-1 : Int) + b) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_unequal_tip_short_n000_point a b (hlong) (hb) ((by simpa only [HP_unequal_tip_short_Box,HP_unequal_tip_short_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) b a (0 : Int) (0 : Int) b) (1 : Int) ((-1 : Int) + b)) := by
    intro occupied
    exact LRegionArithmetic.HP_unequal_tip_short_n000_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (1 : Int) ((-1 : Int) + b) (by omega)
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) b a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (0 : Int) b a (0 : Int) (0 : Int) b) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty hit)
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_unequal_tip_short_n000_o0 a b jx jy (hlong) (insideT) (hit) (sep0).2.2.1 (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_unequal_tip_short_n000_o1 a b jx jy (insideT) (hstrict) (hit) (sep0).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_unequal_tip_short_n000_o2 a b jx jy (hlong) (insideT) (hit) (sep0).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_unequal_tip_short_n000_o3 a b jx jy (hstrict) (insideT) (sep0).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_unequal_tip_short_n000_o4 a b jx jy (insideT) (hit) (hstrict) (sep0).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + a) ((-1 : Int) + b) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_unequal_tip_short_n000_o5 a b jx jy (hlong) (sep0).2.1 (insideT) ((by simpa only [Same,eq_comm] using absent)) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0
    exact local_short_tip_node001 a b ha hb hstrict hlong world copies inside cover separate ht0 ht (apart_sym sep0)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_unequal_tip_short_n000_o6 a b jx jy (hstrict) (insideT) (sep0).2.2.1 (sep0).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_unequal_tip_short_n000_o7 a b jx jy (hlong) (insideT) (hit) (sep0).2.2.1


#print axioms local_short_tip_node000
end PolyominoFormal.LHalfPlaneAlternating

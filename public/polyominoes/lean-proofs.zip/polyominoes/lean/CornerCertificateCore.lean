import CrossUnitsGeometry

/- Shared semantic interface for finite clean-corner proofs. -/
namespace CornerCertificate

open CrossUnits

inductive Kind where
  | alpha | beta | gamma | betaTranspose | gammaTranspose
  deriving DecidableEq, Repr

def wallHeight : Kind → Int
  | .alpha => 4
  | .beta | .gamma => 5
  | .betaTranspose | .gammaTranspose => 6

def wallWidth : Kind → Int
  | .alpha => 4
  | .beta | .gamma => 6
  | .betaTranspose | .gammaTranspose => 5

def potential : Kind → Int
  | .alpha | .gammaTranspose => 0
  | .beta | .gamma => 2
  | .betaTranspose => 1

def zeroRank : Kind → Int
  | .alpha | .gammaTranspose => 0
  | .beta | .betaTranspose => 1
  | .gamma => 2

def Wall (k : Kind) (x y : Int) : Prop :=
  (x = -1 ∧ 0 ≤ y ∧ y < wallHeight k) ∨
  (y = -1 ∧ 0 ≤ x ∧ x < wallWidth k)

def Extra : Kind → Int → Int → Prop
  | .alpha, _, _ => False
  | .beta, x, y | .betaTranspose, x, y => x = 0 ∧ y = 0
  | .gamma, x, y => (x = 0 ∨ x = 1) ∧ y = 0
  | .gammaTranspose, x, y => x = 0 ∧ (y = 0 ∨ y = 1)

/-- B retains all old blocked cells, including those outside the future
quadrant. Only its restriction to that quadrant has a finite prescribed form. -/
def Clean (k : Kind) (ox oy : Int) (B : Int → Int → Prop) : Prop :=
  (∀ x y, Wall k x y → B (ox+x) (oy+y)) ∧
  (∀ x y, 0 ≤ x → 0 ≤ y → (B (ox+x) (oy+y) ↔ Extra k x y))

def TileClosed (world : Cross → Prop) (B : Int → Int → Prop) : Prop :=
  ∀ t, world t → ∀ x y, Contains t x y → B x y →
    ∀ u v, Contains t u v → B u v

def Below (h : Int) (B : Int → Int → Prop) : Prop :=
  ∀ x y, B x y → y < h

def DisjointWorld (world : Cross → Prop) : Prop :=
  ∀ t u x y, world t → world u → Contains t x y → Contains u x y → t = u

def QueryWindow (h x y : Int) : Prop :=
  0 ≤ x ∧ x ≤ 7 ∧ 0 ≤ y ∧ y < h

def CoversWindow (world : Cross → Prop) (h : Int) : Prop :=
  ∀ x y, QueryWindow h x y → ∃ t, world t ∧ Contains t x y

def SelectedBelow (world : Cross → Prop) (h : Int) : Prop :=
  ∀ t, world t → (∃ x y, QueryWindow h x y ∧ Contains t x y) →
    ∀ u v, Contains t u v → v < h

def EnlargesByTiles (world : Cross → Prop)
    (B B' : Int → Int → Prop) : Prop :=
  ∃ added : List Cross, (∀ t, t ∈ added → world t) ∧
    ∀ x y, B' x y ↔ B x y ∨ ∃ t, t ∈ added ∧ Contains t x y

def Progress (old new : Kind) (dx dy : Int) : Prop :=
  0 ≤ dx ∧ 0 ≤ dy ∧ 0 < dx+dy ∧
  (old = .alpha → 0 < dx ∧ 0 < dy) ∧
  dx - 4*dy ≤ potential old - potential new ∧
  (dy = 0 → zeroRank new < zeroRank old)

def Transition (world : Cross → Prop) (h : Int) (old : Kind)
    (B : Int → Int → Prop) : Prop :=
  ∃ (B' : Int → Int → Prop) (new : Kind) (dx dy : Int),
    EnlargesByTiles world B B' ∧ TileClosed world B' ∧ Below h B' ∧
    Clean new dx dy B' ∧ Progress old new dx dy

theorem kind_bounds (k : Kind) :
    4 ≤ wallHeight k ∧ 0 ≤ potential k ∧
    0 ≤ zeroRank k ∧ zeroRank k ≤ 2 := by
  cases k <;> decide

theorem clean_origin_below {k : Kind} {ox oy h : Int} {B : Int → Int → Prop}
    (clean : Clean k ox oy B) (bounded : Below h B) : oy < h := by
  have wall : Wall k (-1) 0 := by
    left
    exact ⟨rfl, by omega, by have := (kind_bounds k).1; omega⟩
  have := bounded (ox + -1) (oy + 0) (clean.1 (-1) 0 wall)
  omega

theorem progress_rank_decreases {old new : Kind} {dx dy : Int}
    (p : Progress old new dx dy) :
    zeroRank new - 3*dy < zeroRank old := by
  have r1 := kind_bounds old
  have r2 := kind_bounds new
  rcases p with ⟨hx,hy,hs,ha,hp,hr⟩
  by_cases hz : dy = 0
  · have := hr hz
    omega
  · omega

end CornerCertificate

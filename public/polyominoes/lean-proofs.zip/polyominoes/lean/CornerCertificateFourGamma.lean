import CornerCertificateFourGammaData

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

namespace CornerCertificate
open CrossUnits


section FourGamma
variable (world : Cross → Prop) (h : Int)
    (copies : ∀ t, world t → Copy 4 1 1 0 t)
    (separate : DisjointWorld world) (cover : CoversWindow world h)
    (ceiling : SelectedBelow world h)

theorem four_gamma_node0001 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0001 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma four_gamma_occ0001 .betaTranspose (1 : Int) (0 : Int) four_gamma_check0001 B state
theorem four_gamma_node0006 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0006 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma four_gamma_occ0006 .gamma (4 : Int) (1 : Int) four_gamma_check0006 B state
theorem four_gamma_node0007 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0007 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma four_gamma_occ0007 .beta (4 : Int) (1 : Int) four_gamma_check0007 B state
include copies separate cover ceiling in
theorem four_gamma_node0010 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0010 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0010 ((6 : Int),(1 : Int)) four_gamma_branches0010 copies separate cover ceiling four_gamma_check0010 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0010, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0011 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0011 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0011 ((6 : Int),(1 : Int)) four_gamma_branches0011 copies separate cover ceiling four_gamma_check0011 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0011, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0009 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0009 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0009 ((5 : Int),(1 : Int)) four_gamma_branches0009 copies separate cover ceiling four_gamma_check0009 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0009, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0010 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0011 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0012 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0012 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0012 ((5 : Int),(1 : Int)) four_gamma_branches0012 copies separate cover ceiling four_gamma_check0012 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0012, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0013 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0013 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0013 ((5 : Int),(1 : Int)) four_gamma_branches0013 copies separate cover ceiling four_gamma_check0013 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0013, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0018 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0018 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0018 ((7 : Int),(1 : Int)) four_gamma_branches0018 copies separate cover ceiling four_gamma_check0018 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0018, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0019 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0019 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0019 ((7 : Int),(1 : Int)) four_gamma_branches0019 copies separate cover ceiling four_gamma_check0019 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0019, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0017 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0017 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0017 ((2 : Int),(6 : Int)) four_gamma_branches0017 copies separate cover ceiling four_gamma_check0017 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0017, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0018 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0019 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0021 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0021 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0021 ((7 : Int),(1 : Int)) four_gamma_branches0021 copies separate cover ceiling four_gamma_check0021 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0021, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0022 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0022 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0022 ((7 : Int),(1 : Int)) four_gamma_branches0022 copies separate cover ceiling four_gamma_check0022 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0022, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0020 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0020 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0020 ((2 : Int),(6 : Int)) four_gamma_branches0020 copies separate cover ceiling four_gamma_check0020 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0020, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0021 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0022 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0024 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0024 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0024 ((7 : Int),(1 : Int)) four_gamma_branches0024 copies separate cover ceiling four_gamma_check0024 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0024, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0025 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0025 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0025 ((7 : Int),(1 : Int)) four_gamma_branches0025 copies separate cover ceiling four_gamma_check0025 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0025, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0023 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0023 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0023 ((2 : Int),(6 : Int)) four_gamma_branches0023 copies separate cover ceiling four_gamma_check0023 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0023, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0024 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0025 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0027 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0027 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0027 ((7 : Int),(1 : Int)) four_gamma_branches0027 copies separate cover ceiling four_gamma_check0027 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0027, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0028 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0028 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0028 ((7 : Int),(1 : Int)) four_gamma_branches0028 copies separate cover ceiling four_gamma_check0028 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0028, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0026 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0026 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0026 ((2 : Int),(6 : Int)) four_gamma_branches0026 copies separate cover ceiling four_gamma_check0026 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0026, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0027 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0028 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0030 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0030 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0030 ((7 : Int),(1 : Int)) four_gamma_branches0030 copies separate cover ceiling four_gamma_check0030 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0030, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0031 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0031 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0031 ((7 : Int),(1 : Int)) four_gamma_branches0031 copies separate cover ceiling four_gamma_check0031 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0031, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0029 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0029 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0029 ((2 : Int),(6 : Int)) four_gamma_branches0029 copies separate cover ceiling four_gamma_check0029 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0029, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0030 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0031 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0033 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0033 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0033 ((7 : Int),(1 : Int)) four_gamma_branches0033 copies separate cover ceiling four_gamma_check0033 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0033, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0034 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0034 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0034 ((7 : Int),(1 : Int)) four_gamma_branches0034 copies separate cover ceiling four_gamma_check0034 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0034, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0032 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0032 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0032 ((2 : Int),(6 : Int)) four_gamma_branches0032 copies separate cover ceiling four_gamma_check0032 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0032, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0033 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0034 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0036 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0036 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0036 ((7 : Int),(1 : Int)) four_gamma_branches0036 copies separate cover ceiling four_gamma_check0036 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0036, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0037 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0037 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0037 ((7 : Int),(1 : Int)) four_gamma_branches0037 copies separate cover ceiling four_gamma_check0037 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0037, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0035 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0035 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0035 ((2 : Int),(6 : Int)) four_gamma_branches0035 copies separate cover ceiling four_gamma_check0035 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0035, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0036 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0037 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0038 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0038 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0038 ((2 : Int),(6 : Int)) four_gamma_branches0038 copies separate cover ceiling four_gamma_check0038 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0038, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0040 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0040 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0040 ((7 : Int),(1 : Int)) four_gamma_branches0040 copies separate cover ceiling four_gamma_check0040 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0040, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0041 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0041 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0041 ((7 : Int),(1 : Int)) four_gamma_branches0041 copies separate cover ceiling four_gamma_check0041 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0041, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0039 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0039 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0039 ((2 : Int),(6 : Int)) four_gamma_branches0039 copies separate cover ceiling four_gamma_check0039 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0039, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0040 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0041 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0043 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0043 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0043 ((7 : Int),(1 : Int)) four_gamma_branches0043 copies separate cover ceiling four_gamma_check0043 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0043, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0044 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0044 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0044 ((7 : Int),(1 : Int)) four_gamma_branches0044 copies separate cover ceiling four_gamma_check0044 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0044, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0042 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0042 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0042 ((2 : Int),(6 : Int)) four_gamma_branches0042 copies separate cover ceiling four_gamma_check0042 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0042, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0043 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0044 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0046 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0046 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0046 ((7 : Int),(1 : Int)) four_gamma_branches0046 copies separate cover ceiling four_gamma_check0046 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0046, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0047 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0047 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0047 ((7 : Int),(1 : Int)) four_gamma_branches0047 copies separate cover ceiling four_gamma_check0047 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0047, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0045 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0045 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0045 ((2 : Int),(6 : Int)) four_gamma_branches0045 copies separate cover ceiling four_gamma_check0045 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0045, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0046 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0047 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0016 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0016 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0016 ((0 : Int),(8 : Int)) four_gamma_branches0016 copies separate cover ceiling four_gamma_check0016 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0016, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0017 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0020 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0023 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0026 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0029 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0032 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0035 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0038 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0039 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0042 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0045 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0050 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0050 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0050 ((7 : Int),(1 : Int)) four_gamma_branches0050 copies separate cover ceiling four_gamma_check0050 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0050, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0051 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0051 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0051 ((7 : Int),(1 : Int)) four_gamma_branches0051 copies separate cover ceiling four_gamma_check0051 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0051, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0049 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0049 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0049 ((2 : Int),(6 : Int)) four_gamma_branches0049 copies separate cover ceiling four_gamma_check0049 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0049, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0050 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0051 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0053 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0053 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0053 ((7 : Int),(1 : Int)) four_gamma_branches0053 copies separate cover ceiling four_gamma_check0053 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0053, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0054 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0054 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0054 ((7 : Int),(1 : Int)) four_gamma_branches0054 copies separate cover ceiling four_gamma_check0054 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0054, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0052 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0052 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0052 ((2 : Int),(6 : Int)) four_gamma_branches0052 copies separate cover ceiling four_gamma_check0052 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0052, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0053 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0054 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0056 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0056 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0056 ((7 : Int),(1 : Int)) four_gamma_branches0056 copies separate cover ceiling four_gamma_check0056 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0056, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0057 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0057 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0057 ((7 : Int),(1 : Int)) four_gamma_branches0057 copies separate cover ceiling four_gamma_check0057 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0057, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0055 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0055 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0055 ((2 : Int),(6 : Int)) four_gamma_branches0055 copies separate cover ceiling four_gamma_check0055 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0055, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0056 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0057 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0059 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0059 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0059 ((7 : Int),(1 : Int)) four_gamma_branches0059 copies separate cover ceiling four_gamma_check0059 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0059, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0060 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0060 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0060 ((7 : Int),(1 : Int)) four_gamma_branches0060 copies separate cover ceiling four_gamma_check0060 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0060, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0058 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0058 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0058 ((2 : Int),(6 : Int)) four_gamma_branches0058 copies separate cover ceiling four_gamma_check0058 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0058, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0059 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0060 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0062 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0062 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0062 ((7 : Int),(1 : Int)) four_gamma_branches0062 copies separate cover ceiling four_gamma_check0062 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0062, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0063 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0063 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0063 ((7 : Int),(1 : Int)) four_gamma_branches0063 copies separate cover ceiling four_gamma_check0063 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0063, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0061 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0061 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0061 ((2 : Int),(6 : Int)) four_gamma_branches0061 copies separate cover ceiling four_gamma_check0061 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0061, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0062 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0063 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0065 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0065 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0065 ((7 : Int),(1 : Int)) four_gamma_branches0065 copies separate cover ceiling four_gamma_check0065 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0065, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0066 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0066 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0066 ((7 : Int),(1 : Int)) four_gamma_branches0066 copies separate cover ceiling four_gamma_check0066 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0066, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0064 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0064 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0064 ((2 : Int),(6 : Int)) four_gamma_branches0064 copies separate cover ceiling four_gamma_check0064 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0064, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0065 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0066 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0068 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0068 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0068 ((7 : Int),(1 : Int)) four_gamma_branches0068 copies separate cover ceiling four_gamma_check0068 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0068, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0069 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0069 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0069 ((7 : Int),(1 : Int)) four_gamma_branches0069 copies separate cover ceiling four_gamma_check0069 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0069, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0067 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0067 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0067 ((2 : Int),(6 : Int)) four_gamma_branches0067 copies separate cover ceiling four_gamma_check0067 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0067, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0068 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0069 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0070 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0070 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0070 ((2 : Int),(6 : Int)) four_gamma_branches0070 copies separate cover ceiling four_gamma_check0070 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0070, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0072 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0072 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0072 ((7 : Int),(1 : Int)) four_gamma_branches0072 copies separate cover ceiling four_gamma_check0072 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0072, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0073 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0073 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0073 ((7 : Int),(1 : Int)) four_gamma_branches0073 copies separate cover ceiling four_gamma_check0073 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0073, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0071 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0071 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0071 ((2 : Int),(6 : Int)) four_gamma_branches0071 copies separate cover ceiling four_gamma_check0071 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0071, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0072 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0073 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0075 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0075 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0075 ((7 : Int),(1 : Int)) four_gamma_branches0075 copies separate cover ceiling four_gamma_check0075 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0075, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0076 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0076 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0076 ((7 : Int),(1 : Int)) four_gamma_branches0076 copies separate cover ceiling four_gamma_check0076 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0076, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0074 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0074 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0074 ((2 : Int),(6 : Int)) four_gamma_branches0074 copies separate cover ceiling four_gamma_check0074 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0074, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0075 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0076 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0078 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0078 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0078 ((7 : Int),(1 : Int)) four_gamma_branches0078 copies separate cover ceiling four_gamma_check0078 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0078, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0079 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0079 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0079 ((7 : Int),(1 : Int)) four_gamma_branches0079 copies separate cover ceiling four_gamma_check0079 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0079, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0077 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0077 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0077 ((2 : Int),(6 : Int)) four_gamma_branches0077 copies separate cover ceiling four_gamma_check0077 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0077, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0078 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0079 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0048 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0048 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0048 ((0 : Int),(8 : Int)) four_gamma_branches0048 copies separate cover ceiling four_gamma_check0048 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0048, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0049 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0052 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0055 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0058 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0061 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0064 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0067 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0070 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0071 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0074 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0077 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0015 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0015 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0015 ((6 : Int),(1 : Int)) four_gamma_branches0015 copies separate cover ceiling four_gamma_check0015 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0015, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0016 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0048 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0083 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0083 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0083 ((7 : Int),(1 : Int)) four_gamma_branches0083 copies separate cover ceiling four_gamma_check0083 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0083, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0084 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0084 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0084 ((7 : Int),(1 : Int)) four_gamma_branches0084 copies separate cover ceiling four_gamma_check0084 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0084, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0085 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0085 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0085 ((7 : Int),(1 : Int)) four_gamma_branches0085 copies separate cover ceiling four_gamma_check0085 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0085, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0082 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0082 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0082 ((2 : Int),(6 : Int)) four_gamma_branches0082 copies separate cover ceiling four_gamma_check0082 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0082, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0083 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0084 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0085 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0087 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0087 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0087 ((7 : Int),(1 : Int)) four_gamma_branches0087 copies separate cover ceiling four_gamma_check0087 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0087, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0088 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0088 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0088 ((7 : Int),(1 : Int)) four_gamma_branches0088 copies separate cover ceiling four_gamma_check0088 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0088, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0089 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0089 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0089 ((7 : Int),(1 : Int)) four_gamma_branches0089 copies separate cover ceiling four_gamma_check0089 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0089, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0086 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0086 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0086 ((2 : Int),(6 : Int)) four_gamma_branches0086 copies separate cover ceiling four_gamma_check0086 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0086, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0087 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0088 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0089 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0091 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0091 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0091 ((7 : Int),(1 : Int)) four_gamma_branches0091 copies separate cover ceiling four_gamma_check0091 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0091, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0092 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0092 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0092 ((7 : Int),(1 : Int)) four_gamma_branches0092 copies separate cover ceiling four_gamma_check0092 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0092, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0093 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0093 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0093 ((7 : Int),(1 : Int)) four_gamma_branches0093 copies separate cover ceiling four_gamma_check0093 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0093, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0090 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0090 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0090 ((2 : Int),(6 : Int)) four_gamma_branches0090 copies separate cover ceiling four_gamma_check0090 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0090, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0091 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0092 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0093 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0095 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0095 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0095 ((7 : Int),(1 : Int)) four_gamma_branches0095 copies separate cover ceiling four_gamma_check0095 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0095, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0096 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0096 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0096 ((7 : Int),(1 : Int)) four_gamma_branches0096 copies separate cover ceiling four_gamma_check0096 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0096, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0097 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0097 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0097 ((7 : Int),(1 : Int)) four_gamma_branches0097 copies separate cover ceiling four_gamma_check0097 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0097, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0094 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0094 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0094 ((2 : Int),(6 : Int)) four_gamma_branches0094 copies separate cover ceiling four_gamma_check0094 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0094, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0095 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0096 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0097 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0099 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0099 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0099 ((7 : Int),(1 : Int)) four_gamma_branches0099 copies separate cover ceiling four_gamma_check0099 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0099, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0100 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0100 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0100 ((7 : Int),(1 : Int)) four_gamma_branches0100 copies separate cover ceiling four_gamma_check0100 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0100, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0101 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0101 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0101 ((7 : Int),(1 : Int)) four_gamma_branches0101 copies separate cover ceiling four_gamma_check0101 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0101, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0098 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0098 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0098 ((2 : Int),(6 : Int)) four_gamma_branches0098 copies separate cover ceiling four_gamma_check0098 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0098, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0099 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0100 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0101 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0103 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0103 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0103 ((7 : Int),(1 : Int)) four_gamma_branches0103 copies separate cover ceiling four_gamma_check0103 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0103, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0104 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0104 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0104 ((7 : Int),(1 : Int)) four_gamma_branches0104 copies separate cover ceiling four_gamma_check0104 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0104, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0105 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0105 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0105 ((7 : Int),(1 : Int)) four_gamma_branches0105 copies separate cover ceiling four_gamma_check0105 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0105, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0102 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0102 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0102 ((2 : Int),(6 : Int)) four_gamma_branches0102 copies separate cover ceiling four_gamma_check0102 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0102, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0103 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0104 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0105 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0107 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0107 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0107 ((7 : Int),(1 : Int)) four_gamma_branches0107 copies separate cover ceiling four_gamma_check0107 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0107, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0108 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0108 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0108 ((7 : Int),(1 : Int)) four_gamma_branches0108 copies separate cover ceiling four_gamma_check0108 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0108, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0109 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0109 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0109 ((7 : Int),(1 : Int)) four_gamma_branches0109 copies separate cover ceiling four_gamma_check0109 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0109, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0106 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0106 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0106 ((2 : Int),(6 : Int)) four_gamma_branches0106 copies separate cover ceiling four_gamma_check0106 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0106, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0107 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0108 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0109 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0110 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0110 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0110 ((2 : Int),(6 : Int)) four_gamma_branches0110 copies separate cover ceiling four_gamma_check0110 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0110, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0112 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0112 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0112 ((7 : Int),(1 : Int)) four_gamma_branches0112 copies separate cover ceiling four_gamma_check0112 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0112, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0113 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0113 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0113 ((7 : Int),(1 : Int)) four_gamma_branches0113 copies separate cover ceiling four_gamma_check0113 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0113, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0114 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0114 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0114 ((7 : Int),(1 : Int)) four_gamma_branches0114 copies separate cover ceiling four_gamma_check0114 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0114, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0111 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0111 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0111 ((2 : Int),(6 : Int)) four_gamma_branches0111 copies separate cover ceiling four_gamma_check0111 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0111, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0112 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0113 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0114 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0116 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0116 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0116 ((7 : Int),(1 : Int)) four_gamma_branches0116 copies separate cover ceiling four_gamma_check0116 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0116, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0117 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0117 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0117 ((7 : Int),(1 : Int)) four_gamma_branches0117 copies separate cover ceiling four_gamma_check0117 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0117, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0118 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0118 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0118 ((7 : Int),(1 : Int)) four_gamma_branches0118 copies separate cover ceiling four_gamma_check0118 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0118, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0115 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0115 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0115 ((2 : Int),(6 : Int)) four_gamma_branches0115 copies separate cover ceiling four_gamma_check0115 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0115, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0116 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0117 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0118 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0120 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0120 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0120 ((7 : Int),(1 : Int)) four_gamma_branches0120 copies separate cover ceiling four_gamma_check0120 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0120, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0121 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0121 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0121 ((7 : Int),(1 : Int)) four_gamma_branches0121 copies separate cover ceiling four_gamma_check0121 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0121, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0122 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0122 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0122 ((7 : Int),(1 : Int)) four_gamma_branches0122 copies separate cover ceiling four_gamma_check0122 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0122, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0119 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0119 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0119 ((2 : Int),(6 : Int)) four_gamma_branches0119 copies separate cover ceiling four_gamma_check0119 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0119, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0120 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0121 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0122 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0081 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0081 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0081 ((0 : Int),(8 : Int)) four_gamma_branches0081 copies separate cover ceiling four_gamma_check0081 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0081, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0082 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0086 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0090 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0094 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0098 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0102 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0106 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0110 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0111 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0115 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0119 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0125 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0125 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0125 ((7 : Int),(1 : Int)) four_gamma_branches0125 copies separate cover ceiling four_gamma_check0125 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0125, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0126 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0126 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0126 ((7 : Int),(1 : Int)) four_gamma_branches0126 copies separate cover ceiling four_gamma_check0126 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0126, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0127 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0127 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0127 ((7 : Int),(1 : Int)) four_gamma_branches0127 copies separate cover ceiling four_gamma_check0127 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0127, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0124 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0124 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0124 ((2 : Int),(6 : Int)) four_gamma_branches0124 copies separate cover ceiling four_gamma_check0124 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0124, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0125 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0126 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0127 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0129 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0129 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0129 ((7 : Int),(1 : Int)) four_gamma_branches0129 copies separate cover ceiling four_gamma_check0129 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0129, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0130 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0130 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0130 ((7 : Int),(1 : Int)) four_gamma_branches0130 copies separate cover ceiling four_gamma_check0130 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0130, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0131 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0131 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0131 ((7 : Int),(1 : Int)) four_gamma_branches0131 copies separate cover ceiling four_gamma_check0131 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0131, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0128 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0128 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0128 ((2 : Int),(6 : Int)) four_gamma_branches0128 copies separate cover ceiling four_gamma_check0128 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0128, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0129 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0130 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0131 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0133 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0133 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0133 ((7 : Int),(1 : Int)) four_gamma_branches0133 copies separate cover ceiling four_gamma_check0133 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0133, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0134 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0134 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0134 ((7 : Int),(1 : Int)) four_gamma_branches0134 copies separate cover ceiling four_gamma_check0134 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0134, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0135 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0135 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0135 ((7 : Int),(1 : Int)) four_gamma_branches0135 copies separate cover ceiling four_gamma_check0135 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0135, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0132 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0132 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0132 ((2 : Int),(6 : Int)) four_gamma_branches0132 copies separate cover ceiling four_gamma_check0132 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0132, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0133 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0134 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0135 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0137 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0137 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0137 ((7 : Int),(1 : Int)) four_gamma_branches0137 copies separate cover ceiling four_gamma_check0137 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0137, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0138 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0138 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0138 ((7 : Int),(1 : Int)) four_gamma_branches0138 copies separate cover ceiling four_gamma_check0138 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0138, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0139 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0139 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0139 ((7 : Int),(1 : Int)) four_gamma_branches0139 copies separate cover ceiling four_gamma_check0139 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0139, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0136 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0136 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0136 ((2 : Int),(6 : Int)) four_gamma_branches0136 copies separate cover ceiling four_gamma_check0136 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0136, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0137 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0138 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0139 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0141 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0141 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0141 ((7 : Int),(1 : Int)) four_gamma_branches0141 copies separate cover ceiling four_gamma_check0141 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0141, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0142 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0142 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0142 ((7 : Int),(1 : Int)) four_gamma_branches0142 copies separate cover ceiling four_gamma_check0142 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0142, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0143 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0143 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0143 ((7 : Int),(1 : Int)) four_gamma_branches0143 copies separate cover ceiling four_gamma_check0143 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0143, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0140 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0140 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0140 ((2 : Int),(6 : Int)) four_gamma_branches0140 copies separate cover ceiling four_gamma_check0140 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0140, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0141 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0142 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0143 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0145 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0145 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0145 ((7 : Int),(1 : Int)) four_gamma_branches0145 copies separate cover ceiling four_gamma_check0145 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0145, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0146 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0146 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0146 ((7 : Int),(1 : Int)) four_gamma_branches0146 copies separate cover ceiling four_gamma_check0146 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0146, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0147 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0147 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0147 ((7 : Int),(1 : Int)) four_gamma_branches0147 copies separate cover ceiling four_gamma_check0147 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0147, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0144 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0144 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0144 ((2 : Int),(6 : Int)) four_gamma_branches0144 copies separate cover ceiling four_gamma_check0144 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0144, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0145 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0146 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0147 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0149 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0149 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0149 ((7 : Int),(1 : Int)) four_gamma_branches0149 copies separate cover ceiling four_gamma_check0149 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0149, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0150 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0150 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0150 ((7 : Int),(1 : Int)) four_gamma_branches0150 copies separate cover ceiling four_gamma_check0150 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0150, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0151 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0151 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0151 ((7 : Int),(1 : Int)) four_gamma_branches0151 copies separate cover ceiling four_gamma_check0151 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0151, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0148 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0148 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0148 ((2 : Int),(6 : Int)) four_gamma_branches0148 copies separate cover ceiling four_gamma_check0148 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0148, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0149 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0150 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0151 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0152 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0152 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0152 ((2 : Int),(6 : Int)) four_gamma_branches0152 copies separate cover ceiling four_gamma_check0152 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0152, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0154 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0154 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0154 ((7 : Int),(1 : Int)) four_gamma_branches0154 copies separate cover ceiling four_gamma_check0154 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0154, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0155 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0155 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0155 ((7 : Int),(1 : Int)) four_gamma_branches0155 copies separate cover ceiling four_gamma_check0155 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0155, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0156 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0156 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0156 ((7 : Int),(1 : Int)) four_gamma_branches0156 copies separate cover ceiling four_gamma_check0156 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0156, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0153 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0153 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0153 ((2 : Int),(6 : Int)) four_gamma_branches0153 copies separate cover ceiling four_gamma_check0153 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0153, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0154 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0155 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0156 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0158 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0158 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0158 ((7 : Int),(1 : Int)) four_gamma_branches0158 copies separate cover ceiling four_gamma_check0158 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0158, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0159 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0159 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0159 ((7 : Int),(1 : Int)) four_gamma_branches0159 copies separate cover ceiling four_gamma_check0159 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0159, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0160 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0160 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0160 ((7 : Int),(1 : Int)) four_gamma_branches0160 copies separate cover ceiling four_gamma_check0160 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0160, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0157 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0157 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0157 ((2 : Int),(6 : Int)) four_gamma_branches0157 copies separate cover ceiling four_gamma_check0157 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0157, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0158 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0159 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0160 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0162 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0162 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0162 ((7 : Int),(1 : Int)) four_gamma_branches0162 copies separate cover ceiling four_gamma_check0162 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0162, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0163 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0163 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0163 ((7 : Int),(1 : Int)) four_gamma_branches0163 copies separate cover ceiling four_gamma_check0163 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0163, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0164 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0164 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0164 ((7 : Int),(1 : Int)) four_gamma_branches0164 copies separate cover ceiling four_gamma_check0164 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0164, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0161 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0161 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0161 ((2 : Int),(6 : Int)) four_gamma_branches0161 copies separate cover ceiling four_gamma_check0161 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0161, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0162 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0163 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0164 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0123 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0123 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0123 ((0 : Int),(8 : Int)) four_gamma_branches0123 copies separate cover ceiling four_gamma_check0123 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0123, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0124 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0128 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0132 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0136 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0140 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0144 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0148 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0152 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0153 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0157 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0161 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0080 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0080 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0080 ((6 : Int),(1 : Int)) four_gamma_branches0080 copies separate cover ceiling four_gamma_check0080 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0080, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0081 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0123 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0014 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0014 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0014 ((4 : Int),(3 : Int)) four_gamma_branches0014 copies separate cover ceiling four_gamma_check0014 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0014, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0015 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0080 world h copies separate cover ceiling nextB nextState
theorem four_gamma_node0166 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0166 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma four_gamma_occ0166 .alpha (5 : Int) (3 : Int) four_gamma_check0166 B state
include copies separate cover ceiling in
theorem four_gamma_node0167 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0167 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0167 ((6 : Int),(1 : Int)) four_gamma_branches0167 copies separate cover ceiling four_gamma_check0167 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0167, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0168 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0168 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0168 ((6 : Int),(1 : Int)) four_gamma_branches0168 copies separate cover ceiling four_gamma_check0168 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0168, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0169 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0169 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0169 ((6 : Int),(1 : Int)) four_gamma_branches0169 copies separate cover ceiling four_gamma_check0169 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0169, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0170 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0170 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0170 ((6 : Int),(1 : Int)) four_gamma_branches0170 copies separate cover ceiling four_gamma_check0170 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0170, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0165 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0165 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0165 ((4 : Int),(3 : Int)) four_gamma_branches0165 copies separate cover ceiling four_gamma_check0165 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0165, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0166 world h nextB nextState
  · exact four_gamma_node0167 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0168 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0169 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0170 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0171 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0171 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0171 ((5 : Int),(1 : Int)) four_gamma_branches0171 copies separate cover ceiling four_gamma_check0171 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0171, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0172 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0172 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0172 ((5 : Int),(1 : Int)) four_gamma_branches0172 copies separate cover ceiling four_gamma_check0172 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0172, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0008 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0008 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0008 ((4 : Int),(2 : Int)) four_gamma_branches0008 copies separate cover ceiling four_gamma_check0008 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0008, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0009 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0012 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0013 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0014 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0165 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0171 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0172 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0005 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0005 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0005 ((4 : Int),(0 : Int)) four_gamma_branches0005 copies separate cover ceiling four_gamma_check0005 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0005, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0006 world h nextB nextState
  · exact four_gamma_node0007 world h nextB nextState
  · exact four_gamma_node0008 world h copies separate cover ceiling nextB nextState
theorem four_gamma_node0174 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0174 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma four_gamma_occ0174 .gamma (4 : Int) (1 : Int) four_gamma_check0174 B state
theorem four_gamma_node0175 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0175 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma four_gamma_occ0175 .beta (4 : Int) (1 : Int) four_gamma_check0175 B state
include copies separate cover ceiling in
theorem four_gamma_node0179 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0179 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0179 ((6 : Int),(1 : Int)) four_gamma_branches0179 copies separate cover ceiling four_gamma_check0179 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0179, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0180 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0180 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0180 ((6 : Int),(1 : Int)) four_gamma_branches0180 copies separate cover ceiling four_gamma_check0180 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0180, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0181 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0181 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0181 ((6 : Int),(1 : Int)) four_gamma_branches0181 copies separate cover ceiling four_gamma_check0181 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0181, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0182 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0182 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0182 ((6 : Int),(1 : Int)) four_gamma_branches0182 copies separate cover ceiling four_gamma_check0182 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0182, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0183 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0183 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0183 ((6 : Int),(1 : Int)) four_gamma_branches0183 copies separate cover ceiling four_gamma_check0183 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0183, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0184 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0184 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0184 ((6 : Int),(1 : Int)) four_gamma_branches0184 copies separate cover ceiling four_gamma_check0184 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0184, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0185 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0185 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0185 ((6 : Int),(1 : Int)) four_gamma_branches0185 copies separate cover ceiling four_gamma_check0185 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0185, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0186 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0186 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0186 ((6 : Int),(1 : Int)) four_gamma_branches0186 copies separate cover ceiling four_gamma_check0186 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0186, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0178 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0178 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0178 ((0 : Int),(7 : Int)) four_gamma_branches0178 copies separate cover ceiling four_gamma_check0178 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0178, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0179 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0180 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0181 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0182 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0183 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0184 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0185 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0186 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0188 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0188 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0188 ((6 : Int),(1 : Int)) four_gamma_branches0188 copies separate cover ceiling four_gamma_check0188 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0188, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0189 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0189 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0189 ((6 : Int),(1 : Int)) four_gamma_branches0189 copies separate cover ceiling four_gamma_check0189 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0189, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0190 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0190 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0190 ((6 : Int),(1 : Int)) four_gamma_branches0190 copies separate cover ceiling four_gamma_check0190 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0190, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0191 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0191 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0191 ((6 : Int),(1 : Int)) four_gamma_branches0191 copies separate cover ceiling four_gamma_check0191 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0191, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0192 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0192 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0192 ((6 : Int),(1 : Int)) four_gamma_branches0192 copies separate cover ceiling four_gamma_check0192 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0192, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0193 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0193 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0193 ((6 : Int),(1 : Int)) four_gamma_branches0193 copies separate cover ceiling four_gamma_check0193 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0193, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0194 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0194 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0194 ((6 : Int),(1 : Int)) four_gamma_branches0194 copies separate cover ceiling four_gamma_check0194 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0194, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0195 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0195 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0195 ((6 : Int),(1 : Int)) four_gamma_branches0195 copies separate cover ceiling four_gamma_check0195 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0195, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0187 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0187 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0187 ((0 : Int),(7 : Int)) four_gamma_branches0187 copies separate cover ceiling four_gamma_check0187 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0187, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0188 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0189 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0190 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0191 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0192 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0193 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0194 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0195 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0177 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0177 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0177 ((5 : Int),(1 : Int)) four_gamma_branches0177 copies separate cover ceiling four_gamma_check0177 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0177, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0178 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0187 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0196 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0196 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0196 ((5 : Int),(1 : Int)) four_gamma_branches0196 copies separate cover ceiling four_gamma_check0196 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0196, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0197 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0197 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0197 ((5 : Int),(1 : Int)) four_gamma_branches0197 copies separate cover ceiling four_gamma_check0197 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0197, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0202 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0202 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0202 ((2 : Int),(6 : Int)) four_gamma_branches0202 copies separate cover ceiling four_gamma_check0202 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0202, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0203 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0203 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0203 ((2 : Int),(6 : Int)) four_gamma_branches0203 copies separate cover ceiling four_gamma_check0203 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0203, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0204 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0204 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0204 ((2 : Int),(6 : Int)) four_gamma_branches0204 copies separate cover ceiling four_gamma_check0204 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0204, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0205 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0205 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0205 ((2 : Int),(6 : Int)) four_gamma_branches0205 copies separate cover ceiling four_gamma_check0205 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0205, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0206 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0206 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0206 ((2 : Int),(6 : Int)) four_gamma_branches0206 copies separate cover ceiling four_gamma_check0206 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0206, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0207 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0207 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0207 ((2 : Int),(6 : Int)) four_gamma_branches0207 copies separate cover ceiling four_gamma_check0207 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0207, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0208 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0208 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0208 ((2 : Int),(6 : Int)) four_gamma_branches0208 copies separate cover ceiling four_gamma_check0208 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0208, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0209 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0209 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0209 ((2 : Int),(6 : Int)) four_gamma_branches0209 copies separate cover ceiling four_gamma_check0209 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0209, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0201 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0201 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0201 ((0 : Int),(8 : Int)) four_gamma_branches0201 copies separate cover ceiling four_gamma_check0201 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0201, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0202 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0203 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0204 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0205 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0206 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0207 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0208 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0209 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0211 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0211 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0211 ((2 : Int),(6 : Int)) four_gamma_branches0211 copies separate cover ceiling four_gamma_check0211 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0211, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0212 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0212 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0212 ((2 : Int),(6 : Int)) four_gamma_branches0212 copies separate cover ceiling four_gamma_check0212 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0212, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0213 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0213 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0213 ((2 : Int),(6 : Int)) four_gamma_branches0213 copies separate cover ceiling four_gamma_check0213 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0213, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0214 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0214 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0214 ((2 : Int),(6 : Int)) four_gamma_branches0214 copies separate cover ceiling four_gamma_check0214 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0214, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0215 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0215 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0215 ((2 : Int),(6 : Int)) four_gamma_branches0215 copies separate cover ceiling four_gamma_check0215 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0215, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0216 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0216 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0216 ((2 : Int),(6 : Int)) four_gamma_branches0216 copies separate cover ceiling four_gamma_check0216 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0216, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0217 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0217 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0217 ((2 : Int),(6 : Int)) four_gamma_branches0217 copies separate cover ceiling four_gamma_check0217 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0217, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0218 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0218 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0218 ((2 : Int),(6 : Int)) four_gamma_branches0218 copies separate cover ceiling four_gamma_check0218 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0218, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0210 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0210 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0210 ((0 : Int),(8 : Int)) four_gamma_branches0210 copies separate cover ceiling four_gamma_check0210 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0210, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0211 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0212 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0213 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0214 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0215 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0216 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0217 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0218 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0200 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0200 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0200 ((6 : Int),(1 : Int)) four_gamma_branches0200 copies separate cover ceiling four_gamma_check0200 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0200, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0201 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0210 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0221 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0221 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0221 ((2 : Int),(6 : Int)) four_gamma_branches0221 copies separate cover ceiling four_gamma_check0221 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0221, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0222 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0222 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0222 ((2 : Int),(6 : Int)) four_gamma_branches0222 copies separate cover ceiling four_gamma_check0222 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0222, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0223 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0223 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0223 ((2 : Int),(6 : Int)) four_gamma_branches0223 copies separate cover ceiling four_gamma_check0223 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0223, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0224 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0224 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0224 ((2 : Int),(6 : Int)) four_gamma_branches0224 copies separate cover ceiling four_gamma_check0224 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0224, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0225 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0225 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0225 ((2 : Int),(6 : Int)) four_gamma_branches0225 copies separate cover ceiling four_gamma_check0225 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0225, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0226 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0226 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0226 ((2 : Int),(6 : Int)) four_gamma_branches0226 copies separate cover ceiling four_gamma_check0226 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0226, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0227 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0227 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0227 ((2 : Int),(6 : Int)) four_gamma_branches0227 copies separate cover ceiling four_gamma_check0227 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0227, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0228 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0228 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0228 ((2 : Int),(6 : Int)) four_gamma_branches0228 copies separate cover ceiling four_gamma_check0228 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0228, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0220 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0220 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0220 ((0 : Int),(8 : Int)) four_gamma_branches0220 copies separate cover ceiling four_gamma_check0220 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0220, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0221 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0222 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0223 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0224 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0225 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0226 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0227 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0228 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0230 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0230 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0230 ((2 : Int),(6 : Int)) four_gamma_branches0230 copies separate cover ceiling four_gamma_check0230 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0230, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0231 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0231 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0231 ((2 : Int),(6 : Int)) four_gamma_branches0231 copies separate cover ceiling four_gamma_check0231 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0231, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0232 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0232 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0232 ((2 : Int),(6 : Int)) four_gamma_branches0232 copies separate cover ceiling four_gamma_check0232 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0232, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0233 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0233 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0233 ((2 : Int),(6 : Int)) four_gamma_branches0233 copies separate cover ceiling four_gamma_check0233 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0233, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0234 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0234 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0234 ((2 : Int),(6 : Int)) four_gamma_branches0234 copies separate cover ceiling four_gamma_check0234 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0234, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0235 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0235 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0235 ((2 : Int),(6 : Int)) four_gamma_branches0235 copies separate cover ceiling four_gamma_check0235 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0235, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0236 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0236 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0236 ((2 : Int),(6 : Int)) four_gamma_branches0236 copies separate cover ceiling four_gamma_check0236 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0236, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0237 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0237 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0237 ((2 : Int),(6 : Int)) four_gamma_branches0237 copies separate cover ceiling four_gamma_check0237 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0237, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0229 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0229 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0229 ((0 : Int),(8 : Int)) four_gamma_branches0229 copies separate cover ceiling four_gamma_check0229 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0229, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0230 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0231 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0232 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0233 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0234 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0235 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0236 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0237 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0219 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0219 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0219 ((6 : Int),(1 : Int)) four_gamma_branches0219 copies separate cover ceiling four_gamma_check0219 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0219, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0220 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0229 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0199 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0199 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0199 ((4 : Int),(3 : Int)) four_gamma_branches0199 copies separate cover ceiling four_gamma_check0199 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0199, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0200 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0219 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0241 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0241 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0241 ((2 : Int),(6 : Int)) four_gamma_branches0241 copies separate cover ceiling four_gamma_check0241 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0241, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0242 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0242 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0242 ((2 : Int),(6 : Int)) four_gamma_branches0242 copies separate cover ceiling four_gamma_check0242 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0242, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0243 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0243 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0243 ((2 : Int),(6 : Int)) four_gamma_branches0243 copies separate cover ceiling four_gamma_check0243 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0243, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0244 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0244 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0244 ((2 : Int),(6 : Int)) four_gamma_branches0244 copies separate cover ceiling four_gamma_check0244 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0244, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0245 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0245 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0245 ((2 : Int),(6 : Int)) four_gamma_branches0245 copies separate cover ceiling four_gamma_check0245 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0245, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0246 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0246 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0246 ((2 : Int),(6 : Int)) four_gamma_branches0246 copies separate cover ceiling four_gamma_check0246 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0246, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0240 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0240 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0240 ((0 : Int),(8 : Int)) four_gamma_branches0240 copies separate cover ceiling four_gamma_check0240 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0240, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0241 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0242 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0243 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0244 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0245 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0246 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0248 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0248 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0248 ((2 : Int),(6 : Int)) four_gamma_branches0248 copies separate cover ceiling four_gamma_check0248 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0248, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0249 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0249 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0249 ((2 : Int),(6 : Int)) four_gamma_branches0249 copies separate cover ceiling four_gamma_check0249 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0249, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0250 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0250 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0250 ((2 : Int),(6 : Int)) four_gamma_branches0250 copies separate cover ceiling four_gamma_check0250 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0250, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0251 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0251 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0251 ((2 : Int),(6 : Int)) four_gamma_branches0251 copies separate cover ceiling four_gamma_check0251 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0251, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0252 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0252 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0252 ((2 : Int),(6 : Int)) four_gamma_branches0252 copies separate cover ceiling four_gamma_check0252 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0252, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0253 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0253 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0253 ((2 : Int),(6 : Int)) four_gamma_branches0253 copies separate cover ceiling four_gamma_check0253 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0253, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0247 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0247 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0247 ((0 : Int),(8 : Int)) four_gamma_branches0247 copies separate cover ceiling four_gamma_check0247 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0247, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0248 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0249 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0250 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0251 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0252 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0253 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0239 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0239 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0239 ((6 : Int),(1 : Int)) four_gamma_branches0239 copies separate cover ceiling four_gamma_check0239 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0239, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0240 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0247 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0256 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0256 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0256 ((2 : Int),(6 : Int)) four_gamma_branches0256 copies separate cover ceiling four_gamma_check0256 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0256, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0257 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0257 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0257 ((2 : Int),(6 : Int)) four_gamma_branches0257 copies separate cover ceiling four_gamma_check0257 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0257, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0258 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0258 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0258 ((2 : Int),(6 : Int)) four_gamma_branches0258 copies separate cover ceiling four_gamma_check0258 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0258, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0259 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0259 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0259 ((2 : Int),(6 : Int)) four_gamma_branches0259 copies separate cover ceiling four_gamma_check0259 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0259, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0260 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0260 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0260 ((2 : Int),(6 : Int)) four_gamma_branches0260 copies separate cover ceiling four_gamma_check0260 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0260, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0261 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0261 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0261 ((2 : Int),(6 : Int)) four_gamma_branches0261 copies separate cover ceiling four_gamma_check0261 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0261, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0255 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0255 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0255 ((0 : Int),(8 : Int)) four_gamma_branches0255 copies separate cover ceiling four_gamma_check0255 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0255, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0256 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0257 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0258 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0259 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0260 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0261 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0263 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0263 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0263 ((2 : Int),(6 : Int)) four_gamma_branches0263 copies separate cover ceiling four_gamma_check0263 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0263, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0264 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0264 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0264 ((2 : Int),(6 : Int)) four_gamma_branches0264 copies separate cover ceiling four_gamma_check0264 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0264, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0265 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0265 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0265 ((2 : Int),(6 : Int)) four_gamma_branches0265 copies separate cover ceiling four_gamma_check0265 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0265, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0266 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0266 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0266 ((2 : Int),(6 : Int)) four_gamma_branches0266 copies separate cover ceiling four_gamma_check0266 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0266, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0267 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0267 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0267 ((2 : Int),(6 : Int)) four_gamma_branches0267 copies separate cover ceiling four_gamma_check0267 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0267, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0268 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0268 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0268 ((2 : Int),(6 : Int)) four_gamma_branches0268 copies separate cover ceiling four_gamma_check0268 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0268, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0262 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0262 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0262 ((0 : Int),(8 : Int)) four_gamma_branches0262 copies separate cover ceiling four_gamma_check0262 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0262, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0263 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0264 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0265 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0266 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0267 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0268 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0254 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0254 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0254 ((6 : Int),(1 : Int)) four_gamma_branches0254 copies separate cover ceiling four_gamma_check0254 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0254, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0255 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0262 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0238 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0238 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0238 ((4 : Int),(3 : Int)) four_gamma_branches0238 copies separate cover ceiling four_gamma_check0238 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0238, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0239 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0254 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0272 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0272 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0272 ((2 : Int),(6 : Int)) four_gamma_branches0272 copies separate cover ceiling four_gamma_check0272 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0272, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0273 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0273 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0273 ((2 : Int),(6 : Int)) four_gamma_branches0273 copies separate cover ceiling four_gamma_check0273 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0273, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0274 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0274 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0274 ((2 : Int),(6 : Int)) four_gamma_branches0274 copies separate cover ceiling four_gamma_check0274 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0274, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0275 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0275 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0275 ((2 : Int),(6 : Int)) four_gamma_branches0275 copies separate cover ceiling four_gamma_check0275 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0275, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0276 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0276 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0276 ((2 : Int),(6 : Int)) four_gamma_branches0276 copies separate cover ceiling four_gamma_check0276 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0276, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0277 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0277 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0277 ((2 : Int),(6 : Int)) four_gamma_branches0277 copies separate cover ceiling four_gamma_check0277 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0277, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0278 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0278 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0278 ((2 : Int),(6 : Int)) four_gamma_branches0278 copies separate cover ceiling four_gamma_check0278 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0278, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0279 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0279 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0279 ((2 : Int),(6 : Int)) four_gamma_branches0279 copies separate cover ceiling four_gamma_check0279 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0279, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0271 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0271 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0271 ((0 : Int),(8 : Int)) four_gamma_branches0271 copies separate cover ceiling four_gamma_check0271 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0271, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0272 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0273 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0274 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0275 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0276 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0277 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0278 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0279 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0281 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0281 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0281 ((2 : Int),(6 : Int)) four_gamma_branches0281 copies separate cover ceiling four_gamma_check0281 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0281, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0282 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0282 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0282 ((2 : Int),(6 : Int)) four_gamma_branches0282 copies separate cover ceiling four_gamma_check0282 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0282, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0283 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0283 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0283 ((2 : Int),(6 : Int)) four_gamma_branches0283 copies separate cover ceiling four_gamma_check0283 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0283, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0284 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0284 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0284 ((2 : Int),(6 : Int)) four_gamma_branches0284 copies separate cover ceiling four_gamma_check0284 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0284, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0285 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0285 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0285 ((2 : Int),(6 : Int)) four_gamma_branches0285 copies separate cover ceiling four_gamma_check0285 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0285, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0286 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0286 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0286 ((2 : Int),(6 : Int)) four_gamma_branches0286 copies separate cover ceiling four_gamma_check0286 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0286, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0287 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0287 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0287 ((2 : Int),(6 : Int)) four_gamma_branches0287 copies separate cover ceiling four_gamma_check0287 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0287, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0288 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0288 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0288 ((2 : Int),(6 : Int)) four_gamma_branches0288 copies separate cover ceiling four_gamma_check0288 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0288, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0280 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0280 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0280 ((0 : Int),(8 : Int)) four_gamma_branches0280 copies separate cover ceiling four_gamma_check0280 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0280, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0281 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0282 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0283 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0284 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0285 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0286 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0287 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0288 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0270 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0270 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0270 ((6 : Int),(1 : Int)) four_gamma_branches0270 copies separate cover ceiling four_gamma_check0270 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0270, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0271 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0280 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0291 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0291 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0291 ((2 : Int),(6 : Int)) four_gamma_branches0291 copies separate cover ceiling four_gamma_check0291 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0291, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0292 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0292 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0292 ((2 : Int),(6 : Int)) four_gamma_branches0292 copies separate cover ceiling four_gamma_check0292 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0292, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0293 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0293 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0293 ((2 : Int),(6 : Int)) four_gamma_branches0293 copies separate cover ceiling four_gamma_check0293 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0293, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0294 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0294 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0294 ((2 : Int),(6 : Int)) four_gamma_branches0294 copies separate cover ceiling four_gamma_check0294 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0294, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0295 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0295 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0295 ((2 : Int),(6 : Int)) four_gamma_branches0295 copies separate cover ceiling four_gamma_check0295 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0295, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0296 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0296 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0296 ((2 : Int),(6 : Int)) four_gamma_branches0296 copies separate cover ceiling four_gamma_check0296 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0296, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0297 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0297 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0297 ((2 : Int),(6 : Int)) four_gamma_branches0297 copies separate cover ceiling four_gamma_check0297 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0297, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0298 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0298 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0298 ((2 : Int),(6 : Int)) four_gamma_branches0298 copies separate cover ceiling four_gamma_check0298 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0298, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0290 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0290 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0290 ((0 : Int),(8 : Int)) four_gamma_branches0290 copies separate cover ceiling four_gamma_check0290 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0290, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0291 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0292 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0293 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0294 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0295 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0296 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0297 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0298 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0300 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0300 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0300 ((2 : Int),(6 : Int)) four_gamma_branches0300 copies separate cover ceiling four_gamma_check0300 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0300, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0301 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0301 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0301 ((2 : Int),(6 : Int)) four_gamma_branches0301 copies separate cover ceiling four_gamma_check0301 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0301, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0302 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0302 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0302 ((2 : Int),(6 : Int)) four_gamma_branches0302 copies separate cover ceiling four_gamma_check0302 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0302, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0303 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0303 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0303 ((2 : Int),(6 : Int)) four_gamma_branches0303 copies separate cover ceiling four_gamma_check0303 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0303, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0304 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0304 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0304 ((2 : Int),(6 : Int)) four_gamma_branches0304 copies separate cover ceiling four_gamma_check0304 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0304, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0305 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0305 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0305 ((2 : Int),(6 : Int)) four_gamma_branches0305 copies separate cover ceiling four_gamma_check0305 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0305, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0306 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0306 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0306 ((2 : Int),(6 : Int)) four_gamma_branches0306 copies separate cover ceiling four_gamma_check0306 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0306, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0307 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0307 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0307 ((2 : Int),(6 : Int)) four_gamma_branches0307 copies separate cover ceiling four_gamma_check0307 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0307, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0299 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0299 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0299 ((0 : Int),(8 : Int)) four_gamma_branches0299 copies separate cover ceiling four_gamma_check0299 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0299, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0300 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0301 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0302 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0303 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0304 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0305 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0306 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0307 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0289 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0289 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0289 ((6 : Int),(1 : Int)) four_gamma_branches0289 copies separate cover ceiling four_gamma_check0289 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0289, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0290 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0299 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0269 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0269 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0269 ((4 : Int),(3 : Int)) four_gamma_branches0269 copies separate cover ceiling four_gamma_check0269 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0269, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0270 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0289 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0311 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0311 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0311 ((2 : Int),(6 : Int)) four_gamma_branches0311 copies separate cover ceiling four_gamma_check0311 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0311, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0312 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0312 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0312 ((2 : Int),(6 : Int)) four_gamma_branches0312 copies separate cover ceiling four_gamma_check0312 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0312, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0313 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0313 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0313 ((2 : Int),(6 : Int)) four_gamma_branches0313 copies separate cover ceiling four_gamma_check0313 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0313, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0314 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0314 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0314 ((2 : Int),(6 : Int)) four_gamma_branches0314 copies separate cover ceiling four_gamma_check0314 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0314, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0315 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0315 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0315 ((2 : Int),(6 : Int)) four_gamma_branches0315 copies separate cover ceiling four_gamma_check0315 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0315, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0316 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0316 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0316 ((2 : Int),(6 : Int)) four_gamma_branches0316 copies separate cover ceiling four_gamma_check0316 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0316, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0310 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0310 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0310 ((0 : Int),(8 : Int)) four_gamma_branches0310 copies separate cover ceiling four_gamma_check0310 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0310, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0311 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0312 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0313 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0314 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0315 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0316 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0318 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0318 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0318 ((2 : Int),(6 : Int)) four_gamma_branches0318 copies separate cover ceiling four_gamma_check0318 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0318, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0319 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0319 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0319 ((2 : Int),(6 : Int)) four_gamma_branches0319 copies separate cover ceiling four_gamma_check0319 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0319, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0320 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0320 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0320 ((2 : Int),(6 : Int)) four_gamma_branches0320 copies separate cover ceiling four_gamma_check0320 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0320, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0321 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0321 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0321 ((2 : Int),(6 : Int)) four_gamma_branches0321 copies separate cover ceiling four_gamma_check0321 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0321, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0322 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0322 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0322 ((2 : Int),(6 : Int)) four_gamma_branches0322 copies separate cover ceiling four_gamma_check0322 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0322, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0323 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0323 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0323 ((2 : Int),(6 : Int)) four_gamma_branches0323 copies separate cover ceiling four_gamma_check0323 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0323, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0317 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0317 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0317 ((0 : Int),(8 : Int)) four_gamma_branches0317 copies separate cover ceiling four_gamma_check0317 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0317, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0318 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0319 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0320 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0321 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0322 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0323 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0309 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0309 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0309 ((6 : Int),(1 : Int)) four_gamma_branches0309 copies separate cover ceiling four_gamma_check0309 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0309, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0310 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0317 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0326 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0326 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0326 ((2 : Int),(6 : Int)) four_gamma_branches0326 copies separate cover ceiling four_gamma_check0326 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0326, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0327 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0327 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0327 ((2 : Int),(6 : Int)) four_gamma_branches0327 copies separate cover ceiling four_gamma_check0327 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0327, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0328 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0328 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0328 ((2 : Int),(6 : Int)) four_gamma_branches0328 copies separate cover ceiling four_gamma_check0328 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0328, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0329 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0329 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0329 ((2 : Int),(6 : Int)) four_gamma_branches0329 copies separate cover ceiling four_gamma_check0329 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0329, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0330 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0330 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0330 ((2 : Int),(6 : Int)) four_gamma_branches0330 copies separate cover ceiling four_gamma_check0330 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0330, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0331 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0331 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0331 ((2 : Int),(6 : Int)) four_gamma_branches0331 copies separate cover ceiling four_gamma_check0331 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0331, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0325 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0325 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0325 ((0 : Int),(8 : Int)) four_gamma_branches0325 copies separate cover ceiling four_gamma_check0325 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0325, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0326 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0327 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0328 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0329 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0330 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0331 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0333 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0333 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0333 ((2 : Int),(6 : Int)) four_gamma_branches0333 copies separate cover ceiling four_gamma_check0333 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0333, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0334 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0334 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0334 ((2 : Int),(6 : Int)) four_gamma_branches0334 copies separate cover ceiling four_gamma_check0334 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0334, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0335 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0335 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0335 ((2 : Int),(6 : Int)) four_gamma_branches0335 copies separate cover ceiling four_gamma_check0335 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0335, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0336 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0336 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0336 ((2 : Int),(6 : Int)) four_gamma_branches0336 copies separate cover ceiling four_gamma_check0336 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0336, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0337 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0337 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0337 ((2 : Int),(6 : Int)) four_gamma_branches0337 copies separate cover ceiling four_gamma_check0337 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0337, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0338 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0338 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0338 ((2 : Int),(6 : Int)) four_gamma_branches0338 copies separate cover ceiling four_gamma_check0338 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0338, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0332 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0332 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0332 ((0 : Int),(8 : Int)) four_gamma_branches0332 copies separate cover ceiling four_gamma_check0332 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0332, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0333 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0334 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0335 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0336 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0337 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0338 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0324 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0324 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0324 ((6 : Int),(1 : Int)) four_gamma_branches0324 copies separate cover ceiling four_gamma_check0324 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0324, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0325 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0332 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0308 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0308 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0308 ((4 : Int),(3 : Int)) four_gamma_branches0308 copies separate cover ceiling four_gamma_check0308 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0308, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0309 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0324 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0342 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0342 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0342 ((2 : Int),(6 : Int)) four_gamma_branches0342 copies separate cover ceiling four_gamma_check0342 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0342, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0343 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0343 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0343 ((2 : Int),(6 : Int)) four_gamma_branches0343 copies separate cover ceiling four_gamma_check0343 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0343, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0344 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0344 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0344 ((2 : Int),(6 : Int)) four_gamma_branches0344 copies separate cover ceiling four_gamma_check0344 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0344, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0341 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0341 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0341 ((0 : Int),(8 : Int)) four_gamma_branches0341 copies separate cover ceiling four_gamma_check0341 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0341, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0342 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0343 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0344 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0346 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0346 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0346 ((2 : Int),(6 : Int)) four_gamma_branches0346 copies separate cover ceiling four_gamma_check0346 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0346, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0347 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0347 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0347 ((2 : Int),(6 : Int)) four_gamma_branches0347 copies separate cover ceiling four_gamma_check0347 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0347, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0348 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0348 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0348 ((2 : Int),(6 : Int)) four_gamma_branches0348 copies separate cover ceiling four_gamma_check0348 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0348, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0345 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0345 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0345 ((0 : Int),(8 : Int)) four_gamma_branches0345 copies separate cover ceiling four_gamma_check0345 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0345, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0346 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0347 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0348 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0340 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0340 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0340 ((6 : Int),(1 : Int)) four_gamma_branches0340 copies separate cover ceiling four_gamma_check0340 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0340, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0341 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0345 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0351 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0351 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0351 ((2 : Int),(6 : Int)) four_gamma_branches0351 copies separate cover ceiling four_gamma_check0351 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0351, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0352 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0352 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0352 ((2 : Int),(6 : Int)) four_gamma_branches0352 copies separate cover ceiling four_gamma_check0352 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0352, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0353 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0353 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0353 ((2 : Int),(6 : Int)) four_gamma_branches0353 copies separate cover ceiling four_gamma_check0353 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0353, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0350 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0350 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0350 ((0 : Int),(8 : Int)) four_gamma_branches0350 copies separate cover ceiling four_gamma_check0350 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0350, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0351 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0352 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0353 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0355 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0355 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0355 ((2 : Int),(6 : Int)) four_gamma_branches0355 copies separate cover ceiling four_gamma_check0355 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0355, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0356 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0356 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0356 ((2 : Int),(6 : Int)) four_gamma_branches0356 copies separate cover ceiling four_gamma_check0356 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0356, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0357 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0357 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0357 ((2 : Int),(6 : Int)) four_gamma_branches0357 copies separate cover ceiling four_gamma_check0357 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0357, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0354 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0354 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0354 ((0 : Int),(8 : Int)) four_gamma_branches0354 copies separate cover ceiling four_gamma_check0354 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0354, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0355 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0356 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0357 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0349 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0349 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0349 ((6 : Int),(1 : Int)) four_gamma_branches0349 copies separate cover ceiling four_gamma_check0349 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0349, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0350 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0354 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0339 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0339 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0339 ((4 : Int),(3 : Int)) four_gamma_branches0339 copies separate cover ceiling four_gamma_check0339 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0339, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0340 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0349 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0360 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0360 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0360 ((2 : Int),(6 : Int)) four_gamma_branches0360 copies separate cover ceiling four_gamma_check0360 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0360, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0361 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0361 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0361 ((2 : Int),(6 : Int)) four_gamma_branches0361 copies separate cover ceiling four_gamma_check0361 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0361, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0359 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0359 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0359 ((6 : Int),(1 : Int)) four_gamma_branches0359 copies separate cover ceiling four_gamma_check0359 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0359, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0360 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0361 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0363 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0363 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0363 ((2 : Int),(6 : Int)) four_gamma_branches0363 copies separate cover ceiling four_gamma_check0363 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0363, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0364 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0364 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0364 ((2 : Int),(6 : Int)) four_gamma_branches0364 copies separate cover ceiling four_gamma_check0364 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0364, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0362 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0362 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0362 ((6 : Int),(1 : Int)) four_gamma_branches0362 copies separate cover ceiling four_gamma_check0362 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0362, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0363 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0364 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0358 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0358 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0358 ((4 : Int),(3 : Int)) four_gamma_branches0358 copies separate cover ceiling four_gamma_check0358 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0358, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0359 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0362 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0367 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0367 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0367 ((2 : Int),(6 : Int)) four_gamma_branches0367 copies separate cover ceiling four_gamma_check0367 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0367, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0368 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0368 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0368 ((2 : Int),(6 : Int)) four_gamma_branches0368 copies separate cover ceiling four_gamma_check0368 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0368, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0366 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0366 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0366 ((6 : Int),(1 : Int)) four_gamma_branches0366 copies separate cover ceiling four_gamma_check0366 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0366, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0367 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0368 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0370 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0370 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0370 ((2 : Int),(6 : Int)) four_gamma_branches0370 copies separate cover ceiling four_gamma_check0370 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0370, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0371 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0371 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0371 ((2 : Int),(6 : Int)) four_gamma_branches0371 copies separate cover ceiling four_gamma_check0371 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0371, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0369 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0369 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0369 ((6 : Int),(1 : Int)) four_gamma_branches0369 copies separate cover ceiling four_gamma_check0369 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0369, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0370 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0371 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0365 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0365 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0365 ((4 : Int),(3 : Int)) four_gamma_branches0365 copies separate cover ceiling four_gamma_check0365 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0365, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0366 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0369 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0374 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0374 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0374 ((2 : Int),(6 : Int)) four_gamma_branches0374 copies separate cover ceiling four_gamma_check0374 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0374, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0375 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0375 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0375 ((2 : Int),(6 : Int)) four_gamma_branches0375 copies separate cover ceiling four_gamma_check0375 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0375, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0373 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0373 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0373 ((6 : Int),(1 : Int)) four_gamma_branches0373 copies separate cover ceiling four_gamma_check0373 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0373, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0374 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0375 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0377 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0377 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0377 ((2 : Int),(6 : Int)) four_gamma_branches0377 copies separate cover ceiling four_gamma_check0377 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0377, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0378 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0378 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0378 ((2 : Int),(6 : Int)) four_gamma_branches0378 copies separate cover ceiling four_gamma_check0378 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0378, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0376 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0376 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0376 ((6 : Int),(1 : Int)) four_gamma_branches0376 copies separate cover ceiling four_gamma_check0376 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0376, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0377 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0378 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0372 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0372 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0372 ((4 : Int),(3 : Int)) four_gamma_branches0372 copies separate cover ceiling four_gamma_check0372 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0372, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0373 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0376 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0198 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0198 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0198 ((0 : Int),(7 : Int)) four_gamma_branches0198 copies separate cover ceiling four_gamma_check0198 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0198, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0199 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0238 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0269 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0308 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0339 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0358 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0365 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0372 world h copies separate cover ceiling nextB nextState
theorem four_gamma_node0381 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0381 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma four_gamma_occ0381 .alpha (5 : Int) (3 : Int) four_gamma_check0381 B state
include copies separate cover ceiling in
theorem four_gamma_node0382 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0382 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0382 ((6 : Int),(1 : Int)) four_gamma_branches0382 copies separate cover ceiling four_gamma_check0382 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0382, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0383 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0383 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0383 ((6 : Int),(1 : Int)) four_gamma_branches0383 copies separate cover ceiling four_gamma_check0383 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0383, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0384 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0384 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0384 ((6 : Int),(1 : Int)) four_gamma_branches0384 copies separate cover ceiling four_gamma_check0384 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0384, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0385 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0385 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0385 ((6 : Int),(1 : Int)) four_gamma_branches0385 copies separate cover ceiling four_gamma_check0385 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0385, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0380 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0380 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0380 ((4 : Int),(3 : Int)) four_gamma_branches0380 copies separate cover ceiling four_gamma_check0380 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0380, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0381 world h nextB nextState
  · exact four_gamma_node0382 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0383 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0384 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0385 world h copies separate cover ceiling nextB nextState
theorem four_gamma_node0387 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0387 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma four_gamma_occ0387 .alpha (5 : Int) (3 : Int) four_gamma_check0387 B state
include copies separate cover ceiling in
theorem four_gamma_node0388 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0388 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0388 ((6 : Int),(1 : Int)) four_gamma_branches0388 copies separate cover ceiling four_gamma_check0388 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0388, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0389 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0389 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0389 ((6 : Int),(1 : Int)) four_gamma_branches0389 copies separate cover ceiling four_gamma_check0389 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0389, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0390 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0390 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0390 ((6 : Int),(1 : Int)) four_gamma_branches0390 copies separate cover ceiling four_gamma_check0390 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0390, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0391 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0391 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0391 ((6 : Int),(1 : Int)) four_gamma_branches0391 copies separate cover ceiling four_gamma_check0391 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0391, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0386 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0386 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0386 ((4 : Int),(3 : Int)) four_gamma_branches0386 copies separate cover ceiling four_gamma_check0386 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0386, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0387 world h nextB nextState
  · exact four_gamma_node0388 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0389 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0390 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0391 world h copies separate cover ceiling nextB nextState
theorem four_gamma_node0393 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0393 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma four_gamma_occ0393 .alpha (5 : Int) (3 : Int) four_gamma_check0393 B state
include copies separate cover ceiling in
theorem four_gamma_node0394 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0394 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0394 ((6 : Int),(1 : Int)) four_gamma_branches0394 copies separate cover ceiling four_gamma_check0394 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0394, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0395 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0395 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0395 ((6 : Int),(1 : Int)) four_gamma_branches0395 copies separate cover ceiling four_gamma_check0395 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0395, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0396 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0396 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0396 ((6 : Int),(1 : Int)) four_gamma_branches0396 copies separate cover ceiling four_gamma_check0396 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0396, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0397 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0397 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0397 ((6 : Int),(1 : Int)) four_gamma_branches0397 copies separate cover ceiling four_gamma_check0397 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0397, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0392 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0392 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0392 ((4 : Int),(3 : Int)) four_gamma_branches0392 copies separate cover ceiling four_gamma_check0392 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0392, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0393 world h nextB nextState
  · exact four_gamma_node0394 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0395 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0396 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0397 world h copies separate cover ceiling nextB nextState
theorem four_gamma_node0399 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0399 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma four_gamma_occ0399 .alpha (5 : Int) (3 : Int) four_gamma_check0399 B state
include copies separate cover ceiling in
theorem four_gamma_node0400 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0400 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0400 ((6 : Int),(1 : Int)) four_gamma_branches0400 copies separate cover ceiling four_gamma_check0400 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0400, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0401 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0401 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0401 ((6 : Int),(1 : Int)) four_gamma_branches0401 copies separate cover ceiling four_gamma_check0401 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0401, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0402 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0402 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0402 ((6 : Int),(1 : Int)) four_gamma_branches0402 copies separate cover ceiling four_gamma_check0402 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0402, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0403 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0403 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0403 ((6 : Int),(1 : Int)) four_gamma_branches0403 copies separate cover ceiling four_gamma_check0403 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0403, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0398 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0398 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0398 ((4 : Int),(3 : Int)) four_gamma_branches0398 copies separate cover ceiling four_gamma_check0398 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0398, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0399 world h nextB nextState
  · exact four_gamma_node0400 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0401 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0402 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0403 world h copies separate cover ceiling nextB nextState
theorem four_gamma_node0405 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0405 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma four_gamma_occ0405 .alpha (5 : Int) (3 : Int) four_gamma_check0405 B state
include copies separate cover ceiling in
theorem four_gamma_node0406 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0406 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0406 ((6 : Int),(1 : Int)) four_gamma_branches0406 copies separate cover ceiling four_gamma_check0406 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0406, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0407 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0407 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0407 ((6 : Int),(1 : Int)) four_gamma_branches0407 copies separate cover ceiling four_gamma_check0407 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0407, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0408 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0408 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0408 ((6 : Int),(1 : Int)) four_gamma_branches0408 copies separate cover ceiling four_gamma_check0408 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0408, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0409 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0409 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0409 ((6 : Int),(1 : Int)) four_gamma_branches0409 copies separate cover ceiling four_gamma_check0409 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0409, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0404 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0404 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0404 ((4 : Int),(3 : Int)) four_gamma_branches0404 copies separate cover ceiling four_gamma_check0404 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0404, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0405 world h nextB nextState
  · exact four_gamma_node0406 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0407 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0408 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0409 world h copies separate cover ceiling nextB nextState
theorem four_gamma_node0411 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0411 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma four_gamma_occ0411 .alpha (5 : Int) (3 : Int) four_gamma_check0411 B state
include copies separate cover ceiling in
theorem four_gamma_node0412 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0412 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0412 ((6 : Int),(1 : Int)) four_gamma_branches0412 copies separate cover ceiling four_gamma_check0412 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0412, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0413 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0413 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0413 ((6 : Int),(1 : Int)) four_gamma_branches0413 copies separate cover ceiling four_gamma_check0413 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0413, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0414 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0414 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0414 ((6 : Int),(1 : Int)) four_gamma_branches0414 copies separate cover ceiling four_gamma_check0414 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0414, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0415 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0415 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0415 ((6 : Int),(1 : Int)) four_gamma_branches0415 copies separate cover ceiling four_gamma_check0415 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0415, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0410 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0410 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0410 ((4 : Int),(3 : Int)) four_gamma_branches0410 copies separate cover ceiling four_gamma_check0410 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0410, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0411 world h nextB nextState
  · exact four_gamma_node0412 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0413 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0414 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0415 world h copies separate cover ceiling nextB nextState
theorem four_gamma_node0417 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0417 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma four_gamma_occ0417 .alpha (5 : Int) (3 : Int) four_gamma_check0417 B state
include copies separate cover ceiling in
theorem four_gamma_node0418 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0418 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0418 ((6 : Int),(1 : Int)) four_gamma_branches0418 copies separate cover ceiling four_gamma_check0418 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0418, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0419 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0419 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0419 ((6 : Int),(1 : Int)) four_gamma_branches0419 copies separate cover ceiling four_gamma_check0419 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0419, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0420 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0420 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0420 ((6 : Int),(1 : Int)) four_gamma_branches0420 copies separate cover ceiling four_gamma_check0420 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0420, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0421 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0421 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0421 ((6 : Int),(1 : Int)) four_gamma_branches0421 copies separate cover ceiling four_gamma_check0421 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0421, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0416 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0416 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0416 ((4 : Int),(3 : Int)) four_gamma_branches0416 copies separate cover ceiling four_gamma_check0416 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0416, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0417 world h nextB nextState
  · exact four_gamma_node0418 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0419 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0420 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0421 world h copies separate cover ceiling nextB nextState
theorem four_gamma_node0423 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0423 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma four_gamma_occ0423 .alpha (5 : Int) (3 : Int) four_gamma_check0423 B state
include copies separate cover ceiling in
theorem four_gamma_node0424 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0424 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0424 ((6 : Int),(1 : Int)) four_gamma_branches0424 copies separate cover ceiling four_gamma_check0424 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0424, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0425 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0425 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0425 ((6 : Int),(1 : Int)) four_gamma_branches0425 copies separate cover ceiling four_gamma_check0425 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0425, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0426 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0426 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0426 ((6 : Int),(1 : Int)) four_gamma_branches0426 copies separate cover ceiling four_gamma_check0426 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0426, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0427 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0427 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0427 ((6 : Int),(1 : Int)) four_gamma_branches0427 copies separate cover ceiling four_gamma_check0427 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0427, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0422 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0422 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0422 ((4 : Int),(3 : Int)) four_gamma_branches0422 copies separate cover ceiling four_gamma_check0422 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0422, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0423 world h nextB nextState
  · exact four_gamma_node0424 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0425 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0426 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0427 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0379 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0379 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0379 ((0 : Int),(7 : Int)) four_gamma_branches0379 copies separate cover ceiling four_gamma_check0379 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0379, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0380 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0386 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0392 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0398 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0404 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0410 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0416 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0422 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0428 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0428 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0428 ((5 : Int),(1 : Int)) four_gamma_branches0428 copies separate cover ceiling four_gamma_check0428 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0428, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0429 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0429 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0429 ((5 : Int),(1 : Int)) four_gamma_branches0429 copies separate cover ceiling four_gamma_check0429 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0429, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0176 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0176 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0176 ((4 : Int),(2 : Int)) four_gamma_branches0176 copies separate cover ceiling four_gamma_check0176 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0176, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0177 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0196 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0197 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0198 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0379 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0428 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0429 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0173 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0173 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0173 ((4 : Int),(0 : Int)) four_gamma_branches0173 copies separate cover ceiling four_gamma_check0173 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0173, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0174 world h nextB nextState
  · exact four_gamma_node0175 world h nextB nextState
  · exact four_gamma_node0176 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0004 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0004 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0004 ((1 : Int),(3 : Int)) four_gamma_branches0004 copies separate cover ceiling four_gamma_check0004 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0004, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0005 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0173 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0432 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0432 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0432 ((4 : Int),(1 : Int)) four_gamma_branches0432 copies separate cover ceiling four_gamma_check0432 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0432, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0434 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0434 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0434 ((4 : Int),(2 : Int)) four_gamma_branches0434 copies separate cover ceiling four_gamma_check0434 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0434, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0435 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0435 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0435 ((4 : Int),(2 : Int)) four_gamma_branches0435 copies separate cover ceiling four_gamma_check0435 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0435, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0433 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0433 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0433 ((4 : Int),(1 : Int)) four_gamma_branches0433 copies separate cover ceiling four_gamma_check0433 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0433, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0434 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0435 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0436 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0436 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0436 ((4 : Int),(1 : Int)) four_gamma_branches0436 copies separate cover ceiling four_gamma_check0436 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0436, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0431 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0431 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0431 ((4 : Int),(0 : Int)) four_gamma_branches0431 copies separate cover ceiling four_gamma_check0431 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0431, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0432 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0433 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0436 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0438 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0438 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0438 ((4 : Int),(1 : Int)) four_gamma_branches0438 copies separate cover ceiling four_gamma_check0438 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0438, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0440 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0440 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0440 ((4 : Int),(2 : Int)) four_gamma_branches0440 copies separate cover ceiling four_gamma_check0440 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0440, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0441 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0441 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0441 ((4 : Int),(2 : Int)) four_gamma_branches0441 copies separate cover ceiling four_gamma_check0441 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0441, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0439 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0439 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0439 ((4 : Int),(1 : Int)) four_gamma_branches0439 copies separate cover ceiling four_gamma_check0439 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0439, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0440 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0441 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0442 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0442 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0442 ((4 : Int),(1 : Int)) four_gamma_branches0442 copies separate cover ceiling four_gamma_check0442 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0442, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0437 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0437 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0437 ((4 : Int),(0 : Int)) four_gamma_branches0437 copies separate cover ceiling four_gamma_check0437 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0437, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0438 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0439 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0442 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0430 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0430 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0430 ((1 : Int),(3 : Int)) four_gamma_branches0430 copies separate cover ceiling four_gamma_check0430 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0430, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0431 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0437 world h copies separate cover ceiling nextB nextState
theorem four_gamma_node0445 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0445 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma four_gamma_occ0445 .gammaTranspose (4 : Int) (1 : Int) four_gamma_check0445 B state
include copies separate cover ceiling in
theorem four_gamma_node0447 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0447 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0447 ((4 : Int),(3 : Int)) four_gamma_branches0447 copies separate cover ceiling four_gamma_check0447 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0447, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0452 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0452 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0452 ((4 : Int),(4 : Int)) four_gamma_branches0452 copies separate cover ceiling four_gamma_check0452 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0452, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0453 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0453 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0453 ((4 : Int),(4 : Int)) four_gamma_branches0453 copies separate cover ceiling four_gamma_check0453 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0453, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0454 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0454 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0454 ((4 : Int),(4 : Int)) four_gamma_branches0454 copies separate cover ceiling four_gamma_check0454 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0454, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0451 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0451 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0451 ((2 : Int),(6 : Int)) four_gamma_branches0451 copies separate cover ceiling four_gamma_check0451 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0451, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0452 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0453 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0454 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0456 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0456 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0456 ((4 : Int),(4 : Int)) four_gamma_branches0456 copies separate cover ceiling four_gamma_check0456 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0456, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0457 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0457 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0457 ((4 : Int),(4 : Int)) four_gamma_branches0457 copies separate cover ceiling four_gamma_check0457 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0457, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0458 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0458 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0458 ((4 : Int),(4 : Int)) four_gamma_branches0458 copies separate cover ceiling four_gamma_check0458 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0458, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0455 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0455 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0455 ((2 : Int),(6 : Int)) four_gamma_branches0455 copies separate cover ceiling four_gamma_check0455 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0455, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0456 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0457 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0458 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0460 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0460 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0460 ((4 : Int),(4 : Int)) four_gamma_branches0460 copies separate cover ceiling four_gamma_check0460 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0460, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0461 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0461 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0461 ((4 : Int),(4 : Int)) four_gamma_branches0461 copies separate cover ceiling four_gamma_check0461 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0461, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0462 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0462 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0462 ((4 : Int),(4 : Int)) four_gamma_branches0462 copies separate cover ceiling four_gamma_check0462 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0462, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0459 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0459 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0459 ((2 : Int),(6 : Int)) four_gamma_branches0459 copies separate cover ceiling four_gamma_check0459 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0459, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0460 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0461 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0462 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0464 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0464 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0464 ((4 : Int),(4 : Int)) four_gamma_branches0464 copies separate cover ceiling four_gamma_check0464 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0464, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0465 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0465 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0465 ((4 : Int),(4 : Int)) four_gamma_branches0465 copies separate cover ceiling four_gamma_check0465 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0465, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0466 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0466 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0466 ((4 : Int),(4 : Int)) four_gamma_branches0466 copies separate cover ceiling four_gamma_check0466 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0466, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0463 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0463 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0463 ((2 : Int),(6 : Int)) four_gamma_branches0463 copies separate cover ceiling four_gamma_check0463 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0463, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0464 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0465 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0466 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0468 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0468 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0468 ((4 : Int),(4 : Int)) four_gamma_branches0468 copies separate cover ceiling four_gamma_check0468 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0468, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0469 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0469 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0469 ((4 : Int),(4 : Int)) four_gamma_branches0469 copies separate cover ceiling four_gamma_check0469 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0469, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0470 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0470 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0470 ((4 : Int),(4 : Int)) four_gamma_branches0470 copies separate cover ceiling four_gamma_check0470 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0470, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0467 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0467 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0467 ((2 : Int),(6 : Int)) four_gamma_branches0467 copies separate cover ceiling four_gamma_check0467 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0467, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0468 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0469 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0470 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0472 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0472 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0472 ((4 : Int),(4 : Int)) four_gamma_branches0472 copies separate cover ceiling four_gamma_check0472 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0472, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0473 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0473 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0473 ((4 : Int),(4 : Int)) four_gamma_branches0473 copies separate cover ceiling four_gamma_check0473 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0473, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0474 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0474 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0474 ((4 : Int),(4 : Int)) four_gamma_branches0474 copies separate cover ceiling four_gamma_check0474 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0474, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0471 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0471 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0471 ((2 : Int),(6 : Int)) four_gamma_branches0471 copies separate cover ceiling four_gamma_check0471 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0471, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0472 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0473 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0474 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0476 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0476 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0476 ((4 : Int),(4 : Int)) four_gamma_branches0476 copies separate cover ceiling four_gamma_check0476 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0476, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0477 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0477 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0477 ((4 : Int),(4 : Int)) four_gamma_branches0477 copies separate cover ceiling four_gamma_check0477 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0477, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0478 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0478 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0478 ((4 : Int),(4 : Int)) four_gamma_branches0478 copies separate cover ceiling four_gamma_check0478 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0478, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0475 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0475 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0475 ((2 : Int),(6 : Int)) four_gamma_branches0475 copies separate cover ceiling four_gamma_check0475 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0475, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0476 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0477 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0478 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0479 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0479 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0479 ((2 : Int),(6 : Int)) four_gamma_branches0479 copies separate cover ceiling four_gamma_check0479 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0479, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0481 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0481 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0481 ((4 : Int),(4 : Int)) four_gamma_branches0481 copies separate cover ceiling four_gamma_check0481 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0481, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0482 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0482 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0482 ((4 : Int),(4 : Int)) four_gamma_branches0482 copies separate cover ceiling four_gamma_check0482 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0482, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0483 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0483 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0483 ((4 : Int),(4 : Int)) four_gamma_branches0483 copies separate cover ceiling four_gamma_check0483 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0483, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0480 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0480 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0480 ((2 : Int),(6 : Int)) four_gamma_branches0480 copies separate cover ceiling four_gamma_check0480 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0480, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0481 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0482 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0483 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0485 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0485 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0485 ((4 : Int),(4 : Int)) four_gamma_branches0485 copies separate cover ceiling four_gamma_check0485 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0485, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0486 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0486 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0486 ((4 : Int),(4 : Int)) four_gamma_branches0486 copies separate cover ceiling four_gamma_check0486 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0486, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0487 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0487 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0487 ((4 : Int),(4 : Int)) four_gamma_branches0487 copies separate cover ceiling four_gamma_check0487 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0487, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0484 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0484 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0484 ((2 : Int),(6 : Int)) four_gamma_branches0484 copies separate cover ceiling four_gamma_check0484 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0484, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0485 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0486 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0487 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0489 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0489 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0489 ((4 : Int),(4 : Int)) four_gamma_branches0489 copies separate cover ceiling four_gamma_check0489 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0489, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0490 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0490 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0490 ((4 : Int),(4 : Int)) four_gamma_branches0490 copies separate cover ceiling four_gamma_check0490 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0490, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0491 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0491 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0491 ((4 : Int),(4 : Int)) four_gamma_branches0491 copies separate cover ceiling four_gamma_check0491 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0491, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0488 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0488 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0488 ((2 : Int),(6 : Int)) four_gamma_branches0488 copies separate cover ceiling four_gamma_check0488 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0488, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0489 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0490 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0491 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0450 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0450 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0450 ((0 : Int),(8 : Int)) four_gamma_branches0450 copies separate cover ceiling four_gamma_check0450 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0450, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0451 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0455 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0459 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0463 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0467 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0471 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0475 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0479 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0480 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0484 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0488 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0494 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0494 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0494 ((4 : Int),(4 : Int)) four_gamma_branches0494 copies separate cover ceiling four_gamma_check0494 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0494, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0495 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0495 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0495 ((4 : Int),(4 : Int)) four_gamma_branches0495 copies separate cover ceiling four_gamma_check0495 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0495, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0496 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0496 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0496 ((4 : Int),(4 : Int)) four_gamma_branches0496 copies separate cover ceiling four_gamma_check0496 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0496, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0493 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0493 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0493 ((2 : Int),(6 : Int)) four_gamma_branches0493 copies separate cover ceiling four_gamma_check0493 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0493, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0494 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0495 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0496 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0498 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0498 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0498 ((4 : Int),(4 : Int)) four_gamma_branches0498 copies separate cover ceiling four_gamma_check0498 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0498, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0499 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0499 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0499 ((4 : Int),(4 : Int)) four_gamma_branches0499 copies separate cover ceiling four_gamma_check0499 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0499, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0500 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0500 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0500 ((4 : Int),(4 : Int)) four_gamma_branches0500 copies separate cover ceiling four_gamma_check0500 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0500, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0497 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0497 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0497 ((2 : Int),(6 : Int)) four_gamma_branches0497 copies separate cover ceiling four_gamma_check0497 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0497, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0498 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0499 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0500 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0502 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0502 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0502 ((4 : Int),(4 : Int)) four_gamma_branches0502 copies separate cover ceiling four_gamma_check0502 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0502, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0503 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0503 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0503 ((4 : Int),(4 : Int)) four_gamma_branches0503 copies separate cover ceiling four_gamma_check0503 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0503, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0504 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0504 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0504 ((4 : Int),(4 : Int)) four_gamma_branches0504 copies separate cover ceiling four_gamma_check0504 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0504, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0501 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0501 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0501 ((2 : Int),(6 : Int)) four_gamma_branches0501 copies separate cover ceiling four_gamma_check0501 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0501, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0502 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0503 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0504 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0506 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0506 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0506 ((4 : Int),(4 : Int)) four_gamma_branches0506 copies separate cover ceiling four_gamma_check0506 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0506, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0507 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0507 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0507 ((4 : Int),(4 : Int)) four_gamma_branches0507 copies separate cover ceiling four_gamma_check0507 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0507, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0508 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0508 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0508 ((4 : Int),(4 : Int)) four_gamma_branches0508 copies separate cover ceiling four_gamma_check0508 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0508, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0505 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0505 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0505 ((2 : Int),(6 : Int)) four_gamma_branches0505 copies separate cover ceiling four_gamma_check0505 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0505, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0506 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0507 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0508 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0510 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0510 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0510 ((4 : Int),(4 : Int)) four_gamma_branches0510 copies separate cover ceiling four_gamma_check0510 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0510, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0511 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0511 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0511 ((4 : Int),(4 : Int)) four_gamma_branches0511 copies separate cover ceiling four_gamma_check0511 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0511, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0512 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0512 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0512 ((4 : Int),(4 : Int)) four_gamma_branches0512 copies separate cover ceiling four_gamma_check0512 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0512, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0509 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0509 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0509 ((2 : Int),(6 : Int)) four_gamma_branches0509 copies separate cover ceiling four_gamma_check0509 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0509, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0510 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0511 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0512 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0514 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0514 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0514 ((4 : Int),(4 : Int)) four_gamma_branches0514 copies separate cover ceiling four_gamma_check0514 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0514, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0515 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0515 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0515 ((4 : Int),(4 : Int)) four_gamma_branches0515 copies separate cover ceiling four_gamma_check0515 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0515, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0516 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0516 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0516 ((4 : Int),(4 : Int)) four_gamma_branches0516 copies separate cover ceiling four_gamma_check0516 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0516, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0513 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0513 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0513 ((2 : Int),(6 : Int)) four_gamma_branches0513 copies separate cover ceiling four_gamma_check0513 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0513, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0514 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0515 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0516 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0518 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0518 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0518 ((4 : Int),(4 : Int)) four_gamma_branches0518 copies separate cover ceiling four_gamma_check0518 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0518, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0519 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0519 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0519 ((4 : Int),(4 : Int)) four_gamma_branches0519 copies separate cover ceiling four_gamma_check0519 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0519, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0520 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0520 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0520 ((4 : Int),(4 : Int)) four_gamma_branches0520 copies separate cover ceiling four_gamma_check0520 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0520, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0517 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0517 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0517 ((2 : Int),(6 : Int)) four_gamma_branches0517 copies separate cover ceiling four_gamma_check0517 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0517, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0518 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0519 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0520 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0521 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0521 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0521 ((2 : Int),(6 : Int)) four_gamma_branches0521 copies separate cover ceiling four_gamma_check0521 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0521, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0523 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0523 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0523 ((4 : Int),(4 : Int)) four_gamma_branches0523 copies separate cover ceiling four_gamma_check0523 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0523, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0524 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0524 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0524 ((4 : Int),(4 : Int)) four_gamma_branches0524 copies separate cover ceiling four_gamma_check0524 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0524, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0525 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0525 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0525 ((4 : Int),(4 : Int)) four_gamma_branches0525 copies separate cover ceiling four_gamma_check0525 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0525, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0522 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0522 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0522 ((2 : Int),(6 : Int)) four_gamma_branches0522 copies separate cover ceiling four_gamma_check0522 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0522, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0523 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0524 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0525 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0527 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0527 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0527 ((4 : Int),(4 : Int)) four_gamma_branches0527 copies separate cover ceiling four_gamma_check0527 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0527, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0528 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0528 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0528 ((4 : Int),(4 : Int)) four_gamma_branches0528 copies separate cover ceiling four_gamma_check0528 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0528, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0529 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0529 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0529 ((4 : Int),(4 : Int)) four_gamma_branches0529 copies separate cover ceiling four_gamma_check0529 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0529, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0526 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0526 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0526 ((2 : Int),(6 : Int)) four_gamma_branches0526 copies separate cover ceiling four_gamma_check0526 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0526, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0527 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0528 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0529 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0531 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0531 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0531 ((4 : Int),(4 : Int)) four_gamma_branches0531 copies separate cover ceiling four_gamma_check0531 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0531, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0532 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0532 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0532 ((4 : Int),(4 : Int)) four_gamma_branches0532 copies separate cover ceiling four_gamma_check0532 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0532, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0533 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0533 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0533 ((4 : Int),(4 : Int)) four_gamma_branches0533 copies separate cover ceiling four_gamma_check0533 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0533, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0530 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0530 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0530 ((2 : Int),(6 : Int)) four_gamma_branches0530 copies separate cover ceiling four_gamma_check0530 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0530, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0531 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0532 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0533 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0492 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0492 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0492 ((0 : Int),(8 : Int)) four_gamma_branches0492 copies separate cover ceiling four_gamma_check0492 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0492, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0493 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0497 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0501 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0505 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0509 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0513 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0517 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0521 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0522 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0526 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0530 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0449 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0449 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0449 ((6 : Int),(1 : Int)) four_gamma_branches0449 copies separate cover ceiling four_gamma_check0449 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0449, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0450 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0492 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0537 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0537 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0537 ((4 : Int),(4 : Int)) four_gamma_branches0537 copies separate cover ceiling four_gamma_check0537 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0537, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0538 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0538 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0538 ((4 : Int),(4 : Int)) four_gamma_branches0538 copies separate cover ceiling four_gamma_check0538 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0538, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0539 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0539 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0539 ((4 : Int),(4 : Int)) four_gamma_branches0539 copies separate cover ceiling four_gamma_check0539 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0539, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0536 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0536 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0536 ((2 : Int),(6 : Int)) four_gamma_branches0536 copies separate cover ceiling four_gamma_check0536 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0536, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0537 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0538 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0539 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0541 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0541 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0541 ((4 : Int),(4 : Int)) four_gamma_branches0541 copies separate cover ceiling four_gamma_check0541 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0541, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0542 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0542 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0542 ((4 : Int),(4 : Int)) four_gamma_branches0542 copies separate cover ceiling four_gamma_check0542 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0542, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0543 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0543 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0543 ((4 : Int),(4 : Int)) four_gamma_branches0543 copies separate cover ceiling four_gamma_check0543 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0543, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0540 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0540 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0540 ((2 : Int),(6 : Int)) four_gamma_branches0540 copies separate cover ceiling four_gamma_check0540 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0540, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0541 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0542 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0543 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0545 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0545 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0545 ((4 : Int),(4 : Int)) four_gamma_branches0545 copies separate cover ceiling four_gamma_check0545 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0545, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0546 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0546 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0546 ((4 : Int),(4 : Int)) four_gamma_branches0546 copies separate cover ceiling four_gamma_check0546 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0546, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0547 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0547 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0547 ((4 : Int),(4 : Int)) four_gamma_branches0547 copies separate cover ceiling four_gamma_check0547 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0547, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0544 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0544 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0544 ((2 : Int),(6 : Int)) four_gamma_branches0544 copies separate cover ceiling four_gamma_check0544 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0544, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0545 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0546 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0547 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0549 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0549 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0549 ((4 : Int),(4 : Int)) four_gamma_branches0549 copies separate cover ceiling four_gamma_check0549 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0549, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0550 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0550 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0550 ((4 : Int),(4 : Int)) four_gamma_branches0550 copies separate cover ceiling four_gamma_check0550 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0550, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0551 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0551 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0551 ((4 : Int),(4 : Int)) four_gamma_branches0551 copies separate cover ceiling four_gamma_check0551 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0551, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0548 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0548 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0548 ((2 : Int),(6 : Int)) four_gamma_branches0548 copies separate cover ceiling four_gamma_check0548 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0548, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0549 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0550 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0551 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0553 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0553 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0553 ((4 : Int),(4 : Int)) four_gamma_branches0553 copies separate cover ceiling four_gamma_check0553 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0553, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0554 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0554 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0554 ((4 : Int),(4 : Int)) four_gamma_branches0554 copies separate cover ceiling four_gamma_check0554 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0554, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0555 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0555 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0555 ((4 : Int),(4 : Int)) four_gamma_branches0555 copies separate cover ceiling four_gamma_check0555 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0555, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0552 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0552 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0552 ((2 : Int),(6 : Int)) four_gamma_branches0552 copies separate cover ceiling four_gamma_check0552 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0552, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0553 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0554 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0555 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0557 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0557 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0557 ((4 : Int),(4 : Int)) four_gamma_branches0557 copies separate cover ceiling four_gamma_check0557 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0557, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0558 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0558 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0558 ((4 : Int),(4 : Int)) four_gamma_branches0558 copies separate cover ceiling four_gamma_check0558 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0558, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0559 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0559 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0559 ((4 : Int),(4 : Int)) four_gamma_branches0559 copies separate cover ceiling four_gamma_check0559 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0559, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0556 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0556 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0556 ((2 : Int),(6 : Int)) four_gamma_branches0556 copies separate cover ceiling four_gamma_check0556 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0556, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0557 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0558 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0559 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0561 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0561 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0561 ((4 : Int),(4 : Int)) four_gamma_branches0561 copies separate cover ceiling four_gamma_check0561 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0561, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0562 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0562 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0562 ((4 : Int),(4 : Int)) four_gamma_branches0562 copies separate cover ceiling four_gamma_check0562 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0562, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0563 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0563 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0563 ((4 : Int),(4 : Int)) four_gamma_branches0563 copies separate cover ceiling four_gamma_check0563 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0563, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0560 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0560 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0560 ((2 : Int),(6 : Int)) four_gamma_branches0560 copies separate cover ceiling four_gamma_check0560 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0560, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0561 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0562 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0563 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0564 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0564 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0564 ((2 : Int),(6 : Int)) four_gamma_branches0564 copies separate cover ceiling four_gamma_check0564 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0564, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0566 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0566 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0566 ((4 : Int),(4 : Int)) four_gamma_branches0566 copies separate cover ceiling four_gamma_check0566 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0566, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0567 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0567 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0567 ((4 : Int),(4 : Int)) four_gamma_branches0567 copies separate cover ceiling four_gamma_check0567 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0567, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0568 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0568 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0568 ((4 : Int),(4 : Int)) four_gamma_branches0568 copies separate cover ceiling four_gamma_check0568 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0568, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0565 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0565 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0565 ((2 : Int),(6 : Int)) four_gamma_branches0565 copies separate cover ceiling four_gamma_check0565 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0565, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0566 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0567 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0568 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0570 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0570 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0570 ((4 : Int),(4 : Int)) four_gamma_branches0570 copies separate cover ceiling four_gamma_check0570 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0570, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0571 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0571 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0571 ((4 : Int),(4 : Int)) four_gamma_branches0571 copies separate cover ceiling four_gamma_check0571 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0571, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0572 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0572 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0572 ((4 : Int),(4 : Int)) four_gamma_branches0572 copies separate cover ceiling four_gamma_check0572 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0572, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0569 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0569 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0569 ((2 : Int),(6 : Int)) four_gamma_branches0569 copies separate cover ceiling four_gamma_check0569 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0569, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0570 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0571 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0572 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0574 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0574 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0574 ((4 : Int),(4 : Int)) four_gamma_branches0574 copies separate cover ceiling four_gamma_check0574 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0574, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0575 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0575 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0575 ((4 : Int),(4 : Int)) four_gamma_branches0575 copies separate cover ceiling four_gamma_check0575 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0575, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0576 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0576 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0576 ((4 : Int),(4 : Int)) four_gamma_branches0576 copies separate cover ceiling four_gamma_check0576 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0576, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0573 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0573 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0573 ((2 : Int),(6 : Int)) four_gamma_branches0573 copies separate cover ceiling four_gamma_check0573 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0573, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0574 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0575 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0576 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0535 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0535 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0535 ((0 : Int),(8 : Int)) four_gamma_branches0535 copies separate cover ceiling four_gamma_check0535 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0535, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0536 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0540 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0544 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0548 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0552 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0556 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0560 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0564 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0565 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0569 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0573 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0579 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0579 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0579 ((4 : Int),(4 : Int)) four_gamma_branches0579 copies separate cover ceiling four_gamma_check0579 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0579, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0580 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0580 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0580 ((4 : Int),(4 : Int)) four_gamma_branches0580 copies separate cover ceiling four_gamma_check0580 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0580, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0581 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0581 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0581 ((4 : Int),(4 : Int)) four_gamma_branches0581 copies separate cover ceiling four_gamma_check0581 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0581, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0578 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0578 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0578 ((2 : Int),(6 : Int)) four_gamma_branches0578 copies separate cover ceiling four_gamma_check0578 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0578, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0579 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0580 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0581 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0583 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0583 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0583 ((4 : Int),(4 : Int)) four_gamma_branches0583 copies separate cover ceiling four_gamma_check0583 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0583, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0584 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0584 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0584 ((4 : Int),(4 : Int)) four_gamma_branches0584 copies separate cover ceiling four_gamma_check0584 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0584, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0585 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0585 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0585 ((4 : Int),(4 : Int)) four_gamma_branches0585 copies separate cover ceiling four_gamma_check0585 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0585, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0582 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0582 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0582 ((2 : Int),(6 : Int)) four_gamma_branches0582 copies separate cover ceiling four_gamma_check0582 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0582, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0583 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0584 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0585 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0587 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0587 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0587 ((4 : Int),(4 : Int)) four_gamma_branches0587 copies separate cover ceiling four_gamma_check0587 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0587, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0588 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0588 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0588 ((4 : Int),(4 : Int)) four_gamma_branches0588 copies separate cover ceiling four_gamma_check0588 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0588, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0589 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0589 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0589 ((4 : Int),(4 : Int)) four_gamma_branches0589 copies separate cover ceiling four_gamma_check0589 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0589, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0586 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0586 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0586 ((2 : Int),(6 : Int)) four_gamma_branches0586 copies separate cover ceiling four_gamma_check0586 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0586, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0587 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0588 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0589 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0591 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0591 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0591 ((4 : Int),(4 : Int)) four_gamma_branches0591 copies separate cover ceiling four_gamma_check0591 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0591, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0592 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0592 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0592 ((4 : Int),(4 : Int)) four_gamma_branches0592 copies separate cover ceiling four_gamma_check0592 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0592, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0593 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0593 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0593 ((4 : Int),(4 : Int)) four_gamma_branches0593 copies separate cover ceiling four_gamma_check0593 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0593, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0590 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0590 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0590 ((2 : Int),(6 : Int)) four_gamma_branches0590 copies separate cover ceiling four_gamma_check0590 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0590, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0591 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0592 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0593 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0595 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0595 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0595 ((4 : Int),(4 : Int)) four_gamma_branches0595 copies separate cover ceiling four_gamma_check0595 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0595, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0596 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0596 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0596 ((4 : Int),(4 : Int)) four_gamma_branches0596 copies separate cover ceiling four_gamma_check0596 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0596, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0597 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0597 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0597 ((4 : Int),(4 : Int)) four_gamma_branches0597 copies separate cover ceiling four_gamma_check0597 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0597, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0594 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0594 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0594 ((2 : Int),(6 : Int)) four_gamma_branches0594 copies separate cover ceiling four_gamma_check0594 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0594, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0595 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0596 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0597 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0599 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0599 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0599 ((4 : Int),(4 : Int)) four_gamma_branches0599 copies separate cover ceiling four_gamma_check0599 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0599, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0600 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0600 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0600 ((4 : Int),(4 : Int)) four_gamma_branches0600 copies separate cover ceiling four_gamma_check0600 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0600, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0601 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0601 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0601 ((4 : Int),(4 : Int)) four_gamma_branches0601 copies separate cover ceiling four_gamma_check0601 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0601, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0598 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0598 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0598 ((2 : Int),(6 : Int)) four_gamma_branches0598 copies separate cover ceiling four_gamma_check0598 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0598, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0599 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0600 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0601 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0603 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0603 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0603 ((4 : Int),(4 : Int)) four_gamma_branches0603 copies separate cover ceiling four_gamma_check0603 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0603, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0604 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0604 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0604 ((4 : Int),(4 : Int)) four_gamma_branches0604 copies separate cover ceiling four_gamma_check0604 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0604, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0605 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0605 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0605 ((4 : Int),(4 : Int)) four_gamma_branches0605 copies separate cover ceiling four_gamma_check0605 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0605, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0602 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0602 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0602 ((2 : Int),(6 : Int)) four_gamma_branches0602 copies separate cover ceiling four_gamma_check0602 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0602, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0603 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0604 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0605 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0606 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0606 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0606 ((2 : Int),(6 : Int)) four_gamma_branches0606 copies separate cover ceiling four_gamma_check0606 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0606, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0608 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0608 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0608 ((4 : Int),(4 : Int)) four_gamma_branches0608 copies separate cover ceiling four_gamma_check0608 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0608, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0609 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0609 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0609 ((4 : Int),(4 : Int)) four_gamma_branches0609 copies separate cover ceiling four_gamma_check0609 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0609, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0610 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0610 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0610 ((4 : Int),(4 : Int)) four_gamma_branches0610 copies separate cover ceiling four_gamma_check0610 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0610, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0607 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0607 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0607 ((2 : Int),(6 : Int)) four_gamma_branches0607 copies separate cover ceiling four_gamma_check0607 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0607, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0608 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0609 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0610 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0612 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0612 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0612 ((4 : Int),(4 : Int)) four_gamma_branches0612 copies separate cover ceiling four_gamma_check0612 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0612, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0613 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0613 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0613 ((4 : Int),(4 : Int)) four_gamma_branches0613 copies separate cover ceiling four_gamma_check0613 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0613, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0614 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0614 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0614 ((4 : Int),(4 : Int)) four_gamma_branches0614 copies separate cover ceiling four_gamma_check0614 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0614, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0611 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0611 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0611 ((2 : Int),(6 : Int)) four_gamma_branches0611 copies separate cover ceiling four_gamma_check0611 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0611, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0612 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0613 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0614 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0616 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0616 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0616 ((4 : Int),(4 : Int)) four_gamma_branches0616 copies separate cover ceiling four_gamma_check0616 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0616, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0617 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0617 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0617 ((4 : Int),(4 : Int)) four_gamma_branches0617 copies separate cover ceiling four_gamma_check0617 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0617, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0618 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0618 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0618 ((4 : Int),(4 : Int)) four_gamma_branches0618 copies separate cover ceiling four_gamma_check0618 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0618, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0615 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0615 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0615 ((2 : Int),(6 : Int)) four_gamma_branches0615 copies separate cover ceiling four_gamma_check0615 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0615, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0616 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0617 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0618 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0577 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0577 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0577 ((0 : Int),(8 : Int)) four_gamma_branches0577 copies separate cover ceiling four_gamma_check0577 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0577, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0578 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0582 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0586 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0590 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0594 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0598 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0602 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0606 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0607 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0611 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0615 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0534 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0534 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0534 ((6 : Int),(1 : Int)) four_gamma_branches0534 copies separate cover ceiling four_gamma_check0534 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0534, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0535 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0577 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0448 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0448 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0448 ((4 : Int),(3 : Int)) four_gamma_branches0448 copies separate cover ceiling four_gamma_check0448 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0448, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0449 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0534 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0620 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0620 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0620 ((4 : Int),(3 : Int)) four_gamma_branches0620 copies separate cover ceiling four_gamma_check0620 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0620, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0619 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0619 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0619 ((5 : Int),(1 : Int)) four_gamma_branches0619 copies separate cover ceiling four_gamma_check0619 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0619, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact four_gamma_node0620 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0621 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0621 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0621 ((5 : Int),(1 : Int)) four_gamma_branches0621 copies separate cover ceiling four_gamma_check0621 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0621, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0623 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0623 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0623 ((4 : Int),(3 : Int)) four_gamma_branches0623 copies separate cover ceiling four_gamma_check0623 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0623, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0622 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0622 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0622 ((5 : Int),(1 : Int)) four_gamma_branches0622 copies separate cover ceiling four_gamma_check0622 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0622, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact four_gamma_node0623 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0446 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0446 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0446 ((4 : Int),(2 : Int)) four_gamma_branches0446 copies separate cover ceiling four_gamma_check0446 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0446, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0447 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0448 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0619 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0621 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0622 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0444 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0444 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0444 ((3 : Int),(1 : Int)) four_gamma_branches0444 copies separate cover ceiling four_gamma_check0444 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0444, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0445 world h nextB nextState
  · exact four_gamma_node0446 world h copies separate cover ceiling nextB nextState
theorem four_gamma_node0625 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0625 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma four_gamma_occ0625 .gammaTranspose (4 : Int) (1 : Int) four_gamma_check0625 B state
include copies separate cover ceiling in
theorem four_gamma_node0628 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0628 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0628 ((4 : Int),(3 : Int)) four_gamma_branches0628 copies separate cover ceiling four_gamma_check0628 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0628, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0629 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0629 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0629 ((4 : Int),(3 : Int)) four_gamma_branches0629 copies separate cover ceiling four_gamma_check0629 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0629, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0630 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0630 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0630 ((4 : Int),(3 : Int)) four_gamma_branches0630 copies separate cover ceiling four_gamma_check0630 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0630, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0631 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0631 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0631 ((4 : Int),(3 : Int)) four_gamma_branches0631 copies separate cover ceiling four_gamma_check0631 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0631, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0632 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0632 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0632 ((4 : Int),(3 : Int)) four_gamma_branches0632 copies separate cover ceiling four_gamma_check0632 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0632, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0633 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0633 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0633 ((4 : Int),(3 : Int)) four_gamma_branches0633 copies separate cover ceiling four_gamma_check0633 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0633, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0634 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0634 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0634 ((4 : Int),(3 : Int)) four_gamma_branches0634 copies separate cover ceiling four_gamma_check0634 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0634, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0635 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0635 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0635 ((4 : Int),(3 : Int)) four_gamma_branches0635 copies separate cover ceiling four_gamma_check0635 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0635, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0627 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0627 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0627 ((0 : Int),(7 : Int)) four_gamma_branches0627 copies separate cover ceiling four_gamma_check0627 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0627, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0628 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0629 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0630 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0631 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0632 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0633 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0634 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0635 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0640 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0640 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0640 ((2 : Int),(6 : Int)) four_gamma_branches0640 copies separate cover ceiling four_gamma_check0640 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0640, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0641 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0641 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0641 ((2 : Int),(6 : Int)) four_gamma_branches0641 copies separate cover ceiling four_gamma_check0641 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0641, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0642 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0642 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0642 ((2 : Int),(6 : Int)) four_gamma_branches0642 copies separate cover ceiling four_gamma_check0642 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0642, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0643 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0643 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0643 ((2 : Int),(6 : Int)) four_gamma_branches0643 copies separate cover ceiling four_gamma_check0643 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0643, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0644 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0644 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0644 ((2 : Int),(6 : Int)) four_gamma_branches0644 copies separate cover ceiling four_gamma_check0644 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0644, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0645 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0645 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0645 ((2 : Int),(6 : Int)) four_gamma_branches0645 copies separate cover ceiling four_gamma_check0645 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0645, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0646 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0646 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0646 ((2 : Int),(6 : Int)) four_gamma_branches0646 copies separate cover ceiling four_gamma_check0646 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0646, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0647 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0647 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0647 ((2 : Int),(6 : Int)) four_gamma_branches0647 copies separate cover ceiling four_gamma_check0647 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0647, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0639 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0639 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0639 ((0 : Int),(8 : Int)) four_gamma_branches0639 copies separate cover ceiling four_gamma_check0639 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0639, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0640 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0641 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0642 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0643 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0644 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0645 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0646 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0647 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0649 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0649 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0649 ((2 : Int),(6 : Int)) four_gamma_branches0649 copies separate cover ceiling four_gamma_check0649 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0649, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0650 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0650 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0650 ((2 : Int),(6 : Int)) four_gamma_branches0650 copies separate cover ceiling four_gamma_check0650 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0650, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0651 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0651 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0651 ((2 : Int),(6 : Int)) four_gamma_branches0651 copies separate cover ceiling four_gamma_check0651 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0651, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0652 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0652 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0652 ((2 : Int),(6 : Int)) four_gamma_branches0652 copies separate cover ceiling four_gamma_check0652 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0652, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0653 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0653 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0653 ((2 : Int),(6 : Int)) four_gamma_branches0653 copies separate cover ceiling four_gamma_check0653 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0653, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0654 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0654 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0654 ((2 : Int),(6 : Int)) four_gamma_branches0654 copies separate cover ceiling four_gamma_check0654 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0654, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0655 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0655 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0655 ((2 : Int),(6 : Int)) four_gamma_branches0655 copies separate cover ceiling four_gamma_check0655 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0655, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0656 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0656 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0656 ((2 : Int),(6 : Int)) four_gamma_branches0656 copies separate cover ceiling four_gamma_check0656 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0656, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0648 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0648 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0648 ((0 : Int),(8 : Int)) four_gamma_branches0648 copies separate cover ceiling four_gamma_check0648 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0648, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0649 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0650 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0651 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0652 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0653 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0654 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0655 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0656 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0638 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0638 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0638 ((6 : Int),(1 : Int)) four_gamma_branches0638 copies separate cover ceiling four_gamma_check0638 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0638, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0639 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0648 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0659 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0659 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0659 ((2 : Int),(6 : Int)) four_gamma_branches0659 copies separate cover ceiling four_gamma_check0659 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0659, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0660 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0660 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0660 ((2 : Int),(6 : Int)) four_gamma_branches0660 copies separate cover ceiling four_gamma_check0660 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0660, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0661 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0661 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0661 ((2 : Int),(6 : Int)) four_gamma_branches0661 copies separate cover ceiling four_gamma_check0661 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0661, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0662 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0662 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0662 ((2 : Int),(6 : Int)) four_gamma_branches0662 copies separate cover ceiling four_gamma_check0662 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0662, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0663 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0663 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0663 ((2 : Int),(6 : Int)) four_gamma_branches0663 copies separate cover ceiling four_gamma_check0663 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0663, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0664 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0664 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0664 ((2 : Int),(6 : Int)) four_gamma_branches0664 copies separate cover ceiling four_gamma_check0664 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0664, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0665 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0665 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0665 ((2 : Int),(6 : Int)) four_gamma_branches0665 copies separate cover ceiling four_gamma_check0665 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0665, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0666 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0666 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0666 ((2 : Int),(6 : Int)) four_gamma_branches0666 copies separate cover ceiling four_gamma_check0666 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0666, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0658 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0658 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0658 ((0 : Int),(8 : Int)) four_gamma_branches0658 copies separate cover ceiling four_gamma_check0658 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0658, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0659 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0660 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0661 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0662 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0663 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0664 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0665 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0666 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0668 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0668 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0668 ((2 : Int),(6 : Int)) four_gamma_branches0668 copies separate cover ceiling four_gamma_check0668 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0668, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0669 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0669 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0669 ((2 : Int),(6 : Int)) four_gamma_branches0669 copies separate cover ceiling four_gamma_check0669 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0669, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0670 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0670 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0670 ((2 : Int),(6 : Int)) four_gamma_branches0670 copies separate cover ceiling four_gamma_check0670 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0670, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0671 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0671 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0671 ((2 : Int),(6 : Int)) four_gamma_branches0671 copies separate cover ceiling four_gamma_check0671 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0671, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0672 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0672 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0672 ((2 : Int),(6 : Int)) four_gamma_branches0672 copies separate cover ceiling four_gamma_check0672 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0672, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0673 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0673 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0673 ((2 : Int),(6 : Int)) four_gamma_branches0673 copies separate cover ceiling four_gamma_check0673 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0673, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0674 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0674 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0674 ((2 : Int),(6 : Int)) four_gamma_branches0674 copies separate cover ceiling four_gamma_check0674 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0674, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0675 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0675 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0675 ((2 : Int),(6 : Int)) four_gamma_branches0675 copies separate cover ceiling four_gamma_check0675 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0675, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0667 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0667 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0667 ((0 : Int),(8 : Int)) four_gamma_branches0667 copies separate cover ceiling four_gamma_check0667 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0667, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0668 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0669 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0670 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0671 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0672 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0673 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0674 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0675 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0657 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0657 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0657 ((6 : Int),(1 : Int)) four_gamma_branches0657 copies separate cover ceiling four_gamma_check0657 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0657, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0658 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0667 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0637 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0637 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0637 ((4 : Int),(3 : Int)) four_gamma_branches0637 copies separate cover ceiling four_gamma_check0637 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0637, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0638 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0657 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0679 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0679 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0679 ((2 : Int),(6 : Int)) four_gamma_branches0679 copies separate cover ceiling four_gamma_check0679 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0679, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0680 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0680 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0680 ((2 : Int),(6 : Int)) four_gamma_branches0680 copies separate cover ceiling four_gamma_check0680 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0680, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0681 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0681 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0681 ((2 : Int),(6 : Int)) four_gamma_branches0681 copies separate cover ceiling four_gamma_check0681 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0681, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0682 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0682 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0682 ((2 : Int),(6 : Int)) four_gamma_branches0682 copies separate cover ceiling four_gamma_check0682 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0682, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0683 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0683 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0683 ((2 : Int),(6 : Int)) four_gamma_branches0683 copies separate cover ceiling four_gamma_check0683 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0683, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0684 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0684 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0684 ((2 : Int),(6 : Int)) four_gamma_branches0684 copies separate cover ceiling four_gamma_check0684 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0684, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0678 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0678 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0678 ((0 : Int),(8 : Int)) four_gamma_branches0678 copies separate cover ceiling four_gamma_check0678 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0678, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0679 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0680 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0681 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0682 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0683 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0684 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0686 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0686 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0686 ((2 : Int),(6 : Int)) four_gamma_branches0686 copies separate cover ceiling four_gamma_check0686 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0686, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0687 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0687 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0687 ((2 : Int),(6 : Int)) four_gamma_branches0687 copies separate cover ceiling four_gamma_check0687 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0687, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0688 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0688 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0688 ((2 : Int),(6 : Int)) four_gamma_branches0688 copies separate cover ceiling four_gamma_check0688 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0688, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0689 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0689 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0689 ((2 : Int),(6 : Int)) four_gamma_branches0689 copies separate cover ceiling four_gamma_check0689 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0689, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0690 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0690 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0690 ((2 : Int),(6 : Int)) four_gamma_branches0690 copies separate cover ceiling four_gamma_check0690 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0690, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0691 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0691 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0691 ((2 : Int),(6 : Int)) four_gamma_branches0691 copies separate cover ceiling four_gamma_check0691 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0691, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0685 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0685 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0685 ((0 : Int),(8 : Int)) four_gamma_branches0685 copies separate cover ceiling four_gamma_check0685 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0685, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0686 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0687 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0688 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0689 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0690 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0691 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0677 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0677 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0677 ((6 : Int),(1 : Int)) four_gamma_branches0677 copies separate cover ceiling four_gamma_check0677 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0677, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0678 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0685 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0694 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0694 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0694 ((2 : Int),(6 : Int)) four_gamma_branches0694 copies separate cover ceiling four_gamma_check0694 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0694, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0695 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0695 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0695 ((2 : Int),(6 : Int)) four_gamma_branches0695 copies separate cover ceiling four_gamma_check0695 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0695, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0696 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0696 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0696 ((2 : Int),(6 : Int)) four_gamma_branches0696 copies separate cover ceiling four_gamma_check0696 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0696, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0697 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0697 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0697 ((2 : Int),(6 : Int)) four_gamma_branches0697 copies separate cover ceiling four_gamma_check0697 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0697, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0698 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0698 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0698 ((2 : Int),(6 : Int)) four_gamma_branches0698 copies separate cover ceiling four_gamma_check0698 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0698, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0699 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0699 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0699 ((2 : Int),(6 : Int)) four_gamma_branches0699 copies separate cover ceiling four_gamma_check0699 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0699, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0693 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0693 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0693 ((0 : Int),(8 : Int)) four_gamma_branches0693 copies separate cover ceiling four_gamma_check0693 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0693, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0694 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0695 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0696 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0697 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0698 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0699 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0701 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0701 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0701 ((2 : Int),(6 : Int)) four_gamma_branches0701 copies separate cover ceiling four_gamma_check0701 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0701, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0702 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0702 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0702 ((2 : Int),(6 : Int)) four_gamma_branches0702 copies separate cover ceiling four_gamma_check0702 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0702, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0703 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0703 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0703 ((2 : Int),(6 : Int)) four_gamma_branches0703 copies separate cover ceiling four_gamma_check0703 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0703, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0704 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0704 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0704 ((2 : Int),(6 : Int)) four_gamma_branches0704 copies separate cover ceiling four_gamma_check0704 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0704, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0705 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0705 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0705 ((2 : Int),(6 : Int)) four_gamma_branches0705 copies separate cover ceiling four_gamma_check0705 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0705, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0706 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0706 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0706 ((2 : Int),(6 : Int)) four_gamma_branches0706 copies separate cover ceiling four_gamma_check0706 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0706, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0700 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0700 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0700 ((0 : Int),(8 : Int)) four_gamma_branches0700 copies separate cover ceiling four_gamma_check0700 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0700, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0701 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0702 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0703 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0704 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0705 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0706 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0692 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0692 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0692 ((6 : Int),(1 : Int)) four_gamma_branches0692 copies separate cover ceiling four_gamma_check0692 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0692, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0693 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0700 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0676 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0676 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0676 ((4 : Int),(3 : Int)) four_gamma_branches0676 copies separate cover ceiling four_gamma_check0676 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0676, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0677 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0692 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0710 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0710 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0710 ((2 : Int),(6 : Int)) four_gamma_branches0710 copies separate cover ceiling four_gamma_check0710 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0710, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0711 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0711 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0711 ((2 : Int),(6 : Int)) four_gamma_branches0711 copies separate cover ceiling four_gamma_check0711 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0711, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0712 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0712 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0712 ((2 : Int),(6 : Int)) four_gamma_branches0712 copies separate cover ceiling four_gamma_check0712 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0712, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0713 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0713 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0713 ((2 : Int),(6 : Int)) four_gamma_branches0713 copies separate cover ceiling four_gamma_check0713 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0713, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0714 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0714 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0714 ((2 : Int),(6 : Int)) four_gamma_branches0714 copies separate cover ceiling four_gamma_check0714 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0714, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0715 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0715 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0715 ((2 : Int),(6 : Int)) four_gamma_branches0715 copies separate cover ceiling four_gamma_check0715 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0715, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0716 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0716 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0716 ((2 : Int),(6 : Int)) four_gamma_branches0716 copies separate cover ceiling four_gamma_check0716 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0716, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0717 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0717 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0717 ((2 : Int),(6 : Int)) four_gamma_branches0717 copies separate cover ceiling four_gamma_check0717 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0717, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0709 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0709 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0709 ((0 : Int),(8 : Int)) four_gamma_branches0709 copies separate cover ceiling four_gamma_check0709 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0709, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0710 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0711 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0712 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0713 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0714 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0715 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0716 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0717 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0719 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0719 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0719 ((2 : Int),(6 : Int)) four_gamma_branches0719 copies separate cover ceiling four_gamma_check0719 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0719, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0720 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0720 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0720 ((2 : Int),(6 : Int)) four_gamma_branches0720 copies separate cover ceiling four_gamma_check0720 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0720, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0721 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0721 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0721 ((2 : Int),(6 : Int)) four_gamma_branches0721 copies separate cover ceiling four_gamma_check0721 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0721, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0722 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0722 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0722 ((2 : Int),(6 : Int)) four_gamma_branches0722 copies separate cover ceiling four_gamma_check0722 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0722, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0723 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0723 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0723 ((2 : Int),(6 : Int)) four_gamma_branches0723 copies separate cover ceiling four_gamma_check0723 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0723, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0724 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0724 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0724 ((2 : Int),(6 : Int)) four_gamma_branches0724 copies separate cover ceiling four_gamma_check0724 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0724, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0725 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0725 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0725 ((2 : Int),(6 : Int)) four_gamma_branches0725 copies separate cover ceiling four_gamma_check0725 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0725, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0726 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0726 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0726 ((2 : Int),(6 : Int)) four_gamma_branches0726 copies separate cover ceiling four_gamma_check0726 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0726, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0718 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0718 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0718 ((0 : Int),(8 : Int)) four_gamma_branches0718 copies separate cover ceiling four_gamma_check0718 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0718, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0719 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0720 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0721 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0722 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0723 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0724 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0725 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0726 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0708 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0708 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0708 ((6 : Int),(1 : Int)) four_gamma_branches0708 copies separate cover ceiling four_gamma_check0708 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0708, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0709 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0718 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0729 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0729 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0729 ((2 : Int),(6 : Int)) four_gamma_branches0729 copies separate cover ceiling four_gamma_check0729 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0729, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0730 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0730 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0730 ((2 : Int),(6 : Int)) four_gamma_branches0730 copies separate cover ceiling four_gamma_check0730 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0730, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0731 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0731 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0731 ((2 : Int),(6 : Int)) four_gamma_branches0731 copies separate cover ceiling four_gamma_check0731 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0731, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0732 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0732 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0732 ((2 : Int),(6 : Int)) four_gamma_branches0732 copies separate cover ceiling four_gamma_check0732 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0732, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0733 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0733 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0733 ((2 : Int),(6 : Int)) four_gamma_branches0733 copies separate cover ceiling four_gamma_check0733 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0733, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0734 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0734 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0734 ((2 : Int),(6 : Int)) four_gamma_branches0734 copies separate cover ceiling four_gamma_check0734 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0734, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0735 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0735 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0735 ((2 : Int),(6 : Int)) four_gamma_branches0735 copies separate cover ceiling four_gamma_check0735 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0735, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0736 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0736 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0736 ((2 : Int),(6 : Int)) four_gamma_branches0736 copies separate cover ceiling four_gamma_check0736 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0736, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0728 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0728 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0728 ((0 : Int),(8 : Int)) four_gamma_branches0728 copies separate cover ceiling four_gamma_check0728 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0728, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0729 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0730 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0731 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0732 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0733 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0734 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0735 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0736 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0738 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0738 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0738 ((2 : Int),(6 : Int)) four_gamma_branches0738 copies separate cover ceiling four_gamma_check0738 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0738, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0739 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0739 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0739 ((2 : Int),(6 : Int)) four_gamma_branches0739 copies separate cover ceiling four_gamma_check0739 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0739, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0740 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0740 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0740 ((2 : Int),(6 : Int)) four_gamma_branches0740 copies separate cover ceiling four_gamma_check0740 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0740, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0741 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0741 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0741 ((2 : Int),(6 : Int)) four_gamma_branches0741 copies separate cover ceiling four_gamma_check0741 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0741, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0742 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0742 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0742 ((2 : Int),(6 : Int)) four_gamma_branches0742 copies separate cover ceiling four_gamma_check0742 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0742, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0743 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0743 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0743 ((2 : Int),(6 : Int)) four_gamma_branches0743 copies separate cover ceiling four_gamma_check0743 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0743, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0744 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0744 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0744 ((2 : Int),(6 : Int)) four_gamma_branches0744 copies separate cover ceiling four_gamma_check0744 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0744, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0745 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0745 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0745 ((2 : Int),(6 : Int)) four_gamma_branches0745 copies separate cover ceiling four_gamma_check0745 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0745, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0737 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0737 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0737 ((0 : Int),(8 : Int)) four_gamma_branches0737 copies separate cover ceiling four_gamma_check0737 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0737, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0738 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0739 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0740 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0741 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0742 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0743 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0744 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0745 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0727 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0727 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0727 ((6 : Int),(1 : Int)) four_gamma_branches0727 copies separate cover ceiling four_gamma_check0727 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0727, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0728 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0737 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0707 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0707 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0707 ((4 : Int),(3 : Int)) four_gamma_branches0707 copies separate cover ceiling four_gamma_check0707 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0707, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0708 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0727 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0749 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0749 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0749 ((2 : Int),(6 : Int)) four_gamma_branches0749 copies separate cover ceiling four_gamma_check0749 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0749, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0750 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0750 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0750 ((2 : Int),(6 : Int)) four_gamma_branches0750 copies separate cover ceiling four_gamma_check0750 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0750, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0751 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0751 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0751 ((2 : Int),(6 : Int)) four_gamma_branches0751 copies separate cover ceiling four_gamma_check0751 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0751, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0752 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0752 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0752 ((2 : Int),(6 : Int)) four_gamma_branches0752 copies separate cover ceiling four_gamma_check0752 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0752, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0753 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0753 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0753 ((2 : Int),(6 : Int)) four_gamma_branches0753 copies separate cover ceiling four_gamma_check0753 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0753, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0754 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0754 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0754 ((2 : Int),(6 : Int)) four_gamma_branches0754 copies separate cover ceiling four_gamma_check0754 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0754, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0748 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0748 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0748 ((0 : Int),(8 : Int)) four_gamma_branches0748 copies separate cover ceiling four_gamma_check0748 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0748, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0749 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0750 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0751 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0752 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0753 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0754 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0756 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0756 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0756 ((2 : Int),(6 : Int)) four_gamma_branches0756 copies separate cover ceiling four_gamma_check0756 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0756, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0757 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0757 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0757 ((2 : Int),(6 : Int)) four_gamma_branches0757 copies separate cover ceiling four_gamma_check0757 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0757, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0758 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0758 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0758 ((2 : Int),(6 : Int)) four_gamma_branches0758 copies separate cover ceiling four_gamma_check0758 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0758, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0759 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0759 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0759 ((2 : Int),(6 : Int)) four_gamma_branches0759 copies separate cover ceiling four_gamma_check0759 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0759, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0760 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0760 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0760 ((2 : Int),(6 : Int)) four_gamma_branches0760 copies separate cover ceiling four_gamma_check0760 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0760, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0761 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0761 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0761 ((2 : Int),(6 : Int)) four_gamma_branches0761 copies separate cover ceiling four_gamma_check0761 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0761, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0755 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0755 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0755 ((0 : Int),(8 : Int)) four_gamma_branches0755 copies separate cover ceiling four_gamma_check0755 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0755, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0756 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0757 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0758 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0759 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0760 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0761 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0747 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0747 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0747 ((6 : Int),(1 : Int)) four_gamma_branches0747 copies separate cover ceiling four_gamma_check0747 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0747, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0748 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0755 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0764 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0764 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0764 ((2 : Int),(6 : Int)) four_gamma_branches0764 copies separate cover ceiling four_gamma_check0764 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0764, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0765 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0765 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0765 ((2 : Int),(6 : Int)) four_gamma_branches0765 copies separate cover ceiling four_gamma_check0765 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0765, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0766 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0766 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0766 ((2 : Int),(6 : Int)) four_gamma_branches0766 copies separate cover ceiling four_gamma_check0766 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0766, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0767 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0767 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0767 ((2 : Int),(6 : Int)) four_gamma_branches0767 copies separate cover ceiling four_gamma_check0767 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0767, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0768 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0768 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0768 ((2 : Int),(6 : Int)) four_gamma_branches0768 copies separate cover ceiling four_gamma_check0768 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0768, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0769 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0769 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0769 ((2 : Int),(6 : Int)) four_gamma_branches0769 copies separate cover ceiling four_gamma_check0769 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0769, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0763 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0763 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0763 ((0 : Int),(8 : Int)) four_gamma_branches0763 copies separate cover ceiling four_gamma_check0763 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0763, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0764 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0765 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0766 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0767 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0768 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0769 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0771 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0771 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0771 ((2 : Int),(6 : Int)) four_gamma_branches0771 copies separate cover ceiling four_gamma_check0771 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0771, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0772 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0772 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0772 ((2 : Int),(6 : Int)) four_gamma_branches0772 copies separate cover ceiling four_gamma_check0772 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0772, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0773 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0773 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0773 ((2 : Int),(6 : Int)) four_gamma_branches0773 copies separate cover ceiling four_gamma_check0773 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0773, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0774 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0774 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0774 ((2 : Int),(6 : Int)) four_gamma_branches0774 copies separate cover ceiling four_gamma_check0774 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0774, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0775 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0775 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0775 ((2 : Int),(6 : Int)) four_gamma_branches0775 copies separate cover ceiling four_gamma_check0775 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0775, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0776 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0776 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0776 ((2 : Int),(6 : Int)) four_gamma_branches0776 copies separate cover ceiling four_gamma_check0776 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0776, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0770 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0770 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0770 ((0 : Int),(8 : Int)) four_gamma_branches0770 copies separate cover ceiling four_gamma_check0770 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0770, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0771 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0772 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0773 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0774 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0775 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0776 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0762 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0762 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0762 ((6 : Int),(1 : Int)) four_gamma_branches0762 copies separate cover ceiling four_gamma_check0762 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0762, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0763 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0770 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0746 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0746 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0746 ((4 : Int),(3 : Int)) four_gamma_branches0746 copies separate cover ceiling four_gamma_check0746 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0746, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0747 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0762 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0780 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0780 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0780 ((2 : Int),(6 : Int)) four_gamma_branches0780 copies separate cover ceiling four_gamma_check0780 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0780, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0781 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0781 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0781 ((2 : Int),(6 : Int)) four_gamma_branches0781 copies separate cover ceiling four_gamma_check0781 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0781, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0782 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0782 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0782 ((2 : Int),(6 : Int)) four_gamma_branches0782 copies separate cover ceiling four_gamma_check0782 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0782, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0779 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0779 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0779 ((0 : Int),(8 : Int)) four_gamma_branches0779 copies separate cover ceiling four_gamma_check0779 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0779, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0780 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0781 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0782 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0784 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0784 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0784 ((2 : Int),(6 : Int)) four_gamma_branches0784 copies separate cover ceiling four_gamma_check0784 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0784, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0785 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0785 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0785 ((2 : Int),(6 : Int)) four_gamma_branches0785 copies separate cover ceiling four_gamma_check0785 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0785, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0786 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0786 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0786 ((2 : Int),(6 : Int)) four_gamma_branches0786 copies separate cover ceiling four_gamma_check0786 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0786, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0783 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0783 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0783 ((0 : Int),(8 : Int)) four_gamma_branches0783 copies separate cover ceiling four_gamma_check0783 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0783, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0784 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0785 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0786 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0778 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0778 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0778 ((6 : Int),(1 : Int)) four_gamma_branches0778 copies separate cover ceiling four_gamma_check0778 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0778, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0779 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0783 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0789 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0789 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0789 ((2 : Int),(6 : Int)) four_gamma_branches0789 copies separate cover ceiling four_gamma_check0789 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0789, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0790 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0790 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0790 ((2 : Int),(6 : Int)) four_gamma_branches0790 copies separate cover ceiling four_gamma_check0790 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0790, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0791 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0791 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0791 ((2 : Int),(6 : Int)) four_gamma_branches0791 copies separate cover ceiling four_gamma_check0791 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0791, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0788 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0788 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0788 ((0 : Int),(8 : Int)) four_gamma_branches0788 copies separate cover ceiling four_gamma_check0788 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0788, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0789 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0790 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0791 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0793 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0793 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0793 ((2 : Int),(6 : Int)) four_gamma_branches0793 copies separate cover ceiling four_gamma_check0793 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0793, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0794 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0794 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0794 ((2 : Int),(6 : Int)) four_gamma_branches0794 copies separate cover ceiling four_gamma_check0794 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0794, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0795 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0795 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0795 ((2 : Int),(6 : Int)) four_gamma_branches0795 copies separate cover ceiling four_gamma_check0795 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0795, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0792 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0792 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0792 ((0 : Int),(8 : Int)) four_gamma_branches0792 copies separate cover ceiling four_gamma_check0792 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0792, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0793 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0794 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0795 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0787 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0787 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0787 ((6 : Int),(1 : Int)) four_gamma_branches0787 copies separate cover ceiling four_gamma_check0787 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0787, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0788 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0792 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0777 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0777 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0777 ((4 : Int),(3 : Int)) four_gamma_branches0777 copies separate cover ceiling four_gamma_check0777 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0777, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0778 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0787 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0798 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0798 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0798 ((2 : Int),(6 : Int)) four_gamma_branches0798 copies separate cover ceiling four_gamma_check0798 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0798, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0799 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0799 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0799 ((2 : Int),(6 : Int)) four_gamma_branches0799 copies separate cover ceiling four_gamma_check0799 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0799, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0797 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0797 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0797 ((6 : Int),(1 : Int)) four_gamma_branches0797 copies separate cover ceiling four_gamma_check0797 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0797, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0798 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0799 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0801 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0801 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0801 ((2 : Int),(6 : Int)) four_gamma_branches0801 copies separate cover ceiling four_gamma_check0801 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0801, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0802 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0802 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0802 ((2 : Int),(6 : Int)) four_gamma_branches0802 copies separate cover ceiling four_gamma_check0802 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0802, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0800 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0800 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0800 ((6 : Int),(1 : Int)) four_gamma_branches0800 copies separate cover ceiling four_gamma_check0800 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0800, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0801 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0802 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0796 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0796 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0796 ((4 : Int),(3 : Int)) four_gamma_branches0796 copies separate cover ceiling four_gamma_check0796 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0796, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0797 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0800 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0805 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0805 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0805 ((2 : Int),(6 : Int)) four_gamma_branches0805 copies separate cover ceiling four_gamma_check0805 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0805, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0806 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0806 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0806 ((2 : Int),(6 : Int)) four_gamma_branches0806 copies separate cover ceiling four_gamma_check0806 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0806, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0804 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0804 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0804 ((6 : Int),(1 : Int)) four_gamma_branches0804 copies separate cover ceiling four_gamma_check0804 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0804, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0805 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0806 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0808 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0808 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0808 ((2 : Int),(6 : Int)) four_gamma_branches0808 copies separate cover ceiling four_gamma_check0808 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0808, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0809 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0809 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0809 ((2 : Int),(6 : Int)) four_gamma_branches0809 copies separate cover ceiling four_gamma_check0809 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0809, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0807 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0807 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0807 ((6 : Int),(1 : Int)) four_gamma_branches0807 copies separate cover ceiling four_gamma_check0807 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0807, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0808 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0809 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0803 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0803 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0803 ((4 : Int),(3 : Int)) four_gamma_branches0803 copies separate cover ceiling four_gamma_check0803 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0803, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0804 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0807 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0812 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0812 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0812 ((2 : Int),(6 : Int)) four_gamma_branches0812 copies separate cover ceiling four_gamma_check0812 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0812, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0813 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0813 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0813 ((2 : Int),(6 : Int)) four_gamma_branches0813 copies separate cover ceiling four_gamma_check0813 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0813, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0811 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0811 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0811 ((6 : Int),(1 : Int)) four_gamma_branches0811 copies separate cover ceiling four_gamma_check0811 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0811, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0812 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0813 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0815 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0815 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0815 ((2 : Int),(6 : Int)) four_gamma_branches0815 copies separate cover ceiling four_gamma_check0815 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0815, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0816 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0816 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0816 ((2 : Int),(6 : Int)) four_gamma_branches0816 copies separate cover ceiling four_gamma_check0816 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0816, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0814 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0814 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0814 ((6 : Int),(1 : Int)) four_gamma_branches0814 copies separate cover ceiling four_gamma_check0814 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0814, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0815 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0816 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0810 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0810 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0810 ((4 : Int),(3 : Int)) four_gamma_branches0810 copies separate cover ceiling four_gamma_check0810 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0810, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0811 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0814 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0636 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0636 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0636 ((0 : Int),(7 : Int)) four_gamma_branches0636 copies separate cover ceiling four_gamma_check0636 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0636, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0637 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0676 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0707 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0746 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0777 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0796 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0803 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0810 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0819 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0819 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0819 ((4 : Int),(3 : Int)) four_gamma_branches0819 copies separate cover ceiling four_gamma_check0819 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0819, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0820 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0820 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0820 ((4 : Int),(3 : Int)) four_gamma_branches0820 copies separate cover ceiling four_gamma_check0820 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0820, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0821 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0821 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0821 ((4 : Int),(3 : Int)) four_gamma_branches0821 copies separate cover ceiling four_gamma_check0821 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0821, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0822 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0822 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0822 ((4 : Int),(3 : Int)) four_gamma_branches0822 copies separate cover ceiling four_gamma_check0822 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0822, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0823 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0823 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0823 ((4 : Int),(3 : Int)) four_gamma_branches0823 copies separate cover ceiling four_gamma_check0823 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0823, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0824 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0824 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0824 ((4 : Int),(3 : Int)) four_gamma_branches0824 copies separate cover ceiling four_gamma_check0824 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0824, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0825 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0825 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0825 ((4 : Int),(3 : Int)) four_gamma_branches0825 copies separate cover ceiling four_gamma_check0825 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0825, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0826 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0826 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0826 ((4 : Int),(3 : Int)) four_gamma_branches0826 copies separate cover ceiling four_gamma_check0826 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0826, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0818 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0818 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0818 ((0 : Int),(7 : Int)) four_gamma_branches0818 copies separate cover ceiling four_gamma_check0818 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0818, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0819 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0820 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0821 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0822 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0823 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0824 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0825 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0826 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0817 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0817 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0817 ((5 : Int),(1 : Int)) four_gamma_branches0817 copies separate cover ceiling four_gamma_check0817 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0817, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact four_gamma_node0818 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0827 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0827 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0827 ((5 : Int),(1 : Int)) four_gamma_branches0827 copies separate cover ceiling four_gamma_check0827 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0827, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0830 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0830 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0830 ((4 : Int),(3 : Int)) four_gamma_branches0830 copies separate cover ceiling four_gamma_check0830 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0830, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0831 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0831 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0831 ((4 : Int),(3 : Int)) four_gamma_branches0831 copies separate cover ceiling four_gamma_check0831 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0831, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0832 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0832 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0832 ((4 : Int),(3 : Int)) four_gamma_branches0832 copies separate cover ceiling four_gamma_check0832 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0832, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0833 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0833 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0833 ((4 : Int),(3 : Int)) four_gamma_branches0833 copies separate cover ceiling four_gamma_check0833 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0833, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0834 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0834 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0834 ((4 : Int),(3 : Int)) four_gamma_branches0834 copies separate cover ceiling four_gamma_check0834 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0834, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0835 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0835 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0835 ((4 : Int),(3 : Int)) four_gamma_branches0835 copies separate cover ceiling four_gamma_check0835 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0835, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0836 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0836 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0836 ((4 : Int),(3 : Int)) four_gamma_branches0836 copies separate cover ceiling four_gamma_check0836 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0836, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0837 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0837 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0837 ((4 : Int),(3 : Int)) four_gamma_branches0837 copies separate cover ceiling four_gamma_check0837 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0837, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0829 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0829 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0829 ((0 : Int),(7 : Int)) four_gamma_branches0829 copies separate cover ceiling four_gamma_check0829 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0829, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0830 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0831 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0832 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0833 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0834 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0835 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0836 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0837 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0828 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0828 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0828 ((5 : Int),(1 : Int)) four_gamma_branches0828 copies separate cover ceiling four_gamma_check0828 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0828, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact four_gamma_node0829 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0626 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0626 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0626 ((4 : Int),(2 : Int)) four_gamma_branches0626 copies separate cover ceiling four_gamma_check0626 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0626, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0627 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0636 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0817 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0827 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0828 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0624 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0624 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0624 ((3 : Int),(1 : Int)) four_gamma_branches0624 copies separate cover ceiling four_gamma_check0624 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0624, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0625 world h nextB nextState
  · exact four_gamma_node0626 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0443 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0443 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0443 ((1 : Int),(3 : Int)) four_gamma_branches0443 copies separate cover ceiling four_gamma_check0443 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0443, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0444 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0624 world h copies separate cover ceiling nextB nextState
theorem four_gamma_node0838 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0838 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma four_gamma_occ0838 .alpha (3 : Int) (1 : Int) four_gamma_check0838 B state
include copies separate cover ceiling in
theorem four_gamma_node0841 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0841 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0841 ((4 : Int),(1 : Int)) four_gamma_branches0841 copies separate cover ceiling four_gamma_check0841 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0841, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0842 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0842 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0842 ((4 : Int),(1 : Int)) four_gamma_branches0842 copies separate cover ceiling four_gamma_check0842 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0842, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0840 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0840 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0840 ((3 : Int),(1 : Int)) four_gamma_branches0840 copies separate cover ceiling four_gamma_check0840 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0840, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0841 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0842 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0844 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0844 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0844 ((4 : Int),(1 : Int)) four_gamma_branches0844 copies separate cover ceiling four_gamma_check0844 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0844, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0845 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0845 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0845 ((4 : Int),(1 : Int)) four_gamma_branches0845 copies separate cover ceiling four_gamma_check0845 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0845, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0843 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0843 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0843 ((3 : Int),(1 : Int)) four_gamma_branches0843 copies separate cover ceiling four_gamma_check0843 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0843, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0844 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0845 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0839 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0839 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0839 ((1 : Int),(3 : Int)) four_gamma_branches0839 copies separate cover ceiling four_gamma_check0839 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0839, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0840 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0843 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0003 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0003 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0003 ((3 : Int),(0 : Int)) four_gamma_branches0003 copies separate cover ceiling four_gamma_check0003 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0003, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0004 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0430 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0443 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0838 world h nextB nextState
  · exact four_gamma_node0839 world h copies separate cover ceiling nextB nextState
theorem four_gamma_node0846 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0846 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma four_gamma_occ0846 .beta (1 : Int) (2 : Int) four_gamma_check0846 B state
theorem four_gamma_node0847 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0847 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma four_gamma_occ0847 .gamma (1 : Int) (2 : Int) four_gamma_check0847 B state
theorem four_gamma_node0848 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0848 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma four_gamma_occ0848 .beta (1 : Int) (2 : Int) four_gamma_check0848 B state
include copies separate cover ceiling in
theorem four_gamma_node0852 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0852 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0852 ((3 : Int),(2 : Int)) four_gamma_branches0852 copies separate cover ceiling four_gamma_check0852 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0852, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0853 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0853 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0853 ((3 : Int),(2 : Int)) four_gamma_branches0853 copies separate cover ceiling four_gamma_check0853 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0853, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0851 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0851 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0851 ((2 : Int),(2 : Int)) four_gamma_branches0851 copies separate cover ceiling four_gamma_check0851 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0851, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0852 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0853 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0854 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0854 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0854 ((2 : Int),(2 : Int)) four_gamma_branches0854 copies separate cover ceiling four_gamma_check0854 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0854, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0855 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0855 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0855 ((2 : Int),(2 : Int)) four_gamma_branches0855 copies separate cover ceiling four_gamma_check0855 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0855, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0858 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0858 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0858 ((4 : Int),(2 : Int)) four_gamma_branches0858 copies separate cover ceiling four_gamma_check0858 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0858, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0859 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0859 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0859 ((4 : Int),(2 : Int)) four_gamma_branches0859 copies separate cover ceiling four_gamma_check0859 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0859, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0857 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0857 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0857 ((3 : Int),(2 : Int)) four_gamma_branches0857 copies separate cover ceiling four_gamma_check0857 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0857, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0858 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0859 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0861 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0861 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0861 ((4 : Int),(2 : Int)) four_gamma_branches0861 copies separate cover ceiling four_gamma_check0861 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0861, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0862 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0862 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0862 ((4 : Int),(2 : Int)) four_gamma_branches0862 copies separate cover ceiling four_gamma_check0862 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0862, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0860 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0860 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0860 ((3 : Int),(2 : Int)) four_gamma_branches0860 copies separate cover ceiling four_gamma_check0860 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0860, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0861 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0862 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0856 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0856 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0856 ((1 : Int),(4 : Int)) four_gamma_branches0856 copies separate cover ceiling four_gamma_check0856 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0856, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0857 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0860 world h copies separate cover ceiling nextB nextState
theorem four_gamma_node0864 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0864 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma four_gamma_occ0864 .alpha (2 : Int) (4 : Int) four_gamma_check0864 B state
include copies separate cover ceiling in
theorem four_gamma_node0865 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0865 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0865 ((3 : Int),(2 : Int)) four_gamma_branches0865 copies separate cover ceiling four_gamma_check0865 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0865, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0866 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0866 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0866 ((3 : Int),(2 : Int)) four_gamma_branches0866 copies separate cover ceiling four_gamma_check0866 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0866, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0867 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0867 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0867 ((3 : Int),(2 : Int)) four_gamma_branches0867 copies separate cover ceiling four_gamma_check0867 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0867, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0868 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0868 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0868 ((3 : Int),(2 : Int)) four_gamma_branches0868 copies separate cover ceiling four_gamma_check0868 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0868, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0863 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0863 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0863 ((1 : Int),(4 : Int)) four_gamma_branches0863 copies separate cover ceiling four_gamma_check0863 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0863, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0864 world h nextB nextState
  · exact four_gamma_node0865 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0866 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0867 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0868 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0869 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0869 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0869 ((2 : Int),(2 : Int)) four_gamma_branches0869 copies separate cover ceiling four_gamma_check0869 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0869, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0870 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0870 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0870 ((2 : Int),(2 : Int)) four_gamma_branches0870 copies separate cover ceiling four_gamma_check0870 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0870, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0850 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0850 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0850 ((1 : Int),(3 : Int)) four_gamma_branches0850 copies separate cover ceiling four_gamma_check0850 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0850, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0851 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0854 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0855 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0856 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0863 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0869 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0870 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0849 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0849 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0849 ((2 : Int),(0 : Int)) four_gamma_branches0849 copies separate cover ceiling four_gamma_check0849 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0849, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact four_gamma_node0850 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0002 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0002 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0002 ((1 : Int),(1 : Int)) four_gamma_branches0002 copies separate cover ceiling four_gamma_check0002 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0002, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0003 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0846 world h nextB nextState
  · exact four_gamma_node0847 world h nextB nextState
  · exact four_gamma_node0848 world h nextB nextState
  · exact four_gamma_node0849 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0872 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0872 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0872 ((1 : Int),(2 : Int)) four_gamma_branches0872 copies separate cover ceiling four_gamma_check0872 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0872, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0875 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0875 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0875 ((1 : Int),(3 : Int)) four_gamma_branches0875 copies separate cover ceiling four_gamma_check0875 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0875, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0876 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0876 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0876 ((1 : Int),(3 : Int)) four_gamma_branches0876 copies separate cover ceiling four_gamma_check0876 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0876, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0874 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0874 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0874 ((3 : Int),(0 : Int)) four_gamma_branches0874 copies separate cover ceiling four_gamma_check0874 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0874, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0875 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0876 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0878 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0878 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0878 ((1 : Int),(3 : Int)) four_gamma_branches0878 copies separate cover ceiling four_gamma_check0878 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0878, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0879 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0879 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0879 ((1 : Int),(3 : Int)) four_gamma_branches0879 copies separate cover ceiling four_gamma_check0879 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0879, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0877 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0877 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0877 ((3 : Int),(0 : Int)) four_gamma_branches0877 copies separate cover ceiling four_gamma_check0877 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0877, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0878 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0879 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0873 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0873 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0873 ((1 : Int),(2 : Int)) four_gamma_branches0873 copies separate cover ceiling four_gamma_check0873 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0873, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0874 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0877 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0881 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0881 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0881 ((1 : Int),(2 : Int)) four_gamma_branches0881 copies separate cover ceiling four_gamma_check0881 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0881, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0880 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0880 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0880 ((2 : Int),(0 : Int)) four_gamma_branches0880 copies separate cover ceiling four_gamma_check0880 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0880, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact four_gamma_node0881 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0882 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0882 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0882 ((2 : Int),(0 : Int)) four_gamma_branches0882 copies separate cover ceiling four_gamma_check0882 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0882, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0884 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0884 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0884 ((1 : Int),(2 : Int)) four_gamma_branches0884 copies separate cover ceiling four_gamma_check0884 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0884, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0883 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0883 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0883 ((2 : Int),(0 : Int)) four_gamma_branches0883 copies separate cover ceiling four_gamma_check0883 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0883, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact four_gamma_node0884 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0871 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0871 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0871 ((1 : Int),(1 : Int)) four_gamma_branches0871 copies separate cover ceiling four_gamma_check0871 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0871, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0872 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0873 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0880 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0882 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0883 world h copies separate cover ceiling nextB nextState
theorem four_gamma_node0886 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0886 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma four_gamma_occ0886 .betaTranspose (1 : Int) (2 : Int) four_gamma_check0886 B state
theorem four_gamma_node0887 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0887 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma four_gamma_occ0887 .gammaTranspose (1 : Int) (2 : Int) four_gamma_check0887 B state
include copies separate cover ceiling in
theorem four_gamma_node0890 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0890 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0890 ((1 : Int),(4 : Int)) four_gamma_branches0890 copies separate cover ceiling four_gamma_check0890 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0890, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0893 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0893 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0893 ((1 : Int),(5 : Int)) four_gamma_branches0893 copies separate cover ceiling four_gamma_check0893 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0893, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0894 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0894 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0894 ((1 : Int),(5 : Int)) four_gamma_branches0894 copies separate cover ceiling four_gamma_check0894 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0894, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0892 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0892 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0892 ((3 : Int),(2 : Int)) four_gamma_branches0892 copies separate cover ceiling four_gamma_check0892 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0892, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0893 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0894 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0896 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0896 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0896 ((1 : Int),(5 : Int)) four_gamma_branches0896 copies separate cover ceiling four_gamma_check0896 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0896, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0897 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0897 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0897 ((1 : Int),(5 : Int)) four_gamma_branches0897 copies separate cover ceiling four_gamma_check0897 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0897, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0895 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0895 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0895 ((3 : Int),(2 : Int)) four_gamma_branches0895 copies separate cover ceiling four_gamma_check0895 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0895, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0896 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0897 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0891 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0891 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0891 ((1 : Int),(4 : Int)) four_gamma_branches0891 copies separate cover ceiling four_gamma_check0891 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0891, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0892 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0895 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0899 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0899 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0899 ((1 : Int),(4 : Int)) four_gamma_branches0899 copies separate cover ceiling four_gamma_check0899 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0899, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0898 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0898 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0898 ((2 : Int),(2 : Int)) four_gamma_branches0898 copies separate cover ceiling four_gamma_check0898 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0898, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact four_gamma_node0899 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0900 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0900 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0900 ((2 : Int),(2 : Int)) four_gamma_branches0900 copies separate cover ceiling four_gamma_check0900 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0900, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0902 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0902 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0902 ((1 : Int),(4 : Int)) four_gamma_branches0902 copies separate cover ceiling four_gamma_check0902 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0902, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0901 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0901 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0901 ((2 : Int),(2 : Int)) four_gamma_branches0901 copies separate cover ceiling four_gamma_check0901 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0901, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact four_gamma_node0902 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0889 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0889 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0889 ((1 : Int),(3 : Int)) four_gamma_branches0889 copies separate cover ceiling four_gamma_check0889 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0889, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0890 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0891 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0898 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0900 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0901 world h copies separate cover ceiling nextB nextState
theorem four_gamma_node0904 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0904 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma four_gamma_occ0904 .alpha (3 : Int) (2 : Int) four_gamma_check0904 B state
include copies separate cover ceiling in
theorem four_gamma_node0907 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0907 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0907 ((1 : Int),(5 : Int)) four_gamma_branches0907 copies separate cover ceiling four_gamma_check0907 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0907, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0908 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0908 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0908 ((1 : Int),(5 : Int)) four_gamma_branches0908 copies separate cover ceiling four_gamma_check0908 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0908, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0906 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0906 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0906 ((3 : Int),(2 : Int)) four_gamma_branches0906 copies separate cover ceiling four_gamma_check0906 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0906, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0907 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0908 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0910 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0910 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0910 ((1 : Int),(5 : Int)) four_gamma_branches0910 copies separate cover ceiling four_gamma_check0910 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0910, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0911 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0911 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0911 ((1 : Int),(5 : Int)) four_gamma_branches0911 copies separate cover ceiling four_gamma_check0911 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0911, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0909 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0909 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0909 ((3 : Int),(2 : Int)) four_gamma_branches0909 copies separate cover ceiling four_gamma_check0909 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0909, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0910 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0911 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0905 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0905 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0905 ((1 : Int),(4 : Int)) four_gamma_branches0905 copies separate cover ceiling four_gamma_check0905 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0905, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0906 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0909 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0912 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0912 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0912 ((2 : Int),(2 : Int)) four_gamma_branches0912 copies separate cover ceiling four_gamma_check0912 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0912, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0913 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0913 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0913 ((2 : Int),(2 : Int)) four_gamma_branches0913 copies separate cover ceiling four_gamma_check0913 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0913, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0914 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0914 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0914 ((2 : Int),(2 : Int)) four_gamma_branches0914 copies separate cover ceiling four_gamma_check0914 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0914, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0903 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0903 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0903 ((1 : Int),(3 : Int)) four_gamma_branches0903 copies separate cover ceiling four_gamma_check0903 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0903, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0904 world h nextB nextState
  · exact four_gamma_node0905 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0912 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0913 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0914 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0888 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0888 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0888 ((2 : Int),(0 : Int)) four_gamma_branches0888 copies separate cover ceiling four_gamma_check0888 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0888, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0889 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0903 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0885 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0885 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0885 ((0 : Int),(2 : Int)) four_gamma_branches0885 copies separate cover ceiling four_gamma_check0885 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0885, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0886 world h nextB nextState
  · exact four_gamma_node0887 world h nextB nextState
  · exact four_gamma_node0888 world h copies separate cover ceiling nextB nextState
theorem four_gamma_node0916 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0916 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma four_gamma_occ0916 .alpha (1 : Int) (2 : Int) four_gamma_check0916 B state
include copies separate cover ceiling in
theorem four_gamma_node0917 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0917 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0917 ((2 : Int),(0 : Int)) four_gamma_branches0917 copies separate cover ceiling four_gamma_check0917 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0917, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0918 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0918 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0918 ((2 : Int),(0 : Int)) four_gamma_branches0918 copies separate cover ceiling four_gamma_check0918 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0918, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0919 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0919 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0919 ((2 : Int),(0 : Int)) four_gamma_branches0919 copies separate cover ceiling four_gamma_check0919 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0919, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0920 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0920 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0920 ((2 : Int),(0 : Int)) four_gamma_branches0920 copies separate cover ceiling four_gamma_check0920 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0920, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0915 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0915 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0915 ((0 : Int),(2 : Int)) four_gamma_branches0915 copies separate cover ceiling four_gamma_check0915 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0915, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0916 world h nextB nextState
  · exact four_gamma_node0917 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0918 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0919 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0920 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0924 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0924 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0924 ((2 : Int),(2 : Int)) four_gamma_branches0924 copies separate cover ceiling four_gamma_check0924 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0924, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0925 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0925 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0925 ((2 : Int),(2 : Int)) four_gamma_branches0925 copies separate cover ceiling four_gamma_check0925 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0925, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0923 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0923 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0923 ((1 : Int),(2 : Int)) four_gamma_branches0923 copies separate cover ceiling four_gamma_check0923 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0923, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0924 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0925 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0927 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0927 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0927 ((2 : Int),(2 : Int)) four_gamma_branches0927 copies separate cover ceiling four_gamma_check0927 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0927, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0928 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0928 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0928 ((2 : Int),(2 : Int)) four_gamma_branches0928 copies separate cover ceiling four_gamma_check0928 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0928, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0926 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0926 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0926 ((1 : Int),(2 : Int)) four_gamma_branches0926 copies separate cover ceiling four_gamma_check0926 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0926, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0927 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0928 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0922 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0922 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0922 ((2 : Int),(0 : Int)) four_gamma_branches0922 copies separate cover ceiling four_gamma_check0922 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0922, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0923 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0926 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0930 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0930 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0930 ((1 : Int),(2 : Int)) four_gamma_branches0930 copies separate cover ceiling four_gamma_check0930 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0930, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0931 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0931 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0931 ((1 : Int),(2 : Int)) four_gamma_branches0931 copies separate cover ceiling four_gamma_check0931 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0931, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0929 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0929 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0929 ((2 : Int),(0 : Int)) four_gamma_branches0929 copies separate cover ceiling four_gamma_check0929 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0929, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0930 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0931 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0933 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0933 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0933 ((1 : Int),(2 : Int)) four_gamma_branches0933 copies separate cover ceiling four_gamma_check0933 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0933, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0934 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0934 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0934 ((1 : Int),(2 : Int)) four_gamma_branches0934 copies separate cover ceiling four_gamma_check0934 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0934, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_gamma_node0932 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0932 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0932 ((2 : Int),(0 : Int)) four_gamma_branches0932 copies separate cover ceiling four_gamma_check0932 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0932, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_gamma_node0933 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0934 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0921 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0921 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0921 ((0 : Int),(2 : Int)) four_gamma_branches0921 copies separate cover ceiling four_gamma_check0921 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0921, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_gamma_node0922 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0929 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0932 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_gamma_node0000 (B : Int → Int → Prop)
    (state : State world h four_gamma_occ0000 B) : Transition world h .gamma B := by
  apply replay_step (4 : Int) (by decide) world h .gamma four_gamma_occ0000 ((0 : Int),(1 : Int)) four_gamma_branches0000 copies separate cover ceiling four_gamma_check0000 ?_ B state
  intro branch member nextB nextState
  simp only [four_gamma_branches0000, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_gamma_node0001 world h nextB nextState
  · exact four_gamma_node0002 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0871 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0885 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0915 world h copies separate cover ceiling nextB nextState
  · exact four_gamma_node0921 world h copies separate cover ceiling nextB nextState
end FourGamma

theorem four_gamma_seed_eq : SameCells (seed .gamma) four_gamma_occ0000 := by decide

theorem four_gamma_local (world : Cross → Prop) (h : Int) (B : Int → Int → Prop)
    (copies : ∀ t, world t → Copy 4 1 1 0 t)
    (separate : DisjointWorld world) (cover : CoversWindow world h)
    (ceiling : SelectedBelow world h) (closed : TileClosed world B)
    (bounded : Below h B) (clean : Clean .gamma 0 0 B) :
    Transition world h .gamma B := by
  exact four_gamma_node0000 world h copies separate cover ceiling B
    (state_congr four_gamma_seed_eq (seed_state world h .gamma B closed bounded clean))
#print axioms four_gamma_local

end CornerCertificate

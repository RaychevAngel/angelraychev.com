import HPFiniteA4B4Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
namespace THalfPlaneFinite
open CrossUnits PolyominoFormal

theorem hp4_4_node955 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected955 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected955 ((7 : Int),(1 : Int)) hp4_4_branches955 hp4_4_evidence955 hp4_4_check955 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches955,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node954 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected954 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected954 ((5 : Int),(1 : Int)) hp4_4_branches954 hp4_4_evidence954 hp4_4_check954 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches954,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node953 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected953 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected953 ((5 : Int),(1 : Int)) hp4_4_branches953 hp4_4_evidence953 hp4_4_check953 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches953,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node952 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected952 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected952 ((5 : Int),(1 : Int)) hp4_4_branches952 hp4_4_evidence952 hp4_4_check952 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches952,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node951 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected951 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected951 ((6 : Int),(1 : Int)) hp4_4_branches951 hp4_4_evidence951 hp4_4_check951 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches951,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node952 T childKnown
  · exact hp4_4_node953 T childKnown
  · exact hp4_4_node954 T childKnown
  · exact hp4_4_node955 T childKnown
theorem hp4_4_node950 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected950 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected950 ((6 : Int),(1 : Int)) hp4_4_branches950 hp4_4_evidence950 hp4_4_check950 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches950,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node949 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected949 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected949 ((6 : Int),(1 : Int)) hp4_4_branches949 hp4_4_evidence949 hp4_4_check949 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches949,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node948 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected948 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected948 ((6 : Int),(1 : Int)) hp4_4_branches948 hp4_4_evidence948 hp4_4_check948 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches948,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node947 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected947 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected947 ((1 : Int),(2 : Int)) hp4_4_branches947 hp4_4_evidence947 hp4_4_check947 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches947,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node946 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected946 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected946 ((1 : Int),(2 : Int)) hp4_4_branches946 hp4_4_evidence946 hp4_4_check946 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches946,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node945 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected945 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected945 ((3 : Int),(1 : Int)) hp4_4_branches945 hp4_4_evidence945 hp4_4_check945 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches945,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node946 T childKnown
  · exact hp4_4_node947 T childKnown
theorem hp4_4_node944 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected944 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected944 ((6 : Int),(1 : Int)) hp4_4_branches944 hp4_4_evidence944 hp4_4_check944 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches944,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node945 T childKnown
theorem hp4_4_node943 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected943 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected943 ((5 : Int),(1 : Int)) hp4_4_branches943 hp4_4_evidence943 hp4_4_check943 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches943,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node944 T childKnown
  · exact hp4_4_node948 T childKnown
  · exact hp4_4_node949 T childKnown
  · exact hp4_4_node950 T childKnown
theorem hp4_4_node942 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected942 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected942 ((7 : Int),(1 : Int)) hp4_4_branches942 hp4_4_evidence942 hp4_4_check942 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches942,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node941 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected941 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected941 ((7 : Int),(0 : Int)) hp4_4_branches941 hp4_4_evidence941 hp4_4_check941 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches941,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node942 T childKnown
theorem hp4_4_node940 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected940 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected940 ((5 : Int),(1 : Int)) hp4_4_branches940 hp4_4_evidence940 hp4_4_check940 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches940,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node941 T childKnown
theorem hp4_4_node939 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected939 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected939 ((1 : Int),(2 : Int)) hp4_4_branches939 hp4_4_evidence939 hp4_4_check939 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches939,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node938 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected938 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected938 ((1 : Int),(2 : Int)) hp4_4_branches938 hp4_4_evidence938 hp4_4_check938 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches938,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node937 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected937 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected937 ((3 : Int),(1 : Int)) hp4_4_branches937 hp4_4_evidence937 hp4_4_check937 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches937,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node938 T childKnown
  · exact hp4_4_node939 T childKnown
theorem hp4_4_node936 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected936 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected936 ((7 : Int),(0 : Int)) hp4_4_branches936 hp4_4_evidence936 hp4_4_check936 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches936,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node937 T childKnown
theorem hp4_4_node935 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected935 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected935 ((5 : Int),(1 : Int)) hp4_4_branches935 hp4_4_evidence935 hp4_4_check935 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches935,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node936 T childKnown
theorem hp4_4_node934 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected934 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected934 ((5 : Int),(1 : Int)) hp4_4_branches934 hp4_4_evidence934 hp4_4_check934 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches934,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node933 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected933 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected933 ((6 : Int),(0 : Int)) hp4_4_branches933 hp4_4_evidence933 hp4_4_check933 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches933,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node934 T childKnown
  · exact hp4_4_node935 T childKnown
  · exact hp4_4_node940 T childKnown
  · exact hp4_4_node943 T childKnown
  · exact hp4_4_node951 T childKnown
theorem hp4_4_node932 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected932 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected932 ((2 : Int),(2 : Int)) hp4_4_branches932 hp4_4_evidence932 hp4_4_check932 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches932,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node931 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected931 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected931 ((2 : Int),(2 : Int)) hp4_4_branches931 hp4_4_evidence931 hp4_4_check931 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches931,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node930 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected930 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected930 ((2 : Int),(1 : Int)) hp4_4_branches930 hp4_4_evidence930 hp4_4_check930 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches930,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node931 T childKnown
  · exact hp4_4_node932 T childKnown
theorem hp4_4_node929 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected929 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected929 ((2 : Int),(2 : Int)) hp4_4_branches929 hp4_4_evidence929 hp4_4_check929 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches929,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node928 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected928 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected928 ((2 : Int),(2 : Int)) hp4_4_branches928 hp4_4_evidence928 hp4_4_check928 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches928,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node927 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected927 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected927 ((2 : Int),(1 : Int)) hp4_4_branches927 hp4_4_evidence927 hp4_4_check927 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches927,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node928 T childKnown
  · exact hp4_4_node929 T childKnown
theorem hp4_4_node926 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected926 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected926 ((9 : Int),(1 : Int)) hp4_4_branches926 hp4_4_evidence926 hp4_4_check926 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches926,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node925 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected925 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected925 ((7 : Int),(2 : Int)) hp4_4_branches925 hp4_4_evidence925 hp4_4_check925 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches925,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node924 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected924 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected924 ((8 : Int),(1 : Int)) hp4_4_branches924 hp4_4_evidence924 hp4_4_check924 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches924,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node925 T childKnown
  · exact hp4_4_node926 T childKnown
theorem hp4_4_node923 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected923 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected923 ((6 : Int),(0 : Int)) hp4_4_branches923 hp4_4_evidence923 hp4_4_check923 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches923,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node924 T childKnown
theorem hp4_4_node922 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected922 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected922 ((3 : Int),(2 : Int)) hp4_4_branches922 hp4_4_evidence922 hp4_4_check922 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches922,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node921 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected921 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected921 ((3 : Int),(2 : Int)) hp4_4_branches921 hp4_4_evidence921 hp4_4_check921 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches921,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node920 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected920 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected920 ((3 : Int),(2 : Int)) hp4_4_branches920 hp4_4_evidence920 hp4_4_check920 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches920,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node919 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected919 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected919 ((4 : Int),(2 : Int)) hp4_4_branches919 hp4_4_evidence919 hp4_4_check919 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches919,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node918 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected918 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected918 ((3 : Int),(2 : Int)) hp4_4_branches918 hp4_4_evidence918 hp4_4_check918 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches918,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node919 T childKnown
theorem hp4_4_node917 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected917 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected917 ((2 : Int),(2 : Int)) hp4_4_branches917 hp4_4_evidence917 hp4_4_check917 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches917,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node918 T childKnown
  · exact hp4_4_node920 T childKnown
  · exact hp4_4_node921 T childKnown
  · exact hp4_4_node922 T childKnown
theorem hp4_4_node916 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected916 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected916 ((8 : Int),(1 : Int)) hp4_4_branches916 hp4_4_evidence916 hp4_4_check916 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches916,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node915 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected915 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected915 ((11 : Int),(2 : Int)) hp4_4_branches915 hp4_4_evidence915 hp4_4_check915 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches915,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node914 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected914 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected914 ((11 : Int),(2 : Int)) hp4_4_branches914 hp4_4_evidence914 hp4_4_check914 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches914,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node913 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected913 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected913 ((11 : Int),(1 : Int)) hp4_4_branches913 hp4_4_evidence913 hp4_4_check913 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches913,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node914 T childKnown
  · exact hp4_4_node915 T childKnown
theorem hp4_4_node912 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected912 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected912 ((9 : Int),(1 : Int)) hp4_4_branches912 hp4_4_evidence912 hp4_4_check912 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches912,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node913 T childKnown
theorem hp4_4_node911 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected911 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected911 ((4 : Int),(2 : Int)) hp4_4_branches911 hp4_4_evidence911 hp4_4_check911 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches911,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node912 T childKnown
  · exact hp4_4_node916 T childKnown
theorem hp4_4_node910 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected910 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected910 ((8 : Int),(1 : Int)) hp4_4_branches910 hp4_4_evidence910 hp4_4_check910 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches910,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node909 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected909 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected909 ((11 : Int),(2 : Int)) hp4_4_branches909 hp4_4_evidence909 hp4_4_check909 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches909,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node908 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected908 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected908 ((11 : Int),(2 : Int)) hp4_4_branches908 hp4_4_evidence908 hp4_4_check908 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches908,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node907 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected907 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected907 ((11 : Int),(1 : Int)) hp4_4_branches907 hp4_4_evidence907 hp4_4_check907 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches907,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node908 T childKnown
  · exact hp4_4_node909 T childKnown
theorem hp4_4_node906 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected906 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected906 ((9 : Int),(1 : Int)) hp4_4_branches906 hp4_4_evidence906 hp4_4_check906 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches906,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node907 T childKnown
theorem hp4_4_node905 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected905 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected905 ((4 : Int),(2 : Int)) hp4_4_branches905 hp4_4_evidence905 hp4_4_check905 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches905,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node906 T childKnown
  · exact hp4_4_node910 T childKnown
theorem hp4_4_node904 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected904 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected904 ((8 : Int),(1 : Int)) hp4_4_branches904 hp4_4_evidence904 hp4_4_check904 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches904,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node903 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected903 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected903 ((11 : Int),(2 : Int)) hp4_4_branches903 hp4_4_evidence903 hp4_4_check903 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches903,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node902 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected902 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected902 ((11 : Int),(2 : Int)) hp4_4_branches902 hp4_4_evidence902 hp4_4_check902 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches902,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node901 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected901 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected901 ((11 : Int),(1 : Int)) hp4_4_branches901 hp4_4_evidence901 hp4_4_check901 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches901,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node902 T childKnown
  · exact hp4_4_node903 T childKnown
theorem hp4_4_node900 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected900 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected900 ((9 : Int),(1 : Int)) hp4_4_branches900 hp4_4_evidence900 hp4_4_check900 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches900,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node901 T childKnown
theorem hp4_4_node899 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected899 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected899 ((8 : Int),(1 : Int)) hp4_4_branches899 hp4_4_evidence899 hp4_4_check899 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches899,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node898 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected898 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected898 ((8 : Int),(1 : Int)) hp4_4_branches898 hp4_4_evidence898 hp4_4_check898 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches898,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node897 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected897 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected897 ((5 : Int),(2 : Int)) hp4_4_branches897 hp4_4_evidence897 hp4_4_check897 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches897,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node898 T childKnown
theorem hp4_4_node896 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected896 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected896 ((8 : Int),(1 : Int)) hp4_4_branches896 hp4_4_evidence896 hp4_4_check896 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches896,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node895 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected895 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected895 ((4 : Int),(2 : Int)) hp4_4_branches895 hp4_4_evidence895 hp4_4_check895 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches895,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node896 T childKnown
  · exact hp4_4_node897 T childKnown
  · exact hp4_4_node899 T childKnown
  · exact hp4_4_node900 T childKnown
  · exact hp4_4_node904 T childKnown
theorem hp4_4_node894 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected894 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected894 ((4 : Int),(2 : Int)) hp4_4_branches894 hp4_4_evidence894 hp4_4_check894 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches894,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node893 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected893 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected893 ((7 : Int),(2 : Int)) hp4_4_branches893 hp4_4_evidence893 hp4_4_check893 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches893,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node892 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected892 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected892 ((4 : Int),(2 : Int)) hp4_4_branches892 hp4_4_evidence892 hp4_4_check892 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches892,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node891 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected891 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected891 ((4 : Int),(2 : Int)) hp4_4_branches891 hp4_4_evidence891 hp4_4_check891 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches891,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node890 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected890 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected890 ((11 : Int),(2 : Int)) hp4_4_branches890 hp4_4_evidence890 hp4_4_check890 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches890,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node889 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected889 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected889 ((11 : Int),(2 : Int)) hp4_4_branches889 hp4_4_evidence889 hp4_4_check889 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches889,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node888 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected888 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected888 ((11 : Int),(1 : Int)) hp4_4_branches888 hp4_4_evidence888 hp4_4_check888 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches888,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node889 T childKnown
  · exact hp4_4_node890 T childKnown
theorem hp4_4_node887 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected887 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected887 ((9 : Int),(1 : Int)) hp4_4_branches887 hp4_4_evidence887 hp4_4_check887 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches887,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node888 T childKnown
theorem hp4_4_node886 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected886 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected886 ((8 : Int),(1 : Int)) hp4_4_branches886 hp4_4_evidence886 hp4_4_check886 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches886,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node887 T childKnown
  · exact hp4_4_node891 T childKnown
  · exact hp4_4_node892 T childKnown
  · exact hp4_4_node893 T childKnown
  · exact hp4_4_node894 T childKnown
theorem hp4_4_node885 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected885 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected885 ((2 : Int),(2 : Int)) hp4_4_branches885 hp4_4_evidence885 hp4_4_check885 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches885,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node886 T childKnown
  · exact hp4_4_node895 T childKnown
  · exact hp4_4_node905 T childKnown
  · exact hp4_4_node911 T childKnown
theorem hp4_4_node884 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected884 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected884 ((6 : Int),(0 : Int)) hp4_4_branches884 hp4_4_evidence884 hp4_4_check884 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches884,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node885 T childKnown
theorem hp4_4_node883 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected883 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected883 ((3 : Int),(2 : Int)) hp4_4_branches883 hp4_4_evidence883 hp4_4_check883 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches883,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node882 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected882 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected882 ((3 : Int),(2 : Int)) hp4_4_branches882 hp4_4_evidence882 hp4_4_check882 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches882,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node881 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected881 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected881 ((3 : Int),(1 : Int)) hp4_4_branches881 hp4_4_evidence881 hp4_4_check881 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches881,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node882 T childKnown
  · exact hp4_4_node883 T childKnown
theorem hp4_4_node880 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected880 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected880 ((11 : Int),(2 : Int)) hp4_4_branches880 hp4_4_evidence880 hp4_4_check880 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches880,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node879 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected879 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected879 ((11 : Int),(2 : Int)) hp4_4_branches879 hp4_4_evidence879 hp4_4_check879 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches879,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node878 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected878 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected878 ((11 : Int),(1 : Int)) hp4_4_branches878 hp4_4_evidence878 hp4_4_check878 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches878,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node879 T childKnown
  · exact hp4_4_node880 T childKnown
theorem hp4_4_node877 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected877 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected877 ((8 : Int),(2 : Int)) hp4_4_branches877 hp4_4_evidence877 hp4_4_check877 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches877,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node878 T childKnown
theorem hp4_4_node876 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected876 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected876 ((8 : Int),(2 : Int)) hp4_4_branches876 hp4_4_evidence876 hp4_4_check876 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches876,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node875 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected875 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected875 ((9 : Int),(1 : Int)) hp4_4_branches875 hp4_4_evidence875 hp4_4_check875 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches875,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node876 T childKnown
  · exact hp4_4_node877 T childKnown
theorem hp4_4_node874 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected874 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected874 ((6 : Int),(0 : Int)) hp4_4_branches874 hp4_4_evidence874 hp4_4_check874 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches874,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node875 T childKnown
theorem hp4_4_node873 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected873 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected873 ((6 : Int),(0 : Int)) hp4_4_branches873 hp4_4_evidence873 hp4_4_check873 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches873,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node872 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected872 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected872 ((3 : Int),(1 : Int)) hp4_4_branches872 hp4_4_evidence872 hp4_4_check872 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches872,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node873 T childKnown
  · exact hp4_4_node874 T childKnown
theorem hp4_4_node871 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected871 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected871 ((2 : Int),(1 : Int)) hp4_4_branches871 hp4_4_evidence871 hp4_4_check871 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches871,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node872 T childKnown
  · exact hp4_4_node881 T childKnown
  · exact hp4_4_node884 T childKnown
  · exact hp4_4_node917 T childKnown
  · exact hp4_4_node923 T childKnown
theorem hp4_4_node870 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected870 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected870 ((3 : Int),(2 : Int)) hp4_4_branches870 hp4_4_evidence870 hp4_4_check870 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches870,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node869 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected869 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected869 ((3 : Int),(2 : Int)) hp4_4_branches869 hp4_4_evidence869 hp4_4_check869 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches869,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node868 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected868 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected868 ((2 : Int),(2 : Int)) hp4_4_branches868 hp4_4_evidence868 hp4_4_check868 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches868,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node869 T childKnown
  · exact hp4_4_node870 T childKnown
theorem hp4_4_node867 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected867 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected867 ((6 : Int),(0 : Int)) hp4_4_branches867 hp4_4_evidence867 hp4_4_check867 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches867,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node868 T childKnown
theorem hp4_4_node866 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected866 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected866 ((3 : Int),(2 : Int)) hp4_4_branches866 hp4_4_evidence866 hp4_4_check866 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches866,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node865 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected865 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected865 ((3 : Int),(2 : Int)) hp4_4_branches865 hp4_4_evidence865 hp4_4_check865 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches865,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node864 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected864 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected864 ((2 : Int),(2 : Int)) hp4_4_branches864 hp4_4_evidence864 hp4_4_check864 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches864,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node865 T childKnown
  · exact hp4_4_node866 T childKnown
theorem hp4_4_node863 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected863 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected863 ((8 : Int),(1 : Int)) hp4_4_branches863 hp4_4_evidence863 hp4_4_check863 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches863,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node862 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected862 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected862 ((11 : Int),(2 : Int)) hp4_4_branches862 hp4_4_evidence862 hp4_4_check862 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches862,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node861 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected861 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected861 ((11 : Int),(2 : Int)) hp4_4_branches861 hp4_4_evidence861 hp4_4_check861 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches861,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node860 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected860 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected860 ((11 : Int),(1 : Int)) hp4_4_branches860 hp4_4_evidence860 hp4_4_check860 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches860,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node861 T childKnown
  · exact hp4_4_node862 T childKnown
theorem hp4_4_node859 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected859 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected859 ((9 : Int),(1 : Int)) hp4_4_branches859 hp4_4_evidence859 hp4_4_check859 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches859,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node860 T childKnown
theorem hp4_4_node858 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected858 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected858 ((4 : Int),(2 : Int)) hp4_4_branches858 hp4_4_evidence858 hp4_4_check858 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches858,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node859 T childKnown
  · exact hp4_4_node863 T childKnown
theorem hp4_4_node857 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected857 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected857 ((8 : Int),(1 : Int)) hp4_4_branches857 hp4_4_evidence857 hp4_4_check857 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches857,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node856 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected856 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected856 ((11 : Int),(2 : Int)) hp4_4_branches856 hp4_4_evidence856 hp4_4_check856 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches856,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node855 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected855 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected855 ((11 : Int),(2 : Int)) hp4_4_branches855 hp4_4_evidence855 hp4_4_check855 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches855,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node854 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected854 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected854 ((11 : Int),(1 : Int)) hp4_4_branches854 hp4_4_evidence854 hp4_4_check854 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches854,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node855 T childKnown
  · exact hp4_4_node856 T childKnown
theorem hp4_4_node853 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected853 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected853 ((9 : Int),(1 : Int)) hp4_4_branches853 hp4_4_evidence853 hp4_4_check853 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches853,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node854 T childKnown
theorem hp4_4_node852 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected852 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected852 ((4 : Int),(2 : Int)) hp4_4_branches852 hp4_4_evidence852 hp4_4_check852 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches852,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node853 T childKnown
  · exact hp4_4_node857 T childKnown
theorem hp4_4_node851 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected851 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected851 ((2 : Int),(2 : Int)) hp4_4_branches851 hp4_4_evidence851 hp4_4_check851 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches851,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node852 T childKnown
  · exact hp4_4_node858 T childKnown
theorem hp4_4_node850 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected850 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected850 ((6 : Int),(0 : Int)) hp4_4_branches850 hp4_4_evidence850 hp4_4_check850 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches850,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node851 T childKnown
theorem hp4_4_node849 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected849 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected849 ((3 : Int),(2 : Int)) hp4_4_branches849 hp4_4_evidence849 hp4_4_check849 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches849,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node848 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected848 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected848 ((3 : Int),(2 : Int)) hp4_4_branches848 hp4_4_evidence848 hp4_4_check848 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches848,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node847 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected847 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected847 ((3 : Int),(1 : Int)) hp4_4_branches847 hp4_4_evidence847 hp4_4_check847 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches847,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node848 T childKnown
  · exact hp4_4_node849 T childKnown
theorem hp4_4_node846 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected846 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected846 ((11 : Int),(2 : Int)) hp4_4_branches846 hp4_4_evidence846 hp4_4_check846 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches846,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node845 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected845 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected845 ((11 : Int),(2 : Int)) hp4_4_branches845 hp4_4_evidence845 hp4_4_check845 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches845,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node844 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected844 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected844 ((11 : Int),(1 : Int)) hp4_4_branches844 hp4_4_evidence844 hp4_4_check844 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches844,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node845 T childKnown
  · exact hp4_4_node846 T childKnown
theorem hp4_4_node843 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected843 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected843 ((8 : Int),(2 : Int)) hp4_4_branches843 hp4_4_evidence843 hp4_4_check843 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches843,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node844 T childKnown
theorem hp4_4_node842 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected842 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected842 ((8 : Int),(2 : Int)) hp4_4_branches842 hp4_4_evidence842 hp4_4_check842 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches842,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node841 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected841 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected841 ((9 : Int),(1 : Int)) hp4_4_branches841 hp4_4_evidence841 hp4_4_check841 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches841,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node842 T childKnown
  · exact hp4_4_node843 T childKnown
theorem hp4_4_node840 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected840 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected840 ((6 : Int),(0 : Int)) hp4_4_branches840 hp4_4_evidence840 hp4_4_check840 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches840,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node841 T childKnown
theorem hp4_4_node839 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected839 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected839 ((6 : Int),(0 : Int)) hp4_4_branches839 hp4_4_evidence839 hp4_4_check839 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches839,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node838 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected838 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected838 ((3 : Int),(1 : Int)) hp4_4_branches838 hp4_4_evidence838 hp4_4_check838 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches838,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node839 T childKnown
  · exact hp4_4_node840 T childKnown
theorem hp4_4_node837 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected837 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected837 ((3 : Int),(2 : Int)) hp4_4_branches837 hp4_4_evidence837 hp4_4_check837 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches837,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node836 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected836 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected836 ((3 : Int),(2 : Int)) hp4_4_branches836 hp4_4_evidence836 hp4_4_check836 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches836,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node835 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected835 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected835 ((3 : Int),(1 : Int)) hp4_4_branches835 hp4_4_evidence835 hp4_4_check835 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches835,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node836 T childKnown
  · exact hp4_4_node837 T childKnown
theorem hp4_4_node834 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected834 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected834 ((2 : Int),(1 : Int)) hp4_4_branches834 hp4_4_evidence834 hp4_4_check834 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches834,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node835 T childKnown
  · exact hp4_4_node838 T childKnown
  · exact hp4_4_node847 T childKnown
  · exact hp4_4_node850 T childKnown
  · exact hp4_4_node864 T childKnown
  · exact hp4_4_node867 T childKnown
theorem hp4_4_node833 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected833 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected833 ((3 : Int),(2 : Int)) hp4_4_branches833 hp4_4_evidence833 hp4_4_check833 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches833,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node832 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected832 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected832 ((3 : Int),(2 : Int)) hp4_4_branches832 hp4_4_evidence832 hp4_4_check832 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches832,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node831 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected831 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected831 ((2 : Int),(2 : Int)) hp4_4_branches831 hp4_4_evidence831 hp4_4_check831 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches831,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node832 T childKnown
  · exact hp4_4_node833 T childKnown
theorem hp4_4_node830 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected830 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected830 ((6 : Int),(0 : Int)) hp4_4_branches830 hp4_4_evidence830 hp4_4_check830 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches830,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node831 T childKnown
theorem hp4_4_node829 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected829 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected829 ((3 : Int),(2 : Int)) hp4_4_branches829 hp4_4_evidence829 hp4_4_check829 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches829,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node828 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected828 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected828 ((3 : Int),(2 : Int)) hp4_4_branches828 hp4_4_evidence828 hp4_4_check828 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches828,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node827 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected827 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected827 ((2 : Int),(2 : Int)) hp4_4_branches827 hp4_4_evidence827 hp4_4_check827 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches827,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node828 T childKnown
  · exact hp4_4_node829 T childKnown
theorem hp4_4_node826 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected826 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected826 ((8 : Int),(1 : Int)) hp4_4_branches826 hp4_4_evidence826 hp4_4_check826 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches826,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node825 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected825 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected825 ((11 : Int),(2 : Int)) hp4_4_branches825 hp4_4_evidence825 hp4_4_check825 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches825,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node824 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected824 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected824 ((11 : Int),(2 : Int)) hp4_4_branches824 hp4_4_evidence824 hp4_4_check824 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches824,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node823 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected823 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected823 ((11 : Int),(1 : Int)) hp4_4_branches823 hp4_4_evidence823 hp4_4_check823 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches823,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node824 T childKnown
  · exact hp4_4_node825 T childKnown
theorem hp4_4_node822 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected822 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected822 ((9 : Int),(1 : Int)) hp4_4_branches822 hp4_4_evidence822 hp4_4_check822 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches822,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node823 T childKnown
theorem hp4_4_node821 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected821 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected821 ((4 : Int),(2 : Int)) hp4_4_branches821 hp4_4_evidence821 hp4_4_check821 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches821,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node822 T childKnown
  · exact hp4_4_node826 T childKnown
theorem hp4_4_node820 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected820 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected820 ((8 : Int),(1 : Int)) hp4_4_branches820 hp4_4_evidence820 hp4_4_check820 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches820,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node819 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected819 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected819 ((11 : Int),(2 : Int)) hp4_4_branches819 hp4_4_evidence819 hp4_4_check819 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches819,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node818 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected818 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected818 ((11 : Int),(2 : Int)) hp4_4_branches818 hp4_4_evidence818 hp4_4_check818 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches818,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node817 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected817 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected817 ((11 : Int),(1 : Int)) hp4_4_branches817 hp4_4_evidence817 hp4_4_check817 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches817,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node818 T childKnown
  · exact hp4_4_node819 T childKnown
theorem hp4_4_node816 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected816 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected816 ((9 : Int),(1 : Int)) hp4_4_branches816 hp4_4_evidence816 hp4_4_check816 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches816,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node817 T childKnown
theorem hp4_4_node815 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected815 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected815 ((4 : Int),(2 : Int)) hp4_4_branches815 hp4_4_evidence815 hp4_4_check815 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches815,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node816 T childKnown
  · exact hp4_4_node820 T childKnown
theorem hp4_4_node814 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected814 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected814 ((2 : Int),(2 : Int)) hp4_4_branches814 hp4_4_evidence814 hp4_4_check814 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches814,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node815 T childKnown
  · exact hp4_4_node821 T childKnown
theorem hp4_4_node813 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected813 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected813 ((6 : Int),(0 : Int)) hp4_4_branches813 hp4_4_evidence813 hp4_4_check813 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches813,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node814 T childKnown
theorem hp4_4_node812 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected812 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected812 ((3 : Int),(2 : Int)) hp4_4_branches812 hp4_4_evidence812 hp4_4_check812 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches812,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node811 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected811 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected811 ((3 : Int),(2 : Int)) hp4_4_branches811 hp4_4_evidence811 hp4_4_check811 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches811,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node810 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected810 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected810 ((3 : Int),(1 : Int)) hp4_4_branches810 hp4_4_evidence810 hp4_4_check810 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches810,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node811 T childKnown
  · exact hp4_4_node812 T childKnown
theorem hp4_4_node809 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected809 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected809 ((11 : Int),(2 : Int)) hp4_4_branches809 hp4_4_evidence809 hp4_4_check809 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches809,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node808 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected808 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected808 ((11 : Int),(2 : Int)) hp4_4_branches808 hp4_4_evidence808 hp4_4_check808 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches808,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node807 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected807 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected807 ((11 : Int),(1 : Int)) hp4_4_branches807 hp4_4_evidence807 hp4_4_check807 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches807,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node808 T childKnown
  · exact hp4_4_node809 T childKnown
theorem hp4_4_node806 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected806 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected806 ((8 : Int),(2 : Int)) hp4_4_branches806 hp4_4_evidence806 hp4_4_check806 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches806,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node807 T childKnown
theorem hp4_4_node805 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected805 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected805 ((8 : Int),(2 : Int)) hp4_4_branches805 hp4_4_evidence805 hp4_4_check805 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches805,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node804 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected804 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected804 ((9 : Int),(1 : Int)) hp4_4_branches804 hp4_4_evidence804 hp4_4_check804 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches804,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node805 T childKnown
  · exact hp4_4_node806 T childKnown
theorem hp4_4_node803 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected803 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected803 ((6 : Int),(0 : Int)) hp4_4_branches803 hp4_4_evidence803 hp4_4_check803 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches803,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node804 T childKnown
theorem hp4_4_node802 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected802 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected802 ((6 : Int),(0 : Int)) hp4_4_branches802 hp4_4_evidence802 hp4_4_check802 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches802,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node801 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected801 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected801 ((3 : Int),(1 : Int)) hp4_4_branches801 hp4_4_evidence801 hp4_4_check801 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches801,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node802 T childKnown
  · exact hp4_4_node803 T childKnown
theorem hp4_4_node800 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected800 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected800 ((3 : Int),(2 : Int)) hp4_4_branches800 hp4_4_evidence800 hp4_4_check800 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches800,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node799 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected799 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected799 ((3 : Int),(2 : Int)) hp4_4_branches799 hp4_4_evidence799 hp4_4_check799 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches799,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node798 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected798 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected798 ((3 : Int),(1 : Int)) hp4_4_branches798 hp4_4_evidence798 hp4_4_check798 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches798,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node799 T childKnown
  · exact hp4_4_node800 T childKnown
theorem hp4_4_node797 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected797 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected797 ((2 : Int),(1 : Int)) hp4_4_branches797 hp4_4_evidence797 hp4_4_check797 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches797,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node798 T childKnown
  · exact hp4_4_node801 T childKnown
  · exact hp4_4_node810 T childKnown
  · exact hp4_4_node813 T childKnown
  · exact hp4_4_node827 T childKnown
  · exact hp4_4_node830 T childKnown
theorem hp4_4_node796 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected796 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected796 ((2 : Int),(1 : Int)) hp4_4_branches796 hp4_4_evidence796 hp4_4_check796 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches796,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node795 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected795 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected795 ((2 : Int),(1 : Int)) hp4_4_branches795 hp4_4_evidence795 hp4_4_check795 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches795,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node794 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected794 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected794 ((3 : Int),(2 : Int)) hp4_4_branches794 hp4_4_evidence794 hp4_4_check794 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches794,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node793 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected793 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected793 ((3 : Int),(2 : Int)) hp4_4_branches793 hp4_4_evidence793 hp4_4_check793 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches793,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node792 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected792 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected792 ((3 : Int),(1 : Int)) hp4_4_branches792 hp4_4_evidence792 hp4_4_check792 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches792,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node793 T childKnown
  · exact hp4_4_node794 T childKnown
theorem hp4_4_node791 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected791 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected791 ((2 : Int),(2 : Int)) hp4_4_branches791 hp4_4_evidence791 hp4_4_check791 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches791,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_4_node792 T childKnown
  · exact hp4_4_node795 T childKnown
  · exact hp4_4_node796 T childKnown
theorem hp4_4_node790 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected790 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected790 ((2 : Int),(1 : Int)) hp4_4_branches790 hp4_4_evidence790 hp4_4_check790 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches790,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node789 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected789 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected789 ((2 : Int),(1 : Int)) hp4_4_branches789 hp4_4_evidence789 hp4_4_check789 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches789,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node788 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected788 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected788 ((3 : Int),(2 : Int)) hp4_4_branches788 hp4_4_evidence788 hp4_4_check788 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches788,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node787 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected787 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected787 ((3 : Int),(2 : Int)) hp4_4_branches787 hp4_4_evidence787 hp4_4_check787 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches787,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node786 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected786 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected786 ((3 : Int),(1 : Int)) hp4_4_branches786 hp4_4_evidence786 hp4_4_check786 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches786,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node787 T childKnown
  · exact hp4_4_node788 T childKnown
theorem hp4_4_node785 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected785 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected785 ((2 : Int),(2 : Int)) hp4_4_branches785 hp4_4_evidence785 hp4_4_check785 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches785,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_4_node786 T childKnown
  · exact hp4_4_node789 T childKnown
  · exact hp4_4_node790 T childKnown
theorem hp4_4_node784 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected784 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected784 ((3 : Int),(2 : Int)) hp4_4_branches784 hp4_4_evidence784 hp4_4_check784 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches784,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node783 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected783 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected783 ((2 : Int),(2 : Int)) hp4_4_branches783 hp4_4_evidence783 hp4_4_check783 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches783,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node784 T childKnown
theorem hp4_4_node782 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected782 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected782 ((3 : Int),(2 : Int)) hp4_4_branches782 hp4_4_evidence782 hp4_4_check782 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches782,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node781 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected781 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected781 ((2 : Int),(2 : Int)) hp4_4_branches781 hp4_4_evidence781 hp4_4_check781 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches781,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node782 T childKnown
theorem hp4_4_node780 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected780 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected780 ((8 : Int),(1 : Int)) hp4_4_branches780 hp4_4_evidence780 hp4_4_check780 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches780,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node779 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected779 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected779 ((11 : Int),(2 : Int)) hp4_4_branches779 hp4_4_evidence779 hp4_4_check779 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches779,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node778 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected778 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected778 ((11 : Int),(2 : Int)) hp4_4_branches778 hp4_4_evidence778 hp4_4_check778 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches778,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node777 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected777 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected777 ((11 : Int),(1 : Int)) hp4_4_branches777 hp4_4_evidence777 hp4_4_check777 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches777,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node778 T childKnown
  · exact hp4_4_node779 T childKnown
theorem hp4_4_node776 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected776 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected776 ((9 : Int),(1 : Int)) hp4_4_branches776 hp4_4_evidence776 hp4_4_check776 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches776,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node777 T childKnown
theorem hp4_4_node775 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected775 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected775 ((4 : Int),(2 : Int)) hp4_4_branches775 hp4_4_evidence775 hp4_4_check775 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches775,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node776 T childKnown
  · exact hp4_4_node780 T childKnown
theorem hp4_4_node774 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected774 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected774 ((6 : Int),(0 : Int)) hp4_4_branches774 hp4_4_evidence774 hp4_4_check774 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches774,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node775 T childKnown
theorem hp4_4_node773 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected773 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected773 ((2 : Int),(2 : Int)) hp4_4_branches773 hp4_4_evidence773 hp4_4_check773 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches773,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node774 T childKnown
theorem hp4_4_node772 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected772 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected772 ((3 : Int),(2 : Int)) hp4_4_branches772 hp4_4_evidence772 hp4_4_check772 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches772,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node771 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected771 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected771 ((3 : Int),(2 : Int)) hp4_4_branches771 hp4_4_evidence771 hp4_4_check771 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches771,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node770 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected770 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected770 ((3 : Int),(1 : Int)) hp4_4_branches770 hp4_4_evidence770 hp4_4_check770 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches770,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node771 T childKnown
  · exact hp4_4_node772 T childKnown
theorem hp4_4_node769 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected769 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected769 ((11 : Int),(2 : Int)) hp4_4_branches769 hp4_4_evidence769 hp4_4_check769 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches769,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node768 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected768 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected768 ((11 : Int),(2 : Int)) hp4_4_branches768 hp4_4_evidence768 hp4_4_check768 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches768,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node767 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected767 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected767 ((11 : Int),(1 : Int)) hp4_4_branches767 hp4_4_evidence767 hp4_4_check767 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches767,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node768 T childKnown
  · exact hp4_4_node769 T childKnown
theorem hp4_4_node766 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected766 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected766 ((8 : Int),(2 : Int)) hp4_4_branches766 hp4_4_evidence766 hp4_4_check766 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches766,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node767 T childKnown
theorem hp4_4_node765 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected765 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected765 ((8 : Int),(2 : Int)) hp4_4_branches765 hp4_4_evidence765 hp4_4_check765 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches765,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node764 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected764 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected764 ((9 : Int),(1 : Int)) hp4_4_branches764 hp4_4_evidence764 hp4_4_check764 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches764,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node765 T childKnown
  · exact hp4_4_node766 T childKnown
theorem hp4_4_node763 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected763 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected763 ((6 : Int),(0 : Int)) hp4_4_branches763 hp4_4_evidence763 hp4_4_check763 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches763,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node764 T childKnown
theorem hp4_4_node762 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected762 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected762 ((6 : Int),(0 : Int)) hp4_4_branches762 hp4_4_evidence762 hp4_4_check762 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches762,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node761 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected761 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected761 ((3 : Int),(1 : Int)) hp4_4_branches761 hp4_4_evidence761 hp4_4_check761 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches761,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node762 T childKnown
  · exact hp4_4_node763 T childKnown
theorem hp4_4_node760 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected760 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected760 ((3 : Int),(2 : Int)) hp4_4_branches760 hp4_4_evidence760 hp4_4_check760 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches760,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node759 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected759 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected759 ((3 : Int),(2 : Int)) hp4_4_branches759 hp4_4_evidence759 hp4_4_check759 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches759,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node758 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected758 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected758 ((3 : Int),(1 : Int)) hp4_4_branches758 hp4_4_evidence758 hp4_4_check758 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches758,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node759 T childKnown
  · exact hp4_4_node760 T childKnown
theorem hp4_4_node757 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected757 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected757 ((2 : Int),(1 : Int)) hp4_4_branches757 hp4_4_evidence757 hp4_4_check757 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches757,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node758 T childKnown
  · exact hp4_4_node761 T childKnown
  · exact hp4_4_node770 T childKnown
  · exact hp4_4_node773 T childKnown
  · exact hp4_4_node781 T childKnown
  · exact hp4_4_node783 T childKnown
theorem hp4_4_node756 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected756 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected756 ((3 : Int),(2 : Int)) hp4_4_branches756 hp4_4_evidence756 hp4_4_check756 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches756,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node755 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected755 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected755 ((3 : Int),(2 : Int)) hp4_4_branches755 hp4_4_evidence755 hp4_4_check755 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches755,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node754 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected754 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected754 ((2 : Int),(2 : Int)) hp4_4_branches754 hp4_4_evidence754 hp4_4_check754 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches754,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node755 T childKnown
  · exact hp4_4_node756 T childKnown
theorem hp4_4_node753 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected753 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected753 ((6 : Int),(0 : Int)) hp4_4_branches753 hp4_4_evidence753 hp4_4_check753 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches753,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node754 T childKnown
theorem hp4_4_node752 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected752 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected752 ((3 : Int),(2 : Int)) hp4_4_branches752 hp4_4_evidence752 hp4_4_check752 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches752,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node751 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected751 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected751 ((3 : Int),(2 : Int)) hp4_4_branches751 hp4_4_evidence751 hp4_4_check751 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches751,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node750 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected750 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected750 ((2 : Int),(2 : Int)) hp4_4_branches750 hp4_4_evidence750 hp4_4_check750 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches750,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node751 T childKnown
  · exact hp4_4_node752 T childKnown
theorem hp4_4_node749 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected749 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected749 ((8 : Int),(1 : Int)) hp4_4_branches749 hp4_4_evidence749 hp4_4_check749 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches749,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node748 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected748 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected748 ((11 : Int),(2 : Int)) hp4_4_branches748 hp4_4_evidence748 hp4_4_check748 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches748,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node747 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected747 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected747 ((11 : Int),(2 : Int)) hp4_4_branches747 hp4_4_evidence747 hp4_4_check747 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches747,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node746 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected746 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected746 ((11 : Int),(1 : Int)) hp4_4_branches746 hp4_4_evidence746 hp4_4_check746 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches746,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node747 T childKnown
  · exact hp4_4_node748 T childKnown
theorem hp4_4_node745 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected745 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected745 ((9 : Int),(1 : Int)) hp4_4_branches745 hp4_4_evidence745 hp4_4_check745 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches745,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node746 T childKnown
theorem hp4_4_node744 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected744 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected744 ((4 : Int),(2 : Int)) hp4_4_branches744 hp4_4_evidence744 hp4_4_check744 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches744,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node745 T childKnown
  · exact hp4_4_node749 T childKnown
theorem hp4_4_node743 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected743 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected743 ((8 : Int),(1 : Int)) hp4_4_branches743 hp4_4_evidence743 hp4_4_check743 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches743,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node742 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected742 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected742 ((11 : Int),(2 : Int)) hp4_4_branches742 hp4_4_evidence742 hp4_4_check742 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches742,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node741 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected741 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected741 ((11 : Int),(2 : Int)) hp4_4_branches741 hp4_4_evidence741 hp4_4_check741 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches741,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node740 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected740 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected740 ((11 : Int),(1 : Int)) hp4_4_branches740 hp4_4_evidence740 hp4_4_check740 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches740,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node741 T childKnown
  · exact hp4_4_node742 T childKnown
theorem hp4_4_node739 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected739 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected739 ((9 : Int),(1 : Int)) hp4_4_branches739 hp4_4_evidence739 hp4_4_check739 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches739,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node740 T childKnown
theorem hp4_4_node738 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected738 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected738 ((4 : Int),(2 : Int)) hp4_4_branches738 hp4_4_evidence738 hp4_4_check738 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches738,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node739 T childKnown
  · exact hp4_4_node743 T childKnown
theorem hp4_4_node737 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected737 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected737 ((2 : Int),(2 : Int)) hp4_4_branches737 hp4_4_evidence737 hp4_4_check737 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches737,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node738 T childKnown
  · exact hp4_4_node744 T childKnown
theorem hp4_4_node736 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected736 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected736 ((6 : Int),(0 : Int)) hp4_4_branches736 hp4_4_evidence736 hp4_4_check736 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches736,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node737 T childKnown
theorem hp4_4_node735 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected735 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected735 ((3 : Int),(2 : Int)) hp4_4_branches735 hp4_4_evidence735 hp4_4_check735 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches735,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node734 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected734 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected734 ((3 : Int),(2 : Int)) hp4_4_branches734 hp4_4_evidence734 hp4_4_check734 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches734,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node733 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected733 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected733 ((3 : Int),(1 : Int)) hp4_4_branches733 hp4_4_evidence733 hp4_4_check733 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches733,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node734 T childKnown
  · exact hp4_4_node735 T childKnown
theorem hp4_4_node732 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected732 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected732 ((11 : Int),(2 : Int)) hp4_4_branches732 hp4_4_evidence732 hp4_4_check732 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches732,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node731 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected731 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected731 ((11 : Int),(2 : Int)) hp4_4_branches731 hp4_4_evidence731 hp4_4_check731 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches731,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node730 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected730 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected730 ((11 : Int),(1 : Int)) hp4_4_branches730 hp4_4_evidence730 hp4_4_check730 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches730,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node731 T childKnown
  · exact hp4_4_node732 T childKnown
theorem hp4_4_node729 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected729 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected729 ((8 : Int),(2 : Int)) hp4_4_branches729 hp4_4_evidence729 hp4_4_check729 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches729,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node730 T childKnown
theorem hp4_4_node728 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected728 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected728 ((8 : Int),(2 : Int)) hp4_4_branches728 hp4_4_evidence728 hp4_4_check728 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches728,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node727 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected727 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected727 ((9 : Int),(1 : Int)) hp4_4_branches727 hp4_4_evidence727 hp4_4_check727 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches727,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node728 T childKnown
  · exact hp4_4_node729 T childKnown
theorem hp4_4_node726 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected726 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected726 ((6 : Int),(0 : Int)) hp4_4_branches726 hp4_4_evidence726 hp4_4_check726 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches726,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node727 T childKnown
theorem hp4_4_node725 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected725 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected725 ((6 : Int),(0 : Int)) hp4_4_branches725 hp4_4_evidence725 hp4_4_check725 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches725,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node724 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected724 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected724 ((3 : Int),(1 : Int)) hp4_4_branches724 hp4_4_evidence724 hp4_4_check724 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches724,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node725 T childKnown
  · exact hp4_4_node726 T childKnown
theorem hp4_4_node723 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected723 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected723 ((3 : Int),(2 : Int)) hp4_4_branches723 hp4_4_evidence723 hp4_4_check723 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches723,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node722 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected722 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected722 ((3 : Int),(2 : Int)) hp4_4_branches722 hp4_4_evidence722 hp4_4_check722 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches722,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node721 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected721 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected721 ((3 : Int),(1 : Int)) hp4_4_branches721 hp4_4_evidence721 hp4_4_check721 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches721,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node722 T childKnown
  · exact hp4_4_node723 T childKnown
theorem hp4_4_node720 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected720 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected720 ((2 : Int),(1 : Int)) hp4_4_branches720 hp4_4_evidence720 hp4_4_check720 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches720,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node721 T childKnown
  · exact hp4_4_node724 T childKnown
  · exact hp4_4_node733 T childKnown
  · exact hp4_4_node736 T childKnown
  · exact hp4_4_node750 T childKnown
  · exact hp4_4_node753 T childKnown
theorem hp4_4_node719 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected719 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected719 ((0 : Int),(2 : Int)) hp4_4_branches719 hp4_4_evidence719 hp4_4_check719 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches719,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node720 T childKnown
  · exact hp4_4_node757 T childKnown
  · exact hp4_4_node785 T childKnown
  · exact hp4_4_node791 T childKnown
theorem hp4_4_node718 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected718 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected718 ((2 : Int),(1 : Int)) hp4_4_branches718 hp4_4_evidence718 hp4_4_check718 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches718,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node717 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected717 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected717 ((2 : Int),(1 : Int)) hp4_4_branches717 hp4_4_evidence717 hp4_4_check717 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches717,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node716 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected716 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected716 ((3 : Int),(2 : Int)) hp4_4_branches716 hp4_4_evidence716 hp4_4_check716 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches716,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node715 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected715 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected715 ((3 : Int),(2 : Int)) hp4_4_branches715 hp4_4_evidence715 hp4_4_check715 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches715,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node714 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected714 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected714 ((3 : Int),(1 : Int)) hp4_4_branches714 hp4_4_evidence714 hp4_4_check714 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches714,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node715 T childKnown
  · exact hp4_4_node716 T childKnown
theorem hp4_4_node713 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected713 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected713 ((2 : Int),(2 : Int)) hp4_4_branches713 hp4_4_evidence713 hp4_4_check713 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches713,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_4_node714 T childKnown
  · exact hp4_4_node717 T childKnown
  · exact hp4_4_node718 T childKnown
theorem hp4_4_node712 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected712 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected712 ((2 : Int),(1 : Int)) hp4_4_branches712 hp4_4_evidence712 hp4_4_check712 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches712,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node711 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected711 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected711 ((2 : Int),(1 : Int)) hp4_4_branches711 hp4_4_evidence711 hp4_4_check711 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches711,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node710 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected710 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected710 ((3 : Int),(2 : Int)) hp4_4_branches710 hp4_4_evidence710 hp4_4_check710 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches710,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node709 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected709 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected709 ((3 : Int),(2 : Int)) hp4_4_branches709 hp4_4_evidence709 hp4_4_check709 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches709,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node708 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected708 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected708 ((3 : Int),(1 : Int)) hp4_4_branches708 hp4_4_evidence708 hp4_4_check708 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches708,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node709 T childKnown
  · exact hp4_4_node710 T childKnown
theorem hp4_4_node707 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected707 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected707 ((2 : Int),(2 : Int)) hp4_4_branches707 hp4_4_evidence707 hp4_4_check707 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches707,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_4_node708 T childKnown
  · exact hp4_4_node711 T childKnown
  · exact hp4_4_node712 T childKnown
theorem hp4_4_node706 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected706 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected706 ((3 : Int),(2 : Int)) hp4_4_branches706 hp4_4_evidence706 hp4_4_check706 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches706,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node705 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected705 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected705 ((2 : Int),(2 : Int)) hp4_4_branches705 hp4_4_evidence705 hp4_4_check705 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches705,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node706 T childKnown
theorem hp4_4_node704 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected704 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected704 ((3 : Int),(2 : Int)) hp4_4_branches704 hp4_4_evidence704 hp4_4_check704 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches704,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node703 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected703 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected703 ((2 : Int),(2 : Int)) hp4_4_branches703 hp4_4_evidence703 hp4_4_check703 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches703,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node704 T childKnown
theorem hp4_4_node702 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected702 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected702 ((8 : Int),(1 : Int)) hp4_4_branches702 hp4_4_evidence702 hp4_4_check702 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches702,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node701 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected701 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected701 ((11 : Int),(2 : Int)) hp4_4_branches701 hp4_4_evidence701 hp4_4_check701 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches701,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node700 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected700 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected700 ((11 : Int),(2 : Int)) hp4_4_branches700 hp4_4_evidence700 hp4_4_check700 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches700,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node699 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected699 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected699 ((11 : Int),(1 : Int)) hp4_4_branches699 hp4_4_evidence699 hp4_4_check699 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches699,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node700 T childKnown
  · exact hp4_4_node701 T childKnown
theorem hp4_4_node698 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected698 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected698 ((9 : Int),(1 : Int)) hp4_4_branches698 hp4_4_evidence698 hp4_4_check698 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches698,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node699 T childKnown
theorem hp4_4_node697 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected697 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected697 ((4 : Int),(2 : Int)) hp4_4_branches697 hp4_4_evidence697 hp4_4_check697 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches697,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node698 T childKnown
  · exact hp4_4_node702 T childKnown
theorem hp4_4_node696 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected696 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected696 ((6 : Int),(0 : Int)) hp4_4_branches696 hp4_4_evidence696 hp4_4_check696 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches696,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node697 T childKnown
theorem hp4_4_node695 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected695 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected695 ((2 : Int),(2 : Int)) hp4_4_branches695 hp4_4_evidence695 hp4_4_check695 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches695,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node696 T childKnown
theorem hp4_4_node694 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected694 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected694 ((3 : Int),(2 : Int)) hp4_4_branches694 hp4_4_evidence694 hp4_4_check694 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches694,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node693 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected693 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected693 ((3 : Int),(2 : Int)) hp4_4_branches693 hp4_4_evidence693 hp4_4_check693 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches693,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node692 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected692 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected692 ((3 : Int),(1 : Int)) hp4_4_branches692 hp4_4_evidence692 hp4_4_check692 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches692,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node693 T childKnown
  · exact hp4_4_node694 T childKnown
theorem hp4_4_node691 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected691 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected691 ((11 : Int),(2 : Int)) hp4_4_branches691 hp4_4_evidence691 hp4_4_check691 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches691,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node690 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected690 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected690 ((11 : Int),(2 : Int)) hp4_4_branches690 hp4_4_evidence690 hp4_4_check690 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches690,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node689 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected689 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected689 ((11 : Int),(1 : Int)) hp4_4_branches689 hp4_4_evidence689 hp4_4_check689 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches689,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node690 T childKnown
  · exact hp4_4_node691 T childKnown
theorem hp4_4_node688 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected688 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected688 ((8 : Int),(2 : Int)) hp4_4_branches688 hp4_4_evidence688 hp4_4_check688 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches688,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node689 T childKnown
theorem hp4_4_node687 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected687 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected687 ((8 : Int),(2 : Int)) hp4_4_branches687 hp4_4_evidence687 hp4_4_check687 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches687,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node686 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected686 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected686 ((9 : Int),(1 : Int)) hp4_4_branches686 hp4_4_evidence686 hp4_4_check686 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches686,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node687 T childKnown
  · exact hp4_4_node688 T childKnown
theorem hp4_4_node685 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected685 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected685 ((6 : Int),(0 : Int)) hp4_4_branches685 hp4_4_evidence685 hp4_4_check685 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches685,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node686 T childKnown
theorem hp4_4_node684 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected684 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected684 ((6 : Int),(0 : Int)) hp4_4_branches684 hp4_4_evidence684 hp4_4_check684 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches684,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node683 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected683 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected683 ((3 : Int),(1 : Int)) hp4_4_branches683 hp4_4_evidence683 hp4_4_check683 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches683,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node684 T childKnown
  · exact hp4_4_node685 T childKnown
theorem hp4_4_node682 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected682 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected682 ((3 : Int),(2 : Int)) hp4_4_branches682 hp4_4_evidence682 hp4_4_check682 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches682,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node681 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected681 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected681 ((3 : Int),(2 : Int)) hp4_4_branches681 hp4_4_evidence681 hp4_4_check681 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches681,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node680 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected680 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected680 ((3 : Int),(1 : Int)) hp4_4_branches680 hp4_4_evidence680 hp4_4_check680 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches680,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node681 T childKnown
  · exact hp4_4_node682 T childKnown
theorem hp4_4_node679 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected679 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected679 ((2 : Int),(1 : Int)) hp4_4_branches679 hp4_4_evidence679 hp4_4_check679 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches679,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node680 T childKnown
  · exact hp4_4_node683 T childKnown
  · exact hp4_4_node692 T childKnown
  · exact hp4_4_node695 T childKnown
  · exact hp4_4_node703 T childKnown
  · exact hp4_4_node705 T childKnown
theorem hp4_4_node678 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected678 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected678 ((3 : Int),(2 : Int)) hp4_4_branches678 hp4_4_evidence678 hp4_4_check678 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches678,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node677 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected677 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected677 ((3 : Int),(2 : Int)) hp4_4_branches677 hp4_4_evidence677 hp4_4_check677 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches677,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node676 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected676 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected676 ((2 : Int),(2 : Int)) hp4_4_branches676 hp4_4_evidence676 hp4_4_check676 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches676,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node677 T childKnown
  · exact hp4_4_node678 T childKnown
theorem hp4_4_node675 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected675 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected675 ((6 : Int),(0 : Int)) hp4_4_branches675 hp4_4_evidence675 hp4_4_check675 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches675,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node676 T childKnown
theorem hp4_4_node674 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected674 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected674 ((3 : Int),(2 : Int)) hp4_4_branches674 hp4_4_evidence674 hp4_4_check674 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches674,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node673 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected673 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected673 ((3 : Int),(2 : Int)) hp4_4_branches673 hp4_4_evidence673 hp4_4_check673 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches673,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node672 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected672 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected672 ((2 : Int),(2 : Int)) hp4_4_branches672 hp4_4_evidence672 hp4_4_check672 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches672,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node673 T childKnown
  · exact hp4_4_node674 T childKnown
theorem hp4_4_node671 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected671 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected671 ((8 : Int),(1 : Int)) hp4_4_branches671 hp4_4_evidence671 hp4_4_check671 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches671,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node670 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected670 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected670 ((11 : Int),(2 : Int)) hp4_4_branches670 hp4_4_evidence670 hp4_4_check670 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches670,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node669 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected669 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected669 ((11 : Int),(2 : Int)) hp4_4_branches669 hp4_4_evidence669 hp4_4_check669 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches669,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node668 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected668 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected668 ((11 : Int),(1 : Int)) hp4_4_branches668 hp4_4_evidence668 hp4_4_check668 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches668,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node669 T childKnown
  · exact hp4_4_node670 T childKnown
theorem hp4_4_node667 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected667 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected667 ((9 : Int),(1 : Int)) hp4_4_branches667 hp4_4_evidence667 hp4_4_check667 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches667,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node668 T childKnown
theorem hp4_4_node666 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected666 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected666 ((4 : Int),(2 : Int)) hp4_4_branches666 hp4_4_evidence666 hp4_4_check666 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches666,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node667 T childKnown
  · exact hp4_4_node671 T childKnown
theorem hp4_4_node665 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected665 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected665 ((8 : Int),(1 : Int)) hp4_4_branches665 hp4_4_evidence665 hp4_4_check665 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches665,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node664 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected664 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected664 ((11 : Int),(2 : Int)) hp4_4_branches664 hp4_4_evidence664 hp4_4_check664 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches664,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node663 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected663 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected663 ((11 : Int),(2 : Int)) hp4_4_branches663 hp4_4_evidence663 hp4_4_check663 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches663,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node662 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected662 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected662 ((11 : Int),(1 : Int)) hp4_4_branches662 hp4_4_evidence662 hp4_4_check662 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches662,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node663 T childKnown
  · exact hp4_4_node664 T childKnown
theorem hp4_4_node661 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected661 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected661 ((9 : Int),(1 : Int)) hp4_4_branches661 hp4_4_evidence661 hp4_4_check661 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches661,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node662 T childKnown
theorem hp4_4_node660 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected660 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected660 ((4 : Int),(2 : Int)) hp4_4_branches660 hp4_4_evidence660 hp4_4_check660 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches660,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node661 T childKnown
  · exact hp4_4_node665 T childKnown
theorem hp4_4_node659 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected659 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected659 ((2 : Int),(2 : Int)) hp4_4_branches659 hp4_4_evidence659 hp4_4_check659 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches659,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node660 T childKnown
  · exact hp4_4_node666 T childKnown
theorem hp4_4_node658 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected658 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected658 ((6 : Int),(0 : Int)) hp4_4_branches658 hp4_4_evidence658 hp4_4_check658 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches658,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node659 T childKnown
theorem hp4_4_node657 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected657 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected657 ((3 : Int),(2 : Int)) hp4_4_branches657 hp4_4_evidence657 hp4_4_check657 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches657,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node656 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected656 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected656 ((3 : Int),(2 : Int)) hp4_4_branches656 hp4_4_evidence656 hp4_4_check656 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches656,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node655 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected655 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected655 ((3 : Int),(1 : Int)) hp4_4_branches655 hp4_4_evidence655 hp4_4_check655 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches655,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node656 T childKnown
  · exact hp4_4_node657 T childKnown
theorem hp4_4_node654 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected654 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected654 ((11 : Int),(2 : Int)) hp4_4_branches654 hp4_4_evidence654 hp4_4_check654 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches654,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node653 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected653 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected653 ((11 : Int),(2 : Int)) hp4_4_branches653 hp4_4_evidence653 hp4_4_check653 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches653,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node652 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected652 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected652 ((11 : Int),(1 : Int)) hp4_4_branches652 hp4_4_evidence652 hp4_4_check652 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches652,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node653 T childKnown
  · exact hp4_4_node654 T childKnown
theorem hp4_4_node651 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected651 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected651 ((8 : Int),(2 : Int)) hp4_4_branches651 hp4_4_evidence651 hp4_4_check651 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches651,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node652 T childKnown
theorem hp4_4_node650 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected650 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected650 ((8 : Int),(2 : Int)) hp4_4_branches650 hp4_4_evidence650 hp4_4_check650 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches650,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node649 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected649 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected649 ((9 : Int),(1 : Int)) hp4_4_branches649 hp4_4_evidence649 hp4_4_check649 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches649,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node650 T childKnown
  · exact hp4_4_node651 T childKnown
theorem hp4_4_node648 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected648 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected648 ((6 : Int),(0 : Int)) hp4_4_branches648 hp4_4_evidence648 hp4_4_check648 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches648,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node649 T childKnown
theorem hp4_4_node647 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected647 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected647 ((6 : Int),(0 : Int)) hp4_4_branches647 hp4_4_evidence647 hp4_4_check647 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches647,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node646 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected646 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected646 ((3 : Int),(1 : Int)) hp4_4_branches646 hp4_4_evidence646 hp4_4_check646 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches646,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node647 T childKnown
  · exact hp4_4_node648 T childKnown
theorem hp4_4_node645 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected645 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected645 ((3 : Int),(2 : Int)) hp4_4_branches645 hp4_4_evidence645 hp4_4_check645 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches645,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node644 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected644 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected644 ((3 : Int),(2 : Int)) hp4_4_branches644 hp4_4_evidence644 hp4_4_check644 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches644,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node643 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected643 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected643 ((3 : Int),(1 : Int)) hp4_4_branches643 hp4_4_evidence643 hp4_4_check643 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches643,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node644 T childKnown
  · exact hp4_4_node645 T childKnown
theorem hp4_4_node642 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected642 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected642 ((2 : Int),(1 : Int)) hp4_4_branches642 hp4_4_evidence642 hp4_4_check642 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches642,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node643 T childKnown
  · exact hp4_4_node646 T childKnown
  · exact hp4_4_node655 T childKnown
  · exact hp4_4_node658 T childKnown
  · exact hp4_4_node672 T childKnown
  · exact hp4_4_node675 T childKnown
theorem hp4_4_node641 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected641 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected641 ((0 : Int),(2 : Int)) hp4_4_branches641 hp4_4_evidence641 hp4_4_check641 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches641,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node642 T childKnown
  · exact hp4_4_node679 T childKnown
  · exact hp4_4_node707 T childKnown
  · exact hp4_4_node713 T childKnown
theorem hp4_4_node640 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected640 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected640 ((2 : Int),(1 : Int)) hp4_4_branches640 hp4_4_evidence640 hp4_4_check640 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches640,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node639 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected639 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected639 ((2 : Int),(1 : Int)) hp4_4_branches639 hp4_4_evidence639 hp4_4_check639 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches639,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node638 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected638 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected638 ((3 : Int),(2 : Int)) hp4_4_branches638 hp4_4_evidence638 hp4_4_check638 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches638,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node637 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected637 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected637 ((3 : Int),(2 : Int)) hp4_4_branches637 hp4_4_evidence637 hp4_4_check637 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches637,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node636 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected636 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected636 ((3 : Int),(1 : Int)) hp4_4_branches636 hp4_4_evidence636 hp4_4_check636 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches636,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node637 T childKnown
  · exact hp4_4_node638 T childKnown
theorem hp4_4_node635 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected635 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected635 ((2 : Int),(2 : Int)) hp4_4_branches635 hp4_4_evidence635 hp4_4_check635 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches635,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_4_node636 T childKnown
  · exact hp4_4_node639 T childKnown
  · exact hp4_4_node640 T childKnown
theorem hp4_4_node634 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected634 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected634 ((2 : Int),(1 : Int)) hp4_4_branches634 hp4_4_evidence634 hp4_4_check634 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches634,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node633 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected633 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected633 ((2 : Int),(1 : Int)) hp4_4_branches633 hp4_4_evidence633 hp4_4_check633 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches633,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node632 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected632 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected632 ((3 : Int),(2 : Int)) hp4_4_branches632 hp4_4_evidence632 hp4_4_check632 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches632,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node631 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected631 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected631 ((3 : Int),(2 : Int)) hp4_4_branches631 hp4_4_evidence631 hp4_4_check631 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches631,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node630 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected630 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected630 ((3 : Int),(1 : Int)) hp4_4_branches630 hp4_4_evidence630 hp4_4_check630 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches630,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node631 T childKnown
  · exact hp4_4_node632 T childKnown
theorem hp4_4_node629 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected629 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected629 ((2 : Int),(2 : Int)) hp4_4_branches629 hp4_4_evidence629 hp4_4_check629 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches629,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_4_node630 T childKnown
  · exact hp4_4_node633 T childKnown
  · exact hp4_4_node634 T childKnown
theorem hp4_4_node628 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected628 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected628 ((3 : Int),(2 : Int)) hp4_4_branches628 hp4_4_evidence628 hp4_4_check628 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches628,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node627 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected627 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected627 ((2 : Int),(2 : Int)) hp4_4_branches627 hp4_4_evidence627 hp4_4_check627 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches627,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node628 T childKnown
theorem hp4_4_node626 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected626 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected626 ((3 : Int),(2 : Int)) hp4_4_branches626 hp4_4_evidence626 hp4_4_check626 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches626,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node625 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected625 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected625 ((2 : Int),(2 : Int)) hp4_4_branches625 hp4_4_evidence625 hp4_4_check625 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches625,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node626 T childKnown
theorem hp4_4_node624 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected624 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected624 ((8 : Int),(1 : Int)) hp4_4_branches624 hp4_4_evidence624 hp4_4_check624 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches624,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node623 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected623 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected623 ((11 : Int),(2 : Int)) hp4_4_branches623 hp4_4_evidence623 hp4_4_check623 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches623,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node622 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected622 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected622 ((11 : Int),(2 : Int)) hp4_4_branches622 hp4_4_evidence622 hp4_4_check622 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches622,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node621 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected621 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected621 ((11 : Int),(1 : Int)) hp4_4_branches621 hp4_4_evidence621 hp4_4_check621 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches621,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node622 T childKnown
  · exact hp4_4_node623 T childKnown
theorem hp4_4_node620 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected620 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected620 ((9 : Int),(1 : Int)) hp4_4_branches620 hp4_4_evidence620 hp4_4_check620 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches620,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node621 T childKnown
theorem hp4_4_node619 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected619 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected619 ((4 : Int),(2 : Int)) hp4_4_branches619 hp4_4_evidence619 hp4_4_check619 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches619,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node620 T childKnown
  · exact hp4_4_node624 T childKnown
theorem hp4_4_node618 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected618 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected618 ((6 : Int),(0 : Int)) hp4_4_branches618 hp4_4_evidence618 hp4_4_check618 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches618,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node619 T childKnown
theorem hp4_4_node617 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected617 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected617 ((2 : Int),(2 : Int)) hp4_4_branches617 hp4_4_evidence617 hp4_4_check617 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches617,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node618 T childKnown
theorem hp4_4_node616 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected616 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected616 ((3 : Int),(2 : Int)) hp4_4_branches616 hp4_4_evidence616 hp4_4_check616 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches616,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node615 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected615 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected615 ((3 : Int),(2 : Int)) hp4_4_branches615 hp4_4_evidence615 hp4_4_check615 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches615,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node614 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected614 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected614 ((3 : Int),(1 : Int)) hp4_4_branches614 hp4_4_evidence614 hp4_4_check614 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches614,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node615 T childKnown
  · exact hp4_4_node616 T childKnown
theorem hp4_4_node613 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected613 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected613 ((11 : Int),(2 : Int)) hp4_4_branches613 hp4_4_evidence613 hp4_4_check613 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches613,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node612 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected612 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected612 ((11 : Int),(2 : Int)) hp4_4_branches612 hp4_4_evidence612 hp4_4_check612 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches612,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node611 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected611 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected611 ((11 : Int),(1 : Int)) hp4_4_branches611 hp4_4_evidence611 hp4_4_check611 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches611,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node612 T childKnown
  · exact hp4_4_node613 T childKnown
theorem hp4_4_node610 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected610 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected610 ((8 : Int),(2 : Int)) hp4_4_branches610 hp4_4_evidence610 hp4_4_check610 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches610,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node611 T childKnown
theorem hp4_4_node609 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected609 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected609 ((8 : Int),(2 : Int)) hp4_4_branches609 hp4_4_evidence609 hp4_4_check609 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches609,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node608 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected608 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected608 ((9 : Int),(1 : Int)) hp4_4_branches608 hp4_4_evidence608 hp4_4_check608 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches608,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node609 T childKnown
  · exact hp4_4_node610 T childKnown
theorem hp4_4_node607 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected607 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected607 ((6 : Int),(0 : Int)) hp4_4_branches607 hp4_4_evidence607 hp4_4_check607 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches607,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node608 T childKnown
theorem hp4_4_node606 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected606 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected606 ((6 : Int),(0 : Int)) hp4_4_branches606 hp4_4_evidence606 hp4_4_check606 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches606,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node605 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected605 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected605 ((3 : Int),(1 : Int)) hp4_4_branches605 hp4_4_evidence605 hp4_4_check605 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches605,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node606 T childKnown
  · exact hp4_4_node607 T childKnown
theorem hp4_4_node604 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected604 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected604 ((3 : Int),(2 : Int)) hp4_4_branches604 hp4_4_evidence604 hp4_4_check604 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches604,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node603 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected603 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected603 ((3 : Int),(2 : Int)) hp4_4_branches603 hp4_4_evidence603 hp4_4_check603 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches603,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node602 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected602 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected602 ((3 : Int),(1 : Int)) hp4_4_branches602 hp4_4_evidence602 hp4_4_check602 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches602,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node603 T childKnown
  · exact hp4_4_node604 T childKnown
theorem hp4_4_node601 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected601 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected601 ((2 : Int),(1 : Int)) hp4_4_branches601 hp4_4_evidence601 hp4_4_check601 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches601,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node602 T childKnown
  · exact hp4_4_node605 T childKnown
  · exact hp4_4_node614 T childKnown
  · exact hp4_4_node617 T childKnown
  · exact hp4_4_node625 T childKnown
  · exact hp4_4_node627 T childKnown
theorem hp4_4_node600 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected600 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected600 ((3 : Int),(2 : Int)) hp4_4_branches600 hp4_4_evidence600 hp4_4_check600 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches600,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node599 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected599 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected599 ((3 : Int),(2 : Int)) hp4_4_branches599 hp4_4_evidence599 hp4_4_check599 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches599,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node598 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected598 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected598 ((2 : Int),(2 : Int)) hp4_4_branches598 hp4_4_evidence598 hp4_4_check598 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches598,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node599 T childKnown
  · exact hp4_4_node600 T childKnown
theorem hp4_4_node597 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected597 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected597 ((6 : Int),(0 : Int)) hp4_4_branches597 hp4_4_evidence597 hp4_4_check597 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches597,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node598 T childKnown
theorem hp4_4_node596 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected596 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected596 ((3 : Int),(2 : Int)) hp4_4_branches596 hp4_4_evidence596 hp4_4_check596 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches596,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node595 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected595 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected595 ((3 : Int),(2 : Int)) hp4_4_branches595 hp4_4_evidence595 hp4_4_check595 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches595,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node594 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected594 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected594 ((2 : Int),(2 : Int)) hp4_4_branches594 hp4_4_evidence594 hp4_4_check594 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches594,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node595 T childKnown
  · exact hp4_4_node596 T childKnown
theorem hp4_4_node593 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected593 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected593 ((8 : Int),(1 : Int)) hp4_4_branches593 hp4_4_evidence593 hp4_4_check593 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches593,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node592 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected592 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected592 ((11 : Int),(2 : Int)) hp4_4_branches592 hp4_4_evidence592 hp4_4_check592 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches592,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node591 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected591 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected591 ((11 : Int),(2 : Int)) hp4_4_branches591 hp4_4_evidence591 hp4_4_check591 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches591,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node590 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected590 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected590 ((11 : Int),(1 : Int)) hp4_4_branches590 hp4_4_evidence590 hp4_4_check590 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches590,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node591 T childKnown
  · exact hp4_4_node592 T childKnown
theorem hp4_4_node589 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected589 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected589 ((9 : Int),(1 : Int)) hp4_4_branches589 hp4_4_evidence589 hp4_4_check589 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches589,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node590 T childKnown
theorem hp4_4_node588 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected588 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected588 ((4 : Int),(2 : Int)) hp4_4_branches588 hp4_4_evidence588 hp4_4_check588 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches588,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node589 T childKnown
  · exact hp4_4_node593 T childKnown
theorem hp4_4_node587 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected587 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected587 ((8 : Int),(1 : Int)) hp4_4_branches587 hp4_4_evidence587 hp4_4_check587 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches587,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node586 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected586 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected586 ((11 : Int),(2 : Int)) hp4_4_branches586 hp4_4_evidence586 hp4_4_check586 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches586,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node585 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected585 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected585 ((11 : Int),(2 : Int)) hp4_4_branches585 hp4_4_evidence585 hp4_4_check585 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches585,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node584 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected584 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected584 ((11 : Int),(1 : Int)) hp4_4_branches584 hp4_4_evidence584 hp4_4_check584 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches584,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node585 T childKnown
  · exact hp4_4_node586 T childKnown
theorem hp4_4_node583 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected583 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected583 ((9 : Int),(1 : Int)) hp4_4_branches583 hp4_4_evidence583 hp4_4_check583 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches583,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node584 T childKnown
theorem hp4_4_node582 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected582 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected582 ((4 : Int),(2 : Int)) hp4_4_branches582 hp4_4_evidence582 hp4_4_check582 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches582,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node583 T childKnown
  · exact hp4_4_node587 T childKnown
theorem hp4_4_node581 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected581 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected581 ((2 : Int),(2 : Int)) hp4_4_branches581 hp4_4_evidence581 hp4_4_check581 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches581,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node582 T childKnown
  · exact hp4_4_node588 T childKnown
theorem hp4_4_node580 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected580 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected580 ((6 : Int),(0 : Int)) hp4_4_branches580 hp4_4_evidence580 hp4_4_check580 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches580,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node581 T childKnown
theorem hp4_4_node579 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected579 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected579 ((3 : Int),(2 : Int)) hp4_4_branches579 hp4_4_evidence579 hp4_4_check579 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches579,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node578 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected578 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected578 ((3 : Int),(2 : Int)) hp4_4_branches578 hp4_4_evidence578 hp4_4_check578 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches578,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node577 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected577 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected577 ((3 : Int),(1 : Int)) hp4_4_branches577 hp4_4_evidence577 hp4_4_check577 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches577,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node578 T childKnown
  · exact hp4_4_node579 T childKnown
theorem hp4_4_node576 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected576 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected576 ((11 : Int),(2 : Int)) hp4_4_branches576 hp4_4_evidence576 hp4_4_check576 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches576,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node575 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected575 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected575 ((11 : Int),(2 : Int)) hp4_4_branches575 hp4_4_evidence575 hp4_4_check575 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches575,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node574 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected574 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected574 ((11 : Int),(1 : Int)) hp4_4_branches574 hp4_4_evidence574 hp4_4_check574 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches574,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node575 T childKnown
  · exact hp4_4_node576 T childKnown
theorem hp4_4_node573 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected573 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected573 ((8 : Int),(2 : Int)) hp4_4_branches573 hp4_4_evidence573 hp4_4_check573 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches573,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node574 T childKnown
theorem hp4_4_node572 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected572 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected572 ((8 : Int),(2 : Int)) hp4_4_branches572 hp4_4_evidence572 hp4_4_check572 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches572,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node571 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected571 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected571 ((9 : Int),(1 : Int)) hp4_4_branches571 hp4_4_evidence571 hp4_4_check571 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches571,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node572 T childKnown
  · exact hp4_4_node573 T childKnown
theorem hp4_4_node570 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected570 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected570 ((6 : Int),(0 : Int)) hp4_4_branches570 hp4_4_evidence570 hp4_4_check570 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches570,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node571 T childKnown
theorem hp4_4_node569 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected569 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected569 ((6 : Int),(0 : Int)) hp4_4_branches569 hp4_4_evidence569 hp4_4_check569 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches569,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node568 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected568 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected568 ((3 : Int),(1 : Int)) hp4_4_branches568 hp4_4_evidence568 hp4_4_check568 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches568,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node569 T childKnown
  · exact hp4_4_node570 T childKnown
theorem hp4_4_node567 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected567 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected567 ((3 : Int),(2 : Int)) hp4_4_branches567 hp4_4_evidence567 hp4_4_check567 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches567,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node566 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected566 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected566 ((3 : Int),(2 : Int)) hp4_4_branches566 hp4_4_evidence566 hp4_4_check566 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches566,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node565 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected565 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected565 ((3 : Int),(1 : Int)) hp4_4_branches565 hp4_4_evidence565 hp4_4_check565 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches565,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node566 T childKnown
  · exact hp4_4_node567 T childKnown
theorem hp4_4_node564 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected564 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected564 ((2 : Int),(1 : Int)) hp4_4_branches564 hp4_4_evidence564 hp4_4_check564 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches564,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node565 T childKnown
  · exact hp4_4_node568 T childKnown
  · exact hp4_4_node577 T childKnown
  · exact hp4_4_node580 T childKnown
  · exact hp4_4_node594 T childKnown
  · exact hp4_4_node597 T childKnown
theorem hp4_4_node563 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected563 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected563 ((0 : Int),(2 : Int)) hp4_4_branches563 hp4_4_evidence563 hp4_4_check563 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches563,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node564 T childKnown
  · exact hp4_4_node601 T childKnown
  · exact hp4_4_node629 T childKnown
  · exact hp4_4_node635 T childKnown
theorem hp4_4_node562 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected562 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected562 ((0 : Int),(1 : Int)) hp4_4_branches562 hp4_4_evidence562 hp4_4_check562 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches562,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node563 T childKnown
  · exact hp4_4_node641 T childKnown
  · exact hp4_4_node719 T childKnown
  · exact hp4_4_node797 T childKnown
  · exact hp4_4_node834 T childKnown
  · exact hp4_4_node871 T childKnown
  · exact hp4_4_node927 T childKnown
  · exact hp4_4_node930 T childKnown
theorem hp4_4_node561 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected561 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected561 ((1 : Int),(1 : Int)) hp4_4_branches561 hp4_4_evidence561 hp4_4_check561 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches561,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node560 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected560 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected560 ((1 : Int),(0 : Int)) hp4_4_branches560 hp4_4_evidence560 hp4_4_check560 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches560,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node561 T childKnown
theorem hp4_4_node559 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected559 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected559 ((2 : Int),(2 : Int)) hp4_4_branches559 hp4_4_evidence559 hp4_4_check559 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches559,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node558 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected558 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected558 ((2 : Int),(2 : Int)) hp4_4_branches558 hp4_4_evidence558 hp4_4_check558 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches558,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node557 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected557 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected557 ((2 : Int),(2 : Int)) hp4_4_branches557 hp4_4_evidence557 hp4_4_check557 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches557,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node556 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected556 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected556 ((3 : Int),(2 : Int)) hp4_4_branches556 hp4_4_evidence556 hp4_4_check556 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches556,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node555 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected555 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected555 ((2 : Int),(2 : Int)) hp4_4_branches555 hp4_4_evidence555 hp4_4_check555 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches555,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node556 T childKnown
theorem hp4_4_node554 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected554 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected554 ((1 : Int),(2 : Int)) hp4_4_branches554 hp4_4_evidence554 hp4_4_check554 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches554,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node555 T childKnown
  · exact hp4_4_node557 T childKnown
  · exact hp4_4_node558 T childKnown
  · exact hp4_4_node559 T childKnown
theorem hp4_4_node553 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected553 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected553 ((1 : Int),(0 : Int)) hp4_4_branches553 hp4_4_evidence553 hp4_4_check553 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches553,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node554 T childKnown
theorem hp4_4_node552 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected552 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected552 ((1 : Int),(1 : Int)) hp4_4_branches552 hp4_4_evidence552 hp4_4_check552 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches552,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node551 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected551 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected551 ((1 : Int),(0 : Int)) hp4_4_branches551 hp4_4_evidence551 hp4_4_check551 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches551,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node552 T childKnown
theorem hp4_4_node550 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected550 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected550 ((6 : Int),(1 : Int)) hp4_4_branches550 hp4_4_evidence550 hp4_4_check550 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches550,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node549 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected549 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected549 ((4 : Int),(1 : Int)) hp4_4_branches549 hp4_4_evidence549 hp4_4_check549 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches549,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node548 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected548 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected548 ((4 : Int),(1 : Int)) hp4_4_branches548 hp4_4_evidence548 hp4_4_check548 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches548,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node547 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected547 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected547 ((4 : Int),(1 : Int)) hp4_4_branches547 hp4_4_evidence547 hp4_4_check547 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches547,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node546 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected546 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected546 ((5 : Int),(1 : Int)) hp4_4_branches546 hp4_4_evidence546 hp4_4_check546 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches546,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node547 T childKnown
  · exact hp4_4_node548 T childKnown
  · exact hp4_4_node549 T childKnown
  · exact hp4_4_node550 T childKnown
theorem hp4_4_node545 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected545 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected545 ((5 : Int),(1 : Int)) hp4_4_branches545 hp4_4_evidence545 hp4_4_check545 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches545,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node544 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected544 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected544 ((5 : Int),(1 : Int)) hp4_4_branches544 hp4_4_evidence544 hp4_4_check544 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches544,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node543 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected543 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected543 ((5 : Int),(1 : Int)) hp4_4_branches543 hp4_4_evidence543 hp4_4_check543 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches543,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node542 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected542 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected542 ((0 : Int),(2 : Int)) hp4_4_branches542 hp4_4_evidence542 hp4_4_check542 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches542,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node541 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected541 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected541 ((0 : Int),(2 : Int)) hp4_4_branches541 hp4_4_evidence541 hp4_4_check541 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches541,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node540 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected540 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected540 ((2 : Int),(1 : Int)) hp4_4_branches540 hp4_4_evidence540 hp4_4_check540 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches540,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node541 T childKnown
  · exact hp4_4_node542 T childKnown
theorem hp4_4_node539 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected539 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected539 ((5 : Int),(1 : Int)) hp4_4_branches539 hp4_4_evidence539 hp4_4_check539 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches539,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node540 T childKnown
theorem hp4_4_node538 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected538 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected538 ((4 : Int),(1 : Int)) hp4_4_branches538 hp4_4_evidence538 hp4_4_check538 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches538,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node539 T childKnown
  · exact hp4_4_node543 T childKnown
  · exact hp4_4_node544 T childKnown
  · exact hp4_4_node545 T childKnown
theorem hp4_4_node537 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected537 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected537 ((6 : Int),(1 : Int)) hp4_4_branches537 hp4_4_evidence537 hp4_4_check537 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches537,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node536 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected536 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected536 ((6 : Int),(0 : Int)) hp4_4_branches536 hp4_4_evidence536 hp4_4_check536 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches536,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node537 T childKnown
theorem hp4_4_node535 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected535 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected535 ((4 : Int),(1 : Int)) hp4_4_branches535 hp4_4_evidence535 hp4_4_check535 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches535,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node536 T childKnown
theorem hp4_4_node534 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected534 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected534 ((0 : Int),(2 : Int)) hp4_4_branches534 hp4_4_evidence534 hp4_4_check534 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches534,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node533 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected533 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected533 ((0 : Int),(2 : Int)) hp4_4_branches533 hp4_4_evidence533 hp4_4_check533 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches533,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node532 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected532 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected532 ((2 : Int),(1 : Int)) hp4_4_branches532 hp4_4_evidence532 hp4_4_check532 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches532,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node533 T childKnown
  · exact hp4_4_node534 T childKnown
theorem hp4_4_node531 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected531 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected531 ((6 : Int),(0 : Int)) hp4_4_branches531 hp4_4_evidence531 hp4_4_check531 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches531,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node532 T childKnown
theorem hp4_4_node530 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected530 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected530 ((4 : Int),(1 : Int)) hp4_4_branches530 hp4_4_evidence530 hp4_4_check530 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches530,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node531 T childKnown
theorem hp4_4_node529 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected529 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected529 ((4 : Int),(1 : Int)) hp4_4_branches529 hp4_4_evidence529 hp4_4_check529 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches529,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node528 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected528 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected528 ((5 : Int),(0 : Int)) hp4_4_branches528 hp4_4_evidence528 hp4_4_check528 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches528,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node529 T childKnown
  · exact hp4_4_node530 T childKnown
  · exact hp4_4_node535 T childKnown
  · exact hp4_4_node538 T childKnown
  · exact hp4_4_node546 T childKnown
theorem hp4_4_node527 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected527 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected527 ((8 : Int),(1 : Int)) hp4_4_branches527 hp4_4_evidence527 hp4_4_check527 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches527,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node526 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected526 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected526 ((6 : Int),(2 : Int)) hp4_4_branches526 hp4_4_evidence526 hp4_4_check526 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches526,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node525 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected525 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected525 ((7 : Int),(1 : Int)) hp4_4_branches525 hp4_4_evidence525 hp4_4_check525 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches525,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node526 T childKnown
  · exact hp4_4_node527 T childKnown
theorem hp4_4_node524 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected524 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected524 ((5 : Int),(0 : Int)) hp4_4_branches524 hp4_4_evidence524 hp4_4_check524 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches524,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node525 T childKnown
theorem hp4_4_node523 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected523 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected523 ((2 : Int),(2 : Int)) hp4_4_branches523 hp4_4_evidence523 hp4_4_check523 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches523,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node522 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected522 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected522 ((2 : Int),(2 : Int)) hp4_4_branches522 hp4_4_evidence522 hp4_4_check522 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches522,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node521 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected521 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected521 ((2 : Int),(2 : Int)) hp4_4_branches521 hp4_4_evidence521 hp4_4_check521 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches521,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node520 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected520 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected520 ((3 : Int),(2 : Int)) hp4_4_branches520 hp4_4_evidence520 hp4_4_check520 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches520,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node519 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected519 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected519 ((2 : Int),(2 : Int)) hp4_4_branches519 hp4_4_evidence519 hp4_4_check519 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches519,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node520 T childKnown
theorem hp4_4_node518 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected518 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected518 ((1 : Int),(2 : Int)) hp4_4_branches518 hp4_4_evidence518 hp4_4_check518 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches518,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node519 T childKnown
  · exact hp4_4_node521 T childKnown
  · exact hp4_4_node522 T childKnown
  · exact hp4_4_node523 T childKnown
theorem hp4_4_node517 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected517 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected517 ((7 : Int),(1 : Int)) hp4_4_branches517 hp4_4_evidence517 hp4_4_check517 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches517,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node516 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected516 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected516 ((10 : Int),(2 : Int)) hp4_4_branches516 hp4_4_evidence516 hp4_4_check516 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches516,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node515 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected515 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected515 ((10 : Int),(2 : Int)) hp4_4_branches515 hp4_4_evidence515 hp4_4_check515 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches515,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node514 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected514 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected514 ((10 : Int),(1 : Int)) hp4_4_branches514 hp4_4_evidence514 hp4_4_check514 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches514,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node515 T childKnown
  · exact hp4_4_node516 T childKnown
theorem hp4_4_node513 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected513 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected513 ((8 : Int),(1 : Int)) hp4_4_branches513 hp4_4_evidence513 hp4_4_check513 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches513,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node514 T childKnown
theorem hp4_4_node512 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected512 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected512 ((3 : Int),(2 : Int)) hp4_4_branches512 hp4_4_evidence512 hp4_4_check512 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches512,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node513 T childKnown
  · exact hp4_4_node517 T childKnown
theorem hp4_4_node511 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected511 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected511 ((7 : Int),(1 : Int)) hp4_4_branches511 hp4_4_evidence511 hp4_4_check511 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches511,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node510 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected510 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected510 ((10 : Int),(2 : Int)) hp4_4_branches510 hp4_4_evidence510 hp4_4_check510 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches510,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node509 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected509 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected509 ((10 : Int),(2 : Int)) hp4_4_branches509 hp4_4_evidence509 hp4_4_check509 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches509,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node508 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected508 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected508 ((10 : Int),(1 : Int)) hp4_4_branches508 hp4_4_evidence508 hp4_4_check508 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches508,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node509 T childKnown
  · exact hp4_4_node510 T childKnown
theorem hp4_4_node507 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected507 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected507 ((8 : Int),(1 : Int)) hp4_4_branches507 hp4_4_evidence507 hp4_4_check507 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches507,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node508 T childKnown
theorem hp4_4_node506 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected506 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected506 ((3 : Int),(2 : Int)) hp4_4_branches506 hp4_4_evidence506 hp4_4_check506 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches506,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node507 T childKnown
  · exact hp4_4_node511 T childKnown
theorem hp4_4_node505 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected505 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected505 ((7 : Int),(1 : Int)) hp4_4_branches505 hp4_4_evidence505 hp4_4_check505 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches505,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node504 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected504 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected504 ((10 : Int),(2 : Int)) hp4_4_branches504 hp4_4_evidence504 hp4_4_check504 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches504,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node503 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected503 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected503 ((10 : Int),(2 : Int)) hp4_4_branches503 hp4_4_evidence503 hp4_4_check503 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches503,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node502 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected502 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected502 ((10 : Int),(1 : Int)) hp4_4_branches502 hp4_4_evidence502 hp4_4_check502 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches502,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node503 T childKnown
  · exact hp4_4_node504 T childKnown
theorem hp4_4_node501 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected501 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected501 ((8 : Int),(1 : Int)) hp4_4_branches501 hp4_4_evidence501 hp4_4_check501 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches501,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node502 T childKnown
theorem hp4_4_node500 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected500 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected500 ((7 : Int),(1 : Int)) hp4_4_branches500 hp4_4_evidence500 hp4_4_check500 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches500,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node499 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected499 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected499 ((7 : Int),(1 : Int)) hp4_4_branches499 hp4_4_evidence499 hp4_4_check499 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches499,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node498 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected498 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected498 ((4 : Int),(2 : Int)) hp4_4_branches498 hp4_4_evidence498 hp4_4_check498 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches498,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node499 T childKnown
theorem hp4_4_node497 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected497 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected497 ((7 : Int),(1 : Int)) hp4_4_branches497 hp4_4_evidence497 hp4_4_check497 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches497,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node496 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected496 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected496 ((3 : Int),(2 : Int)) hp4_4_branches496 hp4_4_evidence496 hp4_4_check496 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches496,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node497 T childKnown
  · exact hp4_4_node498 T childKnown
  · exact hp4_4_node500 T childKnown
  · exact hp4_4_node501 T childKnown
  · exact hp4_4_node505 T childKnown
theorem hp4_4_node495 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected495 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected495 ((3 : Int),(2 : Int)) hp4_4_branches495 hp4_4_evidence495 hp4_4_check495 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches495,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node494 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected494 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected494 ((6 : Int),(2 : Int)) hp4_4_branches494 hp4_4_evidence494 hp4_4_check494 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches494,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node493 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected493 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected493 ((3 : Int),(2 : Int)) hp4_4_branches493 hp4_4_evidence493 hp4_4_check493 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches493,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node492 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected492 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected492 ((3 : Int),(2 : Int)) hp4_4_branches492 hp4_4_evidence492 hp4_4_check492 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches492,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node491 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected491 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected491 ((10 : Int),(2 : Int)) hp4_4_branches491 hp4_4_evidence491 hp4_4_check491 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches491,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node490 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected490 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected490 ((10 : Int),(2 : Int)) hp4_4_branches490 hp4_4_evidence490 hp4_4_check490 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches490,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node489 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected489 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected489 ((10 : Int),(1 : Int)) hp4_4_branches489 hp4_4_evidence489 hp4_4_check489 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches489,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node490 T childKnown
  · exact hp4_4_node491 T childKnown
theorem hp4_4_node488 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected488 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected488 ((8 : Int),(1 : Int)) hp4_4_branches488 hp4_4_evidence488 hp4_4_check488 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches488,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node489 T childKnown
theorem hp4_4_node487 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected487 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected487 ((7 : Int),(1 : Int)) hp4_4_branches487 hp4_4_evidence487 hp4_4_check487 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches487,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node488 T childKnown
  · exact hp4_4_node492 T childKnown
  · exact hp4_4_node493 T childKnown
  · exact hp4_4_node494 T childKnown
  · exact hp4_4_node495 T childKnown
theorem hp4_4_node486 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected486 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected486 ((1 : Int),(2 : Int)) hp4_4_branches486 hp4_4_evidence486 hp4_4_check486 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches486,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node487 T childKnown
  · exact hp4_4_node496 T childKnown
  · exact hp4_4_node506 T childKnown
  · exact hp4_4_node512 T childKnown
theorem hp4_4_node485 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected485 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected485 ((5 : Int),(0 : Int)) hp4_4_branches485 hp4_4_evidence485 hp4_4_check485 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches485,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node486 T childKnown
theorem hp4_4_node484 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected484 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected484 ((2 : Int),(2 : Int)) hp4_4_branches484 hp4_4_evidence484 hp4_4_check484 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches484,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node483 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected483 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected483 ((2 : Int),(2 : Int)) hp4_4_branches483 hp4_4_evidence483 hp4_4_check483 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches483,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node482 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected482 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected482 ((2 : Int),(1 : Int)) hp4_4_branches482 hp4_4_evidence482 hp4_4_check482 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches482,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node483 T childKnown
  · exact hp4_4_node484 T childKnown
theorem hp4_4_node481 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected481 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected481 ((10 : Int),(2 : Int)) hp4_4_branches481 hp4_4_evidence481 hp4_4_check481 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches481,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node480 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected480 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected480 ((10 : Int),(2 : Int)) hp4_4_branches480 hp4_4_evidence480 hp4_4_check480 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches480,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node479 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected479 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected479 ((10 : Int),(1 : Int)) hp4_4_branches479 hp4_4_evidence479 hp4_4_check479 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches479,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node480 T childKnown
  · exact hp4_4_node481 T childKnown
theorem hp4_4_node478 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected478 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected478 ((7 : Int),(2 : Int)) hp4_4_branches478 hp4_4_evidence478 hp4_4_check478 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches478,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node479 T childKnown
theorem hp4_4_node477 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected477 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected477 ((7 : Int),(2 : Int)) hp4_4_branches477 hp4_4_evidence477 hp4_4_check477 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches477,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node476 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected476 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected476 ((8 : Int),(1 : Int)) hp4_4_branches476 hp4_4_evidence476 hp4_4_check476 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches476,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node477 T childKnown
  · exact hp4_4_node478 T childKnown
theorem hp4_4_node475 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected475 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected475 ((5 : Int),(0 : Int)) hp4_4_branches475 hp4_4_evidence475 hp4_4_check475 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches475,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node476 T childKnown
theorem hp4_4_node474 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected474 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected474 ((5 : Int),(0 : Int)) hp4_4_branches474 hp4_4_evidence474 hp4_4_check474 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches474,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node473 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected473 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected473 ((2 : Int),(1 : Int)) hp4_4_branches473 hp4_4_evidence473 hp4_4_check473 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches473,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node474 T childKnown
  · exact hp4_4_node475 T childKnown
theorem hp4_4_node472 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected472 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected472 ((2 : Int),(2 : Int)) hp4_4_branches472 hp4_4_evidence472 hp4_4_check472 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches472,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node471 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected471 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected471 ((2 : Int),(2 : Int)) hp4_4_branches471 hp4_4_evidence471 hp4_4_check471 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches471,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node470 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected470 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected470 ((2 : Int),(1 : Int)) hp4_4_branches470 hp4_4_evidence470 hp4_4_check470 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches470,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node471 T childKnown
  · exact hp4_4_node472 T childKnown
theorem hp4_4_node469 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected469 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected469 ((2 : Int),(2 : Int)) hp4_4_branches469 hp4_4_evidence469 hp4_4_check469 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches469,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node468 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected468 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected468 ((2 : Int),(2 : Int)) hp4_4_branches468 hp4_4_evidence468 hp4_4_check468 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches468,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node467 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected467 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected467 ((2 : Int),(2 : Int)) hp4_4_branches467 hp4_4_evidence467 hp4_4_check467 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches467,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node466 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected466 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected466 ((2 : Int),(1 : Int)) hp4_4_branches466 hp4_4_evidence466 hp4_4_check466 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches466,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_4_node467 T childKnown
  · exact hp4_4_node468 T childKnown
  · exact hp4_4_node469 T childKnown
theorem hp4_4_node465 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected465 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected465 ((3 : Int),(2 : Int)) hp4_4_branches465 hp4_4_evidence465 hp4_4_check465 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches465,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node464 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected464 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected464 ((2 : Int),(2 : Int)) hp4_4_branches464 hp4_4_evidence464 hp4_4_check464 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches464,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node465 T childKnown
theorem hp4_4_node463 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected463 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected463 ((5 : Int),(0 : Int)) hp4_4_branches463 hp4_4_evidence463 hp4_4_check463 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches463,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node462 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected462 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected462 ((10 : Int),(1 : Int)) hp4_4_branches462 hp4_4_evidence462 hp4_4_check462 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches462,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node461 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected461 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected461 ((10 : Int),(1 : Int)) hp4_4_branches461 hp4_4_evidence461 hp4_4_check461 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches461,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node460 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected460 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected460 ((11 : Int),(1 : Int)) hp4_4_branches460 hp4_4_evidence460 hp4_4_check460 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches460,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node461 T childKnown
  · exact hp4_4_node462 T childKnown
theorem hp4_4_node459 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected459 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected459 ((11 : Int),(1 : Int)) hp4_4_branches459 hp4_4_evidence459 hp4_4_check459 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches459,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node458 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected458 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected458 ((11 : Int),(1 : Int)) hp4_4_branches458 hp4_4_evidence458 hp4_4_check458 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches458,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node457 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected457 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected457 ((10 : Int),(1 : Int)) hp4_4_branches457 hp4_4_evidence457 hp4_4_check457 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches457,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node458 T childKnown
  · exact hp4_4_node459 T childKnown
theorem hp4_4_node456 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected456 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected456 ((10 : Int),(1 : Int)) hp4_4_branches456 hp4_4_evidence456 hp4_4_check456 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches456,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node455 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected455 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected455 ((10 : Int),(1 : Int)) hp4_4_branches455 hp4_4_evidence455 hp4_4_check455 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches455,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node454 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected454 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected454 ((10 : Int),(1 : Int)) hp4_4_branches454 hp4_4_evidence454 hp4_4_check454 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches454,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node453 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected453 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected453 ((11 : Int),(0 : Int)) hp4_4_branches453 hp4_4_evidence453 hp4_4_check453 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches453,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node454 T childKnown
  · exact hp4_4_node455 T childKnown
  · exact hp4_4_node456 T childKnown
  · exact hp4_4_node457 T childKnown
  · exact hp4_4_node460 T childKnown
theorem hp4_4_node452 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected452 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected452 ((4 : Int),(2 : Int)) hp4_4_branches452 hp4_4_evidence452 hp4_4_check452 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches452,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node453 T childKnown
theorem hp4_4_node451 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected451 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected451 ((5 : Int),(0 : Int)) hp4_4_branches451 hp4_4_evidence451 hp4_4_check451 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches451,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node452 T childKnown
theorem hp4_4_node450 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected450 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected450 ((2 : Int),(2 : Int)) hp4_4_branches450 hp4_4_evidence450 hp4_4_check450 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches450,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node451 T childKnown
theorem hp4_4_node449 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected449 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected449 ((3 : Int),(2 : Int)) hp4_4_branches449 hp4_4_evidence449 hp4_4_check449 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches449,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node448 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected448 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected448 ((3 : Int),(2 : Int)) hp4_4_branches448 hp4_4_evidence448 hp4_4_check448 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches448,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node447 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected447 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected447 ((3 : Int),(1 : Int)) hp4_4_branches447 hp4_4_evidence447 hp4_4_check447 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches447,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node448 T childKnown
  · exact hp4_4_node449 T childKnown
theorem hp4_4_node446 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected446 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected446 ((10 : Int),(1 : Int)) hp4_4_branches446 hp4_4_evidence446 hp4_4_check446 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches446,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node445 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected445 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected445 ((10 : Int),(1 : Int)) hp4_4_branches445 hp4_4_evidence445 hp4_4_check445 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches445,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node444 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected444 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected444 ((11 : Int),(1 : Int)) hp4_4_branches444 hp4_4_evidence444 hp4_4_check444 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches444,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node443 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected443 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected443 ((11 : Int),(1 : Int)) hp4_4_branches443 hp4_4_evidence443 hp4_4_check443 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches443,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node442 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected442 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected442 ((11 : Int),(0 : Int)) hp4_4_branches442 hp4_4_evidence442 hp4_4_check442 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches442,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node443 T childKnown
  · exact hp4_4_node444 T childKnown
theorem hp4_4_node441 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected441 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected441 ((10 : Int),(2 : Int)) hp4_4_branches441 hp4_4_evidence441 hp4_4_check441 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches441,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_4_node442 T childKnown
  · exact hp4_4_node445 T childKnown
  · exact hp4_4_node446 T childKnown
theorem hp4_4_node440 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected440 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected440 ((10 : Int),(1 : Int)) hp4_4_branches440 hp4_4_evidence440 hp4_4_check440 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches440,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node439 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected439 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected439 ((10 : Int),(1 : Int)) hp4_4_branches439 hp4_4_evidence439 hp4_4_check439 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches439,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node438 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected438 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected438 ((11 : Int),(1 : Int)) hp4_4_branches438 hp4_4_evidence438 hp4_4_check438 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches438,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node437 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected437 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected437 ((11 : Int),(1 : Int)) hp4_4_branches437 hp4_4_evidence437 hp4_4_check437 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches437,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node436 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected436 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected436 ((11 : Int),(0 : Int)) hp4_4_branches436 hp4_4_evidence436 hp4_4_check436 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches436,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node437 T childKnown
  · exact hp4_4_node438 T childKnown
theorem hp4_4_node435 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected435 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected435 ((10 : Int),(2 : Int)) hp4_4_branches435 hp4_4_evidence435 hp4_4_check435 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches435,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_4_node436 T childKnown
  · exact hp4_4_node439 T childKnown
  · exact hp4_4_node440 T childKnown
theorem hp4_4_node434 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected434 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected434 ((10 : Int),(1 : Int)) hp4_4_branches434 hp4_4_evidence434 hp4_4_check434 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches434,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node433 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected433 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected433 ((10 : Int),(1 : Int)) hp4_4_branches433 hp4_4_evidence433 hp4_4_check433 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches433,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node432 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected432 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected432 ((11 : Int),(1 : Int)) hp4_4_branches432 hp4_4_evidence432 hp4_4_check432 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches432,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node433 T childKnown
  · exact hp4_4_node434 T childKnown
theorem hp4_4_node431 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected431 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected431 ((11 : Int),(1 : Int)) hp4_4_branches431 hp4_4_evidence431 hp4_4_check431 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches431,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node430 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected430 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected430 ((11 : Int),(1 : Int)) hp4_4_branches430 hp4_4_evidence430 hp4_4_check430 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches430,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node429 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected429 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected429 ((10 : Int),(1 : Int)) hp4_4_branches429 hp4_4_evidence429 hp4_4_check429 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches429,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node430 T childKnown
  · exact hp4_4_node431 T childKnown
theorem hp4_4_node428 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected428 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected428 ((10 : Int),(1 : Int)) hp4_4_branches428 hp4_4_evidence428 hp4_4_check428 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches428,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node427 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected427 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected427 ((10 : Int),(1 : Int)) hp4_4_branches427 hp4_4_evidence427 hp4_4_check427 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches427,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node426 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected426 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected426 ((10 : Int),(1 : Int)) hp4_4_branches426 hp4_4_evidence426 hp4_4_check426 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches426,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node425 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected425 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected425 ((11 : Int),(0 : Int)) hp4_4_branches425 hp4_4_evidence425 hp4_4_check425 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches425,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node426 T childKnown
  · exact hp4_4_node427 T childKnown
  · exact hp4_4_node428 T childKnown
  · exact hp4_4_node429 T childKnown
  · exact hp4_4_node432 T childKnown
theorem hp4_4_node424 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected424 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected424 ((10 : Int),(1 : Int)) hp4_4_branches424 hp4_4_evidence424 hp4_4_check424 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches424,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node423 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected423 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected423 ((10 : Int),(1 : Int)) hp4_4_branches423 hp4_4_evidence423 hp4_4_check423 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches423,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node422 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected422 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected422 ((11 : Int),(1 : Int)) hp4_4_branches422 hp4_4_evidence422 hp4_4_check422 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches422,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node423 T childKnown
  · exact hp4_4_node424 T childKnown
theorem hp4_4_node421 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected421 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected421 ((11 : Int),(1 : Int)) hp4_4_branches421 hp4_4_evidence421 hp4_4_check421 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches421,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node420 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected420 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected420 ((11 : Int),(1 : Int)) hp4_4_branches420 hp4_4_evidence420 hp4_4_check420 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches420,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node419 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected419 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected419 ((10 : Int),(1 : Int)) hp4_4_branches419 hp4_4_evidence419 hp4_4_check419 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches419,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node420 T childKnown
  · exact hp4_4_node421 T childKnown
theorem hp4_4_node418 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected418 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected418 ((10 : Int),(1 : Int)) hp4_4_branches418 hp4_4_evidence418 hp4_4_check418 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches418,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node417 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected417 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected417 ((10 : Int),(1 : Int)) hp4_4_branches417 hp4_4_evidence417 hp4_4_check417 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches417,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node416 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected416 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected416 ((10 : Int),(1 : Int)) hp4_4_branches416 hp4_4_evidence416 hp4_4_check416 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches416,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node415 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected415 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected415 ((11 : Int),(0 : Int)) hp4_4_branches415 hp4_4_evidence415 hp4_4_check415 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches415,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node416 T childKnown
  · exact hp4_4_node417 T childKnown
  · exact hp4_4_node418 T childKnown
  · exact hp4_4_node419 T childKnown
  · exact hp4_4_node422 T childKnown
theorem hp4_4_node414 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected414 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected414 ((8 : Int),(2 : Int)) hp4_4_branches414 hp4_4_evidence414 hp4_4_check414 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches414,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node415 T childKnown
  · exact hp4_4_node425 T childKnown
  · exact hp4_4_node435 T childKnown
  · exact hp4_4_node441 T childKnown
theorem hp4_4_node413 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected413 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected413 ((3 : Int),(1 : Int)) hp4_4_branches413 hp4_4_evidence413 hp4_4_check413 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches413,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node414 T childKnown
theorem hp4_4_node412 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected412 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected412 ((5 : Int),(0 : Int)) hp4_4_branches412 hp4_4_evidence412 hp4_4_check412 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches412,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node413 T childKnown
theorem hp4_4_node411 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected411 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected411 ((2 : Int),(1 : Int)) hp4_4_branches411 hp4_4_evidence411 hp4_4_check411 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches411,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node412 T childKnown
  · exact hp4_4_node447 T childKnown
  · exact hp4_4_node450 T childKnown
  · exact hp4_4_node463 T childKnown
  · exact hp4_4_node464 T childKnown
theorem hp4_4_node410 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected410 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected410 ((1 : Int),(1 : Int)) hp4_4_branches410 hp4_4_evidence410 hp4_4_check410 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches410,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node411 T childKnown
  · exact hp4_4_node466 T childKnown
  · exact hp4_4_node470 T childKnown
  · exact hp4_4_node473 T childKnown
  · exact hp4_4_node482 T childKnown
  · exact hp4_4_node485 T childKnown
  · exact hp4_4_node518 T childKnown
  · exact hp4_4_node524 T childKnown
theorem hp4_4_node409 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected409 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected409 ((5 : Int),(1 : Int)) hp4_4_branches409 hp4_4_evidence409 hp4_4_check409 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches409,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node408 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected408 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected408 ((3 : Int),(1 : Int)) hp4_4_branches408 hp4_4_evidence408 hp4_4_check408 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches408,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node407 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected407 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected407 ((3 : Int),(1 : Int)) hp4_4_branches407 hp4_4_evidence407 hp4_4_check407 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches407,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node406 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected406 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected406 ((3 : Int),(1 : Int)) hp4_4_branches406 hp4_4_evidence406 hp4_4_check406 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches406,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node405 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected405 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected405 ((4 : Int),(1 : Int)) hp4_4_branches405 hp4_4_evidence405 hp4_4_check405 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches405,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node406 T childKnown
  · exact hp4_4_node407 T childKnown
  · exact hp4_4_node408 T childKnown
  · exact hp4_4_node409 T childKnown
theorem hp4_4_node404 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected404 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected404 ((4 : Int),(1 : Int)) hp4_4_branches404 hp4_4_evidence404 hp4_4_check404 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches404,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node403 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected403 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected403 ((4 : Int),(1 : Int)) hp4_4_branches403 hp4_4_evidence403 hp4_4_check403 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches403,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node402 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected402 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected402 ((4 : Int),(1 : Int)) hp4_4_branches402 hp4_4_evidence402 hp4_4_check402 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches402,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node401 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected401 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected401 ((0 : Int),(2 : Int)) hp4_4_branches401 hp4_4_evidence401 hp4_4_check401 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches401,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node400 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected400 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected400 ((0 : Int),(2 : Int)) hp4_4_branches400 hp4_4_evidence400 hp4_4_check400 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches400,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node399 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected399 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected399 ((1 : Int),(1 : Int)) hp4_4_branches399 hp4_4_evidence399 hp4_4_check399 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches399,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node400 T childKnown
  · exact hp4_4_node401 T childKnown
theorem hp4_4_node398 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected398 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected398 ((4 : Int),(1 : Int)) hp4_4_branches398 hp4_4_evidence398 hp4_4_check398 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches398,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node399 T childKnown
theorem hp4_4_node397 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected397 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected397 ((3 : Int),(1 : Int)) hp4_4_branches397 hp4_4_evidence397 hp4_4_check397 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches397,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node398 T childKnown
  · exact hp4_4_node402 T childKnown
  · exact hp4_4_node403 T childKnown
  · exact hp4_4_node404 T childKnown
theorem hp4_4_node396 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected396 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected396 ((5 : Int),(1 : Int)) hp4_4_branches396 hp4_4_evidence396 hp4_4_check396 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches396,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node395 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected395 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected395 ((5 : Int),(0 : Int)) hp4_4_branches395 hp4_4_evidence395 hp4_4_check395 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches395,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node396 T childKnown
theorem hp4_4_node394 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected394 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected394 ((3 : Int),(1 : Int)) hp4_4_branches394 hp4_4_evidence394 hp4_4_check394 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches394,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node395 T childKnown
theorem hp4_4_node393 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected393 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected393 ((0 : Int),(2 : Int)) hp4_4_branches393 hp4_4_evidence393 hp4_4_check393 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches393,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node392 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected392 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected392 ((0 : Int),(2 : Int)) hp4_4_branches392 hp4_4_evidence392 hp4_4_check392 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches392,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node391 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected391 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected391 ((1 : Int),(1 : Int)) hp4_4_branches391 hp4_4_evidence391 hp4_4_check391 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches391,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node392 T childKnown
  · exact hp4_4_node393 T childKnown
theorem hp4_4_node390 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected390 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected390 ((5 : Int),(0 : Int)) hp4_4_branches390 hp4_4_evidence390 hp4_4_check390 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches390,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node391 T childKnown
theorem hp4_4_node389 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected389 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected389 ((3 : Int),(1 : Int)) hp4_4_branches389 hp4_4_evidence389 hp4_4_check389 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches389,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node390 T childKnown
theorem hp4_4_node388 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected388 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected388 ((3 : Int),(1 : Int)) hp4_4_branches388 hp4_4_evidence388 hp4_4_check388 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches388,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node387 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected387 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected387 ((4 : Int),(0 : Int)) hp4_4_branches387 hp4_4_evidence387 hp4_4_check387 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches387,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node388 T childKnown
  · exact hp4_4_node389 T childKnown
  · exact hp4_4_node394 T childKnown
  · exact hp4_4_node397 T childKnown
  · exact hp4_4_node405 T childKnown
theorem hp4_4_node386 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected386 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected386 ((7 : Int),(1 : Int)) hp4_4_branches386 hp4_4_evidence386 hp4_4_check386 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches386,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node385 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected385 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected385 ((5 : Int),(2 : Int)) hp4_4_branches385 hp4_4_evidence385 hp4_4_check385 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches385,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node384 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected384 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected384 ((6 : Int),(1 : Int)) hp4_4_branches384 hp4_4_evidence384 hp4_4_check384 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches384,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node385 T childKnown
  · exact hp4_4_node386 T childKnown
theorem hp4_4_node383 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected383 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected383 ((4 : Int),(0 : Int)) hp4_4_branches383 hp4_4_evidence383 hp4_4_check383 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches383,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node384 T childKnown
theorem hp4_4_node382 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected382 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected382 ((1 : Int),(2 : Int)) hp4_4_branches382 hp4_4_evidence382 hp4_4_check382 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches382,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node381 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected381 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected381 ((1 : Int),(2 : Int)) hp4_4_branches381 hp4_4_evidence381 hp4_4_check381 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches381,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node380 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected380 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected380 ((1 : Int),(2 : Int)) hp4_4_branches380 hp4_4_evidence380 hp4_4_check380 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches380,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node379 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected379 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected379 ((2 : Int),(2 : Int)) hp4_4_branches379 hp4_4_evidence379 hp4_4_check379 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches379,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node378 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected378 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected378 ((1 : Int),(2 : Int)) hp4_4_branches378 hp4_4_evidence378 hp4_4_check378 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches378,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node379 T childKnown
theorem hp4_4_node377 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected377 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected377 ((0 : Int),(2 : Int)) hp4_4_branches377 hp4_4_evidence377 hp4_4_check377 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches377,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node378 T childKnown
  · exact hp4_4_node380 T childKnown
  · exact hp4_4_node381 T childKnown
  · exact hp4_4_node382 T childKnown
theorem hp4_4_node376 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected376 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected376 ((6 : Int),(1 : Int)) hp4_4_branches376 hp4_4_evidence376 hp4_4_check376 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches376,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node375 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected375 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected375 ((9 : Int),(2 : Int)) hp4_4_branches375 hp4_4_evidence375 hp4_4_check375 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches375,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node374 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected374 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected374 ((9 : Int),(2 : Int)) hp4_4_branches374 hp4_4_evidence374 hp4_4_check374 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches374,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node373 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected373 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected373 ((9 : Int),(1 : Int)) hp4_4_branches373 hp4_4_evidence373 hp4_4_check373 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches373,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node374 T childKnown
  · exact hp4_4_node375 T childKnown
theorem hp4_4_node372 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected372 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected372 ((7 : Int),(1 : Int)) hp4_4_branches372 hp4_4_evidence372 hp4_4_check372 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches372,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node373 T childKnown
theorem hp4_4_node371 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected371 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected371 ((2 : Int),(2 : Int)) hp4_4_branches371 hp4_4_evidence371 hp4_4_check371 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches371,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node372 T childKnown
  · exact hp4_4_node376 T childKnown
theorem hp4_4_node370 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected370 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected370 ((6 : Int),(1 : Int)) hp4_4_branches370 hp4_4_evidence370 hp4_4_check370 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches370,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node369 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected369 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected369 ((9 : Int),(2 : Int)) hp4_4_branches369 hp4_4_evidence369 hp4_4_check369 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches369,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node368 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected368 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected368 ((9 : Int),(2 : Int)) hp4_4_branches368 hp4_4_evidence368 hp4_4_check368 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches368,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node367 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected367 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected367 ((9 : Int),(1 : Int)) hp4_4_branches367 hp4_4_evidence367 hp4_4_check367 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches367,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node368 T childKnown
  · exact hp4_4_node369 T childKnown
theorem hp4_4_node366 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected366 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected366 ((7 : Int),(1 : Int)) hp4_4_branches366 hp4_4_evidence366 hp4_4_check366 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches366,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node367 T childKnown
theorem hp4_4_node365 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected365 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected365 ((2 : Int),(2 : Int)) hp4_4_branches365 hp4_4_evidence365 hp4_4_check365 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches365,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node366 T childKnown
  · exact hp4_4_node370 T childKnown
theorem hp4_4_node364 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected364 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected364 ((6 : Int),(1 : Int)) hp4_4_branches364 hp4_4_evidence364 hp4_4_check364 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches364,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node363 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected363 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected363 ((9 : Int),(2 : Int)) hp4_4_branches363 hp4_4_evidence363 hp4_4_check363 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches363,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node362 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected362 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected362 ((9 : Int),(2 : Int)) hp4_4_branches362 hp4_4_evidence362 hp4_4_check362 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches362,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node361 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected361 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected361 ((9 : Int),(1 : Int)) hp4_4_branches361 hp4_4_evidence361 hp4_4_check361 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches361,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node362 T childKnown
  · exact hp4_4_node363 T childKnown
theorem hp4_4_node360 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected360 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected360 ((7 : Int),(1 : Int)) hp4_4_branches360 hp4_4_evidence360 hp4_4_check360 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches360,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node361 T childKnown
theorem hp4_4_node359 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected359 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected359 ((6 : Int),(1 : Int)) hp4_4_branches359 hp4_4_evidence359 hp4_4_check359 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches359,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node358 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected358 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected358 ((6 : Int),(1 : Int)) hp4_4_branches358 hp4_4_evidence358 hp4_4_check358 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches358,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node357 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected357 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected357 ((3 : Int),(2 : Int)) hp4_4_branches357 hp4_4_evidence357 hp4_4_check357 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches357,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node358 T childKnown
theorem hp4_4_node356 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected356 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected356 ((6 : Int),(1 : Int)) hp4_4_branches356 hp4_4_evidence356 hp4_4_check356 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches356,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node355 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected355 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected355 ((2 : Int),(2 : Int)) hp4_4_branches355 hp4_4_evidence355 hp4_4_check355 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches355,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node356 T childKnown
  · exact hp4_4_node357 T childKnown
  · exact hp4_4_node359 T childKnown
  · exact hp4_4_node360 T childKnown
  · exact hp4_4_node364 T childKnown
theorem hp4_4_node354 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected354 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected354 ((2 : Int),(2 : Int)) hp4_4_branches354 hp4_4_evidence354 hp4_4_check354 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches354,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node353 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected353 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected353 ((5 : Int),(2 : Int)) hp4_4_branches353 hp4_4_evidence353 hp4_4_check353 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches353,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node352 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected352 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected352 ((2 : Int),(2 : Int)) hp4_4_branches352 hp4_4_evidence352 hp4_4_check352 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches352,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node351 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected351 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected351 ((2 : Int),(2 : Int)) hp4_4_branches351 hp4_4_evidence351 hp4_4_check351 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches351,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node350 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected350 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected350 ((9 : Int),(2 : Int)) hp4_4_branches350 hp4_4_evidence350 hp4_4_check350 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches350,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node349 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected349 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected349 ((9 : Int),(2 : Int)) hp4_4_branches349 hp4_4_evidence349 hp4_4_check349 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches349,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node348 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected348 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected348 ((9 : Int),(1 : Int)) hp4_4_branches348 hp4_4_evidence348 hp4_4_check348 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches348,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node349 T childKnown
  · exact hp4_4_node350 T childKnown
theorem hp4_4_node347 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected347 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected347 ((7 : Int),(1 : Int)) hp4_4_branches347 hp4_4_evidence347 hp4_4_check347 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches347,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node348 T childKnown
theorem hp4_4_node346 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected346 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected346 ((6 : Int),(1 : Int)) hp4_4_branches346 hp4_4_evidence346 hp4_4_check346 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches346,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node347 T childKnown
  · exact hp4_4_node351 T childKnown
  · exact hp4_4_node352 T childKnown
  · exact hp4_4_node353 T childKnown
  · exact hp4_4_node354 T childKnown
theorem hp4_4_node345 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected345 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected345 ((0 : Int),(2 : Int)) hp4_4_branches345 hp4_4_evidence345 hp4_4_check345 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches345,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node346 T childKnown
  · exact hp4_4_node355 T childKnown
  · exact hp4_4_node365 T childKnown
  · exact hp4_4_node371 T childKnown
theorem hp4_4_node344 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected344 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected344 ((4 : Int),(0 : Int)) hp4_4_branches344 hp4_4_evidence344 hp4_4_check344 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches344,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node345 T childKnown
theorem hp4_4_node343 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected343 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected343 ((1 : Int),(2 : Int)) hp4_4_branches343 hp4_4_evidence343 hp4_4_check343 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches343,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node342 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected342 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected342 ((1 : Int),(2 : Int)) hp4_4_branches342 hp4_4_evidence342 hp4_4_check342 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches342,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node341 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected341 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected341 ((1 : Int),(1 : Int)) hp4_4_branches341 hp4_4_evidence341 hp4_4_check341 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches341,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node342 T childKnown
  · exact hp4_4_node343 T childKnown
theorem hp4_4_node340 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected340 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected340 ((9 : Int),(2 : Int)) hp4_4_branches340 hp4_4_evidence340 hp4_4_check340 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches340,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node339 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected339 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected339 ((9 : Int),(2 : Int)) hp4_4_branches339 hp4_4_evidence339 hp4_4_check339 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches339,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node338 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected338 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected338 ((9 : Int),(1 : Int)) hp4_4_branches338 hp4_4_evidence338 hp4_4_check338 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches338,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node339 T childKnown
  · exact hp4_4_node340 T childKnown
theorem hp4_4_node337 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected337 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected337 ((6 : Int),(2 : Int)) hp4_4_branches337 hp4_4_evidence337 hp4_4_check337 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches337,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node338 T childKnown
theorem hp4_4_node336 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected336 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected336 ((6 : Int),(2 : Int)) hp4_4_branches336 hp4_4_evidence336 hp4_4_check336 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches336,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node335 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected335 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected335 ((7 : Int),(1 : Int)) hp4_4_branches335 hp4_4_evidence335 hp4_4_check335 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches335,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node336 T childKnown
  · exact hp4_4_node337 T childKnown
theorem hp4_4_node334 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected334 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected334 ((4 : Int),(0 : Int)) hp4_4_branches334 hp4_4_evidence334 hp4_4_check334 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches334,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node335 T childKnown
theorem hp4_4_node333 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected333 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected333 ((4 : Int),(0 : Int)) hp4_4_branches333 hp4_4_evidence333 hp4_4_check333 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches333,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node332 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected332 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected332 ((1 : Int),(1 : Int)) hp4_4_branches332 hp4_4_evidence332 hp4_4_check332 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches332,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node333 T childKnown
  · exact hp4_4_node334 T childKnown
theorem hp4_4_node331 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected331 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected331 ((1 : Int),(2 : Int)) hp4_4_branches331 hp4_4_evidence331 hp4_4_check331 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches331,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node330 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected330 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected330 ((1 : Int),(2 : Int)) hp4_4_branches330 hp4_4_evidence330 hp4_4_check330 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches330,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node329 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected329 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected329 ((1 : Int),(1 : Int)) hp4_4_branches329 hp4_4_evidence329 hp4_4_check329 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches329,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node330 T childKnown
  · exact hp4_4_node331 T childKnown
theorem hp4_4_node328 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected328 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected328 ((1 : Int),(2 : Int)) hp4_4_branches328 hp4_4_evidence328 hp4_4_check328 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches328,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node327 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected327 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected327 ((1 : Int),(2 : Int)) hp4_4_branches327 hp4_4_evidence327 hp4_4_check327 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches327,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node326 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected326 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected326 ((1 : Int),(2 : Int)) hp4_4_branches326 hp4_4_evidence326 hp4_4_check326 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches326,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node325 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected325 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected325 ((1 : Int),(1 : Int)) hp4_4_branches325 hp4_4_evidence325 hp4_4_check325 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches325,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_4_node326 T childKnown
  · exact hp4_4_node327 T childKnown
  · exact hp4_4_node328 T childKnown
theorem hp4_4_node324 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected324 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected324 ((2 : Int),(2 : Int)) hp4_4_branches324 hp4_4_evidence324 hp4_4_check324 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches324,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node323 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected323 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected323 ((1 : Int),(2 : Int)) hp4_4_branches323 hp4_4_evidence323 hp4_4_check323 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches323,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node324 T childKnown
theorem hp4_4_node322 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected322 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected322 ((4 : Int),(0 : Int)) hp4_4_branches322 hp4_4_evidence322 hp4_4_check322 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches322,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node321 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected321 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected321 ((9 : Int),(1 : Int)) hp4_4_branches321 hp4_4_evidence321 hp4_4_check321 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches321,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node320 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected320 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected320 ((9 : Int),(1 : Int)) hp4_4_branches320 hp4_4_evidence320 hp4_4_check320 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches320,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node319 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected319 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected319 ((10 : Int),(1 : Int)) hp4_4_branches319 hp4_4_evidence319 hp4_4_check319 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches319,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node320 T childKnown
  · exact hp4_4_node321 T childKnown
theorem hp4_4_node318 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected318 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected318 ((10 : Int),(1 : Int)) hp4_4_branches318 hp4_4_evidence318 hp4_4_check318 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches318,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node317 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected317 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected317 ((10 : Int),(1 : Int)) hp4_4_branches317 hp4_4_evidence317 hp4_4_check317 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches317,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node316 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected316 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected316 ((9 : Int),(1 : Int)) hp4_4_branches316 hp4_4_evidence316 hp4_4_check316 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches316,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node317 T childKnown
  · exact hp4_4_node318 T childKnown
theorem hp4_4_node315 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected315 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected315 ((9 : Int),(1 : Int)) hp4_4_branches315 hp4_4_evidence315 hp4_4_check315 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches315,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node314 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected314 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected314 ((9 : Int),(1 : Int)) hp4_4_branches314 hp4_4_evidence314 hp4_4_check314 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches314,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node313 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected313 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected313 ((9 : Int),(1 : Int)) hp4_4_branches313 hp4_4_evidence313 hp4_4_check313 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches313,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node312 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected312 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected312 ((10 : Int),(0 : Int)) hp4_4_branches312 hp4_4_evidence312 hp4_4_check312 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches312,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node313 T childKnown
  · exact hp4_4_node314 T childKnown
  · exact hp4_4_node315 T childKnown
  · exact hp4_4_node316 T childKnown
  · exact hp4_4_node319 T childKnown
theorem hp4_4_node311 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected311 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected311 ((3 : Int),(2 : Int)) hp4_4_branches311 hp4_4_evidence311 hp4_4_check311 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches311,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node312 T childKnown
theorem hp4_4_node310 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected310 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected310 ((4 : Int),(0 : Int)) hp4_4_branches310 hp4_4_evidence310 hp4_4_check310 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches310,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node311 T childKnown
theorem hp4_4_node309 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected309 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected309 ((1 : Int),(2 : Int)) hp4_4_branches309 hp4_4_evidence309 hp4_4_check309 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches309,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node310 T childKnown
theorem hp4_4_node308 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected308 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected308 ((2 : Int),(2 : Int)) hp4_4_branches308 hp4_4_evidence308 hp4_4_check308 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches308,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node307 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected307 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected307 ((2 : Int),(2 : Int)) hp4_4_branches307 hp4_4_evidence307 hp4_4_check307 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches307,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node306 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected306 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected306 ((2 : Int),(1 : Int)) hp4_4_branches306 hp4_4_evidence306 hp4_4_check306 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches306,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node307 T childKnown
  · exact hp4_4_node308 T childKnown
theorem hp4_4_node305 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected305 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected305 ((9 : Int),(1 : Int)) hp4_4_branches305 hp4_4_evidence305 hp4_4_check305 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches305,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node304 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected304 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected304 ((9 : Int),(1 : Int)) hp4_4_branches304 hp4_4_evidence304 hp4_4_check304 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches304,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node303 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected303 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected303 ((10 : Int),(1 : Int)) hp4_4_branches303 hp4_4_evidence303 hp4_4_check303 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches303,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node302 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected302 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected302 ((10 : Int),(1 : Int)) hp4_4_branches302 hp4_4_evidence302 hp4_4_check302 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches302,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node301 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected301 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected301 ((10 : Int),(0 : Int)) hp4_4_branches301 hp4_4_evidence301 hp4_4_check301 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches301,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node302 T childKnown
  · exact hp4_4_node303 T childKnown
theorem hp4_4_node300 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected300 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected300 ((9 : Int),(2 : Int)) hp4_4_branches300 hp4_4_evidence300 hp4_4_check300 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches300,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_4_node301 T childKnown
  · exact hp4_4_node304 T childKnown
  · exact hp4_4_node305 T childKnown
theorem hp4_4_node299 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected299 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected299 ((9 : Int),(1 : Int)) hp4_4_branches299 hp4_4_evidence299 hp4_4_check299 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches299,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node298 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected298 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected298 ((9 : Int),(1 : Int)) hp4_4_branches298 hp4_4_evidence298 hp4_4_check298 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches298,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node297 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected297 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected297 ((10 : Int),(1 : Int)) hp4_4_branches297 hp4_4_evidence297 hp4_4_check297 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches297,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node296 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected296 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected296 ((10 : Int),(1 : Int)) hp4_4_branches296 hp4_4_evidence296 hp4_4_check296 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches296,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node295 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected295 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected295 ((10 : Int),(0 : Int)) hp4_4_branches295 hp4_4_evidence295 hp4_4_check295 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches295,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node296 T childKnown
  · exact hp4_4_node297 T childKnown
theorem hp4_4_node294 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected294 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected294 ((9 : Int),(2 : Int)) hp4_4_branches294 hp4_4_evidence294 hp4_4_check294 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches294,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp4_4_node295 T childKnown
  · exact hp4_4_node298 T childKnown
  · exact hp4_4_node299 T childKnown
theorem hp4_4_node293 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected293 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected293 ((9 : Int),(1 : Int)) hp4_4_branches293 hp4_4_evidence293 hp4_4_check293 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches293,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node292 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected292 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected292 ((9 : Int),(1 : Int)) hp4_4_branches292 hp4_4_evidence292 hp4_4_check292 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches292,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node291 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected291 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected291 ((10 : Int),(1 : Int)) hp4_4_branches291 hp4_4_evidence291 hp4_4_check291 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches291,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node292 T childKnown
  · exact hp4_4_node293 T childKnown
theorem hp4_4_node290 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected290 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected290 ((10 : Int),(1 : Int)) hp4_4_branches290 hp4_4_evidence290 hp4_4_check290 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches290,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node289 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected289 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected289 ((10 : Int),(1 : Int)) hp4_4_branches289 hp4_4_evidence289 hp4_4_check289 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches289,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node288 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected288 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected288 ((9 : Int),(1 : Int)) hp4_4_branches288 hp4_4_evidence288 hp4_4_check288 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches288,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node289 T childKnown
  · exact hp4_4_node290 T childKnown
theorem hp4_4_node287 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected287 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected287 ((9 : Int),(1 : Int)) hp4_4_branches287 hp4_4_evidence287 hp4_4_check287 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches287,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node286 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected286 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected286 ((9 : Int),(1 : Int)) hp4_4_branches286 hp4_4_evidence286 hp4_4_check286 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches286,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node285 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected285 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected285 ((9 : Int),(1 : Int)) hp4_4_branches285 hp4_4_evidence285 hp4_4_check285 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches285,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node284 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected284 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected284 ((10 : Int),(0 : Int)) hp4_4_branches284 hp4_4_evidence284 hp4_4_check284 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches284,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node285 T childKnown
  · exact hp4_4_node286 T childKnown
  · exact hp4_4_node287 T childKnown
  · exact hp4_4_node288 T childKnown
  · exact hp4_4_node291 T childKnown
theorem hp4_4_node283 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected283 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected283 ((9 : Int),(1 : Int)) hp4_4_branches283 hp4_4_evidence283 hp4_4_check283 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches283,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node282 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected282 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected282 ((9 : Int),(1 : Int)) hp4_4_branches282 hp4_4_evidence282 hp4_4_check282 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches282,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node281 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected281 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected281 ((10 : Int),(1 : Int)) hp4_4_branches281 hp4_4_evidence281 hp4_4_check281 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches281,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node282 T childKnown
  · exact hp4_4_node283 T childKnown
theorem hp4_4_node280 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected280 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected280 ((10 : Int),(1 : Int)) hp4_4_branches280 hp4_4_evidence280 hp4_4_check280 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches280,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node279 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected279 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected279 ((10 : Int),(1 : Int)) hp4_4_branches279 hp4_4_evidence279 hp4_4_check279 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches279,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node278 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected278 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected278 ((9 : Int),(1 : Int)) hp4_4_branches278 hp4_4_evidence278 hp4_4_check278 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches278,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node279 T childKnown
  · exact hp4_4_node280 T childKnown
theorem hp4_4_node277 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected277 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected277 ((9 : Int),(1 : Int)) hp4_4_branches277 hp4_4_evidence277 hp4_4_check277 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches277,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node276 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected276 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected276 ((9 : Int),(1 : Int)) hp4_4_branches276 hp4_4_evidence276 hp4_4_check276 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches276,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node275 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected275 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected275 ((9 : Int),(1 : Int)) hp4_4_branches275 hp4_4_evidence275 hp4_4_check275 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches275,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node274 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected274 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected274 ((10 : Int),(0 : Int)) hp4_4_branches274 hp4_4_evidence274 hp4_4_check274 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches274,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node275 T childKnown
  · exact hp4_4_node276 T childKnown
  · exact hp4_4_node277 T childKnown
  · exact hp4_4_node278 T childKnown
  · exact hp4_4_node281 T childKnown
theorem hp4_4_node273 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected273 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected273 ((7 : Int),(2 : Int)) hp4_4_branches273 hp4_4_evidence273 hp4_4_check273 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches273,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node274 T childKnown
  · exact hp4_4_node284 T childKnown
  · exact hp4_4_node294 T childKnown
  · exact hp4_4_node300 T childKnown
theorem hp4_4_node272 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected272 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected272 ((2 : Int),(1 : Int)) hp4_4_branches272 hp4_4_evidence272 hp4_4_check272 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches272,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node273 T childKnown
theorem hp4_4_node271 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected271 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected271 ((4 : Int),(0 : Int)) hp4_4_branches271 hp4_4_evidence271 hp4_4_check271 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches271,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node272 T childKnown
theorem hp4_4_node270 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected270 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected270 ((1 : Int),(1 : Int)) hp4_4_branches270 hp4_4_evidence270 hp4_4_check270 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches270,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node271 T childKnown
  · exact hp4_4_node306 T childKnown
  · exact hp4_4_node309 T childKnown
  · exact hp4_4_node322 T childKnown
  · exact hp4_4_node323 T childKnown
theorem hp4_4_node269 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected269 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected269 ((0 : Int),(1 : Int)) hp4_4_branches269 hp4_4_evidence269 hp4_4_check269 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches269,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node270 T childKnown
  · exact hp4_4_node325 T childKnown
  · exact hp4_4_node329 T childKnown
  · exact hp4_4_node332 T childKnown
  · exact hp4_4_node341 T childKnown
  · exact hp4_4_node344 T childKnown
  · exact hp4_4_node377 T childKnown
  · exact hp4_4_node383 T childKnown
theorem hp4_4_node268 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected268 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected268 ((4 : Int),(1 : Int)) hp4_4_branches268 hp4_4_evidence268 hp4_4_check268 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches268,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node267 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected267 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected267 ((2 : Int),(1 : Int)) hp4_4_branches267 hp4_4_evidence267 hp4_4_check267 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches267,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node266 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected266 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected266 ((2 : Int),(1 : Int)) hp4_4_branches266 hp4_4_evidence266 hp4_4_check266 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches266,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node265 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected265 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected265 ((2 : Int),(1 : Int)) hp4_4_branches265 hp4_4_evidence265 hp4_4_check265 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches265,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node264 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected264 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected264 ((3 : Int),(1 : Int)) hp4_4_branches264 hp4_4_evidence264 hp4_4_check264 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches264,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node265 T childKnown
  · exact hp4_4_node266 T childKnown
  · exact hp4_4_node267 T childKnown
  · exact hp4_4_node268 T childKnown
theorem hp4_4_node263 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected263 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected263 ((3 : Int),(1 : Int)) hp4_4_branches263 hp4_4_evidence263 hp4_4_check263 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches263,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node262 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected262 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected262 ((3 : Int),(1 : Int)) hp4_4_branches262 hp4_4_evidence262 hp4_4_check262 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches262,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node261 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected261 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected261 ((3 : Int),(1 : Int)) hp4_4_branches261 hp4_4_evidence261 hp4_4_check261 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches261,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node260 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected260 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected260 ((0 : Int),(2 : Int)) hp4_4_branches260 hp4_4_evidence260 hp4_4_check260 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches260,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node259 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected259 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected259 ((0 : Int),(2 : Int)) hp4_4_branches259 hp4_4_evidence259 hp4_4_check259 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches259,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node258 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected258 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected258 ((0 : Int),(1 : Int)) hp4_4_branches258 hp4_4_evidence258 hp4_4_check258 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches258,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node259 T childKnown
  · exact hp4_4_node260 T childKnown
theorem hp4_4_node257 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected257 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected257 ((3 : Int),(1 : Int)) hp4_4_branches257 hp4_4_evidence257 hp4_4_check257 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches257,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node258 T childKnown
theorem hp4_4_node256 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected256 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected256 ((2 : Int),(1 : Int)) hp4_4_branches256 hp4_4_evidence256 hp4_4_check256 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches256,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node257 T childKnown
  · exact hp4_4_node261 T childKnown
  · exact hp4_4_node262 T childKnown
  · exact hp4_4_node263 T childKnown
theorem hp4_4_node255 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected255 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected255 ((4 : Int),(1 : Int)) hp4_4_branches255 hp4_4_evidence255 hp4_4_check255 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches255,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node254 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected254 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected254 ((4 : Int),(0 : Int)) hp4_4_branches254 hp4_4_evidence254 hp4_4_check254 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches254,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node255 T childKnown
theorem hp4_4_node253 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected253 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected253 ((2 : Int),(1 : Int)) hp4_4_branches253 hp4_4_evidence253 hp4_4_check253 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches253,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node254 T childKnown
theorem hp4_4_node252 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected252 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected252 ((0 : Int),(2 : Int)) hp4_4_branches252 hp4_4_evidence252 hp4_4_check252 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches252,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node251 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected251 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected251 ((0 : Int),(2 : Int)) hp4_4_branches251 hp4_4_evidence251 hp4_4_check251 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches251,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node250 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected250 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected250 ((0 : Int),(1 : Int)) hp4_4_branches250 hp4_4_evidence250 hp4_4_check250 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches250,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node251 T childKnown
  · exact hp4_4_node252 T childKnown
theorem hp4_4_node249 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected249 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected249 ((4 : Int),(0 : Int)) hp4_4_branches249 hp4_4_evidence249 hp4_4_check249 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches249,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node250 T childKnown
theorem hp4_4_node248 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected248 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected248 ((2 : Int),(1 : Int)) hp4_4_branches248 hp4_4_evidence248 hp4_4_check248 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches248,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node249 T childKnown
theorem hp4_4_node247 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected247 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected247 ((2 : Int),(1 : Int)) hp4_4_branches247 hp4_4_evidence247 hp4_4_check247 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches247,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node246 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected246 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected246 ((3 : Int),(0 : Int)) hp4_4_branches246 hp4_4_evidence246 hp4_4_check246 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches246,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node247 T childKnown
  · exact hp4_4_node248 T childKnown
  · exact hp4_4_node253 T childKnown
  · exact hp4_4_node256 T childKnown
  · exact hp4_4_node264 T childKnown
theorem hp4_4_node245 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected245 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected245 ((10 : Int),(1 : Int)) hp4_4_branches245 hp4_4_evidence245 hp4_4_check245 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches245,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node244 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected244 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected244 ((8 : Int),(1 : Int)) hp4_4_branches244 hp4_4_evidence244 hp4_4_check244 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches244,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node243 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected243 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected243 ((8 : Int),(1 : Int)) hp4_4_branches243 hp4_4_evidence243 hp4_4_check243 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches243,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node242 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected242 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected242 ((8 : Int),(1 : Int)) hp4_4_branches242 hp4_4_evidence242 hp4_4_check242 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches242,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node241 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected241 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected241 ((9 : Int),(1 : Int)) hp4_4_branches241 hp4_4_evidence241 hp4_4_check241 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches241,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node242 T childKnown
  · exact hp4_4_node243 T childKnown
  · exact hp4_4_node244 T childKnown
  · exact hp4_4_node245 T childKnown
theorem hp4_4_node240 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected240 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected240 ((9 : Int),(1 : Int)) hp4_4_branches240 hp4_4_evidence240 hp4_4_check240 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches240,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node239 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected239 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected239 ((9 : Int),(1 : Int)) hp4_4_branches239 hp4_4_evidence239 hp4_4_check239 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches239,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node238 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected238 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected238 ((9 : Int),(1 : Int)) hp4_4_branches238 hp4_4_evidence238 hp4_4_check238 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches238,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node237 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected237 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected237 ((4 : Int),(2 : Int)) hp4_4_branches237 hp4_4_evidence237 hp4_4_check237 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches237,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node236 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected236 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected236 ((6 : Int),(1 : Int)) hp4_4_branches236 hp4_4_evidence236 hp4_4_check236 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches236,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node237 T childKnown
theorem hp4_4_node235 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected235 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected235 ((8 : Int),(1 : Int)) hp4_4_branches235 hp4_4_evidence235 hp4_4_check235 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches235,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node236 T childKnown
  · exact hp4_4_node238 T childKnown
  · exact hp4_4_node239 T childKnown
  · exact hp4_4_node240 T childKnown
theorem hp4_4_node234 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected234 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected234 ((4 : Int),(2 : Int)) hp4_4_branches234 hp4_4_evidence234 hp4_4_check234 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches234,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node233 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected233 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected233 ((6 : Int),(1 : Int)) hp4_4_branches233 hp4_4_evidence233 hp4_4_check233 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches233,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node234 T childKnown
theorem hp4_4_node232 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected232 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected232 ((8 : Int),(1 : Int)) hp4_4_branches232 hp4_4_evidence232 hp4_4_check232 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches232,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node233 T childKnown
theorem hp4_4_node231 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected231 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected231 ((4 : Int),(2 : Int)) hp4_4_branches231 hp4_4_evidence231 hp4_4_check231 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches231,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node230 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected230 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected230 ((6 : Int),(1 : Int)) hp4_4_branches230 hp4_4_evidence230 hp4_4_check230 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches230,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node231 T childKnown
theorem hp4_4_node229 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected229 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected229 ((8 : Int),(1 : Int)) hp4_4_branches229 hp4_4_evidence229 hp4_4_check229 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches229,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node230 T childKnown
theorem hp4_4_node228 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected228 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected228 ((8 : Int),(1 : Int)) hp4_4_branches228 hp4_4_evidence228 hp4_4_check228 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches228,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node227 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected227 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected227 ((9 : Int),(0 : Int)) hp4_4_branches227 hp4_4_evidence227 hp4_4_check227 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches227,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node228 T childKnown
  · exact hp4_4_node229 T childKnown
  · exact hp4_4_node232 T childKnown
  · exact hp4_4_node235 T childKnown
  · exact hp4_4_node241 T childKnown
theorem hp4_4_node226 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected226 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected226 ((1 : Int),(1 : Int)) hp4_4_branches226 hp4_4_evidence226 hp4_4_check226 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches226,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node225 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected225 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected225 ((1 : Int),(1 : Int)) hp4_4_branches225 hp4_4_evidence225 hp4_4_check225 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches225,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node224 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected224 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected224 ((1 : Int),(1 : Int)) hp4_4_branches224 hp4_4_evidence224 hp4_4_check224 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches224,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node223 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected223 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected223 ((2 : Int),(1 : Int)) hp4_4_branches223 hp4_4_evidence223 hp4_4_check223 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches223,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node222 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected222 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected222 ((1 : Int),(1 : Int)) hp4_4_branches222 hp4_4_evidence222 hp4_4_check222 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches222,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node223 T childKnown
theorem hp4_4_node221 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected221 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected221 ((0 : Int),(1 : Int)) hp4_4_branches221 hp4_4_evidence221 hp4_4_check221 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches221,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node222 T childKnown
  · exact hp4_4_node224 T childKnown
  · exact hp4_4_node225 T childKnown
  · exact hp4_4_node226 T childKnown
theorem hp4_4_node220 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected220 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected220 ((0 : Int),(1 : Int)) hp4_4_branches220 hp4_4_evidence220 hp4_4_check220 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches220,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node219 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected219 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected219 ((2 : Int),(1 : Int)) hp4_4_branches219 hp4_4_evidence219 hp4_4_check219 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches219,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node220 T childKnown
theorem hp4_4_node218 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected218 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected218 ((0 : Int),(1 : Int)) hp4_4_branches218 hp4_4_evidence218 hp4_4_check218 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches218,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node217 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected217 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected217 ((2 : Int),(1 : Int)) hp4_4_branches217 hp4_4_evidence217 hp4_4_check217 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches217,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node218 T childKnown
theorem hp4_4_node216 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected216 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected216 ((2 : Int),(1 : Int)) hp4_4_branches216 hp4_4_evidence216 hp4_4_check216 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches216,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node215 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected215 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected215 ((0 : Int),(1 : Int)) hp4_4_branches215 hp4_4_evidence215 hp4_4_check215 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches215,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node214 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected214 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected214 ((0 : Int),(1 : Int)) hp4_4_branches214 hp4_4_evidence214 hp4_4_check214 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches214,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node213 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected213 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected213 ((1 : Int),(2 : Int)) hp4_4_branches213 hp4_4_evidence213 hp4_4_check213 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches213,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node212 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected212 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected212 ((1 : Int),(2 : Int)) hp4_4_branches212 hp4_4_evidence212 hp4_4_check212 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches212,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node211 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected211 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected211 ((1 : Int),(2 : Int)) hp4_4_branches211 hp4_4_evidence211 hp4_4_check211 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches211,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node210 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected210 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected210 ((2 : Int),(2 : Int)) hp4_4_branches210 hp4_4_evidence210 hp4_4_check210 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches210,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node209 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected209 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected209 ((1 : Int),(2 : Int)) hp4_4_branches209 hp4_4_evidence209 hp4_4_check209 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches209,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node210 T childKnown
theorem hp4_4_node208 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected208 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected208 ((0 : Int),(2 : Int)) hp4_4_branches208 hp4_4_evidence208 hp4_4_check208 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches208,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node209 T childKnown
  · exact hp4_4_node211 T childKnown
  · exact hp4_4_node212 T childKnown
  · exact hp4_4_node213 T childKnown
theorem hp4_4_node207 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected207 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected207 ((3 : Int),(0 : Int)) hp4_4_branches207 hp4_4_evidence207 hp4_4_check207 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches207,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node208 T childKnown
  · exact hp4_4_node214 T childKnown
  · exact hp4_4_node215 T childKnown
  · exact hp4_4_node216 T childKnown
  · exact hp4_4_node217 T childKnown
  · exact hp4_4_node219 T childKnown
  · exact hp4_4_node221 T childKnown
  · exact hp4_4_node227 T childKnown
theorem hp4_4_node206 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected206 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected206 ((1 : Int),(1 : Int)) hp4_4_branches206 hp4_4_evidence206 hp4_4_check206 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches206,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node205 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected205 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected205 ((1 : Int),(1 : Int)) hp4_4_branches205 hp4_4_evidence205 hp4_4_check205 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches205,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node204 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected204 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected204 ((1 : Int),(0 : Int)) hp4_4_branches204 hp4_4_evidence204 hp4_4_check204 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches204,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node205 T childKnown
  · exact hp4_4_node206 T childKnown
theorem hp4_4_node203 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected203 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected203 ((2 : Int),(1 : Int)) hp4_4_branches203 hp4_4_evidence203 hp4_4_check203 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches203,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node202 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected202 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected202 ((1 : Int),(1 : Int)) hp4_4_branches202 hp4_4_evidence202 hp4_4_check202 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches202,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node203 T childKnown
theorem hp4_4_node201 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected201 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected201 ((3 : Int),(2 : Int)) hp4_4_branches201 hp4_4_evidence201 hp4_4_check201 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches201,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node200 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected200 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected200 ((3 : Int),(2 : Int)) hp4_4_branches200 hp4_4_evidence200 hp4_4_check200 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches200,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node199 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected199 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected199 ((3 : Int),(1 : Int)) hp4_4_branches199 hp4_4_evidence199 hp4_4_check199 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches199,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node200 T childKnown
  · exact hp4_4_node201 T childKnown
theorem hp4_4_node198 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected198 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected198 ((1 : Int),(1 : Int)) hp4_4_branches198 hp4_4_evidence198 hp4_4_check198 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches198,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node199 T childKnown
theorem hp4_4_node197 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected197 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected197 ((2 : Int),(1 : Int)) hp4_4_branches197 hp4_4_evidence197 hp4_4_check197 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches197,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node196 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected196 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected196 ((2 : Int),(0 : Int)) hp4_4_branches196 hp4_4_evidence196 hp4_4_check196 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches196,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node197 T childKnown
theorem hp4_4_node195 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected195 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected195 ((3 : Int),(2 : Int)) hp4_4_branches195 hp4_4_evidence195 hp4_4_check195 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches195,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node194 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected194 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected194 ((3 : Int),(2 : Int)) hp4_4_branches194 hp4_4_evidence194 hp4_4_check194 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches194,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node193 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected193 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected193 ((3 : Int),(2 : Int)) hp4_4_branches193 hp4_4_evidence193 hp4_4_check193 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches193,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node192 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected192 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected192 ((4 : Int),(2 : Int)) hp4_4_branches192 hp4_4_evidence192 hp4_4_check192 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches192,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node191 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected191 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected191 ((3 : Int),(2 : Int)) hp4_4_branches191 hp4_4_evidence191 hp4_4_check191 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches191,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node192 T childKnown
theorem hp4_4_node190 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected190 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected190 ((2 : Int),(2 : Int)) hp4_4_branches190 hp4_4_evidence190 hp4_4_check190 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches190,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node191 T childKnown
  · exact hp4_4_node193 T childKnown
  · exact hp4_4_node194 T childKnown
  · exact hp4_4_node195 T childKnown
theorem hp4_4_node189 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected189 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected189 ((2 : Int),(0 : Int)) hp4_4_branches189 hp4_4_evidence189 hp4_4_check189 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches189,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node190 T childKnown
theorem hp4_4_node188 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected188 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected188 ((1 : Int),(0 : Int)) hp4_4_branches188 hp4_4_evidence188 hp4_4_check188 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches188,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node189 T childKnown
  · exact hp4_4_node196 T childKnown
  · exact hp4_4_node198 T childKnown
  · exact hp4_4_node202 T childKnown
theorem hp4_4_node187 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected187 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected187 ((2 : Int),(1 : Int)) hp4_4_branches187 hp4_4_evidence187 hp4_4_check187 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches187,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node186 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected186 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected186 ((1 : Int),(1 : Int)) hp4_4_branches186 hp4_4_evidence186 hp4_4_check186 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches186,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node187 T childKnown
theorem hp4_4_node185 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected185 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected185 ((3 : Int),(2 : Int)) hp4_4_branches185 hp4_4_evidence185 hp4_4_check185 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches185,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node184 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected184 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected184 ((3 : Int),(2 : Int)) hp4_4_branches184 hp4_4_evidence184 hp4_4_check184 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches184,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node183 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected183 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected183 ((3 : Int),(1 : Int)) hp4_4_branches183 hp4_4_evidence183 hp4_4_check183 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches183,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node184 T childKnown
  · exact hp4_4_node185 T childKnown
theorem hp4_4_node182 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected182 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected182 ((1 : Int),(1 : Int)) hp4_4_branches182 hp4_4_evidence182 hp4_4_check182 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches182,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node183 T childKnown
theorem hp4_4_node181 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected181 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected181 ((2 : Int),(1 : Int)) hp4_4_branches181 hp4_4_evidence181 hp4_4_check181 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches181,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node180 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected180 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected180 ((2 : Int),(0 : Int)) hp4_4_branches180 hp4_4_evidence180 hp4_4_check180 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches180,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node181 T childKnown
theorem hp4_4_node179 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected179 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected179 ((3 : Int),(2 : Int)) hp4_4_branches179 hp4_4_evidence179 hp4_4_check179 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches179,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node178 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected178 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected178 ((3 : Int),(2 : Int)) hp4_4_branches178 hp4_4_evidence178 hp4_4_check178 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches178,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node177 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected177 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected177 ((3 : Int),(2 : Int)) hp4_4_branches177 hp4_4_evidence177 hp4_4_check177 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches177,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node176 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected176 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected176 ((4 : Int),(2 : Int)) hp4_4_branches176 hp4_4_evidence176 hp4_4_check176 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches176,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node175 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected175 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected175 ((3 : Int),(2 : Int)) hp4_4_branches175 hp4_4_evidence175 hp4_4_check175 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches175,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node176 T childKnown
theorem hp4_4_node174 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected174 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected174 ((2 : Int),(2 : Int)) hp4_4_branches174 hp4_4_evidence174 hp4_4_check174 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches174,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node175 T childKnown
  · exact hp4_4_node177 T childKnown
  · exact hp4_4_node178 T childKnown
  · exact hp4_4_node179 T childKnown
theorem hp4_4_node173 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected173 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected173 ((2 : Int),(0 : Int)) hp4_4_branches173 hp4_4_evidence173 hp4_4_check173 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches173,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node174 T childKnown
theorem hp4_4_node172 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected172 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected172 ((1 : Int),(0 : Int)) hp4_4_branches172 hp4_4_evidence172 hp4_4_check172 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches172,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node173 T childKnown
  · exact hp4_4_node180 T childKnown
  · exact hp4_4_node182 T childKnown
  · exact hp4_4_node186 T childKnown
theorem hp4_4_node171 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected171 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected171 ((3 : Int),(1 : Int)) hp4_4_branches171 hp4_4_evidence171 hp4_4_check171 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches171,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node170 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected170 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected170 ((1 : Int),(1 : Int)) hp4_4_branches170 hp4_4_evidence170 hp4_4_check170 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches170,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node169 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected169 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected169 ((1 : Int),(1 : Int)) hp4_4_branches169 hp4_4_evidence169 hp4_4_check169 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches169,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node168 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected168 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected168 ((1 : Int),(1 : Int)) hp4_4_branches168 hp4_4_evidence168 hp4_4_check168 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches168,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node167 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected167 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected167 ((2 : Int),(1 : Int)) hp4_4_branches167 hp4_4_evidence167 hp4_4_check167 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches167,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node168 T childKnown
  · exact hp4_4_node169 T childKnown
  · exact hp4_4_node170 T childKnown
  · exact hp4_4_node171 T childKnown
theorem hp4_4_node166 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected166 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected166 ((2 : Int),(1 : Int)) hp4_4_branches166 hp4_4_evidence166 hp4_4_check166 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches166,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node165 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected165 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected165 ((2 : Int),(1 : Int)) hp4_4_branches165 hp4_4_evidence165 hp4_4_check165 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches165,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node164 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected164 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected164 ((2 : Int),(1 : Int)) hp4_4_branches164 hp4_4_evidence164 hp4_4_check164 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches164,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node163 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected163 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected163 ((4 : Int),(2 : Int)) hp4_4_branches163 hp4_4_evidence163 hp4_4_check163 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches163,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node162 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected162 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected162 ((4 : Int),(2 : Int)) hp4_4_branches162 hp4_4_evidence162 hp4_4_check162 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches162,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node161 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected161 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected161 ((4 : Int),(1 : Int)) hp4_4_branches161 hp4_4_evidence161 hp4_4_check161 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches161,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node162 T childKnown
  · exact hp4_4_node163 T childKnown
theorem hp4_4_node160 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected160 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected160 ((2 : Int),(1 : Int)) hp4_4_branches160 hp4_4_evidence160 hp4_4_check160 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches160,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node161 T childKnown
theorem hp4_4_node159 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected159 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected159 ((1 : Int),(1 : Int)) hp4_4_branches159 hp4_4_evidence159 hp4_4_check159 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches159,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node160 T childKnown
  · exact hp4_4_node164 T childKnown
  · exact hp4_4_node165 T childKnown
  · exact hp4_4_node166 T childKnown
theorem hp4_4_node158 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected158 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected158 ((3 : Int),(1 : Int)) hp4_4_branches158 hp4_4_evidence158 hp4_4_check158 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches158,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node157 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected157 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected157 ((3 : Int),(0 : Int)) hp4_4_branches157 hp4_4_evidence157 hp4_4_check157 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches157,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node158 T childKnown
theorem hp4_4_node156 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected156 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected156 ((1 : Int),(1 : Int)) hp4_4_branches156 hp4_4_evidence156 hp4_4_check156 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches156,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node157 T childKnown
theorem hp4_4_node155 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected155 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected155 ((4 : Int),(2 : Int)) hp4_4_branches155 hp4_4_evidence155 hp4_4_check155 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches155,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node154 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected154 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected154 ((4 : Int),(2 : Int)) hp4_4_branches154 hp4_4_evidence154 hp4_4_check154 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches154,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node153 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected153 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected153 ((3 : Int),(2 : Int)) hp4_4_branches153 hp4_4_evidence153 hp4_4_check153 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches153,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node154 T childKnown
  · exact hp4_4_node155 T childKnown
theorem hp4_4_node152 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected152 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected152 ((3 : Int),(0 : Int)) hp4_4_branches152 hp4_4_evidence152 hp4_4_check152 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches152,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node153 T childKnown
theorem hp4_4_node151 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected151 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected151 ((1 : Int),(1 : Int)) hp4_4_branches151 hp4_4_evidence151 hp4_4_check151 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches151,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node152 T childKnown
theorem hp4_4_node150 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected150 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected150 ((1 : Int),(1 : Int)) hp4_4_branches150 hp4_4_evidence150 hp4_4_check150 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches150,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node149 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected149 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected149 ((2 : Int),(0 : Int)) hp4_4_branches149 hp4_4_evidence149 hp4_4_check149 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches149,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node150 T childKnown
  · exact hp4_4_node151 T childKnown
  · exact hp4_4_node156 T childKnown
  · exact hp4_4_node159 T childKnown
  · exact hp4_4_node167 T childKnown
theorem hp4_4_node148 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected148 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected148 ((9 : Int),(1 : Int)) hp4_4_branches148 hp4_4_evidence148 hp4_4_check148 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches148,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node147 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected147 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected147 ((7 : Int),(1 : Int)) hp4_4_branches147 hp4_4_evidence147 hp4_4_check147 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches147,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node146 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected146 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected146 ((7 : Int),(1 : Int)) hp4_4_branches146 hp4_4_evidence146 hp4_4_check146 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches146,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node145 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected145 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected145 ((7 : Int),(1 : Int)) hp4_4_branches145 hp4_4_evidence145 hp4_4_check145 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches145,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node144 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected144 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected144 ((8 : Int),(1 : Int)) hp4_4_branches144 hp4_4_evidence144 hp4_4_check144 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches144,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node145 T childKnown
  · exact hp4_4_node146 T childKnown
  · exact hp4_4_node147 T childKnown
  · exact hp4_4_node148 T childKnown
theorem hp4_4_node143 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected143 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected143 ((8 : Int),(1 : Int)) hp4_4_branches143 hp4_4_evidence143 hp4_4_check143 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches143,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node142 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected142 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected142 ((8 : Int),(1 : Int)) hp4_4_branches142 hp4_4_evidence142 hp4_4_check142 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches142,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node141 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected141 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected141 ((8 : Int),(1 : Int)) hp4_4_branches141 hp4_4_evidence141 hp4_4_check141 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches141,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node140 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected140 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected140 ((3 : Int),(2 : Int)) hp4_4_branches140 hp4_4_evidence140 hp4_4_check140 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches140,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node139 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected139 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected139 ((5 : Int),(1 : Int)) hp4_4_branches139 hp4_4_evidence139 hp4_4_check139 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches139,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node140 T childKnown
theorem hp4_4_node138 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected138 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected138 ((7 : Int),(1 : Int)) hp4_4_branches138 hp4_4_evidence138 hp4_4_check138 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches138,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node139 T childKnown
  · exact hp4_4_node141 T childKnown
  · exact hp4_4_node142 T childKnown
  · exact hp4_4_node143 T childKnown
theorem hp4_4_node137 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected137 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected137 ((3 : Int),(2 : Int)) hp4_4_branches137 hp4_4_evidence137 hp4_4_check137 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches137,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node136 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected136 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected136 ((5 : Int),(1 : Int)) hp4_4_branches136 hp4_4_evidence136 hp4_4_check136 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches136,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node137 T childKnown
theorem hp4_4_node135 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected135 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected135 ((7 : Int),(1 : Int)) hp4_4_branches135 hp4_4_evidence135 hp4_4_check135 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches135,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node136 T childKnown
theorem hp4_4_node134 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected134 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected134 ((3 : Int),(2 : Int)) hp4_4_branches134 hp4_4_evidence134 hp4_4_check134 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches134,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node133 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected133 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected133 ((5 : Int),(1 : Int)) hp4_4_branches133 hp4_4_evidence133 hp4_4_check133 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches133,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node134 T childKnown
theorem hp4_4_node132 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected132 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected132 ((7 : Int),(1 : Int)) hp4_4_branches132 hp4_4_evidence132 hp4_4_check132 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches132,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node133 T childKnown
theorem hp4_4_node131 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected131 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected131 ((7 : Int),(1 : Int)) hp4_4_branches131 hp4_4_evidence131 hp4_4_check131 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches131,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node130 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected130 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected130 ((8 : Int),(0 : Int)) hp4_4_branches130 hp4_4_evidence130 hp4_4_check130 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches130,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node131 T childKnown
  · exact hp4_4_node132 T childKnown
  · exact hp4_4_node135 T childKnown
  · exact hp4_4_node138 T childKnown
  · exact hp4_4_node144 T childKnown
theorem hp4_4_node129 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected129 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected129 ((1 : Int),(1 : Int)) hp4_4_branches129 hp4_4_evidence129 hp4_4_check129 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches129,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node128 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected128 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected128 ((1 : Int),(1 : Int)) hp4_4_branches128 hp4_4_evidence128 hp4_4_check128 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches128,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node127 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected127 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected127 ((1 : Int),(1 : Int)) hp4_4_branches127 hp4_4_evidence127 hp4_4_check127 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches127,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node126 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected126 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected126 ((2 : Int),(1 : Int)) hp4_4_branches126 hp4_4_evidence126 hp4_4_check126 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches126,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node125 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected125 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected125 ((1 : Int),(1 : Int)) hp4_4_branches125 hp4_4_evidence125 hp4_4_check125 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches125,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node126 T childKnown
theorem hp4_4_node124 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected124 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected124 ((0 : Int),(1 : Int)) hp4_4_branches124 hp4_4_evidence124 hp4_4_check124 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches124,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node125 T childKnown
  · exact hp4_4_node127 T childKnown
  · exact hp4_4_node128 T childKnown
  · exact hp4_4_node129 T childKnown
theorem hp4_4_node123 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected123 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected123 ((0 : Int),(1 : Int)) hp4_4_branches123 hp4_4_evidence123 hp4_4_check123 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches123,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node122 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected122 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected122 ((1 : Int),(1 : Int)) hp4_4_branches122 hp4_4_evidence122 hp4_4_check122 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches122,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node123 T childKnown
theorem hp4_4_node121 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected121 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected121 ((0 : Int),(1 : Int)) hp4_4_branches121 hp4_4_evidence121 hp4_4_check121 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches121,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node120 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected120 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected120 ((1 : Int),(1 : Int)) hp4_4_branches120 hp4_4_evidence120 hp4_4_check120 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches120,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node121 T childKnown
theorem hp4_4_node119 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected119 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected119 ((1 : Int),(1 : Int)) hp4_4_branches119 hp4_4_evidence119 hp4_4_check119 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches119,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node118 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected118 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected118 ((0 : Int),(1 : Int)) hp4_4_branches118 hp4_4_evidence118 hp4_4_check118 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches118,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node117 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected117 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected117 ((0 : Int),(1 : Int)) hp4_4_branches117 hp4_4_evidence117 hp4_4_check117 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches117,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node116 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected116 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected116 ((1 : Int),(2 : Int)) hp4_4_branches116 hp4_4_evidence116 hp4_4_check116 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches116,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node115 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected115 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected115 ((1 : Int),(2 : Int)) hp4_4_branches115 hp4_4_evidence115 hp4_4_check115 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches115,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node114 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected114 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected114 ((1 : Int),(2 : Int)) hp4_4_branches114 hp4_4_evidence114 hp4_4_check114 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches114,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node113 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected113 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected113 ((3 : Int),(1 : Int)) hp4_4_branches113 hp4_4_evidence113 hp4_4_check113 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches113,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node112 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected112 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected112 ((3 : Int),(1 : Int)) hp4_4_branches112 hp4_4_evidence112 hp4_4_check112 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches112,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node111 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected111 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected111 ((4 : Int),(1 : Int)) hp4_4_branches111 hp4_4_evidence111 hp4_4_check111 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches111,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node110 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected110 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected110 ((4 : Int),(0 : Int)) hp4_4_branches110 hp4_4_evidence110 hp4_4_check110 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches110,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node111 T childKnown
theorem hp4_4_node109 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected109 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected109 ((4 : Int),(2 : Int)) hp4_4_branches109 hp4_4_evidence109 hp4_4_check109 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches109,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node108 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected108 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected108 ((4 : Int),(0 : Int)) hp4_4_branches108 hp4_4_evidence108 hp4_4_check108 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches108,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node109 T childKnown
theorem hp4_4_node107 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected107 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected107 ((3 : Int),(0 : Int)) hp4_4_branches107 hp4_4_evidence107 hp4_4_check107 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches107,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node108 T childKnown
  · exact hp4_4_node110 T childKnown
  · exact hp4_4_node112 T childKnown
  · exact hp4_4_node113 T childKnown
theorem hp4_4_node106 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected106 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected106 ((1 : Int),(2 : Int)) hp4_4_branches106 hp4_4_evidence106 hp4_4_check106 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches106,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node107 T childKnown
theorem hp4_4_node105 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected105 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected105 ((0 : Int),(2 : Int)) hp4_4_branches105 hp4_4_evidence105 hp4_4_check105 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches105,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node106 T childKnown
  · exact hp4_4_node114 T childKnown
  · exact hp4_4_node115 T childKnown
  · exact hp4_4_node116 T childKnown
theorem hp4_4_node104 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected104 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected104 ((2 : Int),(0 : Int)) hp4_4_branches104 hp4_4_evidence104 hp4_4_check104 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches104,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node105 T childKnown
  · exact hp4_4_node117 T childKnown
  · exact hp4_4_node118 T childKnown
  · exact hp4_4_node119 T childKnown
  · exact hp4_4_node120 T childKnown
  · exact hp4_4_node122 T childKnown
  · exact hp4_4_node124 T childKnown
  · exact hp4_4_node130 T childKnown
theorem hp4_4_node103 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected103 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected103 ((2 : Int),(1 : Int)) hp4_4_branches103 hp4_4_evidence103 hp4_4_check103 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches103,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node102 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected102 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected102 ((0 : Int),(1 : Int)) hp4_4_branches102 hp4_4_evidence102 hp4_4_check102 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches102,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node101 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected101 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected101 ((0 : Int),(1 : Int)) hp4_4_branches101 hp4_4_evidence101 hp4_4_check101 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches101,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node100 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected100 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected100 ((0 : Int),(1 : Int)) hp4_4_branches100 hp4_4_evidence100 hp4_4_check100 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches100,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node99 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected99 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected99 ((1 : Int),(1 : Int)) hp4_4_branches99 hp4_4_evidence99 hp4_4_check99 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches99,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node100 T childKnown
  · exact hp4_4_node101 T childKnown
  · exact hp4_4_node102 T childKnown
  · exact hp4_4_node103 T childKnown
theorem hp4_4_node98 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected98 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected98 ((1 : Int),(1 : Int)) hp4_4_branches98 hp4_4_evidence98 hp4_4_check98 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches98,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node97 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected97 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected97 ((1 : Int),(1 : Int)) hp4_4_branches97 hp4_4_evidence97 hp4_4_check97 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches97,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node96 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected96 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected96 ((1 : Int),(1 : Int)) hp4_4_branches96 hp4_4_evidence96 hp4_4_check96 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches96,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node95 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected95 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected95 ((3 : Int),(2 : Int)) hp4_4_branches95 hp4_4_evidence95 hp4_4_check95 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches95,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node94 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected94 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected94 ((3 : Int),(2 : Int)) hp4_4_branches94 hp4_4_evidence94 hp4_4_check94 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches94,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node93 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected93 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected93 ((3 : Int),(1 : Int)) hp4_4_branches93 hp4_4_evidence93 hp4_4_check93 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches93,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node94 T childKnown
  · exact hp4_4_node95 T childKnown
theorem hp4_4_node92 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected92 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected92 ((1 : Int),(1 : Int)) hp4_4_branches92 hp4_4_evidence92 hp4_4_check92 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches92,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node93 T childKnown
theorem hp4_4_node91 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected91 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected91 ((0 : Int),(1 : Int)) hp4_4_branches91 hp4_4_evidence91 hp4_4_check91 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches91,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node92 T childKnown
  · exact hp4_4_node96 T childKnown
  · exact hp4_4_node97 T childKnown
  · exact hp4_4_node98 T childKnown
theorem hp4_4_node90 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected90 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected90 ((2 : Int),(1 : Int)) hp4_4_branches90 hp4_4_evidence90 hp4_4_check90 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches90,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node89 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected89 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected89 ((2 : Int),(0 : Int)) hp4_4_branches89 hp4_4_evidence89 hp4_4_check89 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches89,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node90 T childKnown
theorem hp4_4_node88 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected88 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected88 ((0 : Int),(1 : Int)) hp4_4_branches88 hp4_4_evidence88 hp4_4_check88 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches88,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node89 T childKnown
theorem hp4_4_node87 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected87 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected87 ((3 : Int),(2 : Int)) hp4_4_branches87 hp4_4_evidence87 hp4_4_check87 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches87,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node86 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected86 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected86 ((3 : Int),(2 : Int)) hp4_4_branches86 hp4_4_evidence86 hp4_4_check86 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches86,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node85 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected85 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected85 ((2 : Int),(2 : Int)) hp4_4_branches85 hp4_4_evidence85 hp4_4_check85 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches85,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node86 T childKnown
  · exact hp4_4_node87 T childKnown
theorem hp4_4_node84 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected84 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected84 ((2 : Int),(0 : Int)) hp4_4_branches84 hp4_4_evidence84 hp4_4_check84 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches84,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node85 T childKnown
theorem hp4_4_node83 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected83 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected83 ((0 : Int),(1 : Int)) hp4_4_branches83 hp4_4_evidence83 hp4_4_check83 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches83,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node84 T childKnown
theorem hp4_4_node82 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected82 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected82 ((0 : Int),(1 : Int)) hp4_4_branches82 hp4_4_evidence82 hp4_4_check82 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches82,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node81 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected81 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected81 ((1 : Int),(0 : Int)) hp4_4_branches81 hp4_4_evidence81 hp4_4_check81 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches81,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node82 T childKnown
  · exact hp4_4_node83 T childKnown
  · exact hp4_4_node88 T childKnown
  · exact hp4_4_node91 T childKnown
  · exact hp4_4_node99 T childKnown
theorem hp4_4_node80 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected80 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected80 ((8 : Int),(1 : Int)) hp4_4_branches80 hp4_4_evidence80 hp4_4_check80 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches80,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node79 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected79 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected79 ((6 : Int),(1 : Int)) hp4_4_branches79 hp4_4_evidence79 hp4_4_check79 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches79,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node78 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected78 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected78 ((6 : Int),(1 : Int)) hp4_4_branches78 hp4_4_evidence78 hp4_4_check78 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches78,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node77 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected77 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected77 ((6 : Int),(1 : Int)) hp4_4_branches77 hp4_4_evidence77 hp4_4_check77 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches77,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node76 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected76 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected76 ((7 : Int),(1 : Int)) hp4_4_branches76 hp4_4_evidence76 hp4_4_check76 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches76,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node77 T childKnown
  · exact hp4_4_node78 T childKnown
  · exact hp4_4_node79 T childKnown
  · exact hp4_4_node80 T childKnown
theorem hp4_4_node75 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected75 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected75 ((7 : Int),(1 : Int)) hp4_4_branches75 hp4_4_evidence75 hp4_4_check75 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches75,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node74 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected74 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected74 ((7 : Int),(1 : Int)) hp4_4_branches74 hp4_4_evidence74 hp4_4_check74 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches74,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node73 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected73 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected73 ((7 : Int),(1 : Int)) hp4_4_branches73 hp4_4_evidence73 hp4_4_check73 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches73,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node72 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected72 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected72 ((2 : Int),(2 : Int)) hp4_4_branches72 hp4_4_evidence72 hp4_4_check72 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches72,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node71 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected71 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected71 ((4 : Int),(1 : Int)) hp4_4_branches71 hp4_4_evidence71 hp4_4_check71 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches71,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node72 T childKnown
theorem hp4_4_node70 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected70 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected70 ((6 : Int),(1 : Int)) hp4_4_branches70 hp4_4_evidence70 hp4_4_check70 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches70,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node71 T childKnown
  · exact hp4_4_node73 T childKnown
  · exact hp4_4_node74 T childKnown
  · exact hp4_4_node75 T childKnown
theorem hp4_4_node69 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected69 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected69 ((2 : Int),(2 : Int)) hp4_4_branches69 hp4_4_evidence69 hp4_4_check69 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches69,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node68 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected68 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected68 ((4 : Int),(1 : Int)) hp4_4_branches68 hp4_4_evidence68 hp4_4_check68 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches68,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node69 T childKnown
theorem hp4_4_node67 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected67 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected67 ((6 : Int),(1 : Int)) hp4_4_branches67 hp4_4_evidence67 hp4_4_check67 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches67,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node68 T childKnown
theorem hp4_4_node66 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected66 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected66 ((2 : Int),(2 : Int)) hp4_4_branches66 hp4_4_evidence66 hp4_4_check66 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches66,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node65 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected65 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected65 ((4 : Int),(1 : Int)) hp4_4_branches65 hp4_4_evidence65 hp4_4_check65 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches65,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node66 T childKnown
theorem hp4_4_node64 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected64 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected64 ((6 : Int),(1 : Int)) hp4_4_branches64 hp4_4_evidence64 hp4_4_check64 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches64,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node65 T childKnown
theorem hp4_4_node63 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected63 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected63 ((6 : Int),(1 : Int)) hp4_4_branches63 hp4_4_evidence63 hp4_4_check63 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches63,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node62 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected62 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected62 ((7 : Int),(0 : Int)) hp4_4_branches62 hp4_4_evidence62 hp4_4_check62 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches62,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node63 T childKnown
  · exact hp4_4_node64 T childKnown
  · exact hp4_4_node67 T childKnown
  · exact hp4_4_node70 T childKnown
  · exact hp4_4_node76 T childKnown
theorem hp4_4_node61 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected61 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected61 ((1 : Int),(1 : Int)) hp4_4_branches61 hp4_4_evidence61 hp4_4_check61 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches61,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node60 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected60 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected60 ((1 : Int),(1 : Int)) hp4_4_branches60 hp4_4_evidence60 hp4_4_check60 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches60,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node59 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected59 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected59 ((1 : Int),(1 : Int)) hp4_4_branches59 hp4_4_evidence59 hp4_4_check59 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches59,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node58 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected58 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected58 ((3 : Int),(2 : Int)) hp4_4_branches58 hp4_4_evidence58 hp4_4_check58 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches58,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node57 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected57 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected57 ((3 : Int),(2 : Int)) hp4_4_branches57 hp4_4_evidence57 hp4_4_check57 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches57,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node56 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected56 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected56 ((3 : Int),(1 : Int)) hp4_4_branches56 hp4_4_evidence56 hp4_4_check56 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches56,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node57 T childKnown
  · exact hp4_4_node58 T childKnown
theorem hp4_4_node55 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected55 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected55 ((1 : Int),(1 : Int)) hp4_4_branches55 hp4_4_evidence55 hp4_4_check55 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches55,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node56 T childKnown
theorem hp4_4_node54 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected54 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected54 ((0 : Int),(1 : Int)) hp4_4_branches54 hp4_4_evidence54 hp4_4_check54 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches54,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node55 T childKnown
  · exact hp4_4_node59 T childKnown
  · exact hp4_4_node60 T childKnown
  · exact hp4_4_node61 T childKnown
theorem hp4_4_node53 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected53 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected53 ((2 : Int),(1 : Int)) hp4_4_branches53 hp4_4_evidence53 hp4_4_check53 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches53,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node52 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected52 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected52 ((2 : Int),(0 : Int)) hp4_4_branches52 hp4_4_evidence52 hp4_4_check52 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches52,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node53 T childKnown
theorem hp4_4_node51 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected51 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected51 ((0 : Int),(1 : Int)) hp4_4_branches51 hp4_4_evidence51 hp4_4_check51 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches51,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node52 T childKnown
theorem hp4_4_node50 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected50 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected50 ((3 : Int),(2 : Int)) hp4_4_branches50 hp4_4_evidence50 hp4_4_check50 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches50,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node49 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected49 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected49 ((3 : Int),(2 : Int)) hp4_4_branches49 hp4_4_evidence49 hp4_4_check49 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches49,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node48 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected48 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected48 ((2 : Int),(2 : Int)) hp4_4_branches48 hp4_4_evidence48 hp4_4_check48 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches48,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node49 T childKnown
  · exact hp4_4_node50 T childKnown
theorem hp4_4_node47 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected47 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected47 ((2 : Int),(0 : Int)) hp4_4_branches47 hp4_4_evidence47 hp4_4_check47 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches47,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node48 T childKnown
theorem hp4_4_node46 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected46 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected46 ((0 : Int),(1 : Int)) hp4_4_branches46 hp4_4_evidence46 hp4_4_check46 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches46,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node47 T childKnown
theorem hp4_4_node45 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected45 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected45 ((0 : Int),(1 : Int)) hp4_4_branches45 hp4_4_evidence45 hp4_4_check45 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches45,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node44 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected44 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected44 ((0 : Int),(1 : Int)) hp4_4_branches44 hp4_4_evidence44 hp4_4_check44 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches44,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node43 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected43 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected43 ((0 : Int),(1 : Int)) hp4_4_branches43 hp4_4_evidence43 hp4_4_check43 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches43,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node42 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected42 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected42 ((2 : Int),(1 : Int)) hp4_4_branches42 hp4_4_evidence42 hp4_4_check42 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches42,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node41 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected41 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected41 ((2 : Int),(1 : Int)) hp4_4_branches41 hp4_4_evidence41 hp4_4_check41 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches41,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node40 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected40 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected40 ((3 : Int),(1 : Int)) hp4_4_branches40 hp4_4_evidence40 hp4_4_check40 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches40,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node39 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected39 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected39 ((3 : Int),(0 : Int)) hp4_4_branches39 hp4_4_evidence39 hp4_4_check39 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches39,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node40 T childKnown
theorem hp4_4_node38 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected38 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected38 ((3 : Int),(2 : Int)) hp4_4_branches38 hp4_4_evidence38 hp4_4_check38 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches38,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node37 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected37 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected37 ((3 : Int),(0 : Int)) hp4_4_branches37 hp4_4_evidence37 hp4_4_check37 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches37,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node38 T childKnown
theorem hp4_4_node36 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected36 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected36 ((2 : Int),(0 : Int)) hp4_4_branches36 hp4_4_evidence36 hp4_4_check36 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches36,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node37 T childKnown
  · exact hp4_4_node39 T childKnown
  · exact hp4_4_node41 T childKnown
  · exact hp4_4_node42 T childKnown
theorem hp4_4_node35 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected35 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected35 ((2 : Int),(1 : Int)) hp4_4_branches35 hp4_4_evidence35 hp4_4_check35 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches35,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node34 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected34 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected34 ((2 : Int),(1 : Int)) hp4_4_branches34 hp4_4_evidence34 hp4_4_check34 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches34,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node33 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected33 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected33 ((3 : Int),(1 : Int)) hp4_4_branches33 hp4_4_evidence33 hp4_4_check33 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches33,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node32 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected32 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected32 ((3 : Int),(0 : Int)) hp4_4_branches32 hp4_4_evidence32 hp4_4_check32 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches32,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node33 T childKnown
theorem hp4_4_node31 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected31 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected31 ((3 : Int),(2 : Int)) hp4_4_branches31 hp4_4_evidence31 hp4_4_check31 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches31,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node30 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected30 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected30 ((3 : Int),(0 : Int)) hp4_4_branches30 hp4_4_evidence30 hp4_4_check30 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches30,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node31 T childKnown
theorem hp4_4_node29 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected29 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected29 ((2 : Int),(0 : Int)) hp4_4_branches29 hp4_4_evidence29 hp4_4_check29 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches29,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node30 T childKnown
  · exact hp4_4_node32 T childKnown
  · exact hp4_4_node34 T childKnown
  · exact hp4_4_node35 T childKnown
theorem hp4_4_node28 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected28 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected28 ((3 : Int),(1 : Int)) hp4_4_branches28 hp4_4_evidence28 hp4_4_check28 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches28,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node27 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected27 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected27 ((2 : Int),(1 : Int)) hp4_4_branches27 hp4_4_evidence27 hp4_4_check27 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches27,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node28 T childKnown
theorem hp4_4_node26 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected26 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected26 ((4 : Int),(2 : Int)) hp4_4_branches26 hp4_4_evidence26 hp4_4_check26 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches26,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node25 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected25 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected25 ((4 : Int),(2 : Int)) hp4_4_branches25 hp4_4_evidence25 hp4_4_check25 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches25,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node24 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected24 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected24 ((4 : Int),(1 : Int)) hp4_4_branches24 hp4_4_evidence24 hp4_4_check24 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches24,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node25 T childKnown
  · exact hp4_4_node26 T childKnown
theorem hp4_4_node23 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected23 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected23 ((2 : Int),(1 : Int)) hp4_4_branches23 hp4_4_evidence23 hp4_4_check23 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches23,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node24 T childKnown
theorem hp4_4_node22 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected22 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected22 ((3 : Int),(1 : Int)) hp4_4_branches22 hp4_4_evidence22 hp4_4_check22 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches22,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node21 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected21 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected21 ((3 : Int),(0 : Int)) hp4_4_branches21 hp4_4_evidence21 hp4_4_check21 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches21,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node22 T childKnown
theorem hp4_4_node20 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected20 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected20 ((4 : Int),(2 : Int)) hp4_4_branches20 hp4_4_evidence20 hp4_4_check20 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches20,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node19 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected19 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected19 ((4 : Int),(2 : Int)) hp4_4_branches19 hp4_4_evidence19 hp4_4_check19 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches19,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node18 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected18 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected18 ((3 : Int),(2 : Int)) hp4_4_branches18 hp4_4_evidence18 hp4_4_check18 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches18,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node19 T childKnown
  · exact hp4_4_node20 T childKnown
theorem hp4_4_node17 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected17 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected17 ((3 : Int),(0 : Int)) hp4_4_branches17 hp4_4_evidence17 hp4_4_check17 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches17,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node18 T childKnown
theorem hp4_4_node16 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected16 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected16 ((2 : Int),(0 : Int)) hp4_4_branches16 hp4_4_evidence16 hp4_4_check16 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches16,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node17 T childKnown
  · exact hp4_4_node21 T childKnown
  · exact hp4_4_node23 T childKnown
  · exact hp4_4_node27 T childKnown
theorem hp4_4_node15 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected15 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected15 ((3 : Int),(1 : Int)) hp4_4_branches15 hp4_4_evidence15 hp4_4_check15 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches15,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node14 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected14 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected14 ((2 : Int),(1 : Int)) hp4_4_branches14 hp4_4_evidence14 hp4_4_check14 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches14,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node15 T childKnown
theorem hp4_4_node13 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected13 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected13 ((4 : Int),(2 : Int)) hp4_4_branches13 hp4_4_evidence13 hp4_4_check13 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches13,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node12 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected12 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected12 ((4 : Int),(2 : Int)) hp4_4_branches12 hp4_4_evidence12 hp4_4_check12 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches12,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node11 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected11 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected11 ((4 : Int),(1 : Int)) hp4_4_branches11 hp4_4_evidence11 hp4_4_check11 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches11,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node12 T childKnown
  · exact hp4_4_node13 T childKnown
theorem hp4_4_node10 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected10 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected10 ((2 : Int),(1 : Int)) hp4_4_branches10 hp4_4_evidence10 hp4_4_check10 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches10,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node11 T childKnown
theorem hp4_4_node9 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected9 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected9 ((3 : Int),(1 : Int)) hp4_4_branches9 hp4_4_evidence9 hp4_4_check9 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches9,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node8 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected8 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected8 ((3 : Int),(0 : Int)) hp4_4_branches8 hp4_4_evidence8 hp4_4_check8 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches8,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node9 T childKnown
theorem hp4_4_node7 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected7 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected7 ((4 : Int),(2 : Int)) hp4_4_branches7 hp4_4_evidence7 hp4_4_check7 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches7,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node6 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected6 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected6 ((4 : Int),(2 : Int)) hp4_4_branches6 hp4_4_evidence6 hp4_4_check6 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches6,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp4_4_node5 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected5 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected5 ((3 : Int),(2 : Int)) hp4_4_branches5 hp4_4_evidence5 hp4_4_check5 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches5,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp4_4_node6 T childKnown
  · exact hp4_4_node7 T childKnown
theorem hp4_4_node4 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected4 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected4 ((3 : Int),(0 : Int)) hp4_4_branches4 hp4_4_evidence4 hp4_4_check4 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches4,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp4_4_node5 T childKnown
theorem hp4_4_node3 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected3 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected3 ((2 : Int),(0 : Int)) hp4_4_branches3 hp4_4_evidence3 hp4_4_check3 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches3,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node4 T childKnown
  · exact hp4_4_node8 T childKnown
  · exact hp4_4_node10 T childKnown
  · exact hp4_4_node14 T childKnown
theorem hp4_4_node2 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected2 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected2 ((0 : Int),(2 : Int)) hp4_4_branches2 hp4_4_evidence2 hp4_4_check2 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches2,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp4_4_node3 T childKnown
  · exact hp4_4_node16 T childKnown
  · exact hp4_4_node29 T childKnown
  · exact hp4_4_node36 T childKnown
theorem hp4_4_node1 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected1 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected1 ((1 : Int),(0 : Int)) hp4_4_branches1 hp4_4_evidence1 hp4_4_check1 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches1,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node2 T childKnown
  · exact hp4_4_node43 T childKnown
  · exact hp4_4_node44 T childKnown
  · exact hp4_4_node45 T childKnown
  · exact hp4_4_node46 T childKnown
  · exact hp4_4_node51 T childKnown
  · exact hp4_4_node54 T childKnown
  · exact hp4_4_node62 T childKnown
theorem hp4_4_node0 (T : Tiling (4 : Int) (4 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp4_4_selected0 → T.world s) : False := by
  apply replay_step (4 : Int) (4 : Int) (by decide) (by decide) T hp4_4_selected0 ((0 : Int),(0 : Int)) hp4_4_branches0 hp4_4_evidence0 hp4_4_check0 ?_ known
  intro t member childKnown
  simp only [hp4_4_branches0,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp4_4_node1 T childKnown
  · exact hp4_4_node81 T childKnown
  · exact hp4_4_node104 T childKnown
  · exact hp4_4_node149 T childKnown
  · exact hp4_4_node172 T childKnown
  · exact hp4_4_node188 T childKnown
  · exact hp4_4_node204 T childKnown
  · exact hp4_4_node207 T childKnown
  · exact hp4_4_node246 T childKnown
  · exact hp4_4_node269 T childKnown
  · exact hp4_4_node387 T childKnown
  · exact hp4_4_node410 T childKnown
  · exact hp4_4_node528 T childKnown
  · exact hp4_4_node551 T childKnown
  · exact hp4_4_node553 T childKnown
  · exact hp4_4_node560 T childKnown
  · exact hp4_4_node562 T childKnown
  · exact hp4_4_node933 T childKnown

theorem hp4_4_no_half_plane : ¬Tiles (4 : Int) (4 : Int) 1 0 HalfPlane := by
  rintro ⟨T⟩
  exact hp4_4_node0 T (by simp [hp4_4_selected0])
#print axioms hp4_4_no_half_plane

end THalfPlaneFinite

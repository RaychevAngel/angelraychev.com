import LQuadrantHpAlternatingUnequalBarLongFixed53PrunedArithmetic
import TilingCore
import TPlaneGeometry
import TilingSymmetry
import LHalfPlaneBoundaryTips
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PolyominoFormal.LRegion
open CrossUnits
def HP_alternating_unequal_bar_long_fixed_5_3_pruned_M (a b : Int) : Int := 20*(a+b+1)
def HP_alternating_unequal_bar_long_fixed_5_3_pruned_Box (a b x y : Int) : Prop := -HP_alternating_unequal_bar_long_fixed_5_3_pruned_M a b ≤ x ∧ 0≤y ∧ x≤HP_alternating_unequal_bar_long_fixed_5_3_pruned_M a b ∧ y≤HP_alternating_unequal_bar_long_fixed_5_3_pruned_M a b
def HP_alternating_unequal_bar_long_fixed_5_3_pruned_Inside (t : Cross) : Prop := 0≤t.y-t.south

end PolyominoFormal.LRegion

import LHalfPlaneShortbarWindowBottom
import LQuadrantHpSeparatedFrontShortWindowPrunedGeometry

namespace PolyominoFormal.LRegion
open CrossUnits
set_option maxHeartbeats 10000000
set_option linter.unusedVariables false

/-- A genuinely local obstruction: only the rectangle enclosed by the two
short floor bars has to be covered. No half-plane extension is assumed. -/
theorem short_window_upright_long_impossible (a b : Int)
    (ha : 5≤a) (hb : 3≤b) (hab : b+2≤a)
    (world : Cross → Prop) (copies : ∀ t,world t → Copy a b 0 0 t)
    (cover : ∀ x y,0≤x ∧ 0≤y ∧ x≤2*b+1 ∧ y≤a →
      ∃ t,world t ∧ Contains t x y)
    (disjoint : ∀t u x y,world t → world u → Contains t x y → Contains u x y → t=u)
    (hO : world ⟨0,0,b,a,0,0⟩)
    (hU : world ⟨1,1,a,b,0,0⟩)
    (hF : world ⟨2*b+1,0,0,a,b,0⟩) : False := by
  classical
  let O : Cross := ⟨0,0,b,a,0,0⟩
  let F : Cross := ⟨2*b+1,0,0,a,b,0⟩
  let selected : Cross → Prop := fun t => world t ∧ (t=O ∨ t=F ∨ 1≤t.y-t.south)
  have nn : ∀ t,world t → TPlane.Nonnegative t := by
    intro t ht
    exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies t ht)
  have selcover : ∀ x y,0≤x ∧ 0≤y ∧ x≤2*b+1 ∧ y≤a →
      ∃ t,selected t ∧ Contains t x y := by
    intro x y window
    obtain ⟨t,ht,hit⟩ := cover x y window
    refine ⟨t,⟨ht,?_⟩,hit⟩
    by_cases eqO : t=O
    · exact Or.inl eqO
    by_cases eqF : t=F
    · exact Or.inr (Or.inl eqF)
    right; right
    apply short_window_bottom a b x y t (by omega) (by omega) (nn t ht) window hit
    · apply TPlane.apart_of_no_common_nonnegative t O (nn t ht) (nn O hO)
      intro u v h1 h2
      exact eqO (disjoint t O u v ht hO h1 h2)
    · apply TPlane.apart_of_no_common_nonnegative t F (nn t ht) (nn F hF)
      intro u v h1 h2
      exact eqF (disjoint t F u v ht hF h1 h2)
  have inside : ∀t,selected t → 0≤t.y-t.south := by
    intro t ht
    rcases ht.2 with eq | eq | above
    · subst t; dsimp [O]; omega
    · subst t; dsimp [F]; omega
    · omega
  have noTip : ∀t,selected t → ¬ForbiddenBoundaryTip a b t := by
    intro t ht bad
    rcases ht.2 with eq | eq | above
    · subst t; unfold ForbiddenBoundaryTip ForbiddenShortTip at bad; dsimp [O] at bad; omega
    · subst t; unfold ForbiddenBoundaryTip ForbiddenShortTip at bad; dsimp [F] at bad; omega
    · unfold ForbiddenBoundaryTip ForbiddenShortTip at bad; omega
  have noLongBar : ∀t,selected t → ¬(t.y=0 ∧ t.north=b ∧ t.south=0) := by
    intro t ht bad
    rcases ht.2 with eq | eq | above
    · subst t; dsimp [O] at bad; omega
    · subst t; dsimp [F] at bad; omega
    · omega
  have noPair : ∀t u,selected t → selected u → ¬ForbiddenBoundaryPairs a b t u := by
    intro t u ht hu bad
    have nt := noLongBar t ht
    have nu := noLongBar u hu
    unfold ForbiddenBoundaryPairs ForbiddenSameBoundaryBars ForbiddenLongBoundaryCorner LongBoundaryCorner at bad
    omega
  apply HP_separated_front_short_window_pruned_bounded_obstruction a b
    (by omega) hb (by omega) ha hab selected
    (fun t ht => copies t ht.1) inside selcover
    (fun t u x y ht hu hx hy => disjoint t u x y ht.1 hu.1 hx hy) noTip noPair
  · exact ⟨hO,Or.inl rfl⟩
  · exact ⟨hU,Or.inr (Or.inr (by dsimp; omega))⟩
  · have hf : selected F := ⟨hF,Or.inr (Or.inl rfl)⟩
    simpa only [F,Int.add_comm] using hf

/-- The local obstruction at any nonnegative height in a genuine half-plane tiling. -/
theorem short_window_upright_long_shifted (a b p h : Int)
    (ha : 5≤a) (hb : 3≤b) (hab : b+2≤a) (hh : 0≤h)
    (T : Tiling a b 0 0 HalfPlane)
    (hO : T.world ⟨p,h,b,a,0,0⟩)
    (hU : T.world ⟨p+1,h+1,a,b,0,0⟩)
    (hF : T.world ⟨p+2*b+1,h,0,a,b,0⟩) : False := by
  let V := T.translate (-p) (-h)
  refine short_window_upright_long_impossible a b ha hb hab V.world V.copies ?_ V.disjoint ?_ ?_ ?_
  · intro x y window
    apply V.cover
    change 0≤y-(-h)
    omega
  · refine ⟨_,hO,?_⟩
    apply same_eq; dsimp [Same,shift]; omega
  · refine ⟨_,hU,?_⟩
    apply same_eq; dsimp [Same,shift]; omega
  · refine ⟨_,hF,?_⟩
    apply same_eq; dsimp [Same,shift]; omega

#print axioms short_window_upright_long_impossible
#print axioms short_window_upright_long_shifted

/-- The reflected inner long bar gives the second orientation of the pocket. -/
theorem short_window_upright_long_reflected (a b p h : Int)
    (ha : 5≤a) (hb : 3≤b) (hab : b+2≤a) (hh : 0≤h)
    (T : Tiling a b 0 0 HalfPlane)
    (hO : T.world ⟨p,h,b,a,0,0⟩)
    (hU : T.world ⟨p+2*b,h+1,0,b,a,0⟩)
    (hF : T.world ⟨p+2*b+1,h,0,a,b,0⟩) : False := by
  apply short_window_upright_long_shifted a b (-(p+2*b+1)) h ha hb hab hh T.mirrorX
  · exact ⟨_,hF,rfl⟩
  · refine ⟨_,hU,?_⟩
    apply same_eq; dsimp [Same,mirrorX]; omega
  · refine ⟨_,hO,?_⟩
    apply same_eq; dsimp [Same,mirrorX]; omega

def WindowObstruction (a b : Int) (world : Cross → Prop) : Prop :=
  ∀ p h,0≤h → world ⟨p,h,b,a,0,0⟩ → world ⟨p+1,h+1,a,b,0,0⟩ →
    world ⟨p+2*b+1,h,0,a,b,0⟩ → False

theorem tiling_short_window_obstruction (a b : Int)
    (ha : 5≤a) (hb : 3≤b) (hab : b+2≤a)
    (T : Tiling a b 0 0 HalfPlane) : WindowObstruction a b T.world := by
  intro p h hh hO hU hF
  exact short_window_upright_long_shifted a b p h ha hb hab hh T hO hU hF

def ReflectedWindowObstruction (a b : Int) (world : Cross → Prop) : Prop :=
  ∀ p h,0≤h → world ⟨p,h,b,a,0,0⟩ → world ⟨p+2*b,h+1,0,b,a,0⟩ →
    world ⟨p+2*b+1,h,0,a,b,0⟩ → False

theorem tiling_reflected_window_obstruction (a b : Int)
    (ha : 5≤a) (hb : 3≤b) (hab : b+2≤a)
    (T : Tiling a b 0 0 HalfPlane) : ReflectedWindowObstruction a b T.world := by
  intro p h hh hO hU hF
  exact short_window_upright_long_reflected a b p h ha hb hab hh T hO hU hF

#print axioms tiling_reflected_window_obstruction
#print axioms tiling_short_window_obstruction
end PolyominoFormal.LRegion

import TRepObstruction
import PositiveHierarchy

namespace PolyominoFormal

structure ExactStrip (a b c d : Int) : Prop where
  no_rectangle : ¬RectangleTileable a b c d
  no_half_strip : ¬HalfStripTileable a b c d
  no_bent_strip : ¬BentStripTileable a b c d
  no_quadrant : ¬Tiles a b c d Quadrant
  strip : StripTileable a b c d
  half_plane : Tiles a b c d HalfPlane
  plane : Tiles a b c d Plane
  no_rep : ¬RepTileable a b c d

theorem unit_stem_exact_strip (a c : Int) (ha : 2≤a) (hc : 2≤c) : ExactStrip a 1 c 0 := by
  have nq := TBoundary.no_quadrant (b:=1) ha (by omega) hc
  have ns : ¬HalfStripTileable a 1 c 0 := fun h => nq (half_strip_implies_quadrant h)
  have positive := PositiveConstructions.strip_tileable a c (by omega) (by omega)
  exact ⟨(fun h => ns (rectangle_implies_half_strip h)),ns,
    (fun h => nq (PositiveHierarchy.bent_tiles_quadrant h)),nq,positive,
    PositiveHierarchy.strip_tiles_halfplane positive,PositiveHierarchy.strip_tiles_plane positive,
    TRepObstruction.no_rep ha (by omega) hc⟩

#print axioms unit_stem_exact_strip
end PolyominoFormal

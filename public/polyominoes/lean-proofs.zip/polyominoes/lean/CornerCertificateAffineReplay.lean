import CornerCertificateReplay
import TPlaneGeometry

namespace CornerCertificate
open CrossUnits

def knownCells (known : List Cross) : List Cell := known.flatMap cells

def KnownContains (known : List Cross) (x y : Int) : Prop :=
  ∃ t, t ∈ known ∧ Contains t x y

theorem mem_knownCells_iff {known : List Cross}
    (nonnegative : ∀ t, t ∈ known → Nonnegative t) (x y : Int) :
    (x,y) ∈ knownCells known ↔ KnownContains known x y := by
  simp only [knownCells, List.mem_flatMap, KnownContains]
  constructor
  · rintro ⟨t,mem,hit⟩
    exact ⟨t,mem,(mem_cells_iff (nonnegative t mem) x y).1 hit⟩
  · rintro ⟨t,mem,hit⟩
    exact ⟨t,mem,(mem_cells_iff (nonnegative t mem) x y).2 hit⟩

theorem known_top_below {world : Cross → Prop} {h : Int} {known : List Cross}
    {B : Int → Int → Prop} (state : State world h (knownCells known) B)
    (nonnegative : ∀ t, t ∈ known → Nonnegative t)
    {t : Cross} (mem : t ∈ known) : t.y+t.north < h := by
  have nn := nonnegative t mem
  have hit : Contains t t.x (t.y+t.north) := by
    right
    exact ⟨by omega,by omega,by rcases nn with ⟨he,hn,hw,hs⟩; omega,by omega⟩
  have point := (mem_knownCells_iff nonnegative t.x (t.y+t.north)).2 ⟨t,mem,hit⟩
  exact state.2.1 _ _ (state.2.2.1 _ point)

theorem known_separate {known : List Cross}
    {B : Int → Int → Prop}
    (occupied : ∀ p, p ∈ knownCells known → B p.1 p.2)
    (nonnegative : ∀ t, t ∈ known → Nonnegative t)
    {t : Cross} (nn : Nonnegative t)
    (fresh : ∀ x y, Contains t x y → ¬B x y) :
    ∀ u, u ∈ known → Apart t u := by
  intro u mem
  apply TPlane.apart_of_no_common_nonnegative t u nn (nonnegative u mem)
  intro x y ht hu
  have point := (mem_knownCells_iff nonnegative x y).2 ⟨u,mem,hu⟩
  exact fresh x y ht (occupied _ point)

/-- Symbolic completeness is supplied by parameter-wide arithmetic lemmas;
this theorem supplies the actual tiling semantics and all blocked-set updates. -/
theorem replay_affine_step (a : Int) (ha : 0 ≤ a) (world : Cross → Prop)
    (h : Int) (source : Kind) (known : List Cross) (p : Cell)
    (branches : List Branch)
    (copies : ∀ t, world t → Copy a 1 1 0 t)
    (separate : DisjointWorld world) (cover : CoversWindow world h)
    (ceiling : SelectedBelow world h)
    (nonnegative : ∀ t, t ∈ known → Nonnegative t)
    (window : QueryWindow h p.1 p.2)
    (empty : ¬KnownContains known p.1 p.2)
    (complete : ∀ t, Copy a 1 1 0 t → Contains t p.1 p.2 →
      (∀ u, u ∈ known → Apart t u) → ∃ b, b ∈ branches ∧ b.tile=t)
    (updates : ∀ b, b ∈ branches →
      SameCells b.occupied (knownCells known ++ cells b.tile))
    (next : ∀ b, b ∈ branches → ∀ B, State world h b.occupied B →
      Transition world h source B)
    (B : Int → Int → Prop) (state : State world h (knownCells known) B) :
    Transition world h source B := by
  obtain ⟨closed,bounded,occupied,agreement⟩ := state
  obtain ⟨t,ht,hit⟩ := cover p.1 p.2 window
  have freshB : ¬B p.1 p.2 := by
    intro bad
    exact empty ((mem_knownCells_iff nonnegative p.1 p.2).1
      ((agreement p.1 p.2 window.1 window.2.2.1).1 bad))
  have fresh := fresh_disjoint closed ht hit freshB
  have nn := copy_nonnegative ha (copies t ht)
  have apart := known_separate occupied nonnegative nn fresh
  obtain ⟨b,hb,eq⟩ := complete t (copies t ht) hit apart
  have update := updates b hb
  have bState : State world h b.occupied (addTile B t) := by
    refine ⟨addTile_closed closed separate ht,?_,?_,?_⟩
    · intro x y member
      rcases member with member | member
      · exact bounded x y member
      · exact ceiling t ht ⟨p.1,p.2,window,hit⟩ x y member
    · intro q hq
      have union := (sameCells_iff update q).1 hq
      rw [List.mem_append, eq] at union
      rcases union with old | new
      · exact Or.inl (occupied q old)
      · exact Or.inr ((mem_cells_iff nn q.1 q.2).1 new)
    · intro x y hx hy
      rw [sameCells_iff update (x,y), List.mem_append, eq]
      exact or_congr (agreement x y hx hy) (mem_cells_iff nn x y).symm
  exact transition_back (addTile_enlarges ht) (next b hb (addTile B t) bState)

theorem replay_affine_leaf (world : Cross → Prop) (h : Int) (source : Kind)
    (known : List Cross) (new : Kind) (dx dy : Int)
    (nonnegative : ∀ t, t ∈ known → Nonnegative t)
    (progress : Progress source new dx dy)
    (walls : ∀ x y, Wall new x y → KnownContains known (dx+x) (dy+y))
    (future : ∀ x y, dx ≤ x → dy ≤ y →
      (KnownContains known x y ↔ Extra new (x-dx) (y-dy)))
    (B : Int → Int → Prop) (state : State world h (knownCells known) B) :
    Transition world h source B := by
  obtain ⟨closed,bounded,occupied,agreement⟩ := state
  refine ⟨B,new,dx,dy,enlarges_refl world B,closed,bounded,?_,progress⟩
  constructor
  · intro x y wall
    exact occupied _ ((mem_knownCells_iff nonnegative (dx+x) (dy+y)).2 (walls x y wall))
  · intro x y hx hy
    have hx' : 0 ≤ dx+x := by have := progress.1; omega
    have hy' : 0 ≤ dy+y := by have := progress.2.1; omega
    have boundx : dx ≤ dx+x := by omega
    have boundy : dy ≤ dy+y := by omega
    have offsets : Extra new ((dx+x)-dx) ((dy+y)-dy) ↔ Extra new x y := by
      have ex : dx+x-dx=x := by omega
      have ey : dy+y-dy=y := by omega
      rw [ex,ey]
    exact (agreement (dx+x) (dy+y) hx' hy').trans
      ((mem_knownCells_iff nonnegative (dx+x) (dy+y)).trans
        ((future (dx+x) (dy+y) boundx boundy).trans offsets))

end CornerCertificate

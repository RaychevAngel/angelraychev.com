import TilingSymmetry
import TPlaneGeometry
set_option maxHeartbeats 4000000
set_option maxRecDepth 100000
namespace PolyominoFormal.TBoundary
open CrossUnits

theorem quadrant_bounds {a b c : Int} (ha : 0≤a) (hb : 0≤b) (hc : 0≤c)
    (T : Tiling a b c 0 Quadrant) {t : Cross} (ht : T.world t) :
    0≤t.x-t.west ∧ 0≤t.y-t.south := by
  have nn := TPlane.copy_nonnegative ha hb hc (by omega) (T.copies t ht)
  have hw := T.inside t ht (t.x-t.west) t.y (by unfold Contains; unfold TPlane.Nonnegative at nn; left; omega)
  have hs := T.inside t ht t.x (t.y-t.south) (by unfold Contains; unfold TPlane.Nonnegative at nn; right; omega)
  exact ⟨hw.1,hs.2⟩

theorem separate {a b c : Int} {R : Region} (ha : 0≤a) (hb : 0≤b) (hc : 0≤c)
    (T : Tiling a b c 0 R) {t u : Cross} (ht : T.world t) (hu : T.world u)
    {x y : Int} (hit : Contains t x y) (empty : ¬Contains u x y) : Apart t u := by
  apply TPlane.apart_of_no_common_nonnegative t u
    (TPlane.copy_nonnegative ha hb hc (by omega) (T.copies t ht))
    (TPlane.copy_nonnegative ha hb hc (by omega) (T.copies u hu))
  intro p q hp hq
  have eq := T.disjoint t u p q ht hu hp hq
  exact empty (eq ▸ hit)

theorem corner_forms {a b c : Int} (ha : 1≤a) (hb : 1≤b) (hc : 1≤c)
    {t : Cross} (copy : Copy a b c 0 t) (bound : 0≤t.x-t.west ∧ 0≤t.y-t.south)
    (hit : Contains t 0 0) :
    t=⟨c,0,a,b,c,0⟩ ∨ t=⟨a,0,c,b,a,0⟩ ∨
    t=⟨0,c,b,a,0,c⟩ ∨ t=⟨0,a,b,c,0,a⟩ := by
  rcases t with ⟨x,y,e,n,w,s⟩
  rcases copy with h | h | h | h | h | h | h | h
  all_goals rcases h with ⟨he,hn,hw,hs⟩
  all_goals dsimp only at he hn hw hs bound hit
  all_goals subst e; subst n; subst w; subst s
  all_goals simp only [Contains] at hit
  all_goals simp only [Cross.mk.injEq, and_true, true_and]; omega

theorem beside_horizontal {a b c : Int} (ha : 2≤a) (hb : 1≤b) (hc : 2≤c)
    {t : Cross} (copy : Copy a b c 0 t) (bound : 0≤t.x-t.west ∧ 0≤t.y-t.south)
    (hit : Contains t 0 1) (sep : Apart t ⟨c,0,a,b,c,0⟩) :
    t=⟨0,1+c,b,a,0,c⟩ ∨ t=⟨0,1+a,b,c,0,a⟩ := by
  rcases t with ⟨x,y,e,n,w,s⟩
  rcases copy with h | h | h | h | h | h | h | h
  all_goals rcases h with ⟨he,hn,hw,hs⟩
  all_goals dsimp only at he hn hw hs bound hit sep
  all_goals subst e; subst n; subst w; subst s
  all_goals simp only [Contains] at hit
  all_goals simp only [Apart] at sep
  all_goals simp only [Cross.mk.injEq, and_true, true_and]; omega

theorem blocked_diagonal {a b c : Int} (ha : 2≤a) (hb : 1≤b) (hc : 2≤c)
    {t : Cross} (copy : Copy a b c 0 t) (bound : 0≤t.x-t.west ∧ 0≤t.y-t.south)
    (hit : Contains t 1 1) (sep : Apart t ⟨c,0,a,b,c,0⟩)
    (sep2 : Apart t ⟨0,1+c,b,a,0,c⟩ ∨ Apart t ⟨0,1+a,b,c,0,a⟩) : False := by
  rcases t with ⟨x,y,e,n,w,s⟩
  rcases copy with h | h | h | h | h | h | h | h
  all_goals rcases h with ⟨he,hn,hw,hs⟩
  all_goals dsimp only at he hn hw hs bound hit sep sep2
  all_goals subst e; subst n; subst w; subst s
  all_goals simp only [Contains] at hit
  all_goals simp only [Apart] at sep sep2
  all_goals omega

theorem copy_swap {a b c : Int} {t : Cross} (h : Copy a b c 0 t) : Copy c b a 0 t := by
  rcases h with h | h | h | h | h | h | h | h
  all_goals rcases h with ⟨he,hn,hw,hs⟩
  all_goals simp [Copy, Arms, he, hn, hw, hs]

def swapArms {a b c : Int} {R : Region} (T : Tiling a b c 0 R) : Tiling c b a 0 R where
  world := T.world
  copies t ht := copy_swap (T.copies t ht)
  inside := T.inside
  cover := T.cover
  disjoint := T.disjoint

theorem no_horizontal_anchor {a b c : Int} (ha : 2≤a) (hb : 1≤b) (hc : 2≤c)
    (T : Tiling a b c 0 Quadrant) (anchor : T.world ⟨c,0,a,b,c,0⟩) : False := by
  obtain ⟨u,hu,hit⟩ := T.cover 0 1 (by constructor <;> omega)
  have ap := separate (by omega) (by omega) (by omega) T hu anchor hit
    (by simp only [Contains]; dsimp; omega)
  have forms := beside_horizontal ha hb hc (T.copies u hu)
    (quadrant_bounds (by omega) (by omega) (by omega) T hu) hit ap
  obtain ⟨v,hv,hitv⟩ := T.cover 1 1 (by constructor <;> omega)
  have apv := separate (by omega) (by omega) (by omega) T hv anchor hitv
    (by simp only [Contains]; dsimp; omega)
  have apu : Apart v u := separate (by omega) (by omega) (by omega) T hv hu hitv (by
    rcases forms with rfl | rfl <;> simp only [Contains] <;> dsimp <;> omega)
  apply blocked_diagonal ha hb hc (T.copies v hv)
    (quadrant_bounds (by omega) (by omega) (by omega) T hv) hitv apv
  rcases forms with rfl | rfl
  · exact Or.inl apu
  · exact Or.inr apu

/-- If both sides of the T crossbar contain at least two cells beyond the
junction, the three cells at a quadrant corner force a contradiction. -/
theorem no_quadrant {a b c : Int} (ha : 2≤a) (hb : 1≤b) (hc : 2≤c) :
    ¬Tiles a b c 0 Quadrant := by
  rintro ⟨T⟩
  obtain ⟨t,ht,hit⟩ := T.cover 0 0 (by constructor <;> omega)
  have forms := corner_forms (by omega : 1≤a) hb (by omega : 1≤c) (T.copies t ht)
    (quadrant_bounds (by omega) (by omega) (by omega) T ht) hit
  rcases forms with rfl | rfl | rfl | rfl
  · exact no_horizontal_anchor ha hb hc T ht
  · exact no_horizontal_anchor hc hb ha (swapArms T) ht
  · let U : Tiling a b c 0 Quadrant := T.transpose.congr (by intro x y; unfold Quadrant; omega)
    have hU : U.world ⟨c,0,a,b,c,0⟩ := ⟨_,ht,rfl⟩
    exact no_horizontal_anchor ha hb hc U hU
  · let U : Tiling a b c 0 Quadrant := T.transpose.congr (by intro x y; unfold Quadrant; omega)
    have hU : U.world ⟨a,0,c,b,a,0⟩ := ⟨_,ht,rfl⟩
    exact no_horizontal_anchor hc hb ha (swapArms U) hU

#print axioms no_quadrant
end PolyominoFormal.TBoundary

import LQuadrantHpOptimizedUnequalNestedShortBfiveDeltaTwoPrunedArithmeticDefs
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace LRegionArithmetic

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n193_run_four (a b : Int)
    (h0 : (¬ ((-1 : Int) ≤ (1 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n193_run_short (a b : Int)
    (h0 : (¬ (((1 : Int) - (-1 : Int)) < b)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n193_run_nonnegative (a b : Int)
    (h0 : (¬ (((-2 : Int) + ((-1 : Int) * a)) ≤ (0 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n193_run_left (a b : Int)
    (h0 : (¬ ((((((0 : Int) - (0 : Int)) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((0 : Int) ≤ ((-1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((-1 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((1 : Int) ≤ ((-1 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((-1 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((1 : Int) + b + a) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) + a) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-1 : Int) ≤ ((-1 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((-1 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-2 : Int) ≤ ((-1 : Int) - (1 : Int))) ∧ ((-2 : Int) ≥ ((-1 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a)))) ∨ (((((2 : Int) - b) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a))) ∨ (((2 : Int) ≤ ((-1 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((-1 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + a) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n193_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5814 a b) ∨ (fact_9fdb227ae99d_5816 a b) ∨ (fact_9fdb227ae99d_6674 a b) ∨ (fact_9fdb227ae99d_6999 a b) ∨ (fact_9fdb227ae99d_6339 a b) ∨ (((((-1 : Int) - b) ≤ ((1 : Int) + (1 : Int))) ∧ (((1 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-1 : Int) ≤ ((1 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((1 : Int) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ ((1 : Int) + (1 : Int))) ∧ (((1 : Int) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-2 : Int) ≤ ((1 : Int) + (1 : Int))) ∧ ((-2 : Int) ≥ ((1 : Int) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_6358 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n193_run_tall (a b : Int)
    (h0 : (¬ ((((1 : Int) ≥ ((-1 : Int) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7551 a b) ∨ (fact_9fdb227ae99d_7534 a b))) ∨ (((1 : Int) ≥ ((-1 : Int) + (2 : Int))) ∧ (fact_9fdb227ae99d_7551 a b) ∧ (fact_9fdb227ae99d_7534 a b)) ∨ ((1 : Int) ≥ ((-1 : Int) + (4 : Int))) ∨ (((1 : Int) = ((-1 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7551 a b) ∧ (fact_9fdb227ae99d_7534 a b) ∧ (((fact_9fdb227ae99d_6438 a b) ∨ (fact_9fdb227ae99d_6452 a b) ∨ (fact_9fdb227ae99d_6948 a b) ∨ (fact_9fdb227ae99d_7126 a b) ∨ (fact_9fdb227ae99d_6844 a b) ∨ (((((-1 : Int) - b) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((1 : Int) ≥ (-(((-2 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((-1 : Int) ≤ ((-1 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((-1 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) + a)) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_6517 a b) ∨ (fact_9fdb227ae99d_6869 a b)) ∨ ((fact_9fdb227ae99d_6342 a b) ∨ (fact_9fdb227ae99d_6348 a b) ∨ (fact_9fdb227ae99d_6917 a b) ∨ (fact_9fdb227ae99d_7121 a b) ∨ (fact_9fdb227ae99d_6787 a b) ∨ (((((-1 : Int) - b) ≤ ((1 : Int) + (1 : Int))) ∧ (((1 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((1 : Int) ≥ (-(((-2 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((-1 : Int) ≤ ((1 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((1 : Int) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) + a)) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_6427 a b) ∨ (fact_9fdb227ae99d_6796 a b)))) ∨ ((fact_9fdb227ae99d_7551 a b) ∧ (fact_9fdb227ae99d_7534 a b) ∧ ((fact_9fdb227ae99d_6438 a b) ∨ (fact_9fdb227ae99d_6452 a b) ∨ (fact_9fdb227ae99d_6948 a b) ∨ (fact_9fdb227ae99d_7126 a b) ∨ (fact_9fdb227ae99d_6844 a b) ∨ (((((-1 : Int) - b) ≤ ((-1 : Int) - (1 : Int))) ∧ (((-1 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((1 : Int) ≥ (-(((-2 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((-1 : Int) ≤ ((-1 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((-1 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) + a)) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_6517 a b) ∨ (fact_9fdb227ae99d_6869 a b)) ∧ ((fact_9fdb227ae99d_6342 a b) ∨ (fact_9fdb227ae99d_6348 a b) ∨ (fact_9fdb227ae99d_6917 a b) ∨ (fact_9fdb227ae99d_7121 a b) ∨ (fact_9fdb227ae99d_6787 a b) ∨ (((((-1 : Int) - b) ≤ ((1 : Int) + (1 : Int))) ∧ (((1 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((1 : Int) ≥ (-(((-2 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((-1 : Int) ≤ ((1 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((1 : Int) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) + a)) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_6427 a b) ∨ (fact_9fdb227ae99d_6796 a b))))))
    (h1 : (a > b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n193_run_empty (a b run_x : Int)
    (h0 : (a > b))
    (h1 : (a ≥ b))
    (h2 : ((fact_9fdb227ae99d_4083 a b run_x) ∨ (fact_9fdb227ae99d_4111 a b run_x) ∨ (fact_9fdb227ae99d_5317 a b run_x) ∨ (fact_9fdb227ae99d_5932 a b run_x) ∨ (fact_9fdb227ae99d_4746 a b run_x) ∨ (((((-1 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-1 : Int) ≤ run_x) ∧ ((-1 : Int) ≥ run_x) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-2 : Int) ≤ run_x) ∧ ((-2 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_4997 a b run_x)))
    (h3 : ((-1 : Int) ≤ run_x))
    (h4 : ((1 : Int) ≥ run_x))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n193_run_floor (a b run_x : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_5622 a b run_x) ∨ (fact_9fdb227ae99d_5624 a b run_x) ∨ (fact_9fdb227ae99d_6337 a b run_x) ∨ (fact_9fdb227ae99d_6922 a b run_x) ∨ (fact_9fdb227ae99d_5934 a b run_x) ∨ (((((-1 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((1 : Int) ≥ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))))) ∨ (((-1 : Int) ≤ run_x) ∧ ((-1 : Int) ≥ run_x) ∧ (((1 : Int) - (0 : Int)) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((2 : Int) ≥ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))))) ∨ (((-2 : Int) ≤ run_x) ∧ ((-2 : Int) ≥ run_x) ∧ (((2 : Int) - (0 : Int)) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_5956 a b run_x))))
    (h2 : ((-1 : Int) ≤ run_x))
    (h3 : ((1 : Int) ≥ run_x))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n194_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (¬ (((-3 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((-3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n194_empty (a b : Int)
    (h0 : (((((2 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((fact_9fdb227ae99d_2870 a b) ∨ (fact_9fdb227ae99d_2872 a b) ∨ (fact_9fdb227ae99d_3262 a b) ∨ (fact_9fdb227ae99d_4169 a b) ∨ (fact_9fdb227ae99d_3101 a b) ∨ ((((-3 : Int) ≥ ((-1 : Int) - b)) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((-2 : Int) - b)) ∧ ((-3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-2 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_2873 a b)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n194_o0 (a b jx jy : Int)
    (h0 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h1 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h2 : (¬ (((jx = ((-3 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n194_o1 (a b jx jy : Int)
    (h0 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n194_o2 (a b jx jy : Int)
    (h0 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h1 : (¬ ((((-3 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h2 : (b = (5 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n194_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h7 : (¬ ((((-3 : Int) = jx) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n194_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (¬ ((((-3 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n194_o5 (a b jx jy : Int)
    (h0 : (¬ ((((-3 : Int) = jx) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h7 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h8 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n194_o6 (a b jx jy : Int)
    (h0 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h1 : (b = (5 : Int)))
    (h2 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (¬ (((jx = ((-3 : Int) + ((-1 : Int) * b))) ∧ ((3 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n194_o7 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n195_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (¬ (((-1 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((0 : Int) ≥ (0 : Int)) ∧ ((-1 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((0 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n195_empty (a b : Int)
    (h0 : (((0 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((0 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + a)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int)))))
    (h1 : ((fact_9fdb227ae99d_2857 a b) ∨ (fact_9fdb227ae99d_2859 a b) ∨ (fact_9fdb227ae99d_3257 a b) ∨ (fact_9fdb227ae99d_4158 a b) ∨ (fact_9fdb227ae99d_3085 a b) ∨ (fact_9fdb227ae99d_2951 a b) ∨ (fact_9fdb227ae99d_2952 a b) ∨ (fact_9fdb227ae99d_2861 a b) ∨ ((((-1 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((-1 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (3 : Int))) ∨ (((-1 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) + b))))))
    (h2 : (((-1 : Int) > ((1 : Int) + b + a)) ∨ ((-1 : Int) < ((1 : Int) + b + a)) ∨ (((0 : Int) + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < ((0 : Int) - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n195_o0 (a b jx jy : Int)
    (h0 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h1 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (b = (5 : Int)))
    (h8 : ((jx < (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n195_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b = (5 : Int)))
    (h6 : (fact_9fdb227ae99d_2923 a b jy))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n195_o2 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_2924 a b jy))
    (h3 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n195_o3 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b = (5 : Int)))
    (h2 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n195_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_2922 a b jy))
    (h4 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n195_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h7 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n195_o6 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n195_o7 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_2925 a b jy))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n196_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≤ a)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n196_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((a - (3 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n196_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n196_run_left (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((((((0 : Int) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (-(4 : Int))) ∧ ((0 : Int) ≥ (-(4 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((1 : Int) ≤ (-(4 : Int))) ∧ ((1 : Int) ≥ (-(4 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((2 : Int) + a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-(4 : Int))) ∧ ((-1 : Int) ≥ (-(4 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-2 : Int) ≤ (-(4 : Int))) ∧ ((-2 : Int) ≥ (-(4 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((2 : Int) ≤ (-(4 : Int))) ∧ ((2 : Int) ≥ (-(4 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (((((-3 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ (-(4 : Int))) ∧ ((-3 : Int) ≥ (-(4 : Int))) ∧ ((((3 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n196_run_right (a b : Int)
    (h0 : (¬ ((((((0 : Int) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (a + (1 : Int))) ∧ ((0 : Int) ≥ (a + (1 : Int)))) ∨ (((0 : Int) ≤ (-(4 : Int))) ∧ ((0 : Int) ≥ (-(4 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ (((1 : Int) ≤ (-(4 : Int))) ∧ ((1 : Int) ≥ (-(4 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (a + (1 : Int))) ∧ ((0 : Int) ≥ (a + (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ ((((2 : Int) + a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ (((-1 : Int) ≤ (-(4 : Int))) ∧ ((-1 : Int) ≥ (-(4 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ (((-2 : Int) ≤ (-(4 : Int))) ∧ ((-2 : Int) ≥ (-(4 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ (a + (1 : Int))) ∧ ((3 : Int) ≥ (a + (1 : Int)))) ∨ (((2 : Int) ≤ (-(4 : Int))) ∧ ((2 : Int) ≥ (-(4 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (((((-3 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ (-(4 : Int))) ∧ ((-3 : Int) ≥ (-(4 : Int))) ∧ ((((3 : Int) + b) - b) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n196_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_9fdb227ae99d_7405 a b) ∨ (fact_9fdb227ae99d_7339 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_9fdb227ae99d_7405 a b) ∧ (fact_9fdb227ae99d_7339 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7405 a b) ∧ (fact_9fdb227ae99d_7339 a b) ∧ (((fact_9fdb227ae99d_4346 a b) ∨ (fact_9fdb227ae99d_4363 a b) ∨ (fact_9fdb227ae99d_5456 a b) ∨ (fact_9fdb227ae99d_6179 a b) ∨ (fact_9fdb227ae99d_5114 a b) ∨ (((((-1 : Int) - b) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_4455 a b) ∨ (fact_9fdb227ae99d_4375 a b) ∨ (fact_9fdb227ae99d_5231 a b)) ∨ ((fact_9fdb227ae99d_3420 a b) ∨ (fact_9fdb227ae99d_3438 a b) ∨ (fact_9fdb227ae99d_4513 a b) ∨ (fact_9fdb227ae99d_5597 a b) ∨ (fact_9fdb227ae99d_3885 a b) ∨ (((((-1 : Int) - b) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_3528 a b) ∨ (fact_9fdb227ae99d_3450 a b) ∨ (fact_9fdb227ae99d_4292 a b)))) ∨ ((fact_9fdb227ae99d_7405 a b) ∧ (fact_9fdb227ae99d_7339 a b) ∧ ((fact_9fdb227ae99d_4346 a b) ∨ (fact_9fdb227ae99d_4363 a b) ∨ (fact_9fdb227ae99d_5456 a b) ∨ (fact_9fdb227ae99d_6179 a b) ∨ (fact_9fdb227ae99d_5114 a b) ∨ (((((-1 : Int) - b) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_4455 a b) ∨ (fact_9fdb227ae99d_4375 a b) ∨ (fact_9fdb227ae99d_5231 a b)) ∧ ((fact_9fdb227ae99d_3420 a b) ∨ (fact_9fdb227ae99d_3438 a b) ∨ (fact_9fdb227ae99d_4513 a b) ∨ (fact_9fdb227ae99d_5597 a b) ∨ (fact_9fdb227ae99d_3885 a b) ∨ (((((-1 : Int) - b) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_3528 a b) ∨ (fact_9fdb227ae99d_3450 a b) ∨ (fact_9fdb227ae99d_4292 a b))))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n196_run_empty (a b run_x : Int)
    (h0 : (((((2 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((3 : Int) ≤ run_x))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((fact_9fdb227ae99d_2588 a b run_x) ∨ (fact_9fdb227ae99d_2593 a b run_x) ∨ (fact_9fdb227ae99d_3154 a b run_x) ∨ (fact_9fdb227ae99d_3674 a b run_x) ∨ (fact_9fdb227ae99d_3032 a b run_x) ∨ (((((-1 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ (-(4 : Int))) ∧ ((-1 : Int) ≥ (-(4 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ (-(4 : Int))) ∧ ((-2 : Int) ≥ (-(4 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((2 : Int) ≤ (-(4 : Int))) ∧ ((2 : Int) ≥ (-(4 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (((((-3 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ (-(4 : Int))) ∧ ((-3 : Int) ≥ (-(4 : Int))) ∧ ((((3 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + (0 : Int)))))))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (run_x ≤ a))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n196_run_floor (a b run_x : Int)
    (h0 : ((3 : Int) ≤ run_x))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (run_x ≤ a))
    (h3 : (¬ ((fact_9fdb227ae99d_3321 a b run_x) ∨ (fact_9fdb227ae99d_3325 a b run_x) ∨ (fact_9fdb227ae99d_4336 a b run_x) ∨ (fact_9fdb227ae99d_5470 a b run_x) ∨ (fact_9fdb227ae99d_3678 a b run_x) ∨ (((((-1 : Int) - b) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-((4 : Int) - (1 : Int))) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-1 : Int) ≥ (-((4 : Int) - (1 : Int)))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-((4 : Int) - (1 : Int))) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-2 : Int) ≥ (-((4 : Int) - (1 : Int)))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-((4 : Int) - (1 : Int))) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((2 : Int) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((2 : Int) ≥ (-((4 : Int) - (1 : Int)))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (((((-3 : Int) - a) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-((4 : Int) - (1 : Int))) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-3 : Int) ≥ (-((4 : Int) - (1 : Int)))) ∧ ((((3 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n197_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ (((-1 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((0 : Int) ≥ (0 : Int)) ∧ ((-1 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((0 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n197_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((fact_9fdb227ae99d_2857 a b) ∨ (fact_9fdb227ae99d_2859 a b) ∨ (fact_9fdb227ae99d_3257 a b) ∨ (fact_9fdb227ae99d_4158 a b) ∨ (fact_9fdb227ae99d_3085 a b) ∨ (fact_9fdb227ae99d_2951 a b) ∨ (fact_9fdb227ae99d_2952 a b) ∨ (fact_9fdb227ae99d_2861 a b) ∨ ((((-1 : Int) ≥ ((-3 : Int) - b)) ∧ ((-1 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (3 : Int))) ∨ (((-3 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-3 : Int)) ∧ ((0 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) + a))))))
    (h2 : (((-1 : Int) > ((1 : Int) + b + a)) ∨ ((-1 : Int) < ((1 : Int) + b + a)) ∨ (((0 : Int) + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < ((0 : Int) - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n197_o0 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h1 : ((jx < ((-3 : Int) - b)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h2 : (b = (5 : Int)))
    (h3 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a > b))
    (h9 : (a ≥ (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n197_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b = (5 : Int)))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (fact_9fdb227ae99d_2923 a b jy))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n197_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_2924 a b jy))
    (h3 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n197_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h5 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n197_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_2922 a b jy))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n197_o5 (a b jx jy : Int)
    (h0 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((jx + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jx - a)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h6 : (b = (5 : Int)))
    (h7 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n197_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n197_o7 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_2925 a b jy))
    (h3 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n198_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (¬ (((-4 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((-4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n198_empty (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((fact_9fdb227ae99d_2875 a b) ∨ (fact_9fdb227ae99d_2878 a b) ∨ (fact_9fdb227ae99d_3264 a b) ∨ (fact_9fdb227ae99d_4171 a b) ∨ (fact_9fdb227ae99d_3106 a b) ∨ ((((-4 : Int) ≥ ((-1 : Int) - b)) ∧ ((-4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)))) ∨ ((((-4 : Int) ≥ ((-2 : Int) - b)) ∧ ((-4 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-2 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-2 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_2881 a b) ∨ (fact_9fdb227ae99d_3151 a b)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (((((2 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n198_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h3 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h4 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (¬ (((jx = ((-4 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n198_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (((-3 : Int) > (jx + b)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h3 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n198_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h2 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b = (5 : Int)))
    (h4 : (¬ ((((-4 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n198_o3 (a b jx jy : Int)
    (h0 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h5 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h6 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h7 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h8 : (b = (5 : Int)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h11 : ((jx < ((-3 : Int) - b)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    (h14 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n198_o4 (a b jx jy : Int)
    (h0 : ((jx < ((-3 : Int) - b)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - a))))
    (h1 : (b = (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n198_o5 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : (¬ ((((-4 : Int) = jx) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : (b = (5 : Int)))
    (h7 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n198_o6 (a b jx jy : Int)
    (h0 : (¬ (((jx = ((-4 : Int) + ((-1 : Int) * b))) ∧ ((3 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h4 : (b = (5 : Int)))
    (h5 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h6 : (((-3 : Int) > (jx + b)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n198_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n199_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (¬ (((-1 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((0 : Int) ≥ (0 : Int)) ∧ ((-1 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((0 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n199_empty (a b : Int)
    (h0 : (((-1 : Int) > ((1 : Int) + b + a)) ∨ ((-1 : Int) < ((1 : Int) + b + a)) ∨ (((0 : Int) + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < ((0 : Int) - (0 : Int)))))
    (h1 : ((fact_9fdb227ae99d_2857 a b) ∨ (fact_9fdb227ae99d_2859 a b) ∨ (fact_9fdb227ae99d_3257 a b) ∨ (fact_9fdb227ae99d_4158 a b) ∨ (fact_9fdb227ae99d_3085 a b) ∨ (fact_9fdb227ae99d_2951 a b) ∨ (fact_9fdb227ae99d_2952 a b) ∨ (fact_9fdb227ae99d_2861 a b) ∨ ((((-1 : Int) ≥ ((-3 : Int) - b)) ∧ ((-1 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) + a)) ∧ ((0 : Int) ≤ ((3 : Int) + a))) ∨ (((-3 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-3 : Int)) ∧ ((0 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((0 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((-1 : Int) ≥ (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((-1 : Int) ≤ (((-4 : Int) + ((-1 : Int) * a)) + a)) ∧ ((3 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (3 : Int))) ∨ (((-1 : Int) ≥ ((-4 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≤ ((-4 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) + b))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n199_o0 (a b jx jy : Int)
    (h0 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n199_o1 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_2923 a b jy))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n199_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_2924 a b jy))
    (h3 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n199_o3 (a b jx jy : Int)
    (h0 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h1 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n199_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_2922 a b jy))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (b = (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n199_o5 (a b jx jy : Int)
    (h0 : ((jx < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h9 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n199_o6 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n199_o7 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_2925 a b jy))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n200_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≤ a)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n200_run_short (a b : Int)
    (h0 : (¬ ((a - (3 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n200_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n200_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3584 a b) ∨ (fact_9fdb227ae99d_3588 a b) ∨ (fact_9fdb227ae99d_4721 a b) ∨ (fact_9fdb227ae99d_5751 a b) ∨ (fact_9fdb227ae99d_4340 a b) ∨ (((((-1 : Int) - b) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-(5 : Int))) ∧ ((-1 : Int) ≥ (-(5 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-2 : Int) ≤ (-(5 : Int))) ∧ ((-2 : Int) ≥ (-(5 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3590 a b) ∨ (((((-3 : Int) - b) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((-3 : Int) ≤ (-(5 : Int))) ∧ ((-3 : Int) ≥ (-(5 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_4485 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n200_run_right (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ ((fact_9fdb227ae99d_3157 a b) ∨ (fact_9fdb227ae99d_3161 a b) ∨ (fact_9fdb227ae99d_3671 a b) ∨ (fact_9fdb227ae99d_5108 a b) ∨ (fact_9fdb227ae99d_3389 a b) ∨ (((((-1 : Int) - b) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ (((-1 : Int) ≤ (-(5 : Int))) ∧ ((-1 : Int) ≥ (-(5 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ (((-2 : Int) ≤ (-(5 : Int))) ∧ ((-2 : Int) ≥ (-(5 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3162 a b) ∨ (((((-3 : Int) - b) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((-3 : Int) ≤ (-(5 : Int))) ∧ ((-3 : Int) ≥ (-(5 : Int))) ∧ ((((3 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3548 a b))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n200_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_9fdb227ae99d_7550 a b) ∨ (fact_9fdb227ae99d_7415 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_9fdb227ae99d_7550 a b) ∧ (fact_9fdb227ae99d_7415 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7550 a b) ∧ (fact_9fdb227ae99d_7415 a b) ∧ (((fact_9fdb227ae99d_4351 a b) ∨ (fact_9fdb227ae99d_4368 a b) ∨ (fact_9fdb227ae99d_5461 a b) ∨ (fact_9fdb227ae99d_6184 a b) ∨ (fact_9fdb227ae99d_5119 a b) ∨ (((((-1 : Int) - b) ≤ (-((5 : Int) + a))) ∧ ((-((5 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-((5 : Int) + a))) ∧ ((-1 : Int) ≥ (-((5 : Int) + a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_4460 a b) ∨ (fact_9fdb227ae99d_4378 a b) ∨ (fact_9fdb227ae99d_5240 a b) ∨ (fact_9fdb227ae99d_5250 a b)) ∨ ((fact_9fdb227ae99d_3424 a b) ∨ (fact_9fdb227ae99d_3442 a b) ∨ (fact_9fdb227ae99d_4517 a b) ∨ (fact_9fdb227ae99d_5601 a b) ∨ (fact_9fdb227ae99d_3889 a b) ∨ (((((-1 : Int) - b) ≤ (-((5 : Int) + a))) ∧ ((-((5 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ (((-1 : Int) ≤ (-((5 : Int) + a))) ∧ ((-1 : Int) ≥ (-((5 : Int) + a))) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_3531 a b) ∨ (fact_9fdb227ae99d_3452 a b) ∨ (fact_9fdb227ae99d_4303 a b) ∨ (fact_9fdb227ae99d_4306 a b)))) ∨ ((fact_9fdb227ae99d_7550 a b) ∧ (fact_9fdb227ae99d_7415 a b) ∧ ((fact_9fdb227ae99d_4351 a b) ∨ (fact_9fdb227ae99d_4368 a b) ∨ (fact_9fdb227ae99d_5461 a b) ∨ (fact_9fdb227ae99d_6184 a b) ∨ (fact_9fdb227ae99d_5119 a b) ∨ (((((-1 : Int) - b) ≤ (-((5 : Int) + a))) ∧ ((-((5 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-((5 : Int) + a))) ∧ ((-1 : Int) ≥ (-((5 : Int) + a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_4460 a b) ∨ (fact_9fdb227ae99d_4378 a b) ∨ (fact_9fdb227ae99d_5240 a b) ∨ (fact_9fdb227ae99d_5250 a b)) ∧ ((fact_9fdb227ae99d_3424 a b) ∨ (fact_9fdb227ae99d_3442 a b) ∨ (fact_9fdb227ae99d_4517 a b) ∨ (fact_9fdb227ae99d_5601 a b) ∨ (fact_9fdb227ae99d_3889 a b) ∨ (((((-1 : Int) - b) ≤ (-((5 : Int) + a))) ∧ ((-((5 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ (((-1 : Int) ≤ (-((5 : Int) + a))) ∧ ((-1 : Int) ≥ (-((5 : Int) + a))) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_3531 a b) ∨ (fact_9fdb227ae99d_3452 a b) ∨ (fact_9fdb227ae99d_4303 a b) ∨ (fact_9fdb227ae99d_4306 a b))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n200_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((3 : Int) ≤ run_x))
    (h2 : (b = (5 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : ((fact_9fdb227ae99d_2589 a b run_x) ∨ (fact_9fdb227ae99d_2594 a b run_x) ∨ (fact_9fdb227ae99d_3155 a b run_x) ∨ (fact_9fdb227ae99d_3675 a b run_x) ∨ (fact_9fdb227ae99d_3033 a b run_x) ∨ (((((-1 : Int) - b) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ (-(5 : Int))) ∧ ((-1 : Int) ≥ (-(5 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ (-(5 : Int))) ∧ ((-2 : Int) ≥ (-(5 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_2633 a b run_x) ∨ (((((-3 : Int) - b) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a))) ∨ (((-3 : Int) ≤ (-(5 : Int))) ∧ ((-3 : Int) ≥ (-(5 : Int))) ∧ ((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3047 a b run_x)))
    (h5 : (run_x ≤ a))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (((((2 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n200_run_floor (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((fact_9fdb227ae99d_3322 a b run_x) ∨ (fact_9fdb227ae99d_3326 a b run_x) ∨ (fact_9fdb227ae99d_4337 a b run_x) ∨ (fact_9fdb227ae99d_5471 a b run_x) ∨ (fact_9fdb227ae99d_3679 a b run_x) ∨ (((((-1 : Int) - b) ≤ (-((5 : Int) - (1 : Int)))) ∧ ((-((5 : Int) - (1 : Int))) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ (-((5 : Int) - (1 : Int)))) ∧ ((-1 : Int) ≥ (-((5 : Int) - (1 : Int)))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-((5 : Int) - (1 : Int)))) ∧ ((-((5 : Int) - (1 : Int))) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ (-((5 : Int) - (1 : Int)))) ∧ ((-2 : Int) ≥ (-((5 : Int) - (1 : Int)))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3328 a b run_x) ∨ (((((-3 : Int) - b) ≤ (-((5 : Int) - (1 : Int)))) ∧ ((-((5 : Int) - (1 : Int))) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a))) ∨ (((-3 : Int) ≤ (-((5 : Int) - (1 : Int)))) ∧ ((-3 : Int) ≥ (-((5 : Int) - (1 : Int)))) ∧ ((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3747 a b run_x))))
    (h2 : ((3 : Int) ≤ run_x))
    (h3 : (run_x ≤ a))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n201_point (a b : Int)
    (h0 : (¬ (((-1 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((0 : Int) ≥ (0 : Int)) ∧ ((-1 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((0 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n201_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_2857 a b) ∨ (fact_9fdb227ae99d_2859 a b) ∨ (fact_9fdb227ae99d_3257 a b) ∨ (fact_9fdb227ae99d_4158 a b) ∨ (fact_9fdb227ae99d_3085 a b) ∨ (fact_9fdb227ae99d_2951 a b) ∨ (fact_9fdb227ae99d_2952 a b) ∨ (fact_9fdb227ae99d_2861 a b) ∨ ((((-1 : Int) ≥ ((-3 : Int) - b)) ∧ ((-1 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) + a)) ∧ ((0 : Int) ≤ ((3 : Int) + a))) ∨ (((-3 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-3 : Int)) ∧ ((0 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((0 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((-1 : Int) ≥ ((-4 : Int) - a)) ∧ ((-1 : Int) ≤ ((-4 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (3 : Int))) ∨ (((-4 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-4 : Int)) ∧ ((0 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) + b))))))
    (h1 : (((0 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((0 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + a)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((-1 : Int) > ((1 : Int) + b + a)) ∨ ((-1 : Int) < ((1 : Int) + b + a)) ∨ (((0 : Int) + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < ((0 : Int) - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n201_o0 (a b jx jy : Int)
    (h0 : ((jx < ((-4 : Int) - a)) ∨ (((-4 : Int) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : (((jx + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h2 : (b = (5 : Int)))
    (h3 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n201_o1 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_2923 a b jy))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n201_o2 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_2924 a b jy))
    (h2 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n201_o3 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h1 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n201_o4 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (fact_9fdb227ae99d_2922 a b jy))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n201_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h4 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h7 : ((jx < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h8 : (b = (5 : Int)))
    (h9 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n201_o6 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n201_o7 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (fact_9fdb227ae99d_2925 a b jy))
    (h2 : (b = (5 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n202_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((-4 : Int) ≥ ((-3 : Int) + ((-1 : Int) * b)))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n202_run_short (a b : Int)
    (h0 : (¬ (((-4 : Int) - ((-3 : Int) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n202_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n202_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5687 a b) ∨ (fact_9fdb227ae99d_5700 a b) ∨ (fact_9fdb227ae99d_6368 a b) ∨ (fact_9fdb227ae99d_6964 a b) ∨ (fact_9fdb227ae99d_5994 a b) ∨ (((((-1 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-1 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-2 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_5707 a b) ∨ (((((-3 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((-3 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6986 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n202_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3416 a b) ∨ (fact_9fdb227ae99d_3434 a b) ∨ (fact_9fdb227ae99d_4509 a b) ∨ (fact_9fdb227ae99d_5593 a b) ∨ (fact_9fdb227ae99d_3881 a b) ∨ (((((-1 : Int) - b) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-1 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-2 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-2 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3448 a b) ∨ (fact_9fdb227ae99d_4301 a b) ∨ (fact_9fdb227ae99d_5729 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n202_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ ((((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7789 a b) ∨ (fact_9fdb227ae99d_7533 a b))) ∨ (((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (2 : Int))) ∧ (fact_9fdb227ae99d_7789 a b) ∧ (fact_9fdb227ae99d_7533 a b)) ∨ ((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (4 : Int))) ∨ (((-4 : Int) = (((-3 : Int) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_9fdb227ae99d_7789 a b) ∧ (fact_9fdb227ae99d_7533 a b) ∧ (((fact_9fdb227ae99d_6035 a b) ∨ (fact_9fdb227ae99d_6073 a b) ∨ (fact_9fdb227ae99d_6835 a b) ∨ (fact_9fdb227ae99d_7047 a b) ∨ (fact_9fdb227ae99d_6601 a b) ∨ (((((-1 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + a)) ∧ ((1 : Int) ≥ ((4 : Int) + a))) ∨ (((-1 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((-2 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_6097 a b) ∨ (fact_9fdb227ae99d_6730 a b) ∨ (fact_9fdb227ae99d_7111 a b)) ∨ ((fact_9fdb227ae99d_4075 a b) ∨ (fact_9fdb227ae99d_4103 a b) ∨ (fact_9fdb227ae99d_5309 a b) ∨ (fact_9fdb227ae99d_5924 a b) ∨ (fact_9fdb227ae99d_4738 a b) ∨ (((((-1 : Int) - b) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + a)) ∧ ((1 : Int) ≥ ((4 : Int) + a))) ∨ (((-1 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_4270 a b) ∨ (fact_9fdb227ae99d_4117 a b) ∨ (fact_9fdb227ae99d_5090 a b) ∨ (fact_9fdb227ae99d_6168 a b)))) ∨ ((fact_9fdb227ae99d_7789 a b) ∧ (fact_9fdb227ae99d_7533 a b) ∧ ((fact_9fdb227ae99d_6035 a b) ∨ (fact_9fdb227ae99d_6073 a b) ∨ (fact_9fdb227ae99d_6835 a b) ∨ (fact_9fdb227ae99d_7047 a b) ∨ (fact_9fdb227ae99d_6601 a b) ∨ (((((-1 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + a)) ∧ ((1 : Int) ≥ ((4 : Int) + a))) ∨ (((-1 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((-2 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_6097 a b) ∨ (fact_9fdb227ae99d_6730 a b) ∨ (fact_9fdb227ae99d_7111 a b)) ∧ ((fact_9fdb227ae99d_4075 a b) ∨ (fact_9fdb227ae99d_4103 a b) ∨ (fact_9fdb227ae99d_5309 a b) ∨ (fact_9fdb227ae99d_5924 a b) ∨ (fact_9fdb227ae99d_4738 a b) ∨ (((((-1 : Int) - b) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + a)) ∧ ((1 : Int) ≥ ((4 : Int) + a))) ∨ (((-1 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_4270 a b) ∨ (fact_9fdb227ae99d_4117 a b) ∨ (fact_9fdb227ae99d_5090 a b) ∨ (fact_9fdb227ae99d_6168 a b))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n202_run_empty (a b run_x : Int)
    (h0 : (((-3 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h1 : ((-4 : Int) ≥ run_x))
    (h2 : ((fact_9fdb227ae99d_2367 a b run_x) ∨ (fact_9fdb227ae99d_2384 a b run_x) ∨ (fact_9fdb227ae99d_3040 a b run_x) ∨ (fact_9fdb227ae99d_3481 a b run_x) ∨ (fact_9fdb227ae99d_2928 a b run_x) ∨ (fact_9fdb227ae99d_2468 a b run_x) ∨ (fact_9fdb227ae99d_2479 a b run_x) ∨ (fact_9fdb227ae99d_2398 a b run_x) ∨ (fact_9fdb227ae99d_3004 a b run_x) ∨ (fact_9fdb227ae99d_3616 a b run_x)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n202_run_floor (a b run_x : Int)
    (h0 : (((-3 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h1 : (¬ ((fact_9fdb227ae99d_3179 a b run_x) ∨ (fact_9fdb227ae99d_3189 a b run_x) ∨ (fact_9fdb227ae99d_3731 a b run_x) ∨ (fact_9fdb227ae99d_5196 a b run_x) ∨ (fact_9fdb227ae99d_3490 a b run_x) ∨ (fact_9fdb227ae99d_3224 a b run_x) ∨ (fact_9fdb227ae99d_3239 a b run_x) ∨ (fact_9fdb227ae99d_3197 a b run_x) ∨ (fact_9fdb227ae99d_3578 a b run_x) ∨ (fact_9fdb227ae99d_5363 a b run_x))))
    (h2 : ((-4 : Int) ≥ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n203_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ (((-1 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((0 : Int) ≥ (0 : Int)) ∧ ((-1 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((0 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n203_empty (a b : Int)
    (h0 : (((-1 : Int) > ((1 : Int) + b + a)) ∨ ((-1 : Int) < ((1 : Int) + b + a)) ∨ (((0 : Int) + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < ((0 : Int) - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((fact_9fdb227ae99d_2857 a b) ∨ (fact_9fdb227ae99d_2859 a b) ∨ (fact_9fdb227ae99d_3257 a b) ∨ (fact_9fdb227ae99d_4158 a b) ∨ (fact_9fdb227ae99d_3085 a b) ∨ (fact_9fdb227ae99d_2951 a b) ∨ (fact_9fdb227ae99d_2952 a b) ∨ (fact_9fdb227ae99d_2861 a b) ∨ ((((-1 : Int) ≥ ((-3 : Int) - a)) ∧ ((-1 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (3 : Int))) ∨ (((-3 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-3 : Int)) ∧ ((0 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) + b))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n203_o0 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((jx + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n203_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (fact_9fdb227ae99d_2923 a b jy))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n203_o2 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_2924 a b jy))
    (h1 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b = (5 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n203_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h2 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n203_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (fact_9fdb227ae99d_2922 a b jy))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n203_o5 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : (b = (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h8 : (((jx + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jx - a)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n203_o6 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n203_o7 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (fact_9fdb227ae99d_2925 a b jy))
    (h2 : (b = (5 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n204_run_four (a b : Int)
    (h0 : (¬ ((-3 : Int) ≥ ((-2 : Int) + ((-1 : Int) * b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n204_run_short (a b : Int)
    (h0 : (¬ (((-3 : Int) - ((-2 : Int) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n204_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n204_run_left (a b : Int)
    (h0 : (¬ ((((((0 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((0 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + b + a) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((1 : Int) + b + a)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ ((((2 : Int) + a) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((2 : Int) + a)) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ (((2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)))) ∨ ((((((-3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * b)) + b)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * b)) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * b))) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n204_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3414 a b) ∨ (fact_9fdb227ae99d_3432 a b) ∨ (fact_9fdb227ae99d_4507 a b) ∨ (fact_9fdb227ae99d_5591 a b) ∨ (fact_9fdb227ae99d_3879 a b) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-1 : Int) ≤ ((-3 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-3 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-2 : Int) ≤ ((-3 : Int) + (1 : Int))) ∧ ((-2 : Int) ≥ ((-3 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3446 a b) ∨ (fact_9fdb227ae99d_5725 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n204_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ ((((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7667 a b) ∨ (fact_9fdb227ae99d_7400 a b))) ∨ (((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) + (2 : Int))) ∧ (fact_9fdb227ae99d_7667 a b) ∧ (fact_9fdb227ae99d_7400 a b)) ∨ ((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) + (4 : Int))) ∨ (((-3 : Int) = (((-2 : Int) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_9fdb227ae99d_7667 a b) ∧ (fact_9fdb227ae99d_7400 a b) ∧ (((fact_9fdb227ae99d_6027 a b) ∨ (fact_9fdb227ae99d_6065 a b) ∨ (fact_9fdb227ae99d_6827 a b) ∨ (fact_9fdb227ae99d_7039 a b) ∨ (fact_9fdb227ae99d_6593 a b) ∨ (((((-1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + a)) ∧ ((1 : Int) ≥ ((4 : Int) + a))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_6271 a b) ∨ (fact_9fdb227ae99d_6089 a b) ∨ (fact_9fdb227ae99d_7090 a b)) ∨ ((fact_9fdb227ae99d_4069 a b) ∨ (fact_9fdb227ae99d_4097 a b) ∨ (fact_9fdb227ae99d_5303 a b) ∨ (fact_9fdb227ae99d_5918 a b) ∨ (fact_9fdb227ae99d_4732 a b) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + a)) ∧ ((1 : Int) ≥ ((4 : Int) + a))) ∨ (((-1 : Int) ≤ ((-3 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-3 : Int) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_4262 a b) ∨ (fact_9fdb227ae99d_4113 a b) ∨ (fact_9fdb227ae99d_6160 a b)))) ∨ ((fact_9fdb227ae99d_7667 a b) ∧ (fact_9fdb227ae99d_7400 a b) ∧ ((fact_9fdb227ae99d_6027 a b) ∨ (fact_9fdb227ae99d_6065 a b) ∨ (fact_9fdb227ae99d_6827 a b) ∨ (fact_9fdb227ae99d_7039 a b) ∨ (fact_9fdb227ae99d_6593 a b) ∨ (((((-1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + a)) ∧ ((1 : Int) ≥ ((4 : Int) + a))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_6271 a b) ∨ (fact_9fdb227ae99d_6089 a b) ∨ (fact_9fdb227ae99d_7090 a b)) ∧ ((fact_9fdb227ae99d_4069 a b) ∨ (fact_9fdb227ae99d_4097 a b) ∨ (fact_9fdb227ae99d_5303 a b) ∨ (fact_9fdb227ae99d_5918 a b) ∨ (fact_9fdb227ae99d_4732 a b) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + a)) ∧ ((1 : Int) ≥ ((4 : Int) + a))) ∨ (((-1 : Int) ≤ ((-3 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-3 : Int) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_4262 a b) ∨ (fact_9fdb227ae99d_4113 a b) ∨ (fact_9fdb227ae99d_6160 a b))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n204_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : ((-3 : Int) ≥ run_x))
    (h5 : ((fact_9fdb227ae99d_2367 a b run_x) ∨ (fact_9fdb227ae99d_2384 a b run_x) ∨ (fact_9fdb227ae99d_3040 a b run_x) ∨ (fact_9fdb227ae99d_3481 a b run_x) ∨ (fact_9fdb227ae99d_2928 a b run_x) ∨ (fact_9fdb227ae99d_2468 a b run_x) ∨ (fact_9fdb227ae99d_2479 a b run_x) ∨ (fact_9fdb227ae99d_2398 a b run_x) ∨ (fact_9fdb227ae99d_3612 a b run_x)))
    (h6 : (((-2 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n204_run_floor (a b run_x : Int)
    (h0 : (((-2 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h1 : ((-3 : Int) ≥ run_x))
    (h2 : (¬ ((fact_9fdb227ae99d_3179 a b run_x) ∨ (fact_9fdb227ae99d_3189 a b run_x) ∨ (fact_9fdb227ae99d_3731 a b run_x) ∨ (fact_9fdb227ae99d_5196 a b run_x) ∨ (fact_9fdb227ae99d_3490 a b run_x) ∨ (fact_9fdb227ae99d_3224 a b run_x) ∨ (fact_9fdb227ae99d_3239 a b run_x) ∨ (fact_9fdb227ae99d_3197 a b run_x) ∨ (fact_9fdb227ae99d_5356 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n205_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((3 : Int) ≤ a)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n205_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((a - (3 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n205_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n205_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3381 a b) ∨ (fact_9fdb227ae99d_3382 a b) ∨ (fact_9fdb227ae99d_4497 a b) ∨ (fact_9fdb227ae99d_5584 a b) ∨ (fact_9fdb227ae99d_3851 a b) ∨ ((((3 : Int) ≥ ((-1 : Int) - b)) ∧ ((3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((3 : Int) ≥ ((-2 : Int) - b)) ∧ ((3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-2 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3852 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n205_run_right (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((fact_9fdb227ae99d_3067 a b) ∨ (fact_9fdb227ae99d_3068 a b) ∨ (fact_9fdb227ae99d_3569 a b) ∨ (fact_9fdb227ae99d_4707 a b) ∨ (fact_9fdb227ae99d_3300 a b) ∨ ((((3 : Int) ≥ ((-1 : Int) - b)) ∧ ((3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ (((-1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((3 : Int) ≥ ((-2 : Int) - b)) ∧ ((3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ (((-2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-2 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3301 a b))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n205_run_tall (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a > b))
    (h2 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_9fdb227ae99d_7287 a b) ∨ (fact_9fdb227ae99d_7239 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_9fdb227ae99d_7287 a b) ∧ (fact_9fdb227ae99d_7239 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7287 a b) ∧ (fact_9fdb227ae99d_7239 a b) ∧ (((fact_9fdb227ae99d_3756 a b) ∨ (fact_9fdb227ae99d_3788 a b) ∨ (fact_9fdb227ae99d_5166 a b) ∨ (fact_9fdb227ae99d_5844 a b) ∨ (fact_9fdb227ae99d_4538 a b) ∨ (((((-1 : Int) - b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ ((3 : Int) + a)) ∧ ((-1 : Int) ≥ ((3 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_3974 a b) ∨ (fact_9fdb227ae99d_4649 a b)) ∨ ((fact_9fdb227ae99d_3268 a b) ∨ (fact_9fdb227ae99d_3274 a b) ∨ (fact_9fdb227ae99d_4193 a b) ∨ (fact_9fdb227ae99d_5365 a b) ∨ (fact_9fdb227ae99d_3618 a b) ∨ (((((-1 : Int) - b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ (((-1 : Int) ≤ ((3 : Int) + a)) ∧ ((-1 : Int) ≥ ((3 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_3310 a b) ∨ (fact_9fdb227ae99d_3650 a b)))) ∨ ((fact_9fdb227ae99d_7287 a b) ∧ (fact_9fdb227ae99d_7239 a b) ∧ ((fact_9fdb227ae99d_3756 a b) ∨ (fact_9fdb227ae99d_3788 a b) ∨ (fact_9fdb227ae99d_5166 a b) ∨ (fact_9fdb227ae99d_5844 a b) ∨ (fact_9fdb227ae99d_4538 a b) ∨ (((((-1 : Int) - b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ ((3 : Int) + a)) ∧ ((-1 : Int) ≥ ((3 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_3974 a b) ∨ (fact_9fdb227ae99d_4649 a b)) ∧ ((fact_9fdb227ae99d_3268 a b) ∨ (fact_9fdb227ae99d_3274 a b) ∨ (fact_9fdb227ae99d_4193 a b) ∨ (fact_9fdb227ae99d_5365 a b) ∨ (fact_9fdb227ae99d_3618 a b) ∨ (((((-1 : Int) - b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ (((-1 : Int) ≤ ((3 : Int) + a)) ∧ ((-1 : Int) ≥ ((3 : Int) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_3310 a b) ∨ (fact_9fdb227ae99d_3650 a b))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n205_run_empty (a b run_x : Int)
    (h0 : (run_x ≤ a))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((fact_9fdb227ae99d_2444 a b run_x) ∨ (fact_9fdb227ae99d_2445 a b run_x) ∨ (fact_9fdb227ae99d_3064 a b run_x) ∨ (fact_9fdb227ae99d_3570 a b run_x) ∨ (fact_9fdb227ae99d_2980 a b run_x) ∨ ((((3 : Int) ≥ ((-1 : Int) - b)) ∧ ((3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ ((((3 : Int) ≥ ((-2 : Int) - b)) ∧ ((3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-2 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_2981 a b run_x)))
    (h7 : ((3 : Int) ≤ run_x))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n205_run_floor (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((fact_9fdb227ae99d_3173 a b run_x) ∨ (fact_9fdb227ae99d_3183 a b run_x) ∨ (fact_9fdb227ae99d_3726 a b run_x) ∨ (fact_9fdb227ae99d_5191 a b run_x) ∨ (fact_9fdb227ae99d_3485 a b run_x) ∨ (((((-1 : Int) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((-2 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3549 a b run_x))))
    (h2 : (run_x ≤ a))
    (h3 : ((3 : Int) ≤ run_x))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n206_point (a b : Int)
    (h0 : (¬ (((-3 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((-3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n206_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_2869 a b) ∨ (fact_9fdb227ae99d_2871 a b) ∨ (fact_9fdb227ae99d_3261 a b) ∨ (fact_9fdb227ae99d_4168 a b) ∨ (fact_9fdb227ae99d_3100 a b) ∨ ((((-3 : Int) ≥ ((-1 : Int) - b)) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((-2 : Int) - b)) ∧ ((-3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((2 : Int) + a)) ∧ ((2 : Int) ≤ ((2 : Int) + a))) ∨ (((-2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-2 : Int)) ∧ ((2 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((2 : Int) + a) + (0 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (((((2 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n206_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (¬ (((jx = ((-3 : Int) + ((-1 : Int) * a))) ∧ ((2 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h5 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h6 : (b = (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n206_o1 (a b jx jy : Int)
    (h0 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n206_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (¬ ((((-3 : Int) = jx) ∧ (jy = ((2 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h3 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h4 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n206_o3 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h2 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n206_o4 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((jx + (0 : Int)) < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < (jx - b)) ∨ (jy < ((2 : Int) + a)) ∨ (((2 : Int) + a) < jy)))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h6 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n206_o5 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (¬ ((((-3 : Int) = jx) ∧ ((2 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n206_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((jx = ((-3 : Int) + ((-1 : Int) * b))) ∧ ((2 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h3 : (b = (5 : Int)))
    (h4 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n206_o7 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n207_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ (((-1 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((0 : Int) ≥ (0 : Int)) ∧ ((-1 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((0 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n207_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_2857 a b) ∨ (fact_9fdb227ae99d_2859 a b) ∨ (fact_9fdb227ae99d_3257 a b) ∨ (fact_9fdb227ae99d_4158 a b) ∨ (fact_9fdb227ae99d_3085 a b) ∨ (fact_9fdb227ae99d_2951 a b) ∨ ((((-1 : Int) ≥ ((-2 : Int) - b)) ∧ ((-1 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) + a)) ∧ ((0 : Int) ≤ ((2 : Int) + a))) ∨ (((-2 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-2 : Int)) ∧ ((0 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((0 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((-1 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((-1 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (2 : Int))) ∨ (((-1 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) + b))))))
    (h1 : (((-1 : Int) > ((1 : Int) + b + a)) ∨ ((-1 : Int) < ((1 : Int) + b + a)) ∨ (((0 : Int) + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < ((0 : Int) - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n207_o0 (a b jx jy : Int)
    (h0 : ((jx < (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n207_o1 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_9fdb227ae99d_2923 a b jy))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n207_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_2924 a b jy))
    (h3 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n207_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h6 : (b = (5 : Int)))
    (h7 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n207_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_2922 a b jy))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n207_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h4 : ((jx < (((1 : Int) + b + a) - a)) ∨ ((((1 : Int) + b + a) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h5 : (b = (5 : Int)))
    (h6 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h7 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (fact_9fdb227ae99d_107 a b))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n207_o6 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n207_o7 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_2925 a b jy))
    (h2 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n208_run_four (a b : Int)
    (h0 : (¬ ((2 : Int) ≤ ((-1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n208_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((-1 : Int) + a) - (2 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n208_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n208_run_left (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3582 a b) ∨ (fact_9fdb227ae99d_3586 a b) ∨ (fact_9fdb227ae99d_4719 a b) ∨ (fact_9fdb227ae99d_5749 a b) ∨ (fact_9fdb227ae99d_4338 a b) ∨ (((((-1 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-(4 : Int))) ∧ ((-1 : Int) ≥ (-(4 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((-2 : Int) ≤ (-(4 : Int))) ∧ ((-2 : Int) ≥ (-(4 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_4476 a b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n208_run_right (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ ((fact_9fdb227ae99d_4486 a b) ∨ (fact_9fdb227ae99d_4488 a b) ∨ (fact_9fdb227ae99d_5542 a b) ∨ (fact_9fdb227ae99d_6323 a b) ∨ (fact_9fdb227ae99d_5198 a b) ∨ (((((-1 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ (-(4 : Int))) ∧ ((-1 : Int) ≥ (-(4 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((-2 : Int) ≤ (-(4 : Int))) ∧ ((-2 : Int) ≥ (-(4 : Int))) ∧ ((((2 : Int) + a) - a) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_5339 a b))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n208_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (¬ (((((2 : Int) + (3 : Int)) ≤ ((-1 : Int) + a)) ∧ ((fact_9fdb227ae99d_7329 a b) ∨ (fact_9fdb227ae99d_7371 a b))) ∨ ((((2 : Int) + (2 : Int)) ≤ ((-1 : Int) + a)) ∧ (fact_9fdb227ae99d_7329 a b) ∧ (fact_9fdb227ae99d_7371 a b)) ∨ (((2 : Int) + (4 : Int)) ≤ ((-1 : Int) + a)) ∨ ((((-1 : Int) + a) = ((2 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7329 a b) ∧ (fact_9fdb227ae99d_7371 a b) ∧ (((fact_9fdb227ae99d_4345 a b) ∨ (fact_9fdb227ae99d_4362 a b) ∨ (fact_9fdb227ae99d_5455 a b) ∨ (fact_9fdb227ae99d_6178 a b) ∨ (fact_9fdb227ae99d_5113 a b) ∨ (((((-1 : Int) - b) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((-2 : Int) ≤ (-((4 : Int) + a))) ∧ ((-2 : Int) ≥ (-((4 : Int) + a))) ∧ ((((2 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_5230 a b)) ∨ ((fact_9fdb227ae99d_5265 a b) ∨ (fact_9fdb227ae99d_5274 a b) ∨ (fact_9fdb227ae99d_5832 a b) ∨ (fact_9fdb227ae99d_6765 a b) ∨ (fact_9fdb227ae99d_5666 a b) ∨ (((((-1 : Int) - b) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ (((1 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((-2 : Int) ≤ (-((4 : Int) + a))) ∧ ((-2 : Int) ≥ (-((4 : Int) + a))) ∧ ((((2 : Int) + a) - a) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_5779 a b)))) ∨ ((fact_9fdb227ae99d_7329 a b) ∧ (fact_9fdb227ae99d_7371 a b) ∧ ((fact_9fdb227ae99d_4345 a b) ∨ (fact_9fdb227ae99d_4362 a b) ∨ (fact_9fdb227ae99d_5455 a b) ∨ (fact_9fdb227ae99d_6178 a b) ∨ (fact_9fdb227ae99d_5113 a b) ∨ (((((-1 : Int) - b) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((-2 : Int) ≤ (-((4 : Int) + a))) ∧ ((-2 : Int) ≥ (-((4 : Int) + a))) ∧ ((((2 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_5230 a b)) ∧ ((fact_9fdb227ae99d_5265 a b) ∨ (fact_9fdb227ae99d_5274 a b) ∨ (fact_9fdb227ae99d_5832 a b) ∨ (fact_9fdb227ae99d_6765 a b) ∨ (fact_9fdb227ae99d_5666 a b) ∨ (((((-1 : Int) - b) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ (((1 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((-2 : Int) ≤ (-((4 : Int) + a))) ∧ ((-2 : Int) ≥ (-((4 : Int) + a))) ∧ ((((2 : Int) + a) - a) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_5779 a b))))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n208_run_empty (a b run_x : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (((((2 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (run_x ≤ ((-1 : Int) + a)))
    (h4 : (b = (5 : Int)))
    (h5 : ((fact_9fdb227ae99d_2588 a b run_x) ∨ (fact_9fdb227ae99d_2593 a b run_x) ∨ (fact_9fdb227ae99d_3154 a b run_x) ∨ (fact_9fdb227ae99d_3674 a b run_x) ∨ (fact_9fdb227ae99d_3032 a b run_x) ∨ (((((-1 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ (-(4 : Int))) ∧ ((-1 : Int) ≥ (-(4 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((-2 : Int) ≤ (-(4 : Int))) ∧ ((-2 : Int) ≥ (-(4 : Int))) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3045 a b run_x)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((2 : Int) ≤ run_x))
    (h8 : (b ≥ (3 : Int)))
    (h9 : ((((2 : Int) + a) < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + b) < ((2 : Int) + b)) ∨ (((2 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n208_run_floor (a b run_x : Int)
    (h0 : ((2 : Int) ≤ run_x))
    (h1 : (run_x ≤ ((-1 : Int) + a)))
    (h2 : (¬ ((fact_9fdb227ae99d_3321 a b run_x) ∨ (fact_9fdb227ae99d_3325 a b run_x) ∨ (fact_9fdb227ae99d_4336 a b run_x) ∨ (fact_9fdb227ae99d_5470 a b run_x) ∨ (fact_9fdb227ae99d_3678 a b run_x) ∨ (((((-1 : Int) - b) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-((4 : Int) - (1 : Int))) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-1 : Int) ≥ (-((4 : Int) - (1 : Int)))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-((4 : Int) - (1 : Int))) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((-2 : Int) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-2 : Int) ≥ (-((4 : Int) - (1 : Int)))) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3745 a b run_x))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n209_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((-1 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((0 : Int) ≥ (0 : Int)) ∧ ((-1 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((0 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n209_empty (a b : Int)
    (h0 : (((-1 : Int) > ((1 : Int) + b + a)) ∨ ((-1 : Int) < ((1 : Int) + b + a)) ∨ (((0 : Int) + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < ((0 : Int) - (0 : Int)))))
    (h1 : ((fact_9fdb227ae99d_2857 a b) ∨ (fact_9fdb227ae99d_2859 a b) ∨ (fact_9fdb227ae99d_3257 a b) ∨ (fact_9fdb227ae99d_4158 a b) ∨ (fact_9fdb227ae99d_3085 a b) ∨ (fact_9fdb227ae99d_2951 a b) ∨ ((((-1 : Int) ≥ ((-2 : Int) - b)) ∧ ((-1 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) + a)) ∧ ((0 : Int) ≤ ((2 : Int) + a))) ∨ (((-2 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-2 : Int)) ∧ ((0 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((0 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((-1 : Int) ≥ ((-3 : Int) - a)) ∧ ((-1 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-3 : Int)) ∧ ((0 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) + b))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n209_o0 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h4 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n209_o1 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_2923 a b jy))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n209_o2 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_2924 a b jy))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n209_o3 (a b jx jy : Int)
    (h0 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b = (5 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n209_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_2922 a b jy))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n209_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : (((jx + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jx - a)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h7 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h8 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n209_o6 (a b jx jy : Int)
    (h0 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n209_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (fact_9fdb227ae99d_2925 a b jy))
    (h2 : (b = (5 : Int)))
    (h3 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n210_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((-3 : Int) ≥ ((-2 : Int) + ((-1 : Int) * b)))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n210_run_short (a b : Int)
    (h0 : (¬ (((-3 : Int) - ((-2 : Int) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n210_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n210_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5685 a b) ∨ (fact_9fdb227ae99d_5698 a b) ∨ (fact_9fdb227ae99d_6366 a b) ∨ (fact_9fdb227ae99d_6962 a b) ∨ (fact_9fdb227ae99d_5992 a b) ∨ (((((-1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) + a)) ∧ ((3 : Int) ≤ ((2 : Int) + a))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_6980 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n210_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3413 a b) ∨ (fact_9fdb227ae99d_3431 a b) ∨ (fact_9fdb227ae99d_4506 a b) ∨ (fact_9fdb227ae99d_5590 a b) ∨ (fact_9fdb227ae99d_3878 a b) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-1 : Int) ≤ ((-3 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-3 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) + a)) ∧ ((3 : Int) ≤ ((2 : Int) + a))) ∨ (((-2 : Int) ≤ ((-3 : Int) + (1 : Int))) ∧ ((-2 : Int) ≥ ((-3 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_5724 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n210_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ ((((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7525 a b) ∨ (fact_9fdb227ae99d_7319 a b))) ∨ (((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) + (2 : Int))) ∧ (fact_9fdb227ae99d_7525 a b) ∧ (fact_9fdb227ae99d_7319 a b)) ∨ ((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) + (4 : Int))) ∨ (((-3 : Int) = (((-2 : Int) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_9fdb227ae99d_7525 a b) ∧ (fact_9fdb227ae99d_7319 a b) ∧ (((fact_9fdb227ae99d_6025 a b) ∨ (fact_9fdb227ae99d_6063 a b) ∨ (fact_9fdb227ae99d_6825 a b) ∨ (fact_9fdb227ae99d_7037 a b) ∨ (fact_9fdb227ae99d_6591 a b) ∨ (((((-1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_6700 a b) ∨ (fact_9fdb227ae99d_7088 a b)) ∨ ((fact_9fdb227ae99d_4067 a b) ∨ (fact_9fdb227ae99d_4095 a b) ∨ (fact_9fdb227ae99d_5301 a b) ∨ (fact_9fdb227ae99d_5916 a b) ∨ (fact_9fdb227ae99d_4730 a b) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ (((-1 : Int) ≤ ((-3 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-3 : Int) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_5073 a b) ∨ (fact_9fdb227ae99d_6158 a b)))) ∨ ((fact_9fdb227ae99d_7525 a b) ∧ (fact_9fdb227ae99d_7319 a b) ∧ ((fact_9fdb227ae99d_6025 a b) ∨ (fact_9fdb227ae99d_6063 a b) ∨ (fact_9fdb227ae99d_6825 a b) ∨ (fact_9fdb227ae99d_7037 a b) ∨ (fact_9fdb227ae99d_6591 a b) ∨ (((((-1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_6700 a b) ∨ (fact_9fdb227ae99d_7088 a b)) ∧ ((fact_9fdb227ae99d_4067 a b) ∨ (fact_9fdb227ae99d_4095 a b) ∨ (fact_9fdb227ae99d_5301 a b) ∨ (fact_9fdb227ae99d_5916 a b) ∨ (fact_9fdb227ae99d_4730 a b) ∨ (((((-1 : Int) - b) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ (((-1 : Int) ≤ ((-3 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-3 : Int) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_5073 a b) ∨ (fact_9fdb227ae99d_6158 a b))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n210_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((-2 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h4 : ((-3 : Int) ≥ run_x))
    (h5 : ((fact_9fdb227ae99d_2366 a b run_x) ∨ (fact_9fdb227ae99d_2383 a b run_x) ∨ (fact_9fdb227ae99d_3039 a b run_x) ∨ (fact_9fdb227ae99d_3480 a b run_x) ∨ (fact_9fdb227ae99d_2927 a b run_x) ∨ (((((-1 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-1 : Int) ≤ run_x) ∧ ((-1 : Int) ≥ run_x) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-2 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) + a)) ∧ ((3 : Int) ≤ ((2 : Int) + a))) ∨ (((-2 : Int) ≤ run_x) ∧ ((-2 : Int) ≥ run_x) ∧ ((3 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_3611 a b run_x)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n210_run_floor (a b run_x : Int)
    (h0 : ((-3 : Int) ≥ run_x))
    (h1 : (((-2 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h2 : (¬ ((fact_9fdb227ae99d_3178 a b run_x) ∨ (fact_9fdb227ae99d_3188 a b run_x) ∨ (fact_9fdb227ae99d_3730 a b run_x) ∨ (fact_9fdb227ae99d_5195 a b run_x) ∨ (fact_9fdb227ae99d_3489 a b run_x) ∨ (((((-1 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ run_x) ∧ ((-1 : Int) ≥ run_x) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (((((-2 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((-2 : Int) ≤ run_x) ∧ ((-2 : Int) ≥ run_x) ∧ ((((2 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_9fdb227ae99d_5355 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n211_point (a b : Int)
    (h0 : (¬ (((-1 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((0 : Int) ≥ (0 : Int)) ∧ ((-1 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((0 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n211_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((2 : Int) + ((2 : Int) * b)) < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < ((2 : Int) + ((2 : Int) * b))) ∨ ((1 : Int) > ((1 : Int) + a)) ∨ ((1 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : ((fact_9fdb227ae99d_2857 a b) ∨ (fact_9fdb227ae99d_2859 a b) ∨ (fact_9fdb227ae99d_3257 a b) ∨ (fact_9fdb227ae99d_4158 a b) ∨ (fact_9fdb227ae99d_3085 a b) ∨ (fact_9fdb227ae99d_2951 a b) ∨ ((((-1 : Int) ≥ ((-2 : Int) - a)) ∧ ((-1 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (2 : Int))) ∨ (((-2 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-2 : Int)) ∧ ((0 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) + b))))))
    (h3 : (((-1 : Int) > ((1 : Int) + b + a)) ∨ ((-1 : Int) < ((1 : Int) + b + a)) ∨ (((0 : Int) + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < ((0 : Int) - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n211_o0 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : ((jx < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n211_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_2923 a b jy))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n211_o2 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (fact_9fdb227ae99d_2924 a b jy))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n211_o3 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n211_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (fact_9fdb227ae99d_2922 a b jy))
    (h5 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - a)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n211_o5 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h4 : (((jx + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jx - a)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + b)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n211_o6 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - (0 : Int))) ∧ ((0 : Int) ≤ (jy + a)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n211_o7 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_2925 a b jy))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ ((0 : Int) ≥ jy) ∧ ((0 : Int) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((0 : Int) ≥ (jy - b)) ∧ ((0 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n212_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((-2 : Int) ≥ ((-1 : Int) + ((-1 : Int) * b)))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n212_run_short (a b : Int)
    (h0 : (¬ (((-2 : Int) - ((-1 : Int) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n212_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n212_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_5684 a b) ∨ (fact_9fdb227ae99d_5697 a b) ∨ (fact_9fdb227ae99d_6365 a b) ∨ (fact_9fdb227ae99d_6961 a b) ∨ ((((((2 : Int) + a) - a) ≤ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ ((((2 : Int) + a) ≤ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((2 : Int) + a)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_6979 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n212_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3412 a b) ∨ (fact_9fdb227ae99d_3430 a b) ∨ (fact_9fdb227ae99d_4505 a b) ∨ (fact_9fdb227ae99d_5589 a b) ∨ ((((((2 : Int) + a) - a) ≤ ((-2 : Int) + (1 : Int))) ∧ (((-2 : Int) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ ((((2 : Int) + a) ≤ ((-2 : Int) + (1 : Int))) ∧ (((-2 : Int) + (1 : Int)) ≤ ((2 : Int) + a)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - b) ≤ ((-2 : Int) + (1 : Int))) ∧ (((-2 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-1 : Int) ≤ ((-2 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-2 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_5723 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n212_run_tall (a b : Int)
    (h0 : (¬ ((((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7370 a b) ∨ (fact_9fdb227ae99d_7247 a b))) ∨ (((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) + (2 : Int))) ∧ (fact_9fdb227ae99d_7370 a b) ∧ (fact_9fdb227ae99d_7247 a b)) ∨ ((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) + (4 : Int))) ∨ (((-2 : Int) = (((-1 : Int) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_9fdb227ae99d_7370 a b) ∧ (fact_9fdb227ae99d_7247 a b) ∧ (((fact_9fdb227ae99d_6015 a b) ∨ (fact_9fdb227ae99d_6053 a b) ∨ (fact_9fdb227ae99d_6815 a b) ∨ (fact_9fdb227ae99d_7027 a b) ∨ (fact_9fdb227ae99d_6581 a b) ∨ (((((-1 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ (((-1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_7074 a b)) ∨ ((fact_9fdb227ae99d_4063 a b) ∨ (fact_9fdb227ae99d_4091 a b) ∨ (fact_9fdb227ae99d_5297 a b) ∨ (fact_9fdb227ae99d_5912 a b) ∨ (fact_9fdb227ae99d_4726 a b) ∨ (((((-1 : Int) - b) ≤ ((-2 : Int) + (1 : Int))) ∧ (((-2 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ (((-1 : Int) ≤ ((-2 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-2 : Int) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_6145 a b)))) ∨ ((fact_9fdb227ae99d_7370 a b) ∧ (fact_9fdb227ae99d_7247 a b) ∧ ((fact_9fdb227ae99d_6015 a b) ∨ (fact_9fdb227ae99d_6053 a b) ∨ (fact_9fdb227ae99d_6815 a b) ∨ (fact_9fdb227ae99d_7027 a b) ∨ (fact_9fdb227ae99d_6581 a b) ∨ (((((-1 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ (((-1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_7074 a b)) ∧ ((fact_9fdb227ae99d_4063 a b) ∨ (fact_9fdb227ae99d_4091 a b) ∨ (fact_9fdb227ae99d_5297 a b) ∨ (fact_9fdb227ae99d_5912 a b) ∨ (fact_9fdb227ae99d_4726 a b) ∨ (((((-1 : Int) - b) ≤ ((-2 : Int) + (1 : Int))) ∧ (((-2 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ (((-1 : Int) ≤ ((-2 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-2 : Int) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_6145 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n212_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((-2 : Int) ≥ run_x))
    (h2 : (((-1 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((fact_9fdb227ae99d_2366 a b run_x) ∨ (fact_9fdb227ae99d_2383 a b run_x) ∨ (fact_9fdb227ae99d_3039 a b run_x) ∨ (fact_9fdb227ae99d_3480 a b run_x) ∨ (fact_9fdb227ae99d_2927 a b run_x) ∨ (((((-1 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-1 : Int) ≤ run_x) ∧ ((-1 : Int) ≥ run_x) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_3607 a b run_x)))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n212_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3178 a b run_x) ∨ (fact_9fdb227ae99d_3188 a b run_x) ∨ (fact_9fdb227ae99d_3730 a b run_x) ∨ (fact_9fdb227ae99d_5195 a b run_x) ∨ (fact_9fdb227ae99d_3489 a b run_x) ∨ (((((-1 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ run_x) ∧ ((-1 : Int) ≥ run_x) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ (fact_9fdb227ae99d_5351 a b run_x))))
    (h1 : ((-2 : Int) ≥ run_x))
    (h2 : (((-1 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n213_point (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ (((-2 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n213_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_2863 a b) ∨ (fact_9fdb227ae99d_2865 a b) ∨ (fact_9fdb227ae99d_3259 a b) ∨ (fact_9fdb227ae99d_4166 a b) ∨ (fact_9fdb227ae99d_3091 a b) ∨ (fact_9fdb227ae99d_2957 a b)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n213_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h3 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h4 : (¬ (((jx = ((-2 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n213_o1 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n213_o2 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (fact_9fdb227ae99d_2924 a b jy))
    (h2 : (b = (5 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (¬ ((((-2 : Int) = jx) ∧ (jy = ((1 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n213_o3 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h4 : (¬ ((((-2 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n213_o4 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_2922 a b jy))
    (h3 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (¬ ((((-2 : Int) = jx) ∧ (jy = ((1 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n213_o5 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((jx < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h7 : (fact_9fdb227ae99d_7278 a b jx jy))
    (h8 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n213_o6 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h5 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (¬ (((jx = ((-2 : Int) + ((-1 : Int) * b))) ∧ ((1 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n213_o7 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n214_point (a b : Int)
    (h0 : (¬ (((-2 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n214_empty (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((fact_9fdb227ae99d_2864 a b) ∨ (fact_9fdb227ae99d_2866 a b) ∨ (fact_9fdb227ae99d_3260 a b) ∨ (fact_9fdb227ae99d_4167 a b) ∨ ((((-2 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((-2 : Int) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ (((-2 : Int) ≥ ((2 : Int) + a)) ∧ ((-2 : Int) ≤ ((2 : Int) + a)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_2958 a b) ∨ (fact_9fdb227ae99d_4394 a b)))
    (h2 : (((((2 : Int) + a) + (0 : Int)) < ((-2 : Int) + ((-1 : Int) * a))) ∨ (((-2 : Int) + ((-1 : Int) * a)) < (((2 : Int) + a) - a)) ∨ ((2 : Int) < ((1 : Int) - (0 : Int))) ∨ ((2 : Int) > ((1 : Int) + b))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n214_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((jx + a) < ((-2 : Int) + ((-1 : Int) * a))) ∨ (((-2 : Int) + ((-1 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b = (5 : Int)))
    (h7 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n214_o1 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (¬ ((((-2 : Int) = jx) ∧ (jy = ((2 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h7 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n214_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (¬ ((((-2 : Int) = jx) ∧ (jy = ((2 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (((jx + (0 : Int)) < ((-2 : Int) + ((-1 : Int) * a))) ∨ (((-2 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n214_o3 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b = (5 : Int)))
    (h2 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (¬ ((((-2 : Int) = jx) ∧ ((2 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h6 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n214_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (¬ ((((-2 : Int) = jx) ∧ (jy = ((2 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n214_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h8 : (((jx + (0 : Int)) < ((-2 : Int) + ((-1 : Int) * a))) ∨ (((-2 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n214_o6 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h1 : (¬ (((jx = ((-2 : Int) + ((-1 : Int) * b))) ∧ ((2 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : (((jx + b) < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < (jx - (0 : Int))) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (((jx + b) < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < (jx - (0 : Int))) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h9 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h10 : (a ≥ (5 : Int)))
    (h11 : (((jx + b) < ((-1 : Int) - b)) ∨ (((-1 : Int) + (0 : Int)) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n214_o7 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h1 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n215_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_0 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n215_empty (a b : Int)
    (h0 : (a ≥ b))
    (h1 : ((fact_9fdb227ae99d_3050 a b) ∨ (fact_9fdb227ae99d_3052 a b) ∨ (fact_9fdb227ae99d_3562 a b) ∨ (fact_9fdb227ae99d_4700 a b) ∨ (fact_9fdb227ae99d_3284 a b) ∨ (fact_9fdb227ae99d_3113 a b) ∨ ((((0 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((0 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≥ ((1 : Int) + a))) ∨ (((0 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((1 : Int) + b)))) ∨ ((((0 : Int) ≥ ((-2 : Int) - (0 : Int))) ∧ ((0 : Int) ≤ ((-2 : Int) + b)) ∧ (((2 : Int) + a) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((-2 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (-2 : Int)) ∧ ((((2 : Int) + a) - a) ≤ ((1 : Int) + a)) ∧ (((1 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int)))))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n215_o0 (a b jx jy : Int)
    (h0 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h3 : ((jx < ((-2 : Int) - (0 : Int))) ∨ (((-2 : Int) + b) < jx) ∨ ((jy + b) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h4 : (b = (5 : Int)))
    (h5 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((jx + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h8 : (fact_9fdb227ae99d_1604 a b jx jy))
    (h9 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h10 : (fact_9fdb227ae99d_107 a b))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n215_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_1609 a b jx jy))
    (h4 : ((jx < ((-2 : Int) - (0 : Int))) ∨ (((-2 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - a))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h8 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h9 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - a))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n215_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : ((jx < ((-2 : Int) - (0 : Int))) ∨ (((-2 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - b))))
    (h3 : (fact_9fdb227ae99d_1613 a b jx jy))
    (h4 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - b))))
    (h5 : (b = (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a > b))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n215_o3 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (fact_9fdb227ae99d_1616 a b jx jy))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h8 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h9 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n215_o4 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (fact_9fdb227ae99d_1617 a b jx jy))
    (h3 : (fact_9fdb227ae99d_2922 a b jy))
    (h4 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - a))))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : ((jx < ((-2 : Int) - (0 : Int))) ∨ (((-2 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - a))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (b = (5 : Int)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n215_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_1612 a b jx jy))
    (h5 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h8 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h9 : (b = (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n215_o6 (a b jx jy : Int)
    (h0 : (((jx + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h1 : ((jx < ((-2 : Int) - (0 : Int))) ∨ (((-2 : Int) + b) < jx) ∨ ((jy + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h2 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (fact_9fdb227ae99d_1608 a b jx jy))
    (h9 : (b = (5 : Int)))
    (h10 : (fact_9fdb227ae99d_107 a b))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n215_o7 (a b jx jy : Int)
    (h0 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jy - b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((jx < ((-2 : Int) - (0 : Int))) ∨ (((-2 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jy - b))))
    (h5 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (fact_9fdb227ae99d_1605 a b jx jy))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n216_run_four (a b : Int)
    (h0 : (¬ ((2 : Int) ≤ ((-1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n216_run_short (a b : Int)
    (h0 : (¬ ((((-1 : Int) + a) - (2 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n216_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n216_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_5689 a b) ∨ (fact_9fdb227ae99d_5702 a b) ∨ (fact_9fdb227ae99d_6370 a b) ∨ (fact_9fdb227ae99d_6966 a b) ∨ ((((((2 : Int) + a) - a) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((2 : Int) + a) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_5763 a b) ∨ (fact_9fdb227ae99d_6977 a b) ∨ (fact_9fdb227ae99d_6261 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n216_run_right (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (¬ ((fact_9fdb227ae99d_6311 a b) ∨ (fact_9fdb227ae99d_6312 a b) ∨ (fact_9fdb227ae99d_6882 a b) ∨ (fact_9fdb227ae99d_7057 a b) ∨ ((((((2 : Int) + a) - a) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ ((((2 : Int) + a) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_6328 a b) ∨ (fact_9fdb227ae99d_7119 a b) ∨ (fact_9fdb227ae99d_6779 a b))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n216_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (¬ (((((2 : Int) + (3 : Int)) ≤ ((-1 : Int) + a)) ∧ ((fact_9fdb227ae99d_7523 a b) ∨ (fact_9fdb227ae99d_7614 a b))) ∨ ((((2 : Int) + (2 : Int)) ≤ ((-1 : Int) + a)) ∧ (fact_9fdb227ae99d_7523 a b) ∧ (fact_9fdb227ae99d_7614 a b)) ∨ (((2 : Int) + (4 : Int)) ≤ ((-1 : Int) + a)) ∨ ((((-1 : Int) + a) = ((2 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7523 a b) ∧ (fact_9fdb227ae99d_7614 a b) ∧ (((fact_9fdb227ae99d_6004 a b) ∨ (fact_9fdb227ae99d_6042 a b) ∨ (fact_9fdb227ae99d_6804 a b) ∨ (fact_9fdb227ae99d_7016 a b) ∨ (fact_9fdb227ae99d_6570 a b) ∨ (fact_9fdb227ae99d_6220 a b) ∨ (fact_9fdb227ae99d_7062 a b) ∨ (fact_9fdb227ae99d_6689 a b)) ∨ ((fact_9fdb227ae99d_6741 a b) ∨ (fact_9fdb227ae99d_6745 a b) ∨ (fact_9fdb227ae99d_6995 a b) ∨ (fact_9fdb227ae99d_7154 a b) ∨ (fact_9fdb227ae99d_6924 a b) ∨ (fact_9fdb227ae99d_6776 a b) ∨ (fact_9fdb227ae99d_7164 a b) ∨ (fact_9fdb227ae99d_6969 a b)))) ∨ ((fact_9fdb227ae99d_7523 a b) ∧ (fact_9fdb227ae99d_7614 a b) ∧ ((fact_9fdb227ae99d_6004 a b) ∨ (fact_9fdb227ae99d_6042 a b) ∨ (fact_9fdb227ae99d_6804 a b) ∨ (fact_9fdb227ae99d_7016 a b) ∨ (fact_9fdb227ae99d_6570 a b) ∨ (fact_9fdb227ae99d_6220 a b) ∨ (fact_9fdb227ae99d_7062 a b) ∨ (fact_9fdb227ae99d_6689 a b)) ∧ ((fact_9fdb227ae99d_6741 a b) ∨ (fact_9fdb227ae99d_6745 a b) ∨ (fact_9fdb227ae99d_6995 a b) ∨ (fact_9fdb227ae99d_7154 a b) ∨ (fact_9fdb227ae99d_6924 a b) ∨ (fact_9fdb227ae99d_6776 a b) ∨ (fact_9fdb227ae99d_7164 a b) ∨ (fact_9fdb227ae99d_6969 a b))))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n216_run_empty (a b run_x : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((fact_9fdb227ae99d_3627 a b run_x) ∨ (fact_9fdb227ae99d_3636 a b run_x) ∨ (fact_9fdb227ae99d_5035 a b run_x) ∨ (fact_9fdb227ae99d_5788 a b run_x) ∨ ((((((2 : Int) + a) - a) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ ((((2 : Int) + a) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3686 a b run_x) ∨ (fact_9fdb227ae99d_5820 a b run_x) ∨ (fact_9fdb227ae99d_4522 a b run_x)))
    (h2 : ((2 : Int) ≤ run_x))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (run_x ≤ ((-1 : Int) + a)))
    (h9 : (a ≥ b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n216_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5410 a b run_x) ∨ (fact_9fdb227ae99d_5413 a b run_x) ∨ (fact_9fdb227ae99d_5988 a b run_x) ∨ (fact_9fdb227ae99d_6841 a b run_x) ∨ ((((((2 : Int) + a) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ ((((2 : Int) + a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_5484 a b run_x) ∨ (fact_9fdb227ae99d_6897 a b run_x) ∨ (fact_9fdb227ae99d_5812 a b run_x))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((2 : Int) ≤ run_x))
    (h4 : (run_x ≤ ((-1 : Int) + a)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n217_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((2 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n217_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_2817 a b) ∨ (fact_9fdb227ae99d_2818 a b) ∨ (fact_9fdb227ae99d_3202 a b) ∨ (fact_9fdb227ae99d_3848 a b) ∨ (fact_9fdb227ae99d_3060 a b) ∨ (fact_9fdb227ae99d_2895 a b) ∨ ((((2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((2 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((2 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ ((((2 : Int) ≥ ((-2 : Int) - b)) ∧ ((2 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-2 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a))))))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((((2 : Int) + a) + (0 : Int)) < ((-2 : Int) + ((-1 : Int) * a))) ∨ (((-2 : Int) + ((-1 : Int) * a)) < (((2 : Int) + a) - a)) ∨ ((2 : Int) < ((1 : Int) - (0 : Int))) ∨ ((2 : Int) > ((1 : Int) + b))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n217_o0 (a b jx jy : Int)
    (h0 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : (b = (5 : Int)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n217_o1 (a b jx jy : Int)
    (h0 : (¬ ((((2 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h6 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n217_o2 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((2 : Int) ≥ (jx - a)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n217_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (¬ (((jx = ((2 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : ((((2 : Int) ≥ (jx - b)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h3 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n217_o4 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((((2 : Int) ≥ (jx - b)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ ((((2 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n217_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h2 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : ((((2 : Int) ≥ (jx - a)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h5 : ((jx < ((2 : Int) + a)) ∨ (((2 : Int) + a) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (fact_9fdb227ae99d_107 a b))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n217_o6 (a b jx jy : Int)
    (h0 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : (b = (5 : Int)))
    (h4 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (¬ ((((2 : Int) = jx) ∧ ((3 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n217_o7 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b = (5 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (¬ ((((2 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n218_point (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (¬ (((3 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n218_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((((2 : Int) + a) + (0 : Int)) < ((-2 : Int) + ((-1 : Int) * a))) ∨ (((-2 : Int) + ((-1 : Int) * a)) < (((2 : Int) + a) - a)) ∨ ((2 : Int) < ((1 : Int) - (0 : Int))) ∨ ((2 : Int) > ((1 : Int) + b))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : ((fact_9fdb227ae99d_2819 a b) ∨ (fact_9fdb227ae99d_2821 a b) ∨ (fact_9fdb227ae99d_3203 a b) ∨ (fact_9fdb227ae99d_3849 a b) ∨ (fact_9fdb227ae99d_3065 a b) ∨ (fact_9fdb227ae99d_2900 a b) ∨ ((((3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((3 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((3 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ ((((3 : Int) ≥ ((-2 : Int) - b)) ∧ ((3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-2 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3069 a b)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n218_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h7 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n218_o1 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h6 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h7 : (((jx + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) + a)) ∨ (((3 : Int) + a) < jy)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n218_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (b = (5 : Int)))
    (h6 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n218_o3 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (¬ (((jx = ((3 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h8 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n218_o4 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n218_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : (((jx + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h5 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h6 : (b = (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n218_o6 (a b jx jy : Int)
    (h0 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((jy + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h4 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n218_o7 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h4 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (¬ ((((3 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n219_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≤ ((2 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n219_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + b) - (3 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n219_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n219_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3364 a b) ∨ (fact_9fdb227ae99d_3371 a b) ∨ (fact_9fdb227ae99d_4406 a b) ∨ (fact_9fdb227ae99d_5545 a b) ∨ (fact_9fdb227ae99d_3734 a b) ∨ (fact_9fdb227ae99d_3396 a b) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((-2 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_3816 a b) ∨ (fact_9fdb227ae99d_3739 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n219_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3751 a b) ∨ (fact_9fdb227ae99d_3783 a b) ∨ (fact_9fdb227ae99d_5161 a b) ∨ (fact_9fdb227ae99d_5839 a b) ∨ (fact_9fdb227ae99d_4534 a b) ∨ (fact_9fdb227ae99d_3920 a b) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((-2 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((-2 : Int) ≥ (((2 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_9fdb227ae99d_4643 a b) ∨ (fact_9fdb227ae99d_4557 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n219_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ (((((3 : Int) + (3 : Int)) ≤ ((2 : Int) + b)) ∧ ((fact_9fdb227ae99d_7510 a b) ∨ (fact_9fdb227ae99d_7623 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ ((2 : Int) + b)) ∧ (fact_9fdb227ae99d_7510 a b) ∧ (fact_9fdb227ae99d_7623 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ ((2 : Int) + b)) ∨ ((((2 : Int) + b) = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7510 a b) ∧ (fact_9fdb227ae99d_7623 a b) ∧ (((fact_9fdb227ae99d_3759 a b) ∨ (fact_9fdb227ae99d_3791 a b) ∨ (fact_9fdb227ae99d_5169 a b) ∨ (fact_9fdb227ae99d_5847 a b) ∨ (fact_9fdb227ae99d_4540 a b) ∨ (fact_9fdb227ae99d_3929 a b) ∨ (fact_9fdb227ae99d_5964 a b) ∨ (fact_9fdb227ae99d_3981 a b) ∨ (fact_9fdb227ae99d_4654 a b) ∨ (fact_9fdb227ae99d_4559 a b)) ∨ ((fact_9fdb227ae99d_4574 a b) ∨ (fact_9fdb227ae99d_4609 a b) ∨ (fact_9fdb227ae99d_5640 a b) ∨ (fact_9fdb227ae99d_6381 a b) ∨ (fact_9fdb227ae99d_5377 a b) ∨ (fact_9fdb227ae99d_4782 a b) ∨ (fact_9fdb227ae99d_6540 a b) ∨ (fact_9fdb227ae99d_4830 a b) ∨ (fact_9fdb227ae99d_5420 a b) ∨ (fact_9fdb227ae99d_5397 a b)))) ∨ ((fact_9fdb227ae99d_7510 a b) ∧ (fact_9fdb227ae99d_7623 a b) ∧ ((fact_9fdb227ae99d_3759 a b) ∨ (fact_9fdb227ae99d_3791 a b) ∨ (fact_9fdb227ae99d_5169 a b) ∨ (fact_9fdb227ae99d_5847 a b) ∨ (fact_9fdb227ae99d_4540 a b) ∨ (fact_9fdb227ae99d_3929 a b) ∨ (fact_9fdb227ae99d_5964 a b) ∨ (fact_9fdb227ae99d_3981 a b) ∨ (fact_9fdb227ae99d_4654 a b) ∨ (fact_9fdb227ae99d_4559 a b)) ∧ ((fact_9fdb227ae99d_4574 a b) ∨ (fact_9fdb227ae99d_4609 a b) ∨ (fact_9fdb227ae99d_5640 a b) ∨ (fact_9fdb227ae99d_6381 a b) ∨ (fact_9fdb227ae99d_5377 a b) ∨ (fact_9fdb227ae99d_4782 a b) ∨ (fact_9fdb227ae99d_6540 a b) ∨ (fact_9fdb227ae99d_4830 a b) ∨ (fact_9fdb227ae99d_5420 a b) ∨ (fact_9fdb227ae99d_5397 a b))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n219_run_empty (a b run_x : Int)
    (h0 : ((3 : Int) ≤ run_x))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (run_x ≤ ((2 : Int) + b)))
    (h6 : ((fact_9fdb227ae99d_2367 a b run_x) ∨ (fact_9fdb227ae99d_2384 a b run_x) ∨ (fact_9fdb227ae99d_3040 a b run_x) ∨ (fact_9fdb227ae99d_3481 a b run_x) ∨ (fact_9fdb227ae99d_2928 a b run_x) ∨ (fact_9fdb227ae99d_2466 a b run_x) ∨ (fact_9fdb227ae99d_3605 a b run_x) ∨ (fact_9fdb227ae99d_2479 a b run_x) ∨ (fact_9fdb227ae99d_2944 a b run_x) ∨ (fact_9fdb227ae99d_2931 a b run_x)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n219_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3179 a b run_x) ∨ (fact_9fdb227ae99d_3189 a b run_x) ∨ (fact_9fdb227ae99d_3731 a b run_x) ∨ (fact_9fdb227ae99d_5196 a b run_x) ∨ (fact_9fdb227ae99d_3490 a b run_x) ∨ (fact_9fdb227ae99d_3222 a b run_x) ∨ (fact_9fdb227ae99d_5349 a b run_x) ∨ (fact_9fdb227ae99d_3239 a b run_x) ∨ (fact_9fdb227ae99d_3551 a b run_x) ∨ (fact_9fdb227ae99d_3493 a b run_x))))
    (h1 : ((3 : Int) ≤ run_x))
    (h2 : (run_x ≤ ((2 : Int) + b)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n220_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n220_run_short (a b : Int)
    (h0 : (¬ ((((1 : Int) + a) - (4 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

end LRegionArithmetic

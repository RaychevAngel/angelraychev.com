import LQuadrantHpUnequalOutwardLongPrunedGeometry

namespace PolyominoFormal.LRegion
open CrossUnits

theorem outward_long_corner_right_impossible (a b p : Int)
    (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (T : Tiling a b 0 0 HalfPlane)
    (bar : T.world ⟨p,0,a,b,0,0⟩)
    (tip : T.world ⟨p+1,a+1,0,0,b,a⟩) : False := by
  apply HP_unequal_outward_long_pruned_no_shifted_anchor a b p
    (by omega) hb hab ha T
  · simpa only [shift,Int.zero_add,Int.add_zero] using bar
  · simpa only [shift,Int.zero_add,Int.add_zero,Int.add_comm] using tip

theorem outward_long_corner_left_impossible (a b p : Int)
    (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (T : Tiling a b 0 0 HalfPlane)
    (bar : T.world ⟨p,0,0,b,a,0⟩)
    (tip : T.world ⟨p-1,a+1,b,0,0,a⟩) : False := by
  apply outward_long_corner_right_impossible a b (-p) ha hb hab T.mirrorX
  · exact ⟨_,bar,rfl⟩
  · refine ⟨_,tip,?_⟩
    apply same_eq
    dsimp [Same,mirrorX]
    omega

def OutwardLongBoundaryCorner (a b : Int) (t u : Cross) : Prop :=
  t.y=0 ∧ t.north=b ∧ t.south=0 ∧
  u.y=a+1 ∧ u.north=0 ∧ u.south=a ∧
  ((t.east=a ∧ t.west=0 ∧ u.x=t.x+1 ∧ u.east=0 ∧ u.west=b) ∨
   (t.east=0 ∧ t.west=a ∧ u.x=t.x-1 ∧ u.east=b ∧ u.west=0))

def ForbiddenOutwardLongBoundaryCorner (a b : Int) (t u : Cross) : Prop :=
  OutwardLongBoundaryCorner a b t u ∨ OutwardLongBoundaryCorner a b u t

theorem avoid_outward_long_boundary_corner_ordered (a b : Int)
    (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (T : Tiling a b 0 0 HalfPlane) :
    ∀t u,T.world t → T.world u → ¬OutwardLongBoundaryCorner a b t u := by
  rintro ⟨p,y,e,n,w,s⟩ ⟨q,z,f,m,v,r⟩ ht hu
    ⟨hy,hn,hs,hz,hm,hr,arms⟩
  dsimp only at hy hn hs hz hm hr arms
  subst y; subst n; subst s; subst z; subst m; subst r
  rcases arms with ⟨he,hw,hq,hf,hv⟩ | ⟨he,hw,hq,hf,hv⟩
  · subst e; subst w; subst q; subst f; subst v
    exact outward_long_corner_right_impossible a b p ha hb hab T ht hu
  · subst e; subst w; subst q; subst f; subst v
    exact outward_long_corner_left_impossible a b p ha hb hab T ht hu

theorem avoid_outward_long_boundary_corner (a b : Int)
    (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (T : Tiling a b 0 0 HalfPlane) :
    ∀t u,T.world t → T.world u → ¬ForbiddenOutwardLongBoundaryCorner a b t u := by
  intro t u ht hu bad
  rcases bad with bad | bad
  · exact avoid_outward_long_boundary_corner_ordered a b ha hb hab T t u ht hu bad
  · exact avoid_outward_long_boundary_corner_ordered a b ha hb hab T u t hu ht bad

#print axioms outward_long_corner_right_impossible
#print axioms avoid_outward_long_boundary_corner
end PolyominoFormal.LRegion

import LHalfPlaneAlternatingEight
import LHalfPlaneOutwardLongCorner
namespace PolyominoFormal.LHalfPlaneAlternating
open CrossUnits THalfPlaneStarters THalfPlaneGaps LRegion
set_option maxHeartbeats 200000
set_option maxRecDepth 10000

def EightBars {a b : Int} (T : Tiling a b 0 0 HalfPlane) : Prop :=
  T.world ⟨-2*a-3,0,0,b,a,0⟩ ∧ T.world ⟨-2*a-2,0,a,b,0,0⟩ ∧
  T.world ⟨-1,0,0,b,a,0⟩ ∧ T.world ⟨0,0,a,b,0,0⟩ ∧
  T.world ⟨2*a+1,0,0,b,a,0⟩ ∧ T.world ⟨2*a+2,0,a,b,0,0⟩ ∧
  T.world ⟨4*a+3,0,0,b,a,0⟩ ∧ T.world ⟨4*a+4,0,a,b,0,0⟩

theorem no_left_long_starter_any {a b p : Int} (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (hp : 1≤p ∧ p≤2*a) (T : Tiling a b 0 0 HalfPlane) (bars : EightBars T)
    (anchor : T.world ⟨p,a+1,0,0,b,a⟩) : False := by
  rcases bars with ⟨hL0,hL1,h0,h1,h2,h3,hR0,hR1⟩
  by_cases far : 4≤p
  · exact no_left_long_starter_eight ha hb hab ⟨far,hp.2⟩ T hL0 hL1 h0 h1 h2 h3 hR0 hR1 anchor
  by_cases first : p=1
  · subst p
    apply outward_long_corner_right_impossible a b 0 ha hb hab T h1
    simpa only [Int.zero_add] using anchor
  · exact no_near_left_long_starter_strong ha hb hab (by omega) T h0 h1 h2 h3 anchor

theorem no_right_long_starter_any {a b p : Int} (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (hp : 1≤p ∧ p≤2*a) (T : Tiling a b 0 0 HalfPlane) (bars : EightBars T)
    (anchor : T.world ⟨p,a+1,b,0,0,a⟩) : False := by
  rcases bars with ⟨hL0,hL1,h0,h1,h2,h3,hR0,hR1⟩
  let U : Tiling a b 0 0 HalfPlane :=
    (T.mirrorX.translate (2*a+1) 0).congr (by intro x y; simp only [HalfPlane,Int.sub_zero])
  have member (t : Cross) (ht : T.world t) :
      U.world ⟨2*a+1-t.x,t.y,t.west,t.north,t.east,t.south⟩ := by
    refine ⟨mirrorX t,⟨t,ht,rfl⟩,?_⟩
    apply same_eq; dsimp [Same,shift,mirrorX]; omega
  apply no_left_long_starter_any ha hb hab (p:=2*a+1-p) (by omega) U _ (member _ anchor)
  refine ⟨?_,?_,?_,?_,?_,?_,?_,?_⟩
  · have h := member _ hR1
    simpa only [show 2*a+1-(4*a+4)=-2*a-3 by omega] using h
  · have h := member _ hR0
    simpa only [show 2*a+1-(4*a+3)=-2*a-2 by omega] using h
  · have h := member _ h3
    simpa only [show 2*a+1-(2*a+2)=-1 by omega] using h
  · have h := member _ h2
    simpa only [show 2*a+1-(2*a+1)=0 by omega] using h
  · have h := member _ h1
    simpa only [show 2*a+1-0=2*a+1 by omega] using h
  · have h := member _ h0
    simpa only [show 2*a+1-(-1)=2*a+2 by omega] using h
  · have h := member _ hL1
    simpa only [show 2*a+1-(-2*a-2)=4*a+3 by omega] using h
  · have h := member _ hL0
    simpa only [show 2*a+1-(-2*a-3)=4*a+4 by omega] using h

theorem no_row_one_starter {a b p : Int} (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (hp : 1≤p ∧ p≤2*a) (T : Tiling a b 0 0 HalfPlane) (bars : EightBars T)
    {t : Cross} (ht : T.world t) (st : LHalfPlaneLocal.Starter a b p 1 t) : False := by
  rcases st with (eq|eq)|st
  · subst t
    exact no_right_long_starter_any ha hb hab hp T bars (by simpa only [Int.add_comm] using ht)
  · subst t
    exact no_left_long_starter_any ha hb hab hp T bars (by simpa only [Int.add_comm] using ht)
  · rcases bars with ⟨_,_,h0,h1,h2,h3,_,_⟩
    exact no_short_starter ha hb hab hp T h0 h1 h2 h3 ht st

theorem row_one_horizontal {a b p : Int} (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (hp : 1≤p ∧ p≤2*a) (T : Tiling a b 0 0 HalfPlane) (bars : EightBars T) :
    ∃q l r,(l=a ∨ l=b) ∧ (r=0 ∨ r=l) ∧ 1≤q ∧ q≤p ∧ p≤q+l ∧ q+l≤2*a ∧
      T.world ⟨q+r,1,l-r,a+b-l,r,0⟩ := by
  obtain ⟨t,ht,hit⟩ := T.cover p 1 (by unfold HalfPlane; omega)
  have baseBars := bars
  rcases baseBars with ⟨_,_,h0,h1,h2,h3,_,_⟩
  have closed := base_closed T h0 h1 h2 h3
  have empty : ¬Base a b p 1 := by dsimp [Base,Contains]; omega
  have avoid : ∀{x y},Base a b x y → ¬Contains t x y :=
    fun h => avoid_closed closed ht hit empty h
  have form := LHalfPlaneLocal.run_forms (L:=1) (R:=2*a) (by omega) (by omega)
    hp.1 hp.2 (T.copies t ht) hit
    (avoid (by dsimp [Base,Contains]; omega))
    (avoid (by dsimp [Base,Contains]; omega))
    (avoid (by dsimp [Base,Contains]; omega))
    (by intro hx0 hx1; apply avoid; dsimp [Base,Contains]; omega)
  rcases form with ⟨q,l,r,hl,hr,eq,hq0,hq1,hq2,hq3⟩|st
  · exact ⟨q,l,r,hl,hr,hq0,hq1,hq2,hq3,by simpa only [eq] using ht⟩
  · exact False.elim (no_row_one_starter ha hb hab hp T bars ht st)

theorem first_horizontal_bar {a b : Int} (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (T : Tiling a b 0 0 HalfPlane) (bars : EightBars T) :
    ∃l r,(l=a ∨ l=b) ∧ (r=0 ∨ r=l) ∧
      T.world ⟨1+r,1,l-r,a+b-l,r,0⟩ := by
  obtain ⟨q,l,r,hl,hr,hq0,hq1,_,_,ht⟩ := row_one_horizontal (p:=1) ha hb hab (by omega) T bars
  have hq : q=1 := by omega
  subst q
  exact ⟨l,r,hl,hr,ht⟩

#print axioms row_one_horizontal
#print axioms first_horizontal_bar
end PolyominoFormal.LHalfPlaneAlternating

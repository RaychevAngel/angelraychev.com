import CornerCertificateAffineAlpha
import CornerCertificateAffineBeta
import CornerCertificateAffineGamma
import CornerCertificateAffineBetaTranspose
import CornerCertificateAffineGammaTranspose

namespace CornerCertificate
open CrossUnits

theorem large_local (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int) (k : Kind)
    (B : Int → Int → Prop)
    (copies : ∀ t, world t → Copy a 1 1 0 t)
    (separate : DisjointWorld world) (cover : CoversWindow world h)
    (ceiling : SelectedBelow world h) (closed : TileClosed world B)
    (bounded : Below h B) (clean : Clean k 0 0 B) :
    Transition world h k B := by
  cases k with
  | alpha => exact affine_alpha_local a ha world h B copies separate cover ceiling closed bounded clean
  | beta => exact affine_beta_local a ha world h B copies separate cover ceiling closed bounded clean
  | gamma => exact affine_gamma_local a ha world h B copies separate cover ceiling closed bounded clean
  | betaTranspose => exact affine_betaTranspose_local a ha world h B copies separate cover ceiling closed bounded clean
  | gammaTranspose => exact affine_gammaTranspose_local a ha world h B copies separate cover ceiling closed bounded clean

#print axioms large_local

end CornerCertificate

import LRunCertificates
import LQuadrantHpBoundaryallUnequalVleftEastneighborPrunedArithmetic
import TilingCore
import TPlaneGeometry
import TilingSymmetry
import LHalfPlaneBoundaryTips
import LHalfPlaneBoundaryPairPruning
import LHalfPlaneShortbarPairs
import LHalfPlaneOutwardLongCorner
import LHalfPlaneShortbarBranch
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PolyominoFormal.LRegion
open CrossUnits
def HP_boundaryall_unequal_vleft_eastneighbor_pruned_M (a b : Int) : Int := 2*(a+b+1)
def HP_boundaryall_unequal_vleft_eastneighbor_pruned_Box (a b x y : Int) : Prop := -HP_boundaryall_unequal_vleft_eastneighbor_pruned_M a b ≤ x ∧ 0≤y ∧ x≤HP_boundaryall_unequal_vleft_eastneighbor_pruned_M a b ∧ y≤HP_boundaryall_unequal_vleft_eastneighbor_pruned_M a b
def HP_boundaryall_unequal_vleft_eastneighbor_pruned_Inside (t : Cross) : Prop := 0≤t.y-t.south
def HP_boundaryall_unequal_vleft_eastneighbor_pruned_ForbiddenPair (a b : Int) (t u : Cross) : Prop := ((((ForbiddenSameBoundaryBars a b t u) ∨ ForbiddenLongBoundaryCorner a b t u) ∨ ForbiddenSameShortBars a b t u) ∨ ForbiddenOutwardLongBoundaryCorner a b t u) ∨ ForbiddenShortUprightLong a b t u

theorem HP_boundaryall_unequal_vleft_eastneighbor_pruned_node001 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_vleft_eastneighbor_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_vleft_eastneighbor_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_boundaryall_unequal_vleft_eastneighbor_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht2 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk (-1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_3 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have in2 := inside (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk (-1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have allowed2 := avoid (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (-1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (-1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht2 ht3
  apply avoidRunRight [(Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)), (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a), (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (-1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b)] (1 : Int) b ((-1 : Int) * a)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_eastneighbor_pruned_n001_run_four a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_eastneighbor_pruned_n001_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated))
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_eastneighbor_pruned_n001_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated))
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_eastneighbor_pruned_n001_run_empty a b run_x (ha) (hlong) (hx1) (hx0) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated))
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_eastneighbor_pruned_n001_run_floor a b run_x ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx1) (hx0)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_eastneighbor_pruned_n001_run_left a b (hlong) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated))
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_eastneighbor_pruned_n001_run_right a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_eastneighbor_pruned_n001_run_tall a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (hstrict)

theorem HP_boundaryall_unequal_vleft_eastneighbor_pruned_node002 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_vleft_eastneighbor_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_vleft_eastneighbor_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_boundaryall_unequal_vleft_eastneighbor_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht2 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have in2 := inside (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have allowed2 := avoid (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht3
  apply avoidRun [(Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)), (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a), (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int))] ((-1 : Int) * b) (-1 : Int) (2 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_eastneighbor_pruned_n002_run_four a b (hb) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated))
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_eastneighbor_pruned_n002_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated))
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_eastneighbor_pruned_n002_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated))
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_eastneighbor_pruned_n002_run_empty a b run_x (hx1) (hx0) (hstrict) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated))
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_eastneighbor_pruned_n002_run_floor a b run_x ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx0) (hx1)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_eastneighbor_pruned_n002_run_left a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_eastneighbor_pruned_n002_run_right a b (hlong) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated))
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_eastneighbor_pruned_n002_run_tall a b (hb) (hstrict) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated))

theorem HP_boundaryall_unequal_vleft_eastneighbor_pruned_node000 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_vleft_eastneighbor_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_vleft_eastneighbor_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_boundaryall_unequal_vleft_eastneighbor_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht2 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have in2 := inside (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1
  have allowed2 := avoid (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht2
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht2
  have support : HP_boundaryall_unequal_vleft_eastneighbor_pruned_Box a b (-1 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_eastneighbor_pruned_n000_point a b (hlong) (hb) ((by simpa only [HP_boundaryall_unequal_vleft_eastneighbor_pruned_Box,HP_boundaryall_unequal_vleft_eastneighbor_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (-1 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (-1 : Int) (1 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_eastneighbor_pruned_n000_empty a b (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-1 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht2
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_eastneighbor_pruned_n000_o0 a b jx jy (hb) (sep2).2.2.2 (sep0).2.1 (insideT) (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_eastneighbor_pruned_n000_o1 a b jx jy (insideT) (hit) (hlong) (hb) (sep1).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (-1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_vleft_eastneighbor_pruned_n000_o2 a b jx jy (hb) (insideT) (hit) ((by simpa only [Same,eq_comm] using absent)) (allowed)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_unequal_vleft_eastneighbor_pruned_node001 a b ha hb hstrict hlong hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_eastneighbor_pruned_n000_o3 a b jx jy (hit) (sep2).2.2.1 (sep1).2.2.1 (sep0).2.1 (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_eastneighbor_pruned_n000_o4 a b jx jy (hb) (allowed) (hit) (hlong) (sep1).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_eastneighbor_pruned_n000_o5 a b jx jy (sep2).2.1 (sep0).2.1 (hb) (hit) (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) (1 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_vleft_eastneighbor_pruned_n000_o6 a b jx jy (hit) (sep0).2.1 (insideT) (hlong) (hb) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_unequal_vleft_eastneighbor_pruned_node002 a b ha hb hstrict hlong hexception world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_vleft_eastneighbor_pruned_n000_o7 a b jx jy (sep1).2.2.1 (insideT) (hlong) (hb) (hit) (sep0).2.1

theorem HP_boundaryall_unequal_vleft_eastneighbor_pruned_bounded_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_vleft_eastneighbor_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_vleft_eastneighbor_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (disjoint : ∀ t u x y, world t → world u → Contains t x y → Contains u x y → t=u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_boundaryall_unequal_vleft_eastneighbor_pruned_ForbiddenPair a b t u)
    (anchor0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (anchor1 : world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (anchor2 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have sep : ∀ t u, world t → world u → t=u ∨ Apart t u := by
    intro t u ht hu
    by_cases eq : t=u
    · exact Or.inl eq
    · right
      apply TPlane.apart_of_no_common_nonnegative t u
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies t ht)
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies u hu)
      · intro x y hx hy; exact eq (disjoint t u x y ht hu hx hy)
  have rootap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases sep (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) anchor0 anchor1 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) anchor0 anchor2 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) anchor1 anchor2 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  exact HP_boundaryall_unequal_vleft_eastneighbor_pruned_node000 a b ha hb hstrict hlong hexception world copies inside cover sep avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair anchor0 anchor1 anchor2 rootap0_1 rootap0_2 rootap1_2

theorem HP_boundaryall_unequal_vleft_eastneighbor_pruned_anchored_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor0 : T.world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (anchor1 : T.world (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (anchor2 : T.world (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    : False := by
  have avoid : ∀ t, T.world t → ¬ForbiddenBoundaryTip a b t := by
    exact unequal_avoid_boundary_tips a b (by omega) (by omega) (by omega) T
  have avoidPair : ∀t u,T.world t → T.world u → ¬HP_boundaryall_unequal_vleft_eastneighbor_pruned_ForbiddenPair a b t u := by
    intro t u ht hu bad
    rcases bad with bad | bad
    ·
      rcases bad with bad | bad
      ·
        rcases bad with bad | bad
        ·
          rcases bad with bad | bad
          ·
            exact avoid_same_boundary_bars a b (by omega) (by omega) (by omega) T t u ht hu bad
          ·
            exact avoid_long_boundary_corner a b (by omega) (by omega) (by omega) T t u ht hu bad
        ·
          exact avoid_same_short_bars a b (by omega) (by omega) T t u ht hu bad
      ·
        exact avoid_outward_long_boundary_corner a b (by omega) (by omega) (by omega) T t u ht hu bad
    ·
      exact avoid_short_upright_long a b (by omega) (by omega) (by omega) T t u ht hu bad
  apply HP_boundaryall_unequal_vleft_eastneighbor_pruned_bounded_obstruction a b ha hb hstrict hlong hexception T.world T.copies ?_ ?_ T.disjoint (LRunCertificates.tiling_extended_run_obstruction (by omega) (by omega) T) (LRunCertificates.tiling_extended_down_run_obstruction (by omega) (by omega) T) (LRunCertificates.tiling_extended_right_run_obstruction (by omega) (by omega) T) (LRunCertificates.tiling_extended_left_run_obstruction (by omega) (by omega) T) avoid avoidPair anchor0 anchor1 anchor2
  · intro t ht
    have nn := TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (T.copies t ht)
    exact T.inside t ht t.x (t.y-t.south) (by
      unfold Contains; unfold TPlane.Nonnegative at nn; right; omega)
  · intro x y h; exact T.cover x y h.2.1
theorem HP_boundaryall_unequal_vleft_eastneighbor_pruned_no_shifted_anchor (a b p : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hexception : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor0 : T.world (shift p 0 (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int))))
    (anchor1 : T.world (shift p 0 (Cross.mk (1 : Int) ((1 : Int) + a) (0 : Int) (0 : Int) b a)))
    (anchor2 : T.world (shift p 0 (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int))))
    : False := by
  let U : Tiling a b 0 0 HalfPlane :=
    (T.translate (-p) 0).congr (by intro x y; simp only [HalfPlane,Int.sub_zero])
  apply HP_boundaryall_unequal_vleft_eastneighbor_pruned_anchored_obstruction a b ha hb hstrict hlong hexception U
  · refine ⟨_,anchor0,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
  · refine ⟨_,anchor1,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
  · refine ⟨_,anchor2,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
#print axioms HP_boundaryall_unequal_vleft_eastneighbor_pruned_no_shifted_anchor
#print axioms HP_boundaryall_unequal_vleft_eastneighbor_pruned_bounded_obstruction
end PolyominoFormal.LRegion

import LRunCertificates
import LQuadrantHpOptimizedUnequalMixedNonexceptionDeltaTwoPrunedArithmetic
import TilingCore
import TPlaneGeometry
import TilingSymmetry
import LHalfPlaneBoundaryTips
import LHalfPlaneBoundaryPairPruning
import LHalfPlaneShortbarPairs
import LHalfPlaneOutwardLongCorner
import LHalfPlaneShortbarBranch
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PolyominoFormal.LRegion
open CrossUnits
def HP_optimized_unequal_mixed_nonexception_delta_two_pruned_M (a b : Int) : Int := 9*(a+b+1)
def HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Box (a b x y : Int) : Prop := -HP_optimized_unequal_mixed_nonexception_delta_two_pruned_M a b ≤ x ∧ 0≤y ∧ x≤HP_optimized_unequal_mixed_nonexception_delta_two_pruned_M a b ∧ y≤HP_optimized_unequal_mixed_nonexception_delta_two_pruned_M a b
def HP_optimized_unequal_mixed_nonexception_delta_two_pruned_Inside (t : Cross) : Prop := 0≤t.y-t.south
def HP_optimized_unequal_mixed_nonexception_delta_two_pruned_ForbiddenPair (a b : Int) (t u : Cross) : Prop := ((((ForbiddenSameBoundaryBars a b t u) ∨ ForbiddenLongBoundaryCorner a b t u) ∨ ForbiddenSameShortBars a b t u) ∨ ForbiddenOutwardLongBoundaryCorner a b t u) ∨ ForbiddenShortUprightLong a b t u

end PolyominoFormal.LRegion

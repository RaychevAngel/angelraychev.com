import CornerCertificateFourAlphaData

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

namespace CornerCertificate
open CrossUnits


section FourAlpha
variable (world : Cross → Prop) (h : Int)
    (copies : ∀ t, world t → Copy 4 1 1 0 t)
    (separate : DisjointWorld world) (cover : CoversWindow world h)
    (ceiling : SelectedBelow world h)

theorem four_alpha_node0003 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0003 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha four_alpha_occ0003 .gamma (2 : Int) (1 : Int) four_alpha_check0003 B state
theorem four_alpha_node0004 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0004 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha four_alpha_occ0004 .beta (2 : Int) (1 : Int) four_alpha_check0004 B state
include copies separate cover ceiling in
theorem four_alpha_node0007 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0007 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0007 ((4 : Int),(1 : Int)) four_alpha_branches0007 copies separate cover ceiling four_alpha_check0007 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0007, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0008 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0008 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0008 ((4 : Int),(1 : Int)) four_alpha_branches0008 copies separate cover ceiling four_alpha_check0008 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0008, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0006 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0006 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0006 ((3 : Int),(1 : Int)) four_alpha_branches0006 copies separate cover ceiling four_alpha_check0006 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0006, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_alpha_node0007 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0008 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0009 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0009 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0009 ((3 : Int),(1 : Int)) four_alpha_branches0009 copies separate cover ceiling four_alpha_check0009 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0009, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0010 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0010 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0010 ((3 : Int),(1 : Int)) four_alpha_branches0010 copies separate cover ceiling four_alpha_check0010 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0010, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0014 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0014 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0014 ((5 : Int),(1 : Int)) four_alpha_branches0014 copies separate cover ceiling four_alpha_check0014 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0014, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0015 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0015 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0015 ((5 : Int),(1 : Int)) four_alpha_branches0015 copies separate cover ceiling four_alpha_check0015 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0015, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0016 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0016 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0016 ((5 : Int),(1 : Int)) four_alpha_branches0016 copies separate cover ceiling four_alpha_check0016 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0016, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0017 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0017 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0017 ((5 : Int),(1 : Int)) four_alpha_branches0017 copies separate cover ceiling four_alpha_check0017 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0017, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0018 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0018 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0018 ((5 : Int),(1 : Int)) four_alpha_branches0018 copies separate cover ceiling four_alpha_check0018 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0018, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0019 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0019 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0019 ((5 : Int),(1 : Int)) four_alpha_branches0019 copies separate cover ceiling four_alpha_check0019 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0019, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0020 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0020 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0020 ((5 : Int),(1 : Int)) four_alpha_branches0020 copies separate cover ceiling four_alpha_check0020 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0020, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0021 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0021 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0021 ((5 : Int),(1 : Int)) four_alpha_branches0021 copies separate cover ceiling four_alpha_check0021 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0021, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0022 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0022 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0022 ((5 : Int),(1 : Int)) four_alpha_branches0022 copies separate cover ceiling four_alpha_check0022 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0022, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0023 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0023 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0023 ((5 : Int),(1 : Int)) four_alpha_branches0023 copies separate cover ceiling four_alpha_check0023 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0023, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0024 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0024 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0024 ((5 : Int),(1 : Int)) four_alpha_branches0024 copies separate cover ceiling four_alpha_check0024 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0024, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0013 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0013 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0013 ((0 : Int),(6 : Int)) four_alpha_branches0013 copies separate cover ceiling four_alpha_check0013 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0013, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_alpha_node0014 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0015 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0016 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0017 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0018 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0019 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0020 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0021 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0022 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0023 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0024 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0026 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0026 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0026 ((5 : Int),(1 : Int)) four_alpha_branches0026 copies separate cover ceiling four_alpha_check0026 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0026, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0027 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0027 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0027 ((5 : Int),(1 : Int)) four_alpha_branches0027 copies separate cover ceiling four_alpha_check0027 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0027, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0028 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0028 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0028 ((5 : Int),(1 : Int)) four_alpha_branches0028 copies separate cover ceiling four_alpha_check0028 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0028, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0029 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0029 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0029 ((5 : Int),(1 : Int)) four_alpha_branches0029 copies separate cover ceiling four_alpha_check0029 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0029, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0030 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0030 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0030 ((5 : Int),(1 : Int)) four_alpha_branches0030 copies separate cover ceiling four_alpha_check0030 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0030, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0031 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0031 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0031 ((5 : Int),(1 : Int)) four_alpha_branches0031 copies separate cover ceiling four_alpha_check0031 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0031, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0032 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0032 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0032 ((5 : Int),(1 : Int)) four_alpha_branches0032 copies separate cover ceiling four_alpha_check0032 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0032, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0033 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0033 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0033 ((5 : Int),(1 : Int)) four_alpha_branches0033 copies separate cover ceiling four_alpha_check0033 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0033, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0034 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0034 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0034 ((5 : Int),(1 : Int)) four_alpha_branches0034 copies separate cover ceiling four_alpha_check0034 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0034, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0035 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0035 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0035 ((5 : Int),(1 : Int)) four_alpha_branches0035 copies separate cover ceiling four_alpha_check0035 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0035, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0036 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0036 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0036 ((5 : Int),(1 : Int)) four_alpha_branches0036 copies separate cover ceiling four_alpha_check0036 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0036, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0025 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0025 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0025 ((0 : Int),(6 : Int)) four_alpha_branches0025 copies separate cover ceiling four_alpha_check0025 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0025, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_alpha_node0026 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0027 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0028 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0029 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0030 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0031 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0032 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0033 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0034 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0035 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0036 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0012 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0012 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0012 ((4 : Int),(1 : Int)) four_alpha_branches0012 copies separate cover ceiling four_alpha_check0012 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0012, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_alpha_node0013 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0025 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0039 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0039 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0039 ((5 : Int),(1 : Int)) four_alpha_branches0039 copies separate cover ceiling four_alpha_check0039 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0039, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0040 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0040 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0040 ((5 : Int),(1 : Int)) four_alpha_branches0040 copies separate cover ceiling four_alpha_check0040 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0040, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0041 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0041 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0041 ((5 : Int),(1 : Int)) four_alpha_branches0041 copies separate cover ceiling four_alpha_check0041 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0041, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0042 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0042 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0042 ((5 : Int),(1 : Int)) four_alpha_branches0042 copies separate cover ceiling four_alpha_check0042 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0042, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0043 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0043 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0043 ((5 : Int),(1 : Int)) four_alpha_branches0043 copies separate cover ceiling four_alpha_check0043 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0043, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0044 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0044 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0044 ((5 : Int),(1 : Int)) four_alpha_branches0044 copies separate cover ceiling four_alpha_check0044 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0044, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0045 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0045 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0045 ((5 : Int),(1 : Int)) four_alpha_branches0045 copies separate cover ceiling four_alpha_check0045 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0045, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0046 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0046 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0046 ((5 : Int),(1 : Int)) four_alpha_branches0046 copies separate cover ceiling four_alpha_check0046 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0046, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0047 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0047 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0047 ((5 : Int),(1 : Int)) four_alpha_branches0047 copies separate cover ceiling four_alpha_check0047 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0047, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0048 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0048 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0048 ((5 : Int),(1 : Int)) four_alpha_branches0048 copies separate cover ceiling four_alpha_check0048 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0048, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0049 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0049 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0049 ((5 : Int),(1 : Int)) four_alpha_branches0049 copies separate cover ceiling four_alpha_check0049 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0049, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0050 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0050 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0050 ((5 : Int),(1 : Int)) four_alpha_branches0050 copies separate cover ceiling four_alpha_check0050 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0050, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0051 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0051 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0051 ((5 : Int),(1 : Int)) four_alpha_branches0051 copies separate cover ceiling four_alpha_check0051 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0051, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0038 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0038 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0038 ((0 : Int),(6 : Int)) four_alpha_branches0038 copies separate cover ceiling four_alpha_check0038 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0038, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_alpha_node0039 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0040 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0041 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0042 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0043 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0044 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0045 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0046 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0047 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0048 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0049 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0050 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0051 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0053 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0053 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0053 ((5 : Int),(1 : Int)) four_alpha_branches0053 copies separate cover ceiling four_alpha_check0053 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0053, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0054 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0054 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0054 ((5 : Int),(1 : Int)) four_alpha_branches0054 copies separate cover ceiling four_alpha_check0054 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0054, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0055 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0055 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0055 ((5 : Int),(1 : Int)) four_alpha_branches0055 copies separate cover ceiling four_alpha_check0055 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0055, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0056 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0056 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0056 ((5 : Int),(1 : Int)) four_alpha_branches0056 copies separate cover ceiling four_alpha_check0056 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0056, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0057 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0057 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0057 ((5 : Int),(1 : Int)) four_alpha_branches0057 copies separate cover ceiling four_alpha_check0057 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0057, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0058 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0058 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0058 ((5 : Int),(1 : Int)) four_alpha_branches0058 copies separate cover ceiling four_alpha_check0058 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0058, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0059 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0059 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0059 ((5 : Int),(1 : Int)) four_alpha_branches0059 copies separate cover ceiling four_alpha_check0059 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0059, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0060 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0060 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0060 ((5 : Int),(1 : Int)) four_alpha_branches0060 copies separate cover ceiling four_alpha_check0060 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0060, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0061 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0061 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0061 ((5 : Int),(1 : Int)) four_alpha_branches0061 copies separate cover ceiling four_alpha_check0061 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0061, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0062 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0062 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0062 ((5 : Int),(1 : Int)) four_alpha_branches0062 copies separate cover ceiling four_alpha_check0062 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0062, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0063 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0063 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0063 ((5 : Int),(1 : Int)) four_alpha_branches0063 copies separate cover ceiling four_alpha_check0063 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0063, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0064 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0064 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0064 ((5 : Int),(1 : Int)) four_alpha_branches0064 copies separate cover ceiling four_alpha_check0064 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0064, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0065 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0065 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0065 ((5 : Int),(1 : Int)) four_alpha_branches0065 copies separate cover ceiling four_alpha_check0065 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0065, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0052 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0052 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0052 ((0 : Int),(6 : Int)) four_alpha_branches0052 copies separate cover ceiling four_alpha_check0052 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0052, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_alpha_node0053 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0054 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0055 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0056 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0057 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0058 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0059 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0060 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0061 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0062 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0063 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0064 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0065 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0037 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0037 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0037 ((4 : Int),(1 : Int)) four_alpha_branches0037 copies separate cover ceiling four_alpha_check0037 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0037, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_alpha_node0038 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0052 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0011 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0011 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0011 ((2 : Int),(3 : Int)) four_alpha_branches0011 copies separate cover ceiling four_alpha_check0011 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0011, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_alpha_node0012 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0037 world h copies separate cover ceiling nextB nextState
theorem four_alpha_node0067 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0067 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha four_alpha_occ0067 .alpha (3 : Int) (3 : Int) four_alpha_check0067 B state
include copies separate cover ceiling in
theorem four_alpha_node0068 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0068 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0068 ((4 : Int),(1 : Int)) four_alpha_branches0068 copies separate cover ceiling four_alpha_check0068 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0068, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0069 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0069 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0069 ((4 : Int),(1 : Int)) four_alpha_branches0069 copies separate cover ceiling four_alpha_check0069 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0069, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0070 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0070 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0070 ((4 : Int),(1 : Int)) four_alpha_branches0070 copies separate cover ceiling four_alpha_check0070 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0070, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0071 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0071 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0071 ((4 : Int),(1 : Int)) four_alpha_branches0071 copies separate cover ceiling four_alpha_check0071 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0071, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0066 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0066 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0066 ((2 : Int),(3 : Int)) four_alpha_branches0066 copies separate cover ceiling four_alpha_check0066 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0066, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_alpha_node0067 world h nextB nextState
  · exact four_alpha_node0068 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0069 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0070 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0071 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0072 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0072 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0072 ((3 : Int),(1 : Int)) four_alpha_branches0072 copies separate cover ceiling four_alpha_check0072 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0072, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0073 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0073 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0073 ((3 : Int),(1 : Int)) four_alpha_branches0073 copies separate cover ceiling four_alpha_check0073 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0073, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0005 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0005 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0005 ((2 : Int),(2 : Int)) four_alpha_branches0005 copies separate cover ceiling four_alpha_check0005 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0005, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_alpha_node0006 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0009 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0010 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0011 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0066 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0072 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0073 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0002 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0002 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0002 ((2 : Int),(0 : Int)) four_alpha_branches0002 copies separate cover ceiling four_alpha_check0002 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0002, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_alpha_node0003 world h nextB nextState
  · exact four_alpha_node0004 world h nextB nextState
  · exact four_alpha_node0005 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0075 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0075 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0075 ((2 : Int),(1 : Int)) four_alpha_branches0075 copies separate cover ceiling four_alpha_check0075 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0075, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0077 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0077 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0077 ((2 : Int),(2 : Int)) four_alpha_branches0077 copies separate cover ceiling four_alpha_check0077 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0077, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0078 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0078 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0078 ((2 : Int),(2 : Int)) four_alpha_branches0078 copies separate cover ceiling four_alpha_check0078 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0078, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0076 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0076 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0076 ((2 : Int),(1 : Int)) four_alpha_branches0076 copies separate cover ceiling four_alpha_check0076 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0076, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_alpha_node0077 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0078 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0079 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0079 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0079 ((2 : Int),(1 : Int)) four_alpha_branches0079 copies separate cover ceiling four_alpha_check0079 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0079, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0074 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0074 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0074 ((2 : Int),(0 : Int)) four_alpha_branches0074 copies separate cover ceiling four_alpha_check0074 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0074, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_alpha_node0075 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0076 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0079 world h copies separate cover ceiling nextB nextState
theorem four_alpha_node0081 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0081 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha four_alpha_occ0081 .gammaTranspose (2 : Int) (1 : Int) four_alpha_check0081 B state
include copies separate cover ceiling in
theorem four_alpha_node0083 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0083 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0083 ((2 : Int),(3 : Int)) four_alpha_branches0083 copies separate cover ceiling four_alpha_check0083 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0083, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0087 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0087 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0087 ((2 : Int),(4 : Int)) four_alpha_branches0087 copies separate cover ceiling four_alpha_check0087 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0087, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0088 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0088 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0088 ((2 : Int),(4 : Int)) four_alpha_branches0088 copies separate cover ceiling four_alpha_check0088 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0088, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0089 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0089 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0089 ((2 : Int),(4 : Int)) four_alpha_branches0089 copies separate cover ceiling four_alpha_check0089 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0089, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0090 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0090 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0090 ((2 : Int),(4 : Int)) four_alpha_branches0090 copies separate cover ceiling four_alpha_check0090 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0090, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0091 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0091 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0091 ((2 : Int),(4 : Int)) four_alpha_branches0091 copies separate cover ceiling four_alpha_check0091 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0091, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0092 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0092 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0092 ((2 : Int),(4 : Int)) four_alpha_branches0092 copies separate cover ceiling four_alpha_check0092 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0092, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0093 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0093 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0093 ((2 : Int),(4 : Int)) four_alpha_branches0093 copies separate cover ceiling four_alpha_check0093 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0093, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0094 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0094 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0094 ((2 : Int),(4 : Int)) four_alpha_branches0094 copies separate cover ceiling four_alpha_check0094 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0094, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0095 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0095 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0095 ((2 : Int),(4 : Int)) four_alpha_branches0095 copies separate cover ceiling four_alpha_check0095 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0095, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0096 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0096 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0096 ((2 : Int),(4 : Int)) four_alpha_branches0096 copies separate cover ceiling four_alpha_check0096 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0096, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0097 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0097 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0097 ((2 : Int),(4 : Int)) four_alpha_branches0097 copies separate cover ceiling four_alpha_check0097 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0097, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0086 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0086 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0086 ((0 : Int),(6 : Int)) four_alpha_branches0086 copies separate cover ceiling four_alpha_check0086 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0086, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_alpha_node0087 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0088 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0089 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0090 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0091 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0092 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0093 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0094 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0095 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0096 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0097 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0099 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0099 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0099 ((2 : Int),(4 : Int)) four_alpha_branches0099 copies separate cover ceiling four_alpha_check0099 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0099, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0100 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0100 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0100 ((2 : Int),(4 : Int)) four_alpha_branches0100 copies separate cover ceiling four_alpha_check0100 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0100, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0101 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0101 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0101 ((2 : Int),(4 : Int)) four_alpha_branches0101 copies separate cover ceiling four_alpha_check0101 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0101, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0102 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0102 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0102 ((2 : Int),(4 : Int)) four_alpha_branches0102 copies separate cover ceiling four_alpha_check0102 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0102, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0103 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0103 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0103 ((2 : Int),(4 : Int)) four_alpha_branches0103 copies separate cover ceiling four_alpha_check0103 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0103, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0104 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0104 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0104 ((2 : Int),(4 : Int)) four_alpha_branches0104 copies separate cover ceiling four_alpha_check0104 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0104, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0105 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0105 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0105 ((2 : Int),(4 : Int)) four_alpha_branches0105 copies separate cover ceiling four_alpha_check0105 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0105, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0106 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0106 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0106 ((2 : Int),(4 : Int)) four_alpha_branches0106 copies separate cover ceiling four_alpha_check0106 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0106, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0107 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0107 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0107 ((2 : Int),(4 : Int)) four_alpha_branches0107 copies separate cover ceiling four_alpha_check0107 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0107, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0108 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0108 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0108 ((2 : Int),(4 : Int)) four_alpha_branches0108 copies separate cover ceiling four_alpha_check0108 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0108, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0109 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0109 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0109 ((2 : Int),(4 : Int)) four_alpha_branches0109 copies separate cover ceiling four_alpha_check0109 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0109, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0098 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0098 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0098 ((0 : Int),(6 : Int)) four_alpha_branches0098 copies separate cover ceiling four_alpha_check0098 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0098, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_alpha_node0099 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0100 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0101 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0102 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0103 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0104 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0105 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0106 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0107 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0108 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0109 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0085 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0085 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0085 ((4 : Int),(1 : Int)) four_alpha_branches0085 copies separate cover ceiling four_alpha_check0085 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0085, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_alpha_node0086 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0098 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0112 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0112 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0112 ((2 : Int),(4 : Int)) four_alpha_branches0112 copies separate cover ceiling four_alpha_check0112 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0112, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0113 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0113 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0113 ((2 : Int),(4 : Int)) four_alpha_branches0113 copies separate cover ceiling four_alpha_check0113 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0113, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0114 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0114 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0114 ((2 : Int),(4 : Int)) four_alpha_branches0114 copies separate cover ceiling four_alpha_check0114 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0114, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0115 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0115 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0115 ((2 : Int),(4 : Int)) four_alpha_branches0115 copies separate cover ceiling four_alpha_check0115 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0115, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0116 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0116 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0116 ((2 : Int),(4 : Int)) four_alpha_branches0116 copies separate cover ceiling four_alpha_check0116 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0116, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0117 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0117 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0117 ((2 : Int),(4 : Int)) four_alpha_branches0117 copies separate cover ceiling four_alpha_check0117 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0117, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0118 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0118 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0118 ((2 : Int),(4 : Int)) four_alpha_branches0118 copies separate cover ceiling four_alpha_check0118 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0118, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0119 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0119 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0119 ((2 : Int),(4 : Int)) four_alpha_branches0119 copies separate cover ceiling four_alpha_check0119 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0119, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0120 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0120 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0120 ((2 : Int),(4 : Int)) four_alpha_branches0120 copies separate cover ceiling four_alpha_check0120 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0120, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0121 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0121 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0121 ((2 : Int),(4 : Int)) four_alpha_branches0121 copies separate cover ceiling four_alpha_check0121 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0121, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0122 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0122 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0122 ((2 : Int),(4 : Int)) four_alpha_branches0122 copies separate cover ceiling four_alpha_check0122 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0122, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0111 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0111 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0111 ((0 : Int),(6 : Int)) four_alpha_branches0111 copies separate cover ceiling four_alpha_check0111 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0111, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_alpha_node0112 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0113 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0114 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0115 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0116 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0117 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0118 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0119 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0120 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0121 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0122 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0124 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0124 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0124 ((2 : Int),(4 : Int)) four_alpha_branches0124 copies separate cover ceiling four_alpha_check0124 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0124, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0125 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0125 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0125 ((2 : Int),(4 : Int)) four_alpha_branches0125 copies separate cover ceiling four_alpha_check0125 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0125, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0126 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0126 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0126 ((2 : Int),(4 : Int)) four_alpha_branches0126 copies separate cover ceiling four_alpha_check0126 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0126, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0127 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0127 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0127 ((2 : Int),(4 : Int)) four_alpha_branches0127 copies separate cover ceiling four_alpha_check0127 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0127, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0128 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0128 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0128 ((2 : Int),(4 : Int)) four_alpha_branches0128 copies separate cover ceiling four_alpha_check0128 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0128, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0129 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0129 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0129 ((2 : Int),(4 : Int)) four_alpha_branches0129 copies separate cover ceiling four_alpha_check0129 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0129, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0130 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0130 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0130 ((2 : Int),(4 : Int)) four_alpha_branches0130 copies separate cover ceiling four_alpha_check0130 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0130, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0131 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0131 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0131 ((2 : Int),(4 : Int)) four_alpha_branches0131 copies separate cover ceiling four_alpha_check0131 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0131, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0132 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0132 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0132 ((2 : Int),(4 : Int)) four_alpha_branches0132 copies separate cover ceiling four_alpha_check0132 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0132, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0133 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0133 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0133 ((2 : Int),(4 : Int)) four_alpha_branches0133 copies separate cover ceiling four_alpha_check0133 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0133, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0134 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0134 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0134 ((2 : Int),(4 : Int)) four_alpha_branches0134 copies separate cover ceiling four_alpha_check0134 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0134, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0123 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0123 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0123 ((0 : Int),(6 : Int)) four_alpha_branches0123 copies separate cover ceiling four_alpha_check0123 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0123, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_alpha_node0124 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0125 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0126 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0127 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0128 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0129 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0130 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0131 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0132 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0133 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0134 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0110 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0110 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0110 ((4 : Int),(1 : Int)) four_alpha_branches0110 copies separate cover ceiling four_alpha_check0110 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0110, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_alpha_node0111 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0123 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0084 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0084 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0084 ((2 : Int),(3 : Int)) four_alpha_branches0084 copies separate cover ceiling four_alpha_check0084 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0084, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_alpha_node0085 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0110 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0136 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0136 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0136 ((2 : Int),(3 : Int)) four_alpha_branches0136 copies separate cover ceiling four_alpha_check0136 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0136, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0135 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0135 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0135 ((3 : Int),(1 : Int)) four_alpha_branches0135 copies separate cover ceiling four_alpha_check0135 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0135, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact four_alpha_node0136 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0137 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0137 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0137 ((3 : Int),(1 : Int)) four_alpha_branches0137 copies separate cover ceiling four_alpha_check0137 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0137, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0139 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0139 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0139 ((2 : Int),(3 : Int)) four_alpha_branches0139 copies separate cover ceiling four_alpha_check0139 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0139, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0138 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0138 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0138 ((3 : Int),(1 : Int)) four_alpha_branches0138 copies separate cover ceiling four_alpha_check0138 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0138, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact four_alpha_node0139 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0082 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0082 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0082 ((2 : Int),(2 : Int)) four_alpha_branches0082 copies separate cover ceiling four_alpha_check0082 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0082, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_alpha_node0083 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0084 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0135 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0137 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0138 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0080 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0080 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0080 ((1 : Int),(1 : Int)) four_alpha_branches0080 copies separate cover ceiling four_alpha_check0080 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0080, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_alpha_node0081 world h nextB nextState
  · exact four_alpha_node0082 world h copies separate cover ceiling nextB nextState
theorem four_alpha_node0140 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0140 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha four_alpha_occ0140 .alpha (1 : Int) (1 : Int) four_alpha_check0140 B state
include copies separate cover ceiling in
theorem four_alpha_node0142 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0142 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0142 ((2 : Int),(1 : Int)) four_alpha_branches0142 copies separate cover ceiling four_alpha_check0142 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0142, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0143 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0143 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0143 ((2 : Int),(1 : Int)) four_alpha_branches0143 copies separate cover ceiling four_alpha_check0143 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0143, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0141 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0141 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0141 ((1 : Int),(1 : Int)) four_alpha_branches0141 copies separate cover ceiling four_alpha_check0141 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0141, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_alpha_node0142 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0143 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0001 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0001 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0001 ((1 : Int),(0 : Int)) four_alpha_branches0001 copies separate cover ceiling four_alpha_check0001 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0001, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_alpha_node0002 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0074 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0080 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0140 world h nextB nextState
  · exact four_alpha_node0141 world h copies separate cover ceiling nextB nextState
theorem four_alpha_node0145 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0145 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha four_alpha_occ0145 .gamma (1 : Int) (1 : Int) four_alpha_check0145 B state
theorem four_alpha_node0146 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0146 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha four_alpha_occ0146 .beta (1 : Int) (1 : Int) four_alpha_check0146 B state
include copies separate cover ceiling in
theorem four_alpha_node0149 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0149 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0149 ((3 : Int),(1 : Int)) four_alpha_branches0149 copies separate cover ceiling four_alpha_check0149 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0149, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0150 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0150 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0150 ((3 : Int),(1 : Int)) four_alpha_branches0150 copies separate cover ceiling four_alpha_check0150 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0150, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0148 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0148 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0148 ((2 : Int),(1 : Int)) four_alpha_branches0148 copies separate cover ceiling four_alpha_check0148 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0148, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_alpha_node0149 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0150 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0151 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0151 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0151 ((2 : Int),(1 : Int)) four_alpha_branches0151 copies separate cover ceiling four_alpha_check0151 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0151, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0152 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0152 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0152 ((2 : Int),(1 : Int)) four_alpha_branches0152 copies separate cover ceiling four_alpha_check0152 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0152, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0155 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0155 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0155 ((4 : Int),(1 : Int)) four_alpha_branches0155 copies separate cover ceiling four_alpha_check0155 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0155, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0156 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0156 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0156 ((4 : Int),(1 : Int)) four_alpha_branches0156 copies separate cover ceiling four_alpha_check0156 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0156, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0154 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0154 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0154 ((3 : Int),(1 : Int)) four_alpha_branches0154 copies separate cover ceiling four_alpha_check0154 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0154, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_alpha_node0155 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0156 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0158 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0158 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0158 ((4 : Int),(1 : Int)) four_alpha_branches0158 copies separate cover ceiling four_alpha_check0158 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0158, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0159 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0159 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0159 ((4 : Int),(1 : Int)) four_alpha_branches0159 copies separate cover ceiling four_alpha_check0159 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0159, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0157 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0157 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0157 ((3 : Int),(1 : Int)) four_alpha_branches0157 copies separate cover ceiling four_alpha_check0157 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0157, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_alpha_node0158 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0159 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0153 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0153 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0153 ((1 : Int),(3 : Int)) four_alpha_branches0153 copies separate cover ceiling four_alpha_check0153 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0153, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_alpha_node0154 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0157 world h copies separate cover ceiling nextB nextState
theorem four_alpha_node0161 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0161 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha four_alpha_occ0161 .alpha (2 : Int) (3 : Int) four_alpha_check0161 B state
include copies separate cover ceiling in
theorem four_alpha_node0162 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0162 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0162 ((3 : Int),(1 : Int)) four_alpha_branches0162 copies separate cover ceiling four_alpha_check0162 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0162, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0163 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0163 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0163 ((3 : Int),(1 : Int)) four_alpha_branches0163 copies separate cover ceiling four_alpha_check0163 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0163, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0164 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0164 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0164 ((3 : Int),(1 : Int)) four_alpha_branches0164 copies separate cover ceiling four_alpha_check0164 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0164, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0165 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0165 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0165 ((3 : Int),(1 : Int)) four_alpha_branches0165 copies separate cover ceiling four_alpha_check0165 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0165, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0160 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0160 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0160 ((1 : Int),(3 : Int)) four_alpha_branches0160 copies separate cover ceiling four_alpha_check0160 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0160, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_alpha_node0161 world h nextB nextState
  · exact four_alpha_node0162 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0163 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0164 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0165 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0166 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0166 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0166 ((2 : Int),(1 : Int)) four_alpha_branches0166 copies separate cover ceiling four_alpha_check0166 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0166, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0167 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0167 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0167 ((2 : Int),(1 : Int)) four_alpha_branches0167 copies separate cover ceiling four_alpha_check0167 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0167, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0147 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0147 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0147 ((1 : Int),(2 : Int)) four_alpha_branches0147 copies separate cover ceiling four_alpha_check0147 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0147, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_alpha_node0148 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0151 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0152 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0153 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0160 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0166 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0167 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0144 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0144 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0144 ((1 : Int),(0 : Int)) four_alpha_branches0144 copies separate cover ceiling four_alpha_check0144 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0144, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_alpha_node0145 world h nextB nextState
  · exact four_alpha_node0146 world h nextB nextState
  · exact four_alpha_node0147 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0169 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0169 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0169 ((1 : Int),(1 : Int)) four_alpha_branches0169 copies separate cover ceiling four_alpha_check0169 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0169, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0171 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0171 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0171 ((1 : Int),(2 : Int)) four_alpha_branches0171 copies separate cover ceiling four_alpha_check0171 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0171, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0172 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0172 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0172 ((1 : Int),(2 : Int)) four_alpha_branches0172 copies separate cover ceiling four_alpha_check0172 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0172, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0170 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0170 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0170 ((1 : Int),(1 : Int)) four_alpha_branches0170 copies separate cover ceiling four_alpha_check0170 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0170, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_alpha_node0171 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0172 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0173 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0173 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0173 ((1 : Int),(1 : Int)) four_alpha_branches0173 copies separate cover ceiling four_alpha_check0173 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0173, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0168 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0168 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0168 ((1 : Int),(0 : Int)) four_alpha_branches0168 copies separate cover ceiling four_alpha_check0168 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0168, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_alpha_node0169 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0170 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0173 world h copies separate cover ceiling nextB nextState
theorem four_alpha_node0175 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0175 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha four_alpha_occ0175 .betaTranspose (1 : Int) (1 : Int) four_alpha_check0175 B state
theorem four_alpha_node0176 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0176 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha four_alpha_occ0176 .gammaTranspose (1 : Int) (1 : Int) four_alpha_check0176 B state
include copies separate cover ceiling in
theorem four_alpha_node0178 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0178 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0178 ((1 : Int),(3 : Int)) four_alpha_branches0178 copies separate cover ceiling four_alpha_check0178 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0178, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0181 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0181 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0181 ((1 : Int),(4 : Int)) four_alpha_branches0181 copies separate cover ceiling four_alpha_check0181 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0181, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0182 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0182 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0182 ((1 : Int),(4 : Int)) four_alpha_branches0182 copies separate cover ceiling four_alpha_check0182 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0182, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0180 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0180 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0180 ((3 : Int),(1 : Int)) four_alpha_branches0180 copies separate cover ceiling four_alpha_check0180 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0180, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_alpha_node0181 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0182 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0184 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0184 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0184 ((1 : Int),(4 : Int)) four_alpha_branches0184 copies separate cover ceiling four_alpha_check0184 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0184, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0185 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0185 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0185 ((1 : Int),(4 : Int)) four_alpha_branches0185 copies separate cover ceiling four_alpha_check0185 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0185, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0183 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0183 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0183 ((3 : Int),(1 : Int)) four_alpha_branches0183 copies separate cover ceiling four_alpha_check0183 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0183, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_alpha_node0184 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0185 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0179 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0179 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0179 ((1 : Int),(3 : Int)) four_alpha_branches0179 copies separate cover ceiling four_alpha_check0179 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0179, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_alpha_node0180 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0183 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0187 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0187 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0187 ((1 : Int),(3 : Int)) four_alpha_branches0187 copies separate cover ceiling four_alpha_check0187 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0187, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0186 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0186 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0186 ((2 : Int),(1 : Int)) four_alpha_branches0186 copies separate cover ceiling four_alpha_check0186 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0186, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact four_alpha_node0187 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0188 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0188 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0188 ((2 : Int),(1 : Int)) four_alpha_branches0188 copies separate cover ceiling four_alpha_check0188 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0188, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0190 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0190 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0190 ((1 : Int),(3 : Int)) four_alpha_branches0190 copies separate cover ceiling four_alpha_check0190 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0190, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0189 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0189 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0189 ((2 : Int),(1 : Int)) four_alpha_branches0189 copies separate cover ceiling four_alpha_check0189 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0189, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact four_alpha_node0190 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0177 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0177 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0177 ((1 : Int),(2 : Int)) four_alpha_branches0177 copies separate cover ceiling four_alpha_check0177 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0177, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_alpha_node0178 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0179 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0186 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0188 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0189 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0174 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0174 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0174 ((0 : Int),(1 : Int)) four_alpha_branches0174 copies separate cover ceiling four_alpha_check0174 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0174, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_alpha_node0175 world h nextB nextState
  · exact four_alpha_node0176 world h nextB nextState
  · exact four_alpha_node0177 world h copies separate cover ceiling nextB nextState
theorem four_alpha_node0192 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0192 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha four_alpha_occ0192 .alpha (1 : Int) (1 : Int) four_alpha_check0192 B state
theorem four_alpha_node0194 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0194 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha four_alpha_occ0194 .gamma (1 : Int) (2 : Int) four_alpha_check0194 B state
include copies separate cover ceiling in
theorem four_alpha_node0197 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0197 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0197 ((3 : Int),(2 : Int)) four_alpha_branches0197 copies separate cover ceiling four_alpha_check0197 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0197, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0198 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0198 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0198 ((3 : Int),(2 : Int)) four_alpha_branches0198 copies separate cover ceiling four_alpha_check0198 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0198, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0196 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0196 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0196 ((2 : Int),(2 : Int)) four_alpha_branches0196 copies separate cover ceiling four_alpha_check0196 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0196, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_alpha_node0197 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0198 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0199 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0199 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0199 ((2 : Int),(2 : Int)) four_alpha_branches0199 copies separate cover ceiling four_alpha_check0199 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0199, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0200 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0200 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0200 ((2 : Int),(2 : Int)) four_alpha_branches0200 copies separate cover ceiling four_alpha_check0200 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0200, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0203 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0203 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0203 ((4 : Int),(2 : Int)) four_alpha_branches0203 copies separate cover ceiling four_alpha_check0203 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0203, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0204 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0204 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0204 ((4 : Int),(2 : Int)) four_alpha_branches0204 copies separate cover ceiling four_alpha_check0204 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0204, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0202 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0202 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0202 ((3 : Int),(2 : Int)) four_alpha_branches0202 copies separate cover ceiling four_alpha_check0202 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0202, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_alpha_node0203 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0204 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0206 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0206 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0206 ((4 : Int),(2 : Int)) four_alpha_branches0206 copies separate cover ceiling four_alpha_check0206 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0206, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0207 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0207 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0207 ((4 : Int),(2 : Int)) four_alpha_branches0207 copies separate cover ceiling four_alpha_check0207 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0207, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0205 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0205 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0205 ((3 : Int),(2 : Int)) four_alpha_branches0205 copies separate cover ceiling four_alpha_check0205 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0205, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_alpha_node0206 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0207 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0201 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0201 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0201 ((1 : Int),(4 : Int)) four_alpha_branches0201 copies separate cover ceiling four_alpha_check0201 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0201, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_alpha_node0202 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0205 world h copies separate cover ceiling nextB nextState
theorem four_alpha_node0209 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0209 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha four_alpha_occ0209 .alpha (2 : Int) (4 : Int) four_alpha_check0209 B state
include copies separate cover ceiling in
theorem four_alpha_node0210 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0210 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0210 ((3 : Int),(2 : Int)) four_alpha_branches0210 copies separate cover ceiling four_alpha_check0210 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0210, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0211 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0211 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0211 ((3 : Int),(2 : Int)) four_alpha_branches0211 copies separate cover ceiling four_alpha_check0211 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0211, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0212 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0212 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0212 ((3 : Int),(2 : Int)) four_alpha_branches0212 copies separate cover ceiling four_alpha_check0212 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0212, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0213 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0213 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0213 ((3 : Int),(2 : Int)) four_alpha_branches0213 copies separate cover ceiling four_alpha_check0213 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0213, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0208 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0208 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0208 ((1 : Int),(4 : Int)) four_alpha_branches0208 copies separate cover ceiling four_alpha_check0208 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0208, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_alpha_node0209 world h nextB nextState
  · exact four_alpha_node0210 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0211 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0212 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0213 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0214 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0214 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0214 ((2 : Int),(2 : Int)) four_alpha_branches0214 copies separate cover ceiling four_alpha_check0214 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0214, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0215 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0215 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0215 ((2 : Int),(2 : Int)) four_alpha_branches0215 copies separate cover ceiling four_alpha_check0215 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0215, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0195 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0195 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0195 ((1 : Int),(3 : Int)) four_alpha_branches0195 copies separate cover ceiling four_alpha_check0195 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0195, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_alpha_node0196 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0199 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0200 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0201 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0208 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0214 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0215 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0193 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0193 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0193 ((1 : Int),(1 : Int)) four_alpha_branches0193 copies separate cover ceiling four_alpha_check0193 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0193, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_alpha_node0194 world h nextB nextState
  · exact four_alpha_node0195 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0217 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0217 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0217 ((1 : Int),(2 : Int)) four_alpha_branches0217 copies separate cover ceiling four_alpha_check0217 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0217, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0218 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0218 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0218 ((1 : Int),(2 : Int)) four_alpha_branches0218 copies separate cover ceiling four_alpha_check0218 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0218, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0216 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0216 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0216 ((1 : Int),(1 : Int)) four_alpha_branches0216 copies separate cover ceiling four_alpha_check0216 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0216, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_alpha_node0217 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0218 world h copies separate cover ceiling nextB nextState
theorem four_alpha_node0220 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0220 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha four_alpha_occ0220 .betaTranspose (1 : Int) (2 : Int) four_alpha_check0220 B state
theorem four_alpha_node0221 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0221 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha four_alpha_occ0221 .gammaTranspose (1 : Int) (2 : Int) four_alpha_check0221 B state
include copies separate cover ceiling in
theorem four_alpha_node0223 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0223 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0223 ((1 : Int),(4 : Int)) four_alpha_branches0223 copies separate cover ceiling four_alpha_check0223 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0223, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0226 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0226 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0226 ((1 : Int),(5 : Int)) four_alpha_branches0226 copies separate cover ceiling four_alpha_check0226 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0226, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0227 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0227 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0227 ((1 : Int),(5 : Int)) four_alpha_branches0227 copies separate cover ceiling four_alpha_check0227 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0227, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0225 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0225 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0225 ((3 : Int),(2 : Int)) four_alpha_branches0225 copies separate cover ceiling four_alpha_check0225 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0225, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_alpha_node0226 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0227 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0229 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0229 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0229 ((1 : Int),(5 : Int)) four_alpha_branches0229 copies separate cover ceiling four_alpha_check0229 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0229, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0230 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0230 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0230 ((1 : Int),(5 : Int)) four_alpha_branches0230 copies separate cover ceiling four_alpha_check0230 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0230, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0228 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0228 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0228 ((3 : Int),(2 : Int)) four_alpha_branches0228 copies separate cover ceiling four_alpha_check0228 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0228, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_alpha_node0229 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0230 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0224 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0224 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0224 ((1 : Int),(4 : Int)) four_alpha_branches0224 copies separate cover ceiling four_alpha_check0224 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0224, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_alpha_node0225 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0228 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0232 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0232 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0232 ((1 : Int),(4 : Int)) four_alpha_branches0232 copies separate cover ceiling four_alpha_check0232 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0232, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0231 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0231 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0231 ((2 : Int),(2 : Int)) four_alpha_branches0231 copies separate cover ceiling four_alpha_check0231 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0231, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact four_alpha_node0232 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0233 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0233 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0233 ((2 : Int),(2 : Int)) four_alpha_branches0233 copies separate cover ceiling four_alpha_check0233 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0233, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0235 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0235 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0235 ((1 : Int),(4 : Int)) four_alpha_branches0235 copies separate cover ceiling four_alpha_check0235 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0235, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0234 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0234 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0234 ((2 : Int),(2 : Int)) four_alpha_branches0234 copies separate cover ceiling four_alpha_check0234 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0234, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact four_alpha_node0235 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0222 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0222 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0222 ((1 : Int),(3 : Int)) four_alpha_branches0222 copies separate cover ceiling four_alpha_check0222 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0222, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_alpha_node0223 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0224 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0231 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0233 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0234 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0219 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0219 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0219 ((0 : Int),(2 : Int)) four_alpha_branches0219 copies separate cover ceiling four_alpha_check0219 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0219, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_alpha_node0220 world h nextB nextState
  · exact four_alpha_node0221 world h nextB nextState
  · exact four_alpha_node0222 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0238 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0238 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0238 ((2 : Int),(2 : Int)) four_alpha_branches0238 copies separate cover ceiling four_alpha_check0238 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0238, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0239 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0239 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0239 ((2 : Int),(2 : Int)) four_alpha_branches0239 copies separate cover ceiling four_alpha_check0239 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0239, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0237 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0237 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0237 ((1 : Int),(2 : Int)) four_alpha_branches0237 copies separate cover ceiling four_alpha_check0237 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0237, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_alpha_node0238 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0239 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0240 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0240 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0240 ((1 : Int),(2 : Int)) four_alpha_branches0240 copies separate cover ceiling four_alpha_check0240 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0240, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0241 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0241 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0241 ((1 : Int),(2 : Int)) four_alpha_branches0241 copies separate cover ceiling four_alpha_check0241 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0241, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0236 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0236 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0236 ((0 : Int),(2 : Int)) four_alpha_branches0236 copies separate cover ceiling four_alpha_check0236 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0236, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_alpha_node0237 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0240 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0241 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0191 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0191 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0191 ((0 : Int),(1 : Int)) four_alpha_branches0191 copies separate cover ceiling four_alpha_check0191 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0191, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_alpha_node0192 world h nextB nextState
  · exact four_alpha_node0193 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0216 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0219 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0236 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0244 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0244 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0244 ((2 : Int),(1 : Int)) four_alpha_branches0244 copies separate cover ceiling four_alpha_check0244 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0244, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0245 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0245 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0245 ((2 : Int),(1 : Int)) four_alpha_branches0245 copies separate cover ceiling four_alpha_check0245 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0245, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0243 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0243 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0243 ((1 : Int),(1 : Int)) four_alpha_branches0243 copies separate cover ceiling four_alpha_check0243 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0243, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_alpha_node0244 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0245 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0246 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0246 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0246 ((1 : Int),(1 : Int)) four_alpha_branches0246 copies separate cover ceiling four_alpha_check0246 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0246, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0247 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0247 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0247 ((1 : Int),(1 : Int)) four_alpha_branches0247 copies separate cover ceiling four_alpha_check0247 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0247, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_alpha_node0242 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0242 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0242 ((0 : Int),(1 : Int)) four_alpha_branches0242 copies separate cover ceiling four_alpha_check0242 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0242, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_alpha_node0243 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0246 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0247 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_alpha_node0000 (B : Int → Int → Prop)
    (state : State world h four_alpha_occ0000 B) : Transition world h .alpha B := by
  apply replay_step (4 : Int) (by decide) world h .alpha four_alpha_occ0000 ((0 : Int),(0 : Int)) four_alpha_branches0000 copies separate cover ceiling four_alpha_check0000 ?_ B state
  intro branch member nextB nextState
  simp only [four_alpha_branches0000, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_alpha_node0001 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0144 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0168 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0174 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0191 world h copies separate cover ceiling nextB nextState
  · exact four_alpha_node0242 world h copies separate cover ceiling nextB nextState
end FourAlpha

theorem four_alpha_seed_eq : SameCells (seed .alpha) four_alpha_occ0000 := by decide

theorem four_alpha_local (world : Cross → Prop) (h : Int) (B : Int → Int → Prop)
    (copies : ∀ t, world t → Copy 4 1 1 0 t)
    (separate : DisjointWorld world) (cover : CoversWindow world h)
    (ceiling : SelectedBelow world h) (closed : TileClosed world B)
    (bounded : Below h B) (clean : Clean .alpha 0 0 B) :
    Transition world h .alpha B := by
  exact four_alpha_node0000 world h copies separate cover ceiling B
    (state_congr four_alpha_seed_eq (seed_state world h .alpha B closed bounded clean))
#print axioms four_alpha_local

end CornerCertificate

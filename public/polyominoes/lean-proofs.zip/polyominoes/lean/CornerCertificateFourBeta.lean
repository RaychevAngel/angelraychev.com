import CornerCertificateFourBetaData

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

namespace CornerCertificate
open CrossUnits


section FourBeta
variable (world : Cross → Prop) (h : Int)
    (copies : ∀ t, world t → Copy 4 1 1 0 t)
    (separate : DisjointWorld world) (cover : CoversWindow world h)
    (ceiling : SelectedBelow world h)

theorem four_beta_node0001 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0001 B) : Transition world h .beta B := by
  exact replay_leaf world h .beta four_beta_occ0001 .alpha (1 : Int) (0 : Int) four_beta_check0001 B state
include copies separate cover ceiling in
theorem four_beta_node0003 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0003 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0003 ((1 : Int),(1 : Int)) four_beta_branches0003 copies separate cover ceiling four_beta_check0003 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0003, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0004 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0004 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0004 ((1 : Int),(1 : Int)) four_beta_branches0004 copies separate cover ceiling four_beta_check0004 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0004, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0002 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0002 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0002 ((1 : Int),(0 : Int)) four_beta_branches0002 copies separate cover ceiling four_beta_check0002 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0002, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_beta_node0003 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0004 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0006 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0006 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0006 ((1 : Int),(1 : Int)) four_beta_branches0006 copies separate cover ceiling four_beta_check0006 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0006, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0007 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0007 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0007 ((1 : Int),(1 : Int)) four_beta_branches0007 copies separate cover ceiling four_beta_check0007 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0007, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0005 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0005 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0005 ((1 : Int),(0 : Int)) four_beta_branches0005 copies separate cover ceiling four_beta_check0005 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0005, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_beta_node0006 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0007 world h copies separate cover ceiling nextB nextState
theorem four_beta_node0008 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0008 B) : Transition world h .beta B := by
  exact replay_leaf world h .beta four_beta_occ0008 .alpha (2 : Int) (0 : Int) four_beta_check0008 B state
theorem four_beta_node0010 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0010 B) : Transition world h .beta B := by
  exact replay_leaf world h .beta four_beta_occ0010 .alpha (1 : Int) (2 : Int) four_beta_check0010 B state
theorem four_beta_node0013 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0013 B) : Transition world h .beta B := by
  exact replay_leaf world h .beta four_beta_occ0013 .gamma (1 : Int) (3 : Int) four_beta_check0013 B state
include copies separate cover ceiling in
theorem four_beta_node0016 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0016 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0016 ((3 : Int),(3 : Int)) four_beta_branches0016 copies separate cover ceiling four_beta_check0016 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0016, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0017 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0017 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0017 ((3 : Int),(3 : Int)) four_beta_branches0017 copies separate cover ceiling four_beta_check0017 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0017, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0015 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0015 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0015 ((2 : Int),(3 : Int)) four_beta_branches0015 copies separate cover ceiling four_beta_check0015 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0015, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_beta_node0016 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0017 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0018 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0018 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0018 ((2 : Int),(3 : Int)) four_beta_branches0018 copies separate cover ceiling four_beta_check0018 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0018, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0019 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0019 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0019 ((2 : Int),(3 : Int)) four_beta_branches0019 copies separate cover ceiling four_beta_check0019 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0019, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0022 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0022 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0022 ((4 : Int),(3 : Int)) four_beta_branches0022 copies separate cover ceiling four_beta_check0022 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0022, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0023 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0023 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0023 ((4 : Int),(3 : Int)) four_beta_branches0023 copies separate cover ceiling four_beta_check0023 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0023, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0021 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0021 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0021 ((3 : Int),(3 : Int)) four_beta_branches0021 copies separate cover ceiling four_beta_check0021 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0021, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_beta_node0022 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0023 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0025 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0025 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0025 ((4 : Int),(3 : Int)) four_beta_branches0025 copies separate cover ceiling four_beta_check0025 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0025, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0026 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0026 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0026 ((4 : Int),(3 : Int)) four_beta_branches0026 copies separate cover ceiling four_beta_check0026 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0026, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0024 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0024 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0024 ((3 : Int),(3 : Int)) four_beta_branches0024 copies separate cover ceiling four_beta_check0024 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0024, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_beta_node0025 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0026 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0020 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0020 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0020 ((1 : Int),(5 : Int)) four_beta_branches0020 copies separate cover ceiling four_beta_check0020 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0020, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_beta_node0021 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0024 world h copies separate cover ceiling nextB nextState
theorem four_beta_node0028 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0028 B) : Transition world h .beta B := by
  exact replay_leaf world h .beta four_beta_occ0028 .alpha (2 : Int) (5 : Int) four_beta_check0028 B state
include copies separate cover ceiling in
theorem four_beta_node0029 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0029 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0029 ((3 : Int),(3 : Int)) four_beta_branches0029 copies separate cover ceiling four_beta_check0029 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0029, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0030 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0030 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0030 ((3 : Int),(3 : Int)) four_beta_branches0030 copies separate cover ceiling four_beta_check0030 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0030, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0031 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0031 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0031 ((3 : Int),(3 : Int)) four_beta_branches0031 copies separate cover ceiling four_beta_check0031 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0031, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0032 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0032 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0032 ((3 : Int),(3 : Int)) four_beta_branches0032 copies separate cover ceiling four_beta_check0032 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0032, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0027 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0027 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0027 ((1 : Int),(5 : Int)) four_beta_branches0027 copies separate cover ceiling four_beta_check0027 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0027, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_beta_node0028 world h nextB nextState
  · exact four_beta_node0029 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0030 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0031 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0032 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0033 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0033 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0033 ((2 : Int),(3 : Int)) four_beta_branches0033 copies separate cover ceiling four_beta_check0033 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0033, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0034 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0034 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0034 ((2 : Int),(3 : Int)) four_beta_branches0034 copies separate cover ceiling four_beta_check0034 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0034, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0014 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0014 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0014 ((1 : Int),(4 : Int)) four_beta_branches0014 copies separate cover ceiling four_beta_check0014 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0014, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_beta_node0015 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0018 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0019 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0020 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0027 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0033 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0034 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0012 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0012 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0012 ((1 : Int),(2 : Int)) four_beta_branches0012 copies separate cover ceiling four_beta_check0012 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0012, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_beta_node0013 world h nextB nextState
  · exact four_beta_node0014 world h copies separate cover ceiling nextB nextState
theorem four_beta_node0036 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0036 B) : Transition world h .beta B := by
  exact replay_leaf world h .beta four_beta_occ0036 .gamma (1 : Int) (3 : Int) four_beta_check0036 B state
include copies separate cover ceiling in
theorem four_beta_node0039 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0039 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0039 ((3 : Int),(3 : Int)) four_beta_branches0039 copies separate cover ceiling four_beta_check0039 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0039, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0040 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0040 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0040 ((3 : Int),(3 : Int)) four_beta_branches0040 copies separate cover ceiling four_beta_check0040 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0040, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0038 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0038 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0038 ((2 : Int),(3 : Int)) four_beta_branches0038 copies separate cover ceiling four_beta_check0038 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0038, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_beta_node0039 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0040 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0041 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0041 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0041 ((2 : Int),(3 : Int)) four_beta_branches0041 copies separate cover ceiling four_beta_check0041 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0041, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0042 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0042 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0042 ((2 : Int),(3 : Int)) four_beta_branches0042 copies separate cover ceiling four_beta_check0042 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0042, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0045 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0045 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0045 ((4 : Int),(3 : Int)) four_beta_branches0045 copies separate cover ceiling four_beta_check0045 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0045, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0046 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0046 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0046 ((4 : Int),(3 : Int)) four_beta_branches0046 copies separate cover ceiling four_beta_check0046 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0046, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0044 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0044 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0044 ((3 : Int),(3 : Int)) four_beta_branches0044 copies separate cover ceiling four_beta_check0044 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0044, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_beta_node0045 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0046 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0048 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0048 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0048 ((4 : Int),(3 : Int)) four_beta_branches0048 copies separate cover ceiling four_beta_check0048 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0048, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0049 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0049 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0049 ((4 : Int),(3 : Int)) four_beta_branches0049 copies separate cover ceiling four_beta_check0049 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0049, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0047 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0047 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0047 ((3 : Int),(3 : Int)) four_beta_branches0047 copies separate cover ceiling four_beta_check0047 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0047, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_beta_node0048 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0049 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0043 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0043 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0043 ((1 : Int),(5 : Int)) four_beta_branches0043 copies separate cover ceiling four_beta_check0043 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0043, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_beta_node0044 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0047 world h copies separate cover ceiling nextB nextState
theorem four_beta_node0051 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0051 B) : Transition world h .beta B := by
  exact replay_leaf world h .beta four_beta_occ0051 .alpha (2 : Int) (5 : Int) four_beta_check0051 B state
include copies separate cover ceiling in
theorem four_beta_node0052 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0052 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0052 ((3 : Int),(3 : Int)) four_beta_branches0052 copies separate cover ceiling four_beta_check0052 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0052, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0053 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0053 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0053 ((3 : Int),(3 : Int)) four_beta_branches0053 copies separate cover ceiling four_beta_check0053 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0053, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0054 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0054 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0054 ((3 : Int),(3 : Int)) four_beta_branches0054 copies separate cover ceiling four_beta_check0054 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0054, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0055 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0055 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0055 ((3 : Int),(3 : Int)) four_beta_branches0055 copies separate cover ceiling four_beta_check0055 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0055, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0050 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0050 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0050 ((1 : Int),(5 : Int)) four_beta_branches0050 copies separate cover ceiling four_beta_check0050 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0050, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_beta_node0051 world h nextB nextState
  · exact four_beta_node0052 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0053 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0054 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0055 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0056 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0056 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0056 ((2 : Int),(3 : Int)) four_beta_branches0056 copies separate cover ceiling four_beta_check0056 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0056, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0057 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0057 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0057 ((2 : Int),(3 : Int)) four_beta_branches0057 copies separate cover ceiling four_beta_check0057 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0057, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0037 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0037 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0037 ((1 : Int),(4 : Int)) four_beta_branches0037 copies separate cover ceiling four_beta_check0037 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0037, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_beta_node0038 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0041 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0042 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0043 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0050 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0056 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0057 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0035 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0035 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0035 ((1 : Int),(2 : Int)) four_beta_branches0035 copies separate cover ceiling four_beta_check0035 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0035, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_beta_node0036 world h nextB nextState
  · exact four_beta_node0037 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0011 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0011 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0011 ((2 : Int),(0 : Int)) four_beta_branches0011 copies separate cover ceiling four_beta_check0011 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0011, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_beta_node0012 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0035 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0060 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0060 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0060 ((1 : Int),(3 : Int)) four_beta_branches0060 copies separate cover ceiling four_beta_check0060 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0060, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0061 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0061 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0061 ((1 : Int),(3 : Int)) four_beta_branches0061 copies separate cover ceiling four_beta_check0061 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0061, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0059 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0059 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0059 ((1 : Int),(2 : Int)) four_beta_branches0059 copies separate cover ceiling four_beta_check0059 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0059, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_beta_node0060 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0061 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0063 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0063 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0063 ((1 : Int),(3 : Int)) four_beta_branches0063 copies separate cover ceiling four_beta_check0063 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0063, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0064 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0064 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0064 ((1 : Int),(3 : Int)) four_beta_branches0064 copies separate cover ceiling four_beta_check0064 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0064, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0062 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0062 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0062 ((1 : Int),(2 : Int)) four_beta_branches0062 copies separate cover ceiling four_beta_check0062 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0062, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_beta_node0063 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0064 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0058 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0058 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0058 ((2 : Int),(0 : Int)) four_beta_branches0058 copies separate cover ceiling four_beta_check0058 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0058, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_beta_node0059 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0062 world h copies separate cover ceiling nextB nextState
theorem four_beta_node0067 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0067 B) : Transition world h .beta B := by
  exact replay_leaf world h .beta four_beta_occ0067 .betaTranspose (1 : Int) (3 : Int) four_beta_check0067 B state
theorem four_beta_node0068 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0068 B) : Transition world h .beta B := by
  exact replay_leaf world h .beta four_beta_occ0068 .gammaTranspose (1 : Int) (3 : Int) four_beta_check0068 B state
include copies separate cover ceiling in
theorem four_beta_node0070 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0070 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0070 ((1 : Int),(5 : Int)) four_beta_branches0070 copies separate cover ceiling four_beta_check0070 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0070, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0073 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0073 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0073 ((1 : Int),(6 : Int)) four_beta_branches0073 copies separate cover ceiling four_beta_check0073 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0073, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0074 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0074 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0074 ((1 : Int),(6 : Int)) four_beta_branches0074 copies separate cover ceiling four_beta_check0074 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0074, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0072 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0072 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0072 ((3 : Int),(3 : Int)) four_beta_branches0072 copies separate cover ceiling four_beta_check0072 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0072, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_beta_node0073 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0074 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0076 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0076 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0076 ((1 : Int),(6 : Int)) four_beta_branches0076 copies separate cover ceiling four_beta_check0076 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0076, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0077 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0077 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0077 ((1 : Int),(6 : Int)) four_beta_branches0077 copies separate cover ceiling four_beta_check0077 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0077, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0075 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0075 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0075 ((3 : Int),(3 : Int)) four_beta_branches0075 copies separate cover ceiling four_beta_check0075 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0075, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_beta_node0076 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0077 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0071 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0071 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0071 ((1 : Int),(5 : Int)) four_beta_branches0071 copies separate cover ceiling four_beta_check0071 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0071, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_beta_node0072 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0075 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0079 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0079 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0079 ((1 : Int),(5 : Int)) four_beta_branches0079 copies separate cover ceiling four_beta_check0079 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0079, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0078 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0078 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0078 ((2 : Int),(3 : Int)) four_beta_branches0078 copies separate cover ceiling four_beta_check0078 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0078, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact four_beta_node0079 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0080 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0080 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0080 ((2 : Int),(3 : Int)) four_beta_branches0080 copies separate cover ceiling four_beta_check0080 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0080, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0082 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0082 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0082 ((1 : Int),(5 : Int)) four_beta_branches0082 copies separate cover ceiling four_beta_check0082 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0082, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0081 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0081 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0081 ((2 : Int),(3 : Int)) four_beta_branches0081 copies separate cover ceiling four_beta_check0081 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0081, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact four_beta_node0082 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0069 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0069 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0069 ((1 : Int),(4 : Int)) four_beta_branches0069 copies separate cover ceiling four_beta_check0069 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0069, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_beta_node0070 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0071 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0078 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0080 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0081 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0066 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0066 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0066 ((0 : Int),(3 : Int)) four_beta_branches0066 copies separate cover ceiling four_beta_check0066 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0066, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_beta_node0067 world h nextB nextState
  · exact four_beta_node0068 world h nextB nextState
  · exact four_beta_node0069 world h copies separate cover ceiling nextB nextState
theorem four_beta_node0084 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0084 B) : Transition world h .beta B := by
  exact replay_leaf world h .beta four_beta_occ0084 .betaTranspose (1 : Int) (3 : Int) four_beta_check0084 B state
theorem four_beta_node0085 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0085 B) : Transition world h .beta B := by
  exact replay_leaf world h .beta four_beta_occ0085 .gammaTranspose (1 : Int) (3 : Int) four_beta_check0085 B state
include copies separate cover ceiling in
theorem four_beta_node0087 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0087 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0087 ((1 : Int),(5 : Int)) four_beta_branches0087 copies separate cover ceiling four_beta_check0087 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0087, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0090 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0090 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0090 ((1 : Int),(6 : Int)) four_beta_branches0090 copies separate cover ceiling four_beta_check0090 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0090, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0091 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0091 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0091 ((1 : Int),(6 : Int)) four_beta_branches0091 copies separate cover ceiling four_beta_check0091 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0091, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0089 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0089 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0089 ((3 : Int),(3 : Int)) four_beta_branches0089 copies separate cover ceiling four_beta_check0089 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0089, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_beta_node0090 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0091 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0093 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0093 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0093 ((1 : Int),(6 : Int)) four_beta_branches0093 copies separate cover ceiling four_beta_check0093 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0093, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0094 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0094 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0094 ((1 : Int),(6 : Int)) four_beta_branches0094 copies separate cover ceiling four_beta_check0094 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0094, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0092 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0092 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0092 ((3 : Int),(3 : Int)) four_beta_branches0092 copies separate cover ceiling four_beta_check0092 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0092, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_beta_node0093 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0094 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0088 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0088 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0088 ((1 : Int),(5 : Int)) four_beta_branches0088 copies separate cover ceiling four_beta_check0088 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0088, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_beta_node0089 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0092 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0096 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0096 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0096 ((1 : Int),(5 : Int)) four_beta_branches0096 copies separate cover ceiling four_beta_check0096 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0096, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0095 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0095 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0095 ((2 : Int),(3 : Int)) four_beta_branches0095 copies separate cover ceiling four_beta_check0095 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0095, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact four_beta_node0096 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0097 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0097 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0097 ((2 : Int),(3 : Int)) four_beta_branches0097 copies separate cover ceiling four_beta_check0097 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0097, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0099 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0099 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0099 ((1 : Int),(5 : Int)) four_beta_branches0099 copies separate cover ceiling four_beta_check0099 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0099, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0098 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0098 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0098 ((2 : Int),(3 : Int)) four_beta_branches0098 copies separate cover ceiling four_beta_check0098 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0098, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact four_beta_node0099 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0086 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0086 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0086 ((1 : Int),(4 : Int)) four_beta_branches0086 copies separate cover ceiling four_beta_check0086 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0086, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_beta_node0087 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0088 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0095 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0097 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0098 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0083 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0083 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0083 ((0 : Int),(3 : Int)) four_beta_branches0083 copies separate cover ceiling four_beta_check0083 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0083, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_beta_node0084 world h nextB nextState
  · exact four_beta_node0085 world h nextB nextState
  · exact four_beta_node0086 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0065 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0065 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0065 ((2 : Int),(0 : Int)) four_beta_branches0065 copies separate cover ceiling four_beta_check0065 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0065, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_beta_node0066 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0083 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0103 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0103 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0103 ((2 : Int),(3 : Int)) four_beta_branches0103 copies separate cover ceiling four_beta_check0103 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0103, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0104 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0104 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0104 ((2 : Int),(3 : Int)) four_beta_branches0104 copies separate cover ceiling four_beta_check0104 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0104, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0102 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0102 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0102 ((1 : Int),(3 : Int)) four_beta_branches0102 copies separate cover ceiling four_beta_check0102 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0102, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_beta_node0103 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0104 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0105 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0105 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0105 ((1 : Int),(3 : Int)) four_beta_branches0105 copies separate cover ceiling four_beta_check0105 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0105, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0106 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0106 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0106 ((1 : Int),(3 : Int)) four_beta_branches0106 copies separate cover ceiling four_beta_check0106 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0106, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0101 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0101 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0101 ((0 : Int),(3 : Int)) four_beta_branches0101 copies separate cover ceiling four_beta_check0101 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0101, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_beta_node0102 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0105 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0106 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0109 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0109 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0109 ((2 : Int),(3 : Int)) four_beta_branches0109 copies separate cover ceiling four_beta_check0109 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0109, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0110 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0110 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0110 ((2 : Int),(3 : Int)) four_beta_branches0110 copies separate cover ceiling four_beta_check0110 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0110, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0108 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0108 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0108 ((1 : Int),(3 : Int)) four_beta_branches0108 copies separate cover ceiling four_beta_check0108 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0108, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_beta_node0109 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0110 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0111 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0111 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0111 ((1 : Int),(3 : Int)) four_beta_branches0111 copies separate cover ceiling four_beta_check0111 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0111, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0112 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0112 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0112 ((1 : Int),(3 : Int)) four_beta_branches0112 copies separate cover ceiling four_beta_check0112 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0112, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0107 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0107 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0107 ((0 : Int),(3 : Int)) four_beta_branches0107 copies separate cover ceiling four_beta_check0107 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0107, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact four_beta_node0108 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0111 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0112 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0100 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0100 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0100 ((2 : Int),(0 : Int)) four_beta_branches0100 copies separate cover ceiling four_beta_check0100 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0100, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact four_beta_node0101 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0107 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0009 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0009 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0009 ((0 : Int),(2 : Int)) four_beta_branches0009 copies separate cover ceiling four_beta_check0009 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0009, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact four_beta_node0010 world h nextB nextState
  · exact four_beta_node0011 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0058 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0065 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0100 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem four_beta_node0113 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0113 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0113 ((1 : Int),(0 : Int)) four_beta_branches0113 copies separate cover ceiling four_beta_check0113 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0113, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0114 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0114 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0114 ((1 : Int),(0 : Int)) four_beta_branches0114 copies separate cover ceiling four_beta_check0114 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0114, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0115 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0115 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0115 ((1 : Int),(0 : Int)) four_beta_branches0115 copies separate cover ceiling four_beta_check0115 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0115, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem four_beta_node0000 (B : Int → Int → Prop)
    (state : State world h four_beta_occ0000 B) : Transition world h .beta B := by
  apply replay_step (4 : Int) (by decide) world h .beta four_beta_occ0000 ((0 : Int),(1 : Int)) four_beta_branches0000 copies separate cover ceiling four_beta_check0000 ?_ B state
  intro branch member nextB nextState
  simp only [four_beta_branches0000, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact four_beta_node0001 world h nextB nextState
  · exact four_beta_node0002 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0005 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0008 world h nextB nextState
  · exact four_beta_node0009 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0113 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0114 world h copies separate cover ceiling nextB nextState
  · exact four_beta_node0115 world h copies separate cover ceiling nextB nextState
end FourBeta

theorem four_beta_seed_eq : SameCells (seed .beta) four_beta_occ0000 := by decide

theorem four_beta_local (world : Cross → Prop) (h : Int) (B : Int → Int → Prop)
    (copies : ∀ t, world t → Copy 4 1 1 0 t)
    (separate : DisjointWorld world) (cover : CoversWindow world h)
    (ceiling : SelectedBelow world h) (closed : TileClosed world B)
    (bounded : Below h B) (clean : Clean .beta 0 0 B) :
    Transition world h .beta B := by
  exact four_beta_node0000 world h copies separate cover ceiling B
    (state_congr four_beta_seed_eq (seed_state world h .beta B closed bounded clean))
#print axioms four_beta_local

end CornerCertificate

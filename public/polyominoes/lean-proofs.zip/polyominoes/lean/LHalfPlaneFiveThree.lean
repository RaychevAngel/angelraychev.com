import LQuadrantHpAlternatingUnequalBarLongFixed53PrunedGeometry
import LQuadrantHpUnequalBarShortFixed53PrunedGeometry
import LHalfPlaneAssembly
import LHalfPlaneSameBars

namespace PolyominoFormal.LHalfPlaneFiveThree
open CrossUnits LRegion LHalfPlaneAssembly

theorem no_short_bars : NoShortBars 5 3 := by
  intro T p anchor
  apply HP_unequal_bar_short_fixed_5_3_pruned_no_shifted_anchor 5 3 p
    (by decide) (by decide) (by decide) (by decide) rfl rfl T
  simpa only [shift,Int.zero_add,Int.add_zero] using anchor

theorem no_eight_bars : NoEightAlternatingBars 5 3 := by
  intro T h0 h1 h2 h3 h4 h5 h6 h7
  exact HP_alternating_unequal_bar_long_fixed_5_3_pruned_anchored_obstruction 5 3
    (by decide) (by decide) (by decide) (by decide) rfl rfl
    T h0 h1 h2 h3 h4 h5 h6 h7

/-- The exceptional 6-by-4 bounding box, in the shared arm convention.
    This is a statement about every ordinary whole half-plane tiling. -/
theorem no_halfplane : ¬Tiles 5 3 0 0 HalfPlane := by
  apply no_halfplane_from_eight (by decide) (by decide) (by decide)
    no_short_bars ?_ no_eight_bars
  intro T h0 h1
  exact same_long_bars_impossible 5 3 0
    (by decide) (by decide) (by decide) T h0 h1

#print axioms no_halfplane
end PolyominoFormal.LHalfPlaneFiveThree

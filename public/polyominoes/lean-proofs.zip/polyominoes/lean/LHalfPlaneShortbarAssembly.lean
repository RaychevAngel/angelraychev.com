import LHalfPlaneAssembly

set_option maxHeartbeats 1000000
set_option maxRecDepth 10000
namespace PolyominoFormal.LHalfPlaneShortbarAssembly
open CrossUnits TBoundary

def InnerForms (a b : Int) (t : Cross) : Prop :=
  t=⟨1,1,a,b,0,0⟩ ∨
  t=⟨1,a+1,b,0,0,a⟩ ∨
  t=⟨b+1,1,0,a,b,0⟩ ∨
  t=⟨1,a+1,0,0,b,a⟩ ∨
  t=⟨a+1,1,0,b,a,0⟩ ∨
  t=⟨1,1,b,a,0,0⟩ ∨
  t=⟨1,b+1,a,0,0,b⟩

theorem inner_forms {a b : Int} (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (T : Tiling a b 0 0 HalfPlane)
    (anchor : T.world ⟨0,0,b,a,0,0⟩)
    {t : Cross} (ht : T.world t) (hit : Contains t 1 1) : InnerForms a b t := by
  have bound := THalfPlane.hp_bound (by omega) (by omega) (by omega) T ht
  have ap := separate (by omega) (by omega) (by omega) T ht anchor hit
    (by dsimp [Contains]; omega)
  have hv := ap.2.1
  have contact : (t.x-t.west=1 ∧ t.y=1) ∨ (t.x=1 ∧ t.y-t.south=1) := by
    rcases hit with hit | hit
    · left
      dsimp only at hv hit
      omega
    · right
      have vh := ap.2.2.1
      dsimp only at vh hit
      omega
  clear ap hit
  have cp := T.copies _ ht
  rcases t with ⟨x,y,e,n,w,s⟩
  rcases cp with cp | cp | cp | cp | cp | cp | cp | cp
  all_goals rcases cp with ⟨he,hn,hw,hs⟩
  all_goals dsimp only at he hn hw hs bound
  all_goals subst e; subst n; subst w; subst s
  all_goals dsimp only at contact hv bound
  all_goals unfold InnerForms
  · left; apply same_eq; dsimp [Same]; omega
  · right; left; apply same_eq; dsimp [Same]; omega
  · exfalso; omega
  · right; right; left; apply same_eq; dsimp [Same]; omega
  · right; right; right; left; apply same_eq; dsimp [Same]; omega
  · right; right; right; right; left; apply same_eq; dsimp [Same]; omega
  · right; right; right; right; right; left; apply same_eq; dsimp [Same]; omega
  · right; right; right; right; right; right; apply same_eq; dsimp [Same]; omega

def PairObstruction (a b : Int) (u : Cross) : Prop :=
  ∀T:Tiling a b 0 0 HalfPlane,
    T.world ⟨0,0,b,a,0,0⟩ → T.world u → False

/-- The only seven whole-tile possibilities at the short bar's inner corner
    may be proved separately, including by ordinary parameter case splits. -/
theorem no_shortbar_from_seven {a b : Int} (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (uprightLong : PairObstruction a b ⟨1,1,a,b,0,0⟩)
    (longTipRight : PairObstruction a b ⟨1,a+1,b,0,0,a⟩)
    (uprightShortLeft : PairObstruction a b ⟨b+1,1,0,a,b,0⟩)
    (longTipLeft : PairObstruction a b ⟨1,a+1,0,0,b,a⟩)
    (uprightLongLeft : PairObstruction a b ⟨a+1,1,0,b,a,0⟩)
    (uprightShort : PairObstruction a b ⟨1,1,b,a,0,0⟩)
    (shortTipRight : PairObstruction a b ⟨1,b+1,a,0,0,b⟩) :
    LHalfPlaneAssembly.NoShortBars a b := by
  intro T p anchor
  let U : Tiling a b 0 0 HalfPlane := (T.translate (-p) 0).congr (by
    intro x y; simp only [HalfPlane,Int.sub_zero])
  have hO : U.world ⟨0,0,b,a,0,0⟩ := by
    refine ⟨_,anchor,?_⟩
    apply same_eq
    dsimp [Same,shift]
    omega
  obtain ⟨t,ht,hit⟩ := U.cover 1 1 (by unfold HalfPlane; omega)
  rcases inner_forms ha hb hab U hO ht hit with eq | eq | eq | eq | eq | eq | eq
  · subst t; exact uprightLong U hO ht
  · subst t; exact longTipRight U hO ht
  · subst t; exact uprightShortLeft U hO ht
  · subst t; exact longTipLeft U hO ht
  · subst t; exact uprightLongLeft U hO ht
  · subst t; exact uprightShort U hO ht
  · subst t; exact shortTipRight U hO ht

#print axioms inner_forms
#print axioms no_shortbar_from_seven
end PolyominoFormal.LHalfPlaneShortbarAssembly

import LHalfPlaneShortbarAssembly
import LQuadrantHpUnequalNestedShortDeltaGeThreePrunedGeometry

namespace PolyominoFormal.LRegion
open CrossUnits

theorem nested_short_large_obstruction (a b : Int)
    (ha : 5≤a) (hb : 3≤b) (hab : b+3≤a) :
    LHalfPlaneShortbarAssembly.PairObstruction a b ⟨1,1,b,a,0,0⟩ := by
  intro T hO hS
  exact HP_unequal_nested_short_delta_ge_three_pruned_anchored_obstruction a b
    (by omega) hb (by omega) ha hab T hO hS

#print axioms nested_short_large_obstruction
end PolyominoFormal.LRegion

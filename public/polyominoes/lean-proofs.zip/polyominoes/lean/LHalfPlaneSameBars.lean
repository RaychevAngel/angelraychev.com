import LQuadrantHpSamebarsUnequalBarLongPrunedGeometry

namespace PolyominoFormal.LRegion
open CrossUnits

/-- Adjacent long sides on the half-plane boundary cannot have their junctions
    at the same end of the respective intervals. -/
theorem same_long_bars_impossible (a b p : Int)
    (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (T : Tiling a b 0 0 HalfPlane)
    (left : T.world ⟨p,0,a,b,0,0⟩)
    (right : T.world ⟨p+a+1,0,a,b,0,0⟩) : False := by
  apply HP_samebars_unequal_bar_long_pruned_no_shifted_anchor a b p
    (by omega) hb hab ha T
  · simpa only [shift,Int.zero_add,Int.add_zero] using left
  · simpa only [shift,Int.zero_add,Int.add_zero,Int.add_assoc,Int.add_comm,Int.add_left_comm] using right

/-- The reflected orientation is excluded by the same actual-world proof. -/
theorem same_long_bars_left_impossible (a b p : Int)
    (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (T : Tiling a b 0 0 HalfPlane)
    (left : T.world ⟨p,0,0,b,a,0⟩)
    (right : T.world ⟨p+a+1,0,0,b,a,0⟩) : False := by
  apply same_long_bars_impossible a b (-(p+a+1)) ha hb hab T.mirrorX
  · exact ⟨_,right,rfl⟩
  · refine ⟨_,left,?_⟩
    apply same_eq
    unfold Same mirrorX
    dsimp
    exact ⟨by omega,rfl,rfl,rfl,rfl,rfl⟩

#print axioms same_long_bars_impossible
#print axioms same_long_bars_left_impossible
end PolyominoFormal.LRegion

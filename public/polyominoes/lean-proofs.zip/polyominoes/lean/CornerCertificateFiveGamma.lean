import CornerCertificateFiveGammaData

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

namespace CornerCertificate
open CrossUnits


section FiveGamma
variable (world : Cross → Prop) (h : Int)
    (copies : ∀ t, world t → Copy 5 1 1 0 t)
    (separate : DisjointWorld world) (cover : CoversWindow world h)
    (ceiling : SelectedBelow world h)

theorem five_gamma_node0001 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0001 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma five_gamma_occ0001 .betaTranspose (1 : Int) (0 : Int) five_gamma_check0001 B state
theorem five_gamma_node0006 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0006 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma five_gamma_occ0006 .gamma (4 : Int) (1 : Int) five_gamma_check0006 B state
theorem five_gamma_node0007 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0007 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma five_gamma_occ0007 .beta (4 : Int) (1 : Int) five_gamma_check0007 B state
include copies separate cover ceiling in
theorem five_gamma_node0010 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0010 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0010 ((6 : Int),(1 : Int)) five_gamma_branches0010 copies separate cover ceiling five_gamma_check0010 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0010, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0011 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0011 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0011 ((6 : Int),(1 : Int)) five_gamma_branches0011 copies separate cover ceiling five_gamma_check0011 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0011, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0009 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0009 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0009 ((5 : Int),(1 : Int)) five_gamma_branches0009 copies separate cover ceiling five_gamma_check0009 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0009, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0010 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0011 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0012 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0012 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0012 ((5 : Int),(1 : Int)) five_gamma_branches0012 copies separate cover ceiling five_gamma_check0012 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0012, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0013 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0013 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0013 ((5 : Int),(1 : Int)) five_gamma_branches0013 copies separate cover ceiling five_gamma_check0013 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0013, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0016 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0016 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0016 ((7 : Int),(1 : Int)) five_gamma_branches0016 copies separate cover ceiling five_gamma_check0016 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0016, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0017 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0017 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0017 ((7 : Int),(1 : Int)) five_gamma_branches0017 copies separate cover ceiling five_gamma_check0017 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0017, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0015 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0015 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0015 ((6 : Int),(1 : Int)) five_gamma_branches0015 copies separate cover ceiling five_gamma_check0015 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0015, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0016 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0017 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0019 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0019 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0019 ((7 : Int),(1 : Int)) five_gamma_branches0019 copies separate cover ceiling five_gamma_check0019 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0019, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0020 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0020 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0020 ((7 : Int),(1 : Int)) five_gamma_branches0020 copies separate cover ceiling five_gamma_check0020 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0020, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0018 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0018 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0018 ((6 : Int),(1 : Int)) five_gamma_branches0018 copies separate cover ceiling five_gamma_check0018 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0018, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0019 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0020 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0014 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0014 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0014 ((4 : Int),(3 : Int)) five_gamma_branches0014 copies separate cover ceiling five_gamma_check0014 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0014, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0015 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0018 world h copies separate cover ceiling nextB nextState
theorem five_gamma_node0021 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0021 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma five_gamma_occ0021 .alpha (4 : Int) (3 : Int) five_gamma_check0021 B state
include copies separate cover ceiling in
theorem five_gamma_node0022 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0022 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0022 ((5 : Int),(1 : Int)) five_gamma_branches0022 copies separate cover ceiling five_gamma_check0022 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0022, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0023 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0023 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0023 ((5 : Int),(1 : Int)) five_gamma_branches0023 copies separate cover ceiling five_gamma_check0023 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0023, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0008 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0008 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0008 ((4 : Int),(2 : Int)) five_gamma_branches0008 copies separate cover ceiling five_gamma_check0008 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0008, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact five_gamma_node0009 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0012 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0013 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0014 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0021 world h nextB nextState
  · exact five_gamma_node0022 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0023 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0005 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0005 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0005 ((4 : Int),(0 : Int)) five_gamma_branches0005 copies separate cover ceiling five_gamma_check0005 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0005, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact five_gamma_node0006 world h nextB nextState
  · exact five_gamma_node0007 world h nextB nextState
  · exact five_gamma_node0008 world h copies separate cover ceiling nextB nextState
theorem five_gamma_node0025 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0025 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma five_gamma_occ0025 .gamma (4 : Int) (1 : Int) five_gamma_check0025 B state
theorem five_gamma_node0026 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0026 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma five_gamma_occ0026 .beta (4 : Int) (1 : Int) five_gamma_check0026 B state
include copies separate cover ceiling in
theorem five_gamma_node0029 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0029 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0029 ((6 : Int),(1 : Int)) five_gamma_branches0029 copies separate cover ceiling five_gamma_check0029 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0029, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0030 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0030 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0030 ((6 : Int),(1 : Int)) five_gamma_branches0030 copies separate cover ceiling five_gamma_check0030 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0030, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0028 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0028 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0028 ((5 : Int),(1 : Int)) five_gamma_branches0028 copies separate cover ceiling five_gamma_check0028 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0028, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0029 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0030 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0031 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0031 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0031 ((5 : Int),(1 : Int)) five_gamma_branches0031 copies separate cover ceiling five_gamma_check0031 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0031, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0032 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0032 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0032 ((5 : Int),(1 : Int)) five_gamma_branches0032 copies separate cover ceiling five_gamma_check0032 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0032, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0036 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0036 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0036 ((7 : Int),(1 : Int)) five_gamma_branches0036 copies separate cover ceiling five_gamma_check0036 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0036, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0037 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0037 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0037 ((7 : Int),(1 : Int)) five_gamma_branches0037 copies separate cover ceiling five_gamma_check0037 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0037, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0038 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0038 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0038 ((7 : Int),(1 : Int)) five_gamma_branches0038 copies separate cover ceiling five_gamma_check0038 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0038, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0039 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0039 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0039 ((7 : Int),(1 : Int)) five_gamma_branches0039 copies separate cover ceiling five_gamma_check0039 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0039, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0040 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0040 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0040 ((7 : Int),(1 : Int)) five_gamma_branches0040 copies separate cover ceiling five_gamma_check0040 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0040, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0041 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0041 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0041 ((7 : Int),(1 : Int)) five_gamma_branches0041 copies separate cover ceiling five_gamma_check0041 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0041, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0042 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0042 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0042 ((7 : Int),(1 : Int)) five_gamma_branches0042 copies separate cover ceiling five_gamma_check0042 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0042, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0043 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0043 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0043 ((7 : Int),(1 : Int)) five_gamma_branches0043 copies separate cover ceiling five_gamma_check0043 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0043, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0035 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0035 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0035 ((0 : Int),(8 : Int)) five_gamma_branches0035 copies separate cover ceiling five_gamma_check0035 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0035, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact five_gamma_node0036 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0037 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0038 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0039 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0040 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0041 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0042 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0043 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0045 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0045 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0045 ((7 : Int),(1 : Int)) five_gamma_branches0045 copies separate cover ceiling five_gamma_check0045 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0045, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0046 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0046 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0046 ((7 : Int),(1 : Int)) five_gamma_branches0046 copies separate cover ceiling five_gamma_check0046 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0046, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0047 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0047 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0047 ((7 : Int),(1 : Int)) five_gamma_branches0047 copies separate cover ceiling five_gamma_check0047 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0047, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0048 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0048 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0048 ((7 : Int),(1 : Int)) five_gamma_branches0048 copies separate cover ceiling five_gamma_check0048 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0048, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0049 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0049 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0049 ((7 : Int),(1 : Int)) five_gamma_branches0049 copies separate cover ceiling five_gamma_check0049 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0049, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0050 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0050 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0050 ((7 : Int),(1 : Int)) five_gamma_branches0050 copies separate cover ceiling five_gamma_check0050 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0050, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0051 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0051 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0051 ((7 : Int),(1 : Int)) five_gamma_branches0051 copies separate cover ceiling five_gamma_check0051 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0051, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0052 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0052 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0052 ((7 : Int),(1 : Int)) five_gamma_branches0052 copies separate cover ceiling five_gamma_check0052 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0052, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0044 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0044 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0044 ((0 : Int),(8 : Int)) five_gamma_branches0044 copies separate cover ceiling five_gamma_check0044 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0044, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact five_gamma_node0045 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0046 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0047 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0048 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0049 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0050 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0051 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0052 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0034 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0034 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0034 ((6 : Int),(1 : Int)) five_gamma_branches0034 copies separate cover ceiling five_gamma_check0034 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0034, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0035 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0044 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0055 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0055 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0055 ((7 : Int),(1 : Int)) five_gamma_branches0055 copies separate cover ceiling five_gamma_check0055 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0055, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0056 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0056 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0056 ((7 : Int),(1 : Int)) five_gamma_branches0056 copies separate cover ceiling five_gamma_check0056 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0056, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0057 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0057 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0057 ((7 : Int),(1 : Int)) five_gamma_branches0057 copies separate cover ceiling five_gamma_check0057 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0057, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0058 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0058 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0058 ((7 : Int),(1 : Int)) five_gamma_branches0058 copies separate cover ceiling five_gamma_check0058 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0058, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0059 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0059 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0059 ((7 : Int),(1 : Int)) five_gamma_branches0059 copies separate cover ceiling five_gamma_check0059 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0059, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0060 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0060 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0060 ((7 : Int),(1 : Int)) five_gamma_branches0060 copies separate cover ceiling five_gamma_check0060 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0060, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0061 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0061 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0061 ((7 : Int),(1 : Int)) five_gamma_branches0061 copies separate cover ceiling five_gamma_check0061 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0061, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0062 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0062 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0062 ((7 : Int),(1 : Int)) five_gamma_branches0062 copies separate cover ceiling five_gamma_check0062 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0062, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0054 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0054 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0054 ((0 : Int),(8 : Int)) five_gamma_branches0054 copies separate cover ceiling five_gamma_check0054 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0054, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact five_gamma_node0055 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0056 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0057 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0058 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0059 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0060 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0061 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0062 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0064 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0064 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0064 ((7 : Int),(1 : Int)) five_gamma_branches0064 copies separate cover ceiling five_gamma_check0064 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0064, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0065 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0065 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0065 ((7 : Int),(1 : Int)) five_gamma_branches0065 copies separate cover ceiling five_gamma_check0065 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0065, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0066 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0066 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0066 ((7 : Int),(1 : Int)) five_gamma_branches0066 copies separate cover ceiling five_gamma_check0066 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0066, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0067 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0067 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0067 ((7 : Int),(1 : Int)) five_gamma_branches0067 copies separate cover ceiling five_gamma_check0067 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0067, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0068 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0068 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0068 ((7 : Int),(1 : Int)) five_gamma_branches0068 copies separate cover ceiling five_gamma_check0068 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0068, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0069 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0069 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0069 ((7 : Int),(1 : Int)) five_gamma_branches0069 copies separate cover ceiling five_gamma_check0069 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0069, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0070 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0070 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0070 ((7 : Int),(1 : Int)) five_gamma_branches0070 copies separate cover ceiling five_gamma_check0070 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0070, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0071 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0071 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0071 ((7 : Int),(1 : Int)) five_gamma_branches0071 copies separate cover ceiling five_gamma_check0071 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0071, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0063 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0063 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0063 ((0 : Int),(8 : Int)) five_gamma_branches0063 copies separate cover ceiling five_gamma_check0063 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0063, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact five_gamma_node0064 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0065 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0066 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0067 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0068 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0069 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0070 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0071 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0053 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0053 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0053 ((6 : Int),(1 : Int)) five_gamma_branches0053 copies separate cover ceiling five_gamma_check0053 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0053, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0054 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0063 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0033 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0033 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0033 ((4 : Int),(3 : Int)) five_gamma_branches0033 copies separate cover ceiling five_gamma_check0033 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0033, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0034 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0053 world h copies separate cover ceiling nextB nextState
theorem five_gamma_node0072 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0072 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma five_gamma_occ0072 .alpha (4 : Int) (3 : Int) five_gamma_check0072 B state
include copies separate cover ceiling in
theorem five_gamma_node0073 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0073 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0073 ((5 : Int),(1 : Int)) five_gamma_branches0073 copies separate cover ceiling five_gamma_check0073 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0073, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0074 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0074 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0074 ((5 : Int),(1 : Int)) five_gamma_branches0074 copies separate cover ceiling five_gamma_check0074 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0074, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0027 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0027 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0027 ((4 : Int),(2 : Int)) five_gamma_branches0027 copies separate cover ceiling five_gamma_check0027 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0027, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact five_gamma_node0028 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0031 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0032 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0033 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0072 world h nextB nextState
  · exact five_gamma_node0073 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0074 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0024 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0024 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0024 ((4 : Int),(0 : Int)) five_gamma_branches0024 copies separate cover ceiling five_gamma_check0024 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0024, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact five_gamma_node0025 world h nextB nextState
  · exact five_gamma_node0026 world h nextB nextState
  · exact five_gamma_node0027 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0004 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0004 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0004 ((1 : Int),(3 : Int)) five_gamma_branches0004 copies separate cover ceiling five_gamma_check0004 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0004, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0005 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0024 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0077 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0077 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0077 ((4 : Int),(1 : Int)) five_gamma_branches0077 copies separate cover ceiling five_gamma_check0077 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0077, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0079 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0079 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0079 ((4 : Int),(2 : Int)) five_gamma_branches0079 copies separate cover ceiling five_gamma_check0079 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0079, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0080 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0080 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0080 ((4 : Int),(2 : Int)) five_gamma_branches0080 copies separate cover ceiling five_gamma_check0080 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0080, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0078 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0078 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0078 ((4 : Int),(1 : Int)) five_gamma_branches0078 copies separate cover ceiling five_gamma_check0078 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0078, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0079 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0080 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0081 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0081 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0081 ((4 : Int),(1 : Int)) five_gamma_branches0081 copies separate cover ceiling five_gamma_check0081 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0081, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0076 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0076 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0076 ((4 : Int),(0 : Int)) five_gamma_branches0076 copies separate cover ceiling five_gamma_check0076 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0076, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact five_gamma_node0077 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0078 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0081 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0083 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0083 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0083 ((4 : Int),(1 : Int)) five_gamma_branches0083 copies separate cover ceiling five_gamma_check0083 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0083, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0085 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0085 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0085 ((4 : Int),(2 : Int)) five_gamma_branches0085 copies separate cover ceiling five_gamma_check0085 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0085, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0086 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0086 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0086 ((4 : Int),(2 : Int)) five_gamma_branches0086 copies separate cover ceiling five_gamma_check0086 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0086, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0084 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0084 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0084 ((4 : Int),(1 : Int)) five_gamma_branches0084 copies separate cover ceiling five_gamma_check0084 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0084, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0085 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0086 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0087 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0087 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0087 ((4 : Int),(1 : Int)) five_gamma_branches0087 copies separate cover ceiling five_gamma_check0087 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0087, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0082 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0082 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0082 ((4 : Int),(0 : Int)) five_gamma_branches0082 copies separate cover ceiling five_gamma_check0082 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0082, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact five_gamma_node0083 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0084 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0087 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0075 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0075 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0075 ((1 : Int),(3 : Int)) five_gamma_branches0075 copies separate cover ceiling five_gamma_check0075 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0075, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0076 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0082 world h copies separate cover ceiling nextB nextState
theorem five_gamma_node0090 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0090 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma five_gamma_occ0090 .gammaTranspose (4 : Int) (1 : Int) five_gamma_check0090 B state
theorem five_gamma_node0092 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0092 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma five_gamma_occ0092 .alpha (6 : Int) (1 : Int) five_gamma_check0092 B state
include copies separate cover ceiling in
theorem five_gamma_node0095 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0095 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0095 ((4 : Int),(4 : Int)) five_gamma_branches0095 copies separate cover ceiling five_gamma_check0095 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0095, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0096 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0096 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0096 ((4 : Int),(4 : Int)) five_gamma_branches0096 copies separate cover ceiling five_gamma_check0096 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0096, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0094 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0094 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0094 ((6 : Int),(1 : Int)) five_gamma_branches0094 copies separate cover ceiling five_gamma_check0094 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0094, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0095 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0096 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0098 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0098 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0098 ((4 : Int),(4 : Int)) five_gamma_branches0098 copies separate cover ceiling five_gamma_check0098 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0098, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0099 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0099 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0099 ((4 : Int),(4 : Int)) five_gamma_branches0099 copies separate cover ceiling five_gamma_check0099 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0099, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0097 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0097 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0097 ((6 : Int),(1 : Int)) five_gamma_branches0097 copies separate cover ceiling five_gamma_check0097 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0097, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0098 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0099 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0093 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0093 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0093 ((4 : Int),(3 : Int)) five_gamma_branches0093 copies separate cover ceiling five_gamma_check0093 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0093, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0094 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0097 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0101 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0101 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0101 ((4 : Int),(3 : Int)) five_gamma_branches0101 copies separate cover ceiling five_gamma_check0101 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0101, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0100 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0100 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0100 ((5 : Int),(1 : Int)) five_gamma_branches0100 copies separate cover ceiling five_gamma_check0100 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0100, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact five_gamma_node0101 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0102 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0102 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0102 ((5 : Int),(1 : Int)) five_gamma_branches0102 copies separate cover ceiling five_gamma_check0102 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0102, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0104 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0104 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0104 ((4 : Int),(3 : Int)) five_gamma_branches0104 copies separate cover ceiling five_gamma_check0104 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0104, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0103 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0103 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0103 ((5 : Int),(1 : Int)) five_gamma_branches0103 copies separate cover ceiling five_gamma_check0103 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0103, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact five_gamma_node0104 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0091 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0091 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0091 ((4 : Int),(2 : Int)) five_gamma_branches0091 copies separate cover ceiling five_gamma_check0091 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0091, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact five_gamma_node0092 world h nextB nextState
  · exact five_gamma_node0093 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0100 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0102 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0103 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0089 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0089 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0089 ((3 : Int),(1 : Int)) five_gamma_branches0089 copies separate cover ceiling five_gamma_check0089 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0089, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0090 world h nextB nextState
  · exact five_gamma_node0091 world h copies separate cover ceiling nextB nextState
theorem five_gamma_node0106 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0106 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma five_gamma_occ0106 .gammaTranspose (4 : Int) (1 : Int) five_gamma_check0106 B state
theorem five_gamma_node0108 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0108 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma five_gamma_occ0108 .alpha (6 : Int) (1 : Int) five_gamma_check0108 B state
include copies separate cover ceiling in
theorem five_gamma_node0112 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0112 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0112 ((4 : Int),(4 : Int)) five_gamma_branches0112 copies separate cover ceiling five_gamma_check0112 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0112, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0113 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0113 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0113 ((4 : Int),(4 : Int)) five_gamma_branches0113 copies separate cover ceiling five_gamma_check0113 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0113, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0114 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0114 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0114 ((4 : Int),(4 : Int)) five_gamma_branches0114 copies separate cover ceiling five_gamma_check0114 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0114, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0115 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0115 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0115 ((4 : Int),(4 : Int)) five_gamma_branches0115 copies separate cover ceiling five_gamma_check0115 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0115, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0116 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0116 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0116 ((4 : Int),(4 : Int)) five_gamma_branches0116 copies separate cover ceiling five_gamma_check0116 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0116, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0117 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0117 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0117 ((4 : Int),(4 : Int)) five_gamma_branches0117 copies separate cover ceiling five_gamma_check0117 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0117, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0118 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0118 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0118 ((4 : Int),(4 : Int)) five_gamma_branches0118 copies separate cover ceiling five_gamma_check0118 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0118, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0119 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0119 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0119 ((4 : Int),(4 : Int)) five_gamma_branches0119 copies separate cover ceiling five_gamma_check0119 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0119, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0111 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0111 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0111 ((0 : Int),(8 : Int)) five_gamma_branches0111 copies separate cover ceiling five_gamma_check0111 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0111, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact five_gamma_node0112 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0113 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0114 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0115 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0116 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0117 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0118 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0119 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0121 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0121 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0121 ((4 : Int),(4 : Int)) five_gamma_branches0121 copies separate cover ceiling five_gamma_check0121 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0121, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0122 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0122 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0122 ((4 : Int),(4 : Int)) five_gamma_branches0122 copies separate cover ceiling five_gamma_check0122 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0122, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0123 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0123 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0123 ((4 : Int),(4 : Int)) five_gamma_branches0123 copies separate cover ceiling five_gamma_check0123 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0123, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0124 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0124 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0124 ((4 : Int),(4 : Int)) five_gamma_branches0124 copies separate cover ceiling five_gamma_check0124 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0124, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0125 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0125 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0125 ((4 : Int),(4 : Int)) five_gamma_branches0125 copies separate cover ceiling five_gamma_check0125 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0125, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0126 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0126 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0126 ((4 : Int),(4 : Int)) five_gamma_branches0126 copies separate cover ceiling five_gamma_check0126 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0126, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0127 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0127 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0127 ((4 : Int),(4 : Int)) five_gamma_branches0127 copies separate cover ceiling five_gamma_check0127 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0127, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0128 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0128 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0128 ((4 : Int),(4 : Int)) five_gamma_branches0128 copies separate cover ceiling five_gamma_check0128 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0128, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0120 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0120 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0120 ((0 : Int),(8 : Int)) five_gamma_branches0120 copies separate cover ceiling five_gamma_check0120 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0120, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact five_gamma_node0121 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0122 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0123 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0124 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0125 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0126 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0127 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0128 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0110 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0110 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0110 ((6 : Int),(1 : Int)) five_gamma_branches0110 copies separate cover ceiling five_gamma_check0110 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0110, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0111 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0120 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0131 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0131 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0131 ((4 : Int),(4 : Int)) five_gamma_branches0131 copies separate cover ceiling five_gamma_check0131 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0131, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0132 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0132 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0132 ((4 : Int),(4 : Int)) five_gamma_branches0132 copies separate cover ceiling five_gamma_check0132 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0132, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0133 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0133 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0133 ((4 : Int),(4 : Int)) five_gamma_branches0133 copies separate cover ceiling five_gamma_check0133 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0133, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0134 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0134 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0134 ((4 : Int),(4 : Int)) five_gamma_branches0134 copies separate cover ceiling five_gamma_check0134 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0134, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0135 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0135 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0135 ((4 : Int),(4 : Int)) five_gamma_branches0135 copies separate cover ceiling five_gamma_check0135 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0135, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0136 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0136 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0136 ((4 : Int),(4 : Int)) five_gamma_branches0136 copies separate cover ceiling five_gamma_check0136 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0136, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0137 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0137 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0137 ((4 : Int),(4 : Int)) five_gamma_branches0137 copies separate cover ceiling five_gamma_check0137 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0137, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0138 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0138 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0138 ((4 : Int),(4 : Int)) five_gamma_branches0138 copies separate cover ceiling five_gamma_check0138 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0138, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0130 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0130 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0130 ((0 : Int),(8 : Int)) five_gamma_branches0130 copies separate cover ceiling five_gamma_check0130 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0130, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact five_gamma_node0131 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0132 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0133 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0134 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0135 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0136 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0137 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0138 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0140 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0140 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0140 ((4 : Int),(4 : Int)) five_gamma_branches0140 copies separate cover ceiling five_gamma_check0140 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0140, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0141 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0141 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0141 ((4 : Int),(4 : Int)) five_gamma_branches0141 copies separate cover ceiling five_gamma_check0141 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0141, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0142 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0142 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0142 ((4 : Int),(4 : Int)) five_gamma_branches0142 copies separate cover ceiling five_gamma_check0142 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0142, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0143 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0143 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0143 ((4 : Int),(4 : Int)) five_gamma_branches0143 copies separate cover ceiling five_gamma_check0143 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0143, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0144 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0144 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0144 ((4 : Int),(4 : Int)) five_gamma_branches0144 copies separate cover ceiling five_gamma_check0144 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0144, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0145 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0145 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0145 ((4 : Int),(4 : Int)) five_gamma_branches0145 copies separate cover ceiling five_gamma_check0145 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0145, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0146 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0146 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0146 ((4 : Int),(4 : Int)) five_gamma_branches0146 copies separate cover ceiling five_gamma_check0146 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0146, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0147 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0147 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0147 ((4 : Int),(4 : Int)) five_gamma_branches0147 copies separate cover ceiling five_gamma_check0147 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0147, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0139 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0139 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0139 ((0 : Int),(8 : Int)) five_gamma_branches0139 copies separate cover ceiling five_gamma_check0139 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0139, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact five_gamma_node0140 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0141 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0142 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0143 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0144 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0145 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0146 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0147 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0129 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0129 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0129 ((6 : Int),(1 : Int)) five_gamma_branches0129 copies separate cover ceiling five_gamma_check0129 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0129, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0130 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0139 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0109 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0109 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0109 ((4 : Int),(3 : Int)) five_gamma_branches0109 copies separate cover ceiling five_gamma_check0109 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0109, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0110 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0129 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0149 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0149 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0149 ((4 : Int),(3 : Int)) five_gamma_branches0149 copies separate cover ceiling five_gamma_check0149 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0149, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0148 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0148 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0148 ((5 : Int),(1 : Int)) five_gamma_branches0148 copies separate cover ceiling five_gamma_check0148 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0148, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact five_gamma_node0149 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0150 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0150 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0150 ((5 : Int),(1 : Int)) five_gamma_branches0150 copies separate cover ceiling five_gamma_check0150 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0150, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0152 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0152 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0152 ((4 : Int),(3 : Int)) five_gamma_branches0152 copies separate cover ceiling five_gamma_check0152 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0152, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0151 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0151 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0151 ((5 : Int),(1 : Int)) five_gamma_branches0151 copies separate cover ceiling five_gamma_check0151 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0151, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact five_gamma_node0152 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0107 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0107 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0107 ((4 : Int),(2 : Int)) five_gamma_branches0107 copies separate cover ceiling five_gamma_check0107 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0107, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact five_gamma_node0108 world h nextB nextState
  · exact five_gamma_node0109 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0148 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0150 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0151 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0105 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0105 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0105 ((3 : Int),(1 : Int)) five_gamma_branches0105 copies separate cover ceiling five_gamma_check0105 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0105, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0106 world h nextB nextState
  · exact five_gamma_node0107 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0088 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0088 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0088 ((1 : Int),(3 : Int)) five_gamma_branches0088 copies separate cover ceiling five_gamma_check0088 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0088, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0089 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0105 world h copies separate cover ceiling nextB nextState
theorem five_gamma_node0153 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0153 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma five_gamma_occ0153 .alpha (3 : Int) (1 : Int) five_gamma_check0153 B state
include copies separate cover ceiling in
theorem five_gamma_node0156 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0156 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0156 ((4 : Int),(1 : Int)) five_gamma_branches0156 copies separate cover ceiling five_gamma_check0156 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0156, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0157 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0157 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0157 ((4 : Int),(1 : Int)) five_gamma_branches0157 copies separate cover ceiling five_gamma_check0157 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0157, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0155 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0155 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0155 ((3 : Int),(1 : Int)) five_gamma_branches0155 copies separate cover ceiling five_gamma_check0155 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0155, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0156 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0157 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0159 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0159 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0159 ((4 : Int),(1 : Int)) five_gamma_branches0159 copies separate cover ceiling five_gamma_check0159 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0159, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0160 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0160 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0160 ((4 : Int),(1 : Int)) five_gamma_branches0160 copies separate cover ceiling five_gamma_check0160 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0160, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0158 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0158 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0158 ((3 : Int),(1 : Int)) five_gamma_branches0158 copies separate cover ceiling five_gamma_check0158 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0158, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0159 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0160 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0154 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0154 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0154 ((1 : Int),(3 : Int)) five_gamma_branches0154 copies separate cover ceiling five_gamma_check0154 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0154, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0155 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0158 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0003 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0003 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0003 ((3 : Int),(0 : Int)) five_gamma_branches0003 copies separate cover ceiling five_gamma_check0003 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0003, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact five_gamma_node0004 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0075 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0088 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0153 world h nextB nextState
  · exact five_gamma_node0154 world h copies separate cover ceiling nextB nextState
theorem five_gamma_node0161 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0161 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma five_gamma_occ0161 .beta (1 : Int) (2 : Int) five_gamma_check0161 B state
theorem five_gamma_node0162 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0162 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma five_gamma_occ0162 .gamma (1 : Int) (2 : Int) five_gamma_check0162 B state
theorem five_gamma_node0163 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0163 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma five_gamma_occ0163 .beta (1 : Int) (2 : Int) five_gamma_check0163 B state
include copies separate cover ceiling in
theorem five_gamma_node0167 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0167 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0167 ((3 : Int),(2 : Int)) five_gamma_branches0167 copies separate cover ceiling five_gamma_check0167 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0167, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0168 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0168 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0168 ((3 : Int),(2 : Int)) five_gamma_branches0168 copies separate cover ceiling five_gamma_check0168 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0168, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0166 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0166 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0166 ((2 : Int),(2 : Int)) five_gamma_branches0166 copies separate cover ceiling five_gamma_check0166 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0166, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0167 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0168 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0169 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0169 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0169 ((2 : Int),(2 : Int)) five_gamma_branches0169 copies separate cover ceiling five_gamma_check0169 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0169, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0170 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0170 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0170 ((2 : Int),(2 : Int)) five_gamma_branches0170 copies separate cover ceiling five_gamma_check0170 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0170, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0173 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0173 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0173 ((4 : Int),(2 : Int)) five_gamma_branches0173 copies separate cover ceiling five_gamma_check0173 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0173, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0174 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0174 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0174 ((4 : Int),(2 : Int)) five_gamma_branches0174 copies separate cover ceiling five_gamma_check0174 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0174, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0172 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0172 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0172 ((3 : Int),(2 : Int)) five_gamma_branches0172 copies separate cover ceiling five_gamma_check0172 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0172, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0173 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0174 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0176 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0176 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0176 ((4 : Int),(2 : Int)) five_gamma_branches0176 copies separate cover ceiling five_gamma_check0176 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0176, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0177 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0177 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0177 ((4 : Int),(2 : Int)) five_gamma_branches0177 copies separate cover ceiling five_gamma_check0177 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0177, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0175 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0175 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0175 ((3 : Int),(2 : Int)) five_gamma_branches0175 copies separate cover ceiling five_gamma_check0175 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0175, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0176 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0177 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0171 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0171 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0171 ((1 : Int),(4 : Int)) five_gamma_branches0171 copies separate cover ceiling five_gamma_check0171 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0171, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0172 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0175 world h copies separate cover ceiling nextB nextState
theorem five_gamma_node0178 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0178 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma five_gamma_occ0178 .alpha (1 : Int) (4 : Int) five_gamma_check0178 B state
include copies separate cover ceiling in
theorem five_gamma_node0179 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0179 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0179 ((2 : Int),(2 : Int)) five_gamma_branches0179 copies separate cover ceiling five_gamma_check0179 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0179, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0180 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0180 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0180 ((2 : Int),(2 : Int)) five_gamma_branches0180 copies separate cover ceiling five_gamma_check0180 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0180, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0165 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0165 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0165 ((1 : Int),(3 : Int)) five_gamma_branches0165 copies separate cover ceiling five_gamma_check0165 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0165, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact five_gamma_node0166 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0169 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0170 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0171 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0178 world h nextB nextState
  · exact five_gamma_node0179 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0180 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0164 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0164 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0164 ((2 : Int),(0 : Int)) five_gamma_branches0164 copies separate cover ceiling five_gamma_check0164 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0164, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact five_gamma_node0165 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0002 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0002 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0002 ((1 : Int),(1 : Int)) five_gamma_branches0002 copies separate cover ceiling five_gamma_check0002 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0002, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact five_gamma_node0003 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0161 world h nextB nextState
  · exact five_gamma_node0162 world h nextB nextState
  · exact five_gamma_node0163 world h nextB nextState
  · exact five_gamma_node0164 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0182 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0182 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0182 ((1 : Int),(2 : Int)) five_gamma_branches0182 copies separate cover ceiling five_gamma_check0182 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0182, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0185 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0185 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0185 ((1 : Int),(3 : Int)) five_gamma_branches0185 copies separate cover ceiling five_gamma_check0185 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0185, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0186 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0186 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0186 ((1 : Int),(3 : Int)) five_gamma_branches0186 copies separate cover ceiling five_gamma_check0186 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0186, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0184 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0184 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0184 ((3 : Int),(0 : Int)) five_gamma_branches0184 copies separate cover ceiling five_gamma_check0184 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0184, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0185 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0186 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0188 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0188 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0188 ((1 : Int),(3 : Int)) five_gamma_branches0188 copies separate cover ceiling five_gamma_check0188 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0188, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0189 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0189 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0189 ((1 : Int),(3 : Int)) five_gamma_branches0189 copies separate cover ceiling five_gamma_check0189 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0189, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0187 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0187 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0187 ((3 : Int),(0 : Int)) five_gamma_branches0187 copies separate cover ceiling five_gamma_check0187 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0187, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0188 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0189 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0183 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0183 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0183 ((1 : Int),(2 : Int)) five_gamma_branches0183 copies separate cover ceiling five_gamma_check0183 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0183, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0184 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0187 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0191 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0191 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0191 ((1 : Int),(2 : Int)) five_gamma_branches0191 copies separate cover ceiling five_gamma_check0191 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0191, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0190 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0190 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0190 ((2 : Int),(0 : Int)) five_gamma_branches0190 copies separate cover ceiling five_gamma_check0190 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0190, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact five_gamma_node0191 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0192 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0192 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0192 ((2 : Int),(0 : Int)) five_gamma_branches0192 copies separate cover ceiling five_gamma_check0192 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0192, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0194 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0194 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0194 ((1 : Int),(2 : Int)) five_gamma_branches0194 copies separate cover ceiling five_gamma_check0194 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0194, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0193 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0193 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0193 ((2 : Int),(0 : Int)) five_gamma_branches0193 copies separate cover ceiling five_gamma_check0193 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0193, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact five_gamma_node0194 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0181 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0181 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0181 ((1 : Int),(1 : Int)) five_gamma_branches0181 copies separate cover ceiling five_gamma_check0181 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0181, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact five_gamma_node0182 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0183 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0190 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0192 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0193 world h copies separate cover ceiling nextB nextState
theorem five_gamma_node0196 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0196 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma five_gamma_occ0196 .beta (1 : Int) (2 : Int) five_gamma_check0196 B state
theorem five_gamma_node0197 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0197 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma five_gamma_occ0197 .gammaTranspose (1 : Int) (2 : Int) five_gamma_check0197 B state
theorem five_gamma_node0200 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0200 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma five_gamma_occ0200 .alpha (3 : Int) (2 : Int) five_gamma_check0200 B state
include copies separate cover ceiling in
theorem five_gamma_node0203 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0203 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0203 ((1 : Int),(5 : Int)) five_gamma_branches0203 copies separate cover ceiling five_gamma_check0203 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0203, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0204 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0204 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0204 ((1 : Int),(5 : Int)) five_gamma_branches0204 copies separate cover ceiling five_gamma_check0204 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0204, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0202 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0202 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0202 ((3 : Int),(2 : Int)) five_gamma_branches0202 copies separate cover ceiling five_gamma_check0202 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0202, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0203 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0204 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0206 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0206 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0206 ((1 : Int),(5 : Int)) five_gamma_branches0206 copies separate cover ceiling five_gamma_check0206 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0206, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0207 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0207 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0207 ((1 : Int),(5 : Int)) five_gamma_branches0207 copies separate cover ceiling five_gamma_check0207 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0207, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0205 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0205 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0205 ((3 : Int),(2 : Int)) five_gamma_branches0205 copies separate cover ceiling five_gamma_check0205 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0205, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0206 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0207 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0201 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0201 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0201 ((1 : Int),(4 : Int)) five_gamma_branches0201 copies separate cover ceiling five_gamma_check0201 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0201, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0202 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0205 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0209 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0209 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0209 ((1 : Int),(4 : Int)) five_gamma_branches0209 copies separate cover ceiling five_gamma_check0209 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0209, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0208 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0208 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0208 ((2 : Int),(2 : Int)) five_gamma_branches0208 copies separate cover ceiling five_gamma_check0208 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0208, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact five_gamma_node0209 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0210 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0210 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0210 ((2 : Int),(2 : Int)) five_gamma_branches0210 copies separate cover ceiling five_gamma_check0210 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0210, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0212 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0212 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0212 ((1 : Int),(4 : Int)) five_gamma_branches0212 copies separate cover ceiling five_gamma_check0212 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0212, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0211 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0211 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0211 ((2 : Int),(2 : Int)) five_gamma_branches0211 copies separate cover ceiling five_gamma_check0211 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0211, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact five_gamma_node0212 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0199 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0199 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0199 ((1 : Int),(3 : Int)) five_gamma_branches0199 copies separate cover ceiling five_gamma_check0199 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0199, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact five_gamma_node0200 world h nextB nextState
  · exact five_gamma_node0201 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0208 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0210 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0211 world h copies separate cover ceiling nextB nextState
theorem five_gamma_node0214 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0214 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma five_gamma_occ0214 .alpha (3 : Int) (2 : Int) five_gamma_check0214 B state
include copies separate cover ceiling in
theorem five_gamma_node0217 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0217 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0217 ((1 : Int),(5 : Int)) five_gamma_branches0217 copies separate cover ceiling five_gamma_check0217 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0217, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0218 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0218 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0218 ((1 : Int),(5 : Int)) five_gamma_branches0218 copies separate cover ceiling five_gamma_check0218 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0218, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0216 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0216 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0216 ((3 : Int),(2 : Int)) five_gamma_branches0216 copies separate cover ceiling five_gamma_check0216 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0216, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0217 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0218 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0220 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0220 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0220 ((1 : Int),(5 : Int)) five_gamma_branches0220 copies separate cover ceiling five_gamma_check0220 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0220, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0221 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0221 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0221 ((1 : Int),(5 : Int)) five_gamma_branches0221 copies separate cover ceiling five_gamma_check0221 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0221, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0219 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0219 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0219 ((3 : Int),(2 : Int)) five_gamma_branches0219 copies separate cover ceiling five_gamma_check0219 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0219, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0220 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0221 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0215 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0215 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0215 ((1 : Int),(4 : Int)) five_gamma_branches0215 copies separate cover ceiling five_gamma_check0215 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0215, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0216 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0219 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0222 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0222 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0222 ((2 : Int),(2 : Int)) five_gamma_branches0222 copies separate cover ceiling five_gamma_check0222 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0222, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0223 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0223 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0223 ((2 : Int),(2 : Int)) five_gamma_branches0223 copies separate cover ceiling five_gamma_check0223 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0223, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0224 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0224 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0224 ((2 : Int),(2 : Int)) five_gamma_branches0224 copies separate cover ceiling five_gamma_check0224 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0224, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0213 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0213 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0213 ((1 : Int),(3 : Int)) five_gamma_branches0213 copies separate cover ceiling five_gamma_check0213 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0213, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact five_gamma_node0214 world h nextB nextState
  · exact five_gamma_node0215 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0222 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0223 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0224 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0198 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0198 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0198 ((2 : Int),(0 : Int)) five_gamma_branches0198 copies separate cover ceiling five_gamma_check0198 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0198, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0199 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0213 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0195 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0195 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0195 ((0 : Int),(2 : Int)) five_gamma_branches0195 copies separate cover ceiling five_gamma_check0195 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0195, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact five_gamma_node0196 world h nextB nextState
  · exact five_gamma_node0197 world h nextB nextState
  · exact five_gamma_node0198 world h copies separate cover ceiling nextB nextState
theorem five_gamma_node0226 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0226 B) : Transition world h .gamma B := by
  exact replay_leaf world h .gamma five_gamma_occ0226 .alpha (1 : Int) (2 : Int) five_gamma_check0226 B state
include copies separate cover ceiling in
theorem five_gamma_node0227 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0227 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0227 ((2 : Int),(0 : Int)) five_gamma_branches0227 copies separate cover ceiling five_gamma_check0227 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0227, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0228 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0228 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0228 ((2 : Int),(0 : Int)) five_gamma_branches0228 copies separate cover ceiling five_gamma_check0228 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0228, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0229 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0229 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0229 ((2 : Int),(0 : Int)) five_gamma_branches0229 copies separate cover ceiling five_gamma_check0229 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0229, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0230 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0230 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0230 ((2 : Int),(0 : Int)) five_gamma_branches0230 copies separate cover ceiling five_gamma_check0230 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0230, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0225 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0225 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0225 ((0 : Int),(2 : Int)) five_gamma_branches0225 copies separate cover ceiling five_gamma_check0225 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0225, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact five_gamma_node0226 world h nextB nextState
  · exact five_gamma_node0227 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0228 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0229 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0230 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0234 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0234 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0234 ((2 : Int),(2 : Int)) five_gamma_branches0234 copies separate cover ceiling five_gamma_check0234 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0234, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0235 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0235 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0235 ((2 : Int),(2 : Int)) five_gamma_branches0235 copies separate cover ceiling five_gamma_check0235 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0235, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0233 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0233 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0233 ((1 : Int),(2 : Int)) five_gamma_branches0233 copies separate cover ceiling five_gamma_check0233 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0233, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0234 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0235 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0237 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0237 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0237 ((2 : Int),(2 : Int)) five_gamma_branches0237 copies separate cover ceiling five_gamma_check0237 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0237, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0238 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0238 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0238 ((2 : Int),(2 : Int)) five_gamma_branches0238 copies separate cover ceiling five_gamma_check0238 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0238, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0236 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0236 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0236 ((1 : Int),(2 : Int)) five_gamma_branches0236 copies separate cover ceiling five_gamma_check0236 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0236, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0237 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0238 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0232 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0232 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0232 ((2 : Int),(0 : Int)) five_gamma_branches0232 copies separate cover ceiling five_gamma_check0232 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0232, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0233 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0236 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0240 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0240 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0240 ((1 : Int),(2 : Int)) five_gamma_branches0240 copies separate cover ceiling five_gamma_check0240 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0240, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0241 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0241 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0241 ((1 : Int),(2 : Int)) five_gamma_branches0241 copies separate cover ceiling five_gamma_check0241 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0241, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0239 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0239 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0239 ((2 : Int),(0 : Int)) five_gamma_branches0239 copies separate cover ceiling five_gamma_check0239 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0239, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0240 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0241 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0243 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0243 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0243 ((1 : Int),(2 : Int)) five_gamma_branches0243 copies separate cover ceiling five_gamma_check0243 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0243, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0244 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0244 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0244 ((1 : Int),(2 : Int)) five_gamma_branches0244 copies separate cover ceiling five_gamma_check0244 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0244, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gamma_node0242 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0242 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0242 ((2 : Int),(0 : Int)) five_gamma_branches0242 copies separate cover ceiling five_gamma_check0242 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0242, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gamma_node0243 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0244 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0231 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0231 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0231 ((0 : Int),(2 : Int)) five_gamma_branches0231 copies separate cover ceiling five_gamma_check0231 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0231, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact five_gamma_node0232 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0239 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0242 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gamma_node0000 (B : Int → Int → Prop)
    (state : State world h five_gamma_occ0000 B) : Transition world h .gamma B := by
  apply replay_step (5 : Int) (by decide) world h .gamma five_gamma_occ0000 ((0 : Int),(1 : Int)) five_gamma_branches0000 copies separate cover ceiling five_gamma_check0000 ?_ B state
  intro branch member nextB nextState
  simp only [five_gamma_branches0000, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact five_gamma_node0001 world h nextB nextState
  · exact five_gamma_node0002 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0181 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0195 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0225 world h copies separate cover ceiling nextB nextState
  · exact five_gamma_node0231 world h copies separate cover ceiling nextB nextState
end FiveGamma

theorem five_gamma_seed_eq : SameCells (seed .gamma) five_gamma_occ0000 := by decide

theorem five_gamma_local (world : Cross → Prop) (h : Int) (B : Int → Int → Prop)
    (copies : ∀ t, world t → Copy 5 1 1 0 t)
    (separate : DisjointWorld world) (cover : CoversWindow world h)
    (ceiling : SelectedBelow world h) (closed : TileClosed world B)
    (bounded : Below h B) (clean : Clean .gamma 0 0 B) :
    Transition world h .gamma B := by
  exact five_gamma_node0000 world h copies separate cover ceiling B
    (state_congr five_gamma_seed_eq (seed_state world h .gamma B closed bounded clean))
#print axioms five_gamma_local

end CornerCertificate

import LHalfPlaneShortbarAssembly
import LHalfPlaneFiveThree
import LQuadrantHpBoundaryallAdjacentHwestLocalGeometry
import LQuadrantHpBoundaryallDeltaTwoHwestLocalGeometry

namespace PolyominoFormal.LHalfPlaneShortbarAssembly
open CrossUnits LRegion

/-- Two neighboring arm lengths: the left-pointing long bar above a short
boundary bar is impossible in an ordinary half-plane tiling. The finite trees
use no boundary-tip or forbidden-pair pruning lemmas. -/
theorem upright_long_left_near {a b : Int} (ha : 5≤a) (hb : 3≤b)
    (hab : b<a) (hnear : a≤b+2) : PairObstruction a b ⟨a+1,1,0,b,a,0⟩ := by
  intro T hO hU
  by_cases special : a=5 ∧ b=3
  · rcases special with ⟨rfl,rfl⟩
    exact LHalfPlaneFiveThree.no_halfplane ⟨T⟩
  have hex : a≠5 ∨ b≠3 := by omega
  by_cases hadj : a=b+1
  · apply HP_boundaryall_adjacent_hwest_local_anchored_obstruction a b
      (by omega) hb hab ha hadj hex T hO
    simpa only [Int.add_comm] using hU
  · apply HP_boundaryall_delta_two_hwest_local_anchored_obstruction a b
      (by omega) hb hab ha (by omega) hex T hO
    simpa only [Int.add_comm] using hU

#print axioms upright_long_left_near
end PolyominoFormal.LHalfPlaneShortbarAssembly

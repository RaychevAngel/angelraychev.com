import Std.Tactic
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace LRegionArithmetic

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n000_point (a b : Int)
    (h0 : (¬ (((-2 : Int) ≥ (-((4 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((4 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((4 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n000_empty (a b : Int)
    (h0 : (¬ ((((0 : Int) = b) ∧ (a = (0 : Int)) ∧ ((0 : Int) = b) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ (((0 : Int) = a) ∧ (a = (0 : Int)) ∧ ((0 : Int) = a) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h1 : (((((-2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (0 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + a)))) ∨ ((((-2 : Int) ≥ ((1 : Int) - b)) ∧ ((-2 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ ((1 : Int) ≥ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((-2 : Int) ≥ ((-1 : Int) - a)) ∧ ((-2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-1 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + b))))))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n000_o0 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (¬ (((jx = ((-2 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n000_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n000_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h3 : (¬ ((((-2 : Int) = jx) ∧ (jy = ((1 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h4 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n000_o3 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h1 : ((jx < ((1 : Int) - b)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h2 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n000_o4 (a b jx jy : Int)
    (h0 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ ((((0 : Int) = a) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ ((((0 : Int) = b) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = b)))))))
    (h1 : ((jx < ((1 : Int) - b)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - a))))
    (h2 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n000_o5 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h1 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h2 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h3 : (¬ ((((-2 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n000_o6 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h3 : (¬ (((jx = ((-2 : Int) + ((-1 : Int) * b))) ∧ ((1 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n000_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (¬ ((((((jy = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = b) ∧ (b = b) ∧ (b = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (((-1 : Int) = ((jx + a) + (1 : Int))) ∨ (jx = (((-1 : Int) + a) + (1 : Int)))) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = a) ∧ (a = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ (((jy = (0 : Int)) ∧ ((0 : Int) = b) ∧ (b = (0 : Int)) ∧ ((0 : Int) = (b + (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((-1 : Int) = (jx + (1 : Int))) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a) ∧ ((-1 : Int) = (jx - (1 : Int))) ∧ ((0 : Int) = a) ∧ (a = (0 : Int))))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ (jy = (b + (1 : Int))) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int)) ∧ (jx = ((-1 : Int) + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = a)) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (jx = ((-1 : Int) - (1 : Int))) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))) ∨ (((0 : Int) = jy) ∧ ((0 : Int) = a) ∧ (b = a) ∧ (b = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (((-1 : Int) = ((jx + b) + (1 : Int))) ∨ ((((-1 : Int) + b) + (1 : Int)) = jx)) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = b) ∧ (a = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b))))) ∨ (((jy = (0 : Int)) ∧ ((0 : Int) = b) ∧ (b = (0 : Int)) ∧ ((0 : Int) = (a + (1 : Int))) ∧ (b = (0 : Int)) ∧ ((0 : Int) = a) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((-1 : Int) = (jx + (1 : Int))) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b)) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a) ∧ ((-1 : Int) = (jx - (1 : Int))) ∧ ((0 : Int) = b) ∧ (a = (0 : Int))))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ (jy = (a + (1 : Int))) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int)) ∧ (jx = ((-1 : Int) + (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = b)) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (jx = ((-1 : Int) - (1 : Int))) ∧ (a = b) ∧ ((0 : Int) = (0 : Int))))))) ∨ (((jy = (0 : Int)) ∧ ((0 : Int) = a) ∧ (b = (0 : Int)) ∧ ((0 : Int) = (1 : Int)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((-1 : Int) = (jx + (1 : Int))) ∧ ((0 : Int) = a) ∧ (a = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b) ∧ ((-1 : Int) = (jx - (1 : Int))) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((0 : Int) = (0 : Int)) ∧ (jy = (1 : Int)) ∧ ((0 : Int) = b) ∧ (b = (0 : Int)) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int)) ∧ (jx = ((-1 : Int) + (1 : Int))) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b) ∧ (jx = ((-1 : Int) - (1 : Int))) ∧ (a = (0 : Int)) ∧ ((0 : Int) = a))))))))
    : False := by
  apply h4
  clear h4
  left
  left
  left
  right
  right
  refine ⟨?_,?_,?_,?_,?_,?_,?_⟩
  · omega
  · omega
  · omega
  · omega
  · omega
  · omega
  · right
    refine ⟨?_,?_,?_,?_,?_⟩
    · omega
    · omega
    · omega
    · omega
    · omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n001_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((-2 : Int) ≥ (-((4 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((4 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((4 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n001_empty (a b : Int)
    (h0 : (((((-2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + a)))) ∨ ((((-2 : Int) ≥ ((1 : Int) - b)) ∧ ((-2 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((1 : Int) + a)) ∧ ((2 : Int) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((-2 : Int) ≥ ((-1 : Int) - a)) ∧ ((-2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + b)))) ∨ ((((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + b))))))
    (h1 : (a ≥ (5 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n001_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h5 : ((jx < ((-2 : Int) + ((-1 : Int) * a))) ∨ (((-2 : Int) + ((-1 : Int) * a)) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n001_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((1 : Int) - b)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - a))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b)))))))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n001_o2 (a b jx jy : Int)
    (h0 : (¬ ((((-2 : Int) = jx) ∧ (jy = ((2 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (((jx + (0 : Int)) < ((-2 : Int) + ((-1 : Int) * a))) ∨ (((-2 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n001_o3 (a b jx jy : Int)
    (h0 : ((jx < ((1 : Int) - b)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h1 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h2 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h3 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n001_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ ((((0 : Int) = a) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ ((((0 : Int) = b) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = b)))))))
    (h3 : ((jx < ((1 : Int) - b)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - a))))
    (h4 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n001_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h2 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((jx + (0 : Int)) < ((-2 : Int) + ((-1 : Int) * a))) ∨ (((-2 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h5 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n001_o6 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((jx = ((-2 : Int) + ((-1 : Int) * b))) ∧ ((2 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n001_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h2 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((1 : Int) - b)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - b))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n002_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((2 : Int) ≤ ((1 : Int) + b))))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n002_run_short (a b : Int)
    (h0 : (¬ ((((1 : Int) + b) - (2 : Int)) < b)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n002_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n002_run_left (a b : Int)
    (h0 : (¬ ((((((0 : Int) - (0 : Int)) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≥ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) ≥ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-2 : Int) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≥ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((((2 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n002_run_right (a b : Int)
    (h0 : (¬ ((((((0 : Int) - (0 : Int)) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≥ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) ≥ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + a) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-2 : Int) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≥ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((((2 : Int) + b) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n002_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (¬ (((((2 : Int) + (3 : Int)) ≤ ((1 : Int) + b)) ∧ (((((((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((0 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-2 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((2 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int)))))) ∨ ((((((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((0 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((1 : Int) + a) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-2 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((2 : Int) + b) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int)))))))) ∨ ((((2 : Int) + (2 : Int)) ≤ ((1 : Int) + b)) ∧ ((((((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((0 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-2 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((2 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int)))))) ∧ ((((((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((0 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((1 : Int) + a) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-2 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((2 : Int) + b) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))))) ∨ (((2 : Int) + (4 : Int)) ≤ ((1 : Int) + b)) ∨ ((((1 : Int) + b) = ((2 : Int) + (1 : Int))) ∧ ((((((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((0 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-2 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((2 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int)))))) ∧ ((((((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((0 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((1 : Int) + a) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-2 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((2 : Int) + b) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int)))))) ∧ (((((((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + a) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((0 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + a) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-2 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((2 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int)))))) ∨ ((((((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + a) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((0 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + a) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((1 : Int) + a) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-2 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((2 : Int) + b) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int)))))))) ∨ (((((((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((0 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-2 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((2 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int)))))) ∧ ((((((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((0 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((1 : Int) + a) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + b) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-2 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((2 : Int) + b) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int)))))) ∧ ((((((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + a) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((0 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + a) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-2 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((2 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int)))))) ∧ ((((((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + a) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((0 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + a) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((1 : Int) + a) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-1 : Int) + ((-1 : Int) * a)) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-2 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((2 : Int) + b) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))))))))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  apply h1
  clear h1
  right
  left
  refine ⟨?_,?_,?_⟩
  · omega
  · right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · omega
    · omega
    · omega
    · omega
  · right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · omega
    · omega
    · omega
    · omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n002_run_empty (a b run_x : Int)
    (h0 : ((((((0 : Int) - (0 : Int)) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((0 : Int) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≥ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) ≥ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ (((-1 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b))) ∨ (((-2 : Int) ≤ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≥ ((-1 : Int) + ((-1 : Int) * a))) ∧ ((((2 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + b) + (0 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((2 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (run_x ≤ ((1 : Int) + b)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n002_run_floor (a b run_x : Int)
    (h0 : ((2 : Int) ≤ run_x))
    (h1 : (¬ ((((((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((0 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((0 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((1 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ ((((((-2 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ ((((-2 : Int) + ((-1 : Int) * a)) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-1 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b))) ∨ (((-2 : Int) ≤ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-1 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((2 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + b) + (0 : Int))))))))
    (h2 : (run_x ≤ ((1 : Int) + b)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n003_point (a b : Int)
    (h0 : (¬ (((-2 : Int) ≥ (-((4 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((4 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((4 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n003_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((((-2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + a)))) ∨ ((((-2 : Int) ≥ ((1 : Int) - b)) ∧ ((-2 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) + a)) ∧ ((3 : Int) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((-2 : Int) ≥ ((-1 : Int) - a)) ∧ ((-2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ ((((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ ((((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∧ ((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) + b)) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-2 : Int) ≥ ((-2 : Int) + ((-1 : Int) * b))) ∧ ((-2 : Int) ≤ ((-2 : Int) + ((-1 : Int) * b))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a))))))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n003_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((-2 : Int) + ((-1 : Int) * a))) ∨ (((-2 : Int) + ((-1 : Int) * a)) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h5 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n003_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((1 : Int) - b)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - a))))
    (h3 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n003_o2 (a b jx jy : Int)
    (h0 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h1 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((1 : Int) - b)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - b))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((jx + (0 : Int)) < ((-2 : Int) + ((-1 : Int) * b))) ∨ (((-2 : Int) + ((-1 : Int) * b)) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n003_o3 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < (((-2 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h2 : (((jx + (0 : Int)) < ((-2 : Int) + ((-1 : Int) * b))) ∨ (((-2 : Int) + ((-1 : Int) * b)) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h3 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n003_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((1 : Int) - b)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - a))))
    (h3 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ ((((0 : Int) = a) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ ((((0 : Int) = b) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = b)))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n003_o5 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((-2 : Int) + ((-1 : Int) * a))) ∨ (((-2 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h1 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h2 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h3 : ((jx < (((-2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * b)) + b) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n003_o6 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((-2 : Int) + ((-1 : Int) * b))) ∨ (((-2 : Int) + ((-1 : Int) * b)) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h2 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h3 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n003_o7 (a b jx jy : Int)
    (h0 : ((jx < ((1 : Int) - b)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - b))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n004_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((1 : Int) ≤ b)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n004_run_short (a b : Int)
    (h0 : (¬ ((b - (1 : Int)) < b)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n004_run_nonnegative (a b : Int)
    (h0 : (¬ ((1 : Int) ≥ (0 : Int))))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n004_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((((0 : Int) - (0 : Int)) ≤ (-(3 : Int))) ∧ ((-(3 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (-(3 : Int))) ∧ ((0 : Int) ≥ (-(3 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-(3 : Int))) ∧ ((-(3 : Int)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-(3 : Int))) ∧ ((1 : Int) ≥ (-(3 : Int))) ∧ ((((1 : Int) + a) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-(3 : Int))) ∧ ((-(3 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-(3 : Int))) ∧ ((-1 : Int) ≥ (-(3 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-(3 : Int))) ∧ ((-(3 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (-(3 : Int))) ∧ ((-2 : Int) ≥ (-(3 : Int))) ∧ ((((1 : Int) + b) - b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int))))))))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n004_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((((0 : Int) - (0 : Int)) ≤ (-(3 : Int))) ∧ ((-(3 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ (((0 : Int) ≤ (-(3 : Int))) ∧ ((0 : Int) ≥ (-(3 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-(3 : Int))) ∧ ((-(3 : Int)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-(3 : Int))) ∧ ((1 : Int) ≥ (-(3 : Int))) ∧ ((((1 : Int) + a) - a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-(3 : Int))) ∧ ((-(3 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ (((-1 : Int) ≤ (-(3 : Int))) ∧ ((-1 : Int) ≥ (-(3 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-(3 : Int))) ∧ ((-(3 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (-(3 : Int))) ∧ ((-2 : Int) ≥ (-(3 : Int))) ∧ ((((1 : Int) + b) - b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int))))))))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n004_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((((1 : Int) + (3 : Int)) ≤ b) ∧ (((((((0 : Int) - (0 : Int)) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (-((3 : Int) + b))) ∧ ((0 : Int) ≥ (-((3 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-((3 : Int) + b))) ∧ ((1 : Int) ≥ (-((3 : Int) + b))) ∧ ((((1 : Int) + a) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-((3 : Int) + b))) ∧ ((-1 : Int) ≥ (-((3 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (-((3 : Int) + b))) ∧ ((-2 : Int) ≥ (-((3 : Int) + b))) ∧ ((((1 : Int) + b) - b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int)))))) ∨ ((((((0 : Int) - (0 : Int)) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ (((0 : Int) ≤ (-((3 : Int) + b))) ∧ ((0 : Int) ≥ (-((3 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-((3 : Int) + b))) ∧ ((1 : Int) ≥ (-((3 : Int) + b))) ∧ ((((1 : Int) + a) - a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ (((-1 : Int) ≤ (-((3 : Int) + b))) ∧ ((-1 : Int) ≥ (-((3 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (-((3 : Int) + b))) ∧ ((-2 : Int) ≥ (-((3 : Int) + b))) ∧ ((((1 : Int) + b) - b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int)))))))) ∨ ((((1 : Int) + (2 : Int)) ≤ b) ∧ ((((((0 : Int) - (0 : Int)) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (-((3 : Int) + b))) ∧ ((0 : Int) ≥ (-((3 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-((3 : Int) + b))) ∧ ((1 : Int) ≥ (-((3 : Int) + b))) ∧ ((((1 : Int) + a) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-((3 : Int) + b))) ∧ ((-1 : Int) ≥ (-((3 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (-((3 : Int) + b))) ∧ ((-2 : Int) ≥ (-((3 : Int) + b))) ∧ ((((1 : Int) + b) - b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int)))))) ∧ ((((((0 : Int) - (0 : Int)) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ (((0 : Int) ≤ (-((3 : Int) + b))) ∧ ((0 : Int) ≥ (-((3 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-((3 : Int) + b))) ∧ ((1 : Int) ≥ (-((3 : Int) + b))) ∧ ((((1 : Int) + a) - a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ (((-1 : Int) ≤ (-((3 : Int) + b))) ∧ ((-1 : Int) ≥ (-((3 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (-((3 : Int) + b))) ∧ ((-2 : Int) ≥ (-((3 : Int) + b))) ∧ ((((1 : Int) + b) - b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int))))))) ∨ (((1 : Int) + (4 : Int)) ≤ b) ∨ ((b = ((1 : Int) + (1 : Int))) ∧ ((((((0 : Int) - (0 : Int)) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (-((3 : Int) + b))) ∧ ((0 : Int) ≥ (-((3 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-((3 : Int) + b))) ∧ ((1 : Int) ≥ (-((3 : Int) + b))) ∧ ((((1 : Int) + a) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-((3 : Int) + b))) ∧ ((-1 : Int) ≥ (-((3 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (-((3 : Int) + b))) ∧ ((-2 : Int) ≥ (-((3 : Int) + b))) ∧ ((((1 : Int) + b) - b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int)))))) ∧ ((((((0 : Int) - (0 : Int)) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ (((0 : Int) ≤ (-((3 : Int) + b))) ∧ ((0 : Int) ≥ (-((3 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-((3 : Int) + b))) ∧ ((1 : Int) ≥ (-((3 : Int) + b))) ∧ ((((1 : Int) + a) - a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ (((-1 : Int) ≤ (-((3 : Int) + b))) ∧ ((-1 : Int) ≥ (-((3 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (-((3 : Int) + b))) ∧ ((-2 : Int) ≥ (-((3 : Int) + b))) ∧ ((((1 : Int) + b) - b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int)))))) ∧ (((((((0 : Int) - (0 : Int)) ≤ (-((3 : Int) + a))) ∧ ((-((3 : Int) + a)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (-((3 : Int) + a))) ∧ ((0 : Int) ≥ (-((3 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-((3 : Int) + a))) ∧ ((-((3 : Int) + a)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-((3 : Int) + a))) ∧ ((1 : Int) ≥ (-((3 : Int) + a))) ∧ ((((1 : Int) + a) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-((3 : Int) + a))) ∧ ((-((3 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-((3 : Int) + a))) ∧ ((-1 : Int) ≥ (-((3 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-((3 : Int) + a))) ∧ ((-((3 : Int) + a)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (-((3 : Int) + a))) ∧ ((-2 : Int) ≥ (-((3 : Int) + a))) ∧ ((((1 : Int) + b) - b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int)))))) ∨ ((((((0 : Int) - (0 : Int)) ≤ (-((3 : Int) + a))) ∧ ((-((3 : Int) + a)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ (((0 : Int) ≤ (-((3 : Int) + a))) ∧ ((0 : Int) ≥ (-((3 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-((3 : Int) + a))) ∧ ((-((3 : Int) + a)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-((3 : Int) + a))) ∧ ((1 : Int) ≥ (-((3 : Int) + a))) ∧ ((((1 : Int) + a) - a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-((3 : Int) + a))) ∧ ((-((3 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ (((-1 : Int) ≤ (-((3 : Int) + a))) ∧ ((-1 : Int) ≥ (-((3 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-((3 : Int) + a))) ∧ ((-((3 : Int) + a)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (-((3 : Int) + a))) ∧ ((-2 : Int) ≥ (-((3 : Int) + a))) ∧ ((((1 : Int) + b) - b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int)))))))) ∨ (((((((0 : Int) - (0 : Int)) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (-((3 : Int) + b))) ∧ ((0 : Int) ≥ (-((3 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-((3 : Int) + b))) ∧ ((1 : Int) ≥ (-((3 : Int) + b))) ∧ ((((1 : Int) + a) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-((3 : Int) + b))) ∧ ((-1 : Int) ≥ (-((3 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (-((3 : Int) + b))) ∧ ((-2 : Int) ≥ (-((3 : Int) + b))) ∧ ((((1 : Int) + b) - b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int)))))) ∧ ((((((0 : Int) - (0 : Int)) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ (((0 : Int) ≤ (-((3 : Int) + b))) ∧ ((0 : Int) ≥ (-((3 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-((3 : Int) + b))) ∧ ((1 : Int) ≥ (-((3 : Int) + b))) ∧ ((((1 : Int) + a) - a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ (((-1 : Int) ≤ (-((3 : Int) + b))) ∧ ((-1 : Int) ≥ (-((3 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-((3 : Int) + b))) ∧ ((-((3 : Int) + b)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (-((3 : Int) + b))) ∧ ((-2 : Int) ≥ (-((3 : Int) + b))) ∧ ((((1 : Int) + b) - b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int)))))) ∧ ((((((0 : Int) - (0 : Int)) ≤ (-((3 : Int) + a))) ∧ ((-((3 : Int) + a)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (-((3 : Int) + a))) ∧ ((0 : Int) ≥ (-((3 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-((3 : Int) + a))) ∧ ((-((3 : Int) + a)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-((3 : Int) + a))) ∧ ((1 : Int) ≥ (-((3 : Int) + a))) ∧ ((((1 : Int) + a) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-((3 : Int) + a))) ∧ ((-((3 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-((3 : Int) + a))) ∧ ((-1 : Int) ≥ (-((3 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-((3 : Int) + a))) ∧ ((-((3 : Int) + a)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (-((3 : Int) + a))) ∧ ((-2 : Int) ≥ (-((3 : Int) + a))) ∧ ((((1 : Int) + b) - b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int)))))) ∧ ((((((0 : Int) - (0 : Int)) ≤ (-((3 : Int) + a))) ∧ ((-((3 : Int) + a)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ (((0 : Int) ≤ (-((3 : Int) + a))) ∧ ((0 : Int) ≥ (-((3 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-((3 : Int) + a))) ∧ ((-((3 : Int) + a)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-((3 : Int) + a))) ∧ ((1 : Int) ≥ (-((3 : Int) + a))) ∧ ((((1 : Int) + a) - a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-((3 : Int) + a))) ∧ ((-((3 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ (((-1 : Int) ≤ (-((3 : Int) + a))) ∧ ((-1 : Int) ≥ (-((3 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-((3 : Int) + a))) ∧ ((-((3 : Int) + a)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (-((3 : Int) + a))) ∧ ((-2 : Int) ≥ (-((3 : Int) + a))) ∧ ((((1 : Int) + b) - b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int))))))))))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  apply h1
  clear h1
  by_cases split0 : (((1 : Int) + (3 : Int)) ≤ b)
  · by_cases split1 : (((1 : Int) + (4 : Int)) ≤ b)
    · right
      right
      left
      omega
    · left
      refine ⟨?_,?_⟩
      · omega
      · right
        right
        right
        right
        left
        refine ⟨?_,?_,?_,?_⟩
        · omega
        · omega
        · omega
        · omega
  · right
    left
    refine ⟨?_,?_,?_⟩
    · omega
    · right
      right
      left
      left
      refine ⟨?_,?_,?_,?_⟩
      · omega
      · omega
      · omega
      · omega
    · right
      right
      right
      left
      refine ⟨?_,?_,?_,?_⟩
      · omega
      · omega
      · omega
      · omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n004_run_empty (a b run_x : Int)
    (h0 : ((1 : Int) ≤ run_x))
    (h1 : ((((((0 : Int) - (0 : Int)) ≤ (-(3 : Int))) ∧ ((-(3 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((0 : Int) ≤ (-(3 : Int))) ∧ ((0 : Int) ≥ (-(3 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-(3 : Int))) ∧ ((-(3 : Int)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-(3 : Int))) ∧ ((1 : Int) ≥ (-(3 : Int))) ∧ ((((1 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-(3 : Int))) ∧ ((-(3 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ (-(3 : Int))) ∧ ((-1 : Int) ≥ (-(3 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-(3 : Int))) ∧ ((-(3 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (-(3 : Int))) ∧ ((-2 : Int) ≥ (-(3 : Int))) ∧ ((((1 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + b) + (0 : Int)))))))
    (h2 : (a > b))
    (h3 : (run_x ≤ b))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n004_run_floor (a b run_x : Int)
    (h0 : (¬ ((((((0 : Int) - (0 : Int)) ≤ (-((3 : Int) - (1 : Int)))) ∧ ((-((3 : Int) - (1 : Int))) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((0 : Int) ≤ (-((3 : Int) - (1 : Int)))) ∧ ((0 : Int) ≥ (-((3 : Int) - (1 : Int)))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-((3 : Int) - (1 : Int)))) ∧ ((-((3 : Int) - (1 : Int))) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-((3 : Int) - (1 : Int)))) ∧ ((1 : Int) ≥ (-((3 : Int) - (1 : Int)))) ∧ ((((1 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-((3 : Int) - (1 : Int)))) ∧ ((-((3 : Int) - (1 : Int))) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ (-((3 : Int) - (1 : Int)))) ∧ ((-1 : Int) ≥ (-((3 : Int) - (1 : Int)))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-((3 : Int) - (1 : Int)))) ∧ ((-((3 : Int) - (1 : Int))) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (-((3 : Int) - (1 : Int)))) ∧ ((-2 : Int) ≥ (-((3 : Int) - (1 : Int)))) ∧ ((((1 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + b) + (0 : Int))))))))
    (h1 : ((1 : Int) ≤ run_x))
    (h2 : (run_x ≤ b))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n005_point (a b : Int)
    (h0 : (¬ (((-1 : Int) ≥ (-((4 : Int) * ((a + b) + (1 : Int))))) ∧ (((1 : Int) + b) ≥ (0 : Int)) ∧ ((-1 : Int) ≤ ((4 : Int) * ((a + b) + (1 : Int)))) ∧ (((1 : Int) + b) ≤ ((4 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n005_empty (a b : Int)
    (h0 : (a > b))
    (h1 : (((((-1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-1 : Int) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((1 : Int) + b)) ∧ ((0 : Int) ≥ ((1 : Int) + b))) ∨ (((0 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) + b)) ∧ (((1 : Int) + b) ≤ ((0 : Int) + a)))) ∨ ((((-1 : Int) ≥ ((1 : Int) - b)) ∧ ((-1 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((1 : Int) + b)) ∧ (((1 : Int) + b) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (1 : Int)) ∧ ((((1 : Int) + a) - a) ≤ ((1 : Int) + b)) ∧ (((1 : Int) + b) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((-1 : Int) ≥ ((-1 : Int) - a)) ∧ ((-1 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((1 : Int) + b)) ∧ ((0 : Int) ≥ ((1 : Int) + b))) ∨ (((-1 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) + b)) ∧ (((1 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((-1 : Int) ≥ ((-2 : Int) - a)) ∧ ((-1 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≥ ((1 : Int) + b))) ∨ (((-2 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-2 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((1 : Int) + b)) ∧ (((1 : Int) + b) ≤ ((1 : Int) + b))))))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n005_o0 (a b jx jy : Int)
    (h0 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h1 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ (jy ≤ ((1 : Int) + b)) ∧ (((1 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((1 : Int) + b)) ∧ (((1 : Int) + b) ≤ (jy + b)))))
    (h3 : (a > b))
    (h4 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n005_o1 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ (jy ≤ ((1 : Int) + b)) ∧ (((1 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - a) ≤ ((1 : Int) + b)) ∧ (((1 : Int) + b) ≤ (jy + (0 : Int))))))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((jx < ((1 : Int) - b)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - a))))
    (h5 : (a > b))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n005_o2 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((1 : Int) + b)) ∧ (((1 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - b) ≤ ((1 : Int) + b)) ∧ (((1 : Int) + b) ≤ (jy + (0 : Int))))))
    (h1 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - b))))
    (h2 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + ((2 : Int) * b))) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n005_o3 (a b jx jy : Int)
    (h0 : (a > b))
    (h1 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((1 : Int) + b)) ∧ (((1 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((1 : Int) + b)) ∧ (((1 : Int) + b) ≤ (jy + a)))))
    (h2 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h3 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h4 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n005_o4 (a b jx jy : Int)
    (h0 : ((jx < ((1 : Int) - b)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - a))))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ ((((0 : Int) = a) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ ((((0 : Int) = b) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = b)))))))
    (h2 : (a > b))
    (h3 : ((((-1 : Int) ≥ (jx - b)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((1 : Int) + b)) ∧ (((1 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - a) ≤ ((1 : Int) + b)) ∧ (((1 : Int) + b) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n005_o5 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - a)) ∧ ((-1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((1 : Int) + b)) ∧ (((1 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((1 : Int) + b)) ∧ (((1 : Int) + b) ≤ (jy + b)))))
    (h1 : (a > b))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((jx + (0 : Int)) < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < (jx - a)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h4 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h5 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n005_o6 (a b jx jy : Int)
    (h0 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + b)) ∧ (jy ≤ ((1 : Int) + b)) ∧ (((1 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((1 : Int) + b)) ∧ (((1 : Int) + b) ≤ (jy + a)))))
    (h1 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h2 : (a > b))
    (h3 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h4 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n005_o7 (a b jx jy : Int)
    (h0 : ((jx < ((1 : Int) - b)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - b))))
    (h1 : (a > b))
    (h2 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h3 : ((((-1 : Int) ≥ (jx - (0 : Int))) ∧ ((-1 : Int) ≤ (jx + a)) ∧ (jy ≤ ((1 : Int) + b)) ∧ (((1 : Int) + b) ≤ jy)) ∨ (((-1 : Int) ≥ jx) ∧ ((-1 : Int) ≤ jx) ∧ ((jy - b) ≤ ((1 : Int) + b)) ∧ (((1 : Int) + b) ≤ (jy + (0 : Int))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n006_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ b))
    (h2 : (¬ (((-3 : Int) ≥ (-((4 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((-3 : Int) ≤ ((4 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((4 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n006_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((((-3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((1 : Int) - b)) ∧ ((-3 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((1 : Int) + a)) ∧ ((2 : Int) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((-3 : Int) ≥ ((-1 : Int) - a)) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-2 : Int) - a)) ∧ ((-3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-2 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-1 : Int) - a)) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((1 : Int) + ((2 : Int) * b))) ∧ ((2 : Int) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) - b)) ∧ ((2 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int)))))))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n006_o0 (a b jx jy : Int)
    (h0 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h1 : (¬ (((jx = ((-3 : Int) + ((-1 : Int) * a))) ∧ ((2 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h3 : (a ≥ b))
    (h4 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n006_o1 (a b jx jy : Int)
    (h0 : (((-1 : Int) > ((1 : Int) + (0 : Int))) ∨ ((-1 : Int) < ((1 : Int) - b)) ∨ (((1 : Int) + a) < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((1 : Int) + a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (a ≥ b))
    (h4 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jy - a))))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n006_o2 (a b jx jy : Int)
    (h0 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ ((((-3 : Int) = jx) ∧ (jy = ((2 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (a ≥ b))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n006_o3 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h2 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jy - (0 : Int)))))
    (h3 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h4 : (((-1 : Int) > ((1 : Int) + (0 : Int))) ∨ ((-1 : Int) < ((1 : Int) - b)) ∨ (((1 : Int) + a) < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((1 : Int) + a))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a ≥ b))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n006_o4 (a b jx jy : Int)
    (h0 : (((-1 : Int) > ((1 : Int) + (0 : Int))) ∨ ((-1 : Int) < ((1 : Int) - b)) ∨ (((1 : Int) + a) < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((1 : Int) + a))))
    (h1 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jy - a))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n006_o5 (a b jx jy : Int)
    (h0 : ((jx < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h3 : (¬ ((((-3 : Int) = jx) ∧ ((2 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h5 : (a ≥ b))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n006_o6 (a b jx jy : Int)
    (h0 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h1 : (a ≥ b))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jy - (0 : Int)))))
    (h5 : (((-1 : Int) > ((1 : Int) + (0 : Int))) ∨ ((-1 : Int) < ((1 : Int) - b)) ∨ (((1 : Int) + a) < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((1 : Int) + a))))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n006_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h2 : (a ≥ b))
    (h3 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h4 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n007_point (a b : Int)
    (h0 : (¬ (((-3 : Int) ≥ (-((4 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((-3 : Int) ≤ ((4 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((4 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n007_empty (a b : Int)
    (h0 : (((((-3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-3 : Int) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + a)))) ∨ ((((-3 : Int) ≥ ((1 : Int) - b)) ∧ ((-3 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) + a)) ∧ ((3 : Int) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((-3 : Int) ≥ ((-1 : Int) - a)) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-2 : Int) - a)) ∧ ((-3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-2 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-1 : Int) - a)) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ (((1 : Int) + ((2 : Int) * b)) - b)) ∧ ((3 : Int) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ ((((-3 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((-3 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-3 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n007_o0 (a b jx jy : Int)
    (h0 : ((jx < (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h2 : ((jx < ((-3 : Int) + ((-1 : Int) * a))) ∨ (((-3 : Int) + ((-1 : Int) * a)) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h5 : (a ≥ b))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n007_o1 (a b jx jy : Int)
    (h0 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (((-1 : Int) > ((1 : Int) + (0 : Int))) ∨ ((-1 : Int) < ((1 : Int) - b)) ∨ (((1 : Int) + a) < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((1 : Int) + a))))
    (h3 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n007_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (((jx + (0 : Int)) < ((-3 : Int) + ((-1 : Int) * a))) ∨ (((-3 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h2 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (¬ ((((-3 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h4 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n007_o3 (a b jx jy : Int)
    (h0 : (((-1 : Int) > ((1 : Int) + (0 : Int))) ∨ ((-1 : Int) < ((1 : Int) - b)) ∨ (((1 : Int) + a) < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((1 : Int) + a))))
    (h1 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h2 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h3 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jy - (0 : Int)))))
    (h4 : ((jx < (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n007_o4 (a b jx jy : Int)
    (h0 : (a ≥ b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jy - a))))
    (h3 : (((-1 : Int) > ((1 : Int) + (0 : Int))) ∨ ((-1 : Int) < ((1 : Int) - b)) ∨ (((1 : Int) + a) < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((1 : Int) + a))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n007_o5 (a b jx jy : Int)
    (h0 : ((jx < (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h2 : (((jx + (0 : Int)) < ((-3 : Int) + ((-1 : Int) * a))) ∨ (((-3 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h3 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n007_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jy - (0 : Int)))))
    (h3 : (a ≥ b))
    (h4 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h5 : (((-1 : Int) > ((1 : Int) + (0 : Int))) ∨ ((-1 : Int) < ((1 : Int) - b)) ∨ (((1 : Int) + a) < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((1 : Int) + a))))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n007_o7 (a b jx jy : Int)
    (h0 : (a ≥ b))
    (h1 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h3 : (((-1 : Int) > ((1 : Int) + (0 : Int))) ∨ ((-1 : Int) < ((1 : Int) - b)) ∨ (((1 : Int) + a) < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((1 : Int) + a))))
    (h4 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n008_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≤ ((2 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n008_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + b) - (3 : Int)) < b)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n008_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n008_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((((0 : Int) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-2 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-3 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))))))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n008_run_right (a b : Int)
    (h0 : (¬ ((((((0 : Int) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + a) - a) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + b) + (1 : Int)))) ∨ (((-2 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + b) + (1 : Int)))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-3 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - b) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n008_run_tall (a b : Int)
    (h0 : (¬ (((((3 : Int) + (3 : Int)) ≤ ((2 : Int) + b)) ∧ (((((((0 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((0 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((1 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((3 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int)))))) ∨ ((((((0 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((0 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((1 : Int) + a) - a) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + b) + (1 : Int)))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ (((1 : Int) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + b) + (1 : Int)))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((3 : Int) + b) - b) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int)))))))) ∨ ((((3 : Int) + (2 : Int)) ≤ ((2 : Int) + b)) ∧ ((((((0 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((0 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((1 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((3 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int)))))) ∧ ((((((0 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((0 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((1 : Int) + a) - a) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + b) + (1 : Int)))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ (((1 : Int) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + b) + (1 : Int)))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((3 : Int) + b) - b) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))))) ∨ (((3 : Int) + (4 : Int)) ≤ ((2 : Int) + b)) ∨ ((((2 : Int) + b) = ((3 : Int) + (1 : Int))) ∧ ((((((0 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((0 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((1 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((3 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int)))))) ∧ ((((((0 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((0 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((1 : Int) + a) - a) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + b) + (1 : Int)))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ (((1 : Int) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + b) + (1 : Int)))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((3 : Int) + b) - b) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int)))))) ∧ (((((((0 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((0 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((1 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((3 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int)))))) ∨ ((((((0 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((0 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((1 : Int) + a) - a) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + b) + (1 : Int)))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + b) + (1 : Int)))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((3 : Int) + b) - b) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int)))))))) ∨ (((((((0 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((0 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((1 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((3 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int)))))) ∧ ((((((0 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((0 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((1 : Int) + a) - a) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + b) + (1 : Int)))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ (((1 : Int) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + b) + (1 : Int)))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + b) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + b)) ∧ ((((3 : Int) + b) - b) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int)))))) ∧ ((((((0 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((0 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((1 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((3 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int)))))) ∧ ((((((0 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((0 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((1 : Int) + a) - a) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + b) + (1 : Int)))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + b) + (1 : Int)))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((3 : Int) + b) - b) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))))))))
    (h1 : (a > b))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  apply h0
  clear h0
  right
  left
  refine ⟨?_,?_,?_⟩
  · omega
  · right
    right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · omega
    · omega
    · omega
    · omega
  · right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · omega
    · omega
    · omega
    · omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n008_run_empty (a b run_x : Int)
    (h0 : (a ≥ b))
    (h1 : (run_x ≤ ((2 : Int) + b)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((((0 : Int) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((0 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-3 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + (0 : Int)))))))
    (h4 : ((3 : Int) ≤ run_x))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n008_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((2 : Int) + b)))
    (h1 : ((3 : Int) ≤ run_x))
    (h2 : (¬ ((((((0 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((0 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((0 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((1 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (((((-3 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + (0 : Int))))))))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n009_run_four (a b : Int)
    (h0 : (¬ ((2 : Int) ≤ ((1 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n009_run_short (a b : Int)
    (h0 : (¬ ((((1 : Int) + b) - (2 : Int)) < b)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n009_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n009_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((((0 : Int) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (-(4 : Int))) ∧ ((0 : Int) ≥ (-(4 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-(4 : Int))) ∧ ((1 : Int) ≥ (-(4 : Int))) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-(4 : Int))) ∧ ((-1 : Int) ≥ (-(4 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-2 : Int) ≤ (-(4 : Int))) ∧ ((-2 : Int) ≥ (-(4 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (-(4 : Int))) ∧ ((-1 : Int) ≥ (-(4 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-3 : Int) ≤ (-(4 : Int))) ∧ ((-3 : Int) ≥ (-(4 : Int))) ∧ ((((2 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))))))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n009_run_right (a b : Int)
    (h0 : (¬ ((((((0 : Int) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ (-(4 : Int))) ∧ ((0 : Int) ≥ (-(4 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-(4 : Int))) ∧ ((1 : Int) ≥ (-(4 : Int))) ∧ ((((1 : Int) + a) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ (-(4 : Int))) ∧ ((-1 : Int) ≥ (-(4 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((-2 : Int) ≤ (-(4 : Int))) ∧ ((-2 : Int) ≥ (-(4 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (-(4 : Int))) ∧ ((-1 : Int) ≥ (-(4 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-3 : Int) ≤ (-(4 : Int))) ∧ ((-3 : Int) ≥ (-(4 : Int))) ∧ ((((2 : Int) + b) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n009_run_tall (a b : Int)
    (h0 : (¬ (((((2 : Int) + (3 : Int)) ≤ ((1 : Int) + b)) ∧ (((((((0 : Int) - (0 : Int)) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (-((4 : Int) + b))) ∧ ((0 : Int) ≥ (-((4 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-((4 : Int) + b))) ∧ ((1 : Int) ≥ (-((4 : Int) + b))) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + b))) ∧ ((-1 : Int) ≥ (-((4 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-2 : Int) ≤ (-((4 : Int) + b))) ∧ ((-2 : Int) ≥ (-((4 : Int) + b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + b))) ∧ ((-1 : Int) ≥ (-((4 : Int) + b))) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-3 : Int) ≤ (-((4 : Int) + b))) ∧ ((-3 : Int) ≥ (-((4 : Int) + b))) ∧ ((((2 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int)))))) ∨ ((((((0 : Int) - (0 : Int)) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ (-((4 : Int) + b))) ∧ ((0 : Int) ≥ (-((4 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-((4 : Int) + b))) ∧ ((1 : Int) ≥ (-((4 : Int) + b))) ∧ ((((1 : Int) + a) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + b))) ∧ ((-1 : Int) ≥ (-((4 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((-2 : Int) ≤ (-((4 : Int) + b))) ∧ ((-2 : Int) ≥ (-((4 : Int) + b))) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + b))) ∧ ((-1 : Int) ≥ (-((4 : Int) + b))) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-3 : Int) ≤ (-((4 : Int) + b))) ∧ ((-3 : Int) ≥ (-((4 : Int) + b))) ∧ ((((2 : Int) + b) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int)))))))) ∨ ((((2 : Int) + (2 : Int)) ≤ ((1 : Int) + b)) ∧ ((((((0 : Int) - (0 : Int)) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (-((4 : Int) + b))) ∧ ((0 : Int) ≥ (-((4 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-((4 : Int) + b))) ∧ ((1 : Int) ≥ (-((4 : Int) + b))) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + b))) ∧ ((-1 : Int) ≥ (-((4 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-2 : Int) ≤ (-((4 : Int) + b))) ∧ ((-2 : Int) ≥ (-((4 : Int) + b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + b))) ∧ ((-1 : Int) ≥ (-((4 : Int) + b))) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-3 : Int) ≤ (-((4 : Int) + b))) ∧ ((-3 : Int) ≥ (-((4 : Int) + b))) ∧ ((((2 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int)))))) ∧ ((((((0 : Int) - (0 : Int)) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ (-((4 : Int) + b))) ∧ ((0 : Int) ≥ (-((4 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-((4 : Int) + b))) ∧ ((1 : Int) ≥ (-((4 : Int) + b))) ∧ ((((1 : Int) + a) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + b))) ∧ ((-1 : Int) ≥ (-((4 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((-2 : Int) ≤ (-((4 : Int) + b))) ∧ ((-2 : Int) ≥ (-((4 : Int) + b))) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + b))) ∧ ((-1 : Int) ≥ (-((4 : Int) + b))) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-3 : Int) ≤ (-((4 : Int) + b))) ∧ ((-3 : Int) ≥ (-((4 : Int) + b))) ∧ ((((2 : Int) + b) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))))) ∨ (((2 : Int) + (4 : Int)) ≤ ((1 : Int) + b)) ∨ ((((1 : Int) + b) = ((2 : Int) + (1 : Int))) ∧ ((((((0 : Int) - (0 : Int)) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (-((4 : Int) + b))) ∧ ((0 : Int) ≥ (-((4 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-((4 : Int) + b))) ∧ ((1 : Int) ≥ (-((4 : Int) + b))) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + b))) ∧ ((-1 : Int) ≥ (-((4 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-2 : Int) ≤ (-((4 : Int) + b))) ∧ ((-2 : Int) ≥ (-((4 : Int) + b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + b))) ∧ ((-1 : Int) ≥ (-((4 : Int) + b))) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-3 : Int) ≤ (-((4 : Int) + b))) ∧ ((-3 : Int) ≥ (-((4 : Int) + b))) ∧ ((((2 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int)))))) ∧ ((((((0 : Int) - (0 : Int)) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ (-((4 : Int) + b))) ∧ ((0 : Int) ≥ (-((4 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-((4 : Int) + b))) ∧ ((1 : Int) ≥ (-((4 : Int) + b))) ∧ ((((1 : Int) + a) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + b))) ∧ ((-1 : Int) ≥ (-((4 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((-2 : Int) ≤ (-((4 : Int) + b))) ∧ ((-2 : Int) ≥ (-((4 : Int) + b))) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + b))) ∧ ((-1 : Int) ≥ (-((4 : Int) + b))) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-3 : Int) ≤ (-((4 : Int) + b))) ∧ ((-3 : Int) ≥ (-((4 : Int) + b))) ∧ ((((2 : Int) + b) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int)))))) ∧ (((((((0 : Int) - (0 : Int)) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (-((4 : Int) + a))) ∧ ((0 : Int) ≥ (-((4 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-((4 : Int) + a))) ∧ ((1 : Int) ≥ (-((4 : Int) + a))) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-2 : Int) ≤ (-((4 : Int) + a))) ∧ ((-2 : Int) ≥ (-((4 : Int) + a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-3 : Int) ≤ (-((4 : Int) + a))) ∧ ((-3 : Int) ≥ (-((4 : Int) + a))) ∧ ((((2 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int)))))) ∨ ((((((0 : Int) - (0 : Int)) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ (-((4 : Int) + a))) ∧ ((0 : Int) ≥ (-((4 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-((4 : Int) + a))) ∧ ((1 : Int) ≥ (-((4 : Int) + a))) ∧ ((((1 : Int) + a) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((-2 : Int) ≤ (-((4 : Int) + a))) ∧ ((-2 : Int) ≥ (-((4 : Int) + a))) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-3 : Int) ≤ (-((4 : Int) + a))) ∧ ((-3 : Int) ≥ (-((4 : Int) + a))) ∧ ((((2 : Int) + b) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int)))))))) ∨ (((((((0 : Int) - (0 : Int)) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (-((4 : Int) + b))) ∧ ((0 : Int) ≥ (-((4 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-((4 : Int) + b))) ∧ ((1 : Int) ≥ (-((4 : Int) + b))) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + b))) ∧ ((-1 : Int) ≥ (-((4 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-2 : Int) ≤ (-((4 : Int) + b))) ∧ ((-2 : Int) ≥ (-((4 : Int) + b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + b))) ∧ ((-1 : Int) ≥ (-((4 : Int) + b))) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-3 : Int) ≤ (-((4 : Int) + b))) ∧ ((-3 : Int) ≥ (-((4 : Int) + b))) ∧ ((((2 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int)))))) ∧ ((((((0 : Int) - (0 : Int)) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ (-((4 : Int) + b))) ∧ ((0 : Int) ≥ (-((4 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-((4 : Int) + b))) ∧ ((1 : Int) ≥ (-((4 : Int) + b))) ∧ ((((1 : Int) + a) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + b))) ∧ ((-1 : Int) ≥ (-((4 : Int) + b))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((-2 : Int) ≤ (-((4 : Int) + b))) ∧ ((-2 : Int) ≥ (-((4 : Int) + b))) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + b))) ∧ ((-1 : Int) ≥ (-((4 : Int) + b))) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-((4 : Int) + b))) ∧ ((-((4 : Int) + b)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-3 : Int) ≤ (-((4 : Int) + b))) ∧ ((-3 : Int) ≥ (-((4 : Int) + b))) ∧ ((((2 : Int) + b) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int)))))) ∧ ((((((0 : Int) - (0 : Int)) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (-((4 : Int) + a))) ∧ ((0 : Int) ≥ (-((4 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-((4 : Int) + a))) ∧ ((1 : Int) ≥ (-((4 : Int) + a))) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-2 : Int) ≤ (-((4 : Int) + a))) ∧ ((-2 : Int) ≥ (-((4 : Int) + a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-3 : Int) ≤ (-((4 : Int) + a))) ∧ ((-3 : Int) ≥ (-((4 : Int) + a))) ∧ ((((2 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int)))))) ∧ ((((((0 : Int) - (0 : Int)) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ (-((4 : Int) + a))) ∧ ((0 : Int) ≥ (-((4 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-((4 : Int) + a))) ∧ ((1 : Int) ≥ (-((4 : Int) + a))) ∧ ((((1 : Int) + a) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((-2 : Int) ≤ (-((4 : Int) + a))) ∧ ((-2 : Int) ≥ (-((4 : Int) + a))) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((-3 : Int) ≤ (-((4 : Int) + a))) ∧ ((-3 : Int) ≥ (-((4 : Int) + a))) ∧ ((((2 : Int) + b) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  apply h0
  clear h0
  by_cases split0 : (((2 : Int) + (3 : Int)) ≤ ((1 : Int) + b))
  · by_cases split1 : (((2 : Int) + (4 : Int)) ≤ ((1 : Int) + b))
    · right
      right
      left
      omega
    · left
      refine ⟨?_,?_⟩
      · omega
      · right
        right
        right
        right
        right
        right
        left
        refine ⟨?_,?_,?_,?_⟩
        · omega
        · omega
        · omega
        · omega
  · right
    left
    refine ⟨?_,?_,?_⟩
    · omega
    · right
      right
      right
      left
      left
      refine ⟨?_,?_,?_,?_⟩
      · omega
      · omega
      · omega
      · omega
    · right
      right
      right
      right
      right
      left
      refine ⟨?_,?_,?_,?_⟩
      · omega
      · omega
      · omega
      · omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n009_run_empty (a b run_x : Int)
    (h0 : (run_x ≤ ((1 : Int) + b)))
    (h1 : (((-1 : Int) > ((1 : Int) + (0 : Int))) ∨ ((-1 : Int) < ((1 : Int) - b)) ∨ (((1 : Int) + a) < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((1 : Int) + a))))
    (h2 : (a ≥ b))
    (h3 : ((((((0 : Int) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((0 : Int) ≤ (-(4 : Int))) ∧ ((0 : Int) ≥ (-(4 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-(4 : Int))) ∧ ((1 : Int) ≥ (-(4 : Int))) ∧ ((((1 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ (-(4 : Int))) ∧ ((-1 : Int) ≥ (-(4 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ (-(4 : Int))) ∧ ((-2 : Int) ≥ (-(4 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (-(4 : Int))) ∧ ((-1 : Int) ≥ (-(4 : Int))) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b))) ∨ (((-3 : Int) ≤ (-(4 : Int))) ∧ ((-3 : Int) ≥ (-(4 : Int))) ∧ ((((2 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + b) + (0 : Int)))))))
    (h4 : ((2 : Int) ≤ run_x))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n009_run_floor (a b run_x : Int)
    (h0 : ((2 : Int) ≤ run_x))
    (h1 : (¬ ((((((0 : Int) - (0 : Int)) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-((4 : Int) - (1 : Int))) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((0 : Int) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((0 : Int) ≥ (-((4 : Int) - (1 : Int)))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - b) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-((4 : Int) - (1 : Int))) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((1 : Int) ≥ (-((4 : Int) - (1 : Int)))) ∧ ((((1 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-((4 : Int) - (1 : Int))) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-1 : Int) ≥ (-((4 : Int) - (1 : Int)))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-((4 : Int) - (1 : Int))) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-2 : Int) ≥ (-((4 : Int) - (1 : Int)))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-((4 : Int) - (1 : Int))) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-1 : Int) ≥ (-((4 : Int) - (1 : Int)))) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-((4 : Int) - (1 : Int))) ≤ ((-3 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b))) ∨ (((-3 : Int) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-3 : Int) ≥ (-((4 : Int) - (1 : Int)))) ∧ ((((2 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + b) + (0 : Int))))))))
    (h2 : (run_x ≤ ((1 : Int) + b)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n010_point (a b : Int)
    (h0 : (¬ (((-2 : Int) ≥ (-((4 : Int) * ((a + b) + (1 : Int))))) ∧ (((2 : Int) + b) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((4 : Int) * ((a + b) + (1 : Int)))) ∧ (((2 : Int) + b) ≤ ((4 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n010_empty (a b : Int)
    (h0 : (((((-2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((2 : Int) + b)) ∧ ((0 : Int) ≥ ((2 : Int) + b))) ∨ (((0 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((0 : Int) + a)))) ∨ ((((-2 : Int) ≥ ((1 : Int) - b)) ∧ ((-2 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (1 : Int)) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((-2 : Int) ≥ ((-1 : Int) - a)) ∧ ((-2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) + b)) ∧ ((0 : Int) ≥ ((2 : Int) + b))) ∨ (((-1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((-2 : Int) ≥ ((-2 : Int) - a)) ∧ ((-2 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) + b)) ∧ ((1 : Int) ≥ ((2 : Int) + b))) ∨ (((-2 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-2 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((1 : Int) + b)))) ∨ ((((-2 : Int) ≥ ((-1 : Int) - a)) ∧ ((-2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((1 : Int) + ((2 : Int) * b)))) ∨ (((-1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-1 : Int)) ∧ ((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))))) ∨ ((((-2 : Int) ≥ ((-3 : Int) - a)) ∧ ((-2 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≥ ((2 : Int) + b))) ∨ (((-3 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-3 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ ((2 : Int) + b))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((-3 : Int) > ((1 : Int) + (0 : Int))) ∨ ((-3 : Int) < ((1 : Int) - b)) ∨ (((1 : Int) + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < ((1 : Int) + a))))
    (h3 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n010_o0 (a b jx jy : Int)
    (h0 : (((-1 : Int) > ((1 : Int) + (0 : Int))) ∨ ((-1 : Int) < ((1 : Int) - b)) ∨ (((1 : Int) + a) < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((1 : Int) + a))))
    (h1 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h2 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (a ≥ b))
    (h4 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + b)))))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n010_o1 (a b jx jy : Int)
    (h0 : (a ≥ b))
    (h1 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - a) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((1 : Int) - b)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - a))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((-1 : Int) > ((1 : Int) + (0 : Int))) ∨ ((-1 : Int) < ((1 : Int) - b)) ∨ (((1 : Int) + a) < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((1 : Int) + a))))
    (h6 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b)))))))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n010_o2 (a b jx jy : Int)
    (h0 : (((-1 : Int) > ((1 : Int) + (0 : Int))) ∨ ((-1 : Int) < ((1 : Int) - b)) ∨ (((1 : Int) + a) < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((1 : Int) + a))))
    (h1 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - b) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + (0 : Int))))))
    (h2 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - b))))
    (h3 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jy - b))))
    (h6 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h7 : (a ≥ b))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n010_o3 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jy)))
    (h1 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h2 : ((jx < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + a)))))
    (h4 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n010_o4 (a b jx jy : Int)
    (h0 : (((-1 : Int) > ((1 : Int) + (0 : Int))) ∨ ((-1 : Int) < ((1 : Int) - b)) ∨ (((1 : Int) + a) < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((1 : Int) + a))))
    (h1 : ((jx < ((1 : Int) - b)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - a))))
    (h2 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - a) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + (0 : Int))))))
    (h3 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ ((((0 : Int) = a) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ ((((0 : Int) = b) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = b)))))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n010_o5 (a b jx jy : Int)
    (h0 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h3 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + b)))))
    (h4 : (((-1 : Int) > ((1 : Int) + (0 : Int))) ∨ ((-1 : Int) < ((1 : Int) - b)) ∨ (((1 : Int) + a) < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((1 : Int) + a))))
    (h5 : (a ≥ b))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n010_o6 (a b jx jy : Int)
    (h0 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (((-3 : Int) > (jx + b)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((-1 : Int) > ((1 : Int) + (0 : Int))) ∨ ((-1 : Int) < ((1 : Int) - b)) ∨ (((1 : Int) + a) < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((1 : Int) + a))))
    (h4 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + a)))))
    (h5 : ((jx < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h6 : (a ≥ b))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n010_o7 (a b jx jy : Int)
    (h0 : (((-1 : Int) > ((1 : Int) + (0 : Int))) ∨ ((-1 : Int) < ((1 : Int) - b)) ∨ (((1 : Int) + a) < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < ((1 : Int) + a))))
    (h1 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ (jy ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((jy - b) ≤ ((2 : Int) + b)) ∧ (((2 : Int) + b) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ b))
    (h3 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h4 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n011_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((-2 : Int) ≥ (-((4 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((-2 : Int) ≤ ((4 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((4 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n011_empty (a b : Int)
    (h0 : (((((-2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((-2 : Int) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + a)))) ∨ ((((-2 : Int) ≥ ((1 : Int) - b)) ∧ ((-2 : Int) ≤ ((1 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((1 : Int) + a)) ∧ ((2 : Int) ≤ ((1 : Int) + a))) ∨ (((1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((-2 : Int) ≥ ((-1 : Int) - a)) ∧ ((-2 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-2 : Int)) ∧ ((-2 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + b)))) ∨ ((((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∧ ((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * b)) + b)) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≥ ((-2 : Int) + ((-1 : Int) * b))) ∧ ((-2 : Int) ≤ ((-2 : Int) + ((-1 : Int) * b))) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + a))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n011_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((jx + a) < ((-2 : Int) + ((-1 : Int) * b))) ∨ (((-2 : Int) + ((-1 : Int) * b)) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h4 : (a > b))
    (h5 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n011_o1 (a b jx jy : Int)
    (h0 : ((jx < ((1 : Int) - b)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - a))))
    (h1 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b)))))))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n011_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (((jx + (0 : Int)) < ((-2 : Int) + ((-1 : Int) * b))) ∨ (((-2 : Int) + ((-1 : Int) * b)) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (a > b))
    (h4 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n011_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h2 : ((jx < (((-2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * b)) + b) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h4 : (((jx + (0 : Int)) < ((-2 : Int) + ((-1 : Int) * b))) ∨ (((-2 : Int) + ((-1 : Int) * b)) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n011_o4 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - b)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < ((1 : Int) - b)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - a))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ ((((0 : Int) = a) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ ((((0 : Int) = b) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = b)))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n011_o5 (a b jx jy : Int)
    (h0 : ((jx < (((-2 : Int) + ((-1 : Int) * b)) - (0 : Int))) ∨ ((((-2 : Int) + ((-1 : Int) * b)) + b) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h1 : (((jx + (0 : Int)) < ((-2 : Int) + ((-1 : Int) * b))) ∨ (((-2 : Int) + ((-1 : Int) * b)) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : ((((-2 : Int) ≥ (jx - a)) ∧ ((-2 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h3 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h4 : (a > b))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n011_o6 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h1 : ((jx < ((-2 : Int) + ((-1 : Int) * b))) ∨ (((-2 : Int) + ((-1 : Int) * b)) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h5 : (a ≥ (5 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

theorem HP_boundaryall_unequal_vleft_longneighbor_pruned_n011_o7 (a b jx jy : Int)
    (h0 : ((((-2 : Int) ≥ (jx - (0 : Int))) ∧ ((-2 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-2 : Int) ≥ jx) ∧ ((-2 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < ((1 : Int) - b)) ∨ (((1 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - b))))
    (h2 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals omega

end LRegionArithmetic

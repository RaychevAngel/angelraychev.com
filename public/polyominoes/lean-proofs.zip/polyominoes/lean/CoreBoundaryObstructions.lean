import BasicHierarchy

namespace PolyominoFormal
namespace CoreBoundaryObstructions
open CrossUnits

theorem positive_boundary_tip {t : Cross} (pos : Positive t)
    (inside : ∀ x y, Contains t x y → 0≤y)
    (x : Int) (hit : Contains t x 0) :
    t.x=x ∧ 1≤t.y ∧ t.y-t.south=0 := by
  obtain ⟨he,hn,hw,hs⟩ := pos
  have hb := inside t.x (t.y-t.south)
    (Or.inr ⟨by omega,by omega,by omega,by omega⟩)
  unfold Contains at hit
  omega

/-- Two adjacent cells on a global bottom boundary cannot both be tiled
    by positive-arm crosses. The rest of the region is arbitrary. -/
theorem positive_boundary_pair (world : Cross → Prop)
    (positive : ∀ t, world t → Positive t)
    (inside : ∀ t, world t → ∀ x y, Contains t x y → 0≤y)
    (disjoint : ∀ t u x y, world t → world u → Contains t x y → Contains u x y → t=u)
    (left : ∃ t, world t ∧ Contains t 0 0)
    (right : ∃ t, world t ∧ Contains t 1 0) : False := by
  obtain ⟨t,ht,hc⟩ := left
  obtain ⟨u,hu,hd⟩ := right
  obtain ⟨tx,ty,tb⟩ := positive_boundary_tip (positive t ht) (inside t ht) 0 hc
  obtain ⟨ux,uy,ub⟩ := positive_boundary_tip (positive u hu) (inside u hu) 1 hd
  have hne : t≠u := by intro eq; cases eq; omega
  obtain ⟨te,tn,tw,ts⟩ := positive t ht
  obtain ⟨ue,un,uw,us⟩ := positive u hu
  by_cases hh : t.y≤u.y
  · apply hne (disjoint t u 1 t.y ht hu ?_ ?_)
    · left; exact ⟨by omega,by omega,by omega,by omega⟩
    · right; exact ⟨by omega,by omega,by omega,by omega⟩
  · apply hne (disjoint t u 0 u.y ht hu ?_ ?_)
    · right; exact ⟨by omega,by omega,by omega,by omega⟩
    · left; exact ⟨by omega,by omega,by omega,by omega⟩

theorem positive_cross_no_halfplane {a b c d : Int}
    (ha : 1≤a) (hb : 1≤b) (hc : 1≤c) (hd : 1≤d) :
    ¬Tiles a b c d HalfPlane := by
  rintro ⟨T⟩
  exact positive_boundary_pair T.world
    (fun t ht => copy_positive ha hb hc hd (T.copies t ht)) T.inside T.disjoint
    (T.cover 0 0 (by exact Int.le_refl 0)) (T.cover 1 0 (by exact Int.le_refl 0))

theorem positive_cross_no_strip {a b c d : Int}
    (ha : 1≤a) (hb : 1≤b) (hc : 1≤c) (hd : 1≤d) :
    ¬StripTileable a b c d := by
  intro h
  exact positive_cross_no_halfplane ha hb hc hd (PositiveHierarchy.strip_tiles_halfplane h)

theorem positive_cross_no_halfstrip {a b c d : Int}
    (ha : 1≤a) (hb : 1≤b) (hc : 1≤c) (hd : 1≤d) :
    ¬HalfStripTileable a b c d := by
  intro h
  exact positive_cross_no_strip ha hb hc hd (half_strip_implies_strip h)

theorem positive_cross_no_rectangle {a b c d : Int}
    (ha : 1≤a) (hb : 1≤b) (hc : 1≤c) (hd : 1≤d) :
    ¬RectangleTileable a b c d := by
  intro h
  exact positive_cross_no_halfstrip ha hb hc hd (rectangle_implies_half_strip h)

theorem positive_cross_no_quadrant {a b c d : Int}
    (ha : 1≤a) (hb : 1≤b) (hc : 1≤c) (hd : 1≤d) :
    ¬Tiles a b c d Quadrant := by
  intro h
  exact positive_cross_no_halfplane ha hb hc hd (PositiveHierarchy.quadrant_tiles_halfplane h)

theorem positive_cross_no_bentstrip {a b c d : Int}
    (ha : 1≤a) (hb : 1≤b) (hc : 1≤c) (hd : 1≤d) :
    ¬BentStripTileable a b c d := by
  intro h
  exact positive_cross_no_quadrant ha hb hc hd (PositiveHierarchy.bent_tiles_quadrant h)

/-- Integer-cell dilation of the union of the horizontal and vertical rods. -/
def ScaledCross (a b c d k : Int) : Region := fun x y =>
  (-c*k≤x ∧ x<(a+1)*k ∧ 0≤y ∧ y<k) ∨
  (0≤x ∧ x<k ∧ -d*k≤y ∧ y<(b+1)*k)

theorem scaled_cross_below {a b c d k x y : Int} (hd : 0≤d) (hk : 0≤k)
    (hit : ScaledCross a b c d k x y) : -d*k≤y := by
  have nonneg := Int.mul_nonneg hd hk
  rw [Int.neg_mul]
  unfold ScaledCross at hit
  simp only [Int.neg_mul] at hit
  omega

theorem scaled_cross_bottom {a b c d k x : Int} (hb : 0≤b) (hd : 0≤d)
    (hk : 0<k) (hx : 0≤x ∧ x<k) : ScaledCross a b c d k x (-d*k) := by
  right
  have nonneg := Int.mul_nonneg hd (by omega : 0≤k)
  have bn := Int.mul_nonneg hb (by omega : 0≤k)
  refine ⟨hx.1,hx.2,Int.le_refl _,?_⟩
  simp only [Int.add_mul,Int.one_mul,Int.neg_mul]
  omega

theorem positive_cross_no_scaled_copy {a b c d k : Int}
    (ha : 1≤a) (hb : 1≤b) (hc : 1≤c) (hd : 1≤d) (hk : 2≤k) :
    ¬Tiles a b c d (ScaledCross a b c d k) := by
  rintro ⟨T⟩
  let U := T.translate 0 (d*k)
  have inside : ∀ t, U.world t → ∀ x y, Contains t x y → 0≤y := by
    intro t ht x y hit
    have hb' := scaled_cross_below (by omega : 0≤d) (by omega : 0≤k) (U.inside t ht x y hit)
    simp only [Int.neg_mul] at hb'
    omega
  have cover : ∀ x : Int, 0≤x → x<k → ∃ t, U.world t ∧ Contains t x 0 := by
    intro x hx hxk
    apply U.cover x 0
    show ScaledCross a b c d k (x-0) (0-d*k)
    have hx' : x-0=x := by omega
    have hy' : 0-d*k= -d*k := by rw [Int.neg_mul]; omega
    rw [hx',hy']
    exact scaled_cross_bottom (by omega) (by omega) (by omega) ⟨hx,hxk⟩
  exact positive_boundary_pair U.world
    (fun t ht => copy_positive ha hb hc hd (U.copies t ht)) inside U.disjoint
    (cover 0 (by omega) (by omega)) (cover 1 (by omega) (by omega))

#print axioms positive_cross_no_halfplane
#print axioms positive_cross_no_scaled_copy
end CoreBoundaryObstructions
end PolyominoFormal

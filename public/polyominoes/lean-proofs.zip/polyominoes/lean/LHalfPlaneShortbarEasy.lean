import LHalfPlaneShortbarAssembly
import LQuadrantHpBoundaryallUnequalBarShortCheckPrunedGeometry
import LQuadrantHpBoundaryallUnequalShortbarWestShortPrunedGeometry
import LQuadrantHpBoundaryallUnequalShortbarTipRightPrunedGeometry
namespace PolyominoFormal.LHalfPlaneShortbarAssembly
open CrossUnits LRegion

theorem long_tip_right {a b : Int} (ha : 5≤a) (hb : 3≤b) (hab : b<a) :
    PairObstruction a b ⟨1,a+1,b,0,0,a⟩ := by
  intro T hO hU
  apply HP_boundaryall_unequal_bar_short_check_pruned_anchored_obstruction a b (by omega) hb hab ha T hO
  simpa only [Int.add_comm] using hU

theorem upright_short_left {a b : Int} (ha : 5≤a) (hb : 3≤b) (hab : b<a) :
    PairObstruction a b ⟨b+1,1,0,a,b,0⟩ := by
  intro T hO hU
  apply HP_boundaryall_unequal_shortbar_west_short_pruned_anchored_obstruction a b (by omega) hb hab ha T hO
  simpa only [Int.add_comm] using hU

theorem short_tip_right {a b : Int} (ha : 5≤a) (hb : 3≤b) (hab : b<a) :
    PairObstruction a b ⟨1,b+1,a,0,0,b⟩ := by
  intro T hO hU
  apply HP_boundaryall_unequal_shortbar_tip_right_pruned_anchored_obstruction a b (by omega) hb hab ha T hO
  simpa only [Int.add_comm] using hU

#print axioms long_tip_right
#print axioms upright_short_left
#print axioms short_tip_right
end PolyominoFormal.LHalfPlaneShortbarAssembly

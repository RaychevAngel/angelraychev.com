import TilingCore
import CornerCertificateCore

/-!
Geometric infrastructure for the rep-tile obstruction.  The final tiling theorem
must additionally invoke the checked clean-corner replay; the lemmas in this
file alone are not yet a no-rep theorem.
-/

namespace PolyominoFormal
namespace RepObstruction

open CrossUnits

/-- Integer cells of the enlarged T, reflected so its long arm begins at x=0. -/
def Target (a k x y : Int) : Prop :=
  (0 ≤ x ∧ x < (a+2)*k ∧ 0 ≤ y ∧ y < k) ∨
  (a*k ≤ x ∧ x < (a+1)*k ∧ k ≤ y ∧ y < 2*k)

theorem target_below_stem {a k x y : Int}
    (inTarget : Target a k x y) (left : x < a*k) : y < k := by
  rcases inTarget with h | h
  · exact h.2.2.2
  · omega

theorem arm_cell {a k x y : Int} (hk : 0 ≤ k)
    (hx : 0 ≤ x) (hleft : x < a*k) (hy : 0 ≤ y) (htop : y < k) :
    Target a k x y := by
  apply Or.inl
  have width : a*k ≤ (a+2)*k := by
    simp only [Int.add_mul]
    omega
  exact ⟨hx,by omega,hy,htop⟩

/-- The full vertical wall, not only its origin, supplies the crucial margin. -/
theorem wall_buffer {a k X Y w h : Int}
    (ha : 4 ≤ a) (hk : 1 ≤ k) (hw : 4 ≤ w) (hh : 0 ≤ h)
    (wall : Y+w ≤ k) (potential : X-4*Y ≤ -h) : X+a+8 < a*k := by
  have product_nonneg : 0 ≤ (a-4)*(k-1) :=
    Int.mul_nonneg (by omega) (by omega)
  simp only [Int.sub_mul, Int.mul_sub, Int.mul_one] at product_nonneg
  omega

theorem wall_height {a k X Y w : Int} (positive : 1 ≤ w) (left : X < a*k)
    (wall : ∀ j : Int, 0 ≤ j → j < w → Target a k (X-1) (Y+j)) :
    Y+w ≤ k := by
  have top := target_below_stem (wall (w-1) (by omega) (by omega)) (by omega)
  omega

theorem copy_horizontal_extent {a : Int} {t : Cross} (ha : 1 ≤ a)
    (copy : Copy a 1 1 0 t) :
    0 ≤ t.east ∧ 0 ≤ t.west ∧ t.east+t.west ≤ a+1 := by
  rcases copy with h | h | h | h | h | h | h | h
  all_goals rcases h with ⟨he,hn,hw,hs⟩
  all_goals omega

theorem contains_x_bounds {t : Cross} {x y : Int}
    (he : 0 ≤ t.east) (hw : 0 ≤ t.west) (hit : Contains t x y) :
    t.x-t.west ≤ x ∧ x ≤ t.x+t.east := by
  rcases hit with h | h
  · omega
  · omega

theorem copy_horizontal_diameter {a x y u v : Int} {t : Cross}
    (ha : 1 ≤ a) (copy : Copy a 1 1 0 t)
    (first : Contains t x y) (second : Contains t u v) : u-x ≤ a+1 := by
  obtain ⟨he,hw,span⟩ := copy_horizontal_extent ha copy
  have one := contains_x_bounds he hw first
  have two := contains_x_bounds he hw second
  omega

/-- Every cell of a whole tile through a permitted query stays before the stem. -/
theorem selected_tile_before_stem {a k X qx qy x y : Int} {t : Cross}
    (ha : 1 ≤ a) (buffer : X+a+8 < a*k) (queryX : qx ≤ X+7)
    (copy : Copy a 1 1 0 t) (queryHit : Contains t qx qy)
    (hit : Contains t x y) : x < a*k := by
  have span := copy_horizontal_diameter ha copy queryHit hit
  omega

theorem selected_tile_below_top {a k X qx qy x y : Int} {t : Cross}
    (ha : 1 ≤ a) (buffer : X+a+8 < a*k) (queryX : qx ≤ X+7)
    (copy : Copy a 1 1 0 t) (queryHit : Contains t qx qy)
    (contained : ∀ u v, Contains t u v → Target a k u v)
    (hit : Contains t x y) : y < k := by
  exact target_below_stem (contained x y hit)
    (selected_tile_before_stem ha buffer queryX copy queryHit hit)

/-- This is the non-circular query existence step inside one local replay. -/
theorem supported_query_in_target {a k X Y u v : Int}
    (hk : 0 ≤ k) (hX : 0 ≤ X) (hY : 0 ≤ Y)
    (buffer : X+a+8 < a*k) (ha : 1 ≤ a)
    (hu : 0 ≤ u) (hu7 : u ≤ 7) (hv : 0 ≤ v) (supportedY : Y+v < k) :
    Target a k (X+u) (Y+v) := by
  apply arm_cell hk
  · omega
  · omega
  · omega
  · exact supportedY

/-- A successor floor contains the cell at the successor's x coordinate. -/
theorem successor_before_stem {a k X' Y' : Int}
    (known : Int → Int → Prop)
    (allLeft : ∀ x y, known x y → x < a*k)
    (floorCell : known X' (Y'-1)) : X' < a*k :=
  allLeft X' (Y'-1) floorCell

/-- A finite-height process with a bounded secondary rank cannot always advance. -/
theorem no_bounded_progress {State : Type} (good : State → Prop)
    (height rank : State → Int) (H : Int)
    (bounded : ∀ s, good s → height s < H ∧ 0 ≤ rank s ∧ rank s ≤ 2)
    (progress : ∀ s, good s → ∃ t, good t ∧ height s ≤ height t ∧
      (height s = height t → rank t < rank s)) : ∀ s, ¬ good s := by
  let measure (s : State) : Nat := (3*(H-height s)+rank s).toNat
  have decrease {s t : State} (hs : good s) (ht : good t)
      (hy : height s ≤ height t) (hr : height s = height t → rank t < rank s) :
      measure t < measure s := by
    obtain ⟨hsy,hsr0,hsr2⟩ := bounded s hs
    obtain ⟨hty,htr0,htr2⟩ := bounded t ht
    have strict : 3*(H-height t)+rank t < 3*(H-height s)+rank s := by
      by_cases same : height s = height t
      · have := hr same
        omega
      · omega
    exact (Int.toNat_lt_toNat (by omega)).mpr strict
  have all : ∀ n : Nat, ∀ s, measure s = n → ¬ good s := by
    intro n
    refine Nat.strongRecOn n ?_
    intro n ih s equal hs
    obtain ⟨t,ht,hy,hr⟩ := progress s hs
    have smaller : measure t < n := by
      have := decrease hs ht hy hr
      omega
    exact ih (measure t) smaller t rfl ht
  intro s
  exact all (measure s) s rfl

/-- The initial exterior wall is high enough after choosing a large scale. -/
theorem initial_buffer {a k : Int} (ha : 4 ≤ a) (hk : a+2 ≤ k) :
    a+8 < a*k := by
  have := wall_buffer (X:=0) (Y:=0) (w:=4) (h:=0)
    ha (by omega : 1 ≤ k) (by omega) (by omega) (by omega) (by omega)
  omega

/-- Arithmetic reduction only: the actual tiling composition must be supplied
    by the geometric subdivision theorem before this proves a no-rep result. -/
theorem no_small_scale_of_composition (tileable : Nat → Prop) (threshold : Nat)
    (compose : ∀ k l, tileable k → tileable l → tileable (k*l))
    (noLarge : ∀ k, threshold ≤ k → ¬ tileable k) :
    ∀ k, 2 ≤ k → ¬ tileable k := by
  intro k hk tiled
  have powers : ∀ m : Nat, tileable (k^(m+1)) := by
    intro m
    induction m with
    | zero => simpa using tiled
    | succ m ih =>
      simpa only [Nat.succ_eq_add_one, Nat.pow_succ] using compose (k^(m+1)) k ih tiled
  have bound : threshold ≤ k^(threshold+1) := by
    have grows : threshold+1 < k^(threshold+1) := Nat.lt_pow_self (by omega)
    omega
  exact noLarge (k^(threshold+1)) bound (powers threshold)


open CornerCertificate

/-- Exact interface expected from the finite-case kernel replay. -/
def Replay (a : Int) : Prop :=
  ∀ (world : Cross → Prop) (h : Int) (kind : Kind) (B : Region),
    (∀ t, world t → Copy a 1 1 0 t) → DisjointWorld world →
    Clean kind 0 0 B → TileClosed world B → Below h B →
    CoversWindow world h → SelectedBelow world h → Transition world h kind B

def LocalWorld (world : Cross → Prop) (X Y : Int) : Cross → Prop :=
  fun t => world (shift X Y t)

def LocalBlocked (B : Region) (X Y : Int) : Region :=
  fun x y => B (X+x) (Y+y)

def GlobalBlocked (B : Region) (X Y : Int) : Region :=
  fun x y => B (x-X) (y-Y)

theorem local_hit {t : Cross} {X Y x y : Int} (hit : Contains t x y) :
    Contains (shift X Y t) (X+x) (Y+y) := by
  have ex : X+x-X=x := by omega
  have ey : Y+y-Y=y := by omega
  simpa only [contains_shift, ex, ey] using hit

theorem unshift_hit {t : Cross} {X Y x y : Int} (hit : Contains t x y) :
    Contains (shift (-X) (-Y) t) (x-X) (y-Y) := by
  simpa only [contains_shift, Int.sub_neg, Int.sub_add_cancel] using hit

theorem shifted_back (t : Cross) (X Y : Int) :
    shift X Y (shift (-X) (-Y) t) = t := by
  have ex : -X+X=0 := by omega
  have ey : -Y+Y=0 := by omega
  simp only [shift_add, ex, ey, shift_zero]

theorem local_closed {world : Cross → Prop} {B : Region} (X Y : Int)
    (closed : TileClosed world B) :
    TileClosed (LocalWorld world X Y) (LocalBlocked B X Y) := by
  intro t ht x y hit blocked u v other
  exact closed (shift X Y t) ht (X+x) (Y+y) (local_hit hit) blocked
    (X+u) (Y+v) (local_hit other)

theorem global_closed {world : Cross → Prop} {B : Region} (X Y : Int)
    (closed : TileClosed (LocalWorld world X Y) B) :
    TileClosed world (GlobalBlocked B X Y) := by
  intro t ht x y hit blocked u v other
  have localMember : LocalWorld world X Y (shift (-X) (-Y) t) := by
    simpa only [LocalWorld, shifted_back] using ht
  exact closed _ localMember (x-X) (y-Y) (unshift_hit hit) blocked
    (u-X) (v-Y) (unshift_hit other)

theorem local_clean {kind : Kind} {X Y : Int} {B : Region}
    (clean : Clean kind X Y B) : Clean kind 0 0 (LocalBlocked B X Y) := by
  simpa only [Clean, LocalBlocked, Int.zero_add] using clean

theorem global_clean {kind : Kind} {X Y dx dy : Int} {B : Region}
    (clean : Clean kind dx dy B) :
    Clean kind (X+dx) (Y+dy) (GlobalBlocked B X Y) := by
  have ex : ∀ x : Int, X+dx+x-X=dx+x := by intro x; omega
  have ey : ∀ y : Int, Y+dy+y-Y=dy+y := by intro y; omega
  simpa only [Clean, GlobalBlocked, ex, ey] using clean

structure Config where
  kind : Kind
  x : Int
  y : Int
  blocked : Region

def Good (world : Cross → Prop) (k : Int) (s : Config) : Prop :=
  0 ≤ s.x ∧ 0 ≤ s.y ∧ Clean s.kind s.x s.y s.blocked ∧
  TileClosed world s.blocked ∧ Below k s.blocked ∧
  s.x-4*s.y ≤ -potential s.kind

theorem good_wall_height {world : Cross → Prop} {k : Int} {s : Config}
    (good : Good world k s) : s.y+wallHeight s.kind ≤ k := by
  obtain ⟨hx,hy,clean,closed,below,pot⟩ := good
  have bounds := kind_bounds s.kind
  have wall : Wall s.kind (-1) (wallHeight s.kind-1) := by
    exact Or.inl ⟨rfl,by omega,by omega⟩
  have := below _ _ (clean.1 (-1) (wallHeight s.kind-1) wall)
  omega

theorem good_progress {a k : Int} (ha : 4 ≤ a) (hk : 4 ≤ k)
    (replay : Replay a) (T : Tiling a 1 1 0 (Target a k))
    (s : Config) (good : Good T.world k s) :
    ∃ t, Good T.world k t ∧ s.y ≤ t.y ∧
      (s.y = t.y → zeroRank t.kind < zeroRank s.kind) := by
  have high := good_wall_height good
  obtain ⟨hx,hy,clean,closed,below,pot⟩ := good
  have bounds := kind_bounds s.kind
  have buffer : s.x+a+8 < a*k :=
    wall_buffer ha (by omega) bounds.1 bounds.2.1 high pot
  let localWorld := LocalWorld T.world s.x s.y
  let localB := LocalBlocked s.blocked s.x s.y
  have copies : ∀ t, localWorld t → Copy a 1 1 0 t := by
    intro t ht
    exact (copy_shift a 1 1 0 s.x s.y t).1 (T.copies _ ht)
  have separate : DisjointWorld localWorld := by
    intro t u x y ht hu hit other
    exact shift_injective s.x s.y
      (T.disjoint _ _ (s.x+x) (s.y+y) ht hu (local_hit hit) (local_hit other))
  have localBelow : Below (k-s.y) localB := by
    intro x y h
    have := below (s.x+x) (s.y+y) h
    omega
  have cover : CoversWindow localWorld (k-s.y) := by
    intro x y query
    obtain ⟨qx,q7,qy,qtop⟩ := query
    have inside : Target a k (s.x+x) (s.y+y) :=
      supported_query_in_target (by omega) hx hy buffer (by omega) qx q7 qy (by omega)
    obtain ⟨t,ht,hit⟩ := T.cover _ _ inside
    refine ⟨shift (-s.x) (-s.y) t, ?_, ?_⟩
    · change T.world (shift s.x s.y (shift (-s.x) (-s.y) t))
      simpa only [shifted_back] using ht
    · simpa only [contains_shift, Int.sub_neg, Int.add_comm] using hit
  have selected : SelectedBelow localWorld (k-s.y) := by
    intro t ht selected x y hit
    obtain ⟨qx,qy,query,qhit⟩ := selected
    have span := copy_horizontal_diameter (by omega : 1 ≤ a) (copies t ht) qhit hit
    have globalHit := local_hit (X:=s.x) (Y:=s.y) hit
    have inside := T.inside (shift s.x s.y t) ht (s.x+x) (s.y+y) globalHit
    have left : s.x+x < a*k := by
      have q7 := query.2.1
      omega
    have top := target_below_stem inside left
    omega
  obtain ⟨B',kind,dx,dy,enlarges,closed',below',clean',progress⟩ :=
    replay localWorld (k-s.y) s.kind localB copies separate
      (local_clean clean) (local_closed s.x s.y closed) localBelow cover selected
  let t : Config := ⟨kind,s.x+dx,s.y+dy,GlobalBlocked B' s.x s.y⟩
  refine ⟨t, ?_, ?_, ?_⟩
  · have rank := progress.2.2.2.2.1
    have nonnegX := progress.1
    have nonnegY := progress.2.1
    refine ⟨by dsimp [t]; omega, by dsimp [t]; omega,
      global_clean clean', global_closed s.x s.y closed', ?_, ?_⟩
    · intro x y blocked
      have top := below' (x-s.x) (y-s.y) blocked
      omega
    · dsimp [t]
      omega
  · dsimp [t]
    have := progress.2.1
    omega
  · intro same
    have equal : dy=0 := by dsimp [t] at same; omega
    exact progress.2.2.2.2.2 equal

/-- Conditional only on the kernel-checked local replay, with an actual tiling
    (not a pre-assumed infinite path) as the object being contradicted. -/
theorem no_large_target_of_replay {a k : Int} (ha : 4 ≤ a) (hk : 4 ≤ k)
    (replay : Replay a) : ¬ Tiles a 1 1 0 (Target a k) := by
  rintro ⟨T⟩
  let initial : Config := ⟨.alpha,0,0,Wall .alpha⟩
  have start : Good T.world k initial := by
    dsimp only [Good, initial]
    refine ⟨by decide,by decide,?_,?_,?_,by decide⟩
    · constructor
      · intro x y h
        simpa only [Int.zero_add] using h
      · intro x y hx hy
        simp only [Int.zero_add, Extra]
        constructor
        · intro h
          rcases h with h | h <;> omega
        · intro h
          contradiction
    · intro t ht x y hit wall u v other
      have inside := T.inside t ht x y hit
      have nonnegProduct : 0 ≤ a*k := Int.mul_nonneg (by omega) (by omega)
      rcases wall with wall | wall
      · rcases inside with h | h <;> omega
      · rcases inside with h | h <;> omega
    · intro x y wall
      rcases wall with h | h
      · change x = -1 ∧ 0 ≤ y ∧ y < 4 at h
        omega
      · omega
  have impossible := no_bounded_progress (Good T.world k) Config.y
    (fun s => zeroRank s.kind) k
    (by
      intro s good
      exact ⟨clean_origin_below good.2.2.1 good.2.2.2.2.1,
        (kind_bounds s.kind).2.2⟩)
    (good_progress ha hk replay T)
  exact impossible initial start


/-- The two possible axial extents of a bar-and-one-tooth tile. -/
def HorizontalForm (a : Int) (t : Cross) : Prop :=
  1 ≤ t.east ∧ 1 ≤ t.west ∧ t.east+t.west=a+1 ∧
  0 ≤ t.north ∧ 0 ≤ t.south ∧ t.north+t.south=1

def VerticalForm (a : Int) (t : Cross) : Prop :=
  0 ≤ t.east ∧ 0 ≤ t.west ∧ t.east+t.west=1 ∧
  1 ≤ t.north ∧ 1 ≤ t.south ∧ t.north+t.south=a+1

theorem copy_axis_forms {a : Int} {t : Cross} (ha : 1 ≤ a)
    (copy : Copy a 1 1 0 t) : HorizontalForm a t ∨ VerticalForm a t := by
  rcases copy with h | h | h | h | h | h | h | h
  all_goals rcases h with ⟨he,hn,hw,hs⟩
  all_goals unfold HorizontalForm VerticalForm
  all_goals omega

theorem target_nonnegative {a k x y : Int} (ha : 0 ≤ a) (hk : 0 ≤ k)
    (inside : Target a k x y) : 0 ≤ x ∧ 0 ≤ y := by
  have nonnegProduct := Int.mul_nonneg ha hk
  rcases inside with h | h <;> omega

/-- At scale two or three, a tile touching the left end must expose a whole
    horizontal bar there. A vertical bar could fit elsewhere at scale three,
    so the proof uses its forced column zero or one, not total target height. -/
theorem small_boundary_bar {a k y : Int} {t : Cross}
    (ha : 4 ≤ a) (hk : 2 ≤ k) (small : k ≤ 3)
    (copy : Copy a 1 1 0 t)
    (contained : ∀ u v, Contains t u v → Target a k u v)
    (hit : Contains t 0 y) :
    HorizontalForm a t ∧ t.y=y ∧ t.x-t.west=0 ∧
    1 ≤ t.x ∧ t.x ≤ a ∧
    (∀ x, 0 ≤ x → x ≤ a+1 → Contains t x y) := by
  have productBound : a*2 ≤ a*k := Int.mul_le_mul_of_nonneg_left hk (by omega)
  rcases copy_axis_forms (by omega : 1 ≤ a) copy with horizontal | vertical
  · obtain ⟨he,hw,span,hn,hs,one⟩ := horizontal
    have westHit : Contains t (t.x-t.west) t.y := by
      left
      exact ⟨by omega,by omega,by omega,by omega⟩
    have westNonneg := (target_nonnegative (by omega : 0 ≤ a) (by omega : 0 ≤ k)
      (contained _ _ westHit)).1
    have bounds := contains_x_bounds (by omega) (by omega) hit
    have start : t.x-t.west=0 := by omega
    have ty : t.y=y := by
      rcases hit with h | h <;> omega
    refine ⟨⟨he,hw,span,hn,hs,one⟩,ty,start,by omega,by omega,?_⟩
    intro x hx hxmax
    left
    exact ⟨by omega,by omega,by omega,by omega⟩
  · obtain ⟨he,hw,one,hn,hs,span⟩ := vertical
    have bounds := contains_x_bounds he hw hit
    have left : t.x < a*k := by omega
    have lowHit : Contains t t.x (t.y-t.south) := by
      right
      exact ⟨by omega,by omega,by omega,by omega⟩
    have highHit : Contains t t.x (t.y+t.north) := by
      right
      exact ⟨by omega,by omega,by omega,by omega⟩
    have low := (target_nonnegative (by omega : 0 ≤ a) (by omega : 0 ≤ k)
      (contained _ _ lowHit)).2
    have high := target_below_stem (contained _ _ highHit) left
    omega

/-- Actual no-tiling theorem for both small nontrivial integer scales. -/
theorem no_small_target {a k : Int} (ha : 4 ≤ a) (hk : 2 ≤ k) (small : k ≤ 3) :
    ¬ Tiles a 1 1 0 (Target a k) := by
  rintro ⟨T⟩
  have productBound : a*2 ≤ a*k := Int.mul_le_mul_of_nonneg_left hk (by omega)
  have corner : Target a k 0 0 := arm_cell (by omega) (by omega) (by omega) (by omega) (by omega)
  have next : Target a k 0 1 := arm_cell (by omega) (by omega) (by omega) (by omega) (by omega)
  obtain ⟨t,ht,hit⟩ := T.cover 0 0 corner
  obtain ⟨u,hu,other⟩ := T.cover 0 1 next
  obtain ⟨form,ty,start,txpos,txmax,tbar⟩ :=
    small_boundary_bar ha hk small (T.copies t ht) (T.inside t ht) hit
  obtain ⟨uform,uy,ustart,uxpos,uxmax,ubar⟩ :=
    small_boundary_bar ha hk small (T.copies u hu) (T.inside u hu) other
  obtain ⟨te,tw,span,tn,ts,one⟩ := form
  have lower : Contains t t.x (t.y-t.south) := by
    right
    exact ⟨by omega,by omega,by omega,by omega⟩
  have lowNonneg := (target_nonnegative (by omega : 0 ≤ a) (by omega : 0 ≤ k)
    (T.inside t ht _ _ lower)).2
  have tooth : Contains t t.x 1 := by
    right
    exact ⟨by omega,by omega,by omega,by omega⟩
  have collision : Contains u t.x 1 := ubar t.x (by omega) (by omega)
  have same := T.disjoint t u t.x 1 ht hu tooth collision
  have sameY := congrArg Cross.y same
  omega

/-- Once the finite-case Replay theorem is supplied, every nontrivial integer
    enlargement is impossible. Small scales use a direct two-tile argument;
    no unproved iteration or subdivision assumption is needed. -/
theorem no_target_of_replay {a k : Int} (ha : 4 ≤ a) (hk : 2 ≤ k)
    (replay : Replay a) : ¬ Tiles a 1 1 0 (Target a k) := by
  by_cases small : k ≤ 3
  · exact no_small_target ha hk small
  · exact no_large_target_of_replay ha (by omega) replay


/-- Lattice rep-tile convention for this T family: a natural enlargement
    factor, with the target in the explicitly reflected coordinate convention.
    No unequal-scale dissection is included in this definition. -/
def LatticeRepTile (a : Int) : Prop :=
  ∃ k : Nat, 2 ≤ k ∧ Tiles a 1 1 0 (Target a (k : Int))

theorem no_lattice_rep_of_replay {a : Int} (ha : 4 ≤ a) (replay : Replay a) :
    ¬ LatticeRepTile a := by
  rintro ⟨k,hk,tiled⟩
  exact no_target_of_replay ha (by omega : (2 : Int) ≤ (k : Int)) replay tiled

#print axioms no_lattice_rep_of_replay
#print axioms no_small_target
#print axioms no_target_of_replay
#print axioms no_large_target_of_replay
#print axioms no_bounded_progress
#print axioms no_small_scale_of_composition
#print axioms wall_buffer
#print axioms selected_tile_below_top
#print axioms supported_query_in_target

end RepObstruction
end PolyominoFormal

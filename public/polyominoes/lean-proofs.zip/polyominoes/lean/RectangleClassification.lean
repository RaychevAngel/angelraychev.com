import RectangleRep
import BasicHierarchy
import ElementaryRectangles
import SmallTRectangleOne
import SmallTRectangleTwo
import SmallTRectangleThree

namespace PolyominoFormal

structure ExactRectangle (a b c d : Int) : Prop where
  rectangle : RectangleTileable a b c d
  half_strip : HalfStripTileable a b c d
  bent_strip : BentStripTileable a b c d
  quadrant : Tiles a b c d Quadrant
  strip : StripTileable a b c d
  half_plane : Tiles a b c d HalfPlane
  plane : Tiles a b c d Plane
  rep : RepTileable a b c d

theorem exact_rectangle_of_rectangle {a b c d : Int} (h : RectangleTileable a b c d) :
    ExactRectangle a b c d := by
  have hs := rectangle_implies_half_strip h
  have bs := half_strip_implies_bent_strip hs
  have ss := half_strip_implies_strip hs
  exact ⟨h,hs,bs,PositiveHierarchy.bent_tiles_quadrant bs,ss,
    PositiveHierarchy.strip_tiles_halfplane ss,PositiveHierarchy.strip_tiles_plane ss,
    rectangle_implies_rep h⟩

theorem bar_exact_rectangle (a c : Int) (ha : 0≤a) (hc : 0≤c) :
    ExactRectangle a 0 c 0 :=
  exact_rectangle_of_rectangle (ElementaryRectangles.bar_rectangle_tileable a c ha hc)

theorem unit_l_exact_rectangle (a : Int) (ha : 0≤a) : ExactRectangle a 1 0 0 :=
  exact_rectangle_of_rectangle (ElementaryRectangles.unit_l_rectangle_tileable a ha)

theorem p0_exact_rectangle : ExactRectangle 0 1 1 0 := by
  obtain ⟨w,h,hw,hh,⟨T⟩⟩ := ElementaryRectangles.unit_l_rectangle_tileable 1 (by omega)
  exact exact_rectangle_of_rectangle ⟨w,h,hw,hh,
    ⟨T.rotateParameters.rotateParameters.rotateParameters⟩⟩

theorem p1_exact_rectangle : ExactRectangle 1 1 1 0 :=
  exact_rectangle_of_rectangle SmallTRectangles.t1_rectangle_tileable
theorem p2_exact_rectangle : ExactRectangle 2 1 1 0 :=
  exact_rectangle_of_rectangle SmallTRectangles.t2_rectangle_tileable
theorem p3_exact_rectangle : ExactRectangle 3 1 1 0 :=
  exact_rectangle_of_rectangle SmallTRectangles.t3_rectangle_tileable

#print axioms exact_rectangle_of_rectangle
#print axioms p3_exact_rectangle
end PolyominoFormal

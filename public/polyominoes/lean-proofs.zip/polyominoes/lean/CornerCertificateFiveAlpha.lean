import CornerCertificateFiveAlphaData

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

namespace CornerCertificate
open CrossUnits


section FiveAlpha
variable (world : Cross → Prop) (h : Int)
    (copies : ∀ t, world t → Copy 5 1 1 0 t)
    (separate : DisjointWorld world) (cover : CoversWindow world h)
    (ceiling : SelectedBelow world h)

theorem five_alpha_node0003 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0003 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha five_alpha_occ0003 .gamma (2 : Int) (1 : Int) five_alpha_check0003 B state
theorem five_alpha_node0004 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0004 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha five_alpha_occ0004 .beta (2 : Int) (1 : Int) five_alpha_check0004 B state
include copies separate cover ceiling in
theorem five_alpha_node0007 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0007 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0007 ((4 : Int),(1 : Int)) five_alpha_branches0007 copies separate cover ceiling five_alpha_check0007 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0007, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0008 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0008 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0008 ((4 : Int),(1 : Int)) five_alpha_branches0008 copies separate cover ceiling five_alpha_check0008 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0008, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0006 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0006 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0006 ((3 : Int),(1 : Int)) five_alpha_branches0006 copies separate cover ceiling five_alpha_check0006 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0006, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_alpha_node0007 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0008 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0009 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0009 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0009 ((3 : Int),(1 : Int)) five_alpha_branches0009 copies separate cover ceiling five_alpha_check0009 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0009, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0010 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0010 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0010 ((3 : Int),(1 : Int)) five_alpha_branches0010 copies separate cover ceiling five_alpha_check0010 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0010, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0013 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0013 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0013 ((5 : Int),(1 : Int)) five_alpha_branches0013 copies separate cover ceiling five_alpha_check0013 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0013, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0014 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0014 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0014 ((5 : Int),(1 : Int)) five_alpha_branches0014 copies separate cover ceiling five_alpha_check0014 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0014, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0012 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0012 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0012 ((4 : Int),(1 : Int)) five_alpha_branches0012 copies separate cover ceiling five_alpha_check0012 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0012, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_alpha_node0013 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0014 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0016 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0016 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0016 ((5 : Int),(1 : Int)) five_alpha_branches0016 copies separate cover ceiling five_alpha_check0016 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0016, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0017 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0017 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0017 ((5 : Int),(1 : Int)) five_alpha_branches0017 copies separate cover ceiling five_alpha_check0017 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0017, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0015 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0015 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0015 ((4 : Int),(1 : Int)) five_alpha_branches0015 copies separate cover ceiling five_alpha_check0015 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0015, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_alpha_node0016 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0017 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0011 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0011 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0011 ((2 : Int),(3 : Int)) five_alpha_branches0011 copies separate cover ceiling five_alpha_check0011 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0011, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_alpha_node0012 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0015 world h copies separate cover ceiling nextB nextState
theorem five_alpha_node0018 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0018 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha five_alpha_occ0018 .alpha (2 : Int) (3 : Int) five_alpha_check0018 B state
include copies separate cover ceiling in
theorem five_alpha_node0019 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0019 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0019 ((3 : Int),(1 : Int)) five_alpha_branches0019 copies separate cover ceiling five_alpha_check0019 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0019, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0020 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0020 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0020 ((3 : Int),(1 : Int)) five_alpha_branches0020 copies separate cover ceiling five_alpha_check0020 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0020, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0005 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0005 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0005 ((2 : Int),(2 : Int)) five_alpha_branches0005 copies separate cover ceiling five_alpha_check0005 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0005, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact five_alpha_node0006 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0009 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0010 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0011 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0018 world h nextB nextState
  · exact five_alpha_node0019 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0020 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0002 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0002 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0002 ((2 : Int),(0 : Int)) five_alpha_branches0002 copies separate cover ceiling five_alpha_check0002 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0002, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact five_alpha_node0003 world h nextB nextState
  · exact five_alpha_node0004 world h nextB nextState
  · exact five_alpha_node0005 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0022 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0022 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0022 ((2 : Int),(1 : Int)) five_alpha_branches0022 copies separate cover ceiling five_alpha_check0022 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0022, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0024 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0024 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0024 ((2 : Int),(2 : Int)) five_alpha_branches0024 copies separate cover ceiling five_alpha_check0024 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0024, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0025 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0025 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0025 ((2 : Int),(2 : Int)) five_alpha_branches0025 copies separate cover ceiling five_alpha_check0025 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0025, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0023 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0023 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0023 ((2 : Int),(1 : Int)) five_alpha_branches0023 copies separate cover ceiling five_alpha_check0023 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0023, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_alpha_node0024 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0025 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0026 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0026 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0026 ((2 : Int),(1 : Int)) five_alpha_branches0026 copies separate cover ceiling five_alpha_check0026 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0026, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0021 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0021 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0021 ((2 : Int),(0 : Int)) five_alpha_branches0021 copies separate cover ceiling five_alpha_check0021 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0021, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact five_alpha_node0022 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0023 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0026 world h copies separate cover ceiling nextB nextState
theorem five_alpha_node0028 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0028 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha five_alpha_occ0028 .gammaTranspose (2 : Int) (1 : Int) five_alpha_check0028 B state
theorem five_alpha_node0030 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0030 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha five_alpha_occ0030 .alpha (4 : Int) (1 : Int) five_alpha_check0030 B state
include copies separate cover ceiling in
theorem five_alpha_node0033 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0033 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0033 ((2 : Int),(4 : Int)) five_alpha_branches0033 copies separate cover ceiling five_alpha_check0033 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0033, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0034 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0034 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0034 ((2 : Int),(4 : Int)) five_alpha_branches0034 copies separate cover ceiling five_alpha_check0034 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0034, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0032 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0032 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0032 ((4 : Int),(1 : Int)) five_alpha_branches0032 copies separate cover ceiling five_alpha_check0032 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0032, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_alpha_node0033 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0034 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0036 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0036 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0036 ((2 : Int),(4 : Int)) five_alpha_branches0036 copies separate cover ceiling five_alpha_check0036 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0036, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0037 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0037 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0037 ((2 : Int),(4 : Int)) five_alpha_branches0037 copies separate cover ceiling five_alpha_check0037 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0037, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0035 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0035 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0035 ((4 : Int),(1 : Int)) five_alpha_branches0035 copies separate cover ceiling five_alpha_check0035 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0035, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_alpha_node0036 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0037 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0031 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0031 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0031 ((2 : Int),(3 : Int)) five_alpha_branches0031 copies separate cover ceiling five_alpha_check0031 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0031, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_alpha_node0032 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0035 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0039 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0039 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0039 ((2 : Int),(3 : Int)) five_alpha_branches0039 copies separate cover ceiling five_alpha_check0039 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0039, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0038 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0038 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0038 ((3 : Int),(1 : Int)) five_alpha_branches0038 copies separate cover ceiling five_alpha_check0038 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0038, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact five_alpha_node0039 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0040 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0040 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0040 ((3 : Int),(1 : Int)) five_alpha_branches0040 copies separate cover ceiling five_alpha_check0040 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0040, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0042 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0042 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0042 ((2 : Int),(3 : Int)) five_alpha_branches0042 copies separate cover ceiling five_alpha_check0042 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0042, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0041 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0041 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0041 ((3 : Int),(1 : Int)) five_alpha_branches0041 copies separate cover ceiling five_alpha_check0041 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0041, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact five_alpha_node0042 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0029 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0029 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0029 ((2 : Int),(2 : Int)) five_alpha_branches0029 copies separate cover ceiling five_alpha_check0029 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0029, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact five_alpha_node0030 world h nextB nextState
  · exact five_alpha_node0031 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0038 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0040 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0041 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0027 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0027 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0027 ((1 : Int),(1 : Int)) five_alpha_branches0027 copies separate cover ceiling five_alpha_check0027 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0027, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_alpha_node0028 world h nextB nextState
  · exact five_alpha_node0029 world h copies separate cover ceiling nextB nextState
theorem five_alpha_node0043 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0043 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha five_alpha_occ0043 .alpha (1 : Int) (1 : Int) five_alpha_check0043 B state
include copies separate cover ceiling in
theorem five_alpha_node0045 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0045 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0045 ((2 : Int),(1 : Int)) five_alpha_branches0045 copies separate cover ceiling five_alpha_check0045 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0045, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0046 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0046 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0046 ((2 : Int),(1 : Int)) five_alpha_branches0046 copies separate cover ceiling five_alpha_check0046 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0046, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0044 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0044 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0044 ((1 : Int),(1 : Int)) five_alpha_branches0044 copies separate cover ceiling five_alpha_check0044 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0044, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_alpha_node0045 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0046 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0001 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0001 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0001 ((1 : Int),(0 : Int)) five_alpha_branches0001 copies separate cover ceiling five_alpha_check0001 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0001, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact five_alpha_node0002 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0021 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0027 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0043 world h nextB nextState
  · exact five_alpha_node0044 world h copies separate cover ceiling nextB nextState
theorem five_alpha_node0048 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0048 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha five_alpha_occ0048 .gamma (1 : Int) (1 : Int) five_alpha_check0048 B state
theorem five_alpha_node0049 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0049 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha five_alpha_occ0049 .beta (1 : Int) (1 : Int) five_alpha_check0049 B state
include copies separate cover ceiling in
theorem five_alpha_node0052 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0052 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0052 ((3 : Int),(1 : Int)) five_alpha_branches0052 copies separate cover ceiling five_alpha_check0052 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0052, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0053 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0053 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0053 ((3 : Int),(1 : Int)) five_alpha_branches0053 copies separate cover ceiling five_alpha_check0053 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0053, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0051 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0051 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0051 ((2 : Int),(1 : Int)) five_alpha_branches0051 copies separate cover ceiling five_alpha_check0051 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0051, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_alpha_node0052 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0053 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0054 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0054 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0054 ((2 : Int),(1 : Int)) five_alpha_branches0054 copies separate cover ceiling five_alpha_check0054 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0054, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0055 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0055 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0055 ((2 : Int),(1 : Int)) five_alpha_branches0055 copies separate cover ceiling five_alpha_check0055 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0055, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0058 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0058 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0058 ((4 : Int),(1 : Int)) five_alpha_branches0058 copies separate cover ceiling five_alpha_check0058 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0058, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0059 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0059 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0059 ((4 : Int),(1 : Int)) five_alpha_branches0059 copies separate cover ceiling five_alpha_check0059 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0059, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0057 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0057 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0057 ((3 : Int),(1 : Int)) five_alpha_branches0057 copies separate cover ceiling five_alpha_check0057 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0057, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_alpha_node0058 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0059 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0061 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0061 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0061 ((4 : Int),(1 : Int)) five_alpha_branches0061 copies separate cover ceiling five_alpha_check0061 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0061, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0062 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0062 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0062 ((4 : Int),(1 : Int)) five_alpha_branches0062 copies separate cover ceiling five_alpha_check0062 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0062, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0060 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0060 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0060 ((3 : Int),(1 : Int)) five_alpha_branches0060 copies separate cover ceiling five_alpha_check0060 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0060, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_alpha_node0061 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0062 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0056 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0056 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0056 ((1 : Int),(3 : Int)) five_alpha_branches0056 copies separate cover ceiling five_alpha_check0056 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0056, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_alpha_node0057 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0060 world h copies separate cover ceiling nextB nextState
theorem five_alpha_node0063 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0063 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha five_alpha_occ0063 .alpha (1 : Int) (3 : Int) five_alpha_check0063 B state
include copies separate cover ceiling in
theorem five_alpha_node0064 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0064 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0064 ((2 : Int),(1 : Int)) five_alpha_branches0064 copies separate cover ceiling five_alpha_check0064 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0064, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0065 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0065 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0065 ((2 : Int),(1 : Int)) five_alpha_branches0065 copies separate cover ceiling five_alpha_check0065 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0065, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0050 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0050 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0050 ((1 : Int),(2 : Int)) five_alpha_branches0050 copies separate cover ceiling five_alpha_check0050 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0050, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact five_alpha_node0051 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0054 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0055 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0056 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0063 world h nextB nextState
  · exact five_alpha_node0064 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0065 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0047 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0047 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0047 ((1 : Int),(0 : Int)) five_alpha_branches0047 copies separate cover ceiling five_alpha_check0047 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0047, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact five_alpha_node0048 world h nextB nextState
  · exact five_alpha_node0049 world h nextB nextState
  · exact five_alpha_node0050 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0067 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0067 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0067 ((1 : Int),(1 : Int)) five_alpha_branches0067 copies separate cover ceiling five_alpha_check0067 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0067, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0069 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0069 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0069 ((1 : Int),(2 : Int)) five_alpha_branches0069 copies separate cover ceiling five_alpha_check0069 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0069, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0070 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0070 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0070 ((1 : Int),(2 : Int)) five_alpha_branches0070 copies separate cover ceiling five_alpha_check0070 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0070, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0068 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0068 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0068 ((1 : Int),(1 : Int)) five_alpha_branches0068 copies separate cover ceiling five_alpha_check0068 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0068, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_alpha_node0069 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0070 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0071 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0071 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0071 ((1 : Int),(1 : Int)) five_alpha_branches0071 copies separate cover ceiling five_alpha_check0071 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0071, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0066 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0066 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0066 ((1 : Int),(0 : Int)) five_alpha_branches0066 copies separate cover ceiling five_alpha_check0066 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0066, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact five_alpha_node0067 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0068 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0071 world h copies separate cover ceiling nextB nextState
theorem five_alpha_node0073 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0073 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha five_alpha_occ0073 .beta (1 : Int) (1 : Int) five_alpha_check0073 B state
theorem five_alpha_node0074 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0074 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha five_alpha_occ0074 .gammaTranspose (1 : Int) (1 : Int) five_alpha_check0074 B state
theorem five_alpha_node0076 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0076 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha five_alpha_occ0076 .alpha (3 : Int) (1 : Int) five_alpha_check0076 B state
include copies separate cover ceiling in
theorem five_alpha_node0079 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0079 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0079 ((1 : Int),(4 : Int)) five_alpha_branches0079 copies separate cover ceiling five_alpha_check0079 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0079, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0080 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0080 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0080 ((1 : Int),(4 : Int)) five_alpha_branches0080 copies separate cover ceiling five_alpha_check0080 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0080, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0078 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0078 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0078 ((3 : Int),(1 : Int)) five_alpha_branches0078 copies separate cover ceiling five_alpha_check0078 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0078, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_alpha_node0079 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0080 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0082 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0082 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0082 ((1 : Int),(4 : Int)) five_alpha_branches0082 copies separate cover ceiling five_alpha_check0082 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0082, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0083 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0083 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0083 ((1 : Int),(4 : Int)) five_alpha_branches0083 copies separate cover ceiling five_alpha_check0083 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0083, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0081 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0081 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0081 ((3 : Int),(1 : Int)) five_alpha_branches0081 copies separate cover ceiling five_alpha_check0081 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0081, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_alpha_node0082 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0083 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0077 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0077 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0077 ((1 : Int),(3 : Int)) five_alpha_branches0077 copies separate cover ceiling five_alpha_check0077 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0077, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_alpha_node0078 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0081 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0085 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0085 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0085 ((1 : Int),(3 : Int)) five_alpha_branches0085 copies separate cover ceiling five_alpha_check0085 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0085, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0084 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0084 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0084 ((2 : Int),(1 : Int)) five_alpha_branches0084 copies separate cover ceiling five_alpha_check0084 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0084, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact five_alpha_node0085 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0086 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0086 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0086 ((2 : Int),(1 : Int)) five_alpha_branches0086 copies separate cover ceiling five_alpha_check0086 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0086, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0088 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0088 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0088 ((1 : Int),(3 : Int)) five_alpha_branches0088 copies separate cover ceiling five_alpha_check0088 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0088, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0087 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0087 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0087 ((2 : Int),(1 : Int)) five_alpha_branches0087 copies separate cover ceiling five_alpha_check0087 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0087, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact five_alpha_node0088 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0075 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0075 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0075 ((1 : Int),(2 : Int)) five_alpha_branches0075 copies separate cover ceiling five_alpha_check0075 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0075, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact five_alpha_node0076 world h nextB nextState
  · exact five_alpha_node0077 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0084 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0086 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0087 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0072 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0072 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0072 ((0 : Int),(1 : Int)) five_alpha_branches0072 copies separate cover ceiling five_alpha_check0072 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0072, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact five_alpha_node0073 world h nextB nextState
  · exact five_alpha_node0074 world h nextB nextState
  · exact five_alpha_node0075 world h copies separate cover ceiling nextB nextState
theorem five_alpha_node0090 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0090 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha five_alpha_occ0090 .alpha (1 : Int) (1 : Int) five_alpha_check0090 B state
theorem five_alpha_node0092 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0092 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha five_alpha_occ0092 .gamma (1 : Int) (2 : Int) five_alpha_check0092 B state
include copies separate cover ceiling in
theorem five_alpha_node0095 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0095 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0095 ((3 : Int),(2 : Int)) five_alpha_branches0095 copies separate cover ceiling five_alpha_check0095 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0095, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0096 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0096 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0096 ((3 : Int),(2 : Int)) five_alpha_branches0096 copies separate cover ceiling five_alpha_check0096 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0096, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0094 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0094 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0094 ((2 : Int),(2 : Int)) five_alpha_branches0094 copies separate cover ceiling five_alpha_check0094 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0094, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_alpha_node0095 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0096 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0097 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0097 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0097 ((2 : Int),(2 : Int)) five_alpha_branches0097 copies separate cover ceiling five_alpha_check0097 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0097, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0098 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0098 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0098 ((2 : Int),(2 : Int)) five_alpha_branches0098 copies separate cover ceiling five_alpha_check0098 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0098, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0101 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0101 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0101 ((4 : Int),(2 : Int)) five_alpha_branches0101 copies separate cover ceiling five_alpha_check0101 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0101, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0102 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0102 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0102 ((4 : Int),(2 : Int)) five_alpha_branches0102 copies separate cover ceiling five_alpha_check0102 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0102, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0100 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0100 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0100 ((3 : Int),(2 : Int)) five_alpha_branches0100 copies separate cover ceiling five_alpha_check0100 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0100, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_alpha_node0101 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0102 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0104 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0104 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0104 ((4 : Int),(2 : Int)) five_alpha_branches0104 copies separate cover ceiling five_alpha_check0104 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0104, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0105 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0105 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0105 ((4 : Int),(2 : Int)) five_alpha_branches0105 copies separate cover ceiling five_alpha_check0105 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0105, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0103 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0103 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0103 ((3 : Int),(2 : Int)) five_alpha_branches0103 copies separate cover ceiling five_alpha_check0103 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0103, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_alpha_node0104 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0105 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0099 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0099 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0099 ((1 : Int),(4 : Int)) five_alpha_branches0099 copies separate cover ceiling five_alpha_check0099 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0099, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_alpha_node0100 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0103 world h copies separate cover ceiling nextB nextState
theorem five_alpha_node0106 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0106 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha five_alpha_occ0106 .alpha (1 : Int) (4 : Int) five_alpha_check0106 B state
include copies separate cover ceiling in
theorem five_alpha_node0107 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0107 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0107 ((2 : Int),(2 : Int)) five_alpha_branches0107 copies separate cover ceiling five_alpha_check0107 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0107, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0108 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0108 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0108 ((2 : Int),(2 : Int)) five_alpha_branches0108 copies separate cover ceiling five_alpha_check0108 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0108, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0093 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0093 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0093 ((1 : Int),(3 : Int)) five_alpha_branches0093 copies separate cover ceiling five_alpha_check0093 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0093, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact five_alpha_node0094 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0097 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0098 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0099 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0106 world h nextB nextState
  · exact five_alpha_node0107 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0108 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0091 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0091 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0091 ((1 : Int),(1 : Int)) five_alpha_branches0091 copies separate cover ceiling five_alpha_check0091 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0091, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_alpha_node0092 world h nextB nextState
  · exact five_alpha_node0093 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0110 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0110 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0110 ((1 : Int),(2 : Int)) five_alpha_branches0110 copies separate cover ceiling five_alpha_check0110 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0110, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0111 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0111 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0111 ((1 : Int),(2 : Int)) five_alpha_branches0111 copies separate cover ceiling five_alpha_check0111 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0111, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0109 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0109 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0109 ((1 : Int),(1 : Int)) five_alpha_branches0109 copies separate cover ceiling five_alpha_check0109 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0109, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_alpha_node0110 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0111 world h copies separate cover ceiling nextB nextState
theorem five_alpha_node0113 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0113 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha five_alpha_occ0113 .beta (1 : Int) (2 : Int) five_alpha_check0113 B state
theorem five_alpha_node0114 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0114 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha five_alpha_occ0114 .gammaTranspose (1 : Int) (2 : Int) five_alpha_check0114 B state
theorem five_alpha_node0116 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0116 B) : Transition world h .alpha B := by
  exact replay_leaf world h .alpha five_alpha_occ0116 .alpha (3 : Int) (2 : Int) five_alpha_check0116 B state
include copies separate cover ceiling in
theorem five_alpha_node0119 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0119 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0119 ((1 : Int),(5 : Int)) five_alpha_branches0119 copies separate cover ceiling five_alpha_check0119 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0119, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0120 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0120 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0120 ((1 : Int),(5 : Int)) five_alpha_branches0120 copies separate cover ceiling five_alpha_check0120 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0120, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0118 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0118 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0118 ((3 : Int),(2 : Int)) five_alpha_branches0118 copies separate cover ceiling five_alpha_check0118 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0118, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_alpha_node0119 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0120 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0122 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0122 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0122 ((1 : Int),(5 : Int)) five_alpha_branches0122 copies separate cover ceiling five_alpha_check0122 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0122, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0123 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0123 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0123 ((1 : Int),(5 : Int)) five_alpha_branches0123 copies separate cover ceiling five_alpha_check0123 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0123, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0121 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0121 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0121 ((3 : Int),(2 : Int)) five_alpha_branches0121 copies separate cover ceiling five_alpha_check0121 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0121, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_alpha_node0122 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0123 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0117 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0117 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0117 ((1 : Int),(4 : Int)) five_alpha_branches0117 copies separate cover ceiling five_alpha_check0117 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0117, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_alpha_node0118 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0121 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0125 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0125 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0125 ((1 : Int),(4 : Int)) five_alpha_branches0125 copies separate cover ceiling five_alpha_check0125 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0125, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0124 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0124 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0124 ((2 : Int),(2 : Int)) five_alpha_branches0124 copies separate cover ceiling five_alpha_check0124 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0124, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact five_alpha_node0125 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0126 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0126 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0126 ((2 : Int),(2 : Int)) five_alpha_branches0126 copies separate cover ceiling five_alpha_check0126 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0126, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0128 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0128 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0128 ((1 : Int),(4 : Int)) five_alpha_branches0128 copies separate cover ceiling five_alpha_check0128 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0128, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0127 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0127 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0127 ((2 : Int),(2 : Int)) five_alpha_branches0127 copies separate cover ceiling five_alpha_check0127 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0127, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact five_alpha_node0128 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0115 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0115 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0115 ((1 : Int),(3 : Int)) five_alpha_branches0115 copies separate cover ceiling five_alpha_check0115 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0115, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact five_alpha_node0116 world h nextB nextState
  · exact five_alpha_node0117 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0124 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0126 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0127 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0112 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0112 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0112 ((0 : Int),(2 : Int)) five_alpha_branches0112 copies separate cover ceiling five_alpha_check0112 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0112, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact five_alpha_node0113 world h nextB nextState
  · exact five_alpha_node0114 world h nextB nextState
  · exact five_alpha_node0115 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0131 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0131 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0131 ((2 : Int),(2 : Int)) five_alpha_branches0131 copies separate cover ceiling five_alpha_check0131 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0131, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0132 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0132 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0132 ((2 : Int),(2 : Int)) five_alpha_branches0132 copies separate cover ceiling five_alpha_check0132 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0132, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0130 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0130 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0130 ((1 : Int),(2 : Int)) five_alpha_branches0130 copies separate cover ceiling five_alpha_check0130 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0130, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_alpha_node0131 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0132 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0133 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0133 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0133 ((1 : Int),(2 : Int)) five_alpha_branches0133 copies separate cover ceiling five_alpha_check0133 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0133, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0134 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0134 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0134 ((1 : Int),(2 : Int)) five_alpha_branches0134 copies separate cover ceiling five_alpha_check0134 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0134, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0129 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0129 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0129 ((0 : Int),(2 : Int)) five_alpha_branches0129 copies separate cover ceiling five_alpha_check0129 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0129, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact five_alpha_node0130 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0133 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0134 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0089 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0089 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0089 ((0 : Int),(1 : Int)) five_alpha_branches0089 copies separate cover ceiling five_alpha_check0089 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0089, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact five_alpha_node0090 world h nextB nextState
  · exact five_alpha_node0091 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0109 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0112 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0129 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0137 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0137 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0137 ((2 : Int),(1 : Int)) five_alpha_branches0137 copies separate cover ceiling five_alpha_check0137 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0137, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0138 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0138 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0138 ((2 : Int),(1 : Int)) five_alpha_branches0138 copies separate cover ceiling five_alpha_check0138 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0138, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0136 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0136 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0136 ((1 : Int),(1 : Int)) five_alpha_branches0136 copies separate cover ceiling five_alpha_check0136 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0136, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_alpha_node0137 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0138 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0139 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0139 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0139 ((1 : Int),(1 : Int)) five_alpha_branches0139 copies separate cover ceiling five_alpha_check0139 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0139, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0140 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0140 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0140 ((1 : Int),(1 : Int)) five_alpha_branches0140 copies separate cover ceiling five_alpha_check0140 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0140, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_alpha_node0135 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0135 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0135 ((0 : Int),(1 : Int)) five_alpha_branches0135 copies separate cover ceiling five_alpha_check0135 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0135, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact five_alpha_node0136 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0139 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0140 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_alpha_node0000 (B : Int → Int → Prop)
    (state : State world h five_alpha_occ0000 B) : Transition world h .alpha B := by
  apply replay_step (5 : Int) (by decide) world h .alpha five_alpha_occ0000 ((0 : Int),(0 : Int)) five_alpha_branches0000 copies separate cover ceiling five_alpha_check0000 ?_ B state
  intro branch member nextB nextState
  simp only [five_alpha_branches0000, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact five_alpha_node0001 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0047 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0066 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0072 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0089 world h copies separate cover ceiling nextB nextState
  · exact five_alpha_node0135 world h copies separate cover ceiling nextB nextState
end FiveAlpha

theorem five_alpha_seed_eq : SameCells (seed .alpha) five_alpha_occ0000 := by decide

theorem five_alpha_local (world : Cross → Prop) (h : Int) (B : Int → Int → Prop)
    (copies : ∀ t, world t → Copy 5 1 1 0 t)
    (separate : DisjointWorld world) (cover : CoversWindow world h)
    (ceiling : SelectedBelow world h) (closed : TileClosed world B)
    (bounded : Below h B) (clean : Clean .alpha 0 0 B) :
    Transition world h .alpha B := by
  exact five_alpha_node0000 world h copies separate cover ceiling B
    (state_congr five_alpha_seed_eq (seed_state world h .alpha B closed bounded clean))
#print axioms five_alpha_local

end CornerCertificate

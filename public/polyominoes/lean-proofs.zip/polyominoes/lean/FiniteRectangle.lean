import TilingCore

namespace PolyominoFormal
namespace FiniteRectangle
open CrossUnits

instance (a b c d : Int) (t : Cross) : Decidable (Copy a b c d t) := by
  unfold Copy Arms; infer_instance
instance (t : Cross) (x y : Int) : Decidable (Contains t x y) := by
  unfold Contains; infer_instance
instance (t u : Cross) : Decidable (Apart t u) := by
  unfold Apart; infer_instance
instance (t u : Cross) : Decidable (Same t u) := by
  unfold Same; infer_instance

def InsideBounds (w h : Int) (t : Cross) : Prop :=
  0≤t.east ∧ 0≤t.north ∧ 0≤t.west ∧ 0≤t.south ∧
  0≤t.x-t.west ∧ t.x+t.east<w ∧ 0≤t.y-t.south ∧ t.y+t.north<h
instance (w h : Int) (t : Cross) : Decidable (InsideBounds w h t) := by
  unfold InsideBounds; infer_instance

theorem inside_of_bounds {w h : Int} {t : Cross} (bounds : InsideBounds w h t)
    (x y : Int) (hit : Contains t x y) : Rectangle w h x y := by
  unfold InsideBounds at bounds
  unfold Contains at hit
  unfold Rectangle
  omega

theorem apart_no_common {t u : Cross} (sep : Apart t u) (x y : Int)
    (ht : Contains t x y) (hu : Contains u x y) : False := by
  unfold Apart at sep
  unfold Contains at ht hu
  omega

def copiesCheck (ts : List Cross) (a b c d : Int) : Bool :=
  ts.all fun t => decide (Copy a b c d t)
def insideCheck (ts : List Cross) (w h : Nat) : Bool :=
  ts.all fun t => decide (InsideBounds w h t)
def coverCheck (ts : List Cross) (w h : Nat) : Bool :=
  (List.range w).all fun x => (List.range h).all fun y =>
    ts.any fun t => decide (Contains t (x : Int) (y : Int))
def separateCheck (ts : List Cross) : Bool :=
  ts.all fun t => ts.all fun u => decide (Same t u ∨ Apart t u)

/-- Kernel-checked finite certificates yield the same actual tiling structure
    as the infinite constructions. Every pair of pieces is checked. -/
def tilingOfChecks (ts : List Cross) (a b c d : Int) (w h : Nat)
    (copies : copiesCheck ts a b c d=true)
    (inside : insideCheck ts w h=true)
    (cover : coverCheck ts w h=true)
    (separate : separateCheck ts=true) : Tiling a b c d (Rectangle w h) where
  world t := t∈ts
  copies := by
    intro t ht
    exact of_decide_eq_true ((List.all_eq_true.1 copies) t ht)
  inside := by
    intro t ht x y hc
    exact inside_of_bounds (of_decide_eq_true ((List.all_eq_true.1 inside) t ht)) x y hc
  cover := by
    intro x y hc
    have hx : x.toNat∈List.range w := List.mem_range.2 (by unfold Rectangle at hc; omega)
    have hy : y.toNat∈List.range h := List.mem_range.2 (by unfold Rectangle at hc; omega)
    have found := (List.all_eq_true.1 ((List.all_eq_true.1 cover) x.toNat hx)) y.toNat hy
    obtain ⟨t,ht,hc'⟩ := List.any_eq_true.1 found
    refine ⟨t,ht,?_⟩
    have hx' : (x.toNat : Int)=x := by unfold Rectangle at hc; omega
    have hy' : (y.toNat : Int)=y := by unfold Rectangle at hc; omega
    simpa only [hx',hy'] using (of_decide_eq_true hc')
  disjoint := by
    intro t u x y ht hu hc hd
    have pair := (List.all_eq_true.1 ((List.all_eq_true.1 separate) t ht)) u hu
    rcases of_decide_eq_true pair with eq | sep
    · exact same_eq eq
    · exact False.elim (apart_no_common sep x y hc hd)

end FiniteRectangle
end PolyominoFormal

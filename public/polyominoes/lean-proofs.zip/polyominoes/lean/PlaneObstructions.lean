import TilingSymmetry
import TPlaneGeometry

namespace PolyominoFormal
open CrossUnits

/-- The earlier anchored theorem now excludes arbitrary plane tilings,
    with normalization itself checked in Lean. -/
theorem adjacent_units_no_plane (c d : Int) (hc : 2 ≤ c) (hd : c ≤ d) :
    ¬ Tiles 1 1 c d Plane := by
  rintro ⟨T⟩
  obtain ⟨U, anchor⟩ := normalize_plane T
  exact adjacent_no_anchored_plane 1 1 c d rfl rfl hc hd U.world U.copies
    (fun x y => U.cover x y True.intro) U.disjoint anchor

theorem one_unit_no_plane (a c d : Int) (ha : 2 ≤ a) (hc : a ≤ c) (hd : 2 ≤ d) :
    ¬ Tiles a 1 c d Plane := by
  rintro ⟨T⟩
  obtain ⟨U, anchor⟩ := normalize_plane T
  exact one_no_anchored_plane a 1 c d ha rfl hc hd U.world U.copies
    (fun x y => U.cover x y True.intro) U.disjoint anchor

theorem short_stem_two_arm_no_plane (a b : Int)
    (ha : 2 ≤ a) (hb : 3 ≤ b) (hlt : b < a+3) :
    ¬ Tiles a b 2 0 Plane := by
  rintro ⟨T⟩
  obtain ⟨U, anchor⟩ := normalize_plane T
  exact TPlane.two_short_no_anchored_plane a b 2 0 ha (by omega) hb rfl rfl hlt
    U.world U.copies (fun x y => U.cover x y True.intro) U.disjoint anchor

#print axioms adjacent_units_no_plane
#print axioms one_unit_no_plane
#print axioms short_stem_two_arm_no_plane
end PolyominoFormal

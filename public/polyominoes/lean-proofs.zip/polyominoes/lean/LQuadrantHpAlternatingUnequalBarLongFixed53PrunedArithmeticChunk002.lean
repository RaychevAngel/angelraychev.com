import LQuadrantHpAlternatingUnequalBarLongFixed53PrunedArithmeticDefs
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace LRegionArithmetic

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n050_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((14 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((14 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n050_empty (a b : Int)
    (h0 : (((((14 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((14 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((13 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (13 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (5 : Int))) ∨ (((18 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (18 : Int)) ∧ ((2 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n050_o0 (a b jx jy : Int)
    (h0 : (((12 : Int) > (jx + a)) ∨ ((12 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h3 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n050_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h3 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n050_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h2 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n050_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h2 : (b = (3 : Int)))
    (h3 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n050_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h3 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n050_o5 (a b jx jy : Int)
    (h0 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h1 : (b = (3 : Int)))
    (h2 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (¬ ((((19 : Int) = jx) ∧ ((2 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a = (5 : Int)))
    (h8 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n050_o6 (a b jx jy : Int)
    (h0 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h1 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((13 : Int) > (jx + b)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n050_o7 (a b jx jy : Int)
    (h0 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h1 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h2 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n051_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((14 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((14 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n051_empty (a b : Int)
    (h0 : (((((14 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-13 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (23 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (24 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (10 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((14 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((13 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (13 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((18 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((18 : Int) + (0 : Int))) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ (((18 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (18 : Int)) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((19 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((19 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((19 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (19 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n051_o0 (a b jx jy : Int)
    (h0 : (((13 : Int) > (jx + a)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h1 : (((19 : Int) > (jx + a)) ∨ ((19 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h2 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n051_o1 (a b jx jy : Int)
    (h0 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n051_o2 (a b jx jy : Int)
    (h0 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h1 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h2 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n051_o3 (a b jx jy : Int)
    (h0 : (((19 : Int) > (jx + (0 : Int))) ∨ ((19 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h1 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n051_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n051_o5 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h2 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((19 : Int) > (jx + (0 : Int))) ∨ ((19 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n051_o6 (a b jx jy : Int)
    (h0 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h3 : (((13 : Int) > (jx + b)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n051_o7 (a b jx jy : Int)
    (h0 : ((jx < ((18 : Int) - (5 : Int))) ∨ (((18 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h1 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n052_point (a b : Int)
    (h0 : (¬ (((12 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((12 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n052_empty (a b : Int)
    (h0 : (((((12 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((12 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (-13 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (-12 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((12 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (-1 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (0 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((12 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (11 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (12 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((12 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (23 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (24 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (1 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((12 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (10 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((12 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((13 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((13 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (13 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((11 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((11 : Int) + (5 : Int))) ∧ ((7 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (7 : Int))) ∨ (((11 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (11 : Int)) ∧ ((4 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((4 : Int) ≤ ((7 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n052_o0 (a b jx jy : Int)
    (h0 : ((jx < ((11 : Int) - (0 : Int))) ∨ (((11 : Int) + (5 : Int)) < jx) ∨ ((7 : Int) > (jy + b)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h1 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((12 : Int) ≥ (jx - (0 : Int))) ∧ ((12 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h4 : (((11 : Int) > (jx + a)) ∨ ((11 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (3 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n052_o1 (a b jx jy : Int)
    (h0 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((12 : Int) ≥ (jx - (0 : Int))) ∧ ((12 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((11 : Int) - (0 : Int))) ∨ (((11 : Int) + (5 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n052_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - b))))
    (h2 : ((((12 : Int) ≥ (jx - a)) ∧ ((12 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h4 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h5 : ((jx < ((11 : Int) - (0 : Int))) ∨ (((11 : Int) + (5 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h6 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n052_o3 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h3 : ((((12 : Int) ≥ (jx - b)) ∧ ((12 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h4 : (((11 : Int) > (jx + (0 : Int))) ∨ ((11 : Int) < (jx - b)) ∨ (jy < ((7 : Int) - (3 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n052_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((jx < ((11 : Int) - (0 : Int))) ∨ (((11 : Int) + (5 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h2 : ((((12 : Int) ≥ (jx - b)) ∧ ((12 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n052_o5 (a b jx jy : Int)
    (h0 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((jx < ((11 : Int) - (0 : Int))) ∨ (((11 : Int) + (5 : Int)) < jx) ∨ ((7 : Int) > (jy + b)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h4 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h5 : ((((12 : Int) ≥ (jx - a)) ∧ ((12 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n052_o6 (a b jx jy : Int)
    (h0 : (((13 : Int) > (jx + b)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h4 : ((((12 : Int) ≥ (jx - (0 : Int))) ∧ ((12 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((11 : Int) > (jx + b)) ∨ ((11 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (3 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n052_o7 (a b jx jy : Int)
    (h0 : (((11 : Int) > (jx + a)) ∨ ((11 : Int) < (jx - (0 : Int))) ∨ (jy < ((7 : Int) - (3 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h1 : ((((12 : Int) ≥ (jx - (0 : Int))) ∧ ((12 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - b))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h6 : ((jx < ((11 : Int) - (0 : Int))) ∨ (((11 : Int) + (5 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n053_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((11 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((11 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n053_empty (a b : Int)
    (h0 : (((((11 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((11 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (11 : Int)) ∧ ((11 : Int) ≤ (-13 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((11 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((11 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (11 : Int)) ∧ ((11 : Int) ≤ (-12 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((11 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((11 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (11 : Int)) ∧ ((11 : Int) ≤ (-1 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((11 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((11 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (11 : Int)) ∧ ((11 : Int) ≤ (0 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((11 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((11 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (11 : Int)) ∧ ((11 : Int) ≤ (11 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((11 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((11 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (11 : Int)) ∧ ((11 : Int) ≤ (12 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((11 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((11 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (11 : Int)) ∧ ((11 : Int) ≤ (23 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((11 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((11 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (11 : Int)) ∧ ((11 : Int) ≤ (24 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((11 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((11 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (11 : Int)) ∧ ((11 : Int) ≤ (1 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((11 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((11 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (11 : Int)) ∧ ((11 : Int) ≤ (10 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((11 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((11 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (11 : Int)) ∧ ((11 : Int) ≤ (13 : Int)) ∧ ((4 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((6 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n053_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((10 : Int) > (jx + a)) ∨ ((10 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((13 : Int) > (jx + a)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h4 : (((11 : Int) > (jx + a)) ∨ ((11 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((((11 : Int) ≥ (jx - (0 : Int))) ∧ ((11 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((11 : Int) ≥ jx) ∧ ((11 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n053_o1 (a b jx jy : Int)
    (h0 : ((((11 : Int) ≥ (jx - (0 : Int))) ∧ ((11 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((11 : Int) ≥ jx) ∧ ((11 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((11 : Int) > jx) ∨ ((11 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - a))))
    (h4 : (b = (3 : Int)))
    (h5 : (¬ ((((11 : Int) = jx) ∧ ((9 : Int) = jy) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a)))))
    (h6 : (a = (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n053_o2 (a b jx jy : Int)
    (h0 : (¬ ((((11 : Int) = jx) ∧ ((7 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b)))))
    (h1 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h3 : (b = (3 : Int)))
    (h4 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - b))))
    (h5 : (a = (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jy - b) ≥ (0 : Int)))
    (h8 : ((((11 : Int) ≥ (jx - a)) ∧ ((11 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((11 : Int) ≥ jx) ∧ ((11 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h9 : (((11 : Int) > jx) ∨ ((11 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n053_o3 (a b jx jy : Int)
    (h0 : (((11 : Int) > jx) ∨ ((11 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - b)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h4 : (((10 : Int) > (jx + (0 : Int))) ∨ ((10 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h5 : ((((11 : Int) ≥ (jx - b)) ∧ ((11 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((11 : Int) ≥ jx) ∧ ((11 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n053_o4 (a b jx jy : Int)
    (h0 : (¬ ((((11 : Int) = jx) ∧ ((9 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a)))))
    (h1 : (a = (5 : Int)))
    (h2 : ((((11 : Int) ≥ (jx - b)) ∧ ((11 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((11 : Int) ≥ jx) ∧ ((11 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (((11 : Int) > jx) ∨ ((11 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - a))))
    (h4 : (b = (3 : Int)))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n053_o5 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((11 : Int) > jx) ∨ ((11 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h3 : (((10 : Int) > (jx + (0 : Int))) ∨ ((10 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h4 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((((11 : Int) ≥ (jx - a)) ∧ ((11 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((11 : Int) ≥ jx) ∧ ((11 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n053_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((11 : Int) ≥ (jx - (0 : Int))) ∧ ((11 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((11 : Int) ≥ jx) ∧ ((11 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((11 : Int) > jx) ∨ ((11 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h5 : (((13 : Int) > (jx + b)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h6 : (((10 : Int) > (jx + b)) ∨ ((10 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n053_o7 (a b jx jy : Int)
    (h0 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ ((((11 : Int) = jx) ∧ ((7 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b)))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (((11 : Int) > jx) ∨ ((11 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - b))))
    (h5 : (a = (5 : Int)))
    (h6 : ((((11 : Int) ≥ (jx - (0 : Int))) ∧ ((11 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((11 : Int) ≥ jx) ∧ ((11 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (b = (3 : Int)))
    (h8 : (((10 : Int) > (jx + a)) ∨ ((10 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n054_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((12 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((12 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n054_empty (a b : Int)
    (h0 : (((((12 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((12 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (-13 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (-12 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((12 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (-1 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (0 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((12 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (11 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (12 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((12 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (23 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (24 : Int)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (1 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((12 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (10 : Int)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((12 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (13 : Int)) ∧ ((4 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((12 : Int) ≥ ((11 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((11 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (11 : Int)) ∧ ((4 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((4 : Int) ≤ ((9 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n054_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((13 : Int) > (jx + a)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h3 : ((((12 : Int) ≥ (jx - (0 : Int))) ∧ ((12 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h4 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((11 : Int) > (jx + a)) ∨ ((11 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n054_o1 (a b jx jy : Int)
    (h0 : ((((12 : Int) ≥ (jx - (0 : Int))) ∧ ((12 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < ((11 : Int) - (0 : Int))) ∨ (((11 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - a))))
    (h2 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n054_o2 (a b jx jy : Int)
    (h0 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((11 : Int) - (0 : Int))) ∨ (((11 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - b))))
    (h3 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h4 : (((11 : Int) > (jx + (0 : Int))) ∨ ((11 : Int) < (jx - a)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((((12 : Int) ≥ (jx - a)) ∧ ((12 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n054_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < ((11 : Int) - (0 : Int))) ∨ (((11 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + a)) ∨ ((9 : Int) < (jy - (0 : Int)))))
    (h2 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - b)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h3 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((12 : Int) ≥ (jx - b)) ∧ ((12 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n054_o4 (a b jx jy : Int)
    (h0 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((12 : Int) ≥ (jx - b)) ∧ ((12 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((jx < ((11 : Int) - (0 : Int))) ∨ (((11 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n054_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((11 : Int) > (jx + (0 : Int))) ∨ ((11 : Int) < (jx - a)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h6 : ((((12 : Int) ≥ (jx - a)) ∧ ((12 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n054_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h2 : ((((12 : Int) ≥ (jx - (0 : Int))) ∧ ((12 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h3 : (((11 : Int) > (jx + b)) ∨ ((11 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h4 : ((jx < ((11 : Int) - (0 : Int))) ∨ (((11 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + a)) ∨ ((9 : Int) < (jy - (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n054_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (¬ ((((12 : Int) = jx) ∧ ((7 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b)))))
    (h2 : ((((12 : Int) ≥ (jx - (0 : Int))) ∧ ((12 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - b))))
    (h5 : (((11 : Int) > (jx + a)) ∨ ((11 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h6 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h7 : (b = (3 : Int)))
    (h8 : (a = (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n055_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((12 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((8 : Int) ≥ (0 : Int)) ∧ ((12 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((8 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n055_empty (a b : Int)
    (h0 : (((((12 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((12 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (-13 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (-12 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((12 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (-1 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (0 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((12 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (11 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (12 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((12 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (23 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (24 : Int)) ∧ ((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (1 : Int)) ∧ ((8 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((12 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((12 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (10 : Int)) ∧ ((8 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((12 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (13 : Int)) ∧ ((8 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((12 : Int) ≥ ((11 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((11 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (11 : Int)) ∧ ((8 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((8 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((12 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((12 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((7 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (7 : Int))) ∨ (((12 : Int) ≤ (12 : Int)) ∧ ((12 : Int) ≤ (12 : Int)) ∧ ((8 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((8 : Int) ≤ ((7 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n055_o0 (a b jx jy : Int)
    (h0 : (((12 : Int) > (jx + a)) ∨ ((12 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h1 : ((jx < ((11 : Int) - (0 : Int))) ∨ (((11 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + b)) ∨ ((9 : Int) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (5 : Int)) < jx) ∨ ((7 : Int) > (jy + b)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h5 : ((((12 : Int) ≥ (jx - (0 : Int))) ∧ ((12 : Int) ≤ (jx + a)) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - (0 : Int))) ∧ ((8 : Int) ≤ (jy + b)))))
    (h6 : (((11 : Int) > (jx + a)) ∨ ((11 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n055_o1 (a b jx jy : Int)
    (h0 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + (0 : Int)) < ((7 : Int) - (3 : Int))) ∨ (((7 : Int) + (0 : Int)) < (jy - a))))
    (h1 : ((jx < ((11 : Int) - (0 : Int))) ∨ (((11 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - a))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (((11 : Int) > (jx + b)) ∨ ((11 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h5 : ((((12 : Int) ≥ (jx - (0 : Int))) ∧ ((12 : Int) ≤ (jx + b)) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - a)) ∧ ((8 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n055_o2 (a b jx jy : Int)
    (h0 : (((12 : Int) > (jx + (0 : Int))) ∨ ((12 : Int) < (jx - a)) ∨ (jy < ((7 : Int) - (3 : Int))) ∨ (((7 : Int) + (0 : Int)) < jy)))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h2 : ((jx < ((11 : Int) - (0 : Int))) ∨ (((11 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - b))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (5 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - b))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a = (5 : Int)))
    (h8 : ((((12 : Int) ≥ (jx - a)) ∧ ((12 : Int) ≤ (jx + (0 : Int))) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - b)) ∧ ((8 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n055_o3 (a b jx jy : Int)
    (h0 : (((12 : Int) > (jx + (0 : Int))) ∨ ((12 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ ((((15 : Int) = jx) ∧ ((8 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : (b = (3 : Int)))
    (h4 : (((11 : Int) > (jx + (0 : Int))) ∨ ((11 : Int) < (jx - b)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h5 : ((((12 : Int) ≥ (jx - b)) ∧ ((12 : Int) ≤ (jx + (0 : Int))) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - (0 : Int))) ∧ ((8 : Int) ≤ (jy + a)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a = (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n055_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (b = (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (5 : Int)) < jx) ∨ ((7 : Int) > (jy + (0 : Int))) ∨ ((7 : Int) < (jy - a))))
    (h4 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + (0 : Int)) < ((7 : Int) - (3 : Int))) ∨ (((7 : Int) + (0 : Int)) < (jy - a))))
    (h5 : ((jx < ((11 : Int) - (0 : Int))) ∨ (((11 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - a))))
    (h6 : ((((12 : Int) ≥ (jx - b)) ∧ ((12 : Int) ≤ (jx + (0 : Int))) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - a)) ∧ ((8 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n055_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((17 : Int) = jx) ∧ ((8 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((12 : Int) > (jx + (0 : Int))) ∨ ((12 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h4 : (a = (5 : Int)))
    (h5 : (((11 : Int) > (jx + (0 : Int))) ∨ ((11 : Int) < (jx - a)) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h6 : ((((12 : Int) ≥ (jx - a)) ∧ ((12 : Int) ≤ (jx + (0 : Int))) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - (0 : Int))) ∧ ((8 : Int) ≤ (jy + b)))))
    (h7 : (b = (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n055_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((12 : Int) > (jx + b)) ∨ ((12 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + (3 : Int)) < jy)))
    (h2 : ((((12 : Int) ≥ (jx - (0 : Int))) ∧ ((12 : Int) ≤ (jx + b)) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - (0 : Int))) ∧ ((8 : Int) ≤ (jy + a)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((11 : Int) > (jx + b)) ∨ ((11 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    (h5 : ((jx < ((11 : Int) - (0 : Int))) ∨ (((11 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + a)) ∨ ((9 : Int) < (jy - (0 : Int)))))
    (h6 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + a) < ((7 : Int) - (3 : Int))) ∨ (((7 : Int) + (0 : Int)) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n055_o7 (a b jx jy : Int)
    (h0 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((12 : Int) ≥ (jx - (0 : Int))) ∧ ((12 : Int) ≤ (jx + a)) ∧ ((8 : Int) ≥ jy) ∧ ((8 : Int) ≤ jy)) ∨ (((12 : Int) ≥ jx) ∧ ((12 : Int) ≤ jx) ∧ ((8 : Int) ≥ (jy - b)) ∧ ((8 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (((12 : Int) > jx) ∨ ((12 : Int) < jx) ∨ ((jy + (0 : Int)) < ((7 : Int) - (3 : Int))) ∨ (((7 : Int) + (0 : Int)) < (jy - b))))
    (h5 : ((jx < ((11 : Int) - (0 : Int))) ∨ (((11 : Int) + (3 : Int)) < jx) ∨ ((9 : Int) > (jy + (0 : Int))) ∨ ((9 : Int) < (jy - b))))
    (h6 : (((11 : Int) > (jx + a)) ∨ ((11 : Int) < (jx - (0 : Int))) ∨ (jy < ((9 : Int) - (5 : Int))) ∨ (((9 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n056_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((14 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((14 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n056_empty (a b : Int)
    (h0 : (((((14 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-13 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-1 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (0 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (23 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (24 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (10 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((14 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (13 : Int)) ∧ ((1 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((1 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((7 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (7 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((1 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((1 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((15 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((15 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (8 : Int))) ∨ (((15 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (15 : Int)) ∧ ((1 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((8 : Int) + (5 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n056_o0 (a b jx jy : Int)
    (h0 : (b = (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ ((((14 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (5 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h4 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h5 : (((13 : Int) > (jx + a)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a = (5 : Int)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n056_o1 (a b jx jy : Int)
    (h0 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h3 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n056_o2 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n056_o3 (a b jx jy : Int)
    (h0 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h1 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h2 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (5 : Int)) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h3 : (a = (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b = (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - b)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h9 : (¬ ((((17 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n056_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h2 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ ((((0 : Int) = a) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ ((((0 : Int) = b) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = b)))))))
    (h3 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n056_o5 (a b jx jy : Int)
    (h0 : (¬ ((((19 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h2 : (b = (3 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a = (5 : Int)))
    (h5 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (5 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n056_o6 (a b jx jy : Int)
    (h0 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (5 : Int)) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h4 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h5 : (((13 : Int) > (jx + b)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n056_o7 (a b jx jy : Int)
    (h0 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h1 : (b = (3 : Int)))
    (h2 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (¬ ((((14 : Int) = jx) ∧ ((4 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b)))))
    (h4 : (a = (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n057_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((14 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((5 : Int) ≥ (0 : Int)) ∧ ((14 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((5 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n057_empty (a b : Int)
    (h0 : (((((14 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-13 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-12 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-1 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (0 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (23 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (24 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (1 : Int)) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (10 : Int)) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((14 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (13 : Int)) ∧ ((5 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((5 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((7 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (7 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((5 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((5 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((15 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((15 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (8 : Int))) ∨ (((15 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (15 : Int)) ∧ ((5 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((8 : Int) + (5 : Int))))) ∨ ((((14 : Int) ≥ ((14 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((14 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ (((14 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (14 : Int)) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n057_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + b)))))
    (h3 : (((13 : Int) > (jx + a)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h4 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + b)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h5 : (((14 : Int) > jx) ∨ ((14 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n057_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - a)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h4 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n057_o2 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h2 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h3 : (a = (5 : Int)))
    (h4 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - b)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (b = (3 : Int)))
    (h8 : (¬ ((((19 : Int) = jx) ∧ ((5 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n057_o3 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b = (3 : Int)))
    (h3 : (((14 : Int) > jx) ∨ ((14 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h4 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + a)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (5 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n057_o4 (a b jx jy : Int)
    (h0 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - a)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ ((((0 : Int) = a) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ ((((0 : Int) = b) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = b)))))))
    (h2 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n057_o5 (a b jx jy : Int)
    (h0 : (b = (3 : Int)))
    (h1 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + b)))))
    (h2 : (((14 : Int) > jx) ∨ ((14 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h3 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h4 : (¬ ((((19 : Int) = jx) ∧ ((5 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (a = (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n057_o6 (a b jx jy : Int)
    (h0 : (((14 : Int) > jx) ∨ ((14 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h1 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + a)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((13 : Int) > (jx + b)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n057_o7 (a b jx jy : Int)
    (h0 : (((13 : Int) > (jx + a)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (a = (5 : Int)))
    (h3 : (((14 : Int) > jx) ∨ ((14 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < (jy - b))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - b)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n058_point (a b : Int)
    (h0 : (¬ (((15 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((15 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n058_empty (a b : Int)
    (h0 : (((((15 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((15 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (13 : Int)) ∧ ((2 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((15 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((15 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (8 : Int))) ∨ (((15 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (15 : Int)) ∧ ((2 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((8 : Int) + (5 : Int))))) ∨ ((((15 : Int) ≥ ((14 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((14 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((14 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (14 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((19 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((19 : Int) + (0 : Int))) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (5 : Int))) ∨ (((19 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (19 : Int)) ∧ ((2 : Int) ≥ ((5 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n058_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h3 : (((14 : Int) > (jx + a)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h4 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n058_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n058_o2 (a b jx jy : Int)
    (h0 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n058_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h4 : (((19 : Int) > (jx + (0 : Int))) ∨ ((19 : Int) < (jx - b)) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n058_o4 (a b jx jy : Int)
    (h0 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n058_o5 (a b jx jy : Int)
    (h0 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h1 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h5 : (((19 : Int) > (jx + (0 : Int))) ∨ ((19 : Int) < (jx - a)) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n058_o6 (a b jx jy : Int)
    (h0 : (((14 : Int) > (jx + b)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h4 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n058_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h3 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n059_point (a b : Int)
    (h0 : (¬ (((15 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((15 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n059_empty (a b : Int)
    (h0 : (((((15 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((15 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (13 : Int)) ∧ ((2 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((15 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((15 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (8 : Int))) ∨ (((15 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (15 : Int)) ∧ ((2 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((8 : Int) + (5 : Int))))) ∨ ((((15 : Int) ≥ ((14 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((14 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((14 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (14 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((19 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((19 : Int) + (0 : Int))) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (5 : Int))) ∨ (((19 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (19 : Int)) ∧ ((2 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n059_o0 (a b jx jy : Int)
    (h0 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h5 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h6 : (((14 : Int) > (jx + a)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n059_o1 (a b jx jy : Int)
    (h0 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n059_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n059_o3 (a b jx jy : Int)
    (h0 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (b = (3 : Int)))
    (h4 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n059_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n059_o5 (a b jx jy : Int)
    (h0 : (((14 : Int) > (jx + (0 : Int))) ∨ ((14 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a = (5 : Int)))
    (h3 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (b = (3 : Int)))
    (h7 : (¬ ((((20 : Int) = jx) ∧ ((2 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int))))))
    (h8 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n059_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((14 : Int) > (jx + b)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h4 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n059_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h3 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n060_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((15 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((15 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n060_empty (a b : Int)
    (h0 : (((((15 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-13 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (23 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (24 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (10 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((15 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (13 : Int)) ∧ ((3 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((15 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((15 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (8 : Int))) ∨ (((15 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (15 : Int)) ∧ ((3 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((8 : Int) + (5 : Int))))) ∨ ((((15 : Int) ≥ ((14 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((14 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((14 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (14 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((19 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((19 : Int) + (0 : Int))) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ (((19 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (19 : Int)) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((20 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((20 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((20 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (20 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n060_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h4 : (((14 : Int) > (jx + a)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h5 : (((20 : Int) > (jx + a)) ∨ ((20 : Int) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h6 : ((jx < ((20 : Int) - (5 : Int))) ∨ (((20 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n060_o1 (a b jx jy : Int)
    (h0 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n060_o2 (a b jx jy : Int)
    (h0 : ((jx < ((20 : Int) - (5 : Int))) ∨ (((20 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h1 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h5 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n060_o3 (a b jx jy : Int)
    (h0 : (((20 : Int) > (jx + (0 : Int))) ∨ ((20 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h3 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n060_o4 (a b jx jy : Int)
    (h0 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n060_o5 (a b jx jy : Int)
    (h0 : ((jx < ((20 : Int) - (5 : Int))) ∨ (((20 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h3 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h4 : (((20 : Int) > (jx + (0 : Int))) ∨ ((20 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n060_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h2 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((14 : Int) > (jx + b)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n060_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h2 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jx < ((20 : Int) - (5 : Int))) ∨ (((20 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n061_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((14 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((14 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n061_empty (a b : Int)
    (h0 : (((((14 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((14 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (13 : Int)) ∧ ((2 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((15 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((15 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (8 : Int))) ∨ (((15 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (15 : Int)) ∧ ((2 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((8 : Int) + (5 : Int))))) ∨ ((((14 : Int) ≥ ((17 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((17 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((17 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (17 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n061_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((13 : Int) > (jx + a)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h4 : ((jx < ((17 : Int) - (3 : Int))) ∨ (((17 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((17 : Int) > (jx + a)) ∨ ((17 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n061_o1 (a b jx jy : Int)
    (h0 : ((jx < ((17 : Int) - (3 : Int))) ∨ (((17 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n061_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h5 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n061_o3 (a b jx jy : Int)
    (h0 : (((17 : Int) > (jx + (0 : Int))) ∨ ((17 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h1 : ((jx < ((17 : Int) - (3 : Int))) ∨ (((17 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n061_o4 (a b jx jy : Int)
    (h0 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h1 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((17 : Int) - (3 : Int))) ∨ (((17 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n061_o5 (a b jx jy : Int)
    (h0 : (((17 : Int) > (jx + (0 : Int))) ∨ ((17 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h3 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h4 : ((jx < ((17 : Int) - (3 : Int))) ∨ (((17 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n061_o6 (a b jx jy : Int)
    (h0 : (((17 : Int) > (jx + b)) ∨ ((17 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h1 : ((jx < ((17 : Int) - (3 : Int))) ∨ (((17 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h4 : (((13 : Int) > (jx + b)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n061_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h3 : (((17 : Int) > (jx + a)) ∨ ((17 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n062_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((14 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((14 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n062_empty (a b : Int)
    (h0 : (((((14 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((14 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (13 : Int)) ∧ ((2 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((15 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((15 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (8 : Int))) ∨ (((15 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (15 : Int)) ∧ ((2 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((8 : Int) + (5 : Int))))) ∨ ((((14 : Int) ≥ ((19 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((19 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((19 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (19 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n062_o0 (a b jx jy : Int)
    (h0 : (((13 : Int) > (jx + a)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h1 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (5 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((19 : Int) > (jx + a)) ∨ ((19 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n062_o1 (a b jx jy : Int)
    (h0 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h1 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n062_o2 (a b jx jy : Int)
    (h0 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h1 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n062_o3 (a b jx jy : Int)
    (h0 : (b = (3 : Int)))
    (h1 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h2 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (5 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h3 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h4 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n062_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h2 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n062_o5 (a b jx jy : Int)
    (h0 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h1 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((19 : Int) > (jx + (0 : Int))) ∨ ((19 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (5 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n062_o6 (a b jx jy : Int)
    (h0 : (((13 : Int) > (jx + b)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h1 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h2 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h3 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n062_o7 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (b = (3 : Int)))
    (h4 : (¬ ((((14 : Int) = jx) ∧ ((5 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b)))))
    (h5 : (a = (5 : Int)))
    (h6 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h7 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n063_point (a b : Int)
    (h0 : (¬ (((15 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((15 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n063_empty (a b : Int)
    (h0 : (((((15 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((15 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (13 : Int)) ∧ ((2 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((15 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((15 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (8 : Int))) ∨ (((15 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (15 : Int)) ∧ ((2 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((8 : Int) + (5 : Int))))) ∨ ((((15 : Int) ≥ ((19 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((19 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((19 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (19 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((14 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((14 : Int) + (5 : Int))) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (5 : Int))) ∨ (((14 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (14 : Int)) ∧ ((2 : Int) ≥ ((5 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n063_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h4 : (((19 : Int) > (jx + a)) ∨ ((19 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h5 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h6 : (((14 : Int) > (jx + a)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n063_o1 (a b jx jy : Int)
    (h0 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n063_o2 (a b jx jy : Int)
    (h0 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h4 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n063_o3 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((19 : Int) > (jx + (0 : Int))) ∨ ((19 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h4 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n063_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n063_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((14 : Int) > (jx + (0 : Int))) ∨ ((14 : Int) < (jx - a)) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h6 : (((19 : Int) > (jx + (0 : Int))) ∨ ((19 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n063_o6 (a b jx jy : Int)
    (h0 : (((14 : Int) > (jx + b)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h3 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n063_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h4 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n064_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((15 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((15 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n064_empty (a b : Int)
    (h0 : (((((15 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-13 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-1 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (0 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (23 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (24 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (10 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((15 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (13 : Int)) ∧ ((1 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((1 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((7 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (7 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((1 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((1 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((15 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((15 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (8 : Int))) ∨ (((15 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (15 : Int)) ∧ ((1 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((8 : Int) + (5 : Int))))) ∨ ((((15 : Int) ≥ ((14 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((14 : Int) + (5 : Int))) ∧ ((4 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (4 : Int))) ∨ (((14 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (14 : Int)) ∧ ((1 : Int) ≥ ((4 : Int) - (3 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n064_o0 (a b jx jy : Int)
    (h0 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (5 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h3 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h4 : (((14 : Int) > (jx + a)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n064_o1 (a b jx jy : Int)
    (h0 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n064_o2 (a b jx jy : Int)
    (h0 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h1 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h2 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n064_o3 (a b jx jy : Int)
    (h0 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b = (3 : Int)))
    (h3 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n064_o4 (a b jx jy : Int)
    (h0 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n064_o5 (a b jx jy : Int)
    (h0 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h1 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (5 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h2 : (¬ ((((20 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (3 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (((14 : Int) > (jx + (0 : Int))) ∨ ((14 : Int) < (jx - a)) ∨ (jy < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jy)))
    (h8 : (a = (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n064_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h2 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((14 : Int) > (jx + b)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n064_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h4 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n065_point (a b : Int)
    (h0 : (¬ (((15 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((15 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n065_empty (a b : Int)
    (h0 : (((((15 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((15 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (13 : Int)) ∧ ((2 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((15 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((15 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (8 : Int))) ∨ (((15 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (15 : Int)) ∧ ((2 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((8 : Int) + (5 : Int))))) ∨ ((((15 : Int) ≥ ((14 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((14 : Int) + (5 : Int))) ∧ ((4 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (4 : Int))) ∨ (((14 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (14 : Int)) ∧ ((2 : Int) ≥ ((4 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((20 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((20 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((20 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (20 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n065_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h3 : (((14 : Int) > (jx + a)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jy)))
    (h4 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h5 : ((jx < ((20 : Int) - (5 : Int))) ∨ (((20 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n065_o1 (a b jx jy : Int)
    (h0 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n065_o2 (a b jx jy : Int)
    (h0 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((20 : Int) - (5 : Int))) ∨ (((20 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n065_o3 (a b jx jy : Int)
    (h0 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((20 : Int) > (jx + (0 : Int))) ∨ ((20 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h4 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n065_o4 (a b jx jy : Int)
    (h0 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n065_o5 (a b jx jy : Int)
    (h0 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h1 : (((20 : Int) > (jx + (0 : Int))) ∨ ((20 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h2 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h3 : ((jx < ((20 : Int) - (5 : Int))) ∨ (((20 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n065_o6 (a b jx jy : Int)
    (h0 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((14 : Int) > (jx + b)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n065_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h3 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((20 : Int) - (5 : Int))) ∨ (((20 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n066_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((14 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((14 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n066_empty (a b : Int)
    (h0 : (((((14 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-13 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-1 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (0 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (23 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (24 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (10 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((14 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (13 : Int)) ∧ ((1 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((1 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((7 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (7 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((1 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((1 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((17 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((17 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (8 : Int))) ∨ (((17 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (17 : Int)) ∧ ((1 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((8 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n066_o0 (a b jx jy : Int)
    (h0 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h1 : (b = (3 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((13 : Int) > (jx + a)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (¬ ((((14 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : (a = (5 : Int)))
    (h7 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (5 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n066_o1 (a b jx jy : Int)
    (h0 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h2 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n066_o2 (a b jx jy : Int)
    (h0 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h1 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n066_o3 (a b jx jy : Int)
    (h0 : (a = (5 : Int)))
    (h1 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - b)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h4 : (¬ ((((17 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h6 : (b = (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (5 : Int)) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h9 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n066_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ ((((0 : Int) = a) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ ((((0 : Int) = b) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = b)))))))
    (h2 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n066_o5 (a b jx jy : Int)
    (h0 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (5 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (b = (3 : Int)))
    (h6 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h7 : (¬ ((((19 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int))))))
    (h8 : (a = (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n066_o6 (a b jx jy : Int)
    (h0 : (((13 : Int) > (jx + b)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h3 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h4 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (5 : Int)) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n066_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a = (5 : Int)))
    (h2 : (b = (3 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h5 : (¬ ((((14 : Int) = jx) ∧ ((4 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b)))))
    (h6 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n067_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((14 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((5 : Int) ≥ (0 : Int)) ∧ ((14 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((5 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n067_empty (a b : Int)
    (h0 : (((((14 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-13 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-12 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-1 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (0 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (23 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (24 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (1 : Int)) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (10 : Int)) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((14 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (13 : Int)) ∧ ((5 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((5 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((5 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((7 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (7 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((5 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((5 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((17 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((17 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (8 : Int))) ∨ (((17 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (17 : Int)) ∧ ((5 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((8 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((14 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((14 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ (((14 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (14 : Int)) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n067_o0 (a b jx jy : Int)
    (h0 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + b)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h1 : (((14 : Int) > jx) ∨ ((14 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + b)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((13 : Int) > (jx + a)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n067_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ (((b = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (((b = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((b = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - a)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n067_o2 (a b jx jy : Int)
    (h0 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h1 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - b)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (b = (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((14 : Int) > jx) ∨ ((14 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < (jy - b))))
    (h8 : (¬ ((((19 : Int) = jx) ∧ ((5 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((5 : Int) = a) ∧ ((3 : Int) = b)))))
    (h9 : (a = (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n067_o3 (a b jx jy : Int)
    (h0 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - b)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h1 : (((14 : Int) > jx) ∨ ((14 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h2 : (((17 : Int) > jx) ∨ ((17 : Int) < jx) ∨ ((jy + a) < ((8 : Int) - (0 : Int))) ∨ (((8 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h3 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + a)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (3 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n067_o4 (a b jx jy : Int)
    (h0 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - a)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ ((((0 : Int) = a) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ ((((0 : Int) = b) ∧ (b = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (b = b)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n067_o5 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + b)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a = (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h6 : (¬ ((((19 : Int) = jx) ∧ ((5 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int))))))
    (h7 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + b)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h8 : (b = (3 : Int)))
    (h9 : (((14 : Int) > jx) ∨ ((14 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n067_o6 (a b jx jy : Int)
    (h0 : (((14 : Int) > jx) ∨ ((14 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + a)))))
    (h3 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((13 : Int) > (jx + b)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n067_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (((13 : Int) > (jx + a)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h4 : (a = (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((14 : Int) > jx) ∨ ((14 : Int) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < (jy - b))))
    (h7 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - b)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n068_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((15 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((15 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n068_empty (a b : Int)
    (h0 : (((((15 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((15 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (13 : Int)) ∧ ((2 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((17 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((17 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (8 : Int))) ∨ (((17 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (17 : Int)) ∧ ((2 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((8 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((14 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((14 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((14 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (14 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((19 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((19 : Int) + (0 : Int))) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (5 : Int))) ∨ (((19 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (19 : Int)) ∧ ((2 : Int) ≥ ((5 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n068_o0 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((14 : Int) > (jx + a)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h4 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n068_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n068_o2 (a b jx jy : Int)
    (h0 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h3 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n068_o3 (a b jx jy : Int)
    (h0 : (((19 : Int) > (jx + (0 : Int))) ∨ ((19 : Int) < (jx - b)) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h1 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h2 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n068_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n068_o5 (a b jx jy : Int)
    (h0 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h1 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h2 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((19 : Int) > (jx + (0 : Int))) ∨ ((19 : Int) < (jx - a)) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h5 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n068_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((14 : Int) > (jx + b)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h3 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h4 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n068_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h4 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n069_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((15 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((15 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n069_empty (a b : Int)
    (h0 : (((((15 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((15 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (13 : Int)) ∧ ((2 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((17 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((17 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (8 : Int))) ∨ (((17 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (17 : Int)) ∧ ((2 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((8 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((14 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((14 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((14 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (14 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((19 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((19 : Int) + (0 : Int))) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (5 : Int))) ∨ (((19 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (19 : Int)) ∧ ((2 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n069_o0 (a b jx jy : Int)
    (h0 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h1 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h2 : (((14 : Int) > (jx + a)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n069_o1 (a b jx jy : Int)
    (h0 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n069_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h4 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n069_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h3 : (b = (3 : Int)))
    (h4 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n069_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h3 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n069_o5 (a b jx jy : Int)
    (h0 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h1 : (¬ ((((20 : Int) = jx) ∧ ((2 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : (b = (3 : Int)))
    (h3 : (((14 : Int) > (jx + (0 : Int))) ∨ ((14 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a = (5 : Int)))
    (h8 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n069_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h2 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((14 : Int) > (jx + b)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n069_o7 (a b jx jy : Int)
    (h0 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h2 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n070_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((15 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((15 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n070_empty (a b : Int)
    (h0 : (((((15 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-13 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (23 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (24 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (10 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((15 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (13 : Int)) ∧ ((3 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((3 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((3 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (7 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((3 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((3 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((17 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((17 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (8 : Int))) ∨ (((17 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (17 : Int)) ∧ ((3 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((8 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((14 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((14 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((14 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (14 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((19 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((19 : Int) + (0 : Int))) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ (((19 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (19 : Int)) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((20 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((20 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((20 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (20 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n070_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((14 : Int) > (jx + a)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h4 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h5 : ((jx < ((20 : Int) - (5 : Int))) ∨ (((20 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n070_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n070_o2 (a b jx jy : Int)
    (h0 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h5 : ((jx < ((20 : Int) - (5 : Int))) ∨ (((20 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n070_o3 (a b jx jy : Int)
    (h0 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h1 : (((20 : Int) > (jx + (0 : Int))) ∨ ((20 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n070_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h3 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n070_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h2 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h3 : (((20 : Int) > (jx + (0 : Int))) ∨ ((20 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + (3 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((20 : Int) - (5 : Int))) ∨ (((20 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n070_o6 (a b jx jy : Int)
    (h0 : (((14 : Int) > (jx + b)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h3 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n070_o7 (a b jx jy : Int)
    (h0 : ((jx < ((20 : Int) - (5 : Int))) ∨ (((20 : Int) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h1 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h2 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n071_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((14 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((14 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n071_empty (a b : Int)
    (h0 : (((((14 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((14 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (13 : Int)) ∧ ((2 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((17 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((17 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (8 : Int))) ∨ (((17 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (17 : Int)) ∧ ((2 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((8 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((17 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((17 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((17 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (17 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n071_o0 (a b jx jy : Int)
    (h0 : (((17 : Int) > (jx + a)) ∨ ((17 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h1 : (((13 : Int) > (jx + a)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((jx < ((17 : Int) - (3 : Int))) ∨ (((17 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n071_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h4 : ((jx < ((17 : Int) - (3 : Int))) ∨ (((17 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n071_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n071_o3 (a b jx jy : Int)
    (h0 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h1 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h2 : (((17 : Int) > (jx + (0 : Int))) ∨ ((17 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jx < ((17 : Int) - (3 : Int))) ∨ (((17 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n071_o4 (a b jx jy : Int)
    (h0 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < ((17 : Int) - (3 : Int))) ∨ (((17 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n071_o5 (a b jx jy : Int)
    (h0 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((17 : Int) > (jx + (0 : Int))) ∨ ((17 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((17 : Int) - (3 : Int))) ∨ (((17 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n071_o6 (a b jx jy : Int)
    (h0 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h1 : ((jx < ((17 : Int) - (3 : Int))) ∨ (((17 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((17 : Int) > (jx + b)) ∨ ((17 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h4 : (((13 : Int) > (jx + b)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n071_o7 (a b jx jy : Int)
    (h0 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((17 : Int) > (jx + a)) ∨ ((17 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (5 : Int)) < jy)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n072_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((14 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((14 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n072_empty (a b : Int)
    (h0 : (((((14 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((14 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((14 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (13 : Int)) ∧ ((2 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((11 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((11 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((14 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((12 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((14 : Int) ≥ ((17 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((17 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (8 : Int))) ∨ (((17 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (17 : Int)) ∧ ((2 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((8 : Int) + (3 : Int))))) ∨ ((((14 : Int) ≥ ((19 : Int) - (5 : Int))) ∧ ((14 : Int) ≤ ((19 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((19 : Int) ≤ (14 : Int)) ∧ ((14 : Int) ≤ (19 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n072_o0 (a b jx jy : Int)
    (h0 : (((13 : Int) > (jx + a)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h1 : (((19 : Int) > (jx + a)) ∨ ((19 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (5 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h4 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n072_o1 (a b jx jy : Int)
    (h0 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h4 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n072_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n072_o3 (a b jx jy : Int)
    (h0 : (b = (3 : Int)))
    (h1 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    (h4 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (5 : Int)) < jx) ∨ ((7 : Int) > (jy + a)) ∨ ((7 : Int) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n072_o4 (a b jx jy : Int)
    (h0 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((14 : Int) ≥ (jx - b)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + (0 : Int))) ∨ ((6 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n072_o5 (a b jx jy : Int)
    (h0 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (5 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((14 : Int) ≥ (jx - a)) ∧ ((14 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((19 : Int) > (jx + (0 : Int))) ∨ ((19 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    (h6 : (((13 : Int) > (jx + (0 : Int))) ∨ ((13 : Int) < (jx - a)) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n072_o6 (a b jx jy : Int)
    (h0 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h1 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((13 : Int) > (jx + b)) ∨ ((13 : Int) < (jx - (0 : Int))) ∨ (jy < ((6 : Int) - (5 : Int))) ∨ (((6 : Int) + (0 : Int)) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jx < ((13 : Int) - (0 : Int))) ∨ (((13 : Int) + (3 : Int)) < jx) ∨ ((6 : Int) > (jy + a)) ∨ ((6 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n072_o7 (a b jx jy : Int)
    (h0 : (¬ ((((14 : Int) = jx) ∧ ((5 : Int) = jy) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b)))))
    (h1 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h2 : (a = (5 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (b = (3 : Int)))
    (h5 : ((((14 : Int) ≥ (jx - (0 : Int))) ∧ ((14 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((14 : Int) ≥ jx) ∧ ((14 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n073_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((15 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((15 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n073_empty (a b : Int)
    (h0 : (((((15 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-13 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (0 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (23 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (24 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (1 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (10 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((15 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (13 : Int)) ∧ ((2 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((2 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((2 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (7 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((2 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((17 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((17 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (8 : Int))) ∨ (((17 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (17 : Int)) ∧ ((2 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((8 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((19 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((19 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((19 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (19 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((14 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((14 : Int) + (5 : Int))) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (5 : Int))) ∨ (((14 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (14 : Int)) ∧ ((2 : Int) ≥ ((5 : Int) - (3 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n073_o0 (a b jx jy : Int)
    (h0 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h1 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((14 : Int) > (jx + a)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n073_o1 (a b jx jy : Int)
    (h0 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n073_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h3 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n073_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h4 : (((19 : Int) > (jx + (0 : Int))) ∨ ((19 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n073_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n073_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((14 : Int) > (jx + (0 : Int))) ∨ ((14 : Int) < (jx - a)) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h2 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((19 : Int) > (jx + (0 : Int))) ∨ ((19 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + (3 : Int)) < jy)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n073_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((14 : Int) > (jx + b)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((5 : Int) - (3 : Int))) ∨ (((5 : Int) + (0 : Int)) < jy)))
    (h2 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h3 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n073_o7 (a b jx jy : Int)
    (h0 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((jx < ((19 : Int) - (5 : Int))) ∨ (((19 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n074_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((15 : Int) ≥ (-((20 : Int) * ((a + b) + (1 : Int))))) ∧ ((1 : Int) ≥ (0 : Int)) ∧ ((15 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))) ∧ ((1 : Int) ≤ ((20 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n074_empty (a b : Int)
    (h0 : (((((15 : Int) ≥ ((-13 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-13 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-13 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((-12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((-1 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (-1 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((0 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (0 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((23 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((23 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((23 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (23 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((24 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((24 : Int) + (5 : Int))) ∧ ((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int))) ∨ (((24 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (24 : Int)) ∧ ((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((1 : Int) + (5 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((10 : Int) - (3 : Int))) ∧ ((15 : Int) ≤ ((10 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (1 : Int))) ∨ (((10 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (10 : Int)) ∧ ((1 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + (5 : Int))))) ∨ ((((15 : Int) ≥ ((13 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((13 : Int) + (3 : Int))) ∧ ((6 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (6 : Int))) ∨ (((13 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (13 : Int)) ∧ ((1 : Int) ≥ ((6 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((6 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((11 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((11 : Int) + (3 : Int))) ∧ ((9 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (9 : Int))) ∨ (((11 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (11 : Int)) ∧ ((1 : Int) ≥ ((9 : Int) - (5 : Int))) ∧ ((1 : Int) ≤ ((9 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((12 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((12 : Int) + (5 : Int))) ∧ ((7 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (7 : Int))) ∨ (((12 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (12 : Int)) ∧ ((1 : Int) ≥ ((7 : Int) - (3 : Int))) ∧ ((1 : Int) ≤ ((7 : Int) + (0 : Int))))) ∨ ((((15 : Int) ≥ ((17 : Int) - (5 : Int))) ∧ ((15 : Int) ≤ ((17 : Int) + (0 : Int))) ∧ ((8 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (8 : Int))) ∨ (((17 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (17 : Int)) ∧ ((1 : Int) ≥ ((8 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((8 : Int) + (3 : Int))))) ∨ ((((15 : Int) ≥ ((14 : Int) - (0 : Int))) ∧ ((15 : Int) ≤ ((14 : Int) + (5 : Int))) ∧ ((4 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (4 : Int))) ∨ (((14 : Int) ≤ (15 : Int)) ∧ ((15 : Int) ≤ (14 : Int)) ∧ ((1 : Int) ≥ ((4 : Int) - (3 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n074_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h2 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((14 : Int) > (jx + a)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jy)))
    (h5 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (5 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n074_o1 (a b jx jy : Int)
    (h0 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n074_o2 (a b jx jy : Int)
    (h0 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ ((((0 : Int) = a) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ ((((0 : Int) = b) ∧ (a = (0 : Int))) ∨ (((0 : Int) = (0 : Int)) ∧ (a = b)))))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n074_o3 (a b jx jy : Int)
    (h0 : (b = (3 : Int)))
    (h1 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h2 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n074_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h3 : ((((15 : Int) ≥ (jx - b)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - a)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n074_o5 (a b jx jy : Int)
    (h0 : (((14 : Int) > (jx + (0 : Int))) ∨ ((14 : Int) < (jx - a)) ∨ (jy < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jy)))
    (h1 : ((jx < ((12 : Int) - (0 : Int))) ∨ (((12 : Int) + (5 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h2 : (a = (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((15 : Int) ≥ (jx - a)) ∧ ((15 : Int) ≤ (jx + (0 : Int))) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + b)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (¬ ((((20 : Int) = jx) ∧ ((1 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ ((3 : Int) = b) ∧ ((5 : Int) = a) ∧ ((0 : Int) = (0 : Int))))))
    (h7 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h8 : (b = (3 : Int)))
    (h9 : (a ≥ (5 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n074_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + b)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - (0 : Int))) ∧ ((1 : Int) ≤ (jy + a)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((14 : Int) > (jx + b)) ∨ ((14 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (3 : Int))) ∨ (((4 : Int) + (0 : Int)) < jy)))
    (h4 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_alternating_unequal_bar_long_fixed_5_3_pruned_n074_o7 (a b jx jy : Int)
    (h0 : (¬ (((jy = b) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (((a = a) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = a)))) ∨ ((jy = a) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (((a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((a = (0 : Int)) ∧ ((0 : Int) = b)))))))
    (h1 : ((((15 : Int) ≥ (jx - (0 : Int))) ∧ ((15 : Int) ≤ (jx + a)) ∧ ((1 : Int) ≥ jy) ∧ ((1 : Int) ≤ jy)) ∨ (((15 : Int) ≥ jx) ∧ ((15 : Int) ≤ jx) ∧ ((1 : Int) ≥ (jy - b)) ∧ ((1 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((14 : Int) - (0 : Int))) ∨ (((14 : Int) + (5 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

end LRegionArithmetic

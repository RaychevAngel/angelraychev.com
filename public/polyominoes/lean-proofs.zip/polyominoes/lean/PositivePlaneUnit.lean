import PositiveHierarchy

set_option maxRecDepth 10000
set_option maxHeartbeats 500000

namespace PositivePlaneUnit
open CrossUnits PolyominoFormal

def period (a b : Int) : Int := 2*(a+b+2)

def upTile (a b k l : Int) : Cross :=
  ⟨k*period a b+2*l+1,l,a,b,1,0⟩

def downTile (a b k l : Int) : Cross :=
  ⟨k*period a b+2*l+2*a+2,l,1,0,a,b⟩

def World (a b : Int) (t : Cross) : Prop :=
  ∃ k l, t=upTile a b k l ∨ t=downTile a b k l

/-- A cell is assigned to one of four disjoint types in a residue block.
The upright vertical cells belong to the preceding block. -/
def Info (a b k : Int) (t : Cross) (x y : Int) : Prop :=
  (t=upTile a b k y ∧ k*period a b≤x-2*y ∧ x-2*y≤k*period a b+a+1) ∨
  (t=downTile a b k y ∧ k*period a b+a+2≤x-2*y ∧ x-2*y≤k*period a b+2*a+3) ∨
  (∃ j, 1≤j ∧ j≤b ∧ t=upTile a b (k+1) (y-j) ∧
    x-2*y=k*period a b+period a b+1-2*j) ∨
  (∃ j, 1≤j ∧ j≤b ∧ t=downTile a b k (y+j) ∧
    x-2*y=k*period a b+2*a+2+2*j)

theorem up_contains (a b k l x y : Int) (ha : 1≤a) (hb : 1≤b) :
    Contains (upTile a b k l) x y ↔
    (y=l ∧ k*period a b≤x-2*y ∧ x-2*y≤k*period a b+a+1) ∨
    (1≤y-l ∧ y-l≤b ∧ x-2*y=k*period a b+1-2*(y-l)) := by
  unfold Contains upTile
  dsimp
  omega

theorem down_contains (a b k l x y : Int) (ha : 1≤a) (hb : 1≤b) :
    Contains (downTile a b k l) x y ↔
    (y=l ∧ k*period a b+a+2≤x-2*y ∧ x-2*y≤k*period a b+2*a+3) ∨
    (1≤l-y ∧ l-y≤b ∧ x-2*y=k*period a b+2*a+2+2*(l-y)) := by
  unfold Contains downTile
  dsimp
  omega

theorem info_bounds (a b k : Int) (ha : 1≤a) (hb : 1≤b)
    (t : Cross) (x y : Int) (hi : Info a b k t x y) :
    k*period a b≤x-2*y ∧ x-2*y<k*period a b+period a b := by
  rcases hi with ⟨ht,h0,h1⟩ | ⟨ht,h0,h1⟩ | ⟨j,h0,h1,ht,he⟩ | ⟨j,h0,h1,ht,he⟩
  all_goals unfold period at *
  all_goals omega

theorem info_contains (a b k : Int) (ha : 1≤a) (hb : 1≤b)
    (t : Cross) (x y : Int) (hi : Info a b k t x y) : Contains t x y := by
  rcases hi with ⟨rfl,h0,h1⟩ | ⟨rfl,h0,h1⟩ | ⟨j,h0,h1,rfl,he⟩ | ⟨j,h0,h1,rfl,he⟩
  · rw [up_contains a b k y x y ha hb]; exact Or.inl ⟨rfl,h0,h1⟩
  · rw [down_contains a b k y x y ha hb]; exact Or.inl ⟨rfl,h0,h1⟩
  · rw [up_contains a b (k+1) (y-j) x y ha hb]
    right
    simp only [Int.add_mul,Int.one_mul]
    omega
  · rw [down_contains a b k (y+j) x y ha hb]
    right
    omega

theorem contains_info (a b : Int) (ha : 1≤a) (hb : 1≤b)
    (t : Cross) (x y : Int) (ht : World a b t) (hit : Contains t x y) :
    ∃ k, Info a b k t x y := by
  rcases ht with ⟨k,l,rfl | rfl⟩
  · rw [up_contains a b k l x y ha hb] at hit
    rcases hit with ⟨rfl,h0,h1⟩ | ⟨h0,h1,he⟩
    · exact ⟨k,Or.inl ⟨rfl,h0,h1⟩⟩
    · refine ⟨k-1,Or.inr (Or.inr (Or.inl ⟨y-l,h0,h1,?_,?_⟩))⟩
      · have hkl : k-1+1=k := by omega
        have hyl : y-(y-l)=l := by omega
        rw [hkl,hyl]
      · simp only [Int.sub_mul,Int.one_mul]
        omega
  · rw [down_contains a b k l x y ha hb] at hit
    rcases hit with ⟨rfl,h0,h1⟩ | ⟨h0,h1,he⟩
    · exact ⟨k,Or.inr (Or.inl ⟨rfl,h0,h1⟩)⟩
    · refine ⟨k,Or.inr (Or.inr (Or.inr ⟨l-y,h0,h1,?_,he⟩))⟩
      have hyl : y+(l-y)=l := by omega
      rw [hyl]

theorem info_world (a b k : Int) (t : Cross) (x y : Int) (hi : Info a b k t x y) :
    World a b t := by
  rcases hi with ⟨rfl,_,_⟩ | ⟨rfl,_,_⟩ | ⟨j,_,_,rfl,_⟩ | ⟨j,_,_,rfl,_⟩
  · exact ⟨k,y,Or.inl rfl⟩
  · exact ⟨k,y,Or.inr rfl⟩
  · exact ⟨k+1,y-j,Or.inl rfl⟩
  · exact ⟨k,y+j,Or.inr rfl⟩

theorem info_unique (a b k : Int) (ha : 1≤a) (_hb : 1≤b)
    (t u : Cross) (x y : Int) (ht : Info a b k t x y) (hu : Info a b k u x y) : t=u := by
  rcases ht with ⟨rfl,ht0,ht1⟩ | ⟨rfl,ht0,ht1⟩ | ⟨j,hj0,hj1,rfl,hjt⟩ | ⟨j,hj0,hj1,rfl,hjt⟩
  all_goals rcases hu with ⟨rfl,hu0,hu1⟩ | ⟨rfl,hu0,hu1⟩ | ⟨i,hi0,hi1,rfl,hiu⟩ | ⟨i,hi0,hi1,rfl,hiu⟩
  all_goals apply same_eq
  all_goals dsimp [Same,upTile,downTile,period] at *
  all_goals try simp only [Int.add_mul,Int.one_mul,and_true,true_and]
  all_goals omega

theorem cover_info (a b x y : Int) (ha : 1≤a) (hb : 1≤b) :
    ∃ k t, Info a b k t x y := by
  let m := period a b
  let q := (x-2*y)/m
  let r := (x-2*y)%m
  have hm : 0<m := by dsimp [m,period]; omega
  have hr0 : 0≤r := Int.emod_nonneg _ (by omega)
  have hr1 : r<m := Int.emod_lt_of_pos _ hm
  have he : r+q*m=x-2*y := Int.emod_add_ediv_mul _ _
  have hma : m=2*(a+b+2) := rfl
  by_cases hrA : r≤a+1
  · refine ⟨q,upTile a b q y,Or.inl ⟨rfl,?_,?_⟩⟩
    all_goals dsimp [m,period] at *
    all_goals omega
  · by_cases hrB : r≤2*a+3
    · refine ⟨q,downTile a b q y,Or.inr (Or.inl ⟨rfl,?_,?_⟩)⟩
      all_goals dsimp [m,period] at *
      all_goals omega
    · have hp0 := Int.emod_nonneg r (show (2:Int)≠0 by omega)
      have hp1 := Int.emod_lt_of_pos r (show (0:Int)<2 by omega)
      have hep := Int.emod_add_ediv_mul r 2
      by_cases hp : r%2=0
      · let j := r/2-a-1
        refine ⟨q,downTile a b q (y+j),Or.inr (Or.inr (Or.inr ⟨j,?_,?_,rfl,?_⟩))⟩
        all_goals dsimp [m,period] at *
        all_goals dsimp [j]
        all_goals omega
      · let j := a+b+2-r/2
        refine ⟨q,upTile a b (q+1) (y-j),Or.inr (Or.inr (Or.inl ⟨j,?_,?_,rfl,?_⟩))⟩
        all_goals dsimp [m,period] at *
        all_goals dsimp [j]
        all_goals omega

def planeTiling (a b : Int) (ha : 1≤a) (hb : 1≤b) : Tiling a b 1 0 Plane where
  world := World a b
  copies := by
    rintro t ⟨k,l,rfl | rfl⟩
    all_goals simp [Copy,Arms,upTile,downTile]
  inside := by intros; trivial
  cover := by
    intro x y _
    obtain ⟨k,t,hi⟩ := cover_info a b x y ha hb
    exact ⟨t,info_world a b k t x y hi,info_contains a b k ha hb t x y hi⟩
  disjoint := by
    intro t u x y ht hu hit hiu
    obtain ⟨k,hk⟩ := contains_info a b ha hb t x y ht hit
    obtain ⟨l,hl⟩ := contains_info a b ha hb u x y hu hiu
    have hkb := info_bounds a b k ha hb t x y hk
    have hlb := info_bounds a b l ha hb u x y hl
    have hm : 0<period a b := by unfold period; omega
    have hkl := PositiveConstructions.block_unique (period a b) k l (x-2*y) hm
      hkb.1 hkb.2 hlb.1 hlb.2
    subst l
    exact info_unique a b k ha hb t u x y hk hl

theorem tiles_plane (a b : Int) (ha : 1≤a) (hb : 1≤b) : Tiles a b 1 0 Plane :=
  ⟨planeTiling a b ha hb⟩

#print axioms tiles_plane
end PositivePlaneUnit

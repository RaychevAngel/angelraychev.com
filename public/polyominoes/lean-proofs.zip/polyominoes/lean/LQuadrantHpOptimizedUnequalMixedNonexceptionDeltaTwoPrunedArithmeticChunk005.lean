import LQuadrantHpOptimizedUnequalMixedNonexceptionDeltaTwoPrunedArithmeticDefs
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace LRegionArithmetic

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n139_o6 (a b jx jy : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h2 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h3 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h4 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h5 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h8 : (((jx + b) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h9 : (fact_366edf150095_3212 a b jx jy))
    (h10 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h11 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h12 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h13 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h14 : (b ≥ (3 : Int)))
    (h15 : (a ≥ b))
    (h16 : (a > b))
    (h17 : (a = (b + (2 : Int))))
    (h18 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n139_o7 (a b jx jy : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_366edf150095_3211 a b jx jy))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (((jx + a) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n140_run_four (a b : Int)
    (h0 : (¬ (((2 : Int) + ((2 : Int) * b)) ≤ ((2 : Int) + ((2 : Int) * b)))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n140_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + ((2 : Int) * b)) - ((2 : Int) + ((2 : Int) * b))) < b)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n140_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n140_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5831 a b) ∨ (fact_366edf150095_5797 a b) ∨ (fact_366edf150095_6943 a b) ∨ (fact_366edf150095_6945 a b) ∨ (fact_366edf150095_5799 a b) ∨ (fact_366edf150095_5945 a b) ∨ (fact_366edf150095_5801 a b) ∨ (fact_366edf150095_6947 a b) ∨ (fact_366edf150095_6091 a b) ∨ (fact_366edf150095_5805 a b) ∨ (fact_366edf150095_5807 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ (((6 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((6 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_7007 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n140_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5830 a b) ∨ (fact_366edf150095_5796 a b) ∨ (fact_366edf150095_6942 a b) ∨ (fact_366edf150095_6944 a b) ∨ (fact_366edf150095_5798 a b) ∨ (fact_366edf150095_5944 a b) ∨ (fact_366edf150095_5800 a b) ∨ (fact_366edf150095_6946 a b) ∨ (fact_366edf150095_6090 a b) ∨ (fact_366edf150095_5803 a b) ∨ (fact_366edf150095_5806 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ (((6 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((6 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_7006 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n140_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ b))
    (h2 : (¬ ((((((2 : Int) + ((2 : Int) * b)) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((fact_366edf150095_7834 a b) ∨ (fact_366edf150095_7833 a b))) ∨ (((((2 : Int) + ((2 : Int) * b)) + (2 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (fact_366edf150095_7834 a b) ∧ (fact_366edf150095_7833 a b)) ∨ ((((2 : Int) + ((2 : Int) * b)) + (4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∨ ((((2 : Int) + ((2 : Int) * b)) = (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ (fact_366edf150095_7834 a b) ∧ (fact_366edf150095_7833 a b) ∧ (((fact_366edf150095_6144 a b) ∨ (fact_366edf150095_6072 a b) ∨ (fact_366edf150095_7004 a b) ∨ (fact_366edf150095_7012 a b) ∨ (fact_366edf150095_6076 a b) ∨ (fact_366edf150095_6422 a b) ∨ (fact_366edf150095_6080 a b) ∨ (fact_366edf150095_7016 a b) ∨ (fact_366edf150095_6599 a b) ∨ (fact_366edf150095_6097 a b) ∨ (fact_366edf150095_6106 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + a))) ∨ (((6 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((6 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_7182 a b)) ∨ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6597 a b) ∨ (fact_366edf150095_6092 a b) ∨ (fact_366edf150095_6103 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + a))) ∨ (((6 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((6 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_7180 a b)))) ∨ ((fact_366edf150095_7834 a b) ∧ (fact_366edf150095_7833 a b) ∧ ((fact_366edf150095_6144 a b) ∨ (fact_366edf150095_6072 a b) ∨ (fact_366edf150095_7004 a b) ∨ (fact_366edf150095_7012 a b) ∨ (fact_366edf150095_6076 a b) ∨ (fact_366edf150095_6422 a b) ∨ (fact_366edf150095_6080 a b) ∨ (fact_366edf150095_7016 a b) ∨ (fact_366edf150095_6599 a b) ∨ (fact_366edf150095_6097 a b) ∨ (fact_366edf150095_6106 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + a))) ∨ (((6 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((6 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_7182 a b)) ∧ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6597 a b) ∨ (fact_366edf150095_6092 a b) ∨ (fact_366edf150095_6103 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + a))) ∨ (((6 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((6 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_7180 a b))))))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n140_run_empty (a b run_x : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (((2 : Int) + ((2 : Int) * b)) ≤ run_x))
    (h2 : ((((6 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + a) - a)) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h3 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2319 a b run_x) ∨ (fact_366edf150095_3537 a b run_x) ∨ (fact_366edf150095_2995 a b run_x) ∨ (fact_366edf150095_2330 a b run_x) ∨ (fact_366edf150095_2339 a b run_x) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_4212 a b run_x)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n140_run_floor (a b run_x : Int)
    (h0 : (((2 : Int) + ((2 : Int) * b)) ≤ run_x))
    (h1 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3315 a b run_x) ∨ (fact_366edf150095_5230 a b run_x) ∨ (fact_366edf150095_3578 a b run_x) ∨ (fact_366edf150095_3330 a b run_x) ∨ (fact_366edf150095_3340 a b run_x) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_5846 a b run_x))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((6 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + a) - a)) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n141_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_366edf150095_2264 a b))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((6 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + b) - b)) ∨ ((5 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n141_empty (a b : Int)
    (h0 : ((((6 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + b) - b)) ∨ ((5 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h1 : ((fact_366edf150095_4213 a b) ∨ (fact_366edf150095_4198 a b) ∨ (fact_366edf150095_6127 a b) ∨ (fact_366edf150095_6133 a b) ∨ (fact_366edf150095_4201 a b) ∨ (fact_366edf150095_5114 a b) ∨ (fact_366edf150095_4204 a b) ∨ (fact_366edf150095_6136 a b) ∨ (fact_366edf150095_5205 a b) ∨ (fact_366edf150095_4206 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ (((-1 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≥ ((-1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + a)))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ (((-1 : Int) + ((2 : Int) * b)) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ (((6 : Int) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ ((6 : Int) ≥ ((-1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - a) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ (((-1 : Int) + ((2 : Int) * b)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ (((-1 : Int) + ((2 : Int) * b)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (0 : Int)))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n141_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h2 : ((((6 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + b) - b)) ∨ ((5 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h3 : (fact_366edf150095_3238 a b jx jy))
    (h4 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h7 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h8 : (((jx + a) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h9 : (((jx + a) < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h10 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h11 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h12 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h13 : (a ≥ (5 : Int)))
    (h14 : (a ≥ b))
    (h15 : (a > b))
    (h16 : (a = (b + (2 : Int))))
    (h17 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n141_o1 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((6 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + b) - b)) ∨ ((5 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h3 : (fact_366edf150095_2953 a b jy))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jx < (((1 : Int) + ((2 : Int) * b)) - a)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < (jy - a))))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (fact_366edf150095_3241 a b jx jy))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n141_o2 (a b jx jy : Int)
    (h0 : ((((6 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + b) - b)) ∨ ((5 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (fact_366edf150095_3243 a b jx jy))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (((jx + (0 : Int)) < (((1 : Int) + ((2 : Int) * b)) - a)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < (jx - a)) ∨ (jy < ((3 : Int) + b)) ∨ (((3 : Int) + b) < jy)))
    (h5 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n141_o3 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < (jx - b)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h2 : (((jx + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jx - b)) ∨ (jy < (((3 : Int) + b) - b)) ∨ ((((3 : Int) + b) + (0 : Int)) < jy)))
    (h3 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : ((((6 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + b) - b)) ∨ ((5 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h7 : ((jx < (((1 : Int) + ((2 : Int) * b)) - a)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((jy + a) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (fact_366edf150095_3244 a b jx jy))
    (h10 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    (h14 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n141_o4 (a b jx jy : Int)
    (h0 : (fact_366edf150095_2952 a b jy))
    (h1 : ((((6 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + b) - b)) ∨ ((5 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < (((1 : Int) + ((2 : Int) * b)) - a)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < (jy - a))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_366edf150095_3245 a b jx jy))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n141_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h2 : (fact_366edf150095_3242 a b jx jy))
    (h3 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h4 : (((jx + (0 : Int)) < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h5 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h6 : ((jx < (((1 : Int) + ((2 : Int) * b)) - a)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((jy + b) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h7 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h8 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h9 : (b ≥ (3 : Int)))
    (h10 : ((((6 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + b) - b)) ∨ ((5 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h11 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h12 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h13 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h14 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < (jx - a)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h15 : (a ≥ b))
    (h16 : (a > b))
    (h17 : (a = (b + (2 : Int))))
    (h18 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n141_o6 (a b jx jy : Int)
    (h0 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h3 : (((jx + b) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + b) - b)) ∨ ((((3 : Int) + b) + (0 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : ((((6 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + b) - b)) ∨ ((5 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (fact_366edf150095_3240 a b jx jy))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n141_o7 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_366edf150095_3239 a b jx jy))
    (h2 : ((((6 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + b) - b)) ∨ ((5 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h3 : (((jx + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + b) - b)) ∨ ((((3 : Int) + b) + (0 : Int)) < jy)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n142_point (a b : Int)
    (h0 : ((((6 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + a) - a)) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (fact_366edf150095_2264 a b))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n142_empty (a b : Int)
    (h0 : ((fact_366edf150095_4213 a b) ∨ (fact_366edf150095_4198 a b) ∨ (fact_366edf150095_6127 a b) ∨ (fact_366edf150095_6133 a b) ∨ (fact_366edf150095_4201 a b) ∨ (fact_366edf150095_5114 a b) ∨ (fact_366edf150095_4204 a b) ∨ (fact_366edf150095_6136 a b) ∨ (fact_366edf150095_5205 a b) ∨ (fact_366edf150095_4206 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ (((-1 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≥ ((-1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + a)))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ (((-1 : Int) + ((2 : Int) * b)) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ (((6 : Int) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ ((6 : Int) ≥ ((-1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ (((-1 : Int) + ((2 : Int) * b)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ (((-1 : Int) + ((2 : Int) * b)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : ((((6 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + a) - a)) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n142_o0 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (((jx + a) < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h2 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h3 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h4 : (((jx + a) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((6 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + a) - a)) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h7 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h8 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h9 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h10 : (fact_366edf150095_3238 a b jx jy))
    (h11 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h12 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h13 : (b ≥ (3 : Int)))
    (h14 : (a ≥ b))
    (h15 : (a > b))
    (h16 : (a = (b + (2 : Int))))
    (h17 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n142_o1 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_366edf150095_3241 a b jx jy))
    (h3 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : ((((6 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + a) - a)) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h6 : (((jx + b) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n142_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (fact_366edf150095_3243 a b jx jy))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (¬ (((jx = ((-1 : Int) + ((2 : Int) * b))) ∧ (jy = ((3 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h4 : ((((6 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + a) - a)) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n142_o3 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((6 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + a) - a)) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h3 : (fact_366edf150095_3244 a b jx jy))
    (h4 : (((jx + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < (jx - b)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n142_o4 (a b jx jy : Int)
    (h0 : ((((6 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + a) - a)) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h1 : (fact_366edf150095_3245 a b jx jy))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((jx + (0 : Int)) < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < (jx - b)) ∨ (jy < ((3 : Int) + a)) ∨ (((3 : Int) + a) < jy)))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n142_o5 (a b jx jy : Int)
    (h0 : ((((6 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + a) - a)) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h1 : (fact_366edf150095_3242 a b jx jy))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < (jx - a)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h4 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((jx + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n142_o6 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((((6 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + a) - a)) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h4 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (((jx + b) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h10 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h11 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h12 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h13 : (((jx + b) < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h14 : (fact_366edf150095_3240 a b jx jy))
    (h15 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h16 : (a ≥ b))
    (h17 : (a > b))
    (h18 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n142_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((6 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + a) - a)) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h5 : (((jx + a) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : (fact_366edf150095_3239 a b jx jy))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n143_run_four (a b : Int)
    (h0 : (((5 : Int) < (((-1 : Int) + ((2 : Int) * b)) - a)) ∨ ((5 : Int) > (((-1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < ((4 : Int) - (0 : Int)))))
    (h1 : (¬ (((5 : Int) + a) ≤ ((-2 : Int) + ((2 : Int) * b)))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n143_run_short (a b : Int)
    (h0 : (¬ ((((-2 : Int) + ((2 : Int) * b)) - ((5 : Int) + a)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n143_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n143_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4128 a b) ∨ (fact_366edf150095_3723 a b) ∨ (fact_366edf150095_5874 a b) ∨ (fact_366edf150095_5957 a b) ∨ (fact_366edf150095_3804 a b) ∨ (fact_366edf150095_4237 a b) ∨ (fact_366edf150095_3876 a b) ∨ (fact_366edf150095_6029 a b) ∨ (fact_366edf150095_4778 a b) ∨ (fact_366edf150095_3974 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + a) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((5 : Int) ≥ (((5 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + a)))) ∨ (((((6 : Int) - (0 : Int)) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + a) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ (((6 : Int) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((6 : Int) ≥ (((5 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - b) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + a) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + a) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((((-1 : Int) + ((2 : Int) * b)) - a) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + a) - (1 : Int)) ≤ (((-1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b))) ∨ ((((-1 : Int) + ((2 : Int) * b)) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + a) - (1 : Int)) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n143_run_right (a b : Int)
    (h0 : (¬ ((((((-1 : Int) - a) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((0 : Int) ≥ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((1 : Int) ≥ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((2 : Int) ≥ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - b) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((4 : Int) ≥ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((5 : Int) ≥ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + a)))) ∨ (((((6 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ (((6 : Int) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((6 : Int) ≥ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - b) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((((-1 : Int) + ((2 : Int) * b)) - a) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((-1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b))) ∨ ((((-1 : Int) + ((2 : Int) * b)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n143_run_tall (a b : Int)
    (h0 : (((5 : Int) < (((-1 : Int) + ((2 : Int) * b)) - a)) ∨ ((5 : Int) > (((-1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < ((4 : Int) - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (¬ ((((((5 : Int) + a) + (3 : Int)) ≤ ((-2 : Int) + ((2 : Int) * b))) ∧ ((fact_366edf150095_7806 a b) ∨ ((fact_366edf150095_6205 a b) ∨ (fact_366edf150095_6149 a b) ∨ (fact_366edf150095_7049 a b) ∨ (fact_366edf150095_7053 a b) ∨ (fact_366edf150095_6153 a b) ∨ (fact_366edf150095_6635 a b) ∨ (fact_366edf150095_6159 a b) ∨ (fact_366edf150095_7055 a b) ∨ (fact_366edf150095_6701 a b) ∨ (fact_366edf150095_6176 a b) ∨ (fact_366edf150095_6184 a b) ∨ (fact_366edf150095_6192 a b) ∨ (fact_366edf150095_7229 a b) ∨ (fact_366edf150095_7235 a b)))) ∨ (((((5 : Int) + a) + (2 : Int)) ≤ ((-2 : Int) + ((2 : Int) * b))) ∧ (fact_366edf150095_7806 a b) ∧ ((fact_366edf150095_6205 a b) ∨ (fact_366edf150095_6149 a b) ∨ (fact_366edf150095_7049 a b) ∨ (fact_366edf150095_7053 a b) ∨ (fact_366edf150095_6153 a b) ∨ (fact_366edf150095_6635 a b) ∨ (fact_366edf150095_6159 a b) ∨ (fact_366edf150095_7055 a b) ∨ (fact_366edf150095_6701 a b) ∨ (fact_366edf150095_6176 a b) ∨ (fact_366edf150095_6184 a b) ∨ (fact_366edf150095_6192 a b) ∨ (fact_366edf150095_7229 a b) ∨ (fact_366edf150095_7235 a b))) ∨ ((((5 : Int) + a) + (4 : Int)) ≤ ((-2 : Int) + ((2 : Int) * b))) ∨ ((((-2 : Int) + ((2 : Int) * b)) = (((5 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7806 a b) ∧ ((fact_366edf150095_6205 a b) ∨ (fact_366edf150095_6149 a b) ∨ (fact_366edf150095_7049 a b) ∨ (fact_366edf150095_7053 a b) ∨ (fact_366edf150095_6153 a b) ∨ (fact_366edf150095_6635 a b) ∨ (fact_366edf150095_6159 a b) ∨ (fact_366edf150095_7055 a b) ∨ (fact_366edf150095_6701 a b) ∨ (fact_366edf150095_6176 a b) ∨ (fact_366edf150095_6184 a b) ∨ (fact_366edf150095_6192 a b) ∨ (fact_366edf150095_7229 a b) ∨ (fact_366edf150095_7235 a b)) ∧ (((fact_366edf150095_5149 a b) ∨ (fact_366edf150095_4443 a b) ∨ (fact_366edf150095_6368 a b) ∨ (fact_366edf150095_6456 a b) ∨ (fact_366edf150095_4527 a b) ∨ (fact_366edf150095_5277 a b) ∨ (fact_366edf150095_4604 a b) ∨ (fact_366edf150095_6529 a b) ∨ (fact_366edf150095_5542 a b) ∨ (fact_366edf150095_4860 a b) ∨ (fact_366edf150095_4977 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + a) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + a))) ∨ (((6 : Int) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((6 : Int) ≥ (((5 : Int) + a) - (1 : Int))) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_6875 a b) ∨ (fact_366edf150095_6879 a b)) ∨ ((fact_366edf150095_6204 a b) ∨ (fact_366edf150095_6148 a b) ∨ (fact_366edf150095_7048 a b) ∨ (fact_366edf150095_7052 a b) ∨ (fact_366edf150095_6152 a b) ∨ (fact_366edf150095_6634 a b) ∨ (fact_366edf150095_6158 a b) ∨ (fact_366edf150095_7054 a b) ∨ (fact_366edf150095_6700 a b) ∨ (fact_366edf150095_6175 a b) ∨ (fact_366edf150095_6183 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + a))) ∨ (((6 : Int) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((6 : Int) ≥ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_7228 a b) ∨ (fact_366edf150095_7234 a b)))) ∨ ((fact_366edf150095_7806 a b) ∧ ((fact_366edf150095_6205 a b) ∨ (fact_366edf150095_6149 a b) ∨ (fact_366edf150095_7049 a b) ∨ (fact_366edf150095_7053 a b) ∨ (fact_366edf150095_6153 a b) ∨ (fact_366edf150095_6635 a b) ∨ (fact_366edf150095_6159 a b) ∨ (fact_366edf150095_7055 a b) ∨ (fact_366edf150095_6701 a b) ∨ (fact_366edf150095_6176 a b) ∨ (fact_366edf150095_6184 a b) ∨ (fact_366edf150095_6192 a b) ∨ (fact_366edf150095_7229 a b) ∨ (fact_366edf150095_7235 a b)) ∧ ((fact_366edf150095_5149 a b) ∨ (fact_366edf150095_4443 a b) ∨ (fact_366edf150095_6368 a b) ∨ (fact_366edf150095_6456 a b) ∨ (fact_366edf150095_4527 a b) ∨ (fact_366edf150095_5277 a b) ∨ (fact_366edf150095_4604 a b) ∨ (fact_366edf150095_6529 a b) ∨ (fact_366edf150095_5542 a b) ∨ (fact_366edf150095_4860 a b) ∨ (fact_366edf150095_4977 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + a) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + a))) ∨ (((6 : Int) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((6 : Int) ≥ (((5 : Int) + a) - (1 : Int))) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_6875 a b) ∨ (fact_366edf150095_6879 a b)) ∧ ((fact_366edf150095_6204 a b) ∨ (fact_366edf150095_6148 a b) ∨ (fact_366edf150095_7048 a b) ∨ (fact_366edf150095_7052 a b) ∨ (fact_366edf150095_6152 a b) ∨ (fact_366edf150095_6634 a b) ∨ (fact_366edf150095_6158 a b) ∨ (fact_366edf150095_7054 a b) ∨ (fact_366edf150095_6700 a b) ∨ (fact_366edf150095_6175 a b) ∨ (fact_366edf150095_6183 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + a))) ∨ (((6 : Int) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((6 : Int) ≥ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_7228 a b) ∨ (fact_366edf150095_7234 a b))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n143_run_empty (a b run_x : Int)
    (h0 : (((5 : Int) + a) ≤ run_x))
    (h1 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2319 a b run_x) ∨ (fact_366edf150095_3537 a b run_x) ∨ (fact_366edf150095_2995 a b run_x) ∨ (fact_366edf150095_2330 a b run_x) ∨ (fact_366edf150095_2339 a b run_x) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - b) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((((-1 : Int) + ((2 : Int) * b)) - a) ≤ run_x) ∧ (run_x ≤ (((-1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b))) ∨ ((((-1 : Int) + ((2 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (0 : Int)))))))
    (h2 : ((((5 : Int) + b) < ((-1 : Int) + ((2 : Int) * b))) ∨ (((-1 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ ((4 : Int) < (((3 : Int) + b) - b)) ∨ ((4 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((6 : Int) + a) < ((-1 : Int) + ((2 : Int) * b))) ∨ (((-1 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + b) - b)) ∨ ((5 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h6 : (run_x ≤ ((-2 : Int) + ((2 : Int) * b))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n143_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3315 a b run_x) ∨ (fact_366edf150095_5230 a b run_x) ∨ (fact_366edf150095_3578 a b run_x) ∨ (fact_366edf150095_3330 a b run_x) ∨ (fact_366edf150095_3340 a b run_x) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((5 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - b) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((((3 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((((-1 : Int) + ((2 : Int) * b)) - a) ≤ run_x) ∧ (run_x ≤ (((-1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ ((((-1 : Int) + ((2 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ ((((3 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h1 : ((((5 : Int) + b) < ((-1 : Int) + ((2 : Int) * b))) ∨ (((-1 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ ((4 : Int) < (((3 : Int) + b) - b)) ∨ ((4 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((6 : Int) + a) < ((-1 : Int) + ((2 : Int) * b))) ∨ (((-1 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + b) - b)) ∨ ((5 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h4 : (run_x ≤ ((-2 : Int) + ((2 : Int) * b))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((5 : Int) + a) ≤ run_x))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n144_point (a b : Int)
    (h0 : (¬ (((7 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((5 : Int) ≥ (0 : Int)) ∧ ((7 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((5 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n144_empty (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((((7 : Int) ≥ ((-1 : Int) - a)) ∧ ((7 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (-1 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ ((((7 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (0 : Int)) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ ((((7 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((7 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((7 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((7 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ ((((7 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((7 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int))) ∨ (((7 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((7 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + b)))) ∨ ((((7 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (1 : Int)) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + b)))) ∨ ((((7 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((7 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int))) ∨ (((7 : Int) ≥ ((2 : Int) * a)) ∧ ((7 : Int) ≤ ((2 : Int) * a)) ∧ ((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + a)))) ∨ ((((7 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + a)))) ∨ ((((7 : Int) ≥ (((3 : Int) + ((2 : Int) * b)) - b)) ∧ ((7 : Int) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int))) ∨ (((7 : Int) ≥ ((3 : Int) + ((2 : Int) * b))) ∧ ((7 : Int) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + a)))) ∨ ((((7 : Int) ≥ ((3 : Int) - b)) ∧ ((7 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((5 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((7 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (4 : Int)) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)))) ∨ ((((7 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)))) ∨ ((((7 : Int) ≥ ((6 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((6 : Int) + b)) ∧ ((5 : Int) ≥ ((5 : Int) + a)) ∧ ((5 : Int) ≤ ((5 : Int) + a))) ∨ (((6 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (6 : Int)) ∧ ((5 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((5 : Int) + a) + (0 : Int)))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n144_o0 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((6 : Int) > (jx + a)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + a)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + b)))))
    (h6 : (¬ ((((7 : Int) = jx) ∧ ((5 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n144_o1 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + b)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - a)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (((jx + b) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < (jx - (0 : Int))) ∨ (jy < ((5 : Int) + a)) ∨ (((5 : Int) + a) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n144_o2 (a b jx jy : Int)
    (h0 : (fact_366edf150095_2954 a b jy))
    (h1 : ((jx < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((jx < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - b))))
    (h5 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - a)) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h8 : ((((7 : Int) ≥ (jx - a)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - b)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n144_o3 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : ((((7 : Int) ≥ (jx - b)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + a)))))
    (h3 : (¬ (((jx = ((7 : Int) + b)) ∧ ((5 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n144_o4 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((((7 : Int) ≥ (jx - b)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - a)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n144_o5 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (¬ (((jx = ((7 : Int) + a)) ∧ ((5 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - a)) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h6 : ((((7 : Int) ≥ (jx - a)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + b)))))
    (h7 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h8 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n144_o6 (a b jx jy : Int)
    (h0 : (((6 : Int) > (jx + b)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h3 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((jy + a) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < (jy - (0 : Int)))))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + b)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - (0 : Int))) ∧ ((5 : Int) ≤ (jy + a)))))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n144_o7 (a b jx jy : Int)
    (h0 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + a)) ∧ ((5 : Int) ≥ jy) ∧ ((5 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((5 : Int) ≥ (jy - b)) ∧ ((5 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h4 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (¬ ((((7 : Int) = jx) ∧ (jy = ((5 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n145_point (a b : Int)
    (h0 : (fact_366edf150095_2138 a b))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n145_empty (a b : Int)
    (h0 : ((((-1 : Int) + (0 : Int)) < (((1 : Int) + ((2 : Int) * a)) - a)) ∨ ((((1 : Int) + ((2 : Int) * a)) + (0 : Int)) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : (a > b))
    (h3 : ((fact_366edf150095_4132 a b) ∨ (fact_366edf150095_3727 a b) ∨ (fact_366edf150095_5878 a b) ∨ (fact_366edf150095_5961 a b) ∨ (fact_366edf150095_3808 a b) ∨ (fact_366edf150095_4241 a b) ∨ (fact_366edf150095_3878 a b) ∨ (fact_366edf150095_6031 a b) ∨ (fact_366edf150095_4779 a b) ∨ (fact_366edf150095_3977 a b) ∨ (fact_366edf150095_4029 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((6 : Int) + b)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a))) ∨ (((6 : Int) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((6 : Int) ≥ ((1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ (((7 : Int) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((7 : Int) ≥ ((1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + b))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n145_o0 (a b jx jy : Int)
    (h0 : (((jx + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : (fact_366edf150095_3210 a b jx jy))
    (h5 : (((jx + a) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n145_o1 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (((jx + b) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h4 : (fact_366edf150095_3213 a b jx jy))
    (h5 : ((((3 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h6 : (¬ (((jx = ((1 : Int) + ((2 : Int) * b))) ∧ (jy = ((3 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n145_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (¬ (((jx = ((1 : Int) + ((2 : Int) * b))) ∧ (jy = ((3 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h6 : (fact_366edf150095_3215 a b jx jy))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n145_o3 (a b jx jy : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : (((jx + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h2 : (fact_366edf150095_3216 a b jx jy))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h8 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < (jx - b)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n145_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((jx = ((1 : Int) + ((2 : Int) * b))) ∧ (jy = ((3 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : (fact_366edf150095_3217 a b jx jy))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n145_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < (jx - a)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h3 : (((jx + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h4 : (fact_366edf150095_3214 a b jx jy))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((((3 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n145_o6 (a b jx jy : Int)
    (h0 : (((jx + b) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h1 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h2 : (((jx + b) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h5 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h6 : (fact_366edf150095_3212 a b jx jy))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h9 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h10 : ((((3 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h11 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h12 : (a = (b + (2 : Int))))
    (h13 : (a ≥ (5 : Int)))
    (h14 : (b ≥ (3 : Int)))
    (h15 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h16 : (a ≥ b))
    (h17 : (a > b))
    (h18 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n145_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_366edf150095_3211 a b jx jy))
    (h4 : (((jx + a) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((((3 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n146_run_four (a b : Int)
    (h0 : (¬ (((2 : Int) + ((2 : Int) * b)) ≤ ((2 : Int) + ((2 : Int) * b)))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n146_run_short (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((((2 : Int) + ((2 : Int) * b)) - ((2 : Int) + ((2 : Int) * b))) < b)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n146_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n146_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_5831 a b) ∨ (fact_366edf150095_5797 a b) ∨ (fact_366edf150095_6943 a b) ∨ (fact_366edf150095_6945 a b) ∨ (fact_366edf150095_5799 a b) ∨ (fact_366edf150095_5945 a b) ∨ (fact_366edf150095_5801 a b) ∨ (fact_366edf150095_6947 a b) ∨ (fact_366edf150095_6091 a b) ∨ (fact_366edf150095_5805 a b) ∨ (fact_366edf150095_5807 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a))) ∨ (((6 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((6 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ (((7 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((7 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_7007 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n146_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5830 a b) ∨ (fact_366edf150095_5796 a b) ∨ (fact_366edf150095_6942 a b) ∨ (fact_366edf150095_6944 a b) ∨ (fact_366edf150095_5798 a b) ∨ (fact_366edf150095_5944 a b) ∨ (fact_366edf150095_5800 a b) ∨ (fact_366edf150095_6946 a b) ∨ (fact_366edf150095_6090 a b) ∨ (fact_366edf150095_5803 a b) ∨ (fact_366edf150095_5806 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a))) ∨ (((6 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((6 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ (((7 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((7 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_7006 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n146_run_tall (a b : Int)
    (h0 : (¬ ((((((2 : Int) + ((2 : Int) * b)) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((fact_366edf150095_6145 a b) ∨ (fact_366edf150095_6073 a b) ∨ (fact_366edf150095_7005 a b) ∨ (fact_366edf150095_7013 a b) ∨ (fact_366edf150095_6077 a b) ∨ (fact_366edf150095_6423 a b) ∨ (fact_366edf150095_6081 a b) ∨ (fact_366edf150095_7017 a b) ∨ (fact_366edf150095_6600 a b) ∨ (fact_366edf150095_6098 a b) ∨ (fact_366edf150095_6107 a b) ∨ (fact_366edf150095_6629 a b) ∨ (fact_366edf150095_6116 a b) ∨ (fact_366edf150095_7183 a b)) ∨ ((fact_366edf150095_6143 a b) ∨ (fact_366edf150095_6071 a b) ∨ (fact_366edf150095_7003 a b) ∨ (fact_366edf150095_7011 a b) ∨ (fact_366edf150095_6075 a b) ∨ (fact_366edf150095_6421 a b) ∨ (fact_366edf150095_6079 a b) ∨ (fact_366edf150095_7015 a b) ∨ (fact_366edf150095_6598 a b) ∨ (fact_366edf150095_6093 a b) ∨ (fact_366edf150095_6104 a b) ∨ (fact_366edf150095_6627 a b) ∨ (fact_366edf150095_6115 a b) ∨ (fact_366edf150095_7181 a b)))) ∨ (((((2 : Int) + ((2 : Int) * b)) + (2 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((fact_366edf150095_6145 a b) ∨ (fact_366edf150095_6073 a b) ∨ (fact_366edf150095_7005 a b) ∨ (fact_366edf150095_7013 a b) ∨ (fact_366edf150095_6077 a b) ∨ (fact_366edf150095_6423 a b) ∨ (fact_366edf150095_6081 a b) ∨ (fact_366edf150095_7017 a b) ∨ (fact_366edf150095_6600 a b) ∨ (fact_366edf150095_6098 a b) ∨ (fact_366edf150095_6107 a b) ∨ (fact_366edf150095_6629 a b) ∨ (fact_366edf150095_6116 a b) ∨ (fact_366edf150095_7183 a b)) ∧ ((fact_366edf150095_6143 a b) ∨ (fact_366edf150095_6071 a b) ∨ (fact_366edf150095_7003 a b) ∨ (fact_366edf150095_7011 a b) ∨ (fact_366edf150095_6075 a b) ∨ (fact_366edf150095_6421 a b) ∨ (fact_366edf150095_6079 a b) ∨ (fact_366edf150095_7015 a b) ∨ (fact_366edf150095_6598 a b) ∨ (fact_366edf150095_6093 a b) ∨ (fact_366edf150095_6104 a b) ∨ (fact_366edf150095_6627 a b) ∨ (fact_366edf150095_6115 a b) ∨ (fact_366edf150095_7181 a b))) ∨ ((((2 : Int) + ((2 : Int) * b)) + (4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∨ ((((2 : Int) + ((2 : Int) * b)) = (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((fact_366edf150095_6145 a b) ∨ (fact_366edf150095_6073 a b) ∨ (fact_366edf150095_7005 a b) ∨ (fact_366edf150095_7013 a b) ∨ (fact_366edf150095_6077 a b) ∨ (fact_366edf150095_6423 a b) ∨ (fact_366edf150095_6081 a b) ∨ (fact_366edf150095_7017 a b) ∨ (fact_366edf150095_6600 a b) ∨ (fact_366edf150095_6098 a b) ∨ (fact_366edf150095_6107 a b) ∨ (fact_366edf150095_6629 a b) ∨ (fact_366edf150095_6116 a b) ∨ (fact_366edf150095_7183 a b)) ∧ ((fact_366edf150095_6143 a b) ∨ (fact_366edf150095_6071 a b) ∨ (fact_366edf150095_7003 a b) ∨ (fact_366edf150095_7011 a b) ∨ (fact_366edf150095_6075 a b) ∨ (fact_366edf150095_6421 a b) ∨ (fact_366edf150095_6079 a b) ∨ (fact_366edf150095_7015 a b) ∨ (fact_366edf150095_6598 a b) ∨ (fact_366edf150095_6093 a b) ∨ (fact_366edf150095_6104 a b) ∨ (fact_366edf150095_6627 a b) ∨ (fact_366edf150095_6115 a b) ∨ (fact_366edf150095_7181 a b)) ∧ (((fact_366edf150095_6144 a b) ∨ (fact_366edf150095_6072 a b) ∨ (fact_366edf150095_7004 a b) ∨ (fact_366edf150095_7012 a b) ∨ (fact_366edf150095_6076 a b) ∨ (fact_366edf150095_6422 a b) ∨ (fact_366edf150095_6080 a b) ∨ (fact_366edf150095_7016 a b) ∨ (fact_366edf150095_6599 a b) ∨ (fact_366edf150095_6097 a b) ∨ (fact_366edf150095_6106 a b) ∨ (fact_366edf150095_6628 a b) ∨ (((((7 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + a))) ∨ (((7 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((7 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_7182 a b)) ∨ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6597 a b) ∨ (fact_366edf150095_6092 a b) ∨ (fact_366edf150095_6103 a b) ∨ (fact_366edf150095_6626 a b) ∨ (((((7 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + a))) ∨ (((7 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((7 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_7180 a b)))) ∨ (((fact_366edf150095_6145 a b) ∨ (fact_366edf150095_6073 a b) ∨ (fact_366edf150095_7005 a b) ∨ (fact_366edf150095_7013 a b) ∨ (fact_366edf150095_6077 a b) ∨ (fact_366edf150095_6423 a b) ∨ (fact_366edf150095_6081 a b) ∨ (fact_366edf150095_7017 a b) ∨ (fact_366edf150095_6600 a b) ∨ (fact_366edf150095_6098 a b) ∨ (fact_366edf150095_6107 a b) ∨ (fact_366edf150095_6629 a b) ∨ (fact_366edf150095_6116 a b) ∨ (fact_366edf150095_7183 a b)) ∧ ((fact_366edf150095_6143 a b) ∨ (fact_366edf150095_6071 a b) ∨ (fact_366edf150095_7003 a b) ∨ (fact_366edf150095_7011 a b) ∨ (fact_366edf150095_6075 a b) ∨ (fact_366edf150095_6421 a b) ∨ (fact_366edf150095_6079 a b) ∨ (fact_366edf150095_7015 a b) ∨ (fact_366edf150095_6598 a b) ∨ (fact_366edf150095_6093 a b) ∨ (fact_366edf150095_6104 a b) ∨ (fact_366edf150095_6627 a b) ∨ (fact_366edf150095_6115 a b) ∨ (fact_366edf150095_7181 a b)) ∧ ((fact_366edf150095_6144 a b) ∨ (fact_366edf150095_6072 a b) ∨ (fact_366edf150095_7004 a b) ∨ (fact_366edf150095_7012 a b) ∨ (fact_366edf150095_6076 a b) ∨ (fact_366edf150095_6422 a b) ∨ (fact_366edf150095_6080 a b) ∨ (fact_366edf150095_7016 a b) ∨ (fact_366edf150095_6599 a b) ∨ (fact_366edf150095_6097 a b) ∨ (fact_366edf150095_6106 a b) ∨ (fact_366edf150095_6628 a b) ∨ (((((7 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + a))) ∨ (((7 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((7 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_7182 a b)) ∧ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6597 a b) ∨ (fact_366edf150095_6092 a b) ∨ (fact_366edf150095_6103 a b) ∨ (fact_366edf150095_6626 a b) ∨ (((((7 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + a))) ∨ (((7 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((7 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_7180 a b))))))
    (h1 : (a > b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n146_run_empty (a b run_x : Int)
    (h0 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2319 a b run_x) ∨ (fact_366edf150095_3537 a b run_x) ∨ (fact_366edf150095_2995 a b run_x) ∨ (fact_366edf150095_2330 a b run_x) ∨ (fact_366edf150095_2339 a b run_x) ∨ (fact_366edf150095_3023 a b run_x) ∨ (((((7 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ (((7 : Int) ≤ run_x) ∧ ((7 : Int) ≥ run_x) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_4212 a b run_x)))
    (h1 : ((((7 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + a) - a)) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : ((((-1 : Int) + (0 : Int)) < (((1 : Int) + ((2 : Int) * a)) - a)) ∨ ((((1 : Int) + ((2 : Int) * a)) + (0 : Int)) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h6 : (((2 : Int) + ((2 : Int) * b)) ≤ run_x))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n146_run_floor (a b run_x : Int)
    (h0 : (((2 : Int) + ((2 : Int) * b)) ≤ run_x))
    (h1 : ((((7 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + a) - a)) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3315 a b run_x) ∨ (fact_366edf150095_5230 a b run_x) ∨ (fact_366edf150095_3578 a b run_x) ∨ (fact_366edf150095_3330 a b run_x) ∨ (fact_366edf150095_3340 a b run_x) ∨ (fact_366edf150095_3612 a b run_x) ∨ (((((7 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((7 : Int) ≤ run_x) ∧ ((7 : Int) ≥ run_x) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_5846 a b run_x))))
    (h5 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h4
  clear h4
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n147_run_four (a b : Int)
    (h0 : (((5 : Int) < (((1 : Int) + ((2 : Int) * b)) - a)) ∨ ((5 : Int) > (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < ((4 : Int) - (0 : Int)))))
    (h1 : (¬ (((5 : Int) + a) ≤ ((2 : Int) * b))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n147_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) * b) - ((5 : Int) + a)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n147_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n147_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_4128 a b) ∨ (fact_366edf150095_3723 a b) ∨ (fact_366edf150095_5874 a b) ∨ (fact_366edf150095_5957 a b) ∨ (fact_366edf150095_3804 a b) ∨ (fact_366edf150095_4237 a b) ∨ (fact_366edf150095_3876 a b) ∨ (fact_366edf150095_6029 a b) ∨ (fact_366edf150095_4778 a b) ∨ (fact_366edf150095_3974 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + a) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((5 : Int) ≥ (((5 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + a)))) ∨ (((((6 : Int) - (0 : Int)) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + a) - (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a))) ∨ (((6 : Int) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((6 : Int) ≥ (((5 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + a) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ (((7 : Int) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((7 : Int) ≥ (((5 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - a) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + a) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + a) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n147_run_right (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((((((-1 : Int) - a) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((-1 : Int) ≥ (((2 : Int) * b) + (1 : Int))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) * b) + (1 : Int))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) * b) + (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) * b) + (1 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - b) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) * b) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) * b) + (1 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) * b) + (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + a)))) ∨ (((((6 : Int) - (0 : Int)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a))) ∨ (((6 : Int) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((6 : Int) ≥ (((2 : Int) * b) + (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ (((7 : Int) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((7 : Int) ≥ (((2 : Int) * b) + (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - a) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n147_run_tall (a b : Int)
    (h0 : (¬ ((((((5 : Int) + a) + (3 : Int)) ≤ ((2 : Int) * b)) ∧ ((fact_366edf150095_7795 a b) ∨ (fact_366edf150095_7794 a b))) ∨ (((((5 : Int) + a) + (2 : Int)) ≤ ((2 : Int) * b)) ∧ (fact_366edf150095_7795 a b) ∧ (fact_366edf150095_7794 a b)) ∨ ((((5 : Int) + a) + (4 : Int)) ≤ ((2 : Int) * b)) ∨ ((((2 : Int) * b) = (((5 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7795 a b) ∧ (fact_366edf150095_7794 a b) ∧ (((fact_366edf150095_5149 a b) ∨ (fact_366edf150095_4443 a b) ∨ (fact_366edf150095_6368 a b) ∨ (fact_366edf150095_6456 a b) ∨ (fact_366edf150095_4527 a b) ∨ (fact_366edf150095_5277 a b) ∨ (fact_366edf150095_4604 a b) ∨ (fact_366edf150095_6529 a b) ∨ (fact_366edf150095_5542 a b) ∨ (fact_366edf150095_4860 a b) ∨ (fact_366edf150095_4977 a b) ∨ (fact_366edf150095_5717 a b) ∨ (fact_366edf150095_5074 a b) ∨ ((((((1 : Int) + ((2 : Int) * b)) - a) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + a) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((3 : Int) + b))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + a) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((((3 : Int) + b) - b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((3 : Int) + b) + (0 : Int)))))) ∨ ((((((-1 : Int) - a) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) + a)) ∧ ((0 : Int) ≥ ((3 : Int) + a))) ∨ (((-1 : Int) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((-1 : Int) ≥ (((2 : Int) * b) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((3 : Int) + a)) ∧ ((0 : Int) ≥ ((3 : Int) + a))) ∨ (((0 : Int) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) * b) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) + a)) ∧ ((0 : Int) ≥ ((3 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((3 : Int) + a)) ∧ ((0 : Int) ≥ ((3 : Int) + a))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ (((1 : Int) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) * b) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ ((((2 : Int) * a) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) + a))) ∨ (((2 : Int) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) * b) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) + a))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - b) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) * b) + (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≥ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) * b) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) + a))) ∨ (((5 : Int) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) * b) + (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((4 : Int) + a)))) ∨ (((((6 : Int) - (0 : Int)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((6 : Int) + b)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + a))) ∨ (((6 : Int) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((6 : Int) ≥ (((2 : Int) * b) + (1 : Int))) ∧ ((((5 : Int) + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + a))) ∨ (((7 : Int) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((7 : Int) ≥ (((2 : Int) * b) + (1 : Int))) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - a) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((3 : Int) + b))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((((3 : Int) + b) - b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((3 : Int) + b) + (0 : Int)))))))) ∨ ((fact_366edf150095_7795 a b) ∧ (fact_366edf150095_7794 a b) ∧ ((fact_366edf150095_5149 a b) ∨ (fact_366edf150095_4443 a b) ∨ (fact_366edf150095_6368 a b) ∨ (fact_366edf150095_6456 a b) ∨ (fact_366edf150095_4527 a b) ∨ (fact_366edf150095_5277 a b) ∨ (fact_366edf150095_4604 a b) ∨ (fact_366edf150095_6529 a b) ∨ (fact_366edf150095_5542 a b) ∨ (fact_366edf150095_4860 a b) ∨ (fact_366edf150095_4977 a b) ∨ (fact_366edf150095_5717 a b) ∨ (fact_366edf150095_5074 a b) ∨ ((((((1 : Int) + ((2 : Int) * b)) - a) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + a) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((3 : Int) + b))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + a) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((((3 : Int) + b) - b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((3 : Int) + b) + (0 : Int)))))) ∧ ((((((-1 : Int) - a) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) + a)) ∧ ((0 : Int) ≥ ((3 : Int) + a))) ∨ (((-1 : Int) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((-1 : Int) ≥ (((2 : Int) * b) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((3 : Int) + a)) ∧ ((0 : Int) ≥ ((3 : Int) + a))) ∨ (((0 : Int) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) * b) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) + a)) ∧ ((0 : Int) ≥ ((3 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((3 : Int) + a)) ∧ ((0 : Int) ≥ ((3 : Int) + a))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ (((1 : Int) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) * b) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ ((((2 : Int) * a) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) + a))) ∨ (((2 : Int) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) * b) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) + a))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - b) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) * b) + (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≥ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) * b) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((3 : Int) + a))) ∨ (((5 : Int) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((5 : Int) ≥ (((2 : Int) * b) + (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((4 : Int) + a)))) ∨ (((((6 : Int) - (0 : Int)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((6 : Int) + b)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + a))) ∨ (((6 : Int) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((6 : Int) ≥ (((2 : Int) * b) + (1 : Int))) ∧ ((((5 : Int) + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + a))) ∨ (((7 : Int) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((7 : Int) ≥ (((2 : Int) * b) + (1 : Int))) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - a) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((3 : Int) + b))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ (((2 : Int) * b) + (1 : Int))) ∧ ((((2 : Int) * b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((((3 : Int) + b) - b) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((3 : Int) + b) + (0 : Int))))))))))
    (h1 : ((((7 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + b) - b)) ∨ ((5 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  left
  refine ⟨?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n147_run_empty (a b run_x : Int)
    (h0 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2319 a b run_x) ∨ (fact_366edf150095_3537 a b run_x) ∨ (fact_366edf150095_2995 a b run_x) ∨ (fact_366edf150095_2330 a b run_x) ∨ (fact_366edf150095_2339 a b run_x) ∨ (fact_366edf150095_3023 a b run_x) ∨ (((((7 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ (((7 : Int) ≤ run_x) ∧ ((7 : Int) ≥ run_x) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (0 : Int)))))))
    (h1 : (run_x ≤ ((2 : Int) * b)))
    (h2 : ((((7 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + b) - b)) ∨ ((5 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((-1 : Int) + (0 : Int)) < (((1 : Int) + ((2 : Int) * a)) - a)) ∨ ((((1 : Int) + ((2 : Int) * a)) + (0 : Int)) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((5 : Int) + a) ≤ run_x))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n147_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((2 : Int) * b)))
    (h1 : ((((7 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + b) - b)) ∨ ((5 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h2 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3315 a b run_x) ∨ (fact_366edf150095_5230 a b run_x) ∨ (fact_366edf150095_3578 a b run_x) ∨ (fact_366edf150095_3330 a b run_x) ∨ (fact_366edf150095_3340 a b run_x) ∨ (fact_366edf150095_3612 a b run_x) ∨ (((((7 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((7 : Int) ≤ run_x) ∧ ((7 : Int) ≥ run_x) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((5 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((((3 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h3 : (((5 : Int) + a) ≤ run_x))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n148_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((((7 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + a) - a)) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h3 : (fact_366edf150095_2264 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n148_empty (a b : Int)
    (h0 : ((fact_366edf150095_4213 a b) ∨ (fact_366edf150095_4198 a b) ∨ (fact_366edf150095_6127 a b) ∨ (fact_366edf150095_6133 a b) ∨ (fact_366edf150095_4201 a b) ∨ (fact_366edf150095_5114 a b) ∨ (fact_366edf150095_4204 a b) ∨ (fact_366edf150095_6136 a b) ∨ (fact_366edf150095_5205 a b) ∨ (fact_366edf150095_4206 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ (((-1 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≥ ((-1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + a)))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ (((-1 : Int) + ((2 : Int) * b)) ≤ ((6 : Int) + b)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a))) ∨ (((6 : Int) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ ((6 : Int) ≥ ((-1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ (((-1 : Int) + ((2 : Int) * b)) ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ (((7 : Int) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ ((7 : Int) ≥ ((-1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - b) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ (((-1 : Int) + ((2 : Int) * b)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ (((-1 : Int) + ((2 : Int) * b)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((7 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + a) - a)) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h3 : (a ≥ b))
    (h4 : ((((-1 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) + a) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n148_o0 (a b jx jy : Int)
    (h0 : (((6 : Int) > jx) ∨ ((6 : Int) < jx) ∨ ((jy + b) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h1 : ((jx < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((((7 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + a) - a)) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h5 : (fact_366edf150095_3238 a b jx jy))
    (h6 : (((jx + a) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (((jx + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n148_o1 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h1 : ((((7 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + a) - a)) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_366edf150095_3241 a b jx jy))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (((jx + b) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n148_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((((7 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + a) - a)) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (¬ (((jx = ((-1 : Int) + ((2 : Int) * b))) ∧ (jy = ((3 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h6 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h7 : (fact_366edf150095_3243 a b jx jy))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n148_o3 (a b jx jy : Int)
    (h0 : ((jx < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((jy + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h1 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : (fact_366edf150095_3244 a b jx jy))
    (h3 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < (jx - b)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h4 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : ((((7 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + a) - a)) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h8 : (((jx + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    (h14 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n148_o4 (a b jx jy : Int)
    (h0 : ((((7 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + a) - a)) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h1 : (((jx + (0 : Int)) < (((1 : Int) + ((2 : Int) * b)) - b)) ∨ ((((1 : Int) + ((2 : Int) * b)) + (0 : Int)) < (jx - b)) ∨ (jy < ((3 : Int) + a)) ∨ (((3 : Int) + a) < jy)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h6 : (fact_366edf150095_3245 a b jx jy))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n148_o5 (a b jx jy : Int)
    (h0 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h1 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < (jx - a)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h2 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h5 : (fact_366edf150095_3242 a b jx jy))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (((jx + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h8 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h9 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h10 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h11 : ((((7 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + a) - a)) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h12 : (a ≥ (5 : Int)))
    (h13 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h14 : (b ≥ (3 : Int)))
    (h15 : (a ≥ b))
    (h16 : (a > b))
    (h17 : (a = (b + (2 : Int))))
    (h18 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n148_o6 (a b jx jy : Int)
    (h0 : (((jx + b) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h1 : (fact_366edf150095_3240 a b jx jy))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((((7 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + a) - a)) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (((jx + b) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n148_o7 (a b jx jy : Int)
    (h0 : ((((7 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + a) - a)) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (fact_366edf150095_3239 a b jx jy))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (((jx + a) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n149_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((5 : Int) + a) ≤ ((-2 : Int) + ((2 : Int) * b)))))
    (h2 : (((5 : Int) < (((-1 : Int) + ((2 : Int) * b)) - a)) ∨ ((5 : Int) > (((-1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < ((4 : Int) - (0 : Int)))))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n149_run_short (a b : Int)
    (h0 : (¬ ((((-2 : Int) + ((2 : Int) * b)) - ((5 : Int) + a)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n149_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n149_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4128 a b) ∨ (fact_366edf150095_3723 a b) ∨ (fact_366edf150095_5874 a b) ∨ (fact_366edf150095_5957 a b) ∨ (fact_366edf150095_3804 a b) ∨ (fact_366edf150095_4237 a b) ∨ (fact_366edf150095_3876 a b) ∨ (fact_366edf150095_6029 a b) ∨ (fact_366edf150095_4778 a b) ∨ (fact_366edf150095_3974 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + a) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((5 : Int) ≥ (((5 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + a)))) ∨ (((((6 : Int) - (0 : Int)) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + a) - (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a))) ∨ (((6 : Int) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((6 : Int) ≥ (((5 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + a) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ (((7 : Int) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((7 : Int) ≥ (((5 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - b) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + a) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + a) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((((-1 : Int) + ((2 : Int) * b)) - a) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + a) - (1 : Int)) ≤ (((-1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b))) ∨ ((((-1 : Int) + ((2 : Int) * b)) ≤ (((5 : Int) + a) - (1 : Int))) ∧ ((((5 : Int) + a) - (1 : Int)) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n149_run_right (a b : Int)
    (h0 : (¬ ((((((-1 : Int) - a) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((0 : Int) ≥ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((1 : Int) ≥ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((2 : Int) ≥ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - b) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((4 : Int) ≥ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((5 : Int) ≥ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + a)))) ∨ (((((6 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a))) ∨ (((6 : Int) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((6 : Int) ≥ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ (((7 : Int) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((7 : Int) ≥ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - b) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((((-1 : Int) + ((2 : Int) * b)) - a) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((-1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b))) ∨ ((((-1 : Int) + ((2 : Int) * b)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n149_run_tall (a b : Int)
    (h0 : ((((5 : Int) + b) < ((-1 : Int) + ((2 : Int) * b))) ∨ (((-1 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ ((4 : Int) < (((3 : Int) + b) - b)) ∨ ((4 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h1 : (((5 : Int) < (((-1 : Int) + ((2 : Int) * b)) - a)) ∨ ((5 : Int) > (((-1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < ((4 : Int) - (0 : Int)))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((7 : Int) + a) < ((-1 : Int) + ((2 : Int) * b))) ∨ (((-1 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + b) - b)) ∨ ((5 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h5 : (¬ ((((((5 : Int) + a) + (3 : Int)) ≤ ((-2 : Int) + ((2 : Int) * b))) ∧ ((fact_366edf150095_7845 a b) ∨ ((fact_366edf150095_6205 a b) ∨ (fact_366edf150095_6149 a b) ∨ (fact_366edf150095_7049 a b) ∨ (fact_366edf150095_7053 a b) ∨ (fact_366edf150095_6153 a b) ∨ (fact_366edf150095_6635 a b) ∨ (fact_366edf150095_6159 a b) ∨ (fact_366edf150095_7055 a b) ∨ (fact_366edf150095_6701 a b) ∨ (fact_366edf150095_6176 a b) ∨ (fact_366edf150095_6184 a b) ∨ (fact_366edf150095_6739 a b) ∨ (fact_366edf150095_6199 a b) ∨ (fact_366edf150095_7229 a b) ∨ (fact_366edf150095_7235 a b)))) ∨ (((((5 : Int) + a) + (2 : Int)) ≤ ((-2 : Int) + ((2 : Int) * b))) ∧ (fact_366edf150095_7845 a b) ∧ ((fact_366edf150095_6205 a b) ∨ (fact_366edf150095_6149 a b) ∨ (fact_366edf150095_7049 a b) ∨ (fact_366edf150095_7053 a b) ∨ (fact_366edf150095_6153 a b) ∨ (fact_366edf150095_6635 a b) ∨ (fact_366edf150095_6159 a b) ∨ (fact_366edf150095_7055 a b) ∨ (fact_366edf150095_6701 a b) ∨ (fact_366edf150095_6176 a b) ∨ (fact_366edf150095_6184 a b) ∨ (fact_366edf150095_6739 a b) ∨ (fact_366edf150095_6199 a b) ∨ (fact_366edf150095_7229 a b) ∨ (fact_366edf150095_7235 a b))) ∨ ((((5 : Int) + a) + (4 : Int)) ≤ ((-2 : Int) + ((2 : Int) * b))) ∨ ((((-2 : Int) + ((2 : Int) * b)) = (((5 : Int) + a) + (1 : Int))) ∧ (fact_366edf150095_7845 a b) ∧ ((fact_366edf150095_6205 a b) ∨ (fact_366edf150095_6149 a b) ∨ (fact_366edf150095_7049 a b) ∨ (fact_366edf150095_7053 a b) ∨ (fact_366edf150095_6153 a b) ∨ (fact_366edf150095_6635 a b) ∨ (fact_366edf150095_6159 a b) ∨ (fact_366edf150095_7055 a b) ∨ (fact_366edf150095_6701 a b) ∨ (fact_366edf150095_6176 a b) ∨ (fact_366edf150095_6184 a b) ∨ (fact_366edf150095_6739 a b) ∨ (fact_366edf150095_6199 a b) ∨ (fact_366edf150095_7229 a b) ∨ (fact_366edf150095_7235 a b)) ∧ (((fact_366edf150095_5149 a b) ∨ (fact_366edf150095_4443 a b) ∨ (fact_366edf150095_6368 a b) ∨ (fact_366edf150095_6456 a b) ∨ (fact_366edf150095_4527 a b) ∨ (fact_366edf150095_5277 a b) ∨ (fact_366edf150095_4604 a b) ∨ (fact_366edf150095_6529 a b) ∨ (fact_366edf150095_5542 a b) ∨ (fact_366edf150095_4860 a b) ∨ (fact_366edf150095_4977 a b) ∨ (fact_366edf150095_5717 a b) ∨ (fact_366edf150095_5074 a b) ∨ (fact_366edf150095_6875 a b) ∨ (fact_366edf150095_6879 a b)) ∨ ((fact_366edf150095_6204 a b) ∨ (fact_366edf150095_6148 a b) ∨ (fact_366edf150095_7048 a b) ∨ (fact_366edf150095_7052 a b) ∨ (fact_366edf150095_6152 a b) ∨ (fact_366edf150095_6634 a b) ∨ (fact_366edf150095_6158 a b) ∨ (fact_366edf150095_7054 a b) ∨ (fact_366edf150095_6700 a b) ∨ (fact_366edf150095_6175 a b) ∨ (fact_366edf150095_6183 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((6 : Int) + b)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + a))) ∨ (((6 : Int) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((6 : Int) ≥ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((5 : Int) + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + a))) ∨ (((7 : Int) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((7 : Int) ≥ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_7228 a b) ∨ (fact_366edf150095_7234 a b)))) ∨ ((fact_366edf150095_7845 a b) ∧ ((fact_366edf150095_6205 a b) ∨ (fact_366edf150095_6149 a b) ∨ (fact_366edf150095_7049 a b) ∨ (fact_366edf150095_7053 a b) ∨ (fact_366edf150095_6153 a b) ∨ (fact_366edf150095_6635 a b) ∨ (fact_366edf150095_6159 a b) ∨ (fact_366edf150095_7055 a b) ∨ (fact_366edf150095_6701 a b) ∨ (fact_366edf150095_6176 a b) ∨ (fact_366edf150095_6184 a b) ∨ (fact_366edf150095_6739 a b) ∨ (fact_366edf150095_6199 a b) ∨ (fact_366edf150095_7229 a b) ∨ (fact_366edf150095_7235 a b)) ∧ ((fact_366edf150095_5149 a b) ∨ (fact_366edf150095_4443 a b) ∨ (fact_366edf150095_6368 a b) ∨ (fact_366edf150095_6456 a b) ∨ (fact_366edf150095_4527 a b) ∨ (fact_366edf150095_5277 a b) ∨ (fact_366edf150095_4604 a b) ∨ (fact_366edf150095_6529 a b) ∨ (fact_366edf150095_5542 a b) ∨ (fact_366edf150095_4860 a b) ∨ (fact_366edf150095_4977 a b) ∨ (fact_366edf150095_5717 a b) ∨ (fact_366edf150095_5074 a b) ∨ (fact_366edf150095_6875 a b) ∨ (fact_366edf150095_6879 a b)) ∧ ((fact_366edf150095_6204 a b) ∨ (fact_366edf150095_6148 a b) ∨ (fact_366edf150095_7048 a b) ∨ (fact_366edf150095_7052 a b) ∨ (fact_366edf150095_6152 a b) ∨ (fact_366edf150095_6634 a b) ∨ (fact_366edf150095_6158 a b) ∨ (fact_366edf150095_7054 a b) ∨ (fact_366edf150095_6700 a b) ∨ (fact_366edf150095_6175 a b) ∨ (fact_366edf150095_6183 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((6 : Int) + b)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + a))) ∨ (((6 : Int) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((6 : Int) ≥ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((5 : Int) + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((-2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + a))) ∨ (((7 : Int) ≤ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((7 : Int) ≥ (((-2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_7228 a b) ∨ (fact_366edf150095_7234 a b))))))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h5
  clear h5
  right
  left
  refine ⟨?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n149_run_empty (a b run_x : Int)
    (h0 : ((((-1 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) + a) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h1 : (((5 : Int) + a) ≤ run_x))
    (h2 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2319 a b run_x) ∨ (fact_366edf150095_3537 a b run_x) ∨ (fact_366edf150095_2995 a b run_x) ∨ (fact_366edf150095_2330 a b run_x) ∨ (fact_366edf150095_2339 a b run_x) ∨ (fact_366edf150095_3023 a b run_x) ∨ (((((7 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ (((7 : Int) ≤ run_x) ∧ ((7 : Int) ≥ run_x) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - b) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((((-1 : Int) + ((2 : Int) * b)) - a) ≤ run_x) ∧ (run_x ≤ (((-1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b))) ∨ ((((-1 : Int) + ((2 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (0 : Int)))))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (run_x ≤ ((-2 : Int) + ((2 : Int) * b))))
    (h5 : ((((7 : Int) + a) < ((-1 : Int) + ((2 : Int) * b))) ∨ (((-1 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + b) - b)) ∨ ((5 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h6 : ((((5 : Int) + b) < ((-1 : Int) + ((2 : Int) * b))) ∨ (((-1 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ ((4 : Int) < (((3 : Int) + b) - b)) ∨ ((4 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n149_run_floor (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((5 : Int) + a) ≤ run_x))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (run_x ≤ ((-2 : Int) + ((2 : Int) * b))))
    (h4 : ((((5 : Int) + b) < ((-1 : Int) + ((2 : Int) * b))) ∨ (((-1 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ ((4 : Int) < (((3 : Int) + b) - b)) ∨ ((4 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h5 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3315 a b run_x) ∨ (fact_366edf150095_5230 a b run_x) ∨ (fact_366edf150095_3578 a b run_x) ∨ (fact_366edf150095_3330 a b run_x) ∨ (fact_366edf150095_3340 a b run_x) ∨ (fact_366edf150095_3612 a b run_x) ∨ (((((7 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((7 : Int) ≤ run_x) ∧ ((7 : Int) ≥ run_x) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((5 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * b)) - b) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((((3 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((((-1 : Int) + ((2 : Int) * b)) - a) ≤ run_x) ∧ (run_x ≤ (((-1 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ ((((-1 : Int) + ((2 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((-1 : Int) + ((2 : Int) * b))) ∧ ((((3 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h6 : ((((7 : Int) + a) < ((-1 : Int) + ((2 : Int) * b))) ∨ (((-1 : Int) + ((2 : Int) * b)) < ((7 : Int) - (0 : Int))) ∨ ((5 : Int) < (((3 : Int) + b) - b)) ∨ ((5 : Int) > (((3 : Int) + b) + (0 : Int)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h5
  clear h5
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n150_run_four (a b : Int)
    (h0 : (¬ ((7 : Int) ≤ ((6 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n150_run_short (a b : Int)
    (h0 : (¬ ((((6 : Int) + b) - (7 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n150_run_nonnegative (a b : Int)
    (h0 : (¬ ((6 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n150_run_left (a b : Int)
    (h0 : (¬ ((((((-1 : Int) - a) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((6 : Int) ≥ ((3 : Int) + a)) ∧ ((6 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((6 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + a)))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((6 : Int) ≥ ((5 : Int) + a)) ∧ ((6 : Int) ≤ ((5 : Int) + a))) ∨ (((6 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((6 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ ((((((7 : Int) + b) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((7 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int))) ∨ ((((7 : Int) + b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((7 : Int) + b)) ∧ ((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + a)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n150_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((((-1 : Int) - a) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((-1 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((6 : Int) ≥ ((3 : Int) + a)) ∧ ((6 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((6 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((6 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + a)))) ∨ (((((6 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((6 : Int) ≥ ((5 : Int) + a)) ∧ ((6 : Int) ≤ ((5 : Int) + a))) ∨ (((6 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((6 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((6 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((6 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ ((((((7 : Int) + b) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((7 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int))) ∨ ((((7 : Int) + b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((7 : Int) + b)) ∧ ((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + a)))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n150_run_tall (a b : Int)
    (h0 : (¬ (((((7 : Int) + (3 : Int)) ≤ ((6 : Int) + b)) ∧ ((fact_366edf150095_7690 a b) ∨ (fact_366edf150095_7717 a b))) ∨ ((((7 : Int) + (2 : Int)) ≤ ((6 : Int) + b)) ∧ (fact_366edf150095_7690 a b) ∧ (fact_366edf150095_7717 a b)) ∨ (((7 : Int) + (4 : Int)) ≤ ((6 : Int) + b)) ∨ ((((6 : Int) + b) = ((7 : Int) + (1 : Int))) ∧ (fact_366edf150095_7690 a b) ∧ (fact_366edf150095_7717 a b) ∧ (((((((-1 : Int) - a) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ (((-1 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ (((0 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((6 : Int) + a)) ∧ ((1 : Int) ≥ ((6 : Int) + a))) ∨ (((1 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((6 : Int) + a)) ∧ ((1 : Int) ≥ ((6 : Int) + a))) ∨ ((((2 : Int) * a) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a))) ∨ (((2 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a))) ∨ (((4 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a))) ∨ (((5 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + a)))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((6 : Int) + b)) ∧ (((5 : Int) + a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a))) ∨ (((6 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((((5 : Int) + a) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ ((((((7 : Int) + b) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((7 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≥ ((6 : Int) + a))) ∨ ((((7 : Int) + b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((7 : Int) + b)) ∧ (((5 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a))))) ∨ ((((((-1 : Int) - a) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ (((-1 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((-1 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ (((0 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((6 : Int) + a)) ∧ ((1 : Int) ≥ ((6 : Int) + a))) ∨ (((1 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((6 : Int) + a)) ∧ ((1 : Int) ≥ ((6 : Int) + a))) ∨ ((((2 : Int) * a) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a))) ∨ (((2 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a))) ∨ (((4 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a))) ∨ (((5 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + a)))) ∨ (((((6 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((6 : Int) + b)) ∧ (((5 : Int) + a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a))) ∨ (((6 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((6 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + a) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ ((((((7 : Int) + b) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((7 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≥ ((6 : Int) + a))) ∨ ((((7 : Int) + b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((7 : Int) + b)) ∧ (((5 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a))))))) ∨ ((fact_366edf150095_7690 a b) ∧ (fact_366edf150095_7717 a b) ∧ ((((((-1 : Int) - a) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ (((-1 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ (((0 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((6 : Int) + a)) ∧ ((1 : Int) ≥ ((6 : Int) + a))) ∨ (((1 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((6 : Int) + a)) ∧ ((1 : Int) ≥ ((6 : Int) + a))) ∨ ((((2 : Int) * a) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a))) ∨ (((2 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a))) ∨ (((4 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a))) ∨ (((5 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + a)))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((6 : Int) + b)) ∧ (((5 : Int) + a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a))) ∨ (((6 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((((5 : Int) + a) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ ((((((7 : Int) + b) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((7 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≥ ((6 : Int) + a))) ∨ ((((7 : Int) + b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((7 : Int) + b)) ∧ (((5 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a))))) ∧ ((((((-1 : Int) - a) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ (((-1 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((-1 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ (((0 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((6 : Int) + a)) ∧ ((1 : Int) ≥ ((6 : Int) + a))) ∨ (((1 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((6 : Int) + a)) ∧ ((1 : Int) ≥ ((6 : Int) + a))) ∨ ((((2 : Int) * a) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a))) ∨ (((2 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a))) ∨ (((4 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a))) ∨ (((5 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + a)))) ∨ (((((6 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((6 : Int) + b)) ∧ (((5 : Int) + a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a))) ∨ (((6 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((6 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + a) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ ((((((7 : Int) + b) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((7 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≥ ((6 : Int) + a))) ∨ ((((7 : Int) + b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((7 : Int) + b)) ∧ (((5 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a)))))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < (((7 : Int) + b) - b)) ∨ ((((7 : Int) + b) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n150_run_empty (a b run_x : Int)
    (h0 : (run_x ≤ ((6 : Int) + b)))
    (h1 : ((7 : Int) ≤ run_x))
    (h2 : ((fact_366edf150095_2378 a b run_x) ∨ (fact_366edf150095_2313 a b run_x) ∨ (fact_366edf150095_3521 a b run_x) ∨ (fact_366edf150095_3536 a b run_x) ∨ (fact_366edf150095_2318 a b run_x) ∨ (fact_366edf150095_2960 a b run_x) ∨ (fact_366edf150095_2322 a b run_x) ∨ (fact_366edf150095_3540 a b run_x) ∨ (fact_366edf150095_3000 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ ((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + a)))) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + b)) ∧ ((6 : Int) ≥ ((5 : Int) + a)) ∧ ((6 : Int) ≤ ((5 : Int) + a))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((6 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((6 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ ((((((7 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((7 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int))) ∨ ((((7 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + b)) ∧ ((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + a))))))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < (((7 : Int) + b) - b)) ∨ ((((7 : Int) + b) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n150_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((6 : Int) + b)))
    (h1 : ((7 : Int) ≤ run_x))
    (h2 : (¬ ((fact_366edf150095_3352 a b run_x) ∨ (fact_366edf150095_3301 a b run_x) ∨ (fact_366edf150095_5216 a b run_x) ∨ (fact_366edf150095_5226 a b run_x) ∨ (fact_366edf150095_3311 a b run_x) ∨ (fact_366edf150095_3531 a b run_x) ∨ (fact_366edf150095_3318 a b run_x) ∨ (fact_366edf150095_5233 a b run_x) ∨ (fact_366edf150095_3581 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((6 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int)))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ (((4 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + b)) ∧ (((5 : Int) + a) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((5 : Int) + a))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((((5 : Int) + a) - a) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ ((((((7 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((7 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((6 : Int) - (1 : Int)))) ∨ ((((7 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + b)) ∧ (((5 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((5 : Int) + a)))))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n151_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_366edf150095_2138 a b))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n151_empty (a b : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : ((((-1 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) + a) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h2 : (a > b))
    (h3 : ((fact_366edf150095_4132 a b) ∨ (fact_366edf150095_3727 a b) ∨ (fact_366edf150095_5878 a b) ∨ (fact_366edf150095_5961 a b) ∨ (fact_366edf150095_3808 a b) ∨ (fact_366edf150095_4241 a b) ∨ (fact_366edf150095_3878 a b) ∨ (fact_366edf150095_6031 a b) ∨ (fact_366edf150095_4779 a b) ∨ (fact_366edf150095_3977 a b) ∨ (fact_366edf150095_4029 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((6 : Int) + b)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a))) ∨ (((6 : Int) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ ((6 : Int) ≥ ((1 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ ((((((7 : Int) + a) - a) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ ((((7 : Int) + a) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + b))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n151_o0 (a b jx jy : Int)
    (h0 : (((jx + a) < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h3 : (fact_366edf150095_3210 a b jx jy))
    (h4 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h5 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (((jx + a) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h8 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h9 : ((((3 : Int) + ((2 : Int) * b)) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h10 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h11 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h12 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h13 : (b ≥ (3 : Int)))
    (h14 : (a ≥ b))
    (h15 : (a > b))
    (h16 : (a = (b + (2 : Int))))
    (h17 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n151_o1 (a b jx jy : Int)
    (h0 : (fact_366edf150095_3213 a b jx jy))
    (h1 : (¬ (((jx = ((1 : Int) + ((2 : Int) * b))) ∧ (jy = ((3 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((jx + b) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n151_o2 (a b jx jy : Int)
    (h0 : (fact_366edf150095_3215 a b jx jy))
    (h1 : (((jx + (0 : Int)) < ((7 : Int) + a)) ∨ (((7 : Int) + a) < (jx - a)) ∨ (jy < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jy)))
    (h2 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - a)) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : ((((3 : Int) + ((2 : Int) * b)) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n151_o3 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < (jx - b)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (fact_366edf150095_3216 a b jx jy))
    (h3 : (((jx + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((3 : Int) + ((2 : Int) * b)) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h6 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n151_o4 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((jx + (0 : Int)) < ((7 : Int) + a)) ∨ (((7 : Int) + a) < (jx - b)) ∨ (jy < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jy)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((3 : Int) + ((2 : Int) * b)) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h6 : (fact_366edf150095_3217 a b jx jy))
    (h7 : ((jx < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h8 : ((jy - a) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n151_o5 (a b jx jy : Int)
    (h0 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < (jx - a)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_366edf150095_3214 a b jx jy))
    (h4 : (((jx + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h5 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h6 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h10 : ((((3 : Int) + ((2 : Int) * b)) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h11 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h12 : (b ≥ (3 : Int)))
    (h13 : (a ≥ b))
    (h14 : (a > b))
    (h15 : (a = (b + (2 : Int))))
    (h16 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n151_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h4 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h5 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h6 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h7 : (((jx + b) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h8 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h9 : (a = (b + (2 : Int))))
    (h10 : (fact_366edf150095_3212 a b jx jy))
    (h11 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h12 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h13 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h14 : (a ≥ (5 : Int)))
    (h15 : (((jx + b) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h16 : (a ≥ b))
    (h17 : (a > b))
    (h18 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n151_o7 (a b jx jy : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (fact_366edf150095_3211 a b jx jy))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (((jx + a) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n152_run_four (a b : Int)
    (h0 : (¬ (((2 : Int) + ((2 : Int) * b)) ≤ ((2 : Int) + ((2 : Int) * b)))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n152_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + ((2 : Int) * b)) - ((2 : Int) + ((2 : Int) * b))) < b)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n152_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n152_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5831 a b) ∨ (fact_366edf150095_5797 a b) ∨ (fact_366edf150095_6943 a b) ∨ (fact_366edf150095_6945 a b) ∨ (fact_366edf150095_5799 a b) ∨ (fact_366edf150095_5945 a b) ∨ (fact_366edf150095_5801 a b) ∨ (fact_366edf150095_6947 a b) ∨ (fact_366edf150095_6091 a b) ∨ (fact_366edf150095_5805 a b) ∨ (fact_366edf150095_5807 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a))) ∨ (((6 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((6 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ ((((((7 : Int) + a) - a) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ ((((7 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_7007 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n152_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5830 a b) ∨ (fact_366edf150095_5796 a b) ∨ (fact_366edf150095_6942 a b) ∨ (fact_366edf150095_6944 a b) ∨ (fact_366edf150095_5798 a b) ∨ (fact_366edf150095_5944 a b) ∨ (fact_366edf150095_5800 a b) ∨ (fact_366edf150095_6946 a b) ∨ (fact_366edf150095_6090 a b) ∨ (fact_366edf150095_5803 a b) ∨ (fact_366edf150095_5806 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a))) ∨ (((6 : Int) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((6 : Int) ≥ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ ((((((7 : Int) + a) - a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ ((((7 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_7006 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n152_run_tall (a b : Int)
    (h0 : (a ≥ b))
    (h1 : (a > b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ ((((((2 : Int) + ((2 : Int) * b)) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((fact_366edf150095_6145 a b) ∨ (fact_366edf150095_6073 a b) ∨ (fact_366edf150095_7005 a b) ∨ (fact_366edf150095_7013 a b) ∨ (fact_366edf150095_6077 a b) ∨ (fact_366edf150095_6423 a b) ∨ (fact_366edf150095_6081 a b) ∨ (fact_366edf150095_7017 a b) ∨ (fact_366edf150095_6600 a b) ∨ (fact_366edf150095_6098 a b) ∨ (fact_366edf150095_6107 a b) ∨ (fact_366edf150095_6629 a b) ∨ (fact_366edf150095_6565 a b) ∨ (fact_366edf150095_7183 a b)) ∨ ((fact_366edf150095_6143 a b) ∨ (fact_366edf150095_6071 a b) ∨ (fact_366edf150095_7003 a b) ∨ (fact_366edf150095_7011 a b) ∨ (fact_366edf150095_6075 a b) ∨ (fact_366edf150095_6421 a b) ∨ (fact_366edf150095_6079 a b) ∨ (fact_366edf150095_7015 a b) ∨ (fact_366edf150095_6598 a b) ∨ (fact_366edf150095_6093 a b) ∨ (fact_366edf150095_6104 a b) ∨ (fact_366edf150095_6627 a b) ∨ (fact_366edf150095_6564 a b) ∨ (fact_366edf150095_7181 a b)))) ∨ (((((2 : Int) + ((2 : Int) * b)) + (2 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((fact_366edf150095_6145 a b) ∨ (fact_366edf150095_6073 a b) ∨ (fact_366edf150095_7005 a b) ∨ (fact_366edf150095_7013 a b) ∨ (fact_366edf150095_6077 a b) ∨ (fact_366edf150095_6423 a b) ∨ (fact_366edf150095_6081 a b) ∨ (fact_366edf150095_7017 a b) ∨ (fact_366edf150095_6600 a b) ∨ (fact_366edf150095_6098 a b) ∨ (fact_366edf150095_6107 a b) ∨ (fact_366edf150095_6629 a b) ∨ (fact_366edf150095_6565 a b) ∨ (fact_366edf150095_7183 a b)) ∧ ((fact_366edf150095_6143 a b) ∨ (fact_366edf150095_6071 a b) ∨ (fact_366edf150095_7003 a b) ∨ (fact_366edf150095_7011 a b) ∨ (fact_366edf150095_6075 a b) ∨ (fact_366edf150095_6421 a b) ∨ (fact_366edf150095_6079 a b) ∨ (fact_366edf150095_7015 a b) ∨ (fact_366edf150095_6598 a b) ∨ (fact_366edf150095_6093 a b) ∨ (fact_366edf150095_6104 a b) ∨ (fact_366edf150095_6627 a b) ∨ (fact_366edf150095_6564 a b) ∨ (fact_366edf150095_7181 a b))) ∨ ((((2 : Int) + ((2 : Int) * b)) + (4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∨ ((((2 : Int) + ((2 : Int) * b)) = (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((fact_366edf150095_6145 a b) ∨ (fact_366edf150095_6073 a b) ∨ (fact_366edf150095_7005 a b) ∨ (fact_366edf150095_7013 a b) ∨ (fact_366edf150095_6077 a b) ∨ (fact_366edf150095_6423 a b) ∨ (fact_366edf150095_6081 a b) ∨ (fact_366edf150095_7017 a b) ∨ (fact_366edf150095_6600 a b) ∨ (fact_366edf150095_6098 a b) ∨ (fact_366edf150095_6107 a b) ∨ (fact_366edf150095_6629 a b) ∨ (fact_366edf150095_6565 a b) ∨ (fact_366edf150095_7183 a b)) ∧ ((fact_366edf150095_6143 a b) ∨ (fact_366edf150095_6071 a b) ∨ (fact_366edf150095_7003 a b) ∨ (fact_366edf150095_7011 a b) ∨ (fact_366edf150095_6075 a b) ∨ (fact_366edf150095_6421 a b) ∨ (fact_366edf150095_6079 a b) ∨ (fact_366edf150095_7015 a b) ∨ (fact_366edf150095_6598 a b) ∨ (fact_366edf150095_6093 a b) ∨ (fact_366edf150095_6104 a b) ∨ (fact_366edf150095_6627 a b) ∨ (fact_366edf150095_6564 a b) ∨ (fact_366edf150095_7181 a b)) ∧ (((fact_366edf150095_6144 a b) ∨ (fact_366edf150095_6072 a b) ∨ (fact_366edf150095_7004 a b) ∨ (fact_366edf150095_7012 a b) ∨ (fact_366edf150095_6076 a b) ∨ (fact_366edf150095_6422 a b) ∨ (fact_366edf150095_6080 a b) ∨ (fact_366edf150095_7016 a b) ∨ (fact_366edf150095_6599 a b) ∨ (fact_366edf150095_6097 a b) ∨ (fact_366edf150095_6106 a b) ∨ (fact_366edf150095_6628 a b) ∨ ((((((7 : Int) + a) - a) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + a))) ∨ ((((7 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_7182 a b)) ∨ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6597 a b) ∨ (fact_366edf150095_6092 a b) ∨ (fact_366edf150095_6103 a b) ∨ (fact_366edf150095_6626 a b) ∨ ((((((7 : Int) + a) - a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + a))) ∨ ((((7 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((7 : Int) + a)) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_7180 a b)))) ∨ (((fact_366edf150095_6145 a b) ∨ (fact_366edf150095_6073 a b) ∨ (fact_366edf150095_7005 a b) ∨ (fact_366edf150095_7013 a b) ∨ (fact_366edf150095_6077 a b) ∨ (fact_366edf150095_6423 a b) ∨ (fact_366edf150095_6081 a b) ∨ (fact_366edf150095_7017 a b) ∨ (fact_366edf150095_6600 a b) ∨ (fact_366edf150095_6098 a b) ∨ (fact_366edf150095_6107 a b) ∨ (fact_366edf150095_6629 a b) ∨ (fact_366edf150095_6565 a b) ∨ (fact_366edf150095_7183 a b)) ∧ ((fact_366edf150095_6143 a b) ∨ (fact_366edf150095_6071 a b) ∨ (fact_366edf150095_7003 a b) ∨ (fact_366edf150095_7011 a b) ∨ (fact_366edf150095_6075 a b) ∨ (fact_366edf150095_6421 a b) ∨ (fact_366edf150095_6079 a b) ∨ (fact_366edf150095_7015 a b) ∨ (fact_366edf150095_6598 a b) ∨ (fact_366edf150095_6093 a b) ∨ (fact_366edf150095_6104 a b) ∨ (fact_366edf150095_6627 a b) ∨ (fact_366edf150095_6564 a b) ∨ (fact_366edf150095_7181 a b)) ∧ ((fact_366edf150095_6144 a b) ∨ (fact_366edf150095_6072 a b) ∨ (fact_366edf150095_7004 a b) ∨ (fact_366edf150095_7012 a b) ∨ (fact_366edf150095_6076 a b) ∨ (fact_366edf150095_6422 a b) ∨ (fact_366edf150095_6080 a b) ∨ (fact_366edf150095_7016 a b) ∨ (fact_366edf150095_6599 a b) ∨ (fact_366edf150095_6097 a b) ∨ (fact_366edf150095_6106 a b) ∨ (fact_366edf150095_6628 a b) ∨ ((((((7 : Int) + a) - a) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + a))) ∨ ((((7 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_7182 a b)) ∧ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6597 a b) ∨ (fact_366edf150095_6092 a b) ∨ (fact_366edf150095_6103 a b) ∨ (fact_366edf150095_6626 a b) ∨ ((((((7 : Int) + a) - a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + a))) ∨ ((((7 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((7 : Int) + a)) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_7180 a b))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n152_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (((2 : Int) + ((2 : Int) * b)) ≤ run_x))
    (h3 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2319 a b run_x) ∨ (fact_366edf150095_3537 a b run_x) ∨ (fact_366edf150095_2995 a b run_x) ∨ (fact_366edf150095_2330 a b run_x) ∨ (fact_366edf150095_2339 a b run_x) ∨ (fact_366edf150095_3023 a b run_x) ∨ ((((((7 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ ((((7 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_4212 a b run_x)))
    (h4 : (((((7 : Int) + a) + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (((7 : Int) + a) - a)) ∨ ((5 : Int) < (((3 : Int) + a) - a)) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h5 : ((((-1 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) + a) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h6 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n152_run_floor (a b run_x : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h2 : (((2 : Int) + ((2 : Int) * b)) ≤ run_x))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3315 a b run_x) ∨ (fact_366edf150095_5230 a b run_x) ∨ (fact_366edf150095_3578 a b run_x) ∨ (fact_366edf150095_3330 a b run_x) ∨ (fact_366edf150095_3340 a b run_x) ∨ (fact_366edf150095_3612 a b run_x) ∨ ((((((7 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((7 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + a)) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_5846 a b run_x))))
    (h5 : (((((7 : Int) + a) + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (((7 : Int) + a) - a)) ∨ ((5 : Int) < (((3 : Int) + a) - a)) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h4
  clear h4
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n153_run_four (a b : Int)
    (h0 : (¬ ((5 : Int) ≤ ((2 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n153_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + a) - (5 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n153_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n153_run_left (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((((8 : Int) ≥ ((-1 : Int) - a)) ∧ ((8 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((8 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((8 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((8 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((8 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((8 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((8 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((8 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((8 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((8 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((8 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((8 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((8 : Int) ≥ ((2 : Int) * a)) ∧ ((8 : Int) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((8 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((2 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (2 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((8 : Int) ≥ (((3 : Int) + ((2 : Int) * b)) - b)) ∧ ((8 : Int) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((8 : Int) ≥ ((3 : Int) + ((2 : Int) * b))) ∧ ((8 : Int) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((8 : Int) ≥ ((3 : Int) - b)) ∧ ((8 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (3 : Int)) ∧ ((((3 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ ((((8 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((5 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (5 : Int)) ∧ (((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a)))) ∨ ((((8 : Int) ≥ ((6 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((6 : Int) + b)) ∧ (((5 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((5 : Int) + a))) ∨ (((6 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (6 : Int)) ∧ ((((5 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((7 : Int) + a)) ∧ (((5 : Int) + b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((5 : Int) + b))) ∨ (((7 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (7 : Int)) ∧ ((((5 : Int) + b) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int))))))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n153_run_right (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((((8 : Int) ≥ ((-1 : Int) - a)) ∧ ((8 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((8 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((0 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((8 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((8 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((8 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((8 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((8 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((8 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((8 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((8 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((8 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((1 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((8 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((8 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((8 : Int) ≥ ((2 : Int) * a)) ∧ ((8 : Int) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((8 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((2 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (2 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((8 : Int) ≥ (((3 : Int) + ((2 : Int) * b)) - b)) ∧ ((8 : Int) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((8 : Int) ≥ ((3 : Int) + ((2 : Int) * b))) ∧ ((8 : Int) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((8 : Int) ≥ ((3 : Int) - b)) ∧ ((8 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (3 : Int)) ∧ ((((3 : Int) + a) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((4 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ ((((8 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((5 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (5 : Int)) ∧ (((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a)))) ∨ ((((8 : Int) ≥ ((6 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((6 : Int) + b)) ∧ (((5 : Int) + a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((5 : Int) + a))) ∨ (((6 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (6 : Int)) ∧ ((((5 : Int) + a) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((5 : Int) + a) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((7 : Int) + a)) ∧ (((5 : Int) + b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((5 : Int) + b))) ∨ (((7 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (7 : Int)) ∧ ((((5 : Int) + b) - b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int))))))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n153_run_tall (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : (a > b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (¬ (((((5 : Int) + (3 : Int)) ≤ ((2 : Int) + a)) ∧ ((fact_366edf150095_7691 a b) ∨ (fact_366edf150095_7718 a b))) ∨ ((((5 : Int) + (2 : Int)) ≤ ((2 : Int) + a)) ∧ (fact_366edf150095_7691 a b) ∧ (fact_366edf150095_7718 a b)) ∨ (((5 : Int) + (4 : Int)) ≤ ((2 : Int) + a)) ∨ ((((2 : Int) + a) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7691 a b) ∧ (fact_366edf150095_7718 a b) ∧ (((fact_366edf150095_4191 a b) ∨ (fact_366edf150095_3786 a b) ∨ (fact_366edf150095_5937 a b) ∨ (fact_366edf150095_6020 a b) ∨ (fact_366edf150095_3867 a b) ∨ (fact_366edf150095_4300 a b) ∨ (fact_366edf150095_3913 a b) ∨ (fact_366edf150095_6065 a b) ∨ (fact_366edf150095_4833 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((8 : Int) + a)) ∧ (((8 : Int) + a) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ ((8 : Int) + a)) ∧ ((4 : Int) ≥ ((8 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((8 : Int) + a)) ∧ (((8 : Int) + a) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((5 : Int) ≤ ((8 : Int) + a)) ∧ ((5 : Int) ≥ ((8 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (fact_366edf150095_5057 a b) ∨ (fact_366edf150095_5077 a b)) ∨ ((fact_366edf150095_5194 a b) ∨ (fact_366edf150095_4488 a b) ∨ (fact_366edf150095_6413 a b) ∨ (fact_366edf150095_6501 a b) ∨ (fact_366edf150095_4572 a b) ∨ (fact_366edf150095_5322 a b) ∨ (fact_366edf150095_4629 a b) ∨ (fact_366edf150095_6548 a b) ∨ (fact_366edf150095_5566 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((8 : Int) + a)) ∧ (((8 : Int) + a) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((4 : Int) ≤ ((8 : Int) + a)) ∧ ((4 : Int) ≥ ((8 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((8 : Int) + a)) ∧ (((8 : Int) + a) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((5 : Int) ≤ ((8 : Int) + a)) ∧ ((5 : Int) ≥ ((8 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (fact_366edf150095_5736 a b) ∨ (fact_366edf150095_5766 a b)))) ∨ ((fact_366edf150095_7691 a b) ∧ (fact_366edf150095_7718 a b) ∧ ((fact_366edf150095_4191 a b) ∨ (fact_366edf150095_3786 a b) ∨ (fact_366edf150095_5937 a b) ∨ (fact_366edf150095_6020 a b) ∨ (fact_366edf150095_3867 a b) ∨ (fact_366edf150095_4300 a b) ∨ (fact_366edf150095_3913 a b) ∨ (fact_366edf150095_6065 a b) ∨ (fact_366edf150095_4833 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((8 : Int) + a)) ∧ (((8 : Int) + a) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ ((8 : Int) + a)) ∧ ((4 : Int) ≥ ((8 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((8 : Int) + a)) ∧ (((8 : Int) + a) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((5 : Int) ≤ ((8 : Int) + a)) ∧ ((5 : Int) ≥ ((8 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (fact_366edf150095_5057 a b) ∨ (fact_366edf150095_5077 a b)) ∧ ((fact_366edf150095_5194 a b) ∨ (fact_366edf150095_4488 a b) ∨ (fact_366edf150095_6413 a b) ∨ (fact_366edf150095_6501 a b) ∨ (fact_366edf150095_4572 a b) ∨ (fact_366edf150095_5322 a b) ∨ (fact_366edf150095_4629 a b) ∨ (fact_366edf150095_6548 a b) ∨ (fact_366edf150095_5566 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((8 : Int) + a)) ∧ (((8 : Int) + a) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((4 : Int) ≤ ((8 : Int) + a)) ∧ ((4 : Int) ≥ ((8 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((8 : Int) + a)) ∧ (((8 : Int) + a) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((5 : Int) ≤ ((8 : Int) + a)) ∧ ((5 : Int) ≥ ((8 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (fact_366edf150095_5736 a b) ∨ (fact_366edf150095_5766 a b))))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h4
  clear h4
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n153_run_empty (a b run_x : Int)
    (h0 : ((5 : Int) ≤ run_x))
    (h1 : (run_x ≤ ((2 : Int) + a)))
    (h2 : ((fact_366edf150095_2383 a b run_x) ∨ (fact_366edf150095_2356 a b run_x) ∨ (fact_366edf150095_3628 a b run_x) ∨ (fact_366edf150095_3629 a b run_x) ∨ (fact_366edf150095_2357 a b run_x) ∨ (fact_366edf150095_3058 a b run_x) ∨ ((((8 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((2 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (2 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ ((((8 : Int) ≥ (((3 : Int) + ((2 : Int) * b)) - b)) ∧ ((8 : Int) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((8 : Int) ≥ ((3 : Int) + ((2 : Int) * b))) ∧ ((8 : Int) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ ((((8 : Int) ≥ ((3 : Int) - b)) ∧ ((8 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (3 : Int)) ∧ ((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ ((((8 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x)) ∨ (((5 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (5 : Int)) ∧ (((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a)))) ∨ ((((8 : Int) ≥ ((6 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((6 : Int) + b)) ∧ (((5 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a))) ∨ (((6 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (6 : Int)) ∧ ((((5 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((5 : Int) + a) + (0 : Int))))) ∨ ((((8 : Int) ≥ ((7 : Int) - (0 : Int))) ∧ ((8 : Int) ≤ ((7 : Int) + a)) ∧ (((5 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + b))) ∨ (((7 : Int) ≤ (8 : Int)) ∧ ((8 : Int) ≤ (7 : Int)) ∧ ((((5 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((5 : Int) + b) + (0 : Int)))))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n153_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3347 a b run_x) ∨ (fact_366edf150095_3296 a b run_x) ∨ (fact_366edf150095_5211 a b run_x) ∨ (fact_366edf150095_5221 a b run_x) ∨ (fact_366edf150095_3306 a b run_x) ∨ (fact_366edf150095_3526 a b run_x) ∨ (((((2 : Int) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((2 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - b) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x)) ∨ (((5 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a)))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((6 : Int) + b)) ∧ (((5 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a))) ∨ (((6 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((((5 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((5 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ ((8 : Int) - (1 : Int))) ∧ (((8 : Int) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ (((5 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + b))) ∨ (((7 : Int) ≤ ((8 : Int) - (1 : Int))) ∧ ((7 : Int) ≥ ((8 : Int) - (1 : Int))) ∧ ((((5 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((5 : Int) + b) + (0 : Int))))))))
    (h1 : (run_x ≤ ((2 : Int) + a)))
    (h2 : ((5 : Int) ≤ run_x))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n154_run_four (a b : Int)
    (h0 : (¬ ((6 : Int) ≤ ((3 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n154_run_short (a b : Int)
    (h0 : (¬ ((((3 : Int) + a) - (6 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n154_run_nonnegative (a b : Int)
    (h0 : (¬ ((6 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n154_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((((-1 : Int) - a) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - b) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((6 : Int) ≥ ((3 : Int) + a)) ∧ ((6 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((6 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + a)))) ∨ ((((((6 : Int) + b) - b) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ (((6 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int))) ∨ ((((6 : Int) + b) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + a)))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n154_run_right (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (¬ ((((((-1 : Int) - a) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((-1 : Int) ≥ (((3 : Int) + a) + (1 : Int))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((3 : Int) + a) + (1 : Int))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((6 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((3 : Int) + a) + (1 : Int))) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((6 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((3 : Int) + a) + (1 : Int))) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((6 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - b) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((6 : Int) ≥ ((3 : Int) + a)) ∧ ((6 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + a) + (1 : Int))) ∧ ((6 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((6 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + a) + (1 : Int))) ∧ ((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + a) + (1 : Int))) ∧ ((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + a)))) ∨ ((((((6 : Int) + b) - b) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ (((6 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int))) ∨ ((((6 : Int) + b) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + a)))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n154_run_tall (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a > b))
    (h4 : (¬ (((((6 : Int) + (3 : Int)) ≤ ((3 : Int) + a)) ∧ ((fact_366edf150095_7598 a b) ∨ (fact_366edf150095_7657 a b))) ∨ ((((6 : Int) + (2 : Int)) ≤ ((3 : Int) + a)) ∧ (fact_366edf150095_7598 a b) ∧ (fact_366edf150095_7657 a b)) ∨ (((6 : Int) + (4 : Int)) ≤ ((3 : Int) + a)) ∨ ((((3 : Int) + a) = ((6 : Int) + (1 : Int))) ∧ (fact_366edf150095_7598 a b) ∧ (fact_366edf150095_7657 a b) ∧ (((fact_366edf150095_4177 a b) ∨ (fact_366edf150095_3772 a b) ∨ (fact_366edf150095_5923 a b) ∨ (fact_366edf150095_6006 a b) ∨ (fact_366edf150095_3853 a b) ∨ (fact_366edf150095_4286 a b) ∨ (fact_366edf150095_3906 a b) ∨ (fact_366edf150095_6058 a b) ∨ (fact_366edf150095_4820 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a))) ∨ (((5 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + a)))) ∨ (fact_366edf150095_4400 a b)) ∨ ((fact_366edf150095_5136 a b) ∨ (fact_366edf150095_4430 a b) ∨ (fact_366edf150095_6355 a b) ∨ (fact_366edf150095_6443 a b) ∨ (fact_366edf150095_4514 a b) ∨ (fact_366edf150095_5264 a b) ∨ (fact_366edf150095_4594 a b) ∨ (fact_366edf150095_6521 a b) ∨ (fact_366edf150095_5531 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a))) ∨ (((4 : Int) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + a) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a))) ∨ (((5 : Int) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + a) + (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + a)))) ∨ ((((((6 : Int) + b) - b) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ (((6 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≥ ((6 : Int) + a))) ∨ ((((6 : Int) + b) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((6 : Int) + b)) ∧ (((5 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a))))))) ∨ ((fact_366edf150095_7598 a b) ∧ (fact_366edf150095_7657 a b) ∧ ((fact_366edf150095_4177 a b) ∨ (fact_366edf150095_3772 a b) ∨ (fact_366edf150095_5923 a b) ∨ (fact_366edf150095_6006 a b) ∨ (fact_366edf150095_3853 a b) ∨ (fact_366edf150095_4286 a b) ∨ (fact_366edf150095_3906 a b) ∨ (fact_366edf150095_6058 a b) ∨ (fact_366edf150095_4820 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a))) ∨ (((5 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + a)))) ∨ (fact_366edf150095_4400 a b)) ∧ ((fact_366edf150095_5136 a b) ∨ (fact_366edf150095_4430 a b) ∨ (fact_366edf150095_6355 a b) ∨ (fact_366edf150095_6443 a b) ∨ (fact_366edf150095_4514 a b) ∨ (fact_366edf150095_5264 a b) ∨ (fact_366edf150095_4594 a b) ∨ (fact_366edf150095_6521 a b) ∨ (fact_366edf150095_5531 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a))) ∨ (((4 : Int) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + a) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a))) ∨ (((5 : Int) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + a) + (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + a)))) ∨ ((((((6 : Int) + b) - b) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ (((6 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≥ ((6 : Int) + a))) ∨ ((((6 : Int) + b) ≤ (((3 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) + (1 : Int)) ≤ ((6 : Int) + b)) ∧ (((5 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a)))))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h4
  clear h4
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n154_run_empty (a b run_x : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + b) - b)) ∨ ((((6 : Int) + b) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (run_x ≤ ((3 : Int) + a)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((fact_366edf150095_2378 a b run_x) ∨ (fact_366edf150095_2313 a b run_x) ∨ (fact_366edf150095_3521 a b run_x) ∨ (fact_366edf150095_3536 a b run_x) ∨ (fact_366edf150095_2318 a b run_x) ∨ (fact_366edf150095_2960 a b run_x) ∨ (fact_366edf150095_2322 a b run_x) ∨ (fact_366edf150095_3540 a b run_x) ∨ (fact_366edf150095_3000 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((6 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ ((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + a)))) ∨ ((((((6 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((6 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int))) ∨ ((((6 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + b)) ∧ ((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + a))))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : ((6 : Int) ≤ run_x))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n154_run_floor (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((fact_366edf150095_3352 a b run_x) ∨ (fact_366edf150095_3301 a b run_x) ∨ (fact_366edf150095_5216 a b run_x) ∨ (fact_366edf150095_5226 a b run_x) ∨ (fact_366edf150095_3311 a b run_x) ∨ (fact_366edf150095_3531 a b run_x) ∨ (fact_366edf150095_3318 a b run_x) ∨ (fact_366edf150095_5233 a b run_x) ∨ (fact_366edf150095_3581 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((6 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int)))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ (((4 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + a)))) ∨ ((((((6 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((6 : Int) + b) + (0 : Int))) ∧ ((5 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((6 : Int) - (1 : Int)))) ∨ ((((6 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + b)) ∧ (((5 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((5 : Int) + a)))))))
    (h2 : ((6 : Int) ≤ run_x))
    (h3 : (run_x ≤ ((3 : Int) + a)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n155_point (a b : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (((0 : Int) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((0 : Int) > (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h4 : (¬ (((4 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ (((4 : Int) + b) ≥ (0 : Int)) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ (((4 : Int) + b) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n155_empty (a b : Int)
    (h0 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (((-1 : Int) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((-1 : Int) > (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h2 : (((((4 : Int) ≥ ((-1 : Int) - a)) ∧ ((4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ (((-1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ (((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((4 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((4 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ (((4 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((4 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((4 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((4 : Int) + b)) ∧ ((0 : Int) ≥ ((4 : Int) + b))) ∨ (((4 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((0 : Int) + b)))) ∨ ((((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((4 : Int) + b)) ∧ ((1 : Int) ≥ ((4 : Int) + b))) ∨ (((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((1 : Int) + b)))) ∨ ((((4 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((4 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((4 : Int) + b)) ∧ ((1 : Int) ≥ ((4 : Int) + b))) ∨ (((4 : Int) ≥ ((2 : Int) * a)) ∧ ((4 : Int) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((1 : Int) + a)))) ∨ ((((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≥ ((4 : Int) + b))) ∨ (((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((2 : Int) + a)))) ∨ ((((4 : Int) ≥ (((3 : Int) + ((2 : Int) * b)) - b)) ∧ ((4 : Int) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≥ ((4 : Int) + b))) ∨ (((4 : Int) ≥ ((3 : Int) + ((2 : Int) * b))) ∧ ((4 : Int) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((2 : Int) + a)))) ∨ ((((4 : Int) ≥ ((3 : Int) - b)) ∧ ((4 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((((3 : Int) + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((4 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((4 : Int) + b))) ∨ (((4 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((3 : Int) + b)))) ∨ ((((4 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≥ ((4 : Int) + b))) ∨ (((5 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (5 : Int)) ∧ (((4 : Int) - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((4 : Int) + a)))) ∨ ((((4 : Int) ≥ ((6 : Int) - b)) ∧ ((4 : Int) ≤ ((6 : Int) + (0 : Int))) ∧ (((5 : Int) + a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ ((5 : Int) + a))) ∨ (((6 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (6 : Int)) ∧ ((((5 : Int) + a) - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (((5 : Int) + a) + (0 : Int)))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((0 : Int) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((0 : Int) > (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n155_o0 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (((jx + a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < (jx - (0 : Int))) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h5 : (((jx + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jx - (0 : Int))) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h6 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (((jx + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h9 : (((5 : Int) > (jx + a)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h10 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ (jy ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (jy + b)))))
    (h11 : (((jx + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jx - (0 : Int))) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h12 : (a ≥ (5 : Int)))
    (h13 : (a ≥ b))
    (h14 : (a > b))
    (h15 : (a = (b + (2 : Int))))
    (h16 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n155_o1 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < (jy - a))))
    (h3 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ (jy ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((jy - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h7 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - a))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n155_o2 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - b))))
    (h2 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < (jy - b))))
    (h3 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((jy - b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (jy + (0 : Int))))))
    (h4 : (fact_366edf150095_2954 a b jy))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - a)) ∨ (jy < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h9 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : (a = (b + (2 : Int))))
    (h14 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n155_o3 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h1 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (jy + a)))))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h7 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h8 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n155_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((jy - a) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (jy + (0 : Int))))))
    (h5 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < (jy - a))))
    (h6 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - a))))
    (h7 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n155_o5 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h3 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - a)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h5 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h6 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (jy + b)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n155_o6 (a b jx jy : Int)
    (h0 : (((5 : Int) > (jx + b)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h1 : (((jx + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jx - (0 : Int))) ∨ ((1 : Int) > jy) ∨ ((1 : Int) < jy)))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ (jy ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (jy + a)))))
    (h6 : (((jx + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jx - (0 : Int))) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h7 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (((jx + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jx - (0 : Int))) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h10 : (((jx + b) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < (jx - (0 : Int))) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h11 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h12 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h13 : (a ≥ b))
    (h14 : (a > b))
    (h15 : (a = (b + (2 : Int))))
    (h16 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n155_o7 (a b jx jy : Int)
    (h0 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - b))))
    (h1 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ (jy ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((jy - b) ≤ ((4 : Int) + b)) ∧ (((4 : Int) + b) ≤ (jy + (0 : Int))))))
    (h6 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h7 : ((jx < ((6 : Int) - b)) ∨ (((6 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((5 : Int) + a)) ∨ (((5 : Int) + a) < (jy - b))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n156_point (a b : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : (fact_366edf150095_2138 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n156_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (a ≥ b))
    (h2 : ((fact_366edf150095_4132 a b) ∨ (fact_366edf150095_3727 a b) ∨ (fact_366edf150095_5878 a b) ∨ (fact_366edf150095_5961 a b) ∨ (fact_366edf150095_3808 a b) ∨ (fact_366edf150095_4241 a b) ∨ (fact_366edf150095_3878 a b) ∨ (fact_366edf150095_6031 a b) ∨ (fact_366edf150095_4779 a b) ∨ (fact_366edf150095_3977 a b) ∨ (fact_366edf150095_4029 a b) ∨ ((((((6 : Int) + a) - a) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ (((6 : Int) + a) + (0 : Int))) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ ((((6 : Int) + a) ≤ ((1 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) + ((2 : Int) * b)) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + b))))))
    (h3 : (a > b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n156_o0 (a b jx jy : Int)
    (h0 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h1 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : (fact_366edf150095_3210 a b jx jy))
    (h4 : (((jx + a) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h5 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((jx + a) < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h8 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h9 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h10 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h11 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h12 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h13 : (b ≥ (3 : Int)))
    (h14 : (a ≥ b))
    (h15 : (a > b))
    (h16 : (a = (b + (2 : Int))))
    (h17 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n156_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (¬ (((jx = ((1 : Int) + ((2 : Int) * b))) ∧ (jy = ((3 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : (fact_366edf150095_3213 a b jx jy))
    (h4 : (((jx + b) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n156_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (((jx + (0 : Int)) < ((6 : Int) + a)) ∨ (((6 : Int) + a) < (jx - a)) ∨ (jy < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : (fact_366edf150095_3215 a b jx jy))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - a)) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n156_o3 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (fact_366edf150095_3216 a b jx jy))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < (jx - b)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((jx + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n156_o4 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((jx + (0 : Int)) < ((6 : Int) + a)) ∨ (((6 : Int) + a) < (jx - b)) ∨ (jy < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jy)))
    (h3 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (fact_366edf150095_3217 a b jx jy))
    (h6 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n156_o5 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < (jx - a)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h2 : (((jx + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : (fact_366edf150095_3214 a b jx jy))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n156_o6 (a b jx jy : Int)
    (h0 : (fact_366edf150095_3212 a b jx jy))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jy - (0 : Int)))))
    (h10 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h11 : (((jx + b) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h12 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h13 : (((jx + b) < ((3 : Int) + ((2 : Int) * b))) ∨ (((3 : Int) + ((2 : Int) * b)) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h14 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h15 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h16 : (a ≥ b))
    (h17 : (a > b))
    (h18 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n156_o7 (a b jx jy : Int)
    (h0 : (((jx + a) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h1 : (fact_366edf150095_3211 a b jx jy))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n157_run_four (a b : Int)
    (h0 : (¬ (((2 : Int) + ((2 : Int) * b)) ≤ ((2 : Int) + ((2 : Int) * b)))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n157_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + ((2 : Int) * b)) - ((2 : Int) + ((2 : Int) * b))) < b)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n157_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n157_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5831 a b) ∨ (fact_366edf150095_5797 a b) ∨ (fact_366edf150095_6943 a b) ∨ (fact_366edf150095_6945 a b) ∨ (fact_366edf150095_5799 a b) ∨ (fact_366edf150095_5945 a b) ∨ (fact_366edf150095_5801 a b) ∨ (fact_366edf150095_6947 a b) ∨ (fact_366edf150095_6091 a b) ∨ (fact_366edf150095_5805 a b) ∨ (fact_366edf150095_5807 a b) ∨ ((((((6 : Int) + a) - a) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ (((6 : Int) + a) + (0 : Int))) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ ((((6 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_7007 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n157_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_5830 a b) ∨ (fact_366edf150095_5796 a b) ∨ (fact_366edf150095_6942 a b) ∨ (fact_366edf150095_6944 a b) ∨ (fact_366edf150095_5798 a b) ∨ (fact_366edf150095_5944 a b) ∨ (fact_366edf150095_5800 a b) ∨ (fact_366edf150095_6946 a b) ∨ (fact_366edf150095_6090 a b) ∨ (fact_366edf150095_5803 a b) ∨ (fact_366edf150095_5806 a b) ∨ ((((((6 : Int) + a) - a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((6 : Int) + a) + (0 : Int))) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ ((((6 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_7006 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n157_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (¬ ((((((2 : Int) + ((2 : Int) * b)) + (3 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((fact_366edf150095_7838 a b) ∨ (fact_366edf150095_7836 a b))) ∨ (((((2 : Int) + ((2 : Int) * b)) + (2 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (fact_366edf150095_7838 a b) ∧ (fact_366edf150095_7836 a b)) ∨ ((((2 : Int) + ((2 : Int) * b)) + (4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∨ ((((2 : Int) + ((2 : Int) * b)) = (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ (fact_366edf150095_7838 a b) ∧ (fact_366edf150095_7836 a b) ∧ (((fact_366edf150095_6144 a b) ∨ (fact_366edf150095_6072 a b) ∨ (fact_366edf150095_7004 a b) ∨ (fact_366edf150095_7012 a b) ∨ (fact_366edf150095_6076 a b) ∨ (fact_366edf150095_6422 a b) ∨ (fact_366edf150095_6080 a b) ∨ (fact_366edf150095_7016 a b) ∨ (fact_366edf150095_6599 a b) ∨ (fact_366edf150095_6097 a b) ∨ (fact_366edf150095_6106 a b) ∨ ((((((6 : Int) + a) - a) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ (((6 : Int) + a) + (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + a))) ∨ ((((6 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_7182 a b)) ∨ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6597 a b) ∨ (fact_366edf150095_6092 a b) ∨ (fact_366edf150095_6103 a b) ∨ ((((((6 : Int) + a) - a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((6 : Int) + a) + (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + a))) ∨ ((((6 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_7180 a b)))) ∨ ((fact_366edf150095_7838 a b) ∧ (fact_366edf150095_7836 a b) ∧ ((fact_366edf150095_6144 a b) ∨ (fact_366edf150095_6072 a b) ∨ (fact_366edf150095_7004 a b) ∨ (fact_366edf150095_7012 a b) ∨ (fact_366edf150095_6076 a b) ∨ (fact_366edf150095_6422 a b) ∨ (fact_366edf150095_6080 a b) ∨ (fact_366edf150095_7016 a b) ∨ (fact_366edf150095_6599 a b) ∨ (fact_366edf150095_6097 a b) ∨ (fact_366edf150095_6106 a b) ∨ ((((((6 : Int) + a) - a) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ (((6 : Int) + a) + (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + a))) ∨ ((((6 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) - (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_7182 a b)) ∧ ((fact_366edf150095_6142 a b) ∨ (fact_366edf150095_6070 a b) ∨ (fact_366edf150095_7002 a b) ∨ (fact_366edf150095_7010 a b) ∨ (fact_366edf150095_6074 a b) ∨ (fact_366edf150095_6420 a b) ∨ (fact_366edf150095_6078 a b) ∨ (fact_366edf150095_7014 a b) ∨ (fact_366edf150095_6597 a b) ∨ (fact_366edf150095_6092 a b) ∨ (fact_366edf150095_6103 a b) ∨ ((((((6 : Int) + a) - a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ (((6 : Int) + a) + (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + a)) ∧ ((5 : Int) ≥ ((3 : Int) + a))) ∨ ((((6 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * b)) + (1 : Int))) ∧ ((((2 : Int) + ((2 : Int) * b)) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_7180 a b))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n157_run_empty (a b run_x : Int)
    (h0 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2319 a b run_x) ∨ (fact_366edf150095_3537 a b run_x) ∨ (fact_366edf150095_2995 a b run_x) ∨ (fact_366edf150095_2330 a b run_x) ∨ (fact_366edf150095_2339 a b run_x) ∨ ((((((6 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((6 : Int) + a) + (0 : Int))) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (5 : Int))) ∨ ((((6 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_4212 a b run_x)))
    (h1 : (((2 : Int) + ((2 : Int) * b)) ≤ run_x))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((((6 : Int) + a) + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((5 : Int) < (((3 : Int) + a) - a)) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h4 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n157_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3315 a b run_x) ∨ (fact_366edf150095_5230 a b run_x) ∨ (fact_366edf150095_3578 a b run_x) ∨ (fact_366edf150095_3330 a b run_x) ∨ (fact_366edf150095_3340 a b run_x) ∨ ((((((6 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((6 : Int) + a) + (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((6 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ (((5 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((5 : Int) + b)))) ∨ (fact_366edf150095_5846 a b run_x))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((2 : Int) + ((2 : Int) * b)) ≤ run_x))
    (h3 : (((((6 : Int) + a) + (0 : Int)) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((5 : Int) < (((3 : Int) + a) - a)) ∨ ((5 : Int) > (((3 : Int) + a) + (0 : Int)))))
    (h4 : (run_x ≤ ((2 : Int) + ((2 : Int) * b))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n158_point (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (¬ ((((6 : Int) + b) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ (((6 : Int) + b) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n158_empty (a b : Int)
    (h0 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < ((2 : Int) * a)) ∨ ((5 : Int) > ((1 : Int) + a)) ∨ ((5 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((-1 : Int) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((-1 : Int) > (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h3 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : ((((((-1 : Int) - a) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ ((6 : Int) + b)) ∧ ((-1 : Int) ≥ ((6 : Int) + b)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ ((6 : Int) + b)) ∧ ((0 : Int) ≥ ((6 : Int) + b)) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ ((6 : Int) + b)) ∧ ((1 : Int) ≥ ((6 : Int) + b)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ ((2 : Int) * a)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ ((6 : Int) + b)) ∧ ((2 : Int) ≥ ((6 : Int) + b)) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - b) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ ((3 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ ((6 : Int) + b)) ∧ ((3 : Int) ≥ ((6 : Int) + b)) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ ((6 : Int) + b)) ∧ ((4 : Int) ≥ ((6 : Int) + b)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (4 : Int))) ∨ (((5 : Int) ≤ ((6 : Int) + b)) ∧ ((5 : Int) ≥ ((6 : Int) + b)) ∧ ((4 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((4 : Int) + a)))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ ((6 : Int) + b)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (5 : Int))) ∨ (((6 : Int) ≤ ((6 : Int) + b)) ∧ ((6 : Int) ≥ ((6 : Int) + b)) ∧ ((4 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((5 : Int) + a))))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((0 : Int) < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((0 : Int) > (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n158_o0 (a b jx jy : Int)
    (h0 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h1 : (((jx + a) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((5 : Int) > (jx + a)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < jy)))
    (h4 : ((((jx - (0 : Int)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ ((jx ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h5 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n158_o1 (a b jx jy : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - a))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((jx - (0 : Int)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ ((jx ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n158_o2 (a b jx jy : Int)
    (h0 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h1 : (fact_366edf150095_2954 a b jy))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((jx - a) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ ((jx ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n158_o3 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < (jx - b)) ∨ ((4 : Int) > jy) ∨ ((4 : Int) < jy)))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((((jx - b) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ ((jx ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h6 : (((jx + (0 : Int)) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n158_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < jy)))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : ((((jx - b) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ ((jx ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n158_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((((jx - a) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ ((jx ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h4 : (((jx + (0 : Int)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < (jx - a)) ∨ ((4 : Int) > jy) ∨ ((4 : Int) < jy)))
    (h5 : (((jx + (0 : Int)) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((5 : Int) > (jy + b)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h9 : (((jx + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jx - a)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h10 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n158_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((5 : Int) > (jy + a)) ∨ ((5 : Int) < (jy - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : ((((jx - (0 : Int)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ ((jx ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n158_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < ((3 : Int) + ((2 : Int) * b))) ∨ ((5 : Int) > ((2 : Int) + a)) ∨ ((5 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : (fact_366edf150095_2955 a b jy))
    (h3 : ((((jx - (0 : Int)) ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ ((jx ≤ ((6 : Int) + b)) ∧ (((6 : Int) + b) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((5 : Int) > (jy + (0 : Int))) ∨ ((5 : Int) < (jy - b))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n159_run_four (a b : Int)
    (h0 : (¬ ((5 : Int) ≤ ((2 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n159_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + a) - (5 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n159_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n159_run_left (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_366edf150095_3515 a b) ∨ (fact_366edf150095_3490 a b) ∨ (fact_366edf150095_5823 a b) ∨ (fact_366edf150095_5826 a b) ∨ (fact_366edf150095_3493 a b) ∨ (fact_366edf150095_4099 a b) ∨ (fact_366edf150095_3494 a b) ∨ (fact_366edf150095_5827 a b) ∨ ((((7 : Int) ≥ ((3 : Int) - b)) ∧ ((7 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((((3 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((7 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ ((((7 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((5 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (5 : Int)) ∧ (((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (fact_366edf150095_4108 a b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n159_run_right (a b : Int)
    (h0 : (¬ (((((7 : Int) ≥ ((-1 : Int) - a)) ∧ ((7 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((7 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((0 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((7 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((7 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((7 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((7 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((7 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((7 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((7 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((7 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((7 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((1 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((7 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((7 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((7 : Int) ≥ ((2 : Int) * a)) ∧ ((7 : Int) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((7 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((2 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (2 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((7 : Int) ≥ (((3 : Int) + ((2 : Int) * b)) - b)) ∧ ((7 : Int) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((7 : Int) ≥ ((3 : Int) + ((2 : Int) * b))) ∧ ((7 : Int) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ ((((7 : Int) ≥ ((3 : Int) - b)) ∧ ((7 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((((3 : Int) + a) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((7 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((4 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ ((((7 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((5 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (5 : Int)) ∧ (((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a)))) ∨ ((((7 : Int) ≥ ((6 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((6 : Int) + a)) ∧ (((5 : Int) + b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((5 : Int) + b))) ∨ (((6 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (6 : Int)) ∧ ((((5 : Int) + b) - b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((5 : Int) + b) + (0 : Int))))))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n159_run_tall (a b : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : (¬ (((((5 : Int) + (3 : Int)) ≤ ((2 : Int) + a)) ∧ ((fact_366edf150095_7600 a b) ∨ (fact_366edf150095_7659 a b))) ∨ ((((5 : Int) + (2 : Int)) ≤ ((2 : Int) + a)) ∧ (fact_366edf150095_7600 a b) ∧ (fact_366edf150095_7659 a b)) ∨ (((5 : Int) + (4 : Int)) ≤ ((2 : Int) + a)) ∨ ((((2 : Int) + a) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7600 a b) ∧ (fact_366edf150095_7659 a b) ∧ (((fact_366edf150095_4181 a b) ∨ (fact_366edf150095_3776 a b) ∨ (fact_366edf150095_5927 a b) ∨ (fact_366edf150095_6010 a b) ∨ (fact_366edf150095_3857 a b) ∨ (fact_366edf150095_4290 a b) ∨ (fact_366edf150095_3908 a b) ∨ (fact_366edf150095_6060 a b) ∨ (fact_366edf150095_4822 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ ((7 : Int) + a)) ∧ ((4 : Int) ≥ ((7 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((5 : Int) ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≥ ((7 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (fact_366edf150095_5047 a b)) ∨ ((fact_366edf150095_5187 a b) ∨ (fact_366edf150095_4481 a b) ∨ (fact_366edf150095_6406 a b) ∨ (fact_366edf150095_6494 a b) ∨ (fact_366edf150095_4565 a b) ∨ (fact_366edf150095_5315 a b) ∨ (fact_366edf150095_4625 a b) ∨ (fact_366edf150095_6544 a b) ∨ (fact_366edf150095_5561 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((4 : Int) ≤ ((7 : Int) + a)) ∧ ((4 : Int) ≥ ((7 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((5 : Int) ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≥ ((7 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (fact_366edf150095_5729 a b)))) ∨ ((fact_366edf150095_7600 a b) ∧ (fact_366edf150095_7659 a b) ∧ ((fact_366edf150095_4181 a b) ∨ (fact_366edf150095_3776 a b) ∨ (fact_366edf150095_5927 a b) ∨ (fact_366edf150095_6010 a b) ∨ (fact_366edf150095_3857 a b) ∨ (fact_366edf150095_4290 a b) ∨ (fact_366edf150095_3908 a b) ∨ (fact_366edf150095_6060 a b) ∨ (fact_366edf150095_4822 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ ((7 : Int) + a)) ∧ ((4 : Int) ≥ ((7 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((5 : Int) ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≥ ((7 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (fact_366edf150095_5047 a b)) ∧ ((fact_366edf150095_5187 a b) ∨ (fact_366edf150095_4481 a b) ∨ (fact_366edf150095_6406 a b) ∨ (fact_366edf150095_6494 a b) ∨ (fact_366edf150095_4565 a b) ∨ (fact_366edf150095_5315 a b) ∨ (fact_366edf150095_4625 a b) ∨ (fact_366edf150095_6544 a b) ∨ (fact_366edf150095_5561 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((4 : Int) ≤ ((7 : Int) + a)) ∧ ((4 : Int) ≥ ((7 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((7 : Int) + a)) ∧ (((7 : Int) + a) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int)))) ∨ (((5 : Int) ≤ ((7 : Int) + a)) ∧ ((5 : Int) ≥ ((7 : Int) + a)) ∧ (((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + a)))) ∨ (fact_366edf150095_5729 a b))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a > b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n159_run_empty (a b run_x : Int)
    (h0 : ((fact_366edf150095_2382 a b run_x) ∨ (fact_366edf150095_2352 a b run_x) ∨ (fact_366edf150095_3625 a b run_x) ∨ (fact_366edf150095_3626 a b run_x) ∨ (fact_366edf150095_2353 a b run_x) ∨ (fact_366edf150095_3052 a b run_x) ∨ (fact_366edf150095_2354 a b run_x) ∨ (fact_366edf150095_3627 a b run_x) ∨ (fact_366edf150095_3054 a b run_x) ∨ ((((7 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ ((((7 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x)) ∨ (((5 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (5 : Int)) ∧ (((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a)))) ∨ (fact_366edf150095_3057 a b run_x)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((5 : Int) ≤ run_x))
    (h4 : (run_x ≤ ((2 : Int) + a)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n159_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((2 : Int) + a)))
    (h1 : (¬ ((fact_366edf150095_3346 a b run_x) ∨ (fact_366edf150095_3295 a b run_x) ∨ (fact_366edf150095_5210 a b run_x) ∨ (fact_366edf150095_5220 a b run_x) ∨ (fact_366edf150095_3305 a b run_x) ∨ (fact_366edf150095_3525 a b run_x) ∨ (fact_366edf150095_3314 a b run_x) ∨ (fact_366edf150095_5229 a b run_x) ∨ (fact_366edf150095_3574 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((5 : Int) + b)) ∧ ((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x)) ∨ (((5 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + a)))) ∨ (fact_366edf150095_3606 a b run_x))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((5 : Int) ≤ run_x))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n160_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((4 : Int) ≤ ((1 : Int) + a))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n160_run_short (a b : Int)
    (h0 : (¬ ((((1 : Int) + a) - (4 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n160_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n160_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3512 a b) ∨ (fact_366edf150095_3482 a b) ∨ (fact_366edf150095_5817 a b) ∨ (fact_366edf150095_5819 a b) ∨ (fact_366edf150095_3484 a b) ∨ (fact_366edf150095_4084 a b) ∨ (fact_366edf150095_3485 a b) ∨ (fact_366edf150095_5820 a b) ∨ ((((6 : Int) ≥ ((3 : Int) - b)) ∧ ((6 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((((3 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_4095 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n160_run_right (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (¬ ((fact_366edf150095_4209 a b) ∨ (fact_366edf150095_4090 a b) ∨ (fact_366edf150095_6120 a b) ∨ (fact_366edf150095_6121 a b) ∨ (fact_366edf150095_4091 a b) ∨ (fact_366edf150095_5103 a b) ∨ (fact_366edf150095_4092 a b) ∨ (fact_366edf150095_6122 a b) ∨ ((((6 : Int) ≥ ((3 : Int) - b)) ∧ ((6 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((((3 : Int) + a) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_5105 a b))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n160_run_tall (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ (((1 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h2 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_366edf150095_7508 a b) ∨ (fact_366edf150095_7582 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ (fact_366edf150095_7508 a b) ∧ (fact_366edf150095_7582 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = ((4 : Int) + (1 : Int))) ∧ (fact_366edf150095_7508 a b) ∧ (fact_366edf150095_7582 a b) ∧ (((fact_366edf150095_4165 a b) ∨ (fact_366edf150095_3760 a b) ∨ (fact_366edf150095_5911 a b) ∨ (fact_366edf150095_5994 a b) ∨ (fact_366edf150095_3841 a b) ∨ (fact_366edf150095_4274 a b) ∨ (fact_366edf150095_3897 a b) ∨ (fact_366edf150095_6049 a b) ∨ (fact_366edf150095_4803 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_4995 a b)) ∨ ((fact_366edf150095_5180 a b) ∨ (fact_366edf150095_4474 a b) ∨ (fact_366edf150095_6399 a b) ∨ (fact_366edf150095_6487 a b) ∨ (fact_366edf150095_4558 a b) ∨ (fact_366edf150095_5308 a b) ∨ (fact_366edf150095_4621 a b) ∨ (fact_366edf150095_6540 a b) ∨ (fact_366edf150095_5556 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_5677 a b)))) ∨ ((fact_366edf150095_7508 a b) ∧ (fact_366edf150095_7582 a b) ∧ ((fact_366edf150095_4165 a b) ∨ (fact_366edf150095_3760 a b) ∨ (fact_366edf150095_5911 a b) ∨ (fact_366edf150095_5994 a b) ∨ (fact_366edf150095_3841 a b) ∨ (fact_366edf150095_4274 a b) ∨ (fact_366edf150095_3897 a b) ∨ (fact_366edf150095_6049 a b) ∨ (fact_366edf150095_4803 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_4995 a b)) ∧ ((fact_366edf150095_5180 a b) ∨ (fact_366edf150095_4474 a b) ∨ (fact_366edf150095_6399 a b) ∨ (fact_366edf150095_6487 a b) ∨ (fact_366edf150095_4558 a b) ∨ (fact_366edf150095_5308 a b) ∨ (fact_366edf150095_4621 a b) ∨ (fact_366edf150095_6540 a b) ∨ (fact_366edf150095_5556 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) + (1 : Int)))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_5677 a b))))))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n160_run_empty (a b run_x : Int)
    (h0 : ((fact_366edf150095_2381 a b run_x) ∨ (fact_366edf150095_2347 a b run_x) ∨ (fact_366edf150095_3622 a b run_x) ∨ (fact_366edf150095_3623 a b run_x) ∨ (fact_366edf150095_2348 a b run_x) ∨ (fact_366edf150095_3045 a b run_x) ∨ (fact_366edf150095_2349 a b run_x) ∨ (fact_366edf150095_3624 a b run_x) ∨ (fact_366edf150095_3048 a b run_x) ∨ ((((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_3051 a b run_x)))
    (h1 : (run_x ≤ ((1 : Int) + a)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((4 : Int) ≤ run_x))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n160_run_floor (a b run_x : Int)
    (h0 : ((4 : Int) ≤ run_x))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (run_x ≤ ((1 : Int) + a)))
    (h3 : (¬ ((fact_366edf150095_3345 a b run_x) ∨ (fact_366edf150095_3294 a b run_x) ∨ (fact_366edf150095_5209 a b run_x) ∨ (fact_366edf150095_5219 a b run_x) ∨ (fact_366edf150095_3304 a b run_x) ∨ (fact_366edf150095_3524 a b run_x) ∨ (fact_366edf150095_3313 a b run_x) ∨ (fact_366edf150095_5228 a b run_x) ∨ (fact_366edf150095_3573 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + a)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_3596 a b run_x))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n161_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((5 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((5 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n161_empty (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((fact_366edf150095_2904 a b) ∨ (fact_366edf150095_2576 a b) ∨ (fact_366edf150095_4065 a b) ∨ (fact_366edf150095_4070 a b) ∨ (fact_366edf150095_2579 a b) ∨ (fact_366edf150095_3179 a b) ∨ ((((5 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ ((((5 : Int) ≥ (((3 : Int) + ((2 : Int) * b)) - b)) ∧ ((5 : Int) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((5 : Int) ≥ ((3 : Int) + ((2 : Int) * b))) ∧ ((5 : Int) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ ((((5 : Int) ≥ ((3 : Int) - b)) ∧ ((5 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3189 a b)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n161_o0 (a b jx jy : Int)
    (h0 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h1 : (¬ ((((5 : Int) = jx) ∧ ((3 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : (((4 : Int) > (jx + a)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n161_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - a))))
    (h5 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n161_o2 (a b jx jy : Int)
    (h0 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h3 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - b))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (fact_366edf150095_2954 a b jy))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n161_o3 (a b jx jy : Int)
    (h0 : (¬ (((jx = ((5 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h5 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n161_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((((5 : Int) ≥ (jx - b)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n161_o5 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((5 : Int) ≥ (jx - a)) ∧ ((5 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h4 : (¬ (((jx = ((5 : Int) + a)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n161_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((jy + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : (((4 : Int) > (jx + b)) ∨ ((4 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h6 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n161_o7 (a b jx jy : Int)
    (h0 : (¬ ((((5 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h1 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (fact_366edf150095_2955 a b jy))
    (h4 : ((((5 : Int) ≥ (jx - (0 : Int))) ∧ ((5 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((5 : Int) ≥ jx) ∧ ((5 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n162_point (a b : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (¬ (((6 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((6 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n162_empty (a b : Int)
    (h0 : ((fact_366edf150095_2908 a b) ∨ (fact_366edf150095_2588 a b) ∨ (fact_366edf150095_4081 a b) ∨ (fact_366edf150095_4086 a b) ∨ (fact_366edf150095_2591 a b) ∨ (fact_366edf150095_3193 a b) ∨ (fact_366edf150095_2593 a b) ∨ (fact_366edf150095_4088 a b) ∨ (fact_366edf150095_3201 a b) ∨ ((((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((6 : Int) ≥ ((5 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ (((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + b))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n162_o0 (a b jx jy : Int)
    (h0 : (¬ ((((6 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((5 : Int) > (jx + a)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n162_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h7 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - a))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n162_o2 (a b jx jy : Int)
    (h0 : ((((6 : Int) ≥ (jx - a)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h5 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n162_o3 (a b jx jy : Int)
    (h0 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h1 : ((((6 : Int) ≥ (jx - b)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h5 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h6 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h7 : (¬ (((jx = ((6 : Int) + b)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n162_o4 (a b jx jy : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - a))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : ((((6 : Int) ≥ (jx - b)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n162_o5 (a b jx jy : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((((6 : Int) ≥ (jx - a)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (¬ (((jx = ((6 : Int) + a)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n162_o6 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h4 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((jy + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h5 : (((5 : Int) > (jx + b)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jy)))
    (h6 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    (h12 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n162_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (¬ ((((6 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h2 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n163_run_four (a b : Int)
    (h0 : (¬ ((5 : Int) ≤ (5 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n163_run_short (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((5 : Int) - (5 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n163_run_nonnegative (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((-2 : Int) + ((-1 : Int) * a)) ≤ (0 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n163_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((((-1 : Int) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) * a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((3 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((5 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + b)))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((4 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((6 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + b)))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n163_run_right (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((((-1 : Int) - a) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-1 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((0 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((1 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) * a) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((2 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - b) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((3 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((5 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((5 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + b)))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((4 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((6 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + b)))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n163_run_tall (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((5 : Int) ≥ ((5 : Int) + (3 : Int))) ∧ ((fact_366edf150095_7808 a b) ∨ (fact_366edf150095_7807 a b))) ∨ (((5 : Int) ≥ ((5 : Int) + (2 : Int))) ∧ (fact_366edf150095_7808 a b) ∧ (fact_366edf150095_7807 a b)) ∨ ((5 : Int) ≥ ((5 : Int) + (4 : Int))) ∨ (((5 : Int) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7808 a b) ∧ (fact_366edf150095_7807 a b) ∧ (((fact_366edf150095_6591 a b) ∨ (fact_366edf150095_6233 a b) ∨ (fact_366edf150095_7088 a b) ∨ (fact_366edf150095_7122 a b) ∨ (fact_366edf150095_6263 a b) ∨ (fact_366edf150095_6777 a b) ∨ (fact_366edf150095_6277 a b) ∨ (fact_366edf150095_7137 a b) ∨ (fact_366edf150095_6833 a b) ∨ (fact_366edf150095_6845 a b) ∨ (fact_366edf150095_6327 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((4 : Int) ≥ (-(((-2 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((6 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) + a)) ≤ ((4 : Int) + b))))) ∨ ((fact_366edf150095_6586 a b) ∨ (fact_366edf150095_6228 a b) ∨ (fact_366edf150095_7083 a b) ∨ (fact_366edf150095_7117 a b) ∨ (fact_366edf150095_6258 a b) ∨ (fact_366edf150095_6772 a b) ∨ (fact_366edf150095_6274 a b) ∨ (fact_366edf150095_7134 a b) ∨ (fact_366edf150095_6829 a b) ∨ (fact_366edf150095_6840 a b) ∨ (fact_366edf150095_6322 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((4 : Int) ≥ (-(((-2 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((6 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) + a)) ≤ ((4 : Int) + b))))))) ∨ ((fact_366edf150095_7808 a b) ∧ (fact_366edf150095_7807 a b) ∧ ((fact_366edf150095_6591 a b) ∨ (fact_366edf150095_6233 a b) ∨ (fact_366edf150095_7088 a b) ∨ (fact_366edf150095_7122 a b) ∨ (fact_366edf150095_6263 a b) ∨ (fact_366edf150095_6777 a b) ∨ (fact_366edf150095_6277 a b) ∨ (fact_366edf150095_7137 a b) ∨ (fact_366edf150095_6833 a b) ∨ (fact_366edf150095_6845 a b) ∨ (fact_366edf150095_6327 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((4 : Int) ≥ (-(((-2 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((6 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) + a)) ≤ ((4 : Int) + b))))) ∧ ((fact_366edf150095_6586 a b) ∨ (fact_366edf150095_6228 a b) ∨ (fact_366edf150095_7083 a b) ∨ (fact_366edf150095_7117 a b) ∨ (fact_366edf150095_6258 a b) ∨ (fact_366edf150095_6772 a b) ∨ (fact_366edf150095_6274 a b) ∨ (fact_366edf150095_7134 a b) ∨ (fact_366edf150095_6829 a b) ∨ (fact_366edf150095_6840 a b) ∨ (fact_366edf150095_6322 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((4 : Int) ≥ (-(((-2 : Int) + ((-1 : Int) * a)) + a)))) ∨ (((6 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((4 : Int) - (0 : Int)) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) + a)) ≤ ((4 : Int) + b)))))))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : (a > b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n163_run_empty (a b run_x : Int)
    (h0 : ((((-1 : Int) + (0 : Int)) < (((1 : Int) + ((2 : Int) * a)) - a)) ∨ ((((1 : Int) + ((2 : Int) * a)) + (0 : Int)) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((5 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((5 : Int) ≥ run_x))
    (h6 : ((fact_366edf150095_4215 a b run_x) ∨ (fact_366edf150095_4200 a b run_x) ∨ (fact_366edf150095_6129 a b run_x) ∨ (fact_366edf150095_6135 a b run_x) ∨ (fact_366edf150095_4203 a b run_x) ∨ (fact_366edf150095_5116 a b run_x) ∨ (fact_366edf150095_4205 a b run_x) ∨ (fact_366edf150095_6137 a b run_x) ∨ (((((3 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((((3 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ (((3 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((3 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + b)))) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((4 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ (((4 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + b))))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n163_run_floor (a b run_x : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (¬ ((fact_366edf150095_5849 a b run_x) ∨ (fact_366edf150095_5834 a b run_x) ∨ (fact_366edf150095_6957 a b run_x) ∨ (fact_366edf150095_6960 a b run_x) ∨ (fact_366edf150095_5837 a b run_x) ∨ (fact_366edf150095_6132 a b run_x) ∨ (fact_366edf150095_5838 a b run_x) ∨ (fact_366edf150095_6961 a b run_x) ∨ (((((3 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((3 : Int) + a))) ∨ (fact_366edf150095_670 a run_x)) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ (((3 : Int) + a) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((3 : Int) + a))) ∨ (fact_366edf150095_680 a run_x)) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((3 : Int) ≥ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((3 : Int) + b)))) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((4 : Int) ≥ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ (((4 : Int) - (0 : Int)) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((4 : Int) + b)))))))
    (h2 : ((5 : Int) ≤ run_x))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : ((5 : Int) ≥ run_x))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n164_run_four (a b : Int)
    (h0 : (¬ ((6 : Int) ≤ ((5 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n164_run_short (a b : Int)
    (h0 : (¬ ((((5 : Int) + b) - (6 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n164_run_nonnegative (a b : Int)
    (h0 : (¬ ((5 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n164_run_left (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_366edf150095_3506 a b) ∨ (fact_366edf150095_3455 a b) ∨ (fact_366edf150095_5782 a b) ∨ (fact_366edf150095_5790 a b) ∨ (fact_366edf150095_3463 a b) ∨ (fact_366edf150095_3701 a b) ∨ (fact_366edf150095_3468 a b) ∨ (fact_366edf150095_5795 a b) ∨ (fact_366edf150095_3973 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((5 : Int) ≥ ((3 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((5 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_3710 a b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n164_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4130 a b) ∨ (fact_366edf150095_3725 a b) ∨ (fact_366edf150095_5876 a b) ∨ (fact_366edf150095_5959 a b) ∨ (fact_366edf150095_3806 a b) ∨ (fact_366edf150095_4239 a b) ∨ (fact_366edf150095_3877 a b) ∨ (fact_366edf150095_6030 a b) ∨ (((((3 : Int) - b) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((5 : Int) ≥ ((3 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((5 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_4395 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n164_run_tall (a b : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + b) - b)) ∨ ((((6 : Int) + b) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : (a > b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (¬ (((((6 : Int) + (3 : Int)) ≤ ((5 : Int) + b)) ∧ ((fact_366edf150095_7606 a b) ∨ (fact_366edf150095_7669 a b))) ∨ ((((6 : Int) + (2 : Int)) ≤ ((5 : Int) + b)) ∧ (fact_366edf150095_7606 a b) ∧ (fact_366edf150095_7669 a b)) ∨ (((6 : Int) + (4 : Int)) ≤ ((5 : Int) + b)) ∨ ((((5 : Int) + b) = ((6 : Int) + (1 : Int))) ∧ (fact_366edf150095_7606 a b) ∧ (fact_366edf150095_7669 a b) ∧ (((fact_366edf150095_4175 a b) ∨ (fact_366edf150095_3770 a b) ∨ (fact_366edf150095_5921 a b) ∨ (fact_366edf150095_6004 a b) ∨ (fact_366edf150095_3851 a b) ∨ (fact_366edf150095_4284 a b) ∨ (fact_366edf150095_3904 a b) ∨ (fact_366edf150095_6056 a b) ∨ (fact_366edf150095_4818 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ (((5 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_4398 a b)) ∨ ((fact_366edf150095_5153 a b) ∨ (fact_366edf150095_4447 a b) ∨ (fact_366edf150095_6372 a b) ∨ (fact_366edf150095_6460 a b) ∨ (fact_366edf150095_4531 a b) ∨ (fact_366edf150095_5281 a b) ∨ (fact_366edf150095_4606 a b) ∨ (fact_366edf150095_6531 a b) ∨ (fact_366edf150095_5546 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ (((5 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_5412 a b)))) ∨ ((fact_366edf150095_7606 a b) ∧ (fact_366edf150095_7669 a b) ∧ ((fact_366edf150095_4175 a b) ∨ (fact_366edf150095_3770 a b) ∨ (fact_366edf150095_5921 a b) ∨ (fact_366edf150095_6004 a b) ∨ (fact_366edf150095_3851 a b) ∨ (fact_366edf150095_4284 a b) ∨ (fact_366edf150095_3904 a b) ∨ (fact_366edf150095_6056 a b) ∨ (fact_366edf150095_4818 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ (((5 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_4398 a b)) ∧ ((fact_366edf150095_5153 a b) ∨ (fact_366edf150095_4447 a b) ∨ (fact_366edf150095_6372 a b) ∨ (fact_366edf150095_6460 a b) ∨ (fact_366edf150095_4531 a b) ∨ (fact_366edf150095_5281 a b) ∨ (fact_366edf150095_4606 a b) ∨ (fact_366edf150095_6531 a b) ∨ (fact_366edf150095_5546 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((3 : Int) + a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a))) ∨ (((5 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_5412 a b))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n164_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((6 : Int) ≤ run_x))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : (run_x ≤ ((5 : Int) + b)))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : ((fact_366edf150095_2377 a b run_x) ∨ (fact_366edf150095_2312 a b run_x) ∨ (fact_366edf150095_3520 a b run_x) ∨ (fact_366edf150095_3535 a b run_x) ∨ (fact_366edf150095_2317 a b run_x) ∨ (fact_366edf150095_2959 a b run_x) ∨ (fact_366edf150095_2321 a b run_x) ∨ (fact_366edf150095_3539 a b run_x) ∨ (fact_366edf150095_2999 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ ((5 : Int) ≥ ((3 : Int) + a)) ∧ ((5 : Int) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((5 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((5 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ ((5 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_2976 a b run_x)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n164_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((5 : Int) + b)))
    (h1 : ((6 : Int) ≤ run_x))
    (h2 : (¬ ((fact_366edf150095_3351 a b run_x) ∨ (fact_366edf150095_3300 a b run_x) ∨ (fact_366edf150095_5215 a b run_x) ∨ (fact_366edf150095_5225 a b run_x) ∨ (fact_366edf150095_3310 a b run_x) ∨ (fact_366edf150095_3530 a b run_x) ∨ (fact_366edf150095_3317 a b run_x) ∨ (fact_366edf150095_5232 a b run_x) ∨ (fact_366edf150095_3580 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ (((3 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((3 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int)))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))) ∨ (fact_366edf150095_3556 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n165_point (a b : Int)
    (h0 : (¬ ((((6 : Int) + a) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ (((6 : Int) + a) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n165_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : (a ≥ b))
    (h3 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : ((((-1 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) + a) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((4 : Int) > ((1 : Int) + a)) ∨ ((4 : Int) < ((1 : Int) - (0 : Int)))))
    (h7 : ((((((-1 : Int) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ ((6 : Int) + a)) ∧ ((-1 : Int) ≥ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ ((6 : Int) + a)) ∧ ((0 : Int) ≥ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ ((6 : Int) + a)) ∧ ((1 : Int) ≥ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) * a)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - b) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((3 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((6 : Int) + a)) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (3 : Int))) ∨ (((5 : Int) ≤ ((6 : Int) + a)) ∧ ((5 : Int) ≥ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((3 : Int) + b)))) ∨ ((((((6 : Int) + a) - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (((6 : Int) + a) + (0 : Int))) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (4 : Int))) ∨ ((((6 : Int) + a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) + b))))))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n165_o0 (a b jx jy : Int)
    (h0 : ((((jx - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ ((jx ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + b)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n165_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((jx - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ ((jx ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n165_o2 (a b jx jy : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - b))))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : ((((jx - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ ((jx ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n165_o3 (a b jx jy : Int)
    (h0 : ((((jx - b) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ ((jx ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h1 : (((4 : Int) > jx) ∨ ((4 : Int) < jx) ∨ ((jy + a) < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h2 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h3 : ((jx < ((6 : Int) + a)) ∨ (((6 : Int) + a) < jx) ∨ ((jy + a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h8 : (((jx + (0 : Int)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < (jx - b)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h9 : (((jx + (0 : Int)) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h10 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h11 : (b ≥ (3 : Int)))
    (h12 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h13 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h14 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h15 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < (jy - (0 : Int)))))
    (h16 : (a ≥ b))
    (h17 : (a > b))
    (h18 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n165_o4 (a b jx jy : Int)
    (h0 : ((((jx - b) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ ((jx ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + (0 : Int))) ∨ ((4 : Int) < (jy - a))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n165_o5 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h1 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : ((((jx - a) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ ((jx ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((jx + (0 : Int)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < (jx - a)) ∨ ((3 : Int) > jy) ∨ ((3 : Int) < jy)))
    (h8 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h9 : ((jx < (((3 : Int) + ((2 : Int) * b)) - b)) ∨ ((((3 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n165_o6 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h3 : ((jx < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < jx) ∨ ((4 : Int) > (jy + a)) ∨ ((4 : Int) < (jy - (0 : Int)))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : ((((jx - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ ((jx ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n165_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((3 : Int) + ((2 : Int) * b)) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((3 : Int) + ((2 : Int) * b))) ∨ ((4 : Int) > ((2 : Int) + a)) ∨ ((4 : Int) < ((2 : Int) - (0 : Int)))))
    (h2 : ((((jx - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ ((jx ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (((jx + a) < ((6 : Int) + a)) ∨ (((6 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jy)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n166_run_four (a b : Int)
    (h0 : (¬ ((5 : Int) ≤ (5 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n166_run_short (a b : Int)
    (h0 : (¬ (((5 : Int) - (5 : Int)) < b)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n166_run_nonnegative (a b : Int)
    (h0 : (¬ (((-2 : Int) + ((-1 : Int) * a)) ≤ (0 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n166_run_left (a b : Int)
    (h0 : (¬ ((((((-1 : Int) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((0 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((1 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) * a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((2 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((3 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((5 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + b)))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ (((4 : Int) + b) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + b))) ∨ (((6 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((4 : Int) + b) - b) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n166_run_right (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ ((((((-1 : Int) - a) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((-1 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((0 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((0 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((0 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((1 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((1 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((1 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((2 : Int) * a) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((2 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((2 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((2 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - b) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ (((3 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((5 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((5 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + b)))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ (((4 : Int) + b) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + b))) ∨ (((6 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ ((((4 : Int) + b) - b) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n166_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ ((((5 : Int) ≥ ((5 : Int) + (3 : Int))) ∧ ((fact_366edf150095_7813 a b) ∨ (fact_366edf150095_7812 a b))) ∨ (((5 : Int) ≥ ((5 : Int) + (2 : Int))) ∧ (fact_366edf150095_7813 a b) ∧ (fact_366edf150095_7812 a b)) ∨ ((5 : Int) ≥ ((5 : Int) + (4 : Int))) ∨ (((5 : Int) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7813 a b) ∧ (fact_366edf150095_7812 a b) ∧ (((fact_366edf150095_6591 a b) ∨ (fact_366edf150095_6233 a b) ∨ (fact_366edf150095_7088 a b) ∨ (fact_366edf150095_7122 a b) ∨ (fact_366edf150095_6263 a b) ∨ (fact_366edf150095_6777 a b) ∨ (fact_366edf150095_6277 a b) ∨ (fact_366edf150095_7137 a b) ∨ (fact_366edf150095_6833 a b) ∨ (fact_366edf150095_6845 a b) ∨ (fact_366edf150095_6327 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ (((4 : Int) + b) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) + a)) ≤ ((4 : Int) + b))) ∨ (((6 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((4 : Int) + b) - b) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) + a)) ≤ (((4 : Int) + b) + (0 : Int)))))) ∨ ((fact_366edf150095_6586 a b) ∨ (fact_366edf150095_6228 a b) ∨ (fact_366edf150095_7083 a b) ∨ (fact_366edf150095_7117 a b) ∨ (fact_366edf150095_6258 a b) ∨ (fact_366edf150095_6772 a b) ∨ (fact_366edf150095_6274 a b) ∨ (fact_366edf150095_7134 a b) ∨ (fact_366edf150095_6829 a b) ∨ (fact_366edf150095_6840 a b) ∨ (fact_366edf150095_6322 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ (((4 : Int) + b) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) + a)) ≤ ((4 : Int) + b))) ∨ (((6 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ ((((4 : Int) + b) - b) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) + a)) ≤ (((4 : Int) + b) + (0 : Int)))))))) ∨ ((fact_366edf150095_7813 a b) ∧ (fact_366edf150095_7812 a b) ∧ ((fact_366edf150095_6591 a b) ∨ (fact_366edf150095_6233 a b) ∨ (fact_366edf150095_7088 a b) ∨ (fact_366edf150095_7122 a b) ∨ (fact_366edf150095_6263 a b) ∨ (fact_366edf150095_6777 a b) ∨ (fact_366edf150095_6277 a b) ∨ (fact_366edf150095_7137 a b) ∨ (fact_366edf150095_6833 a b) ∨ (fact_366edf150095_6845 a b) ∨ (fact_366edf150095_6327 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ (((4 : Int) + b) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) + a)) ≤ ((4 : Int) + b))) ∨ (((6 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((4 : Int) + b) - b) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) + a)) ≤ (((4 : Int) + b) + (0 : Int)))))) ∧ ((fact_366edf150095_6586 a b) ∨ (fact_366edf150095_6228 a b) ∨ (fact_366edf150095_7083 a b) ∨ (fact_366edf150095_7117 a b) ∨ (fact_366edf150095_6258 a b) ∨ (fact_366edf150095_6772 a b) ∨ (fact_366edf150095_6274 a b) ∨ (fact_366edf150095_7134 a b) ∨ (fact_366edf150095_6829 a b) ∨ (fact_366edf150095_6840 a b) ∨ (fact_366edf150095_6322 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) + (1 : Int))) ∧ (((5 : Int) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ (((4 : Int) + b) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) + a)) ≤ ((4 : Int) + b))) ∨ (((6 : Int) ≤ ((5 : Int) + (1 : Int))) ∧ ((6 : Int) ≥ ((5 : Int) + (1 : Int))) ∧ ((((4 : Int) + b) - b) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) + a))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) + a)) ≤ (((4 : Int) + b) + (0 : Int))))))))))
    (h3 : ((((3 : Int) + ((2 : Int) * b)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ ((3 : Int) > ((2 : Int) + a)) ∨ ((3 : Int) < ((2 : Int) - (0 : Int)))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (a > b))
    (h6 : (a ≥ b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n166_run_empty (a b run_x : Int)
    (h0 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h1 : ((5 : Int) ≤ run_x))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((5 : Int) ≥ run_x))
    (h4 : ((((-1 : Int) + (0 : Int)) < (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) + a) < ((-1 : Int) - a)) ∨ ((0 : Int) < (0 : Int)) ∨ ((0 : Int) < (0 : Int))))
    (h5 : ((fact_366edf150095_4215 a b run_x) ∨ (fact_366edf150095_4200 a b run_x) ∨ (fact_366edf150095_6129 a b run_x) ∨ (fact_366edf150095_6135 a b run_x) ∨ (fact_366edf150095_4203 a b run_x) ∨ (fact_366edf150095_5116 a b run_x) ∨ (fact_366edf150095_4205 a b run_x) ∨ (fact_366edf150095_6137 a b run_x) ∨ (((((3 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((((3 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ (((3 : Int) + a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((3 : Int) + a) - a) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((3 : Int) ≥ (-((-2 : Int) + ((-1 : Int) * a))))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((3 : Int) + b)))) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ (((4 : Int) + b) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ ((4 : Int) + b))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((((4 : Int) + b) - b) ≤ (-((-2 : Int) + ((-1 : Int) * a)))) ∧ ((-((-2 : Int) + ((-1 : Int) * a))) ≤ (((4 : Int) + b) + (0 : Int)))))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n166_run_floor (a b run_x : Int)
    (h0 : ((5 : Int) ≥ run_x))
    (h1 : ((5 : Int) ≤ run_x))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ ((fact_366edf150095_5849 a b run_x) ∨ (fact_366edf150095_5834 a b run_x) ∨ (fact_366edf150095_6957 a b run_x) ∨ (fact_366edf150095_6960 a b run_x) ∨ (fact_366edf150095_5837 a b run_x) ∨ (fact_366edf150095_6132 a b run_x) ∨ (fact_366edf150095_5838 a b run_x) ∨ (fact_366edf150095_6961 a b run_x) ∨ (((((3 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((3 : Int) + a))) ∨ (fact_366edf150095_670 a run_x)) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ (((3 : Int) + a) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((3 : Int) + a))) ∨ (fact_366edf150095_680 a run_x)) ∨ (((((5 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((3 : Int) ≥ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))))) ∨ (((5 : Int) ≤ run_x) ∧ ((5 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((3 : Int) + b)))) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ (((4 : Int) + b) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ ((4 : Int) + b))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((((4 : Int) + b) - b) ≤ (-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)))) ∧ ((-(((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ≤ (((4 : Int) + b) + (0 : Int))))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((3 : Int) + ((2 : Int) * b)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((3 : Int) + ((2 : Int) * b))) ∨ (((2 : Int) + a) < ((4 : Int) + b)) ∨ (((4 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n167_run_four (a b : Int)
    (h0 : (¬ ((5 : Int) ≤ ((4 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n167_run_short (a b : Int)
    (h0 : (¬ ((((4 : Int) + b) - (5 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n167_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n167_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_3503 a b) ∨ (fact_366edf150095_3452 a b) ∨ (fact_366edf150095_5779 a b) ∨ (fact_366edf150095_5787 a b) ∨ (fact_366edf150095_3460 a b) ∨ (fact_366edf150095_3698 a b) ∨ (fact_366edf150095_3466 a b) ∨ (fact_366edf150095_5793 a b) ∨ (((((3 : Int) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3707 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n167_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4125 a b) ∨ (fact_366edf150095_3720 a b) ∨ (fact_366edf150095_5871 a b) ∨ (fact_366edf150095_5954 a b) ∨ (fact_366edf150095_3801 a b) ∨ (fact_366edf150095_4234 a b) ∨ (((((2 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - b) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4386 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n167_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((((5 : Int) + (3 : Int)) ≤ ((4 : Int) + b)) ∧ ((fact_366edf150095_7519 a b) ∨ (fact_366edf150095_7587 a b))) ∨ ((((5 : Int) + (2 : Int)) ≤ ((4 : Int) + b)) ∧ (fact_366edf150095_7519 a b) ∧ (fact_366edf150095_7587 a b)) ∨ (((5 : Int) + (4 : Int)) ≤ ((4 : Int) + b)) ∨ ((((4 : Int) + b) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7519 a b) ∧ (fact_366edf150095_7587 a b) ∧ (((fact_366edf150095_4158 a b) ∨ (fact_366edf150095_3753 a b) ∨ (fact_366edf150095_5904 a b) ∨ (fact_366edf150095_5987 a b) ∨ (fact_366edf150095_3834 a b) ∨ (fact_366edf150095_4267 a b) ∨ (fact_366edf150095_3891 a b) ∨ (fact_366edf150095_6043 a b) ∨ (fact_366edf150095_4794 a b) ∨ (fact_366edf150095_4890 a b) ∨ (fact_366edf150095_4388 a b)) ∨ ((fact_366edf150095_5142 a b) ∨ (fact_366edf150095_4436 a b) ∨ (fact_366edf150095_6361 a b) ∨ (fact_366edf150095_6449 a b) ∨ (fact_366edf150095_4520 a b) ∨ (fact_366edf150095_5270 a b) ∨ (((((2 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((2 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + b) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - b) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5589 a b) ∨ (fact_366edf150095_5399 a b)))) ∨ ((fact_366edf150095_7519 a b) ∧ (fact_366edf150095_7587 a b) ∧ ((fact_366edf150095_4158 a b) ∨ (fact_366edf150095_3753 a b) ∨ (fact_366edf150095_5904 a b) ∨ (fact_366edf150095_5987 a b) ∨ (fact_366edf150095_3834 a b) ∨ (fact_366edf150095_4267 a b) ∨ (fact_366edf150095_3891 a b) ∨ (fact_366edf150095_6043 a b) ∨ (fact_366edf150095_4794 a b) ∨ (fact_366edf150095_4890 a b) ∨ (fact_366edf150095_4388 a b)) ∧ ((fact_366edf150095_5142 a b) ∨ (fact_366edf150095_4436 a b) ∨ (fact_366edf150095_6361 a b) ∨ (fact_366edf150095_6449 a b) ∨ (fact_366edf150095_4520 a b) ∨ (fact_366edf150095_5270 a b) ∨ (((((2 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((2 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((4 : Int) + b) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a)))) ∨ ((((((3 : Int) + ((2 : Int) * b)) - b) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ (((3 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ ((((3 : Int) + ((2 : Int) * b)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + ((2 : Int) * b))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (((((3 : Int) - b) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((4 : Int) + b) + (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5589 a b) ∨ (fact_366edf150095_5399 a b))))))
    (h2 : (a > b))
    (h3 : (a ≥ b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n167_run_empty (a b run_x : Int)
    (h0 : ((fact_366edf150095_2376 a b run_x) ∨ (fact_366edf150095_2311 a b run_x) ∨ (fact_366edf150095_3519 a b run_x) ∨ (fact_366edf150095_3534 a b run_x) ∨ (fact_366edf150095_2316 a b run_x) ∨ (fact_366edf150095_2958 a b run_x) ∨ (fact_366edf150095_2320 a b run_x) ∨ (fact_366edf150095_3538 a b run_x) ∨ (fact_366edf150095_2997 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_2972 a b run_x)))
    (h1 : (run_x ≤ ((4 : Int) + b)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((5 : Int) ≤ run_x))
    (h6 : (a ≥ b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a > b))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n167_run_floor (a b run_x : Int)
    (h0 : ((5 : Int) ≤ run_x))
    (h1 : (¬ ((fact_366edf150095_3350 a b run_x) ∨ (fact_366edf150095_3299 a b run_x) ∨ (fact_366edf150095_5214 a b run_x) ∨ (fact_366edf150095_5224 a b run_x) ∨ (fact_366edf150095_3309 a b run_x) ∨ (fact_366edf150095_3529 a b run_x) ∨ (fact_366edf150095_3316 a b run_x) ∨ (fact_366edf150095_5231 a b run_x) ∨ (fact_366edf150095_3579 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ (((3 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((3 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3552 a b run_x))))
    (h2 : (run_x ≤ ((4 : Int) + b)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

end LRegionArithmetic

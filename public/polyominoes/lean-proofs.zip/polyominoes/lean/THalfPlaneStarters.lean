import TBoundary
import CornerCertificateCore

set_option maxRecDepth 10000
set_option maxHeartbeats 100000

namespace PolyominoFormal.THalfPlaneStarters
open CrossUnits TBoundary

/-- Vertical crossbar or downward stem beginning at the indicated cell. -/
def Starter (a b c p h : Int) (t : Cross) : Prop :=
  t=⟨p,h+a,b,c,0,a⟩ ∨ t=⟨p,h+c,b,a,0,c⟩ ∨
  t=⟨p,h+a,0,c,b,a⟩ ∨ t=⟨p,h+c,0,a,b,c⟩ ∨
  t=⟨p,h+b,a,0,c,b⟩ ∨ t=⟨p,h+b,c,0,a,b⟩

/-- Exhaustive ways in which a T can touch a straight lower boundary. -/
def BoundaryForm (a b c p : Int) (t : Cross) : Prop :=
  (∃ x, t=⟨x,0,a,b,c,0⟩ ∧ x-c≤p ∧ p≤x+a) ∨
  (∃ x, t=⟨x,0,c,b,a,0⟩ ∧ x-a≤p ∧ p≤x+c) ∨ Starter a b c p 0 t

theorem boundary_forms {a b c p : Int} (ha : 1≤a) (hb : 1≤b) (hc : 1≤c)
    {t : Cross} (copy : Copy a b c 0 t) (bound : 0≤t.y-t.south)
    (hit : Contains t p 0) : BoundaryForm a b c p t := by
  rcases t with ⟨x,y,e,n,w,s⟩
  rcases copy with h | h | h | h | h | h | h | h
  all_goals rcases h with ⟨he,hn,hw,hs⟩
  all_goals dsimp only at he hn hw hs bound hit
  all_goals subst e; subst n; subst w; subst s
  all_goals dsimp [Contains] at hit
  · have hy : y=0 := by omega
    subst y
    exact Or.inl ⟨x,rfl,by omega,by omega⟩
  · right; right; left
    apply same_eq; dsimp [Same]; omega
  · right; right; right; right; right; right; right
    apply same_eq; dsimp [Same]; omega
  · right; right; right; right; right; left
    apply same_eq; dsimp [Same]; omega
  · right; right; right; right; left
    apply same_eq; dsimp [Same]; omega
  · have hy : y=0 := by omega
    subst y
    exact Or.inr (Or.inl ⟨x,rfl,by omega,by omega⟩)
  · right; right; right; left
    apply same_eq; dsimp [Same]; omega
  · right; right; right; right; right; right; left
    apply same_eq; dsimp [Same]; omega

theorem starter_contains_base {a b c p h : Int} (ha : 1≤a) (hb : 1≤b) (hc : 1≤c)
    {t : Cross} (st : Starter a b c p h t) : Contains t p h := by
  rcases st with rfl | rfl | rfl | rfl | rfl | rfl
  all_goals right
  all_goals dsimp
  all_goals omega

/-- Adjacent starters at a common level must be crossbars pointing away
from each other when the perpendicular stem is no longer than the bar. -/
theorem adjacent_starters {a b c p h : Int} (ha : 1≤a) (hb : 1≤b) (hc : 1≤c)
    (short : b≤a+c) {t u : Cross}
    (st : Starter a b c p h t) (su : Starter a b c (p+1) h u) (apart : Apart t u) :
    (t=⟨p,h+a,0,c,b,a⟩ ∨ t=⟨p,h+c,0,a,b,c⟩) ∧
    (u=⟨p+1,h+a,b,c,0,a⟩ ∨ u=⟨p+1,h+c,b,a,0,c⟩) := by
  rcases st with rfl | rfl | rfl | rfl | rfl | rfl
  all_goals rcases su with rfl | rfl | rfl | rfl | rfl | rfl
  all_goals first | (constructor <;> first | (left; rfl) | (right; rfl)) | skip
  all_goals exfalso
  all_goals dsimp [Apart] at apart
  all_goals omega

theorem no_three_starters {a b c p h : Int} (ha : 1≤a) (hb : 1≤b) (hc : 1≤c)
    (short : b≤a+c) {t u v : Cross}
    (st : Starter a b c p h t) (su : Starter a b c (p+1) h u)
    (sv : Starter a b c (p+2) h v) (apart : Apart t u) (apart2 : Apart u v) : False := by
  have left := adjacent_starters ha hb hc short st su apart
  have right := adjacent_starters ha hb hc short su
    (by simpa only [show p+1+1=p+2 by omega] using sv) apart2
  rcases left.2 with h | h
  all_goals rcases right.1 with h' | h'
  all_goals have he := congrArg Cross.east (h.symm.trans h')
  all_goals dsimp at he
  all_goals omega

/-- A cell in a short blocked run must start a vertical bar or a downward
stem. Only the two end cells and the floor under the queried tile matter. -/
theorem short_run_forms {a b c L R p h : Int} (ha : 1≤a) (hb : 1≤b) (hc : 1≤c)
    (short : R-L<a+c) (hp0 : L≤p) (hp1 : p≤R) {t : Cross}
    (copy : Copy a b c 0 t) (hit : Contains t p h)
    (left : ¬Contains t (L-1) h) (right : ¬Contains t (R+1) h)
    (floor : ¬Contains t p (h-1))
    (center : L≤t.x → t.x≤R → ¬Contains t t.x (h-1)) : Starter a b c p h t := by
  have nn := TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) copy
  rcases nn with ⟨he,hn,hw,hs⟩
  have shape : t.east+t.west=a+c ∨ 1≤t.south := by
    rcases copy with h | h | h | h | h | h | h | h
    all_goals rcases h with ⟨e,n,w,s⟩
    all_goals omega
  have notRow : t.y≠h := by
    intro hy
    have span : t.x-t.west≤p ∧ p≤t.x+t.east := by
      rcases hit with hit | hit <;> omega
    have noLeft : ¬(t.x-t.west≤L-1 ∧ L-1≤t.x+t.east) := by
      rintro ⟨h0,h1⟩
      exact left (Or.inl ⟨h0,h1,by omega,by omega⟩)
    have noRight : ¬(t.x-t.west≤R+1 ∧ R+1≤t.x+t.east) := by
      rintro ⟨h0,h1⟩
      exact right (Or.inl ⟨h0,h1,by omega,by omega⟩)
    have bounds : L≤t.x-t.west ∧ t.x+t.east≤R := by omega
    rcases shape with long | south
    · omega
    · have below : Contains t t.x (h-1) := Or.inr ⟨by omega,by omega,by omega,by omega⟩
      exact center (by omega) (by omega) below
  have vertical : t.x=p ∧ t.y-t.south≤h ∧ h≤t.y+t.north := by
    rcases hit with hit | hit <;> omega
  have bottom : t.y-t.south=h := by
    apply Classical.byContradiction
    intro different
    have below : Contains t p (h-1) := Or.inr ⟨by omega,by omega,by omega,by omega⟩
    exact floor below
  rcases t with ⟨x,y,e,n,w,s⟩
  rcases copy with copy | copy | copy | copy | copy | copy | copy | copy
  all_goals rcases copy with ⟨ce,cn,cw,cs⟩
  all_goals dsimp only at ce cn cw cs bottom vertical notRow
  all_goals subst e; subst n; subst w; subst s
  · exfalso; omega
  · left; apply same_eq; dsimp [Same]; simp only [and_true]; omega
  · right; right; right; right; right
    apply same_eq; dsimp [Same]; simp only [and_true]; omega
  · right; right; right; left
    apply same_eq; dsimp [Same]; simp only [and_true]; omega
  · right; right; left
    apply same_eq; dsimp [Same]; simp only [and_true]; omega
  · exfalso; omega
  · right; left; apply same_eq; dsimp [Same]; simp only [and_true]; omega
  · right; right; right; right; left
    apply same_eq; dsimp [Same]; simp only [and_true]; omega

theorem starter_base_only {a b c p h : Int} (ha : 1≤a) (hb : 1≤b) (hc : 1≤c)
    {t : Cross} (st : Starter a b c p h t) {x : Int} (hit : Contains t x h) : x=p := by
  rcases st with rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Contains] at hit
  all_goals omega

theorem avoid_closed {world : Cross→Prop} {B : Region}
    (closed : CornerCertificate.TileClosed world B) {t : Cross} (ht : world t)
    {p h x y : Int} (hit : Contains t p h) (empty : ¬B p h) (blocked : B x y) :
    ¬Contains t x y := by
  intro other
  exact empty (closed t ht x y other blocked p h hit)

/-- The local blocked-run obstruction for an arbitrary region and arbitrary
world: a full floor and two end walls forbid a short run of at least three
empty cells when b does not exceed the crossbar length minus one. -/
theorem blocked_short_run {a b c L R h : Int} {region : Region}
    (ha : 1≤a) (hb : 1≤b) (hc : 1≤c) (shortStem : b≤a+c)
    (three : L+2≤R) (shortRun : R-L<a+c)
    (T : Tiling a b c 0 region) (B : Region)
    (closed : CornerCertificate.TileClosed T.world B)
    (inside : ∀ x, L≤x → x≤R → region x h)
    (empty : ∀ x, L≤x → x≤R → ¬B x h)
    (floor : ∀ x, L≤x → x≤R → B x (h-1))
    (left : B (L-1) h) (right : B (R+1) h) : False := by
  have choose : ∀ p, L≤p → p≤R → ∃ t, T.world t ∧ Starter a b c p h t := by
    intro p hp0 hp1
    obtain ⟨t,ht,hit⟩ := T.cover p h (inside p hp0 hp1)
    have avoid : ∀ {x y}, B x y → ¬Contains t x y :=
      fun blocked => avoid_closed closed ht hit (empty p hp0 hp1) blocked
    refine ⟨t,ht,short_run_forms ha hb hc shortRun hp0 hp1 (T.copies t ht) hit
      (avoid left) (avoid right) (avoid (floor p hp0 hp1)) ?_⟩
    intro hx0 hx1
    exact avoid (floor t.x hx0 hx1)
  obtain ⟨t,ht,st⟩ := choose L (by omega) (by omega)
  obtain ⟨u,hu,su⟩ := choose (L+1) (by omega) (by omega)
  obtain ⟨v,hv,sv⟩ := choose (L+2) (by omega) (by omega)
  have ap : Apart t u := separate (by omega) (by omega) (by omega) T ht hu
    (starter_contains_base ha hb hc st) (by
      intro hit
      have := starter_base_only ha hb hc su hit
      omega)
  have ap2 : Apart u v := separate (by omega) (by omega) (by omega) T hu hv
    (starter_contains_base ha hb hc su) (by
      intro hit
      have := starter_base_only ha hb hc sv hit
      omega)
  exact no_three_starters ha hb hc shortStem st su sv ap ap2

#print axioms short_run_forms
#print axioms blocked_short_run

#print axioms boundary_forms
#print axioms no_three_starters
end PolyominoFormal.THalfPlaneStarters

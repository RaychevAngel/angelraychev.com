import CornerCertificateFiveGammaTransposeData

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

namespace CornerCertificate
open CrossUnits


section FiveGammaTranspose
variable (world : Cross → Prop) (h : Int)
    (copies : ∀ t, world t → Copy 5 1 1 0 t)
    (separate : DisjointWorld world) (cover : CoversWindow world h)
    (ceiling : SelectedBelow world h)

include copies separate cover ceiling in
theorem five_gammaTranspose_node0001 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0001 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0001 ((0 : Int),(2 : Int)) five_gammaTranspose_branches0001 copies separate cover ceiling five_gammaTranspose_check0001 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0001, List.mem_cons, List.not_mem_nil, or_false] at member
theorem five_gammaTranspose_node0004 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0004 B) : Transition world h .gammaTranspose B := by
  exact replay_leaf world h .gammaTranspose five_gammaTranspose_occ0004 .gamma (2 : Int) (1 : Int) five_gammaTranspose_check0004 B state
theorem five_gammaTranspose_node0005 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0005 B) : Transition world h .gammaTranspose B := by
  exact replay_leaf world h .gammaTranspose five_gammaTranspose_occ0005 .beta (2 : Int) (1 : Int) five_gammaTranspose_check0005 B state
include copies separate cover ceiling in
theorem five_gammaTranspose_node0008 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0008 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0008 ((4 : Int),(1 : Int)) five_gammaTranspose_branches0008 copies separate cover ceiling five_gammaTranspose_check0008 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0008, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0009 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0009 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0009 ((4 : Int),(1 : Int)) five_gammaTranspose_branches0009 copies separate cover ceiling five_gammaTranspose_check0009 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0009, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0007 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0007 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0007 ((3 : Int),(1 : Int)) five_gammaTranspose_branches0007 copies separate cover ceiling five_gammaTranspose_check0007 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0007, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0008 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0009 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0010 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0010 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0010 ((3 : Int),(1 : Int)) five_gammaTranspose_branches0010 copies separate cover ceiling five_gammaTranspose_check0010 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0010, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0011 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0011 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0011 ((3 : Int),(1 : Int)) five_gammaTranspose_branches0011 copies separate cover ceiling five_gammaTranspose_check0011 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0011, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0014 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0014 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0014 ((5 : Int),(1 : Int)) five_gammaTranspose_branches0014 copies separate cover ceiling five_gammaTranspose_check0014 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0014, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0015 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0015 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0015 ((5 : Int),(1 : Int)) five_gammaTranspose_branches0015 copies separate cover ceiling five_gammaTranspose_check0015 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0015, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0013 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0013 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0013 ((4 : Int),(1 : Int)) five_gammaTranspose_branches0013 copies separate cover ceiling five_gammaTranspose_check0013 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0013, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0014 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0015 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0017 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0017 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0017 ((5 : Int),(1 : Int)) five_gammaTranspose_branches0017 copies separate cover ceiling five_gammaTranspose_check0017 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0017, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0018 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0018 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0018 ((5 : Int),(1 : Int)) five_gammaTranspose_branches0018 copies separate cover ceiling five_gammaTranspose_check0018 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0018, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0016 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0016 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0016 ((4 : Int),(1 : Int)) five_gammaTranspose_branches0016 copies separate cover ceiling five_gammaTranspose_check0016 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0016, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0017 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0018 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0012 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0012 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0012 ((2 : Int),(3 : Int)) five_gammaTranspose_branches0012 copies separate cover ceiling five_gammaTranspose_check0012 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0012, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0013 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0016 world h copies separate cover ceiling nextB nextState
theorem five_gammaTranspose_node0019 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0019 B) : Transition world h .gammaTranspose B := by
  exact replay_leaf world h .gammaTranspose five_gammaTranspose_occ0019 .alpha (2 : Int) (3 : Int) five_gammaTranspose_check0019 B state
include copies separate cover ceiling in
theorem five_gammaTranspose_node0020 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0020 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0020 ((3 : Int),(1 : Int)) five_gammaTranspose_branches0020 copies separate cover ceiling five_gammaTranspose_check0020 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0020, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0021 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0021 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0021 ((3 : Int),(1 : Int)) five_gammaTranspose_branches0021 copies separate cover ceiling five_gammaTranspose_check0021 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0021, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0006 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0006 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0006 ((2 : Int),(2 : Int)) five_gammaTranspose_branches0006 copies separate cover ceiling five_gammaTranspose_check0006 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0006, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact five_gammaTranspose_node0007 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0010 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0011 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0012 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0019 world h nextB nextState
  · exact five_gammaTranspose_node0020 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0021 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0003 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0003 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0003 ((2 : Int),(0 : Int)) five_gammaTranspose_branches0003 copies separate cover ceiling five_gammaTranspose_check0003 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0003, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact five_gammaTranspose_node0004 world h nextB nextState
  · exact five_gammaTranspose_node0005 world h nextB nextState
  · exact five_gammaTranspose_node0006 world h copies separate cover ceiling nextB nextState
theorem five_gammaTranspose_node0023 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0023 B) : Transition world h .gammaTranspose B := by
  exact replay_leaf world h .gammaTranspose five_gammaTranspose_occ0023 .gamma (2 : Int) (1 : Int) five_gammaTranspose_check0023 B state
theorem five_gammaTranspose_node0024 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0024 B) : Transition world h .gammaTranspose B := by
  exact replay_leaf world h .gammaTranspose five_gammaTranspose_occ0024 .beta (2 : Int) (1 : Int) five_gammaTranspose_check0024 B state
include copies separate cover ceiling in
theorem five_gammaTranspose_node0026 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0026 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0026 ((3 : Int),(1 : Int)) five_gammaTranspose_branches0026 copies separate cover ceiling five_gammaTranspose_check0026 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0026, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0027 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0027 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0027 ((3 : Int),(1 : Int)) five_gammaTranspose_branches0027 copies separate cover ceiling five_gammaTranspose_check0027 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0027, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0030 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0030 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0030 ((5 : Int),(1 : Int)) five_gammaTranspose_branches0030 copies separate cover ceiling five_gammaTranspose_check0030 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0030, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0031 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0031 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0031 ((5 : Int),(1 : Int)) five_gammaTranspose_branches0031 copies separate cover ceiling five_gammaTranspose_check0031 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0031, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0029 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0029 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0029 ((4 : Int),(1 : Int)) five_gammaTranspose_branches0029 copies separate cover ceiling five_gammaTranspose_check0029 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0029, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0030 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0031 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0033 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0033 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0033 ((5 : Int),(1 : Int)) five_gammaTranspose_branches0033 copies separate cover ceiling five_gammaTranspose_check0033 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0033, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0034 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0034 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0034 ((5 : Int),(1 : Int)) five_gammaTranspose_branches0034 copies separate cover ceiling five_gammaTranspose_check0034 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0034, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0032 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0032 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0032 ((4 : Int),(1 : Int)) five_gammaTranspose_branches0032 copies separate cover ceiling five_gammaTranspose_check0032 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0032, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0033 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0034 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0028 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0028 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0028 ((2 : Int),(3 : Int)) five_gammaTranspose_branches0028 copies separate cover ceiling five_gammaTranspose_check0028 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0028, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0029 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0032 world h copies separate cover ceiling nextB nextState
theorem five_gammaTranspose_node0035 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0035 B) : Transition world h .gammaTranspose B := by
  exact replay_leaf world h .gammaTranspose five_gammaTranspose_occ0035 .alpha (2 : Int) (3 : Int) five_gammaTranspose_check0035 B state
include copies separate cover ceiling in
theorem five_gammaTranspose_node0036 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0036 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0036 ((3 : Int),(1 : Int)) five_gammaTranspose_branches0036 copies separate cover ceiling five_gammaTranspose_check0036 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0036, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0037 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0037 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0037 ((3 : Int),(1 : Int)) five_gammaTranspose_branches0037 copies separate cover ceiling five_gammaTranspose_check0037 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0037, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0025 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0025 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0025 ((2 : Int),(2 : Int)) five_gammaTranspose_branches0025 copies separate cover ceiling five_gammaTranspose_check0025 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0025, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact five_gammaTranspose_node0026 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0027 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0028 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0035 world h nextB nextState
  · exact five_gammaTranspose_node0036 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0037 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0022 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0022 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0022 ((2 : Int),(0 : Int)) five_gammaTranspose_branches0022 copies separate cover ceiling five_gammaTranspose_check0022 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0022, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact five_gammaTranspose_node0023 world h nextB nextState
  · exact five_gammaTranspose_node0024 world h nextB nextState
  · exact five_gammaTranspose_node0025 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0002 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0002 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0002 ((0 : Int),(2 : Int)) five_gammaTranspose_branches0002 copies separate cover ceiling five_gammaTranspose_check0002 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0002, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0003 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0022 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0040 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0040 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0040 ((2 : Int),(1 : Int)) five_gammaTranspose_branches0040 copies separate cover ceiling five_gammaTranspose_check0040 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0040, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0042 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0042 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0042 ((2 : Int),(2 : Int)) five_gammaTranspose_branches0042 copies separate cover ceiling five_gammaTranspose_check0042 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0042, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0043 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0043 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0043 ((2 : Int),(2 : Int)) five_gammaTranspose_branches0043 copies separate cover ceiling five_gammaTranspose_check0043 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0043, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0041 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0041 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0041 ((2 : Int),(1 : Int)) five_gammaTranspose_branches0041 copies separate cover ceiling five_gammaTranspose_check0041 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0041, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0042 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0043 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0044 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0044 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0044 ((2 : Int),(1 : Int)) five_gammaTranspose_branches0044 copies separate cover ceiling five_gammaTranspose_check0044 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0044, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0039 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0039 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0039 ((2 : Int),(0 : Int)) five_gammaTranspose_branches0039 copies separate cover ceiling five_gammaTranspose_check0039 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0039, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact five_gammaTranspose_node0040 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0041 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0044 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0046 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0046 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0046 ((2 : Int),(1 : Int)) five_gammaTranspose_branches0046 copies separate cover ceiling five_gammaTranspose_check0046 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0046, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0048 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0048 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0048 ((2 : Int),(2 : Int)) five_gammaTranspose_branches0048 copies separate cover ceiling five_gammaTranspose_check0048 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0048, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0049 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0049 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0049 ((2 : Int),(2 : Int)) five_gammaTranspose_branches0049 copies separate cover ceiling five_gammaTranspose_check0049 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0049, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0047 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0047 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0047 ((2 : Int),(1 : Int)) five_gammaTranspose_branches0047 copies separate cover ceiling five_gammaTranspose_check0047 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0047, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0048 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0049 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0050 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0050 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0050 ((2 : Int),(1 : Int)) five_gammaTranspose_branches0050 copies separate cover ceiling five_gammaTranspose_check0050 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0050, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0045 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0045 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0045 ((2 : Int),(0 : Int)) five_gammaTranspose_branches0045 copies separate cover ceiling five_gammaTranspose_check0045 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0045, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact five_gammaTranspose_node0046 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0047 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0050 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0038 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0038 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0038 ((0 : Int),(2 : Int)) five_gammaTranspose_branches0038 copies separate cover ceiling five_gammaTranspose_check0038 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0038, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0039 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0045 world h copies separate cover ceiling nextB nextState
theorem five_gammaTranspose_node0053 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0053 B) : Transition world h .gammaTranspose B := by
  exact replay_leaf world h .gammaTranspose five_gammaTranspose_occ0053 .gammaTranspose (2 : Int) (1 : Int) five_gammaTranspose_check0053 B state
theorem five_gammaTranspose_node0055 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0055 B) : Transition world h .gammaTranspose B := by
  exact replay_leaf world h .gammaTranspose five_gammaTranspose_occ0055 .alpha (4 : Int) (1 : Int) five_gammaTranspose_check0055 B state
include copies separate cover ceiling in
theorem five_gammaTranspose_node0058 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0058 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0058 ((2 : Int),(4 : Int)) five_gammaTranspose_branches0058 copies separate cover ceiling five_gammaTranspose_check0058 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0058, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0059 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0059 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0059 ((2 : Int),(4 : Int)) five_gammaTranspose_branches0059 copies separate cover ceiling five_gammaTranspose_check0059 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0059, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0057 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0057 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0057 ((4 : Int),(1 : Int)) five_gammaTranspose_branches0057 copies separate cover ceiling five_gammaTranspose_check0057 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0057, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0058 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0059 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0061 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0061 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0061 ((2 : Int),(4 : Int)) five_gammaTranspose_branches0061 copies separate cover ceiling five_gammaTranspose_check0061 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0061, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0062 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0062 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0062 ((2 : Int),(4 : Int)) five_gammaTranspose_branches0062 copies separate cover ceiling five_gammaTranspose_check0062 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0062, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0060 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0060 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0060 ((4 : Int),(1 : Int)) five_gammaTranspose_branches0060 copies separate cover ceiling five_gammaTranspose_check0060 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0060, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0061 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0062 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0056 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0056 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0056 ((2 : Int),(3 : Int)) five_gammaTranspose_branches0056 copies separate cover ceiling five_gammaTranspose_check0056 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0056, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0057 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0060 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0064 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0064 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0064 ((2 : Int),(3 : Int)) five_gammaTranspose_branches0064 copies separate cover ceiling five_gammaTranspose_check0064 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0064, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0063 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0063 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0063 ((3 : Int),(1 : Int)) five_gammaTranspose_branches0063 copies separate cover ceiling five_gammaTranspose_check0063 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0063, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact five_gammaTranspose_node0064 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0065 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0065 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0065 ((3 : Int),(1 : Int)) five_gammaTranspose_branches0065 copies separate cover ceiling five_gammaTranspose_check0065 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0065, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0067 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0067 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0067 ((2 : Int),(3 : Int)) five_gammaTranspose_branches0067 copies separate cover ceiling five_gammaTranspose_check0067 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0067, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0066 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0066 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0066 ((3 : Int),(1 : Int)) five_gammaTranspose_branches0066 copies separate cover ceiling five_gammaTranspose_check0066 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0066, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact five_gammaTranspose_node0067 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0054 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0054 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0054 ((2 : Int),(2 : Int)) five_gammaTranspose_branches0054 copies separate cover ceiling five_gammaTranspose_check0054 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0054, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact five_gammaTranspose_node0055 world h nextB nextState
  · exact five_gammaTranspose_node0056 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0063 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0065 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0066 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0052 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0052 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0052 ((1 : Int),(1 : Int)) five_gammaTranspose_branches0052 copies separate cover ceiling five_gammaTranspose_check0052 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0052, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0053 world h nextB nextState
  · exact five_gammaTranspose_node0054 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0068 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0068 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0068 ((1 : Int),(1 : Int)) five_gammaTranspose_branches0068 copies separate cover ceiling five_gammaTranspose_check0068 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0068, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0069 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0069 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0069 ((1 : Int),(1 : Int)) five_gammaTranspose_branches0069 copies separate cover ceiling five_gammaTranspose_check0069 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0069, List.mem_cons, List.not_mem_nil, or_false] at member
theorem five_gammaTranspose_node0070 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0070 B) : Transition world h .gammaTranspose B := by
  exact replay_leaf world h .gammaTranspose five_gammaTranspose_occ0070 .beta (2 : Int) (1 : Int) five_gammaTranspose_check0070 B state
theorem five_gammaTranspose_node0072 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0072 B) : Transition world h .gammaTranspose B := by
  exact replay_leaf world h .gammaTranspose five_gammaTranspose_occ0072 .alpha (1 : Int) (3 : Int) five_gammaTranspose_check0072 B state
theorem five_gammaTranspose_node0074 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0074 B) : Transition world h .gammaTranspose B := by
  exact replay_leaf world h .gammaTranspose five_gammaTranspose_occ0074 .gamma (1 : Int) (4 : Int) five_gammaTranspose_check0074 B state
include copies separate cover ceiling in
theorem five_gammaTranspose_node0078 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0078 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0078 ((3 : Int),(4 : Int)) five_gammaTranspose_branches0078 copies separate cover ceiling five_gammaTranspose_check0078 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0078, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0079 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0079 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0079 ((3 : Int),(4 : Int)) five_gammaTranspose_branches0079 copies separate cover ceiling five_gammaTranspose_check0079 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0079, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0077 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0077 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0077 ((2 : Int),(4 : Int)) five_gammaTranspose_branches0077 copies separate cover ceiling five_gammaTranspose_check0077 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0077, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0078 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0079 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0080 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0080 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0080 ((2 : Int),(4 : Int)) five_gammaTranspose_branches0080 copies separate cover ceiling five_gammaTranspose_check0080 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0080, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0081 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0081 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0081 ((2 : Int),(4 : Int)) five_gammaTranspose_branches0081 copies separate cover ceiling five_gammaTranspose_check0081 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0081, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0084 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0084 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0084 ((4 : Int),(4 : Int)) five_gammaTranspose_branches0084 copies separate cover ceiling five_gammaTranspose_check0084 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0084, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0085 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0085 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0085 ((4 : Int),(4 : Int)) five_gammaTranspose_branches0085 copies separate cover ceiling five_gammaTranspose_check0085 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0085, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0083 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0083 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0083 ((3 : Int),(4 : Int)) five_gammaTranspose_branches0083 copies separate cover ceiling five_gammaTranspose_check0083 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0083, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0084 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0085 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0087 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0087 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0087 ((4 : Int),(4 : Int)) five_gammaTranspose_branches0087 copies separate cover ceiling five_gammaTranspose_check0087 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0087, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0088 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0088 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0088 ((4 : Int),(4 : Int)) five_gammaTranspose_branches0088 copies separate cover ceiling five_gammaTranspose_check0088 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0088, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0086 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0086 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0086 ((3 : Int),(4 : Int)) five_gammaTranspose_branches0086 copies separate cover ceiling five_gammaTranspose_check0086 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0086, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0087 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0088 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0082 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0082 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0082 ((1 : Int),(6 : Int)) five_gammaTranspose_branches0082 copies separate cover ceiling five_gammaTranspose_check0082 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0082, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0083 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0086 world h copies separate cover ceiling nextB nextState
theorem five_gammaTranspose_node0089 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0089 B) : Transition world h .gammaTranspose B := by
  exact replay_leaf world h .gammaTranspose five_gammaTranspose_occ0089 .alpha (1 : Int) (6 : Int) five_gammaTranspose_check0089 B state
include copies separate cover ceiling in
theorem five_gammaTranspose_node0090 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0090 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0090 ((2 : Int),(4 : Int)) five_gammaTranspose_branches0090 copies separate cover ceiling five_gammaTranspose_check0090 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0090, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0091 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0091 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0091 ((2 : Int),(4 : Int)) five_gammaTranspose_branches0091 copies separate cover ceiling five_gammaTranspose_check0091 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0091, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0076 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0076 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0076 ((1 : Int),(5 : Int)) five_gammaTranspose_branches0076 copies separate cover ceiling five_gammaTranspose_check0076 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0076, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact five_gammaTranspose_node0077 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0080 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0081 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0082 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0089 world h nextB nextState
  · exact five_gammaTranspose_node0090 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0091 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0094 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0094 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0094 ((3 : Int),(4 : Int)) five_gammaTranspose_branches0094 copies separate cover ceiling five_gammaTranspose_check0094 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0094, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0095 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0095 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0095 ((3 : Int),(4 : Int)) five_gammaTranspose_branches0095 copies separate cover ceiling five_gammaTranspose_check0095 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0095, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0093 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0093 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0093 ((2 : Int),(4 : Int)) five_gammaTranspose_branches0093 copies separate cover ceiling five_gammaTranspose_check0093 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0093, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0094 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0095 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0096 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0096 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0096 ((2 : Int),(4 : Int)) five_gammaTranspose_branches0096 copies separate cover ceiling five_gammaTranspose_check0096 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0096, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0097 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0097 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0097 ((2 : Int),(4 : Int)) five_gammaTranspose_branches0097 copies separate cover ceiling five_gammaTranspose_check0097 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0097, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0100 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0100 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0100 ((4 : Int),(4 : Int)) five_gammaTranspose_branches0100 copies separate cover ceiling five_gammaTranspose_check0100 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0100, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0101 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0101 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0101 ((4 : Int),(4 : Int)) five_gammaTranspose_branches0101 copies separate cover ceiling five_gammaTranspose_check0101 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0101, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0099 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0099 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0099 ((3 : Int),(4 : Int)) five_gammaTranspose_branches0099 copies separate cover ceiling five_gammaTranspose_check0099 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0099, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0100 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0101 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0103 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0103 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0103 ((4 : Int),(4 : Int)) five_gammaTranspose_branches0103 copies separate cover ceiling five_gammaTranspose_check0103 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0103, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0104 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0104 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0104 ((4 : Int),(4 : Int)) five_gammaTranspose_branches0104 copies separate cover ceiling five_gammaTranspose_check0104 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0104, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0102 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0102 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0102 ((3 : Int),(4 : Int)) five_gammaTranspose_branches0102 copies separate cover ceiling five_gammaTranspose_check0102 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0102, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0103 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0104 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0098 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0098 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0098 ((1 : Int),(6 : Int)) five_gammaTranspose_branches0098 copies separate cover ceiling five_gammaTranspose_check0098 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0098, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0099 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0102 world h copies separate cover ceiling nextB nextState
theorem five_gammaTranspose_node0105 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0105 B) : Transition world h .gammaTranspose B := by
  exact replay_leaf world h .gammaTranspose five_gammaTranspose_occ0105 .alpha (1 : Int) (6 : Int) five_gammaTranspose_check0105 B state
include copies separate cover ceiling in
theorem five_gammaTranspose_node0106 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0106 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0106 ((2 : Int),(4 : Int)) five_gammaTranspose_branches0106 copies separate cover ceiling five_gammaTranspose_check0106 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0106, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0107 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0107 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0107 ((2 : Int),(4 : Int)) five_gammaTranspose_branches0107 copies separate cover ceiling five_gammaTranspose_check0107 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0107, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0092 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0092 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0092 ((1 : Int),(5 : Int)) five_gammaTranspose_branches0092 copies separate cover ceiling five_gammaTranspose_check0092 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0092, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact five_gammaTranspose_node0093 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0096 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0097 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0098 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0105 world h nextB nextState
  · exact five_gammaTranspose_node0106 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0107 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0075 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0075 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0075 ((3 : Int),(1 : Int)) five_gammaTranspose_branches0075 copies separate cover ceiling five_gammaTranspose_check0075 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0075, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0076 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0092 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0073 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0073 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0073 ((1 : Int),(3 : Int)) five_gammaTranspose_branches0073 copies separate cover ceiling five_gammaTranspose_check0073 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0073, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0074 world h nextB nextState
  · exact five_gammaTranspose_node0075 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0110 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0110 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0110 ((1 : Int),(4 : Int)) five_gammaTranspose_branches0110 copies separate cover ceiling five_gammaTranspose_check0110 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0110, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0111 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0111 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0111 ((1 : Int),(4 : Int)) five_gammaTranspose_branches0111 copies separate cover ceiling five_gammaTranspose_check0111 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0111, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0109 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0109 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0109 ((3 : Int),(1 : Int)) five_gammaTranspose_branches0109 copies separate cover ceiling five_gammaTranspose_check0109 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0109, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0110 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0111 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0113 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0113 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0113 ((1 : Int),(4 : Int)) five_gammaTranspose_branches0113 copies separate cover ceiling five_gammaTranspose_check0113 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0113, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0114 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0114 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0114 ((1 : Int),(4 : Int)) five_gammaTranspose_branches0114 copies separate cover ceiling five_gammaTranspose_check0114 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0114, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0112 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0112 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0112 ((3 : Int),(1 : Int)) five_gammaTranspose_branches0112 copies separate cover ceiling five_gammaTranspose_check0112 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0112, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0113 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0114 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0108 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0108 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0108 ((1 : Int),(3 : Int)) five_gammaTranspose_branches0108 copies separate cover ceiling five_gammaTranspose_check0108 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0108, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0109 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0112 world h copies separate cover ceiling nextB nextState
theorem five_gammaTranspose_node0116 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0116 B) : Transition world h .gammaTranspose B := by
  exact replay_leaf world h .gammaTranspose five_gammaTranspose_occ0116 .beta (1 : Int) (4 : Int) five_gammaTranspose_check0116 B state
theorem five_gammaTranspose_node0117 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0117 B) : Transition world h .gammaTranspose B := by
  exact replay_leaf world h .gammaTranspose five_gammaTranspose_occ0117 .gammaTranspose (1 : Int) (4 : Int) five_gammaTranspose_check0117 B state
theorem five_gammaTranspose_node0120 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0120 B) : Transition world h .gammaTranspose B := by
  exact replay_leaf world h .gammaTranspose five_gammaTranspose_occ0120 .alpha (3 : Int) (4 : Int) five_gammaTranspose_check0120 B state
include copies separate cover ceiling in
theorem five_gammaTranspose_node0123 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0123 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0123 ((1 : Int),(7 : Int)) five_gammaTranspose_branches0123 copies separate cover ceiling five_gammaTranspose_check0123 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0123, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0124 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0124 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0124 ((1 : Int),(7 : Int)) five_gammaTranspose_branches0124 copies separate cover ceiling five_gammaTranspose_check0124 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0124, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0122 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0122 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0122 ((3 : Int),(4 : Int)) five_gammaTranspose_branches0122 copies separate cover ceiling five_gammaTranspose_check0122 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0122, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0123 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0124 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0126 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0126 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0126 ((1 : Int),(7 : Int)) five_gammaTranspose_branches0126 copies separate cover ceiling five_gammaTranspose_check0126 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0126, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0127 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0127 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0127 ((1 : Int),(7 : Int)) five_gammaTranspose_branches0127 copies separate cover ceiling five_gammaTranspose_check0127 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0127, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0125 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0125 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0125 ((3 : Int),(4 : Int)) five_gammaTranspose_branches0125 copies separate cover ceiling five_gammaTranspose_check0125 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0125, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0126 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0127 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0121 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0121 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0121 ((1 : Int),(6 : Int)) five_gammaTranspose_branches0121 copies separate cover ceiling five_gammaTranspose_check0121 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0121, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0122 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0125 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0129 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0129 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0129 ((1 : Int),(6 : Int)) five_gammaTranspose_branches0129 copies separate cover ceiling five_gammaTranspose_check0129 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0129, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0128 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0128 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0128 ((2 : Int),(4 : Int)) five_gammaTranspose_branches0128 copies separate cover ceiling five_gammaTranspose_check0128 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0128, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact five_gammaTranspose_node0129 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0130 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0130 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0130 ((2 : Int),(4 : Int)) five_gammaTranspose_branches0130 copies separate cover ceiling five_gammaTranspose_check0130 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0130, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0132 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0132 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0132 ((1 : Int),(6 : Int)) five_gammaTranspose_branches0132 copies separate cover ceiling five_gammaTranspose_check0132 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0132, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0131 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0131 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0131 ((2 : Int),(4 : Int)) five_gammaTranspose_branches0131 copies separate cover ceiling five_gammaTranspose_check0131 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0131, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact five_gammaTranspose_node0132 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0119 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0119 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0119 ((1 : Int),(5 : Int)) five_gammaTranspose_branches0119 copies separate cover ceiling five_gammaTranspose_check0119 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0119, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact five_gammaTranspose_node0120 world h nextB nextState
  · exact five_gammaTranspose_node0121 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0128 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0130 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0131 world h copies separate cover ceiling nextB nextState
theorem five_gammaTranspose_node0134 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0134 B) : Transition world h .gammaTranspose B := by
  exact replay_leaf world h .gammaTranspose five_gammaTranspose_occ0134 .alpha (3 : Int) (4 : Int) five_gammaTranspose_check0134 B state
include copies separate cover ceiling in
theorem five_gammaTranspose_node0137 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0137 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0137 ((1 : Int),(7 : Int)) five_gammaTranspose_branches0137 copies separate cover ceiling five_gammaTranspose_check0137 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0137, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0138 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0138 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0138 ((1 : Int),(7 : Int)) five_gammaTranspose_branches0138 copies separate cover ceiling five_gammaTranspose_check0138 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0138, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0136 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0136 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0136 ((3 : Int),(4 : Int)) five_gammaTranspose_branches0136 copies separate cover ceiling five_gammaTranspose_check0136 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0136, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0137 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0138 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0140 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0140 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0140 ((1 : Int),(7 : Int)) five_gammaTranspose_branches0140 copies separate cover ceiling five_gammaTranspose_check0140 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0140, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0141 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0141 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0141 ((1 : Int),(7 : Int)) five_gammaTranspose_branches0141 copies separate cover ceiling five_gammaTranspose_check0141 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0141, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0139 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0139 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0139 ((3 : Int),(4 : Int)) five_gammaTranspose_branches0139 copies separate cover ceiling five_gammaTranspose_check0139 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0139, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0140 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0141 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0135 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0135 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0135 ((1 : Int),(6 : Int)) five_gammaTranspose_branches0135 copies separate cover ceiling five_gammaTranspose_check0135 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0135, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0136 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0139 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0143 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0143 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0143 ((1 : Int),(6 : Int)) five_gammaTranspose_branches0143 copies separate cover ceiling five_gammaTranspose_check0143 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0143, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0142 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0142 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0142 ((2 : Int),(4 : Int)) five_gammaTranspose_branches0142 copies separate cover ceiling five_gammaTranspose_check0142 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0142, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact five_gammaTranspose_node0143 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0144 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0144 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0144 ((2 : Int),(4 : Int)) five_gammaTranspose_branches0144 copies separate cover ceiling five_gammaTranspose_check0144 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0144, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0146 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0146 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0146 ((1 : Int),(6 : Int)) five_gammaTranspose_branches0146 copies separate cover ceiling five_gammaTranspose_check0146 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0146, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0145 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0145 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0145 ((2 : Int),(4 : Int)) five_gammaTranspose_branches0145 copies separate cover ceiling five_gammaTranspose_check0145 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0145, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl
  · exact five_gammaTranspose_node0146 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0133 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0133 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0133 ((1 : Int),(5 : Int)) five_gammaTranspose_branches0133 copies separate cover ceiling five_gammaTranspose_check0133 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0133, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact five_gammaTranspose_node0134 world h nextB nextState
  · exact five_gammaTranspose_node0135 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0142 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0144 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0145 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0118 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0118 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0118 ((3 : Int),(1 : Int)) five_gammaTranspose_branches0118 copies separate cover ceiling five_gammaTranspose_check0118 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0118, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0119 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0133 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0115 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0115 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0115 ((0 : Int),(4 : Int)) five_gammaTranspose_branches0115 copies separate cover ceiling five_gammaTranspose_check0115 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0115, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact five_gammaTranspose_node0116 world h nextB nextState
  · exact five_gammaTranspose_node0117 world h nextB nextState
  · exact five_gammaTranspose_node0118 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0150 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0150 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0150 ((2 : Int),(4 : Int)) five_gammaTranspose_branches0150 copies separate cover ceiling five_gammaTranspose_check0150 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0150, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0151 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0151 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0151 ((2 : Int),(4 : Int)) five_gammaTranspose_branches0151 copies separate cover ceiling five_gammaTranspose_check0151 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0151, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0149 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0149 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0149 ((1 : Int),(4 : Int)) five_gammaTranspose_branches0149 copies separate cover ceiling five_gammaTranspose_check0149 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0149, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0150 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0151 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0153 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0153 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0153 ((2 : Int),(4 : Int)) five_gammaTranspose_branches0153 copies separate cover ceiling five_gammaTranspose_check0153 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0153, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0154 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0154 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0154 ((2 : Int),(4 : Int)) five_gammaTranspose_branches0154 copies separate cover ceiling five_gammaTranspose_check0154 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0154, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0152 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0152 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0152 ((1 : Int),(4 : Int)) five_gammaTranspose_branches0152 copies separate cover ceiling five_gammaTranspose_check0152 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0152, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0153 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0154 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0148 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0148 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0148 ((3 : Int),(1 : Int)) five_gammaTranspose_branches0148 copies separate cover ceiling five_gammaTranspose_check0148 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0148, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0149 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0152 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0156 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0156 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0156 ((1 : Int),(4 : Int)) five_gammaTranspose_branches0156 copies separate cover ceiling five_gammaTranspose_check0156 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0156, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0157 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0157 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0157 ((1 : Int),(4 : Int)) five_gammaTranspose_branches0157 copies separate cover ceiling five_gammaTranspose_check0157 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0157, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0155 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0155 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0155 ((3 : Int),(1 : Int)) five_gammaTranspose_branches0155 copies separate cover ceiling five_gammaTranspose_check0155 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0155, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0156 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0157 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0159 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0159 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0159 ((1 : Int),(4 : Int)) five_gammaTranspose_branches0159 copies separate cover ceiling five_gammaTranspose_check0159 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0159, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0160 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0160 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0160 ((1 : Int),(4 : Int)) five_gammaTranspose_branches0160 copies separate cover ceiling five_gammaTranspose_check0160 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0160, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0158 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0158 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0158 ((3 : Int),(1 : Int)) five_gammaTranspose_branches0158 copies separate cover ceiling five_gammaTranspose_check0158 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0158, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0159 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0160 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0147 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0147 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0147 ((0 : Int),(4 : Int)) five_gammaTranspose_branches0147 copies separate cover ceiling five_gammaTranspose_check0147 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0147, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · exact five_gammaTranspose_node0148 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0155 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0158 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0071 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0071 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0071 ((0 : Int),(3 : Int)) five_gammaTranspose_branches0071 copies separate cover ceiling five_gammaTranspose_check0071 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0071, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact five_gammaTranspose_node0072 world h nextB nextState
  · exact five_gammaTranspose_node0073 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0108 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0115 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0147 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0161 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0161 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0161 ((1 : Int),(1 : Int)) five_gammaTranspose_branches0161 copies separate cover ceiling five_gammaTranspose_check0161 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0161, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0162 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0162 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0162 ((1 : Int),(1 : Int)) five_gammaTranspose_branches0162 copies separate cover ceiling five_gammaTranspose_check0162 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0162, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0163 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0163 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0163 ((1 : Int),(1 : Int)) five_gammaTranspose_branches0163 copies separate cover ceiling five_gammaTranspose_check0163 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0163, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0051 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0051 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0051 ((0 : Int),(2 : Int)) five_gammaTranspose_branches0051 copies separate cover ceiling five_gammaTranspose_check0051 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0051, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact five_gammaTranspose_node0052 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0068 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0069 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0070 world h nextB nextState
  · exact five_gammaTranspose_node0071 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0161 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0162 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0163 world h copies separate cover ceiling nextB nextState
theorem five_gammaTranspose_node0164 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0164 B) : Transition world h .gammaTranspose B := by
  exact replay_leaf world h .gammaTranspose five_gammaTranspose_occ0164 .beta (0 : Int) (1 : Int) five_gammaTranspose_check0164 B state
include copies separate cover ceiling in
theorem five_gammaTranspose_node0167 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0167 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0167 ((2 : Int),(1 : Int)) five_gammaTranspose_branches0167 copies separate cover ceiling five_gammaTranspose_check0167 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0167, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0168 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0168 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0168 ((2 : Int),(1 : Int)) five_gammaTranspose_branches0168 copies separate cover ceiling five_gammaTranspose_check0168 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0168, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0166 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0166 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0166 ((1 : Int),(1 : Int)) five_gammaTranspose_branches0166 copies separate cover ceiling five_gammaTranspose_check0166 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0166, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0167 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0168 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0169 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0169 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0169 ((1 : Int),(1 : Int)) five_gammaTranspose_branches0169 copies separate cover ceiling five_gammaTranspose_check0169 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0169, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0170 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0170 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0170 ((1 : Int),(1 : Int)) five_gammaTranspose_branches0170 copies separate cover ceiling five_gammaTranspose_check0170 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0170, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0173 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0173 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0173 ((3 : Int),(1 : Int)) five_gammaTranspose_branches0173 copies separate cover ceiling five_gammaTranspose_check0173 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0173, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0174 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0174 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0174 ((3 : Int),(1 : Int)) five_gammaTranspose_branches0174 copies separate cover ceiling five_gammaTranspose_check0174 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0174, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0172 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0172 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0172 ((2 : Int),(1 : Int)) five_gammaTranspose_branches0172 copies separate cover ceiling five_gammaTranspose_check0172 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0172, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0173 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0174 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0176 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0176 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0176 ((3 : Int),(1 : Int)) five_gammaTranspose_branches0176 copies separate cover ceiling five_gammaTranspose_check0176 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0176, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0177 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0177 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0177 ((3 : Int),(1 : Int)) five_gammaTranspose_branches0177 copies separate cover ceiling five_gammaTranspose_check0177 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0177, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0175 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0175 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0175 ((2 : Int),(1 : Int)) five_gammaTranspose_branches0175 copies separate cover ceiling five_gammaTranspose_check0175 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0175, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0176 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0177 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0171 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0171 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0171 ((0 : Int),(3 : Int)) five_gammaTranspose_branches0171 copies separate cover ceiling five_gammaTranspose_check0171 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0171, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · exact five_gammaTranspose_node0172 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0175 world h copies separate cover ceiling nextB nextState
theorem five_gammaTranspose_node0179 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0179 B) : Transition world h .gammaTranspose B := by
  exact replay_leaf world h .gammaTranspose five_gammaTranspose_occ0179 .alpha (1 : Int) (3 : Int) five_gammaTranspose_check0179 B state
include copies separate cover ceiling in
theorem five_gammaTranspose_node0180 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0180 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0180 ((2 : Int),(1 : Int)) five_gammaTranspose_branches0180 copies separate cover ceiling five_gammaTranspose_check0180 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0180, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0181 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0181 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0181 ((2 : Int),(1 : Int)) five_gammaTranspose_branches0181 copies separate cover ceiling five_gammaTranspose_check0181 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0181, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0182 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0182 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0182 ((2 : Int),(1 : Int)) five_gammaTranspose_branches0182 copies separate cover ceiling five_gammaTranspose_check0182 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0182, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0183 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0183 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0183 ((2 : Int),(1 : Int)) five_gammaTranspose_branches0183 copies separate cover ceiling five_gammaTranspose_check0183 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0183, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0178 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0178 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0178 ((0 : Int),(3 : Int)) five_gammaTranspose_branches0178 copies separate cover ceiling five_gammaTranspose_check0178 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0178, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact five_gammaTranspose_node0179 world h nextB nextState
  · exact five_gammaTranspose_node0180 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0181 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0182 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0183 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0184 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0184 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0184 ((1 : Int),(1 : Int)) five_gammaTranspose_branches0184 copies separate cover ceiling five_gammaTranspose_check0184 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0184, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0185 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0185 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0185 ((1 : Int),(1 : Int)) five_gammaTranspose_branches0185 copies separate cover ceiling five_gammaTranspose_check0185 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0185, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0186 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0186 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0186 ((1 : Int),(1 : Int)) five_gammaTranspose_branches0186 copies separate cover ceiling five_gammaTranspose_check0186 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0186, List.mem_cons, List.not_mem_nil, or_false] at member
include copies separate cover ceiling in
theorem five_gammaTranspose_node0165 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0165 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0165 ((0 : Int),(2 : Int)) five_gammaTranspose_branches0165 copies separate cover ceiling five_gammaTranspose_check0165 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0165, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact five_gammaTranspose_node0166 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0169 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0170 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0171 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0178 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0184 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0185 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0186 world h copies separate cover ceiling nextB nextState
include copies separate cover ceiling in
theorem five_gammaTranspose_node0000 (B : Int → Int → Prop)
    (state : State world h five_gammaTranspose_occ0000 B) : Transition world h .gammaTranspose B := by
  apply replay_step (5 : Int) (by decide) world h .gammaTranspose five_gammaTranspose_occ0000 ((1 : Int),(0 : Int)) five_gammaTranspose_branches0000 copies separate cover ceiling five_gammaTranspose_check0000 ?_ B state
  intro branch member nextB nextState
  simp only [five_gammaTranspose_branches0000, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact five_gammaTranspose_node0001 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0002 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0038 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0051 world h copies separate cover ceiling nextB nextState
  · exact five_gammaTranspose_node0164 world h nextB nextState
  · exact five_gammaTranspose_node0165 world h copies separate cover ceiling nextB nextState
end FiveGammaTranspose

theorem five_gammaTranspose_seed_eq : SameCells (seed .gammaTranspose) five_gammaTranspose_occ0000 := by decide

theorem five_gammaTranspose_local (world : Cross → Prop) (h : Int) (B : Int → Int → Prop)
    (copies : ∀ t, world t → Copy 5 1 1 0 t)
    (separate : DisjointWorld world) (cover : CoversWindow world h)
    (ceiling : SelectedBelow world h) (closed : TileClosed world B)
    (bounded : Below h B) (clean : Clean .gammaTranspose 0 0 B) :
    Transition world h .gammaTranspose B := by
  exact five_gammaTranspose_node0000 world h copies separate cover ceiling B
    (state_congr five_gammaTranspose_seed_eq (seed_state world h .gammaTranspose B closed bounded clean))
#print axioms five_gammaTranspose_local

end CornerCertificate

import LHalfPlaneAlternatingReflection
import LHalfPlaneAssembly
import LHalfPlaneFiveThree

namespace PolyominoFormal.LHalfPlaneUnequal
open CrossUnits LHalfPlaneAlternating

def MixedObstruction (a b : Int) : Prop :=
  ∀T:Tiling a b 0 0 HalfPlane, a=b+2 → (a≠5 ∨ b≠3) →
    T.world ⟨-1,0,0,b,a,0⟩ → T.world ⟨0,0,a,b,0,0⟩ →
    T.world ⟨2*a+1,0,0,b,a,0⟩ → T.world ⟨2*a+2,0,a,b,0,0⟩ →
    T.world ⟨1,1,a,b,0,0⟩ → T.world ⟨2*a,1,0,a,b,0⟩ → False

/-- The reflected mixed pattern is reduced using the actual reflected tiling,
including all eight boundary bars. -/
theorem no_eight_of_delta_and_mixed {a b : Int} (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (delta : ∀T:Tiling a b 0 0 HalfPlane, EightBars T → a=b+2)
    (mixed : MixedObstruction a b) : LHalfPlaneAssembly.NoEightAlternatingBars a b := by
  intro T hL0 hL1 h0 h1 h2 h3 hR0 hR1
  have bars : EightBars T := ⟨hL0,hL1,h0,h1,h2,h3,hR0,hR1⟩
  by_cases special : a=5 ∧ b=3
  · rcases special with ⟨rfl,rfl⟩
    exact LHalfPlaneFiveThree.no_halfplane ⟨T⟩
  have hex : a≠5 ∨ b≠3 := by omega
  have hd := delta T bars
  rcases mixed_motif_of_delta_two ha hb hab hd T bars with first | second
  · exact mixed T hd hex h0 h1 h2 h3 first.1 first.2
  · let U := reflectPocket T
    have ubars : EightBars U := reflect_eight_bars T bars
    have upper : U.world ⟨1,1,a,b,0,0⟩ := by
      have member := reflect_pocket_member T second.2
      simpa only [reflectCross,show 2*a+1-2*a=1 by omega] using member
    have lower : U.world ⟨2*a,1,0,a,b,0⟩ := by
      have member := reflect_pocket_member T second.1
      simpa only [reflectCross,show 2*a+1-1=2*a by omega] using member
    exact mixed U hd hex ubars.2.2.1 ubars.2.2.2.1 ubars.2.2.2.2.1
      ubars.2.2.2.2.2.1 upper lower

theorem no_halfplane_from_inputs {a b : Int} (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (short : LHalfPlaneAssembly.NoShortBars a b)
    (delta : ∀T:Tiling a b 0 0 HalfPlane, EightBars T → a=b+2)
    (mixed : MixedObstruction a b) : ¬Tiles a b 0 0 HalfPlane := by
  exact LHalfPlaneAssembly.no_halfplane_from_eight ha hb hab short
    (LHalfPlaneAssembly.same_bars ha hb hab)
    (no_eight_of_delta_and_mixed ha hb hab delta mixed)

#print axioms no_eight_of_delta_and_mixed
#print axioms no_halfplane_from_inputs
end PolyominoFormal.LHalfPlaneUnequal

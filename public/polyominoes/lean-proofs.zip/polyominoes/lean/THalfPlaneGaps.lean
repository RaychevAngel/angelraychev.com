import THalfPlaneStarters

namespace PolyominoFormal.THalfPlaneGaps
open CrossUnits CornerCertificate THalfPlaneStarters

theorem single_closed {a b c d : Int} {R : Region} (T : Tiling a b c d R)
    {t : Cross} (ht : T.world t) : TileClosed T.world (Contains t) := by
  intro u hu x y hit blocked p q other
  have eq := T.disjoint u t x y hu ht hit blocked
  simpa only [eq] using other

theorem union_closed {world : Cross→Prop} {B C : Region}
    (hb : TileClosed world B) (hc : TileClosed world C) :
    TileClosed world (fun x y => B x y ∨ C x y) := by
  intro t ht x y hit blocked p q other
  rcases blocked with b | c
  · exact Or.inl (hb t ht x y hit b p q other)
  · exact Or.inr (hc t ht x y hit c p q other)

theorem pair_closed {a b c d : Int} {R : Region} (T : Tiling a b c d R)
    {t u : Cross} (ht : T.world t) (hu : T.world u) :
    TileClosed T.world (fun x y => Contains t x y ∨ Contains u x y) :=
  union_closed (single_closed T ht) (single_closed T hu)

/-- Two adjacent boundary bars cannot have a descending pair of junction
offsets when their resulting gap has at least three cells. -/
theorem no_short_horizontal_pair {a b c p r s : Int}
    (ha : c≤a) (hc : 1≤c) (hb : 1≤b) (short : b≤a+c)
    (hr : r=a ∨ r=c) (hs : s=a ∨ s=c)
    (descending : s≤r) (gap : 3≤a+c+s-r)
    (T : Tiling a b c 0 HalfPlane)
    (first : T.world ⟨p+r,0,a+c-r,b,r,0⟩)
    (second : T.world ⟨p+(a+c+1)+s,0,a+c-s,b,s,0⟩) : False := by
  let t : Cross := ⟨p+r,0,a+c-r,b,r,0⟩
  let u : Cross := ⟨p+(a+c+1)+s,0,a+c-s,b,s,0⟩
  let B : Region := fun x y => Contains t x y ∨ Contains u x y
  apply blocked_short_run (L:=p+r+1) (R:=p+(a+c+1)+s-1) (h:=1)
    (by omega) hb hc short (by omega) (by omega) T B (pair_closed T first second)
  · intro x hx0 hx1
    exact show (0:Int)≤1 by omega
  · intro x hx0 hx1
    dsimp [B,t,u,Contains]
    omega
  · intro x hx0 hx1
    dsimp [B,t,u,Contains]
    omega
  · dsimp [B,t,u,Contains]
    omega
  · dsimp [B,t,u,Contains]
    omega

def HorizontalCover {a b c : Int} (T : Tiling a b c 0 HalfPlane) : Prop :=
  ∀ x, ∃ p r, (r=a ∨ r=c) ∧ T.world ⟨p+r,0,a+c-r,b,r,0⟩ ∧
    p≤x ∧ x≤p+a+c

theorem next_horizontal {a b c p r : Int}
    (ha : c≤a) (hc : 1≤c) (hb : 1≤b) (hr : r=a ∨ r=c)
    (T : Tiling a b c 0 HalfPlane) (cover : HorizontalCover T)
    (anchor : T.world ⟨p+r,0,a+c-r,b,r,0⟩) :
    ∃ s, (s=a ∨ s=c) ∧ T.world ⟨p+(a+c+1)+s,0,a+c-s,b,s,0⟩ := by
  obtain ⟨q,s,hs,hu,hq0,hq1⟩ := cover (p+(a+c+1))
  have hit : Contains ⟨q+s,0,a+c-s,b,s,0⟩ (p+(a+c+1)) 0 := by
    left; dsimp; omega
  have ap := TBoundary.separate (by omega) (by omega) (by omega) T hu anchor hit
    (by simp only [Contains]; omega)
  have hq : q=p+(a+c+1) := by
    dsimp [Apart] at ap
    omega
  subst q
  exact ⟨s,hs,hu⟩

theorem all_horizontal_short_impossible {a b c : Int}
    (ha : c≤a) (hc : 2≤c) (hb : 1≤b) (short : b≤a+c)
    (T : Tiling a b c 0 HalfPlane) (cover : HorizontalCover T) : False := by
  obtain ⟨p,r,hr,first,_,_⟩ := cover 0
  obtain ⟨s,hs,second⟩ := next_horizontal ha (by omega) hb hr T cover first
  by_cases desc : s≤r
  · exact no_short_horizontal_pair ha (by omega) hb short hr hs desc (by omega) T first second
  · obtain ⟨q,hq,third⟩ := next_horizontal ha (by omega) hb hs T cover second
    have desc2 : q≤s := by omega
    exact no_short_horizontal_pair ha (by omega) hb short hs hq desc2 (by omega) T second third

#print axioms no_short_horizontal_pair
#print axioms all_horizontal_short_impossible
end PolyominoFormal.THalfPlaneGaps

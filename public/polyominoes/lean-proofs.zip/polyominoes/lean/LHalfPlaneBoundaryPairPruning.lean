import LHalfPlaneAlternatingPairPruning
import LHalfPlaneLongCorner
namespace PolyominoFormal.LRegion
open CrossUnits

def ForbiddenBoundaryPairs (a b : Int) (t u : Cross) : Prop :=
  ForbiddenSameBoundaryBars a b t u ∨ ForbiddenLongBoundaryCorner a b t u

theorem avoid_boundary_pairs (a b : Int) (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (T : Tiling a b 0 0 HalfPlane) :
    ∀t u,T.world t → T.world u → ¬ForbiddenBoundaryPairs a b t u := by
  intro t u ht hu bad
  rcases bad with bad|bad
  · exact avoid_same_boundary_bars a b ha hb hab T t u ht hu bad
  · exact avoid_long_boundary_corner a b ha hb hab T t u ht hu bad

#print axioms avoid_boundary_pairs
end PolyominoFormal.LRegion

import CornerAffineBetaArithmetic
import CornerCertificateAffineReplay

set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace CornerCertificate
open CrossUnits

def affine_beta_known000 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))]
def affine_beta_known001 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a)]
def affine_beta_known002 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_beta_known003 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_beta_known004 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_beta_known005 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (2 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_beta_known006 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_beta_known007 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a)]
def affine_beta_known008 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (2 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_beta_known009 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (2 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_beta_known010 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (1 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_beta_known011 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (1 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_beta_known012 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int))]
def affine_beta_known013 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((4 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a)]
def affine_beta_known014 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((4 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (3 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_beta_known015 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((4 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (3 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_beta_known016 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_beta_known017 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (3 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_beta_known018 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (3 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_beta_known019 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int))]
def affine_beta_known020 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_beta_known021 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_beta_known022 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_beta_known023 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_beta_known024 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_beta_known025 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_beta_known026 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (2 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_beta_known027 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_beta_known028 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_beta_known029 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) (0 : Int) a (1 : Int) (1 : Int))]
def affine_beta_known030 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int))]
def affine_beta_known031 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a)]
def affine_beta_known032 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_beta_known033 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_beta_known034 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_beta_known035 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_beta_known036 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (1 : Int) ((4 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a)]
def affine_beta_known037 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (1 : Int) ((4 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (2 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_beta_known038 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (1 : Int) ((4 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (2 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_beta_known039 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (1 : Int) (5 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_beta_known040 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (1 : Int) ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_beta_known041 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int))]
def affine_beta_known042 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((5 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a)]
def affine_beta_known043 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((5 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (3 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_beta_known044 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((5 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (3 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_beta_known045 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((5 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_beta_known046 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((5 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (3 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_beta_known047 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((5 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (3 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_beta_known048 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int))]
def affine_beta_known049 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_beta_known050 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_beta_known051 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_beta_known052 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_beta_known053 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_beta_known054 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (1 : Int) ((4 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a)]
def affine_beta_known055 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (1 : Int) ((4 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (2 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_beta_known056 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (1 : Int) ((4 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (2 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_beta_known057 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (1 : Int) (5 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_beta_known058 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (1 : Int) ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_beta_known059 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int))]
def affine_beta_known060 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((5 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a)]
def affine_beta_known061 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((5 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (3 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_beta_known062 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((5 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (3 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_beta_known063 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((5 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_beta_known064 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((5 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (3 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_beta_known065 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)),(Cross.mk (1 : Int) ((5 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (3 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_beta_known066 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int))]
def affine_beta_known067 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_beta_known068 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_beta_known069 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_beta_known070 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_beta_known071 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_beta_known072 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_beta_known073 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_beta_known074 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_beta_known075 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_beta_known076 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_beta_known077 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_beta_known078 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a)]
def affine_beta_known079 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_beta_known080 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_beta_known081 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int))]
def affine_beta_known082 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int))]
def affine_beta_known083 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (2 : Int) (5 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_beta_known084 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (2 : Int) (5 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_beta_known085 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (2 : Int) (5 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_beta_known086 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (5 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_beta_known087 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (5 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_beta_known088 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (5 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_beta_known089 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_beta_known090 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_beta_known091 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_beta_known092 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_beta_known093 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((2 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_beta_known094 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_beta_known095 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a)]
def affine_beta_known096 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_beta_known097 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_beta_known098 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int))]
def affine_beta_known099 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int))]
def affine_beta_known100 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (2 : Int) (5 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_beta_known101 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (2 : Int) (5 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_beta_known102 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (2 : Int) (5 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_beta_known103 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (5 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_beta_known104 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (5 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_beta_known105 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (5 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_beta_known106 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_beta_known107 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_beta_known108 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_beta_known109 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_beta_known110 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((2 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_beta_known111 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk a (2 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_beta_known112 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk a (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_beta_known113 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk a (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a)]
def affine_beta_known114 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk a (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_beta_known115 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk a (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_beta_known116 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk a (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_beta_known117 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk a (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_beta_known118 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk a (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_beta_known119 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk a (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a)]
def affine_beta_known120 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk a (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_beta_known121 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk a (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_beta_known122 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk a (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_beta_known123 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk a (2 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_beta_known124 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_beta_known125 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_beta_known126 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a)]
def affine_beta_known127 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_beta_known128 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_beta_known129 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int))]
def affine_beta_known130 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int))]
def affine_beta_known131 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_beta_known132 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_beta_known133 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_beta_known134 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_beta_known135 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_beta_known136 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)),(Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_beta_known137 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int))]
def affine_beta_known138 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_beta_known139 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_beta_known140 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_beta_known141 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a),(Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_beta_known142 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (1 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_beta_known143 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int))]
def affine_beta_known144 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int))]
def affine_beta_known145 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a)]
def affine_beta_known146 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_beta_known147 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a),(Cross.mk (1 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_beta_known148 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int))]
def affine_beta_known149 (a : Int) : List Cross := [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk (5 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)),(Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)),(Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)),(Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)]
def affine_beta_branches000 (a : Int) : List Branch := [Branch.mk (Cross.mk (0 : Int) ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_beta_known001 a)),Branch.mk (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known002 a)),Branch.mk (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known023 a)),Branch.mk (Cross.mk (1 : Int) (1 : Int) (0 : Int) a (1 : Int) (1 : Int)) (knownCells (affine_beta_known029 a)),Branch.mk (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (knownCells (affine_beta_known030 a)),Branch.mk (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known124 a)),Branch.mk (Cross.mk a (1 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known142 a)),Branch.mk (Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known143 a))]
def affine_beta_branches002 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known003 a)),Branch.mk (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known004 a)),Branch.mk (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known022 a))]
def affine_beta_branches003 (a : Int) : List Branch := []
def affine_beta_branches004 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known005 a)),Branch.mk (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known006 a))]
def affine_beta_branches006 (a : Int) : List Branch := [Branch.mk (Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_beta_known007 a)),Branch.mk (Cross.mk (1 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known010 a)),Branch.mk (Cross.mk (1 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known011 a)),Branch.mk (Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)) (knownCells (affine_beta_known012 a)),Branch.mk (Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)) (knownCells (affine_beta_known019 a)),Branch.mk (Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known020 a)),Branch.mk (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known021 a))]
def affine_beta_branches007 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known008 a)),Branch.mk (Cross.mk (2 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known009 a))]
def affine_beta_branches008 (a : Int) : List Branch := []
def affine_beta_branches009 (a : Int) : List Branch := []
def affine_beta_branches010 (a : Int) : List Branch := []
def affine_beta_branches011 (a : Int) : List Branch := []
def affine_beta_branches012 (a : Int) : List Branch := [Branch.mk (Cross.mk (1 : Int) ((4 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_beta_known013 a)),Branch.mk (Cross.mk (1 : Int) ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known016 a))]
def affine_beta_branches013 (a : Int) : List Branch := [Branch.mk (Cross.mk (3 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known014 a)),Branch.mk (Cross.mk (3 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known015 a))]
def affine_beta_branches014 (a : Int) : List Branch := []
def affine_beta_branches015 (a : Int) : List Branch := []
def affine_beta_branches016 (a : Int) : List Branch := [Branch.mk (Cross.mk (3 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known017 a)),Branch.mk (Cross.mk (3 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known018 a))]
def affine_beta_branches017 (a : Int) : List Branch := []
def affine_beta_branches018 (a : Int) : List Branch := []
def affine_beta_branches020 (a : Int) : List Branch := []
def affine_beta_branches021 (a : Int) : List Branch := []
def affine_beta_branches022 (a : Int) : List Branch := []
def affine_beta_branches023 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known024 a)),Branch.mk (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known025 a)),Branch.mk (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known028 a))]
def affine_beta_branches024 (a : Int) : List Branch := []
def affine_beta_branches025 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known026 a)),Branch.mk (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known027 a))]
def affine_beta_branches026 (a : Int) : List Branch := []
def affine_beta_branches027 (a : Int) : List Branch := []
def affine_beta_branches028 (a : Int) : List Branch := []
def affine_beta_branches030 (a : Int) : List Branch := [Branch.mk (Cross.mk (0 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_beta_known031 a)),Branch.mk (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known032 a)),Branch.mk (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known069 a)),Branch.mk (Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known076 a)),Branch.mk (Cross.mk a (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known111 a))]
def affine_beta_branches032 (a : Int) : List Branch := [Branch.mk (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known033 a)),Branch.mk (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known051 a))]
def affine_beta_branches033 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known034 a)),Branch.mk (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known035 a))]
def affine_beta_branches035 (a : Int) : List Branch := [Branch.mk (Cross.mk (1 : Int) ((4 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_beta_known036 a)),Branch.mk (Cross.mk (1 : Int) (5 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known039 a)),Branch.mk (Cross.mk (1 : Int) ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known040 a)),Branch.mk (Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)) (knownCells (affine_beta_known041 a)),Branch.mk (Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)) (knownCells (affine_beta_known048 a)),Branch.mk (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known049 a)),Branch.mk (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known050 a))]
def affine_beta_branches036 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known037 a)),Branch.mk (Cross.mk (2 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known038 a))]
def affine_beta_branches037 (a : Int) : List Branch := []
def affine_beta_branches038 (a : Int) : List Branch := []
def affine_beta_branches039 (a : Int) : List Branch := []
def affine_beta_branches040 (a : Int) : List Branch := []
def affine_beta_branches041 (a : Int) : List Branch := [Branch.mk (Cross.mk (1 : Int) ((5 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_beta_known042 a)),Branch.mk (Cross.mk (1 : Int) ((5 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known045 a))]
def affine_beta_branches042 (a : Int) : List Branch := [Branch.mk (Cross.mk (3 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known043 a)),Branch.mk (Cross.mk (3 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known044 a))]
def affine_beta_branches043 (a : Int) : List Branch := []
def affine_beta_branches044 (a : Int) : List Branch := []
def affine_beta_branches045 (a : Int) : List Branch := [Branch.mk (Cross.mk (3 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known046 a)),Branch.mk (Cross.mk (3 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known047 a))]
def affine_beta_branches046 (a : Int) : List Branch := []
def affine_beta_branches047 (a : Int) : List Branch := []
def affine_beta_branches049 (a : Int) : List Branch := []
def affine_beta_branches050 (a : Int) : List Branch := []
def affine_beta_branches051 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known052 a)),Branch.mk (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known053 a))]
def affine_beta_branches053 (a : Int) : List Branch := [Branch.mk (Cross.mk (1 : Int) ((4 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_beta_known054 a)),Branch.mk (Cross.mk (1 : Int) (5 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known057 a)),Branch.mk (Cross.mk (1 : Int) ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known058 a)),Branch.mk (Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)) (knownCells (affine_beta_known059 a)),Branch.mk (Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)) (knownCells (affine_beta_known066 a)),Branch.mk (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known067 a)),Branch.mk (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known068 a))]
def affine_beta_branches054 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known055 a)),Branch.mk (Cross.mk (2 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known056 a))]
def affine_beta_branches055 (a : Int) : List Branch := []
def affine_beta_branches056 (a : Int) : List Branch := []
def affine_beta_branches057 (a : Int) : List Branch := []
def affine_beta_branches058 (a : Int) : List Branch := []
def affine_beta_branches059 (a : Int) : List Branch := [Branch.mk (Cross.mk (1 : Int) ((5 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_beta_known060 a)),Branch.mk (Cross.mk (1 : Int) ((5 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known063 a))]
def affine_beta_branches060 (a : Int) : List Branch := [Branch.mk (Cross.mk (3 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known061 a)),Branch.mk (Cross.mk (3 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known062 a))]
def affine_beta_branches061 (a : Int) : List Branch := []
def affine_beta_branches062 (a : Int) : List Branch := []
def affine_beta_branches063 (a : Int) : List Branch := [Branch.mk (Cross.mk (3 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known064 a)),Branch.mk (Cross.mk (3 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known065 a))]
def affine_beta_branches064 (a : Int) : List Branch := []
def affine_beta_branches065 (a : Int) : List Branch := []
def affine_beta_branches067 (a : Int) : List Branch := []
def affine_beta_branches068 (a : Int) : List Branch := []
def affine_beta_branches069 (a : Int) : List Branch := [Branch.mk (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known070 a)),Branch.mk (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known073 a))]
def affine_beta_branches070 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known071 a)),Branch.mk (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known072 a))]
def affine_beta_branches071 (a : Int) : List Branch := []
def affine_beta_branches072 (a : Int) : List Branch := []
def affine_beta_branches073 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known074 a)),Branch.mk (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known075 a))]
def affine_beta_branches074 (a : Int) : List Branch := []
def affine_beta_branches075 (a : Int) : List Branch := []
def affine_beta_branches076 (a : Int) : List Branch := [Branch.mk (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known077 a)),Branch.mk (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known094 a))]
def affine_beta_branches077 (a : Int) : List Branch := [Branch.mk (Cross.mk (0 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_beta_known078 a)),Branch.mk (Cross.mk (0 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known079 a)),Branch.mk (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known080 a))]
def affine_beta_branches080 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)) (knownCells (affine_beta_known081 a)),Branch.mk (Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)) (knownCells (affine_beta_known082 a)),Branch.mk (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known089 a)),Branch.mk (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known091 a)),Branch.mk (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known092 a))]
def affine_beta_branches082 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) (5 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known083 a)),Branch.mk (Cross.mk ((1 : Int) + a) (5 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known086 a))]
def affine_beta_branches083 (a : Int) : List Branch := [Branch.mk (Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known084 a)),Branch.mk (Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known085 a))]
def affine_beta_branches084 (a : Int) : List Branch := []
def affine_beta_branches085 (a : Int) : List Branch := []
def affine_beta_branches086 (a : Int) : List Branch := [Branch.mk (Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known087 a)),Branch.mk (Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known088 a))]
def affine_beta_branches087 (a : Int) : List Branch := []
def affine_beta_branches088 (a : Int) : List Branch := []
def affine_beta_branches089 (a : Int) : List Branch := [Branch.mk (Cross.mk ((2 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known090 a))]
def affine_beta_branches090 (a : Int) : List Branch := []
def affine_beta_branches091 (a : Int) : List Branch := []
def affine_beta_branches092 (a : Int) : List Branch := [Branch.mk (Cross.mk ((2 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known093 a))]
def affine_beta_branches093 (a : Int) : List Branch := []
def affine_beta_branches094 (a : Int) : List Branch := [Branch.mk (Cross.mk (0 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_beta_known095 a)),Branch.mk (Cross.mk (0 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known096 a)),Branch.mk (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known097 a))]
def affine_beta_branches097 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)) (knownCells (affine_beta_known098 a)),Branch.mk (Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)) (knownCells (affine_beta_known099 a)),Branch.mk (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known106 a)),Branch.mk (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known108 a)),Branch.mk (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known109 a))]
def affine_beta_branches099 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) (5 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known100 a)),Branch.mk (Cross.mk ((1 : Int) + a) (5 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known103 a))]
def affine_beta_branches100 (a : Int) : List Branch := [Branch.mk (Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known101 a)),Branch.mk (Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known102 a))]
def affine_beta_branches101 (a : Int) : List Branch := []
def affine_beta_branches102 (a : Int) : List Branch := []
def affine_beta_branches103 (a : Int) : List Branch := [Branch.mk (Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known104 a)),Branch.mk (Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known105 a))]
def affine_beta_branches104 (a : Int) : List Branch := []
def affine_beta_branches105 (a : Int) : List Branch := []
def affine_beta_branches106 (a : Int) : List Branch := [Branch.mk (Cross.mk ((2 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known107 a))]
def affine_beta_branches107 (a : Int) : List Branch := []
def affine_beta_branches108 (a : Int) : List Branch := []
def affine_beta_branches109 (a : Int) : List Branch := [Branch.mk (Cross.mk ((2 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known110 a))]
def affine_beta_branches110 (a : Int) : List Branch := []
def affine_beta_branches111 (a : Int) : List Branch := [Branch.mk (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known112 a)),Branch.mk (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known118 a))]
def affine_beta_branches112 (a : Int) : List Branch := [Branch.mk (Cross.mk (0 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_beta_known113 a)),Branch.mk (Cross.mk (0 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known116 a)),Branch.mk (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known117 a))]
def affine_beta_branches113 (a : Int) : List Branch := [Branch.mk (Cross.mk (1 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known114 a)),Branch.mk (Cross.mk (1 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known115 a))]
def affine_beta_branches114 (a : Int) : List Branch := []
def affine_beta_branches115 (a : Int) : List Branch := []
def affine_beta_branches116 (a : Int) : List Branch := []
def affine_beta_branches117 (a : Int) : List Branch := []
def affine_beta_branches118 (a : Int) : List Branch := [Branch.mk (Cross.mk (0 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_beta_known119 a)),Branch.mk (Cross.mk (0 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known122 a)),Branch.mk (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known123 a))]
def affine_beta_branches119 (a : Int) : List Branch := [Branch.mk (Cross.mk (1 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known120 a)),Branch.mk (Cross.mk (1 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known121 a))]
def affine_beta_branches120 (a : Int) : List Branch := []
def affine_beta_branches121 (a : Int) : List Branch := []
def affine_beta_branches122 (a : Int) : List Branch := []
def affine_beta_branches123 (a : Int) : List Branch := []
def affine_beta_branches124 (a : Int) : List Branch := [Branch.mk (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known125 a))]
def affine_beta_branches125 (a : Int) : List Branch := [Branch.mk (Cross.mk (0 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_beta_known126 a)),Branch.mk (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known127 a)),Branch.mk (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known128 a))]
def affine_beta_branches128 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)) (knownCells (affine_beta_known129 a)),Branch.mk (Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)) (knownCells (affine_beta_known130 a)),Branch.mk (Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known137 a)),Branch.mk (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known139 a)),Branch.mk (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known140 a))]
def affine_beta_branches130 (a : Int) : List Branch := [Branch.mk (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known131 a)),Branch.mk (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known134 a))]
def affine_beta_branches131 (a : Int) : List Branch := [Branch.mk (Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known132 a)),Branch.mk (Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known133 a))]
def affine_beta_branches132 (a : Int) : List Branch := []
def affine_beta_branches133 (a : Int) : List Branch := []
def affine_beta_branches134 (a : Int) : List Branch := [Branch.mk (Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known135 a)),Branch.mk (Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known136 a))]
def affine_beta_branches135 (a : Int) : List Branch := []
def affine_beta_branches136 (a : Int) : List Branch := []
def affine_beta_branches137 (a : Int) : List Branch := [Branch.mk (Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known138 a))]
def affine_beta_branches138 (a : Int) : List Branch := []
def affine_beta_branches139 (a : Int) : List Branch := []
def affine_beta_branches140 (a : Int) : List Branch := [Branch.mk (Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known141 a))]
def affine_beta_branches141 (a : Int) : List Branch := []
def affine_beta_branches142 (a : Int) : List Branch := []
def affine_beta_branches143 (a : Int) : List Branch := [Branch.mk (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known144 a))]
def affine_beta_branches144 (a : Int) : List Branch := [Branch.mk (Cross.mk (0 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_beta_known145 a)),Branch.mk (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known148 a)),Branch.mk (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known149 a))]
def affine_beta_branches145 (a : Int) : List Branch := [Branch.mk (Cross.mk (1 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known146 a)),Branch.mk (Cross.mk (1 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known147 a))]
def affine_beta_branches146 (a : Int) : List Branch := []
def affine_beta_branches147 (a : Int) : List Branch := []
def affine_beta_branches148 (a : Int) : List Branch := []
def affine_beta_branches149 (a : Int) : List Branch := []

theorem affine_beta_nonnegative000 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known000 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known000, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty000 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known000 a) (0 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n000_empty a ((by simpa only [KnownContains, affine_beta_known000, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window000 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known000 a)) B) : QueryWindow h (0 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_beta_nonnegative000 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known000])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n000_height a h (top1) ((by omega))

theorem affine_beta_complete000 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (0 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_beta_known000 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches000 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known000])
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known000])
  have apart6 := separated (Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known000])
  have apart7 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known000])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n000_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart1).1 (apart6).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known124 a)), by simp [affine_beta_branches000], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n000_o1 a jx jy (apart6).2.2.1 (apart1).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known023 a)), by simp [affine_beta_branches000], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk a (1 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n000_o2 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart2).1 (apart1).1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk a (1 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known142 a)), by simp [affine_beta_branches000], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a (1 : Int) (1 : Int)) (Cross.mk (1 : Int) (1 : Int) (0 : Int) a (1 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n000_o3 a jx jy (apart1).1 (apart6).2.2.1 (apart2).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) (1 : Int) (0 : Int) a (1 : Int) (1 : Int)) (knownCells (affine_beta_known029 a)), by simp [affine_beta_branches000], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (1 : Int) (1 : Int) a) (Cross.mk (0 : Int) ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n000_o4 a jx jy (apart7).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart6).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_beta_known001 a)), by simp [affine_beta_branches000], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n000_o5 a jx jy (apart1).1 (ha) (apart6).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known143 a)), by simp [affine_beta_branches000], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n000_o6 a jx jy (apart6).2.2.1 (apart1).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known002 a)), by simp [affine_beta_branches000], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (1 : Int) (1 : Int)) (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n000_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart2).1 (ha) (apart1).1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (knownCells (affine_beta_known030 a)), by simp [affine_beta_branches000], (same_eq m0).symm⟩

theorem affine_beta_nonnegative001 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known001 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known001, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_cover0_001 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known001 a) ((1 : Int)+(-1 : Int)) ((0 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n001_wall0 a ((by simpa only [KnownContains, affine_beta_known001, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover1_001 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known001 a) ((1 : Int)+(-1 : Int)) ((0 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n001_wall1 a (ha) ((by simpa only [KnownContains, affine_beta_known001, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover2_001 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known001 a) ((1 : Int)+(-1 : Int)) ((0 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n001_wall2 a (ha) ((by simpa only [KnownContains, affine_beta_known001, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover3_001 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known001 a) ((1 : Int)+(-1 : Int)) ((0 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n001_wall3 a (ha) ((by simpa only [KnownContains, affine_beta_known001, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover4_001 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known001 a) ((1 : Int)+(0 : Int)) ((0 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n001_wall4 a ((by simpa only [KnownContains, affine_beta_known001, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover5_001 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known001 a) ((1 : Int)+(1 : Int)) ((0 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n001_wall5 a ((by simpa only [KnownContains, affine_beta_known001, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover6_001 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known001 a) ((1 : Int)+(2 : Int)) ((0 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n001_wall6 a ((by simpa only [KnownContains, affine_beta_known001, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover7_001 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known001 a) ((1 : Int)+(3 : Int)) ((0 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n001_wall7 a ((by simpa only [KnownContains, affine_beta_known001, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_leaf001 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known001 a)) B) : Transition world h .beta B := by
  apply replay_affine_leaf world h .beta (affine_beta_known001 a) .alpha (1 : Int) (0 : Int) (affine_beta_nonnegative001 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .alpha x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (0 : Int)+y=((0 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover0_001 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (0 : Int)+y=((0 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover1_001 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (0 : Int)+y=((0 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover2_001 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (0 : Int)+y=((0 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover3_001 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(0 : Int)) := by omega
      have ey : (0 : Int)+y=((0 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover4_001 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(1 : Int)) := by omega
      have ey : (0 : Int)+y=((0 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover5_001 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(2 : Int)) := by omega
      have ey : (0 : Int)+y=((0 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover6_001 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(3 : Int)) := by omega
      have ey : (0 : Int)+y=((0 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover7_001 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.beta_n001_dirty a x y ((by simpa only [KnownContains, affine_beta_known001, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (hy) (hx)
    · intro extra
      have mem := (mem_extraCells .alpha (x-(1 : Int)) (y-(0 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem

theorem affine_beta_nonnegative002 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known002 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known002, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty002 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known002 a) (1 : Int) (0 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n002_empty a ((by simpa only [KnownContains, affine_beta_known002, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window002 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known002 a)) B) : QueryWindow h (1 : Int) (0 : Int) := by
  have top0 := known_top_below state (affine_beta_nonnegative002 a ha) (t := (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known002])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n002_height a h (top0) ((by omega))

theorem affine_beta_complete002 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (0 : Int))
    (separated : ∀ u, u ∈ affine_beta_known002 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches002 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known002])
  have apart6 := separated (Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known002])
  have apart7 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known002])
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known002])
  have apart12 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known002])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n002_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart6).1 (apart7).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known003 a)), by simp [affine_beta_branches002], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n002_o1 a jx jy (apart6).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart7).2.2.1 (ha) (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n002_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart6).1 (ha) (apart1).1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known004 a)), by simp [affine_beta_branches002], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n002_o3 a jx jy (apart8).2.2.1 (ha) (apart7).2.2.1 (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n002_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart7).1 (apart6).1 (ha) (apart12).2.1 (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n002_o5 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart7).2.2.1 (apart6).1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known022 a)), by simp [affine_beta_branches002], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n002_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart7).2.2.1 (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n002_o7 a jx jy (apart6).1 (ha) (apart8).2.2.1 (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative003 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known003 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known003, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty003 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known003 a) (1 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n003_empty a ((by simpa only [KnownContains, affine_beta_known003, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window003 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known003 a)) B) : QueryWindow h (1 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_beta_nonnegative003 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known003])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n003_height a h (top1) ((by omega))

theorem affine_beta_complete003 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_beta_known003 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches003 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known003])
  have apart6 := separated (Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known003])
  have apart7 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known003])
  have apart12 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known003])
  have apart13 := separated (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known003])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n003_o0 a jx jy (apart1).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.2.1 (apart13).2.2.1 (apart13).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n003_o1 a jx jy (apart13).2.1 (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n003_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart6).2.2.1 (apart12).2.2.1 (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n003_o3 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1 (apart12).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n003_o4 a jx jy (ha) (apart6).1 (apart12).2.1 (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n003_o5 a jx jy (apart12).2.2.1 (apart13).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n003_o6 a jx jy (apart13).2.1 (ha) (apart12).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart7).2.2.1 (apart6).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n003_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1 (apart12).2.1 (ha))

theorem affine_beta_nonnegative004 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known004 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known004, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty004 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known004 a) (1 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n004_empty a ((by simpa only [KnownContains, affine_beta_known004, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window004 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known004 a)) B) : QueryWindow h (1 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_beta_nonnegative004 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known004])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n004_height a h ((by omega)) (top1)

theorem affine_beta_complete004 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_beta_known004 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches004 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known004])
  have apart7 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known004])
  have apart12 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known004])
  have apart13 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known004])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n004_o0 a jx jy (apart1).1 (ha) (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known005 a)), by simp [affine_beta_branches004], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n004_o1 a jx jy (apart12).2.2.1 (apart7).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n004_o2 a jx jy (apart12).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.2.1 (apart13).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n004_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.2.1 (apart12).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n004_o4 a jx jy (apart12).2.1 (apart13).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n004_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1 (apart13).2.2.1 (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known006 a)), by simp [affine_beta_branches004], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n004_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1 (apart12).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n004_o7 a jx jy (apart1).1 (apart13).2.2.1 (ha) (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative005 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known005 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known005, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_cover0_005 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known005 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n005_wall0 a ((by simpa only [KnownContains, affine_beta_known005, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover1_005 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known005 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n005_wall1 a ((by simpa only [KnownContains, affine_beta_known005, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover2_005 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known005 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n005_wall2 a ((by simpa only [KnownContains, affine_beta_known005, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover3_005 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known005 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n005_wall3 a ((by simpa only [KnownContains, affine_beta_known005, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover4_005 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known005 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(4 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n005_wall4 a ((by simpa only [KnownContains, affine_beta_known005, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover5_005 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known005 a) ((1 : Int)+(0 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n005_wall5 a ((by simpa only [KnownContains, affine_beta_known005, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover6_005 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known005 a) ((1 : Int)+(1 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n005_wall6 a ((by simpa only [KnownContains, affine_beta_known005, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover7_005 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known005 a) ((1 : Int)+(2 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n005_wall7 a ((by simpa only [KnownContains, affine_beta_known005, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover8_005 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known005 a) ((1 : Int)+(3 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n005_wall8 a ((by simpa only [KnownContains, affine_beta_known005, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover9_005 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known005 a) ((1 : Int)+(4 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n005_wall9 a ((by simpa only [KnownContains, affine_beta_known005, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover10_005 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known005 a) ((1 : Int)+(5 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n005_wall10 a ((by simpa only [KnownContains, affine_beta_known005, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover11_005 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known005 a) ((1 : Int)+(0 : Int)) ((2 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n005_wall11 a ((by simpa only [KnownContains, affine_beta_known005, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover12_005 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known005 a) ((1 : Int)+(1 : Int)) ((2 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n005_wall12 a ((by simpa only [KnownContains, affine_beta_known005, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_leaf005 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known005 a)) B) : Transition world h .beta B := by
  apply replay_affine_leaf world h .beta (affine_beta_known005 a) .gamma (1 : Int) (2 : Int) (affine_beta_nonnegative005 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .gamma x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7 | m8 | m9 | m10
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover0_005 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover1_005 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover2_005 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover3_005 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(4 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover4_005 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(0 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover5_005 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover6_005 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(2 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover7_005 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(3 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover8_005 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(4 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover9_005 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(5 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover10_005 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.beta_n005_dirty a x y (hx) ((by simpa only [Extra,or_and_right,and_or_left,or_assoc,and_assoc] using notExtra)) ((by simpa only [KnownContains, affine_beta_known005, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (hy)
    · intro extra
      have mem := (mem_extraCells .gamma (x-(1 : Int)) (y-(2 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem
      rcases mem with e0 | e1
      · have ex : x=((1 : Int)+(0 : Int)) := by omega
        have ey : y=((2 : Int)+(0 : Int)) := by omega
        rw [ex,ey]
        exact affine_beta_cover11_005 a ha
      · have ex : x=((1 : Int)+(1 : Int)) := by omega
        have ey : y=((2 : Int)+(0 : Int)) := by omega
        rw [ex,ey]
        exact affine_beta_cover12_005 a ha

theorem affine_beta_nonnegative006 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known006 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known006, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty006 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known006 a) (1 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n006_empty a ((by simpa only [KnownContains, affine_beta_known006, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window006 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known006 a)) B) : QueryWindow h (1 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative006 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known006])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n006_height a h ((by omega)) (top3)

theorem affine_beta_complete006 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known006 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches006 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart12 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known006])
  have apart14 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known006])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n006_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known020 a)), by simp [affine_beta_branches006], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (1 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n006_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1 (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known011 a)), by simp [affine_beta_branches006], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n006_o2 a jx jy (ha) (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a (1 : Int) (1 : Int)) (Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n006_o3 a jx jy (apart12).2.1 (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)) (knownCells (affine_beta_known012 a)), by simp [affine_beta_branches006], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (1 : Int) (1 : Int) a) (Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n006_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) (apart12).2.1 (apart14).2.2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_beta_known007 a)), by simp [affine_beta_branches006], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n006_o5 a jx jy (ha) (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known021 a)), by simp [affine_beta_branches006], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (1 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n006_o6 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known010 a)), by simp [affine_beta_branches006], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (1 : Int) (1 : Int)) (Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n006_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)) (knownCells (affine_beta_known019 a)), by simp [affine_beta_branches006], (same_eq m0).symm⟩

theorem affine_beta_nonnegative007 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known007 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known007, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty007 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known007 a) (2 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n007_empty a (ha) ((by simpa only [KnownContains, affine_beta_known007, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window007 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known007 a)) B) : QueryWindow h (2 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative007 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known007])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n007_height a h ((by omega)) (top2)

theorem affine_beta_complete007 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known007 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches007 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known007])
  have apart9 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known007])
  have apart12 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known007])
  have apart14 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known007])
  have apart15 := separated (Cross.mk (1 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_beta_known007])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n007_o0 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).1 (apart14).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n007_o1 a jx jy (apart14).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known009 a)), by simp [affine_beta_branches007], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n007_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.1 (apart12).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n007_o3 a jx jy (apart14).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n007_o4 a jx jy (apart15).2.1 (apart9).2.2.1 (apart8).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n007_o5 a jx jy (ha) (apart14).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (2 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n007_o6 a jx jy (apart14).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known008 a)), by simp [affine_beta_branches007], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n007_o7 a jx jy (apart12).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (apart14).2.1)

theorem affine_beta_nonnegative008 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known008 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known008, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty008 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known008 a) (3 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n008_empty a ((by simpa only [KnownContains, affine_beta_known008, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window008 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known008 a)) B) : QueryWindow h (3 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative008 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known008])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n008_height a h ((by omega)) (top2)

theorem affine_beta_complete008 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known008 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches008 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart9 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known008])
  have apart12 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known008])
  have apart13 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known008])
  have apart14 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known008])
  have apart16 := separated (Cross.mk (2 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known008])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n008_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).1 (apart14).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n008_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.2.1 (apart16).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n008_o2 a jx jy (ha) (apart14).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.1 (apart16).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n008_o3 a jx jy (apart16).2.2.1 (apart14).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n008_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.2.1 (apart16).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n008_o5 a jx jy (apart12).1 (ha) (apart14).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n008_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.2.1 (apart16).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n008_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).1 (ha) (apart16).2.2.1 (apart14).2.1)

theorem affine_beta_nonnegative009 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known009 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known009, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty009 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known009 a) (3 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n009_empty a ((by simpa only [KnownContains, affine_beta_known009, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window009 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known009 a)) B) : QueryWindow h (3 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative009 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known009])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n009_height a h ((by omega)) (top2)

theorem affine_beta_complete009 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known009 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches009 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart12 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known009])
  have apart14 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known009])
  have apart16 := separated (Cross.mk (2 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known009])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n009_o0 a jx jy (apart16).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n009_o1 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).1 (apart14).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n009_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.1 (apart14).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n009_o3 a jx jy (apart16).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n009_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.1 (ha) (apart14).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n009_o5 a jx jy (apart14).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n009_o6 a jx jy (ha) (apart16).2.2.1 (apart14).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n009_o7 a jx jy (apart16).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1 (ha))

theorem affine_beta_nonnegative010 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known010 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known010, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty010 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known010 a) (2 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n010_empty a (ha) ((by simpa only [KnownContains, affine_beta_known010, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window010 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known010 a)) B) : QueryWindow h (2 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative010 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known010])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n010_height a h ((by omega)) (top2)

theorem affine_beta_complete010 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known010 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches010 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known010])
  have apart9 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known010])
  have apart12 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known010])
  have apart14 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known010])
  have apart15 := separated (Cross.mk (1 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known010])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n010_o0 a jx jy (apart12).2.1 (apart14).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n010_o1 a jx jy (apart15).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (apart15).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n010_o2 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.1 (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n010_o3 a jx jy (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n010_o4 a jx jy (apart15).2.1 (apart8).2.2.1 (apart9).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n010_o5 a jx jy (ha) (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n010_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (ha) (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n010_o7 a jx jy (ha) (apart14).2.1 (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).1)

theorem affine_beta_nonnegative011 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known011 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known011, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty011 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known011 a) (2 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n011_empty a (ha) ((by simpa only [KnownContains, affine_beta_known011, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window011 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known011 a)) B) : QueryWindow h (2 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative011 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known011])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n011_height a h (top2) ((by omega))

theorem affine_beta_complete011 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known011 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches011 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known011])
  have apart9 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known011])
  have apart12 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known011])
  have apart14 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known011])
  have apart15 := separated (Cross.mk (1 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known011])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n011_o0 a jx jy (apart14).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n011_o1 a jx jy (apart14).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n011_o2 a jx jy (apart14).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n011_o3 a jx jy (ha) (apart14).2.2.1 (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n011_o4 a jx jy (apart8).2.2.1 (apart15).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n011_o5 a jx jy (apart14).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n011_o6 a jx jy (apart14).2.2.1 (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n011_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).1 (ha) (apart14).2.1 (apart15).2.1)

theorem affine_beta_nonnegative012 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known012 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known012, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty012 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known012 a) (1 : Int) (4 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n012_empty a ((by simpa only [KnownContains, affine_beta_known012, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window012 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known012 a)) B) : QueryWindow h (1 : Int) (4 : Int) := by
  have top4 := known_top_below state (affine_beta_nonnegative012 a ha) (t := (Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known012])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n012_height a h (top4) ((by omega))

theorem affine_beta_complete012 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (4 : Int))
    (separated : ∀ u, u ∈ affine_beta_known012 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches012 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart4 := separated (Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known012])
  have apart12 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known012])
  have apart15 := separated (Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)) (by simp [affine_beta_known012])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n012_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart4).1 (ha) (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (1 : Int) ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n012_o1 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (apart12).2.2.2 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known016 a)), by simp [affine_beta_branches012], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n012_o2 a jx jy (apart12).2.1 (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n012_o3 a jx jy (apart12).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (1 : Int) (1 : Int) a) (Cross.mk (1 : Int) ((4 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n012_o4 a jx jy (ha) (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) ((4 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_beta_known013 a)), by simp [affine_beta_branches012], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n012_o5 a jx jy (apart15).2.1 (ha) (apart4).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n012_o6 a jx jy (apart12).2.2.2 (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n012_o7 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (apart12).2.1)

theorem affine_beta_nonnegative013 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known013 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known013, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty013 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known013 a) (3 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n013_empty a ((by simpa only [KnownContains, affine_beta_known013, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window013 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known013 a)) B) : QueryWindow h (3 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative013 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known013])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n013_height a h (top2) ((by omega))

theorem affine_beta_complete013 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known013 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches013 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart9 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known013])
  have apart10 := separated (Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known013])
  have apart12 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known013])
  have apart14 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known013])
  have apart15 := separated (Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)) (by simp [affine_beta_known013])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n013_o0 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1 (apart12).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n013_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart14).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known015 a)), by simp [affine_beta_branches013], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n013_o2 a jx jy (apart14).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n013_o3 a jx jy (apart15).1 (apart14).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n013_o4 a jx jy (ha) (apart10).2.2.1 (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n013_o5 a jx jy (ha) (apart14).2.1 (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (3 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n013_o6 a jx jy (ha) (apart14).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known014 a)), by simp [affine_beta_branches013], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n013_o7 a jx jy (ha) (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1)

theorem affine_beta_nonnegative014 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known014 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known014, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty014 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known014 a) (4 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n014_empty a ((by simpa only [KnownContains, affine_beta_known014, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window014 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known014 a)) B) : QueryWindow h (4 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative014 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known014])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n014_height a h ((by omega)) (top2)

theorem affine_beta_complete014 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (4 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known014 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches014 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart10 := separated (Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known014])
  have apart12 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known014])
  have apart13 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known014])
  have apart14 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known014])
  have apart17 := separated (Cross.mk (3 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known014])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n014_o0 a jx jy (apart12).1 (apart14).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n014_o1 a jx jy (apart10).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart17).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n014_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart14).2.2.1 (apart14).2.1 (apart17).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n014_o3 a jx jy (apart17).2.2.1 (apart14).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n014_o4 a jx jy (apart13).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart17).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n014_o5 a jx jy (apart17).2.1 (ha) (apart14).1 (apart14).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n014_o6 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart17).2.2.1 (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n014_o7 a jx jy (apart17).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).1 (apart14).2.1)

theorem affine_beta_nonnegative015 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known015 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known015, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty015 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known015 a) (4 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n015_empty a ((by simpa only [KnownContains, affine_beta_known015, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window015 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known015 a)) B) : QueryWindow h (4 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative015 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known015])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n015_height a h (top2) ((by omega))

theorem affine_beta_complete015 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (4 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known015 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches015 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart12 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known015])
  have apart14 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known015])
  have apart17 := separated (Cross.mk (3 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known015])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n015_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1 (ha) (apart12).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n015_o1 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.1 (apart17).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n015_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1 (apart17).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n015_o3 a jx jy (apart14).2.2.1 (ha) (apart17).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n015_o4 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.1 (apart17).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n015_o5 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1 (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n015_o6 a jx jy (apart17).2.2.1 (apart14).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n015_o7 a jx jy (apart17).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart14).2.1)

theorem affine_beta_nonnegative016 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known016 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known016, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty016 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known016 a) (3 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n016_empty a (ha) ((by simpa only [KnownContains, affine_beta_known016, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window016 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known016 a)) B) : QueryWindow h (3 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative016 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known016])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n016_height a h ((by omega)) (top2)

theorem affine_beta_complete016 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known016 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches016 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart12 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known016])
  have apart13 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known016])
  have apart14 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known016])
  have apart15 := separated (Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)) (by simp [affine_beta_known016])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n016_o0 a jx jy (apart14).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n016_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.1 (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known018 a)), by simp [affine_beta_branches016], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n016_o2 a jx jy (ha) (apart14).2.1 (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n016_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.1 (ha) (apart15).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n016_o4 a jx jy (ha) (apart15).2.1 (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n016_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1 (ha) (apart14).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (3 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n016_o6 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known017 a)), by simp [affine_beta_branches016], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n016_o7 a jx jy (ha) (apart14).2.1 (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative017 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known017 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known017, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty017 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known017 a) (4 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n017_empty a ((by simpa only [KnownContains, affine_beta_known017, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window017 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known017 a)) B) : QueryWindow h (4 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative017 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known017])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n017_height a h (top2) ((by omega))

theorem affine_beta_complete017 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (4 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known017 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches017 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart10 := separated (Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known017])
  have apart12 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known017])
  have apart13 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known017])
  have apart14 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known017])
  have apart17 := separated (Cross.mk (3 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known017])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n017_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1 (ha) (apart12).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n017_o1 a jx jy (apart17).2.2.1 (ha) (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n017_o2 a jx jy (ha) (apart14).2.2.1 (apart17).2.2.1 (apart14).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n017_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart17).2.2.1 (ha) (apart14).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n017_o4 a jx jy (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart17).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n017_o5 a jx jy (apart14).2.2.1 (apart14).2.1 (ha) (apart12).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n017_o6 a jx jy (ha) (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart17).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n017_o7 a jx jy (apart14).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).1 (ha) (apart17).2.2.1)

theorem affine_beta_nonnegative018 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known018 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known018, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty018 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known018 a) (4 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n018_empty a (ha) ((by simpa only [KnownContains, affine_beta_known018, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window018 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known018 a)) B) : QueryWindow h (4 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative018 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known018])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n018_height a h (top2) ((by omega))

theorem affine_beta_complete018 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (4 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known018 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches018 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart12 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known018])
  have apart14 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known018])
  have apart15 := separated (Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)) (by simp [affine_beta_known018])
  have apart17 := separated (Cross.mk (3 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known018])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n018_o0 a jx jy (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n018_o1 a jx jy (apart14).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart17).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n018_o2 a jx jy (ha) (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n018_o3 a jx jy (apart14).2.2.1 (apart17).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n018_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.1 (ha) (apart17).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n018_o5 a jx jy (apart14).2.1 (apart12).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n018_o6 a jx jy (apart17).2.2.1 (apart14).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n018_o7 a jx jy (ha) (apart17).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1)

theorem affine_beta_nonnegative019 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known019 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known019, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_cover0_019 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known019 a) ((1 : Int)+(-1 : Int)) ((4 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n019_wall0 a ((by simpa only [KnownContains, affine_beta_known019, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover1_019 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known019 a) ((1 : Int)+(-1 : Int)) ((4 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n019_wall1 a ((by simpa only [KnownContains, affine_beta_known019, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover2_019 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known019 a) ((1 : Int)+(-1 : Int)) ((4 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n019_wall2 a ((by simpa only [KnownContains, affine_beta_known019, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover3_019 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known019 a) ((1 : Int)+(-1 : Int)) ((4 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n019_wall3 a ((by simpa only [KnownContains, affine_beta_known019, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover4_019 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known019 a) ((1 : Int)+(0 : Int)) ((4 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n019_wall4 a ((by simpa only [KnownContains, affine_beta_known019, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover5_019 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known019 a) ((1 : Int)+(1 : Int)) ((4 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n019_wall5 a ((by simpa only [KnownContains, affine_beta_known019, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover6_019 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known019 a) ((1 : Int)+(2 : Int)) ((4 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n019_wall6 a ((by simpa only [KnownContains, affine_beta_known019, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover7_019 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known019 a) ((1 : Int)+(3 : Int)) ((4 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n019_wall7 a ((by simpa only [KnownContains, affine_beta_known019, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_leaf019 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known019 a)) B) : Transition world h .beta B := by
  apply replay_affine_leaf world h .beta (affine_beta_known019 a) .alpha (1 : Int) (4 : Int) (affine_beta_nonnegative019 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .alpha x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (4 : Int)+y=((4 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover0_019 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (4 : Int)+y=((4 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover1_019 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (4 : Int)+y=((4 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover2_019 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (4 : Int)+y=((4 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover3_019 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(0 : Int)) := by omega
      have ey : (4 : Int)+y=((4 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover4_019 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(1 : Int)) := by omega
      have ey : (4 : Int)+y=((4 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover5_019 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(2 : Int)) := by omega
      have ey : (4 : Int)+y=((4 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover6_019 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(3 : Int)) := by omega
      have ey : (4 : Int)+y=((4 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover7_019 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.beta_n019_dirty a x y (hy) (hx) ((by simpa only [KnownContains, affine_beta_known019, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))
    · intro extra
      have mem := (mem_extraCells .alpha (x-(1 : Int)) (y-(4 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem

theorem affine_beta_nonnegative020 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known020 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known020, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty020 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known020 a) (2 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n020_empty a ((by simpa only [KnownContains, affine_beta_known020, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window020 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known020 a)) B) : QueryWindow h (2 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative020 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known020])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n020_height a h ((by omega)) (top2)

theorem affine_beta_complete020 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known020 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches020 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known020])
  have apart12 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known020])
  have apart14 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known020])
  have apart15 := separated (Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known020])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n020_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart14).2.1 (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n020_o1 a jx jy (ha) (apart15).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n020_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.1 (apart15).2.2.2 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n020_o3 a jx jy (apart15).2.1 (apart14).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n020_o4 a jx jy (apart14).1 (apart15).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n020_o5 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.1 (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n020_o6 a jx jy (apart15).2.2.2 (ha) (apart12).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n020_o7 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).1 (apart15).2.2.1 (apart14).2.1)

theorem affine_beta_nonnegative021 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known021 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known021, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty021 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known021 a) (2 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n021_empty a (ha) ((by simpa only [KnownContains, affine_beta_known021, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window021 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known021 a)) B) : QueryWindow h (2 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative021 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known021])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n021_height a h (top2) ((by omega))

theorem affine_beta_complete021 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known021 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches021 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known021])
  have apart12 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known021])
  have apart14 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known021])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known021])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n021_o0 a jx jy (ha) (apart14).2.1 (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n021_o1 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n021_o2 a jx jy (apart12).2.1 (ha) (apart14).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n021_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.1 (ha) (apart15).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n021_o4 a jx jy (ha) (apart15).2.2.1 (apart14).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n021_o5 a jx jy (apart15).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n021_o6 a jx jy (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n021_o7 a jx jy (apart12).1 (apart15).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart14).2.1)

theorem affine_beta_nonnegative022 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known022 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known022, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty022 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known022 a) (1 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n022_empty a ((by simpa only [KnownContains, affine_beta_known022, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window022 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known022 a)) B) : QueryWindow h (1 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_beta_nonnegative022 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known022])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n022_height a h ((by omega)) (top1)

theorem affine_beta_complete022 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_beta_known022 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches022 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known022])
  have apart7 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known022])
  have apart12 := separated (Cross.mk (0 : Int) (2 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known022])
  have apart13 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known022])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n022_o0 a jx jy (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n022_o1 a jx jy (apart7).2.2.1 (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n022_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.2.1 (apart12).2.2.1 (apart12).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n022_o3 a jx jy (apart13).2.2.1 (apart12).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n022_o4 a jx jy (apart13).2.2.1 (ha) (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n022_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.1 (apart13).1 (apart1).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n022_o6 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart7).2.2.1 (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n022_o7 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart1).1 (apart13).2.1 (apart12).2.2.1)

theorem affine_beta_nonnegative023 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known023 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known023, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty023 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known023 a) (1 : Int) (0 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n023_empty a (ha) ((by simpa only [KnownContains, affine_beta_known023, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window023 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known023 a)) B) : QueryWindow h (1 : Int) (0 : Int) := by
  have top0 := known_top_below state (affine_beta_nonnegative023 a ha) (t := (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known023])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n023_height a h (top0) ((by omega))

theorem affine_beta_complete023 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (0 : Int))
    (separated : ∀ u, u ∈ affine_beta_known023 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches023 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known023])
  have apart6 := separated (Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known023])
  have apart7 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known023])
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known023])
  have apart12 := separated (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known023])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n023_o0 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart7).2.2.1 (apart6).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known024 a)), by simp [affine_beta_branches023], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n023_o1 a jx jy (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.2 (ha) (apart7).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n023_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) (apart1).1 (apart6).1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known025 a)), by simp [affine_beta_branches023], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n023_o3 a jx jy (apart8).2.2.1 (apart7).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n023_o4 a jx jy (apart6).1 (apart8).2.2.1 (ha) (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart7).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n023_o5 a jx jy (apart7).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart6).1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known028 a)), by simp [affine_beta_branches023], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n023_o6 a jx jy (apart6).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart7).2.2.1 (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n023_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1 (apart8).2.2.1 (ha) (apart6).1)

theorem affine_beta_nonnegative024 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known024 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known024, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty024 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known024 a) (1 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n024_empty a (ha) ((by simpa only [KnownContains, affine_beta_known024, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window024 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known024 a)) B) : QueryWindow h (1 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_beta_nonnegative024 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known024])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n024_height a h ((by omega)) (top1)

theorem affine_beta_complete024 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_beta_known024 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches024 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known024])
  have apart12 := separated (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known024])
  have apart13 := separated (Cross.mk (2 : Int) (0 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known024])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n024_o0 a jx jy (ha) (apart1).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n024_o1 a jx jy (apart12).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1 (ha) (apart13).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n024_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.1 (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n024_o3 a jx jy (apart12).2.1 (apart13).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n024_o4 a jx jy (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).1 (apart12).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n024_o5 a jx jy (apart1).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n024_o6 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1 (apart13).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n024_o7 a jx jy (apart12).2.1 (ha) (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative025 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known025 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known025, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty025 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known025 a) (1 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n025_empty a (ha) ((by simpa only [KnownContains, affine_beta_known025, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window025 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known025 a)) B) : QueryWindow h (1 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_beta_nonnegative025 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known025])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n025_height a h (top1) ((by omega))

theorem affine_beta_complete025 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_beta_known025 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches025 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known025])
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known025])
  have apart7 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known025])
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known025])
  have apart12 := separated (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known025])
  have apart13 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known025])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (2 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n025_o0 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1 (apart12).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known026 a)), by simp [affine_beta_branches025], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n025_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1 (apart12).2.1 (apart7).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n025_o2 a jx jy (apart2).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.2.1 (apart1).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n025_o3 a jx jy (ha) (apart12).2.1 (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n025_o4 a jx jy (apart7).2.2.1 (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n025_o5 a jx jy (apart12).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart13).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known027 a)), by simp [affine_beta_branches025], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n025_o6 a jx jy (ha) (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart7).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n025_o7 a jx jy (apart13).2.2.1 (ha) (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative026 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known026 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known026, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty026 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known026 a) (1 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n026_empty a ((by simpa only [KnownContains, affine_beta_known026, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window026 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known026 a)) B) : QueryWindow h (1 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative026 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known026])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n026_height a h ((by omega)) (top2)

theorem affine_beta_complete026 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known026 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches026 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known026])
  have apart7 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known026])
  have apart12 := separated (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known026])
  have apart14 := separated (Cross.mk (2 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known026])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n026_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart2).1 (apart14).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n026_o1 a jx jy (apart7).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1 (ha) (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n026_o2 a jx jy (ha) (apart14).2.1 (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n026_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.1 (ha) (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n026_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.1 (apart14).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n026_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart2).1 (ha) (apart14).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n026_o6 a jx jy (apart14).2.2.1 (apart12).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n026_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.2 (apart12).2.1 (ha))

theorem affine_beta_nonnegative027 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known027 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known027, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty027 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known027 a) (1 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n027_empty a ((by simpa only [KnownContains, affine_beta_known027, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window027 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known027 a)) B) : QueryWindow h (1 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative027 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known027])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n027_height a h ((by omega)) (top2)

theorem affine_beta_complete027 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known027 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches027 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known027])
  have apart7 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known027])
  have apart12 := separated (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known027])
  have apart13 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known027])
  have apart14 := separated (Cross.mk ((1 : Int) + a) (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known027])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n027_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart14).2.1 (apart2).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n027_o1 a jx jy (apart12).2.2.1 (apart12).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n027_o2 a jx jy (apart14).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n027_o3 a jx jy (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart14).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n027_o4 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1 (apart14).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n027_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).1 (ha) (apart14).2.1 (apart2).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n027_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.2.1 (apart7).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n027_o7 a jx jy (ha) (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1)

theorem affine_beta_nonnegative028 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known028 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known028, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty028 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known028 a) (1 : Int) (1 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n028_empty a ((by simpa only [KnownContains, affine_beta_known028, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window028 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known028 a)) B) : QueryWindow h (1 : Int) (1 : Int) := by
  have top1 := known_top_below state (affine_beta_nonnegative028 a ha) (t := (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known028])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n028_height a h ((by omega)) (top1)

theorem affine_beta_complete028 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (1 : Int))
    (separated : ∀ u, u ∈ affine_beta_known028 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches028 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known028])
  have apart6 := separated (Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known028])
  have apart7 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known028])
  have apart12 := separated (Cross.mk (0 : Int) ((1 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known028])
  have apart13 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known028])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n028_o0 a jx jy (apart13).2.1 (apart1).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n028_o1 a jx jy (apart6).2.2.1 (apart12).2.2.1 (ha) (apart7).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n028_o2 a jx jy (apart12).2.1 (apart13).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n028_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.2.1 (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n028_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1 (ha) (apart12).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n028_o5 a jx jy (apart13).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.2 (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n028_o6 a jx jy (apart7).2.2.1 (apart12).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n028_o7 a jx jy (ha) (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1)

theorem affine_beta_nonnegative029 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known029 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known029, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_cover0_029 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known029 a) ((2 : Int)+(-1 : Int)) ((0 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n029_wall0 a (ha) ((by simpa only [KnownContains, affine_beta_known029, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover1_029 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known029 a) ((2 : Int)+(-1 : Int)) ((0 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n029_wall1 a ((by simpa only [KnownContains, affine_beta_known029, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover2_029 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known029 a) ((2 : Int)+(-1 : Int)) ((0 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n029_wall2 a ((by simpa only [KnownContains, affine_beta_known029, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover3_029 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known029 a) ((2 : Int)+(-1 : Int)) ((0 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n029_wall3 a ((by simpa only [KnownContains, affine_beta_known029, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover4_029 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known029 a) ((2 : Int)+(0 : Int)) ((0 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n029_wall4 a ((by simpa only [KnownContains, affine_beta_known029, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover5_029 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known029 a) ((2 : Int)+(1 : Int)) ((0 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n029_wall5 a ((by simpa only [KnownContains, affine_beta_known029, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover6_029 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known029 a) ((2 : Int)+(2 : Int)) ((0 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n029_wall6 a ((by simpa only [KnownContains, affine_beta_known029, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover7_029 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known029 a) ((2 : Int)+(3 : Int)) ((0 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n029_wall7 a ((by simpa only [KnownContains, affine_beta_known029, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_leaf029 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known029 a)) B) : Transition world h .beta B := by
  apply replay_affine_leaf world h .beta (affine_beta_known029 a) .alpha (2 : Int) (0 : Int) (affine_beta_nonnegative029 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .alpha x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7
    · have ex : (2 : Int)+x=((2 : Int)+(-1 : Int)) := by omega
      have ey : (0 : Int)+y=((0 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover0_029 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(-1 : Int)) := by omega
      have ey : (0 : Int)+y=((0 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover1_029 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(-1 : Int)) := by omega
      have ey : (0 : Int)+y=((0 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover2_029 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(-1 : Int)) := by omega
      have ey : (0 : Int)+y=((0 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover3_029 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(0 : Int)) := by omega
      have ey : (0 : Int)+y=((0 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover4_029 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(1 : Int)) := by omega
      have ey : (0 : Int)+y=((0 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover5_029 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(2 : Int)) := by omega
      have ey : (0 : Int)+y=((0 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover6_029 a ha
    · have ex : (2 : Int)+x=((2 : Int)+(3 : Int)) := by omega
      have ey : (0 : Int)+y=((0 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover7_029 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.beta_n029_dirty a x y (hy) (hx) ((by simpa only [KnownContains, affine_beta_known029, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))
    · intro extra
      have mem := (mem_extraCells .alpha (x-(2 : Int)) (y-(0 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem

theorem affine_beta_nonnegative030 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known030 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known030, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty030 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known030 a) (0 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n030_empty a ((by simpa only [KnownContains, affine_beta_known030, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window030 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known030 a)) B) : QueryWindow h (0 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative030 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known030])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n030_height a h (top2) ((by omega))

theorem affine_beta_complete030 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (0 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known030 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches030 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known030])
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known030])
  have apart3 := separated (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known030])
  have apart6 := separated (Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known030])
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known030])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n030_o0 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart2).1 (apart12).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known076 a)), by simp [affine_beta_branches030], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n030_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1 (apart2).1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known069 a)), by simp [affine_beta_branches030], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n030_o2 a jx jy (ha) (apart3).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1 (apart1).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n030_o3 a jx jy (apart12).2.2.2 (apart6).2.2.1 (apart3).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart2).1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (1 : Int) (1 : Int) a) (Cross.mk (0 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n030_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_beta_known031 a)), by simp [affine_beta_branches030], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk a (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n030_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart2).1 (apart1).1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk a (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known111 a)), by simp [affine_beta_branches030], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n030_o6 a jx jy (apart2).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart12).2.2.1 (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known032 a)), by simp [affine_beta_branches030], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n030_o7 a jx jy (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart3).1 (ha) (apart2).1)

theorem affine_beta_nonnegative031 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known031 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known031, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_cover0_031 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known031 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n031_wall0 a (ha) ((by simpa only [KnownContains, affine_beta_known031, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover1_031 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known031 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n031_wall1 a ((by simpa only [KnownContains, affine_beta_known031, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover2_031 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known031 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n031_wall2 a (ha) ((by simpa only [KnownContains, affine_beta_known031, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover3_031 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known031 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n031_wall3 a (ha) ((by simpa only [KnownContains, affine_beta_known031, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover4_031 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known031 a) ((1 : Int)+(0 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n031_wall4 a ((by simpa only [KnownContains, affine_beta_known031, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover5_031 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known031 a) ((1 : Int)+(1 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n031_wall5 a (ha) ((by simpa only [KnownContains, affine_beta_known031, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover6_031 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known031 a) ((1 : Int)+(2 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n031_wall6 a ((by simpa only [KnownContains, affine_beta_known031, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover7_031 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known031 a) ((1 : Int)+(3 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n031_wall7 a ((by simpa only [KnownContains, affine_beta_known031, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_leaf031 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known031 a)) B) : Transition world h .beta B := by
  apply replay_affine_leaf world h .beta (affine_beta_known031 a) .alpha (1 : Int) (2 : Int) (affine_beta_nonnegative031 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .alpha x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover0_031 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover1_031 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover2_031 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover3_031 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(0 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover4_031 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover5_031 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(2 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover6_031 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(3 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover7_031 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.beta_n031_dirty a x y (hy) ((by simpa only [KnownContains, affine_beta_known031, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (hx)
    · intro extra
      have mem := (mem_extraCells .alpha (x-(1 : Int)) (y-(2 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem

theorem affine_beta_nonnegative032 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known032 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known032, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty032 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known032 a) (2 : Int) (0 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n032_empty a ((by simpa only [KnownContains, affine_beta_known032, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window032 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known032 a)) B) : QueryWindow h (2 : Int) (0 : Int) := by
  have top0 := known_top_below state (affine_beta_nonnegative032 a ha) (t := (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known032])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n032_height a h ((by omega)) (top0)

theorem affine_beta_complete032 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (0 : Int))
    (separated : ∀ u, u ∈ affine_beta_known032 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches032 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart7 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known032])
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known032])
  have apart9 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known032])
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known032])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n032_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (ha) (apart12).2.1 (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n032_o1 a jx jy (ha) (apart8).2.2.1 (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n032_o2 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known033 a)), by simp [affine_beta_branches032], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n032_o3 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (apart12).2.1 (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n032_o4 a jx jy (apart7).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n032_o5 a jx jy (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart8).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known051 a)), by simp [affine_beta_branches032], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n032_o6 a jx jy (apart8).2.2.1 (apart12).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n032_o7 a jx jy (ha) (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1)

theorem affine_beta_nonnegative033 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known033 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known033, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty033 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known033 a) (1 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n033_empty a ((by simpa only [KnownContains, affine_beta_known033, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window033 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known033 a)) B) : QueryWindow h (1 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative033 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known033])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n033_height a h (top2) ((by omega))

theorem affine_beta_complete033 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known033 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches033 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known033])
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known033])
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known033])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n033_o0 a jx jy (apart13).2.1 (apart12).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known034 a)), by simp [affine_beta_branches033], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n033_o1 a jx jy (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n033_o2 a jx jy (apart12).2.2.2 (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n033_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.2.1 (apart13).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n033_o4 a jx jy (apart13).2.1 (ha) (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n033_o5 a jx jy (apart13).2.1 (apart12).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known035 a)), by simp [affine_beta_branches033], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n033_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.2.1 (apart12).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n033_o7 a jx jy (apart13).2.2.1 (apart12).2.2.1 (apart2).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))

theorem affine_beta_nonnegative034 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known034 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known034, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_cover0_034 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known034 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n034_wall0 a ((by simpa only [KnownContains, affine_beta_known034, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover1_034 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known034 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n034_wall1 a ((by simpa only [KnownContains, affine_beta_known034, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover2_034 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known034 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n034_wall2 a ((by simpa only [KnownContains, affine_beta_known034, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover3_034 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known034 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n034_wall3 a ((by simpa only [KnownContains, affine_beta_known034, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover4_034 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known034 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(4 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n034_wall4 a ((by simpa only [KnownContains, affine_beta_known034, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover5_034 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known034 a) ((1 : Int)+(0 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n034_wall5 a ((by simpa only [KnownContains, affine_beta_known034, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover6_034 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known034 a) ((1 : Int)+(1 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n034_wall6 a ((by simpa only [KnownContains, affine_beta_known034, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover7_034 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known034 a) ((1 : Int)+(2 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n034_wall7 a ((by simpa only [KnownContains, affine_beta_known034, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover8_034 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known034 a) ((1 : Int)+(3 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n034_wall8 a ((by simpa only [KnownContains, affine_beta_known034, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover9_034 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known034 a) ((1 : Int)+(4 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n034_wall9 a ((by simpa only [KnownContains, affine_beta_known034, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover10_034 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known034 a) ((1 : Int)+(5 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n034_wall10 a ((by simpa only [KnownContains, affine_beta_known034, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover11_034 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known034 a) ((1 : Int)+(0 : Int)) ((3 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n034_wall11 a ((by simpa only [KnownContains, affine_beta_known034, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover12_034 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known034 a) ((1 : Int)+(1 : Int)) ((3 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n034_wall12 a ((by simpa only [KnownContains, affine_beta_known034, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_leaf034 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known034 a)) B) : Transition world h .beta B := by
  apply replay_affine_leaf world h .beta (affine_beta_known034 a) .gamma (1 : Int) (3 : Int) (affine_beta_nonnegative034 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .gamma x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7 | m8 | m9 | m10
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover0_034 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover1_034 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover2_034 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover3_034 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(4 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover4_034 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(0 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover5_034 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover6_034 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(2 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover7_034 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(3 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover8_034 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(4 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover9_034 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(5 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover10_034 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.beta_n034_dirty a x y (hx) ((by simpa only [Extra,or_and_right,and_or_left,or_assoc,and_assoc] using notExtra)) (hy) ((by simpa only [KnownContains, affine_beta_known034, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))
    · intro extra
      have mem := (mem_extraCells .gamma (x-(1 : Int)) (y-(3 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem
      rcases mem with e0 | e1
      · have ex : x=((1 : Int)+(0 : Int)) := by omega
        have ey : y=((3 : Int)+(0 : Int)) := by omega
        rw [ex,ey]
        exact affine_beta_cover11_034 a ha
      · have ex : x=((1 : Int)+(1 : Int)) := by omega
        have ey : y=((3 : Int)+(0 : Int)) := by omega
        rw [ex,ey]
        exact affine_beta_cover12_034 a ha

theorem affine_beta_nonnegative035 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known035 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known035, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty035 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known035 a) (1 : Int) (4 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n035_empty a ((by simpa only [KnownContains, affine_beta_known035, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window035 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known035 a)) B) : QueryWindow h (1 : Int) (4 : Int) := by
  have top4 := known_top_below state (affine_beta_nonnegative035 a ha) (t := (Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known035])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n035_height a h ((by omega)) (top4)

theorem affine_beta_complete035 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (4 : Int))
    (separated : ∀ u, u ∈ affine_beta_known035 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches035 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known035])
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known035])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known035])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n035_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known049 a)), by simp [affine_beta_branches035], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (1 : Int) ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n035_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) (apart13).2.2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known040 a)), by simp [affine_beta_branches035], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n035_o2 a jx jy (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a (1 : Int) (1 : Int)) (Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n035_o3 a jx jy (apart13).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)) (knownCells (affine_beta_known041 a)), by simp [affine_beta_branches035], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (1 : Int) (1 : Int) a) (Cross.mk (1 : Int) ((4 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n035_o4 a jx jy (apart13).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) ((4 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_beta_known036 a)), by simp [affine_beta_branches035], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n035_o5 a jx jy (apart13).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known050 a)), by simp [affine_beta_branches035], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (1 : Int) (5 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n035_o6 a jx jy (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) (5 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known039 a)), by simp [affine_beta_branches035], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (1 : Int) (1 : Int)) (Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n035_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)) (knownCells (affine_beta_known048 a)), by simp [affine_beta_branches035], (same_eq m0).symm⟩

theorem affine_beta_nonnegative036 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known036 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known036, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty036 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known036 a) (2 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n036_empty a (ha) ((by simpa only [KnownContains, affine_beta_known036, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window036 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known036 a)) B) : QueryWindow h (2 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative036 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known036])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n036_height a h (top3) ((by omega))

theorem affine_beta_complete036 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known036 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches036 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known036])
  have apart9 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known036])
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known036])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known036])
  have apart16 := separated (Cross.mk (1 : Int) ((4 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_beta_known036])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n036_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1 (ha) (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n036_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known038 a)), by simp [affine_beta_branches036], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n036_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (apart13).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n036_o3 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.1 (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n036_o4 a jx jy (apart9).2.2.1 (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n036_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (ha) (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (2 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n036_o6 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known037 a)), by simp [affine_beta_branches036], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n036_o7 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).1 (apart16).2.1 (apart15).2.1)

theorem affine_beta_nonnegative037 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known037 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known037, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty037 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known037 a) (3 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n037_empty a (ha) ((by simpa only [KnownContains, affine_beta_known037, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window037 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known037 a)) B) : QueryWindow h (3 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative037 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known037])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n037_height a h ((by omega)) (top3)

theorem affine_beta_complete037 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known037 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches037 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart9 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known037])
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known037])
  have apart14 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known037])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known037])
  have apart17 := separated (Cross.mk (2 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known037])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n037_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.1 (apart17).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n037_o1 a jx jy (apart9).2.2.1 (apart17).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n037_o2 a jx jy (ha) (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (apart17).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n037_o3 a jx jy (ha) (apart17).2.2.1 (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n037_o4 a jx jy (apart17).2.1 (apart14).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n037_o5 a jx jy (ha) (apart13).1 (apart15).2.1 (apart15).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n037_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (ha) (apart17).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n037_o7 a jx jy (apart15).2.1 (apart17).2.2.1 (ha) (apart13).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative038 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known038 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known038, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty038 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known038 a) (3 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n038_empty a (ha) ((by simpa only [KnownContains, affine_beta_known038, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window038 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known038 a)) B) : QueryWindow h (3 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative038 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known038])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n038_height a h ((by omega)) (top3)

theorem affine_beta_complete038 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known038 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches038 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known038])
  have apart14 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known038])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known038])
  have apart17 := separated (Cross.mk (2 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known038])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n038_o0 a jx jy (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart17).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n038_o1 a jx jy (apart17).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n038_o2 a jx jy (apart13).2.1 (apart15).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n038_o3 a jx jy (apart17).2.1 (apart15).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n038_o4 a jx jy (apart17).2.1 (apart14).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n038_o5 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n038_o6 a jx jy (apart17).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n038_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (ha) (apart17).2.1)

theorem affine_beta_nonnegative039 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known039 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known039, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty039 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known039 a) (2 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n039_empty a (ha) ((by simpa only [KnownContains, affine_beta_known039, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window039 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known039 a)) B) : QueryWindow h (2 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative039 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known039])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n039_height a h (top3) ((by omega))

theorem affine_beta_complete039 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known039 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches039 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known039])
  have apart9 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known039])
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known039])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known039])
  have apart16 := separated (Cross.mk (1 : Int) (5 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known039])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n039_o0 a jx jy (ha) (apart13).2.1 (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n039_o1 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.2.2 (apart16).2.2.1 (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n039_o2 a jx jy (ha) (apart15).2.2.1 (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n039_o3 a jx jy (apart15).2.2.1 (apart16).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n039_o4 a jx jy (apart16).2.1 (apart9).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n039_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1 (apart15).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n039_o6 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (apart16).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n039_o7 a jx jy (apart13).1 (ha) (apart15).2.1 (apart16).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative040 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known040 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known040, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty040 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known040 a) (2 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n040_empty a (ha) ((by simpa only [KnownContains, affine_beta_known040, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window040 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known040 a)) B) : QueryWindow h (2 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative040 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known040])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n040_height a h ((by omega)) (top3)

theorem affine_beta_complete040 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known040 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches040 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known040])
  have apart9 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known040])
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known040])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known040])
  have apart16 := separated (Cross.mk (1 : Int) ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known040])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n040_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (ha) (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n040_o1 a jx jy (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart16).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n040_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1 (apart15).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n040_o3 a jx jy (ha) (apart16).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n040_o4 a jx jy (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.1 (apart8).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n040_o5 a jx jy (apart15).2.1 (ha) (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n040_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.2.1 (apart15).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n040_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (apart16).2.1 (apart13).2.1 (ha))

theorem affine_beta_nonnegative041 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known041 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known041, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty041 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known041 a) (1 : Int) (5 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n041_empty a ((by simpa only [KnownContains, affine_beta_known041, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window041 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known041 a)) B) : QueryWindow h (1 : Int) (5 : Int) := by
  have top16 := known_top_below state (affine_beta_nonnegative041 a ha) (t := (Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int))) (by simp [affine_beta_known041])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n041_height a h ((by omega)) (ha) (top16)

theorem affine_beta_complete041 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (5 : Int))
    (separated : ∀ u, u ∈ affine_beta_known041 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches041 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known041])
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known041])
  have apart16 := separated (Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)) (by simp [affine_beta_known041])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n041_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1 (ha) (apart16).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (1 : Int) ((5 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n041_o1 a jx jy (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart16).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) ((5 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known045 a)), by simp [affine_beta_branches041], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n041_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart16).2.1 (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n041_o3 a jx jy (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (1 : Int) (1 : Int) a) (Cross.mk (1 : Int) ((5 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n041_o4 a jx jy (ha) (apart16).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) ((5 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_beta_known042 a)), by simp [affine_beta_branches041], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n041_o5 a jx jy (apart16).2.1 (apart13).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n041_o6 a jx jy (ha) (apart13).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.1 (apart13).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n041_o7 a jx jy (apart16).2.2.1 (apart13).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative042 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known042 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known042, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty042 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known042 a) (3 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n042_empty a (ha) ((by simpa only [KnownContains, affine_beta_known042, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window042 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known042 a)) B) : QueryWindow h (3 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative042 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known042])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n042_height a h ((by omega)) (top3)

theorem affine_beta_complete042 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known042 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches042 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known042])
  have apart14 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known042])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known042])
  have apart16 := separated (Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)) (by simp [affine_beta_known042])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n042_o0 a jx jy (apart15).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n042_o1 a jx jy (ha) (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known044 a)), by simp [affine_beta_branches042], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n042_o2 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n042_o3 a jx jy (ha) (apart16).1 (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n042_o4 a jx jy (apart14).2.2.1 (ha) (apart16).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n042_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.1 (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (3 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n042_o6 a jx jy (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known043 a)), by simp [affine_beta_branches042], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n042_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.1 (apart15).2.1 (ha))

theorem affine_beta_nonnegative043 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known043 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known043, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty043 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known043 a) (4 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n043_empty a (ha) ((by simpa only [KnownContains, affine_beta_known043, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window043 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known043 a)) B) : QueryWindow h (4 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative043 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known043])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n043_height a h (top3) ((by omega))

theorem affine_beta_complete043 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (4 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known043 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches043 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart10 := separated (Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known043])
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known043])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known043])
  have apart16 := separated (Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)) (by simp [affine_beta_known043])
  have apart18 := separated (Cross.mk (3 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known043])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n043_o0 a jx jy (ha) (apart16).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n043_o1 a jx jy (ha) (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart18).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n043_o2 a jx jy (apart15).2.2.1 (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart18).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n043_o3 a jx jy (apart18).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n043_o4 a jx jy (apart15).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart18).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n043_o5 a jx jy (apart15).2.1 (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart16).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n043_o6 a jx jy (ha) (apart10).2.2.1 (apart18).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n043_o7 a jx jy (apart13).1 (apart15).2.1 (ha) (apart18).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative044 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known044 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known044, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty044 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known044 a) (4 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n044_empty a (ha) ((by simpa only [KnownContains, affine_beta_known044, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window044 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known044 a)) B) : QueryWindow h (4 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative044 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known044])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n044_height a h ((by omega)) (top3)

theorem affine_beta_complete044 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (4 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known044 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches044 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known044])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known044])
  have apart18 := separated (Cross.mk (3 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known044])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n044_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.1 (apart13).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n044_o1 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (apart18).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n044_o2 a jx jy (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n044_o3 a jx jy (apart18).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n044_o4 a jx jy (apart18).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n044_o5 a jx jy (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n044_o6 a jx jy (apart15).2.2.1 (apart18).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n044_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart18).2.1 (apart15).2.1)

theorem affine_beta_nonnegative045 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known045 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known045, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty045 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known045 a) (3 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n045_empty a (ha) ((by simpa only [KnownContains, affine_beta_known045, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window045 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known045 a)) B) : QueryWindow h (3 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative045 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known045])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n045_height a h (top3) ((by omega))

theorem affine_beta_complete045 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known045 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches045 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known045])
  have apart14 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known045])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known045])
  have apart16 := separated (Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)) (by simp [affine_beta_known045])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n045_o0 a jx jy (ha) (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n045_o1 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known047 a)), by simp [affine_beta_branches045], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n045_o2 a jx jy (ha) (apart13).2.1 (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n045_o3 a jx jy (ha) (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n045_o4 a jx jy (apart14).2.2.1 (apart16).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n045_o5 a jx jy (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (3 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n045_o6 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known046 a)), by simp [affine_beta_branches045], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n045_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart16).2.1 (apart15).2.1)

theorem affine_beta_nonnegative046 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known046 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known046, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty046 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known046 a) (4 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n046_empty a (ha) ((by simpa only [KnownContains, affine_beta_known046, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window046 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known046 a)) B) : QueryWindow h (4 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative046 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known046])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n046_height a h ((by omega)) (top3)

theorem affine_beta_complete046 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (4 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known046 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches046 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart10 := separated (Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known046])
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known046])
  have apart14 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known046])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known046])
  have apart18 := separated (Cross.mk (3 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known046])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n046_o0 a jx jy (apart15).2.1 (apart13).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n046_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart18).2.2.1 (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n046_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart18).2.2.1 (apart15).2.1 (ha) (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n046_o3 a jx jy (apart15).2.2.1 (apart18).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n046_o4 a jx jy (apart14).2.2.1 (apart18).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n046_o5 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).1 (apart15).1 (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n046_o6 a jx jy (ha) (apart18).2.2.1 (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n046_o7 a jx jy (ha) (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).1 (apart18).2.2.1)

theorem affine_beta_nonnegative047 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known047 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known047, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty047 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known047 a) (4 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n047_empty a (ha) ((by simpa only [KnownContains, affine_beta_known047, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window047 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known047 a)) B) : QueryWindow h (4 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative047 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known047])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n047_height a h (top3) ((by omega))

theorem affine_beta_complete047 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (4 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known047 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches047 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known047])
  have apart14 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known047])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known047])
  have apart18 := separated (Cross.mk (3 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known047])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n047_o0 a jx jy (apart15).2.1 (apart13).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n047_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart18).1 (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n047_o2 a jx jy (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n047_o3 a jx jy (apart18).2.1 (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n047_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.1 (ha) (apart18).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n047_o5 a jx jy (apart13).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (apart15).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n047_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart18).2.2.1 (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n047_o7 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart18).2.1 (apart15).2.1)

theorem affine_beta_nonnegative048 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known048 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known048, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_cover0_048 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known048 a) ((1 : Int)+(-1 : Int)) ((5 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n048_wall0 a (ha) ((by simpa only [KnownContains, affine_beta_known048, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover1_048 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known048 a) ((1 : Int)+(-1 : Int)) ((5 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n048_wall1 a ((by simpa only [KnownContains, affine_beta_known048, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover2_048 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known048 a) ((1 : Int)+(-1 : Int)) ((5 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n048_wall2 a ((by simpa only [KnownContains, affine_beta_known048, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover3_048 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known048 a) ((1 : Int)+(-1 : Int)) ((5 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n048_wall3 a ((by simpa only [KnownContains, affine_beta_known048, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover4_048 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known048 a) ((1 : Int)+(0 : Int)) ((5 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n048_wall4 a ((by simpa only [KnownContains, affine_beta_known048, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover5_048 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known048 a) ((1 : Int)+(1 : Int)) ((5 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n048_wall5 a ((by simpa only [KnownContains, affine_beta_known048, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover6_048 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known048 a) ((1 : Int)+(2 : Int)) ((5 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n048_wall6 a ((by simpa only [KnownContains, affine_beta_known048, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover7_048 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known048 a) ((1 : Int)+(3 : Int)) ((5 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n048_wall7 a ((by simpa only [KnownContains, affine_beta_known048, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_leaf048 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known048 a)) B) : Transition world h .beta B := by
  apply replay_affine_leaf world h .beta (affine_beta_known048 a) .alpha (1 : Int) (5 : Int) (affine_beta_nonnegative048 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .alpha x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (5 : Int)+y=((5 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover0_048 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (5 : Int)+y=((5 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover1_048 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (5 : Int)+y=((5 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover2_048 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (5 : Int)+y=((5 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover3_048 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(0 : Int)) := by omega
      have ey : (5 : Int)+y=((5 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover4_048 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(1 : Int)) := by omega
      have ey : (5 : Int)+y=((5 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover5_048 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(2 : Int)) := by omega
      have ey : (5 : Int)+y=((5 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover6_048 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(3 : Int)) := by omega
      have ey : (5 : Int)+y=((5 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover7_048 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.beta_n048_dirty a x y (hy) ((by simpa only [KnownContains, affine_beta_known048, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (hx)
    · intro extra
      have mem := (mem_extraCells .alpha (x-(1 : Int)) (y-(5 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem

theorem affine_beta_nonnegative049 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known049 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known049, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty049 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known049 a) (2 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n049_empty a (ha) ((by simpa only [KnownContains, affine_beta_known049, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window049 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known049 a)) B) : QueryWindow h (2 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative049 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known049])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n049_height a h (top3) ((by omega))

theorem affine_beta_complete049 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known049 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches049 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known049])
  have apart9 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known049])
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known049])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known049])
  have apart16 := separated (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known049])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n049_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (apart13).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n049_o1 a jx jy (apart16).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (apart13).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n049_o2 a jx jy (apart16).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).1 (apart15).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n049_o3 a jx jy (apart15).2.2.1 (ha) (apart16).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n049_o4 a jx jy (apart16).2.2.2 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n049_o5 a jx jy (apart16).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n049_o6 a jx jy (apart8).2.2.1 (apart16).2.2.2 (ha) (apart13).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n049_o7 a jx jy (ha) (apart15).2.1 (apart13).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.2.2)

theorem affine_beta_nonnegative050 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known050 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known050, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty050 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known050 a) (2 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n050_empty a ((by simpa only [KnownContains, affine_beta_known050, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window050 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known050 a)) B) : QueryWindow h (2 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative050 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known050])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n050_height a h ((by omega)) (top3)

theorem affine_beta_complete050 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known050 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches050 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known050])
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known050])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known050])
  have apart16 := separated (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known050])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n050_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (ha) (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n050_o1 a jx jy (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart16).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n050_o2 a jx jy (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n050_o3 a jx jy (apart16).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n050_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (apart16).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n050_o5 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.2.1 (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n050_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.2.1 (ha) (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n050_o7 a jx jy (apart16).1 (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).1 (ha))

theorem affine_beta_nonnegative051 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known051 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known051, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty051 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known051 a) (1 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n051_empty a ((by simpa only [KnownContains, affine_beta_known051, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window051 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known051 a)) B) : QueryWindow h (1 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative051 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known051])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n051_height a h (top2) ((by omega))

theorem affine_beta_complete051 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known051 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches051 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known051])
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known051])
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known051])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n051_o0 a jx jy (apart12).2.2.2 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart13).2.2.1 (apart2).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known052 a)), by simp [affine_beta_branches051], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n051_o1 a jx jy (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n051_o2 a jx jy (apart13).2.2.1 (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n051_o3 a jx jy (apart12).2.2.1 (apart13).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n051_o4 a jx jy (apart12).2.2.1 (ha) (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n051_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1 (apart12).2.2.2 (apart13).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known053 a)), by simp [affine_beta_branches051], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n051_o6 a jx jy (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n051_o7 a jx jy (apart13).2.2.1 (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart2).1)

theorem affine_beta_nonnegative052 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known052 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known052, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_cover0_052 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known052 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n052_wall0 a ((by simpa only [KnownContains, affine_beta_known052, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover1_052 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known052 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n052_wall1 a ((by simpa only [KnownContains, affine_beta_known052, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover2_052 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known052 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n052_wall2 a ((by simpa only [KnownContains, affine_beta_known052, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover3_052 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known052 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n052_wall3 a (ha) ((by simpa only [KnownContains, affine_beta_known052, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover4_052 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known052 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(4 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n052_wall4 a ((by simpa only [KnownContains, affine_beta_known052, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover5_052 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known052 a) ((1 : Int)+(0 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n052_wall5 a (ha) ((by simpa only [KnownContains, affine_beta_known052, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover6_052 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known052 a) ((1 : Int)+(1 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n052_wall6 a ((by simpa only [KnownContains, affine_beta_known052, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover7_052 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known052 a) ((1 : Int)+(2 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n052_wall7 a (ha) ((by simpa only [KnownContains, affine_beta_known052, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover8_052 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known052 a) ((1 : Int)+(3 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n052_wall8 a ((by simpa only [KnownContains, affine_beta_known052, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover9_052 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known052 a) ((1 : Int)+(4 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n052_wall9 a (ha) ((by simpa only [KnownContains, affine_beta_known052, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover10_052 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known052 a) ((1 : Int)+(5 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n052_wall10 a (ha) ((by simpa only [KnownContains, affine_beta_known052, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover11_052 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known052 a) ((1 : Int)+(0 : Int)) ((3 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n052_wall11 a ((by simpa only [KnownContains, affine_beta_known052, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover12_052 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known052 a) ((1 : Int)+(1 : Int)) ((3 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n052_wall12 a ((by simpa only [KnownContains, affine_beta_known052, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_leaf052 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known052 a)) B) : Transition world h .beta B := by
  apply replay_affine_leaf world h .beta (affine_beta_known052 a) .gamma (1 : Int) (3 : Int) (affine_beta_nonnegative052 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .gamma x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7 | m8 | m9 | m10
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover0_052 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover1_052 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover2_052 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover3_052 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(4 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover4_052 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(0 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover5_052 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover6_052 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(2 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover7_052 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(3 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover8_052 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(4 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover9_052 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(5 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover10_052 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.beta_n052_dirty a x y ((by simpa only [Extra,or_and_right,and_or_left,or_assoc,and_assoc] using notExtra)) (hy) ((by simpa only [KnownContains, affine_beta_known052, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (hx)
    · intro extra
      have mem := (mem_extraCells .gamma (x-(1 : Int)) (y-(3 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem
      rcases mem with e0 | e1
      · have ex : x=((1 : Int)+(0 : Int)) := by omega
        have ey : y=((3 : Int)+(0 : Int)) := by omega
        rw [ex,ey]
        exact affine_beta_cover11_052 a ha
      · have ex : x=((1 : Int)+(1 : Int)) := by omega
        have ey : y=((3 : Int)+(0 : Int)) := by omega
        rw [ex,ey]
        exact affine_beta_cover12_052 a ha

theorem affine_beta_nonnegative053 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known053 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known053, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty053 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known053 a) (1 : Int) (4 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n053_empty a ((by simpa only [KnownContains, affine_beta_known053, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window053 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known053 a)) B) : QueryWindow h (1 : Int) (4 : Int) := by
  have top4 := known_top_below state (affine_beta_nonnegative053 a ha) (t := (Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known053])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n053_height a h ((by omega)) (top4)

theorem affine_beta_complete053 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (4 : Int))
    (separated : ∀ u, u ∈ affine_beta_known053 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches053 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known053])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known053])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n053_o0 a jx jy (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known067 a)), by simp [affine_beta_branches053], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (1 : Int) ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n053_o1 a jx jy (ha) (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known058 a)), by simp [affine_beta_branches053], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n053_o2 a jx jy (apart15).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a (1 : Int) (1 : Int)) (Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n053_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart13).2.2.1 (apart13).2.1 (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)) (knownCells (affine_beta_known059 a)), by simp [affine_beta_branches053], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (1 : Int) (1 : Int) a) (Cross.mk (1 : Int) ((4 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n053_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (ha) (apart13).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) ((4 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_beta_known054 a)), by simp [affine_beta_branches053], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n053_o5 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known068 a)), by simp [affine_beta_branches053], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (1 : Int) (5 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n053_o6 a jx jy (apart13).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) (5 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known057 a)), by simp [affine_beta_branches053], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (1 : Int) (1 : Int)) (Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n053_o7 a jx jy (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)) (knownCells (affine_beta_known066 a)), by simp [affine_beta_branches053], (same_eq m0).symm⟩

theorem affine_beta_nonnegative054 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known054 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known054, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty054 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known054 a) (2 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n054_empty a (ha) ((by simpa only [KnownContains, affine_beta_known054, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window054 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known054 a)) B) : QueryWindow h (2 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative054 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known054])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n054_height a h ((by omega)) (top3)

theorem affine_beta_complete054 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known054 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches054 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known054])
  have apart9 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known054])
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known054])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known054])
  have apart16 := separated (Cross.mk (1 : Int) ((4 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_beta_known054])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n054_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.1 (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n054_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart15).2.2.1 (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known056 a)), by simp [affine_beta_branches054], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n054_o2 a jx jy (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n054_o3 a jx jy (apart15).2.2.1 (apart16).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n054_o4 a jx jy (ha) (apart9).2.2.1 (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n054_o5 a jx jy (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (2 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n054_o6 a jx jy (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known055 a)), by simp [affine_beta_branches054], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n054_o7 a jx jy (ha) (apart13).2.1 (apart15).2.1 (apart16).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative055 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known055 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known055, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty055 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known055 a) (3 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n055_empty a ((by simpa only [KnownContains, affine_beta_known055, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window055 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known055 a)) B) : QueryWindow h (3 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative055 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known055])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n055_height a h (top3) ((by omega))

theorem affine_beta_complete055 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known055 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches055 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart9 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known055])
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known055])
  have apart14 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known055])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known055])
  have apart17 := separated (Cross.mk (2 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known055])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n055_o0 a jx jy (apart17).2.1 (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n055_o1 a jx jy (ha) (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart17).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n055_o2 a jx jy (ha) (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart17).2.2.1 (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n055_o3 a jx jy (apart15).2.2.1 (apart17).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n055_o4 a jx jy (apart17).2.1 (apart14).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n055_o5 a jx jy (apart15).2.2.1 (apart13).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n055_o6 a jx jy (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart17).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n055_o7 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).1 (apart17).2.2.1 (apart15).2.1)

theorem affine_beta_nonnegative056 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known056 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known056, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty056 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known056 a) (3 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n056_empty a (ha) ((by simpa only [KnownContains, affine_beta_known056, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window056 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known056 a)) B) : QueryWindow h (3 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative056 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known056])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n056_height a h (top3) ((by omega))

theorem affine_beta_complete056 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known056 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches056 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart3 := separated (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known056])
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known056])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known056])
  have apart17 := separated (Cross.mk (2 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known056])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n056_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.1 (apart3).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n056_o1 a jx jy (apart15).2.2.1 (apart17).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n056_o2 a jx jy (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n056_o3 a jx jy (apart15).2.2.1 (apart17).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n056_o4 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (apart17).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n056_o5 a jx jy (apart15).2.1 (ha) (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n056_o6 a jx jy (ha) (apart17).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n056_o7 a jx jy (apart17).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1)

theorem affine_beta_nonnegative057 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known057 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known057, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty057 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known057 a) (2 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n057_empty a ((by simpa only [KnownContains, affine_beta_known057, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window057 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known057 a)) B) : QueryWindow h (2 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative057 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known057])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n057_height a h (top3) ((by omega))

theorem affine_beta_complete057 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known057 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches057 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known057])
  have apart9 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known057])
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known057])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known057])
  have apart16 := separated (Cross.mk (1 : Int) (5 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known057])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n057_o0 a jx jy (ha) (apart13).1 (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n057_o1 a jx jy (apart16).2.2.1 (apart8).2.2.1 (apart16).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n057_o2 a jx jy (apart15).2.2.1 (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n057_o3 a jx jy (ha) (apart15).2.2.1 (apart16).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n057_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart8).2.2.1 (apart16).2.1 (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n057_o5 a jx jy (apart15).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n057_o6 a jx jy (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart16).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n057_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.1 (apart13).1 (apart15).2.1 (ha))

theorem affine_beta_nonnegative058 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known058 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known058, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty058 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known058 a) (2 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n058_empty a ((by simpa only [KnownContains, affine_beta_known058, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window058 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known058 a)) B) : QueryWindow h (2 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative058 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known058])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n058_height a h (top3) ((by omega))

theorem affine_beta_complete058 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known058 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches058 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known058])
  have apart9 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known058])
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known058])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known058])
  have apart16 := separated (Cross.mk (1 : Int) ((4 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known058])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n058_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (apart13).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n058_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.2.1 (apart16).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n058_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1 (ha) (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n058_o3 a jx jy (ha) (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n058_o4 a jx jy (apart9).2.2.1 (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n058_o5 a jx jy (apart13).2.1 (ha) (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n058_o6 a jx jy (ha) (apart16).2.2.1 (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n058_o7 a jx jy (apart16).2.1 (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.1)

theorem affine_beta_nonnegative059 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known059 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known059, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty059 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known059 a) (1 : Int) (5 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n059_empty a ((by simpa only [KnownContains, affine_beta_known059, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window059 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known059 a)) B) : QueryWindow h (1 : Int) (5 : Int) := by
  have top16 := known_top_below state (affine_beta_nonnegative059 a ha) (t := (Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int))) (by simp [affine_beta_known059])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n059_height a h (ha) (top16) ((by omega))

theorem affine_beta_complete059 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (5 : Int))
    (separated : ∀ u, u ∈ affine_beta_known059 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches059 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known059])
  have apart16 := separated (Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)) (by simp [affine_beta_known059])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n059_o0 a jx jy (apart13).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (1 : Int) ((5 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n059_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart16).2.1 (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) ((5 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known063 a)), by simp [affine_beta_branches059], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n059_o2 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.1 (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n059_o3 a jx jy (apart16).2.2.1 (apart13).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (1 : Int) (1 : Int) a) (Cross.mk (1 : Int) ((5 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n059_o4 a jx jy (ha) (apart16).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) ((5 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_beta_known060 a)), by simp [affine_beta_branches059], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n059_o5 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.1 (apart13).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n059_o6 a jx jy (apart13).2.2.2 (ha) (apart16).2.1 (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n059_o7 a jx jy (apart13).2.1 (apart16).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative060 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known060 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known060, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty060 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known060 a) (3 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n060_empty a ((by simpa only [KnownContains, affine_beta_known060, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window060 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known060 a)) B) : QueryWindow h (3 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative060 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known060])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n060_height a h (top3) ((by omega))

theorem affine_beta_complete060 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known060 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches060 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known060])
  have apart14 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known060])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known060])
  have apart16 := separated (Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)) (by simp [affine_beta_known060])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n060_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart16).2.1 (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n060_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known062 a)), by simp [affine_beta_branches060], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n060_o2 a jx jy (apart15).2.1 (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n060_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (ha) (apart16).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n060_o4 a jx jy (apart14).2.2.1 (apart16).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n060_o5 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (3 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n060_o6 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known061 a)), by simp [affine_beta_branches060], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n060_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.1 (apart16).2.1)

theorem affine_beta_nonnegative061 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known061 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known061, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty061 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known061 a) (4 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n061_empty a (ha) ((by simpa only [KnownContains, affine_beta_known061, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window061 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known061 a)) B) : QueryWindow h (4 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative061 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known061])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n061_height a h ((by omega)) (top3)

theorem affine_beta_complete061 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (4 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known061 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches061 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart10 := separated (Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known061])
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known061])
  have apart14 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known061])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known061])
  have apart18 := separated (Cross.mk (3 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known061])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n061_o0 a jx jy (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n061_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart18).2.2.1 (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n061_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (apart15).2.2.1 (apart18).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n061_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (ha) (apart18).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n061_o4 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart18).2.1 (apart14).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n061_o5 a jx jy (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (apart13).1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n061_o6 a jx jy (apart18).2.2.1 (apart10).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n061_o7 a jx jy (apart13).1 (apart15).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart18).2.2.1)

theorem affine_beta_nonnegative062 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known062 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known062, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty062 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known062 a) (4 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n062_empty a ((by simpa only [KnownContains, affine_beta_known062, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window062 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known062 a)) B) : QueryWindow h (4 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative062 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known062])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n062_height a h ((by omega)) (top3)

theorem affine_beta_complete062 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (4 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known062 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches062 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known062])
  have apart14 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known062])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known062])
  have apart18 := separated (Cross.mk (3 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known062])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n062_o0 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (apart13).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n062_o1 a jx jy (apart15).2.2.1 (ha) (apart18).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n062_o2 a jx jy (apart15).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n062_o3 a jx jy (apart15).2.2.1 (apart18).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n062_o4 a jx jy (apart14).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart18).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n062_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1 (apart15).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n062_o6 a jx jy (apart15).2.2.1 (apart18).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n062_o7 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart18).2.1 (apart15).2.1)

theorem affine_beta_nonnegative063 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known063 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known063, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty063 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known063 a) (3 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n063_empty a (ha) ((by simpa only [KnownContains, affine_beta_known063, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window063 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known063 a)) B) : QueryWindow h (3 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative063 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known063])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n063_height a h ((by omega)) (top3)

theorem affine_beta_complete063 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known063 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches063 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known063])
  have apart14 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known063])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known063])
  have apart16 := separated (Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)) (by simp [affine_beta_known063])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n063_o0 a jx jy (ha) (apart15).2.1 (apart13).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n063_o1 a jx jy (ha) (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known065 a)), by simp [affine_beta_branches063], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n063_o2 a jx jy (ha) (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n063_o3 a jx jy (apart16).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n063_o4 a jx jy (apart16).2.1 (ha) (apart14).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n063_o5 a jx jy (ha) (apart15).2.1 (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (3 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n063_o6 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (3 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known064 a)), by simp [affine_beta_branches063], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n063_o7 a jx jy (apart16).2.1 (ha) (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative064 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known064 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known064, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty064 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known064 a) (4 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n064_empty a ((by simpa only [KnownContains, affine_beta_known064, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window064 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known064 a)) B) : QueryWindow h (4 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative064 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known064])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n064_height a h ((by omega)) (top3)

theorem affine_beta_complete064 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (4 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known064 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches064 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart10 := separated (Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known064])
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known064])
  have apart14 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known064])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known064])
  have apart16 := separated (Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)) (by simp [affine_beta_known064])
  have apart18 := separated (Cross.mk (3 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known064])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n064_o0 a jx jy (ha) (apart15).2.1 (apart16).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n064_o1 a jx jy (apart18).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n064_o2 a jx jy (apart15).2.1 (apart18).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n064_o3 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (apart18).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n064_o4 a jx jy (apart14).2.2.1 (ha) (apart18).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n064_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).1 (apart15).2.1 (apart15).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n064_o6 a jx jy (ha) (apart10).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart18).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n064_o7 a jx jy (apart13).1 (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart18).2.2.1)

theorem affine_beta_nonnegative065 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known065 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known065, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty065 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known065 a) (4 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n065_empty a ((by simpa only [KnownContains, affine_beta_known065, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window065 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known065 a)) B) : QueryWindow h (4 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative065 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known065])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n065_height a h ((by omega)) (top3)

theorem affine_beta_complete065 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (4 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known065 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches065 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known065])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known065])
  have apart18 := separated (Cross.mk (3 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known065])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n065_o0 a jx jy (apart13).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n065_o1 a jx jy (apart18).1 (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n065_o2 a jx jy (ha) (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n065_o3 a jx jy (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart18).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n065_o4 a jx jy (apart15).2.2.1 (apart18).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n065_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).1 (apart15).2.1 (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n065_o6 a jx jy (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart18).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n065_o7 a jx jy (ha) (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart18).2.1)

theorem affine_beta_nonnegative066 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known066 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known066, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_cover0_066 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known066 a) ((1 : Int)+(-1 : Int)) ((5 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n066_wall0 a (ha) ((by simpa only [KnownContains, affine_beta_known066, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover1_066 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known066 a) ((1 : Int)+(-1 : Int)) ((5 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n066_wall1 a ((by simpa only [KnownContains, affine_beta_known066, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover2_066 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known066 a) ((1 : Int)+(-1 : Int)) ((5 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n066_wall2 a ((by simpa only [KnownContains, affine_beta_known066, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover3_066 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known066 a) ((1 : Int)+(-1 : Int)) ((5 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n066_wall3 a ((by simpa only [KnownContains, affine_beta_known066, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover4_066 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known066 a) ((1 : Int)+(0 : Int)) ((5 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n066_wall4 a (ha) ((by simpa only [KnownContains, affine_beta_known066, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover5_066 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known066 a) ((1 : Int)+(1 : Int)) ((5 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n066_wall5 a ((by simpa only [KnownContains, affine_beta_known066, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover6_066 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known066 a) ((1 : Int)+(2 : Int)) ((5 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n066_wall6 a ((by simpa only [KnownContains, affine_beta_known066, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover7_066 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known066 a) ((1 : Int)+(3 : Int)) ((5 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n066_wall7 a (ha) ((by simpa only [KnownContains, affine_beta_known066, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_leaf066 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known066 a)) B) : Transition world h .beta B := by
  apply replay_affine_leaf world h .beta (affine_beta_known066 a) .alpha (1 : Int) (5 : Int) (affine_beta_nonnegative066 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .alpha x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (5 : Int)+y=((5 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover0_066 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (5 : Int)+y=((5 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover1_066 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (5 : Int)+y=((5 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover2_066 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (5 : Int)+y=((5 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover3_066 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(0 : Int)) := by omega
      have ey : (5 : Int)+y=((5 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover4_066 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(1 : Int)) := by omega
      have ey : (5 : Int)+y=((5 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover5_066 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(2 : Int)) := by omega
      have ey : (5 : Int)+y=((5 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover6_066 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(3 : Int)) := by omega
      have ey : (5 : Int)+y=((5 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover7_066 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.beta_n066_dirty a x y (hx) ((by simpa only [KnownContains, affine_beta_known066, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (hy)
    · intro extra
      have mem := (mem_extraCells .alpha (x-(1 : Int)) (y-(5 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem

theorem affine_beta_nonnegative067 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known067 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known067, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty067 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known067 a) (2 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n067_empty a (ha) ((by simpa only [KnownContains, affine_beta_known067, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window067 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known067 a)) B) : QueryWindow h (2 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative067 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known067])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n067_height a h (top3) ((by omega))

theorem affine_beta_complete067 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known067 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches067 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known067])
  have apart9 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known067])
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known067])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known067])
  have apart16 := separated (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known067])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n067_o0 a jx jy (ha) (apart15).2.1 (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n067_o1 a jx jy (ha) (apart8).2.2.1 (apart13).2.2.1 (apart16).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n067_o2 a jx jy (apart16).2.2.2 (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n067_o3 a jx jy (apart16).2.2.2 (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n067_o4 a jx jy (apart8).2.2.1 (apart16).2.2.2 (apart9).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n067_o5 a jx jy (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart16).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n067_o6 a jx jy (apart13).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.2.2 (apart8).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n067_o7 a jx jy (apart15).2.1 (apart16).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).1 (ha))

theorem affine_beta_nonnegative068 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known068 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known068, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty068 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known068 a) (2 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n068_empty a (ha) ((by simpa only [KnownContains, affine_beta_known068, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window068 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known068 a)) B) : QueryWindow h (2 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative068 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known068])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n068_height a h ((by omega)) (top3)

theorem affine_beta_complete068 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known068 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches068 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known068])
  have apart13 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known068])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known068])
  have apart16 := separated (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known068])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n068_o0 a jx jy (apart15).2.1 (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n068_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (apart16).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n068_o2 a jx jy (apart13).2.1 (ha) (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n068_o3 a jx jy (apart15).2.2.1 (apart16).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n068_o4 a jx jy (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart16).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n068_o5 a jx jy (ha) (apart16).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n068_o6 a jx jy (ha) (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n068_o7 a jx jy (apart15).2.1 (apart13).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).1)

theorem affine_beta_nonnegative069 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known069 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known069, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty069 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known069 a) (2 : Int) (0 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n069_empty a ((by simpa only [KnownContains, affine_beta_known069, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window069 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known069 a)) B) : QueryWindow h (2 : Int) (0 : Int) := by
  have top0 := known_top_below state (affine_beta_nonnegative069 a ha) (t := (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known069])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n069_height a h (top0) ((by omega))

theorem affine_beta_complete069 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (0 : Int))
    (separated : ∀ u, u ∈ affine_beta_known069 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches069 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart7 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known069])
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known069])
  have apart9 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known069])
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known069])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n069_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1 (apart8).2.2.1 (ha) (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n069_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1 (ha) (apart9).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n069_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart12).2.1 (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known070 a)), by simp [affine_beta_branches069], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n069_o3 a jx jy (apart8).2.2.1 (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n069_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart7).1 (ha) (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n069_o5 a jx jy (ha) (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known073 a)), by simp [affine_beta_branches069], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n069_o6 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (apart12).2.1 (apart12).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n069_o7 a jx jy (apart9).2.2.1 (ha) (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative070 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known070 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known070, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty070 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known070 a) (1 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n070_empty a (ha) ((by simpa only [KnownContains, affine_beta_known070, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window070 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known070 a)) B) : QueryWindow h (1 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative070 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known070])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n070_height a h (top2) ((by omega))

theorem affine_beta_complete070 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known070 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches070 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart3 := separated (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known070])
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known070])
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known070])
  have apart13 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known070])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n070_o0 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart12).2.2.2 (apart13).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known071 a)), by simp [affine_beta_branches070], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n070_o1 a jx jy (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n070_o2 a jx jy (ha) (apart3).1 (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n070_o3 a jx jy (apart12).2.2.1 (ha) (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n070_o4 a jx jy (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.2.2 (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n070_o5 a jx jy (apart12).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) (apart13).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known072 a)), by simp [affine_beta_branches070], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n070_o6 a jx jy (apart12).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n070_o7 a jx jy (apart13).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1)

theorem affine_beta_nonnegative071 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known071 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known071, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty071 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known071 a) (1 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n071_empty a (ha) ((by simpa only [KnownContains, affine_beta_known071, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window071 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known071 a)) B) : QueryWindow h (1 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative071 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known071])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n071_height a h ((by omega)) (top3)

theorem affine_beta_complete071 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known071 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches071 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart3 := separated (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known071])
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known071])
  have apart13 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known071])
  have apart15 := separated (Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known071])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n071_o0 a jx jy (ha) (apart3).1 (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n071_o1 a jx jy (apart13).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1 (apart12).2.2.2 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n071_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (ha) (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n071_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.2.2 (apart15).2.1 (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n071_o4 a jx jy (apart15).2.1 (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n071_o5 a jx jy (apart3).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n071_o6 a jx jy (apart12).2.2.2 (apart13).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n071_o7 a jx jy (apart15).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.1)

theorem affine_beta_nonnegative072 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known072 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known072, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty072 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known072 a) (1 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n072_empty a ((by simpa only [KnownContains, affine_beta_known072, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window072 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known072 a)) B) : QueryWindow h (1 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative072 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known072])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n072_height a h (top3) ((by omega))

theorem affine_beta_complete072 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known072 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches072 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known072])
  have apart13 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known072])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known072])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n072_o0 a jx jy (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n072_o1 a jx jy (apart13).2.2.1 (apart13).2.2.2 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n072_o2 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n072_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1 (ha) (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n072_o4 a jx jy (ha) (apart12).2.2.1 (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n072_o5 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n072_o6 a jx jy (ha) (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n072_o7 a jx jy (apart15).2.1 (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))

theorem affine_beta_nonnegative073 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known073 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known073, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty073 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known073 a) (1 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n073_empty a (ha) ((by simpa only [KnownContains, affine_beta_known073, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window073 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known073 a)) B) : QueryWindow h (1 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative073 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known073])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n073_height a h ((by omega)) (top2)

theorem affine_beta_complete073 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known073 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches073 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart3 := separated (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known073])
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known073])
  have apart13 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known073])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n073_o0 a jx jy (apart13).2.1 (apart12).2.2.2 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known074 a)), by simp [affine_beta_branches073], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n073_o1 a jx jy (apart13).1 (apart13).2.2.2 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n073_o2 a jx jy (ha) (apart3).1 (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n073_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1 (apart13).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n073_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1 (ha) (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n073_o5 a jx jy (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart12).1 (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known075 a)), by simp [affine_beta_branches073], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n073_o6 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1 (apart12).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n073_o7 a jx jy (apart13).2.1 (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))

theorem affine_beta_nonnegative074 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known074 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known074, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty074 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known074 a) (1 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n074_empty a ((by simpa only [KnownContains, affine_beta_known074, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window074 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known074 a)) B) : QueryWindow h (1 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative074 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known074])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n074_height a h (top3) ((by omega))

theorem affine_beta_complete074 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known074 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches074 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart3 := separated (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known074])
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known074])
  have apart13 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known074])
  have apart15 := separated (Cross.mk (2 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known074])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n074_o0 a jx jy (apart15).2.1 (apart3).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n074_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.2 (apart12).2.2.2 (ha) (apart13).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n074_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (apart13).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n074_o3 a jx jy (apart13).2.1 (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.2 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n074_o4 a jx jy (ha) (apart15).2.1 (apart12).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n074_o5 a jx jy (apart3).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n074_o6 a jx jy (ha) (apart13).2.2.1 (apart12).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n074_o7 a jx jy (apart13).2.1 (ha) (apart15).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative075 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known075 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known075, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty075 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known075 a) (1 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n075_empty a ((by simpa only [KnownContains, affine_beta_known075, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window075 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known075 a)) B) : QueryWindow h (1 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative075 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known075])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n075_height a h (top3) ((by omega))

theorem affine_beta_complete075 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known075 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches075 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart3 := separated (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known075])
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known075])
  have apart13 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known075])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known075])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n075_o0 a jx jy (apart15).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart3).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n075_o1 a jx jy (apart12).2.2.2 (apart13).2.2.2 (apart13).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n075_o2 a jx jy (apart13).2.1 (apart15).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n075_o3 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n075_o4 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1 (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n075_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.1 (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n075_o6 a jx jy (apart12).2.2.2 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n075_o7 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1 (apart15).2.1)

theorem affine_beta_nonnegative076 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known076 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known076, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty076 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known076 a) (2 : Int) (0 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n076_empty a ((by simpa only [KnownContains, affine_beta_known076, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window076 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known076 a)) B) : QueryWindow h (2 : Int) (0 : Int) := by
  have top0 := known_top_below state (affine_beta_nonnegative076 a ha) (t := (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known076])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n076_height a h (top0) ((by omega))

theorem affine_beta_complete076 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (0 : Int))
    (separated : ∀ u, u ∈ affine_beta_known076 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches076 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart6 := separated (Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known076])
  have apart7 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known076])
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known076])
  have apart9 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known076])
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known076])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n076_o0 a jx jy (apart8).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart6).1 (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n076_o1 a jx jy (apart12).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n076_o2 a jx jy (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known077 a)), by simp [affine_beta_branches076], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n076_o3 a jx jy (apart8).2.2.1 (apart9).2.2.1 (apart12).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n076_o4 a jx jy (apart7).1 (ha) (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n076_o5 a jx jy (apart12).2.1 (apart9).1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known094 a)), by simp [affine_beta_branches076], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n076_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (ha) (apart12).1 (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n076_o7 a jx jy (apart9).2.2.1 (ha) (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative077 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known077 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known077, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty077 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known077 a) (0 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n077_empty a ((by simpa only [KnownContains, affine_beta_known077, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window077 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known077 a)) B) : QueryWindow h (0 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative077 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known077])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n077_height a h (top3) ((by omega))

theorem affine_beta_complete077 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (0 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known077 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches077 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known077])
  have apart3 := separated (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known077])
  have apart4 := separated (Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known077])
  have apart6 := separated (Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known077])
  have apart13 := separated (Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known077])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n077_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart3).1 (apart13).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n077_o1 a jx jy (apart13).2.2.1 (apart3).1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known080 a)), by simp [affine_beta_branches077], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n077_o2 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart4).1 (apart13).2.1 (apart3).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n077_o3 a jx jy (apart2).1 (apart4).1 (apart3).1 (apart6).2.2.1 (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (1 : Int) (1 : Int) a) (Cross.mk (0 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n077_o4 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1 (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_beta_known078 a)), by simp [affine_beta_branches077], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n077_o5 a jx jy (ha) (apart3).2.2.1 (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (0 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n077_o6 a jx jy (apart6).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart3).1 (apart13).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known079 a)), by simp [affine_beta_branches077], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n077_o7 a jx jy (ha) (apart4).1 (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart3).1)

theorem affine_beta_nonnegative078 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known078 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known078, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_cover0_078 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known078 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n078_wall0 a ((by simpa only [KnownContains, affine_beta_known078, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover1_078 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known078 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n078_wall1 a (ha) ((by simpa only [KnownContains, affine_beta_known078, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover2_078 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known078 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n078_wall2 a ((by simpa only [KnownContains, affine_beta_known078, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover3_078 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known078 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n078_wall3 a (ha) ((by simpa only [KnownContains, affine_beta_known078, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover4_078 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known078 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(4 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n078_wall4 a (ha) ((by simpa only [KnownContains, affine_beta_known078, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover5_078 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known078 a) ((1 : Int)+(0 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n078_wall5 a ((by simpa only [KnownContains, affine_beta_known078, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover6_078 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known078 a) ((1 : Int)+(1 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n078_wall6 a (ha) ((by simpa only [KnownContains, affine_beta_known078, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover7_078 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known078 a) ((1 : Int)+(2 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n078_wall7 a (ha) ((by simpa only [KnownContains, affine_beta_known078, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover8_078 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known078 a) ((1 : Int)+(3 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n078_wall8 a (ha) ((by simpa only [KnownContains, affine_beta_known078, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover9_078 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known078 a) ((1 : Int)+(4 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n078_wall9 a (ha) ((by simpa only [KnownContains, affine_beta_known078, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover10_078 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known078 a) ((1 : Int)+(5 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n078_wall10 a (ha) ((by simpa only [KnownContains, affine_beta_known078, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover11_078 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known078 a) ((1 : Int)+(0 : Int)) ((3 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n078_wall11 a ((by simpa only [KnownContains, affine_beta_known078, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_leaf078 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known078 a)) B) : Transition world h .beta B := by
  apply replay_affine_leaf world h .beta (affine_beta_known078 a) .beta (1 : Int) (3 : Int) (affine_beta_nonnegative078 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .beta x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7 | m8 | m9 | m10
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover0_078 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover1_078 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover2_078 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover3_078 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(4 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover4_078 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(0 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover5_078 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover6_078 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(2 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover7_078 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(3 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover8_078 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(4 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover9_078 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(5 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover10_078 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.beta_n078_dirty a x y (hy) (hx) ((by simpa only [KnownContains, affine_beta_known078, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) ((by simpa only [Extra,or_and_right,and_or_left,or_assoc,and_assoc] using notExtra))
    · intro extra
      have mem := (mem_extraCells .beta (x-(1 : Int)) (y-(3 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem
      have ex : x=((1 : Int)+(0 : Int)) := by omega
      have ey : y=((3 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover11_078 a ha

theorem affine_beta_nonnegative079 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known079 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known079, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_cover0_079 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known079 a) ((1 : Int)+(0 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n079_wall0 a ((by simpa only [KnownContains, affine_beta_known079, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover1_079 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known079 a) ((1 : Int)+(1 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n079_wall1 a ((by simpa only [KnownContains, affine_beta_known079, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover2_079 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known079 a) ((1 : Int)+(2 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n079_wall2 a ((by simpa only [KnownContains, affine_beta_known079, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover3_079 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known079 a) ((1 : Int)+(3 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n079_wall3 a (ha) ((by simpa only [KnownContains, affine_beta_known079, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover4_079 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known079 a) ((1 : Int)+(4 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n079_wall4 a ((by simpa only [KnownContains, affine_beta_known079, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover5_079 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known079 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n079_wall5 a ((by simpa only [KnownContains, affine_beta_known079, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover6_079 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known079 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n079_wall6 a ((by simpa only [KnownContains, affine_beta_known079, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover7_079 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known079 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n079_wall7 a (ha) ((by simpa only [KnownContains, affine_beta_known079, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover8_079 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known079 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n079_wall8 a ((by simpa only [KnownContains, affine_beta_known079, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover9_079 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known079 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(4 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n079_wall9 a ((by simpa only [KnownContains, affine_beta_known079, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover10_079 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known079 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(5 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n079_wall10 a ((by simpa only [KnownContains, affine_beta_known079, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover11_079 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known079 a) ((1 : Int)+(0 : Int)) ((3 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n079_wall11 a ((by simpa only [KnownContains, affine_beta_known079, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover12_079 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known079 a) ((1 : Int)+(0 : Int)) ((3 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n079_wall12 a ((by simpa only [KnownContains, affine_beta_known079, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_leaf079 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known079 a)) B) : Transition world h .beta B := by
  apply replay_affine_leaf world h .beta (affine_beta_known079 a) .gammaTranspose (1 : Int) (3 : Int) (affine_beta_nonnegative079 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .gammaTranspose x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7 | m8 | m9 | m10
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover5_079 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover6_079 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover7_079 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover8_079 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(4 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover9_079 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(5 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover10_079 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(0 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover0_079 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover1_079 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(2 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover2_079 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(3 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover3_079 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(4 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover4_079 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.beta_n079_dirty a x y ((by simpa only [Extra,or_and_right,and_or_left,or_assoc,and_assoc] using notExtra)) ((by simpa only [KnownContains, affine_beta_known079, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (hx) (hy)
    · intro extra
      have mem := (mem_extraCells .gammaTranspose (x-(1 : Int)) (y-(3 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem
      rcases mem with e0 | e1
      · have ex : x=((1 : Int)+(0 : Int)) := by omega
        have ey : y=((3 : Int)+(0 : Int)) := by omega
        rw [ex,ey]
        exact affine_beta_cover11_079 a ha
      · have ex : x=((1 : Int)+(0 : Int)) := by omega
        have ey : y=((3 : Int)+(1 : Int)) := by omega
        rw [ex,ey]
        exact affine_beta_cover12_079 a ha

theorem affine_beta_nonnegative080 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known080 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known080, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty080 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known080 a) (1 : Int) (4 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n080_empty a ((by simpa only [KnownContains, affine_beta_known080, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window080 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known080 a)) B) : QueryWindow h (1 : Int) (4 : Int) := by
  have top4 := known_top_below state (affine_beta_nonnegative080 a ha) (t := (Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known080])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n080_height a h (top4) ((by omega))

theorem affine_beta_complete080 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (4 : Int))
    (separated : ∀ u, u ∈ affine_beta_known080 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches080 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known080])
  have apart13 := separated (Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known080])
  have apart15 := separated (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known080])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n080_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known089 a)), by simp [affine_beta_branches080], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n080_o1 a jx jy (ha) (apart15).2.2.1 (apart15).2.2.2 (apart13).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n080_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known091 a)), by simp [affine_beta_branches080], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a (1 : Int) (1 : Int)) (Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n080_o3 a jx jy (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.2 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)) (knownCells (affine_beta_known081 a)), by simp [affine_beta_branches080], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n080_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1 (ha) (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n080_o5 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known092 a)), by simp [affine_beta_branches080], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n080_o6 a jx jy (apart13).2.2.2 (apart15).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (1 : Int) (1 : Int)) (Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n080_o7 a jx jy (apart15).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)) (knownCells (affine_beta_known082 a)), by simp [affine_beta_branches080], (same_eq m0).symm⟩

theorem affine_beta_nonnegative081 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known081 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known081, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_cover0_081 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known081 a) ((3 : Int)+(-1 : Int)) ((3 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n081_wall0 a ((by simpa only [KnownContains, affine_beta_known081, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover1_081 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known081 a) ((3 : Int)+(-1 : Int)) ((3 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n081_wall1 a ((by simpa only [KnownContains, affine_beta_known081, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover2_081 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known081 a) ((3 : Int)+(-1 : Int)) ((3 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n081_wall2 a ((by simpa only [KnownContains, affine_beta_known081, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover3_081 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known081 a) ((3 : Int)+(-1 : Int)) ((3 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n081_wall3 a (ha) ((by simpa only [KnownContains, affine_beta_known081, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover4_081 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known081 a) ((3 : Int)+(0 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n081_wall4 a ((by simpa only [KnownContains, affine_beta_known081, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover5_081 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known081 a) ((3 : Int)+(1 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n081_wall5 a ((by simpa only [KnownContains, affine_beta_known081, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover6_081 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known081 a) ((3 : Int)+(2 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n081_wall6 a ((by simpa only [KnownContains, affine_beta_known081, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover7_081 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known081 a) ((3 : Int)+(3 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n081_wall7 a ((by simpa only [KnownContains, affine_beta_known081, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_leaf081 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known081 a)) B) : Transition world h .beta B := by
  apply replay_affine_leaf world h .beta (affine_beta_known081 a) .alpha (3 : Int) (3 : Int) (affine_beta_nonnegative081 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .alpha x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7
    · have ex : (3 : Int)+x=((3 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover0_081 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover1_081 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover2_081 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover3_081 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(0 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover4_081 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover5_081 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(2 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover6_081 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(3 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover7_081 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.beta_n081_dirty a x y (hy) (hx) ((by simpa only [KnownContains, affine_beta_known081, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))
    · intro extra
      have mem := (mem_extraCells .alpha (x-(3 : Int)) (y-(3 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem

theorem affine_beta_nonnegative082 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known082 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known082, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty082 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known082 a) (1 : Int) (5 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n082_empty a ((by simpa only [KnownContains, affine_beta_known082, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window082 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known082 a)) B) : QueryWindow h (1 : Int) (5 : Int) := by
  have top15 := known_top_below state (affine_beta_nonnegative082 a ha) (t := (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)) (by simp [affine_beta_known082])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n082_height a h (top15) ((by omega)) (ha)

theorem affine_beta_complete082 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (5 : Int))
    (separated : ∀ u, u ∈ affine_beta_known082 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches082 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known082])
  have apart13 := separated (Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known082])
  have apart15 := separated (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known082])
  have apart16 := separated (Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known082])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (2 : Int) (5 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n082_o0 a jx jy (apart15).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (5 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known083 a)), by simp [affine_beta_branches082], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n082_o1 a jx jy (apart13).2.2.2 (apart15).2.2.1 (apart15).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n082_o2 a jx jy (apart16).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n082_o3 a jx jy (ha) (apart16).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n082_o4 a jx jy (apart12).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((1 : Int) + a) (5 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n082_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (5 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known086 a)), by simp [affine_beta_branches082], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n082_o6 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (apart13).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n082_o7 a jx jy (apart16).2.2.2 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1)

theorem affine_beta_nonnegative083 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known083 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known083, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty083 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known083 a) (3 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n083_empty a ((by simpa only [KnownContains, affine_beta_known083, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window083 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known083 a)) B) : QueryWindow h (3 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative083 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known083])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n083_height a h ((by omega)) (top3)

theorem affine_beta_complete083 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known083 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches083 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart9 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known083])
  have apart10 := separated (Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known083])
  have apart13 := separated (Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known083])
  have apart16 := separated (Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known083])
  have apart17 := separated (Cross.mk (2 : Int) (5 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known083])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n083_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).1 (apart13).2.1 (apart16).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n083_o1 a jx jy (apart9).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart17).2.2.1 (apart16).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n083_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.1 (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known084 a)), by simp [affine_beta_branches083], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n083_o3 a jx jy (apart16).2.1 (apart13).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n083_o4 a jx jy (apart17).2.2.1 (ha) (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n083_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.1 (apart13).2.1 (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known085 a)), by simp [affine_beta_branches083], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n083_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart17).2.2.1 (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n083_o7 a jx jy (apart13).2.2.1 (apart16).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative084 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known084 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known084, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty084 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known084 a) (1 : Int) (6 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n084_empty a (ha) ((by simpa only [KnownContains, affine_beta_known084, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window084 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known084 a)) B) : QueryWindow h (1 : Int) (6 : Int) := by
  have top17 := known_top_below state (affine_beta_nonnegative084 a ha) (t := (Cross.mk (2 : Int) (5 : Int) a (1 : Int) (1 : Int) (0 : Int))) (by simp [affine_beta_known084])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n084_height a h ((by omega)) (top17)

theorem affine_beta_complete084 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (6 : Int))
    (separated : ∀ u, u ∈ affine_beta_known084 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches084 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart15 := separated (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known084])
  have apart16 := separated (Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known084])
  have apart17 := separated (Cross.mk (2 : Int) (5 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known084])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n084_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.1 (apart17).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n084_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (apart15).2.1 (ha) (apart17).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n084_o2 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (apart17).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n084_o3 a jx jy (apart17).2.2.1 (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n084_o4 a jx jy (apart17).2.2.1 (apart15).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n084_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.2 (apart17).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n084_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart16).2.2.1 (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n084_o7 a jx jy (apart15).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart17).2.1)

theorem affine_beta_nonnegative085 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known085 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known085, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty085 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known085 a) (1 : Int) (6 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n085_empty a (ha) ((by simpa only [KnownContains, affine_beta_known085, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window085 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known085 a)) B) : QueryWindow h (1 : Int) (6 : Int) := by
  have top17 := known_top_below state (affine_beta_nonnegative085 a ha) (t := (Cross.mk (2 : Int) (5 : Int) a (1 : Int) (1 : Int) (0 : Int))) (by simp [affine_beta_known085])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n085_height a h (top17) ((by omega))

theorem affine_beta_complete085 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (6 : Int))
    (separated : ∀ u, u ∈ affine_beta_known085 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches085 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart13 := separated (Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known085])
  have apart15 := separated (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known085])
  have apart16 := separated (Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known085])
  have apart17 := separated (Cross.mk (2 : Int) (5 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known085])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n085_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart17).2.1 (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n085_o1 a jx jy (apart15).2.1 (ha) (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart17).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n085_o2 a jx jy (apart17).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n085_o3 a jx jy (apart15).2.1 (apart16).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart17).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n085_o4 a jx jy (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart17).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n085_o5 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart17).2.1 (apart15).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n085_o6 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (apart13).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n085_o7 a jx jy (ha) (apart17).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1)

theorem affine_beta_nonnegative086 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known086 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known086, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty086 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known086 a) (3 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n086_empty a ((by simpa only [KnownContains, affine_beta_known086, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window086 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known086 a)) B) : QueryWindow h (3 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative086 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known086])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n086_height a h ((by omega)) (top3)

theorem affine_beta_complete086 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known086 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches086 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart9 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known086])
  have apart10 := separated (Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known086])
  have apart13 := separated (Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known086])
  have apart16 := separated (Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known086])
  have apart17 := separated (Cross.mk ((1 : Int) + a) (5 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known086])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n086_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.1 (apart13).1 (apart16).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n086_o1 a jx jy (apart16).2.2.1 (ha) (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n086_o2 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart16).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known087 a)), by simp [affine_beta_branches086], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n086_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1 (apart16).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n086_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.2.1 (apart17).2.2.1 (apart10).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n086_o5 a jx jy (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1 (apart16).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known088 a)), by simp [affine_beta_branches086], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n086_o6 a jx jy (ha) (apart16).2.2.1 (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n086_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1 (ha) (apart16).2.1)

theorem affine_beta_nonnegative087 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known087 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known087, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty087 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known087 a) (1 : Int) (6 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n087_empty a ((by simpa only [KnownContains, affine_beta_known087, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window087 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known087 a)) B) : QueryWindow h (1 : Int) (6 : Int) := by
  have top17 := known_top_below state (affine_beta_nonnegative087 a ha) (t := (Cross.mk ((1 : Int) + a) (5 : Int) (1 : Int) (1 : Int) a (0 : Int))) (by simp [affine_beta_known087])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n087_height a h ((by omega)) (top17)

theorem affine_beta_complete087 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (6 : Int))
    (separated : ∀ u, u ∈ affine_beta_known087 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches087 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart13 := separated (Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known087])
  have apart15 := separated (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known087])
  have apart17 := separated (Cross.mk ((1 : Int) + a) (5 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known087])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n087_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart17).2.1 (ha) (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n087_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.2 (ha) (apart15).2.2.2 (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n087_o2 a jx jy (ha) (apart17).2.2.1 (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n087_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.1 (apart17).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n087_o4 a jx jy (apart15).2.2.1 (apart17).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n087_o5 a jx jy (apart17).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n087_o6 a jx jy (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.2 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n087_o7 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart17).2.1 (apart15).2.1)

theorem affine_beta_nonnegative088 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known088 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known088, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty088 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known088 a) (1 : Int) (6 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n088_empty a (ha) ((by simpa only [KnownContains, affine_beta_known088, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window088 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known088 a)) B) : QueryWindow h (1 : Int) (6 : Int) := by
  have top17 := known_top_below state (affine_beta_nonnegative088 a ha) (t := (Cross.mk ((1 : Int) + a) (5 : Int) (1 : Int) (1 : Int) a (0 : Int))) (by simp [affine_beta_known088])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n088_height a h (top17) ((by omega))

theorem affine_beta_complete088 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (6 : Int))
    (separated : ∀ u, u ∈ affine_beta_known088 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches088 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart13 := separated (Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known088])
  have apart15 := separated (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known088])
  have apart17 := separated (Cross.mk ((1 : Int) + a) (5 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known088])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n088_o0 a jx jy (ha) (apart17).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n088_o1 a jx jy (apart13).2.2.2 (apart15).2.2.1 (apart15).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n088_o2 a jx jy (apart17).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n088_o3 a jx jy (ha) (apart17).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n088_o4 a jx jy (apart15).2.2.1 (apart17).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n088_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.1 (apart17).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n088_o6 a jx jy (apart13).2.2.2 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n088_o7 a jx jy (apart15).2.1 (apart17).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))

theorem affine_beta_nonnegative089 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known089 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known089, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty089 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known089 a) (2 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n089_empty a ((by simpa only [KnownContains, affine_beta_known089, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window089 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known089 a)) B) : QueryWindow h (2 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative089 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known089])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n089_height a h (top3) ((by omega))

theorem affine_beta_complete089 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known089 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches089 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known089])
  have apart9 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known089])
  have apart13 := separated (Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known089])
  have apart16 := separated (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known089])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n089_o0 a jx jy (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart16).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n089_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1 (apart16).2.2.2 (ha) (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((2 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n089_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart16).2.2.2
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((2 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known090 a)), by simp [affine_beta_branches089], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n089_o3 a jx jy (ha) (apart13).2.2.1 (apart16).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n089_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (ha) (apart13).2.1 (apart16).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n089_o5 a jx jy (apart16).2.2.1 (apart13).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n089_o6 a jx jy (apart13).2.1 (apart8).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n089_o7 a jx jy (apart13).2.2.1 (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.2.2 (ha))

theorem affine_beta_nonnegative090 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known090 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known090, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty090 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known090 a) (1 : Int) (5 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n090_empty a ((by simpa only [KnownContains, affine_beta_known090, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window090 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known090 a)) B) : QueryWindow h (1 : Int) (5 : Int) := by
  have top16 := known_top_below state (affine_beta_nonnegative090 a ha) (t := (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int))) (by simp [affine_beta_known090])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n090_height a h ((by omega)) (top16)

theorem affine_beta_complete090 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (5 : Int))
    (separated : ∀ u, u ∈ affine_beta_known090 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches090 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart13 := separated (Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known090])
  have apart15 := separated (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known090])
  have apart16 := separated (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known090])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n090_o0 a jx jy (apart15).2.1 (ha) (apart16).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n090_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.2 (ha) (apart15).2.2.2 (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n090_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.1 (ha) (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n090_o3 a jx jy (apart16).2.2.1 (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n090_o4 a jx jy (apart15).2.1 (apart16).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n090_o5 a jx jy (apart15).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n090_o6 a jx jy (apart13).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n090_o7 a jx jy (ha) (apart15).2.1 (apart16).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative091 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known091 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known091, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty091 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known091 a) (2 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n091_empty a (ha) ((by simpa only [KnownContains, affine_beta_known091, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window091 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known091 a)) B) : QueryWindow h (2 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative091 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known091])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n091_height a h ((by omega)) (top3)

theorem affine_beta_complete091 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known091 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches091 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known091])
  have apart13 := separated (Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known091])
  have apart15 := separated (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known091])
  have apart16 := separated (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known091])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n091_o0 a jx jy (ha) (apart16).2.1 (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n091_o1 a jx jy (ha) (apart16).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n091_o2 a jx jy (apart16).2.1 (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n091_o3 a jx jy (ha) (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n091_o4 a jx jy (apart13).2.1 (ha) (apart16).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n091_o5 a jx jy (ha) (apart13).2.1 (apart16).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n091_o6 a jx jy (apart13).2.2.1 (apart16).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n091_o7 a jx jy (apart16).2.1 (apart13).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative092 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known092 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known092, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty092 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known092 a) (2 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n092_empty a ((by simpa only [KnownContains, affine_beta_known092, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window092 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known092 a)) B) : QueryWindow h (2 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative092 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known092])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n092_height a h (top3) ((by omega))

theorem affine_beta_complete092 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known092 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches092 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known092])
  have apart13 := separated (Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known092])
  have apart15 := separated (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known092])
  have apart16 := separated (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known092])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n092_o0 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.2.1 (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n092_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.2.1 (ha) (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((2 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n092_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1 (apart15).2.1 (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((2 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known093 a)), by simp [affine_beta_branches092], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n092_o3 a jx jy (ha) (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n092_o4 a jx jy (ha) (apart13).2.1 (apart16).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n092_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.1 (apart16).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n092_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.2.1 (ha) (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n092_o7 a jx jy (apart16).1 (ha) (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1)

theorem affine_beta_nonnegative093 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known093 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known093, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty093 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known093 a) (1 : Int) (5 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n093_empty a ((by simpa only [KnownContains, affine_beta_known093, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window093 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known093 a)) B) : QueryWindow h (1 : Int) (5 : Int) := by
  have top16 := known_top_below state (affine_beta_nonnegative093 a ha) (t := (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int))) (by simp [affine_beta_known093])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n093_height a h (top16) ((by omega))

theorem affine_beta_complete093 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (5 : Int))
    (separated : ∀ u, u ∈ affine_beta_known093 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches093 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known093])
  have apart13 := separated (Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known093])
  have apart15 := separated (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known093])
  have apart16 := separated (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known093])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n093_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (ha) (apart16).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n093_o1 a jx jy (ha) (apart13).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.2 (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n093_o2 a jx jy (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart16).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n093_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (apart16).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n093_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.2.1 (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n093_o5 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.2.2 (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n093_o6 a jx jy (apart15).2.2.1 (apart13).2.2.2 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n093_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.1 (apart15).2.1 (ha))

theorem affine_beta_nonnegative094 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known094 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known094, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty094 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known094 a) (0 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n094_empty a ((by simpa only [KnownContains, affine_beta_known094, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window094 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known094 a)) B) : QueryWindow h (0 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative094 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known094])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n094_height a h ((by omega)) (top3)

theorem affine_beta_complete094 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (0 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known094 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches094 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart3 := separated (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known094])
  have apart4 := separated (Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known094])
  have apart6 := separated (Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known094])
  have apart13 := separated (Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known094])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n094_o0 a jx jy (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart3).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n094_o1 a jx jy (apart4).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known097 a)), by simp [affine_beta_branches094], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n094_o2 a jx jy (apart4).1 (ha) (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart3).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n094_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1 (ha) (apart4).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (1 : Int) (1 : Int) a) (Cross.mk (0 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n094_o4 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart13).2.2.1 (apart13).2.1 (apart3).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_beta_known095 a)), by simp [affine_beta_branches094], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n094_o5 a jx jy (apart3).2.2.1 (apart13).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (0 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n094_o6 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart3).1 (apart6).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known096 a)), by simp [affine_beta_branches094], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n094_o7 a jx jy (apart4).1 (ha) (apart13).2.2.1 (apart3).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative095 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known095 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known095, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_cover0_095 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known095 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n095_wall0 a ((by simpa only [KnownContains, affine_beta_known095, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover1_095 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known095 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n095_wall1 a ((by simpa only [KnownContains, affine_beta_known095, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover2_095 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known095 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n095_wall2 a ((by simpa only [KnownContains, affine_beta_known095, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover3_095 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known095 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n095_wall3 a (ha) ((by simpa only [KnownContains, affine_beta_known095, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover4_095 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known095 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(4 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n095_wall4 a ((by simpa only [KnownContains, affine_beta_known095, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover5_095 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known095 a) ((1 : Int)+(0 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n095_wall5 a ((by simpa only [KnownContains, affine_beta_known095, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover6_095 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known095 a) ((1 : Int)+(1 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n095_wall6 a (ha) ((by simpa only [KnownContains, affine_beta_known095, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover7_095 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known095 a) ((1 : Int)+(2 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n095_wall7 a (ha) ((by simpa only [KnownContains, affine_beta_known095, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover8_095 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known095 a) ((1 : Int)+(3 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n095_wall8 a ((by simpa only [KnownContains, affine_beta_known095, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover9_095 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known095 a) ((1 : Int)+(4 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n095_wall9 a ((by simpa only [KnownContains, affine_beta_known095, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover10_095 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known095 a) ((1 : Int)+(5 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n095_wall10 a ((by simpa only [KnownContains, affine_beta_known095, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover11_095 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known095 a) ((1 : Int)+(0 : Int)) ((3 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n095_wall11 a ((by simpa only [KnownContains, affine_beta_known095, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_leaf095 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known095 a)) B) : Transition world h .beta B := by
  apply replay_affine_leaf world h .beta (affine_beta_known095 a) .beta (1 : Int) (3 : Int) (affine_beta_nonnegative095 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .beta x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7 | m8 | m9 | m10
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover0_095 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover1_095 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover2_095 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover3_095 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(4 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover4_095 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(0 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover5_095 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover6_095 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(2 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover7_095 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(3 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover8_095 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(4 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover9_095 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(5 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover10_095 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.beta_n095_dirty a x y (hy) (hx) ((by simpa only [KnownContains, affine_beta_known095, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) ((by simpa only [Extra,or_and_right,and_or_left,or_assoc,and_assoc] using notExtra))
    · intro extra
      have mem := (mem_extraCells .beta (x-(1 : Int)) (y-(3 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem
      have ex : x=((1 : Int)+(0 : Int)) := by omega
      have ey : y=((3 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover11_095 a ha

theorem affine_beta_nonnegative096 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known096 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known096, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_cover0_096 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known096 a) ((1 : Int)+(0 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n096_wall0 a ((by simpa only [KnownContains, affine_beta_known096, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover1_096 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known096 a) ((1 : Int)+(1 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n096_wall1 a ((by simpa only [KnownContains, affine_beta_known096, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover2_096 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known096 a) ((1 : Int)+(2 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n096_wall2 a ((by simpa only [KnownContains, affine_beta_known096, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover3_096 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known096 a) ((1 : Int)+(3 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n096_wall3 a ((by simpa only [KnownContains, affine_beta_known096, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover4_096 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known096 a) ((1 : Int)+(4 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n096_wall4 a (ha) ((by simpa only [KnownContains, affine_beta_known096, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover5_096 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known096 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n096_wall5 a (ha) ((by simpa only [KnownContains, affine_beta_known096, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover6_096 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known096 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n096_wall6 a ((by simpa only [KnownContains, affine_beta_known096, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover7_096 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known096 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n096_wall7 a (ha) ((by simpa only [KnownContains, affine_beta_known096, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover8_096 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known096 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n096_wall8 a (ha) ((by simpa only [KnownContains, affine_beta_known096, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover9_096 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known096 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(4 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n096_wall9 a ((by simpa only [KnownContains, affine_beta_known096, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover10_096 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known096 a) ((1 : Int)+(-1 : Int)) ((3 : Int)+(5 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n096_wall10 a (ha) ((by simpa only [KnownContains, affine_beta_known096, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover11_096 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known096 a) ((1 : Int)+(0 : Int)) ((3 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n096_wall11 a ((by simpa only [KnownContains, affine_beta_known096, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover12_096 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known096 a) ((1 : Int)+(0 : Int)) ((3 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n096_wall12 a ((by simpa only [KnownContains, affine_beta_known096, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_leaf096 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known096 a)) B) : Transition world h .beta B := by
  apply replay_affine_leaf world h .beta (affine_beta_known096 a) .gammaTranspose (1 : Int) (3 : Int) (affine_beta_nonnegative096 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .gammaTranspose x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7 | m8 | m9 | m10
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover5_096 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover6_096 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover7_096 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover8_096 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(4 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover9_096 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(5 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover10_096 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(0 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover0_096 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover1_096 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(2 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover2_096 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(3 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover3_096 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(4 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover4_096 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.beta_n096_dirty a x y ((by simpa only [KnownContains, affine_beta_known096, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) ((by simpa only [Extra,or_and_right,and_or_left,or_assoc,and_assoc] using notExtra)) (hy) (hx)
    · intro extra
      have mem := (mem_extraCells .gammaTranspose (x-(1 : Int)) (y-(3 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem
      rcases mem with e0 | e1
      · have ex : x=((1 : Int)+(0 : Int)) := by omega
        have ey : y=((3 : Int)+(0 : Int)) := by omega
        rw [ex,ey]
        exact affine_beta_cover11_096 a ha
      · have ex : x=((1 : Int)+(0 : Int)) := by omega
        have ey : y=((3 : Int)+(1 : Int)) := by omega
        rw [ex,ey]
        exact affine_beta_cover12_096 a ha

theorem affine_beta_nonnegative097 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known097 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known097, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty097 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known097 a) (1 : Int) (4 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n097_empty a (ha) ((by simpa only [KnownContains, affine_beta_known097, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window097 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known097 a)) B) : QueryWindow h (1 : Int) (4 : Int) := by
  have top4 := known_top_below state (affine_beta_nonnegative097 a ha) (t := (Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known097])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n097_height a h ((by omega)) (top4)

theorem affine_beta_complete097 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (4 : Int))
    (separated : ∀ u, u ∈ affine_beta_known097 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches097 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known097])
  have apart13 := separated (Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known097])
  have apart15 := separated (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known097])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n097_o0 a jx jy (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known106 a)), by simp [affine_beta_branches097], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n097_o1 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.2 (apart15).2.2.1 (apart15).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n097_o2 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known108 a)), by simp [affine_beta_branches097], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a (1 : Int) (1 : Int)) (Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n097_o3 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart13).2.2.2
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (4 : Int) (0 : Int) a (1 : Int) (1 : Int)) (knownCells (affine_beta_known098 a)), by simp [affine_beta_branches097], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n097_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1 (apart15).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n097_o5 a jx jy (apart15).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known109 a)), by simp [affine_beta_branches097], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n097_o6 a jx jy (apart15).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (1 : Int) (1 : Int)) (Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n097_o7 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart15).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)) (knownCells (affine_beta_known099 a)), by simp [affine_beta_branches097], (same_eq m0).symm⟩

theorem affine_beta_nonnegative098 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known098 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known098, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_cover0_098 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known098 a) ((3 : Int)+(-1 : Int)) ((3 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n098_wall0 a ((by simpa only [KnownContains, affine_beta_known098, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover1_098 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known098 a) ((3 : Int)+(-1 : Int)) ((3 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n098_wall1 a ((by simpa only [KnownContains, affine_beta_known098, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover2_098 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known098 a) ((3 : Int)+(-1 : Int)) ((3 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n098_wall2 a ((by simpa only [KnownContains, affine_beta_known098, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover3_098 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known098 a) ((3 : Int)+(-1 : Int)) ((3 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n098_wall3 a ((by simpa only [KnownContains, affine_beta_known098, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover4_098 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known098 a) ((3 : Int)+(0 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n098_wall4 a ((by simpa only [KnownContains, affine_beta_known098, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover5_098 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known098 a) ((3 : Int)+(1 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n098_wall5 a ((by simpa only [KnownContains, affine_beta_known098, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover6_098 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known098 a) ((3 : Int)+(2 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n098_wall6 a (ha) ((by simpa only [KnownContains, affine_beta_known098, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover7_098 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known098 a) ((3 : Int)+(3 : Int)) ((3 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n098_wall7 a (ha) ((by simpa only [KnownContains, affine_beta_known098, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_leaf098 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known098 a)) B) : Transition world h .beta B := by
  apply replay_affine_leaf world h .beta (affine_beta_known098 a) .alpha (3 : Int) (3 : Int) (affine_beta_nonnegative098 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .alpha x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7
    · have ex : (3 : Int)+x=((3 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover0_098 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover1_098 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover2_098 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(-1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover3_098 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(0 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover4_098 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(1 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover5_098 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(2 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover6_098 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(3 : Int)) := by omega
      have ey : (3 : Int)+y=((3 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover7_098 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.beta_n098_dirty a x y ((by simpa only [KnownContains, affine_beta_known098, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (hy) (hx)
    · intro extra
      have mem := (mem_extraCells .alpha (x-(3 : Int)) (y-(3 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem

theorem affine_beta_nonnegative099 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known099 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known099, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty099 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known099 a) (1 : Int) (5 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n099_empty a (ha) ((by simpa only [KnownContains, affine_beta_known099, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window099 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known099 a)) B) : QueryWindow h (1 : Int) (5 : Int) := by
  have top15 := known_top_below state (affine_beta_nonnegative099 a ha) (t := (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a)) (by simp [affine_beta_known099])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n099_height a h (ha) ((by omega)) (top15)

theorem affine_beta_complete099 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (5 : Int))
    (separated : ∀ u, u ∈ affine_beta_known099 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches099 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known099])
  have apart13 := separated (Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known099])
  have apart15 := separated (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known099])
  have apart16 := separated (Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known099])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (2 : Int) (5 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n099_o0 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (5 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known100 a)), by simp [affine_beta_branches099], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n099_o1 a jx jy (apart13).2.2.2 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (apart15).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n099_o2 a jx jy (apart15).2.1 (apart16).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n099_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.2.1 (ha) (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n099_o4 a jx jy (apart15).2.2.1 (ha) (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((1 : Int) + a) (5 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n099_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (5 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known103 a)), by simp [affine_beta_branches099], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n099_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.2 (apart15).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n099_o7 a jx jy (apart15).2.1 (ha) (apart16).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative100 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known100 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known100, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty100 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known100 a) (3 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n100_empty a ((by simpa only [KnownContains, affine_beta_known100, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window100 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known100 a)) B) : QueryWindow h (3 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative100 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known100])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n100_height a h ((by omega)) (top3)

theorem affine_beta_complete100 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known100 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches100 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart9 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known100])
  have apart10 := separated (Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known100])
  have apart13 := separated (Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known100])
  have apart16 := separated (Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known100])
  have apart17 := separated (Cross.mk (2 : Int) (5 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known100])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n100_o0 a jx jy (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1 (ha) (apart16).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n100_o1 a jx jy (apart9).2.2.1 (ha) (apart17).2.2.1 (apart16).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n100_o2 a jx jy (apart16).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known101 a)), by simp [affine_beta_branches100], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n100_o3 a jx jy (apart16).2.1 (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n100_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (apart17).2.2.1 (apart10).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n100_o5 a jx jy (apart16).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known102 a)), by simp [affine_beta_branches100], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n100_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart17).2.2.1 (apart13).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n100_o7 a jx jy (apart16).2.1 (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))

theorem affine_beta_nonnegative101 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known101 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known101, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty101 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known101 a) (1 : Int) (6 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n101_empty a (ha) ((by simpa only [KnownContains, affine_beta_known101, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window101 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known101 a)) B) : QueryWindow h (1 : Int) (6 : Int) := by
  have top17 := known_top_below state (affine_beta_nonnegative101 a ha) (t := (Cross.mk (2 : Int) (5 : Int) a (1 : Int) (1 : Int) (0 : Int))) (by simp [affine_beta_known101])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n101_height a h (top17) ((by omega))

theorem affine_beta_complete101 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (6 : Int))
    (separated : ∀ u, u ∈ affine_beta_known101 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches101 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart13 := separated (Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known101])
  have apart15 := separated (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known101])
  have apart17 := separated (Cross.mk (2 : Int) (5 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known101])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n101_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart17).2.2.2 (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n101_o1 a jx jy (ha) (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.2 (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n101_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (ha) (apart17).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n101_o3 a jx jy (apart15).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart17).2.2.2 (apart13).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n101_o4 a jx jy (ha) (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart17).2.1 (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n101_o5 a jx jy (ha) (apart17).2.1 (apart15).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n101_o6 a jx jy (apart15).2.2.1 (apart13).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n101_o7 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (apart17).2.2.2)

theorem affine_beta_nonnegative102 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known102 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known102, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty102 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known102 a) (1 : Int) (6 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n102_empty a ((by simpa only [KnownContains, affine_beta_known102, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window102 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known102 a)) B) : QueryWindow h (1 : Int) (6 : Int) := by
  have top17 := known_top_below state (affine_beta_nonnegative102 a ha) (t := (Cross.mk (2 : Int) (5 : Int) a (1 : Int) (1 : Int) (0 : Int))) (by simp [affine_beta_known102])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n102_height a h (top17) ((by omega))

theorem affine_beta_complete102 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (6 : Int))
    (separated : ∀ u, u ∈ affine_beta_known102 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches102 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known102])
  have apart15 := separated (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known102])
  have apart17 := separated (Cross.mk (2 : Int) (5 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known102])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n102_o0 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart17).2.1 (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n102_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart17).2.2.1 (apart15).2.1 (ha) (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n102_o2 a jx jy (ha) (apart15).2.1 (apart17).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n102_o3 a jx jy (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart17).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n102_o4 a jx jy (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart17).2.1 (apart15).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n102_o5 a jx jy (apart17).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n102_o6 a jx jy (apart12).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n102_o7 a jx jy (apart17).2.1 (ha) (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative103 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known103 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known103, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty103 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known103 a) (3 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n103_empty a ((by simpa only [KnownContains, affine_beta_known103, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window103 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known103 a)) B) : QueryWindow h (3 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative103 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known103])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n103_height a h ((by omega)) (top3)

theorem affine_beta_complete103 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known103 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches103 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart9 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known103])
  have apart10 := separated (Cross.mk (4 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known103])
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known103])
  have apart13 := separated (Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known103])
  have apart16 := separated (Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known103])
  have apart17 := separated (Cross.mk ((1 : Int) + a) (5 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known103])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n103_o0 a jx jy (apart13).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.1 (apart16).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n103_o1 a jx jy (ha) (apart9).2.2.1 (apart16).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart17).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n103_o2 a jx jy (apart16).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known104 a)), by simp [affine_beta_branches103], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n103_o3 a jx jy (apart17).2.2.1 (ha) (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n103_o4 a jx jy (apart17).2.2.1 (apart10).2.2.1 (apart9).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n103_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart16).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((3 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known105 a)), by simp [affine_beta_branches103], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n103_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1 (apart16).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n103_o7 a jx jy (ha) (apart16).2.1 (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative104 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known104 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known104, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty104 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known104 a) (1 : Int) (6 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n104_empty a (ha) ((by simpa only [KnownContains, affine_beta_known104, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window104 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known104 a)) B) : QueryWindow h (1 : Int) (6 : Int) := by
  have top17 := known_top_below state (affine_beta_nonnegative104 a ha) (t := (Cross.mk ((1 : Int) + a) (5 : Int) (1 : Int) (1 : Int) a (0 : Int))) (by simp [affine_beta_known104])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n104_height a h (top17) ((by omega))

theorem affine_beta_complete104 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (6 : Int))
    (separated : ∀ u, u ∈ affine_beta_known104 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches104 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known104])
  have apart15 := separated (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known104])
  have apart16 := separated (Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known104])
  have apart17 := separated (Cross.mk ((1 : Int) + a) (5 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known104])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n104_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (ha) (apart17).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n104_o1 a jx jy (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n104_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart17).2.2.1 (apart15).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n104_o3 a jx jy (apart17).2.2.1 (apart15).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n104_o4 a jx jy (ha) (apart15).2.2.1 (apart16).2.2.2 (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n104_o5 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart17).2.2.2 (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n104_o6 a jx jy (apart16).2.2.1 (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n104_o7 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart17).2.1 (apart15).2.1)

theorem affine_beta_nonnegative105 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known105 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known105, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty105 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known105 a) (1 : Int) (6 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n105_empty a (ha) ((by simpa only [KnownContains, affine_beta_known105, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window105 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known105 a)) B) : QueryWindow h (1 : Int) (6 : Int) := by
  have top17 := known_top_below state (affine_beta_nonnegative105 a ha) (t := (Cross.mk ((1 : Int) + a) (5 : Int) (1 : Int) (1 : Int) a (0 : Int))) (by simp [affine_beta_known105])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n105_height a h ((by omega)) (top17)

theorem affine_beta_complete105 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (6 : Int))
    (separated : ∀ u, u ∈ affine_beta_known105 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches105 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known105])
  have apart13 := separated (Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known105])
  have apart15 := separated (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known105])
  have apart16 := separated (Cross.mk (2 : Int) (4 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known105])
  have apart17 := separated (Cross.mk ((1 : Int) + a) (5 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known105])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n105_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart17).2.1 (apart15).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n105_o1 a jx jy (apart15).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.2 (ha) (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n105_o2 a jx jy (apart17).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n105_o3 a jx jy (apart17).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n105_o4 a jx jy (apart15).2.2.1 (ha) (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n105_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart17).2.2.2 (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n105_o6 a jx jy (ha) (apart16).2.2.1 (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n105_o7 a jx jy (apart17).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (ha))

theorem affine_beta_nonnegative106 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known106 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known106, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty106 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known106 a) (2 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n106_empty a ((by simpa only [KnownContains, affine_beta_known106, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window106 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known106 a)) B) : QueryWindow h (2 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative106 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known106])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n106_height a h (top3) ((by omega))

theorem affine_beta_complete106 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known106 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches106 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known106])
  have apart9 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known106])
  have apart13 := separated (Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known106])
  have apart16 := separated (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known106])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n106_o0 a jx jy (ha) (apart16).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n106_o1 a jx jy (apart8).2.2.1 (apart16).2.2.2 (apart13).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((2 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n106_o2 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart16).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1 (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((2 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known107 a)), by simp [affine_beta_branches106], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n106_o3 a jx jy (apart8).2.2.1 (apart16).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n106_o4 a jx jy (apart13).2.1 (ha) (apart16).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n106_o5 a jx jy (ha) (apart16).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n106_o6 a jx jy (apart13).2.1 (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.2.2 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n106_o7 a jx jy (ha) (apart13).2.1 (apart13).2.2.1 (apart16).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative107 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known107 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known107, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty107 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known107 a) (1 : Int) (5 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n107_empty a ((by simpa only [KnownContains, affine_beta_known107, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window107 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known107 a)) B) : QueryWindow h (1 : Int) (5 : Int) := by
  have top16 := known_top_below state (affine_beta_nonnegative107 a ha) (t := (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int))) (by simp [affine_beta_known107])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n107_height a h ((by omega)) (top16)

theorem affine_beta_complete107 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (5 : Int))
    (separated : ∀ u, u ∈ affine_beta_known107 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches107 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart13 := separated (Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known107])
  have apart15 := separated (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known107])
  have apart16 := separated (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known107])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n107_o0 a jx jy (apart15).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n107_o1 a jx jy (ha) (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.2 (apart13).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n107_o2 a jx jy (apart16).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n107_o3 a jx jy (ha) (apart13).2.2.2 (apart16).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n107_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (apart15).2.1 (apart16).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n107_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.2.2 (apart16).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n107_o6 a jx jy (apart13).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n107_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.1 (apart16).2.2.1)

theorem affine_beta_nonnegative108 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known108 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known108, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty108 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known108 a) (2 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n108_empty a ((by simpa only [KnownContains, affine_beta_known108, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window108 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known108 a)) B) : QueryWindow h (2 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative108 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known108])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n108_height a h ((by omega)) (top3)

theorem affine_beta_complete108 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known108 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches108 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known108])
  have apart13 := separated (Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known108])
  have apart15 := separated (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known108])
  have apart16 := separated (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known108])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n108_o0 a jx jy (apart16).2.1 (apart13).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n108_o1 a jx jy (apart16).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n108_o2 a jx jy (apart15).2.1 (apart16).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n108_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1 (apart16).1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n108_o4 a jx jy (apart16).2.2.1 (apart13).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n108_o5 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1 (apart16).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n108_o6 a jx jy (apart16).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n108_o7 a jx jy (ha) (apart16).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1)

theorem affine_beta_nonnegative109 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known109 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known109, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty109 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known109 a) (2 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n109_empty a ((by simpa only [KnownContains, affine_beta_known109, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window109 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known109 a)) B) : QueryWindow h (2 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative109 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known109])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n109_height a h (top3) ((by omega))

theorem affine_beta_complete109 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known109 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches109 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known109])
  have apart13 := separated (Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known109])
  have apart15 := separated (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known109])
  have apart16 := separated (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known109])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n109_o0 a jx jy (apart13).2.1 (apart16).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n109_o1 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.2.1 (apart8).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((2 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n109_o2 a jx jy (apart13).2.1 (ha) (apart15).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((2 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known110 a)), by simp [affine_beta_branches109], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n109_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart16).1 (apart13).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n109_o4 a jx jy (apart13).2.1 (apart16).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n109_o5 a jx jy (apart13).2.1 (apart16).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n109_o6 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (apart16).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n109_o7 a jx jy (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart16).2.1 (apart13).2.2.1)

theorem affine_beta_nonnegative110 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known110 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known110, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty110 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known110 a) (1 : Int) (5 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n110_empty a (ha) ((by simpa only [KnownContains, affine_beta_known110, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window110 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known110 a)) B) : QueryWindow h (1 : Int) (5 : Int) := by
  have top16 := known_top_below state (affine_beta_nonnegative110 a ha) (t := (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int))) (by simp [affine_beta_known110])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n110_height a h ((by omega)) (top16)

theorem affine_beta_complete110 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (5 : Int))
    (separated : ∀ u, u ∈ affine_beta_known110 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches110 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known110])
  have apart13 := separated (Cross.mk (1 : Int) (2 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known110])
  have apart15 := separated (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known110])
  have apart16 := separated (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known110])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n110_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.1 (apart15).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n110_o1 a jx jy (apart15).2.2.1 (apart15).2.2.2 (ha) (apart13).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n110_o2 a jx jy (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart16).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n110_o3 a jx jy (apart15).2.1 (apart16).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n110_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (ha) (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n110_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (ha) (apart16).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n110_o6 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (apart13).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n110_o7 a jx jy (ha) (apart16).2.1 (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative111 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known111 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known111, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty111 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known111 a) (2 : Int) (0 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n111_empty a ((by simpa only [KnownContains, affine_beta_known111, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window111 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known111 a)) B) : QueryWindow h (2 : Int) (0 : Int) := by
  have top0 := known_top_below state (affine_beta_nonnegative111 a ha) (t := (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known111])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n111_height a h (top0) ((by omega))

theorem affine_beta_complete111 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (0 : Int))
    (separated : ∀ u, u ∈ affine_beta_known111 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches111 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart6 := separated (Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known111])
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known111])
  have apart9 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known111])
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known111])
  have apart13 := separated (Cross.mk a (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known111])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n111_o0 a jx jy (apart12).2.2.1 (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart6).1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n111_o1 a jx jy (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n111_o2 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known112 a)), by simp [affine_beta_branches111], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n111_o3 a jx jy (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (ha) (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n111_o4 a jx jy (apart13).2.2.1 (apart8).2.2.1 (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n111_o5 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known118 a)), by simp [affine_beta_branches111], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n111_o6 a jx jy (apart8).2.2.1 (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n111_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart9).2.2.1 (apart12).2.1)

theorem affine_beta_nonnegative112 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known112 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known112, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty112 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known112 a) (0 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n112_empty a (ha) ((by simpa only [KnownContains, affine_beta_known112, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window112 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known112 a)) B) : QueryWindow h (0 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative112 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known112])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n112_height a h ((by omega)) (top3)

theorem affine_beta_complete112 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (0 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known112 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches112 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known112])
  have apart3 := separated (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known112])
  have apart4 := separated (Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known112])
  have apart13 := separated (Cross.mk a (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known112])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n112_o0 a jx jy (apart13).2.1 (ha) (apart3).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n112_o1 a jx jy (ha) (apart13).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart3).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known117 a)), by simp [affine_beta_branches112], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n112_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1 (apart4).1 (apart3).1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n112_o3 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1 (apart4).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (1 : Int) (1 : Int) a) (Cross.mk (0 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n112_o4 a jx jy (ha) (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_beta_known113 a)), by simp [affine_beta_branches112], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n112_o5 a jx jy (ha) (apart2).1 (apart3).1 (apart13).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (0 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n112_o6 a jx jy (apart3).1 (apart13).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known116 a)), by simp [affine_beta_branches112], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n112_o7 a jx jy (apart3).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1 (ha) (apart4).1)

theorem affine_beta_nonnegative113 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known113 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known113, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty113 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known113 a) (1 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n113_empty a ((by simpa only [KnownContains, affine_beta_known113, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window113 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known113 a)) B) : QueryWindow h (1 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative113 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known113])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n113_height a h ((by omega)) (top3)

theorem affine_beta_complete113 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known113 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches113 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart3 := separated (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known113])
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known113])
  have apart13 := separated (Cross.mk a (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known113])
  have apart15 := separated (Cross.mk (0 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_beta_known113])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n113_o0 a jx jy (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (1 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n113_o1 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known115 a)), by simp [affine_beta_branches113], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n113_o2 a jx jy (apart15).2.1 (ha) (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n113_o3 a jx jy (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n113_o4 a jx jy (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n113_o5 a jx jy (apart13).2.1 (apart13).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart3).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (1 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n113_o6 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart13).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known114 a)), by simp [affine_beta_branches113], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n113_o7 a jx jy (apart15).2.1 (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))

theorem affine_beta_nonnegative114 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known114 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known114, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty114 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known114 a) (2 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n114_empty a ((by simpa only [KnownContains, affine_beta_known114, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window114 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known114 a)) B) : QueryWindow h (2 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative114 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known114])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n114_height a h (top3) ((by omega))

theorem affine_beta_complete114 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known114 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches114 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart3 := separated (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known114])
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known114])
  have apart13 := separated (Cross.mk a (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known114])
  have apart14 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known114])
  have apart16 := separated (Cross.mk (1 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known114])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n114_o0 a jx jy (apart3).1 (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n114_o1 a jx jy (apart8).2.2.1 (apart16).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n114_o2 a jx jy (apart16).2.2.1 (ha) (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n114_o3 a jx jy (apart13).2.2.1 (apart16).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n114_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart16).2.1 (apart14).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n114_o5 a jx jy (apart13).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1 (ha) (apart3).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n114_o6 a jx jy (apart16).2.2.1 (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n114_o7 a jx jy (apart3).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.2.1 (ha) (apart13).2.1)

theorem affine_beta_nonnegative115 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known115 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known115, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty115 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known115 a) (2 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n115_empty a ((by simpa only [KnownContains, affine_beta_known115, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window115 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known115 a)) B) : QueryWindow h (2 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative115 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known115])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n115_height a h ((by omega)) (top3)

theorem affine_beta_complete115 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known115 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches115 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart3 := separated (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known115])
  have apart13 := separated (Cross.mk a (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known115])
  have apart14 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known115])
  have apart15 := separated (Cross.mk (0 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_beta_known115])
  have apart16 := separated (Cross.mk (1 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known115])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n115_o0 a jx jy (apart13).2.1 (apart16).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n115_o1 a jx jy (ha) (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n115_o2 a jx jy (apart15).2.1 (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n115_o3 a jx jy (ha) (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n115_o4 a jx jy (ha) (apart14).2.2.1 (apart16).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n115_o5 a jx jy (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart3).1 (ha) (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n115_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1 (apart16).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n115_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1 (ha) (apart16).2.1)

theorem affine_beta_nonnegative116 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known116 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known116, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty116 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known116 a) (1 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n116_empty a (ha) ((by simpa only [KnownContains, affine_beta_known116, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window116 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known116 a)) B) : QueryWindow h (1 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative116 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known116])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n116_height a h ((by omega)) (top3)

theorem affine_beta_complete116 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known116 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches116 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart3 := separated (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known116])
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known116])
  have apart13 := separated (Cross.mk a (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known116])
  have apart15 := separated (Cross.mk (0 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known116])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n116_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (ha) (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n116_o1 a jx jy (apart15).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n116_o2 a jx jy (apart13).2.2.1 (apart15).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n116_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1 (ha) (apart15).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n116_o4 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1 (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n116_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1 (ha) (apart13).2.2.1 (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n116_o6 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (apart12).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n116_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (ha) (apart3).1 (apart13).2.1)

theorem affine_beta_nonnegative117 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known117 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known117, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty117 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known117 a) (1 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n117_empty a (ha) ((by simpa only [KnownContains, affine_beta_known117, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window117 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known117 a)) B) : QueryWindow h (1 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative117 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known117])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n117_height a h ((by omega)) (top3)

theorem affine_beta_complete117 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known117 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches117 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart3 := separated (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known117])
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known117])
  have apart13 := separated (Cross.mk a (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known117])
  have apart15 := separated (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known117])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n117_o0 a jx jy (apart13).2.1 (apart3).1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n117_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (ha) (apart15).2.2.2 (apart12).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n117_o2 a jx jy (apart13).2.2.1 (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n117_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.1 (apart13).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n117_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.1 (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n117_o5 a jx jy (ha) (apart13).2.1 (apart15).2.1 (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n117_o6 a jx jy (ha) (apart12).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n117_o7 a jx jy (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.1)

theorem affine_beta_nonnegative118 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known118 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known118, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty118 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known118 a) (0 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n118_empty a ((by simpa only [KnownContains, affine_beta_known118, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window118 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known118 a)) B) : QueryWindow h (0 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative118 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known118])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n118_height a h (top3) ((by omega))

theorem affine_beta_complete118 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (0 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known118 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches118 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known118])
  have apart3 := separated (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known118])
  have apart4 := separated (Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known118])
  have apart13 := separated (Cross.mk a (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known118])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n118_o0 a jx jy (ha) (apart3).1 (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n118_o1 a jx jy (apart13).2.2.1 (apart3).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known123 a)), by simp [affine_beta_branches118], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n118_o2 a jx jy (apart2).2.2.1 (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart4).1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n118_o3 a jx jy (apart4).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (1 : Int) (1 : Int) a) (Cross.mk (0 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n118_o4 a jx jy (apart13).2.2.1 (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_beta_known119 a)), by simp [affine_beta_branches118], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n118_o5 a jx jy (apart3).1 (apart13).2.2.2 (apart2).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (0 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n118_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart13).2.2.1 (ha) (apart3).1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known122 a)), by simp [affine_beta_branches118], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n118_o7 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1 (apart4).1 (apart3).1)

theorem affine_beta_nonnegative119 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known119 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known119, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty119 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known119 a) (1 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n119_empty a ((by simpa only [KnownContains, affine_beta_known119, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window119 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known119 a)) B) : QueryWindow h (1 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative119 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known119])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n119_height a h ((by omega)) (top3)

theorem affine_beta_complete119 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known119 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches119 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known119])
  have apart13 := separated (Cross.mk a (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known119])
  have apart15 := separated (Cross.mk (0 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_beta_known119])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n119_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (ha) (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (1 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n119_o1 a jx jy (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known121 a)), by simp [affine_beta_branches119], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n119_o2 a jx jy (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n119_o3 a jx jy (apart13).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n119_o4 a jx jy (apart15).2.1 (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n119_o5 a jx jy (apart15).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).1 (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (1 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n119_o6 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1 (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known120 a)), by simp [affine_beta_branches119], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n119_o7 a jx jy (apart15).2.1 (ha) (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative120 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known120 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known120, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty120 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known120 a) (2 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n120_empty a ((by simpa only [KnownContains, affine_beta_known120, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window120 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known120 a)) B) : QueryWindow h (2 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative120 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known120])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n120_height a h (top3) ((by omega))

theorem affine_beta_complete120 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known120 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches120 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart3 := separated (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known120])
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known120])
  have apart13 := separated (Cross.mk a (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known120])
  have apart14 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known120])
  have apart16 := separated (Cross.mk (1 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known120])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n120_o0 a jx jy (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart16).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n120_o1 a jx jy (apart13).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart16).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n120_o2 a jx jy (ha) (apart16).2.2.1 (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n120_o3 a jx jy (apart16).2.2.1 (ha) (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n120_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart14).2.2.1 (apart16).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n120_o5 a jx jy (apart13).2.2.1 (ha) (apart3).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n120_o6 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (apart16).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n120_o7 a jx jy (ha) (apart3).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.2.1 (apart13).2.1)

theorem affine_beta_nonnegative121 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known121 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known121, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty121 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known121 a) (2 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n121_empty a (ha) ((by simpa only [KnownContains, affine_beta_known121, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window121 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known121 a)) B) : QueryWindow h (2 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative121 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known121])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n121_height a h (top3) ((by omega))

theorem affine_beta_complete121 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known121 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches121 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known121])
  have apart13 := separated (Cross.mk a (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known121])
  have apart14 := separated (Cross.mk ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known121])
  have apart15 := separated (Cross.mk (0 : Int) ((3 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_beta_known121])
  have apart16 := separated (Cross.mk (1 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known121])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n121_o0 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1 (apart16).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n121_o1 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).1 (apart13).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n121_o2 a jx jy (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n121_o3 a jx jy (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart16).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n121_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.1 (ha) (apart16).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n121_o5 a jx jy (ha) (apart16).2.1 (apart2).1 (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n121_o6 a jx jy (ha) (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n121_o7 a jx jy (apart13).2.1 (ha) (apart16).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative122 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known122 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known122, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty122 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known122 a) (1 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n122_empty a ((by simpa only [KnownContains, affine_beta_known122, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window122 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known122 a)) B) : QueryWindow h (1 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative122 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known122])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n122_height a h ((by omega)) (top3)

theorem affine_beta_complete122 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known122 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches122 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known122])
  have apart13 := separated (Cross.mk a (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known122])
  have apart15 := separated (Cross.mk (0 : Int) (4 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known122])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n122_o0 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n122_o1 a jx jy (apart12).2.2.2 (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n122_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (ha) (apart13).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n122_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).1 (apart13).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n122_o4 a jx jy (ha) (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n122_o5 a jx jy (ha) (apart15).2.1 (apart13).2.1 (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n122_o6 a jx jy (ha) (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n122_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.1 (apart15).2.1)

theorem affine_beta_nonnegative123 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known123 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known123, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty123 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known123 a) (1 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n123_empty a (ha) ((by simpa only [KnownContains, affine_beta_known123, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window123 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known123 a)) B) : QueryWindow h (1 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative123 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known123])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n123_height a h ((by omega)) (top3)

theorem affine_beta_complete123 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known123 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches123 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart3 := separated (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known123])
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known123])
  have apart13 := separated (Cross.mk a (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known123])
  have apart15 := separated (Cross.mk (0 : Int) ((3 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known123])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n123_o0 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (apart13).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n123_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (apart12).2.2.2 (apart15).2.2.2 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n123_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1 (ha) (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n123_o3 a jx jy (apart13).2.2.1 (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n123_o4 a jx jy (ha) (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n123_o5 a jx jy (apart13).1 (apart13).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart3).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n123_o6 a jx jy (apart15).2.2.1 (apart12).2.2.2 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n123_o7 a jx jy (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.1 (ha))

theorem affine_beta_nonnegative124 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known124 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known124, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty124 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known124 a) (1 : Int) (0 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n124_empty a ((by simpa only [KnownContains, affine_beta_known124, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window124 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known124 a)) B) : QueryWindow h (1 : Int) (0 : Int) := by
  have top0 := known_top_below state (affine_beta_nonnegative124 a ha) (t := (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known124])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n124_height a h ((by omega)) (top0)

theorem affine_beta_complete124 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (0 : Int))
    (separated : ∀ u, u ∈ affine_beta_known124 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches124 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart5 := separated (Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known124])
  have apart6 := separated (Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known124])
  have apart7 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known124])
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known124])
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known124])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n124_o0 a jx jy (apart6).1 (ha) (apart7).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n124_o1 a jx jy (apart12).2.2.2 (apart6).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart7).1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n124_o2 a jx jy (apart12).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart6).1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known125 a)), by simp [affine_beta_branches124], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n124_o3 a jx jy (apart12).2.1 (apart8).2.2.1 (ha) (apart7).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n124_o4 a jx jy (apart5).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n124_o5 a jx jy (apart7).2.2.1 (apart12).2.2.2 (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n124_o6 a jx jy (apart7).2.2.1 (apart5).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n124_o7 a jx jy (apart8).2.2.1 (ha) (apart6).1 (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative125 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known125 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known125, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty125 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known125 a) (0 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n125_empty a ((by simpa only [KnownContains, affine_beta_known125, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window125 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known125 a)) B) : QueryWindow h (0 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative125 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known125])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n125_height a h (top2) ((by omega))

theorem affine_beta_complete125 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (0 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known125 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches125 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known125])
  have apart3 := separated (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known125])
  have apart6 := separated (Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known125])
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known125])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n125_o0 a jx jy (apart2).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n125_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart2).1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) (apart12).2.2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known128 a)), by simp [affine_beta_branches125], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n125_o2 a jx jy (apart12).2.1 (apart3).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart2).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n125_o3 a jx jy (ha) (apart2).1 (apart6).2.2.1 (apart3).1 (apart12).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (1 : Int) (1 : Int) a) (Cross.mk (0 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n125_o4 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart12).2.2.1 (apart2).1 (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_beta_known126 a)), by simp [affine_beta_branches125], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n125_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1 (ha) (apart3).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n125_o6 a jx jy (apart12).2.1 (apart6).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart2).1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known127 a)), by simp [affine_beta_branches125], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n125_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.2 (apart3).1 (apart2).1 (ha))

theorem affine_beta_nonnegative126 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known126 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known126, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_cover0_126 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known126 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n126_wall0 a (ha) ((by simpa only [KnownContains, affine_beta_known126, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover1_126 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known126 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n126_wall1 a ((by simpa only [KnownContains, affine_beta_known126, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover2_126 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known126 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n126_wall2 a ((by simpa only [KnownContains, affine_beta_known126, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover3_126 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known126 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n126_wall3 a ((by simpa only [KnownContains, affine_beta_known126, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover4_126 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known126 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(4 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n126_wall4 a (ha) ((by simpa only [KnownContains, affine_beta_known126, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover5_126 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known126 a) ((1 : Int)+(0 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n126_wall5 a ((by simpa only [KnownContains, affine_beta_known126, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover6_126 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known126 a) ((1 : Int)+(1 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n126_wall6 a (ha) ((by simpa only [KnownContains, affine_beta_known126, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover7_126 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known126 a) ((1 : Int)+(2 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n126_wall7 a (ha) ((by simpa only [KnownContains, affine_beta_known126, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover8_126 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known126 a) ((1 : Int)+(3 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n126_wall8 a ((by simpa only [KnownContains, affine_beta_known126, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover9_126 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known126 a) ((1 : Int)+(4 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n126_wall9 a (ha) ((by simpa only [KnownContains, affine_beta_known126, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover10_126 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known126 a) ((1 : Int)+(5 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n126_wall10 a ((by simpa only [KnownContains, affine_beta_known126, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover11_126 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known126 a) ((1 : Int)+(0 : Int)) ((2 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n126_wall11 a ((by simpa only [KnownContains, affine_beta_known126, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_leaf126 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known126 a)) B) : Transition world h .beta B := by
  apply replay_affine_leaf world h .beta (affine_beta_known126 a) .beta (1 : Int) (2 : Int) (affine_beta_nonnegative126 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .beta x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7 | m8 | m9 | m10
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover0_126 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover1_126 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover2_126 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover3_126 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(4 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover4_126 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(0 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover5_126 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover6_126 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(2 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover7_126 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(3 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover8_126 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(4 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover9_126 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(5 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover10_126 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.beta_n126_dirty a x y ((by simpa only [KnownContains, affine_beta_known126, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) ((by simpa only [Extra,or_and_right,and_or_left,or_assoc,and_assoc] using notExtra)) (hy) (hx)
    · intro extra
      have mem := (mem_extraCells .beta (x-(1 : Int)) (y-(2 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem
      have ex : x=((1 : Int)+(0 : Int)) := by omega
      have ey : y=((2 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover11_126 a ha

theorem affine_beta_nonnegative127 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known127 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known127, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_cover0_127 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known127 a) ((1 : Int)+(0 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n127_wall0 a ((by simpa only [KnownContains, affine_beta_known127, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover1_127 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known127 a) ((1 : Int)+(1 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n127_wall1 a (ha) ((by simpa only [KnownContains, affine_beta_known127, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover2_127 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known127 a) ((1 : Int)+(2 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n127_wall2 a (ha) ((by simpa only [KnownContains, affine_beta_known127, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover3_127 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known127 a) ((1 : Int)+(3 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n127_wall3 a (ha) ((by simpa only [KnownContains, affine_beta_known127, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover4_127 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known127 a) ((1 : Int)+(4 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n127_wall4 a (ha) ((by simpa only [KnownContains, affine_beta_known127, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover5_127 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known127 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n127_wall5 a ((by simpa only [KnownContains, affine_beta_known127, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover6_127 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known127 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n127_wall6 a ((by simpa only [KnownContains, affine_beta_known127, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover7_127 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known127 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n127_wall7 a ((by simpa only [KnownContains, affine_beta_known127, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover8_127 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known127 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n127_wall8 a (ha) ((by simpa only [KnownContains, affine_beta_known127, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover9_127 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known127 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(4 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n127_wall9 a ((by simpa only [KnownContains, affine_beta_known127, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover10_127 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known127 a) ((1 : Int)+(-1 : Int)) ((2 : Int)+(5 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n127_wall10 a ((by simpa only [KnownContains, affine_beta_known127, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover11_127 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known127 a) ((1 : Int)+(0 : Int)) ((2 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n127_wall11 a ((by simpa only [KnownContains, affine_beta_known127, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover12_127 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known127 a) ((1 : Int)+(0 : Int)) ((2 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n127_wall12 a ((by simpa only [KnownContains, affine_beta_known127, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_leaf127 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known127 a)) B) : Transition world h .beta B := by
  apply replay_affine_leaf world h .beta (affine_beta_known127 a) .gammaTranspose (1 : Int) (2 : Int) (affine_beta_nonnegative127 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .gammaTranspose x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7 | m8 | m9 | m10
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover5_127 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover6_127 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover7_127 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover8_127 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(4 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover9_127 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(5 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover10_127 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(0 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover0_127 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover1_127 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(2 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover2_127 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(3 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover3_127 a ha
    · have ex : (1 : Int)+x=((1 : Int)+(4 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover4_127 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.beta_n127_dirty a x y (hy) ((by simpa only [KnownContains, affine_beta_known127, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) ((by simpa only [Extra,or_and_right,and_or_left,or_assoc,and_assoc] using notExtra)) (hx)
    · intro extra
      have mem := (mem_extraCells .gammaTranspose (x-(1 : Int)) (y-(2 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem
      rcases mem with e0 | e1
      · have ex : x=((1 : Int)+(0 : Int)) := by omega
        have ey : y=((2 : Int)+(0 : Int)) := by omega
        rw [ex,ey]
        exact affine_beta_cover11_127 a ha
      · have ex : x=((1 : Int)+(0 : Int)) := by omega
        have ey : y=((2 : Int)+(1 : Int)) := by omega
        rw [ex,ey]
        exact affine_beta_cover12_127 a ha

theorem affine_beta_nonnegative128 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known128 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known128, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty128 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known128 a) (1 : Int) (3 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n128_empty a ((by simpa only [KnownContains, affine_beta_known128, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window128 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known128 a)) B) : QueryWindow h (1 : Int) (3 : Int) := by
  have top3 := known_top_below state (affine_beta_nonnegative128 a ha) (t := (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known128])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n128_height a h ((by omega)) (top3)

theorem affine_beta_complete128 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (3 : Int))
    (separated : ∀ u, u ∈ affine_beta_known128 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches128 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known128])
  have apart13 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known128])
  have apart14 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known128])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n128_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart14).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known137 a)), by simp [affine_beta_branches128], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n128_o1 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.1 (apart12).2.2.2 (apart14).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n128_o2 a jx jy (ha) (apart14).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known139 a)), by simp [affine_beta_branches128], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a (1 : Int) (1 : Int)) (Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n128_o3 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart12).2.2.2 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (3 : Int) (0 : Int) a (1 : Int) (1 : Int)) (knownCells (affine_beta_known129 a)), by simp [affine_beta_branches128], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n128_o4 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1 (apart13).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n128_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart14).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known140 a)), by simp [affine_beta_branches128], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n128_o6 a jx jy (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (1 : Int) (1 : Int)) (Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n128_o7 a jx jy (apart14).2.1 (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)) (knownCells (affine_beta_known130 a)), by simp [affine_beta_branches128], (same_eq m0).symm⟩

theorem affine_beta_nonnegative129 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known129 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known129, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_cover0_129 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known129 a) ((3 : Int)+(-1 : Int)) ((2 : Int)+(0 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n129_wall0 a (ha) ((by simpa only [KnownContains, affine_beta_known129, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover1_129 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known129 a) ((3 : Int)+(-1 : Int)) ((2 : Int)+(1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n129_wall1 a ((by simpa only [KnownContains, affine_beta_known129, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing))

theorem affine_beta_cover2_129 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known129 a) ((3 : Int)+(-1 : Int)) ((2 : Int)+(2 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n129_wall2 a ((by simpa only [KnownContains, affine_beta_known129, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover3_129 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known129 a) ((3 : Int)+(-1 : Int)) ((2 : Int)+(3 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n129_wall3 a ((by simpa only [KnownContains, affine_beta_known129, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover4_129 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known129 a) ((3 : Int)+(0 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n129_wall4 a ((by simpa only [KnownContains, affine_beta_known129, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover5_129 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known129 a) ((3 : Int)+(1 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n129_wall5 a ((by simpa only [KnownContains, affine_beta_known129, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover6_129 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known129 a) ((3 : Int)+(2 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n129_wall6 a ((by simpa only [KnownContains, affine_beta_known129, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_cover7_129 (a : Int) (ha : 6≤a) : KnownContains (affine_beta_known129 a) ((3 : Int)+(3 : Int)) ((2 : Int)+(-1 : Int)) := by
  apply Classical.byContradiction
  intro missing
  exact CornerAffineArithmetic.beta_n129_wall7 a ((by simpa only [KnownContains, affine_beta_known129, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using missing)) (ha)

theorem affine_beta_leaf129 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known129 a)) B) : Transition world h .beta B := by
  apply replay_affine_leaf world h .beta (affine_beta_known129 a) .alpha (3 : Int) (2 : Int) (affine_beta_nonnegative129 a ha) ?_ ?_ ?_ B state
  · simp [Progress,potential,zeroRank] <;> omega
  · intro x y wall
    have mem := (mem_wallCells .alpha x y).2 wall
    simp [wallCells,wallHeight,wallWidth,List.range_succ,List.mem_append,Prod.mk.injEq] at mem
    rcases mem with m0 | m1 | m2 | m3 | m4 | m5 | m6 | m7
    · have ex : (3 : Int)+x=((3 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(0 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover0_129 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover1_129 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(2 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover2_129 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(-1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(3 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover3_129 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(0 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover4_129 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(1 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover5_129 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(2 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover6_129 a ha
    · have ex : (3 : Int)+x=((3 : Int)+(3 : Int)) := by omega
      have ey : (2 : Int)+y=((2 : Int)+(-1 : Int)) := by omega
      rw [ex,ey]
      exact affine_beta_cover7_129 a ha
  · intro x y hx hy
    constructor
    · intro claimed
      apply Classical.byContradiction
      intro notExtra
      exact CornerAffineArithmetic.beta_n129_dirty a x y (hy) (hx) ((by simpa only [KnownContains, affine_beta_known129, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))
    · intro extra
      have mem := (mem_extraCells .alpha (x-(3 : Int)) (y-(2 : Int))).2 extra
      simp only [extraCells,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at mem

theorem affine_beta_nonnegative130 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known130 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known130, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty130 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known130 a) (1 : Int) (4 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n130_empty a (ha) ((by simpa only [KnownContains, affine_beta_known130, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window130 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known130 a)) B) : QueryWindow h (1 : Int) (4 : Int) := by
  have top4 := known_top_below state (affine_beta_nonnegative130 a ha) (t := (Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known130])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n130_height a h ((by omega)) (top4)

theorem affine_beta_complete130 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (4 : Int))
    (separated : ∀ u, u ∈ affine_beta_known130 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches130 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known130])
  have apart14 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known130])
  have apart15 := separated (Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known130])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (1 : Int) (1 : Int) (0 : Int)) (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n130_o0 a jx jy (apart14).2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) (knownCells (affine_beta_known131 a)), by simp [affine_beta_branches130], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n130_o1 a jx jy (apart14).2.1 (apart14).2.2.1 (apart12).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n130_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1 (apart15).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n130_o3 a jx jy (apart15).2.2.2 (ha) (apart12).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n130_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.2.1 (apart14).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n130_o5 a jx jy (apart14).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known134 a)), by simp [affine_beta_branches130], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n130_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.1 (apart12).2.2.2 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n130_o7 a jx jy (ha) (apart15).2.2.2 (apart14).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative131 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known131 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known131, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty131 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known131 a) (3 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n131_empty a ((by simpa only [KnownContains, affine_beta_known131, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window131 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known131 a)) B) : QueryWindow h (3 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative131 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known131])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n131_height a h (top2) ((by omega))

theorem affine_beta_complete131 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known131 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches131 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart9 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known131])
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known131])
  have apart13 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known131])
  have apart15 := separated (Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known131])
  have apart16 := separated (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known131])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n131_o0 a jx jy (apart12).1 (ha) (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n131_o1 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart9).2.2.1 (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n131_o2 a jx jy (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known132 a)), by simp [affine_beta_branches131], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n131_o3 a jx jy (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart16).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n131_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.2.1 (apart9).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n131_o5 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (apart12).2.1 (ha)
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known133 a)), by simp [affine_beta_branches131], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n131_o6 a jx jy (ha) (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n131_o7 a jx jy (ha) (apart15).2.1 (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative132 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known132 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known132, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty132 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known132 a) (1 : Int) (5 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n132_empty a (ha) ((by simpa only [KnownContains, affine_beta_known132, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window132 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known132 a)) B) : QueryWindow h (1 : Int) (5 : Int) := by
  have top16 := known_top_below state (affine_beta_nonnegative132 a ha) (t := (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int))) (by simp [affine_beta_known132])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n132_height a h ((by omega)) (top16)

theorem affine_beta_complete132 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (5 : Int))
    (separated : ∀ u, u ∈ affine_beta_known132 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches132 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known132])
  have apart14 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known132])
  have apart16 := separated (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known132])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n132_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1 (ha) (apart16).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n132_o1 a jx jy (apart14).2.2.1 (apart12).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart14).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n132_o2 a jx jy (ha) (apart16).2.1 (apart14).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n132_o3 a jx jy (ha) (apart14).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.2 (apart16).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n132_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1 (ha) (apart16).2.1 (apart14).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n132_o5 a jx jy (apart16).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart14).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n132_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.1 (ha) (apart12).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n132_o7 a jx jy (apart16).2.2.2 (apart14).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative133 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known133 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known133, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty133 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known133 a) (1 : Int) (5 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n133_empty a ((by simpa only [KnownContains, affine_beta_known133, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window133 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known133 a)) B) : QueryWindow h (1 : Int) (5 : Int) := by
  have top16 := known_top_below state (affine_beta_nonnegative133 a ha) (t := (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int))) (by simp [affine_beta_known133])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n133_height a h (top16) ((by omega))

theorem affine_beta_complete133 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (5 : Int))
    (separated : ∀ u, u ∈ affine_beta_known133 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches133 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known133])
  have apart14 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known133])
  have apart16 := separated (Cross.mk (2 : Int) (4 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known133])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n133_o0 a jx jy (apart14).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n133_o1 a jx jy (apart14).2.2.1 (apart14).2.2.2 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n133_o2 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.1 (apart14).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n133_o3 a jx jy (apart14).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.2 (apart16).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n133_o4 a jx jy (apart14).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.1 (ha) (apart16).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n133_o5 a jx jy (ha) (apart16).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n133_o6 a jx jy (apart12).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n133_o7 a jx jy (apart16).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart14).2.1)

theorem affine_beta_nonnegative134 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known134 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known134, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty134 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known134 a) (3 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n134_empty a ((by simpa only [KnownContains, affine_beta_known134, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window134 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known134 a)) B) : QueryWindow h (3 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative134 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known134])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n134_height a h ((by omega)) (top2)

theorem affine_beta_complete134 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (3 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known134 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches134 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart9 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known134])
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known134])
  have apart15 := separated (Cross.mk (2 : Int) (3 : Int) a (0 : Int) (1 : Int) (1 : Int)) (by simp [affine_beta_known134])
  have apart16 := separated (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known134])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n134_o0 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1 (apart12).1 (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n134_o1 a jx jy (ha) (apart12).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n134_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart15).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known135 a)), by simp [affine_beta_branches134], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n134_o3 a jx jy (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n134_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (apart9).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n134_o5 a jx jy (ha) (apart15).2.1 (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((3 : Int) + a) (2 : Int) (1 : Int) (1 : Int) a (0 : Int)) (knownCells (affine_beta_known136 a)), by simp [affine_beta_branches134], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n134_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart16).2.2.1 (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n134_o7 a jx jy (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (ha))

theorem affine_beta_nonnegative135 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known135 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known135, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty135 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known135 a) (1 : Int) (5 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n135_empty a (ha) ((by simpa only [KnownContains, affine_beta_known135, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window135 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known135 a)) B) : QueryWindow h (1 : Int) (5 : Int) := by
  have top16 := known_top_below state (affine_beta_nonnegative135 a ha) (t := (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int))) (by simp [affine_beta_known135])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n135_height a h (top16) ((by omega))

theorem affine_beta_complete135 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (5 : Int))
    (separated : ∀ u, u ∈ affine_beta_known135 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches135 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known135])
  have apart13 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known135])
  have apart14 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known135])
  have apart16 := separated (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known135])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n135_o0 a jx jy (ha) (apart16).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n135_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.1 (apart12).2.2.2 (apart14).2.2.2 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n135_o2 a jx jy (apart14).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n135_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1 (apart16).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n135_o4 a jx jy (apart14).2.2.1 (ha) (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n135_o5 a jx jy (apart16).2.2.2 (apart14).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n135_o6 a jx jy (apart12).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart14).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n135_o7 a jx jy (apart16).2.1 (ha) (apart14).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative136 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known136 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known136, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty136 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known136 a) (1 : Int) (5 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n136_empty a ((by simpa only [KnownContains, affine_beta_known136, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window136 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known136 a)) B) : QueryWindow h (1 : Int) (5 : Int) := by
  have top16 := known_top_below state (affine_beta_nonnegative136 a ha) (t := (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int))) (by simp [affine_beta_known136])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n136_height a h (top16) ((by omega))

theorem affine_beta_complete136 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (5 : Int))
    (separated : ∀ u, u ∈ affine_beta_known136 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches136 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known136])
  have apart13 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known136])
  have apart14 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known136])
  have apart16 := separated (Cross.mk ((1 : Int) + a) (4 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known136])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n136_o0 a jx jy (apart14).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart16).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n136_o1 a jx jy (apart14).2.2.1 (apart14).2.2.2 (apart12).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n136_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1 (apart16).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n136_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart14).2.1 (apart16).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n136_o4 a jx jy (apart13).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n136_o5 a jx jy (ha) (apart16).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n136_o6 a jx jy (apart12).2.2.2 (apart14).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n136_o7 a jx jy (apart16).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart14).2.1)

theorem affine_beta_nonnegative137 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known137 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known137, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty137 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known137 a) (2 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n137_empty a ((by simpa only [KnownContains, affine_beta_known137, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window137 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known137 a)) B) : QueryWindow h (2 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative137 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known137])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n137_height a h (top2) ((by omega))

theorem affine_beta_complete137 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known137 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches137 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known137])
  have apart9 := separated (Cross.mk (3 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known137])
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known137])
  have apart15 := separated (Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known137])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n137_o0 a jx jy (apart15).2.2.1 (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n137_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.1 (apart8).2.2.1 (apart15).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n137_o2 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.2.2
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known138 a)), by simp [affine_beta_branches137], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n137_o3 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n137_o4 a jx jy (apart12).2.1 (ha) (apart15).2.2.2 (apart9).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n137_o5 a jx jy (ha) (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n137_o6 a jx jy (apart12).2.2.2 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).2.2.1 (apart15).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n137_o7 a jx jy (apart15).2.2.2 (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1 (ha))

theorem affine_beta_nonnegative138 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known138 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known138, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty138 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known138 a) (1 : Int) (4 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n138_empty a ((by simpa only [KnownContains, affine_beta_known138, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window138 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known138 a)) B) : QueryWindow h (1 : Int) (4 : Int) := by
  have top4 := known_top_below state (affine_beta_nonnegative138 a ha) (t := (Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known138])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n138_height a h (top4) ((by omega))

theorem affine_beta_complete138 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (4 : Int))
    (separated : ∀ u, u ∈ affine_beta_known138 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches138 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart4 := separated (Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known138])
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known138])
  have apart14 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known138])
  have apart15 := separated (Cross.mk (2 : Int) (3 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known138])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n138_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1 (ha) (apart4).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n138_o1 a jx jy (apart14).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.2 (apart12).2.2.2 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n138_o2 a jx jy (apart14).2.1 (ha) (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n138_o3 a jx jy (ha) (apart12).2.2.2 (apart14).2.1 (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n138_o4 a jx jy (apart14).2.2.1 (apart14).2.1 (ha) (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n138_o5 a jx jy (ha) (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart4).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n138_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.2 (ha) (apart14).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n138_o7 a jx jy (apart14).2.1 (apart15).2.2.2 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))

theorem affine_beta_nonnegative139 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known139 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known139, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty139 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known139 a) (2 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n139_empty a ((by simpa only [KnownContains, affine_beta_known139, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window139 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known139 a)) B) : QueryWindow h (2 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative139 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known139])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n139_height a h ((by omega)) (top2)

theorem affine_beta_complete139 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known139 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches139 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known139])
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known139])
  have apart13 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known139])
  have apart14 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known139])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known139])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n139_o0 a jx jy (ha) (apart15).2.1 (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n139_o1 a jx jy (apart8).2.2.1 (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n139_o2 a jx jy (ha) (apart14).2.1 (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n139_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.2.1 (apart15).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n139_o4 a jx jy (apart12).2.1 (ha) (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n139_o5 a jx jy (apart15).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n139_o6 a jx jy (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n139_o7 a jx jy (ha) (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.1)

theorem affine_beta_nonnegative140 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known140 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known140, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty140 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known140 a) (2 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n140_empty a ((by simpa only [KnownContains, affine_beta_known140, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window140 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known140 a)) B) : QueryWindow h (2 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative140 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known140])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n140_height a h ((by omega)) (top2)

theorem affine_beta_complete140 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known140 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches140 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known140])
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known140])
  have apart14 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known140])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known140])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n140_o0 a jx jy (ha) (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n140_o1 a jx jy (apart12).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n140_o2 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((2 : Int) + a) (2 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known141 a)), by simp [affine_beta_branches140], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n140_o3 a jx jy (ha) (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n140_o4 a jx jy (apart12).2.1 (apart15).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n140_o5 a jx jy (apart15).2.2.1 (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n140_o6 a jx jy (ha) (apart8).2.2.1 (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n140_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1 (apart12).2.1 (ha) (apart15).1)

theorem affine_beta_nonnegative141 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known141 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known141, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty141 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known141 a) (1 : Int) (4 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n141_empty a (ha) ((by simpa only [KnownContains, affine_beta_known141, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window141 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known141 a)) B) : QueryWindow h (1 : Int) (4 : Int) := by
  have top4 := known_top_below state (affine_beta_nonnegative141 a ha) (t := (Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known141])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n141_height a h ((by omega)) (top4)

theorem affine_beta_complete141 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (4 : Int))
    (separated : ∀ u, u ∈ affine_beta_known141 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches141 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart4 := separated (Cross.mk (-1 : Int) (4 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known141])
  have apart12 := separated (Cross.mk (1 : Int) (1 : Int) a (1 : Int) (1 : Int) (0 : Int)) (by simp [affine_beta_known141])
  have apart13 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known141])
  have apart14 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known141])
  have apart15 := separated (Cross.mk ((1 : Int) + a) (3 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known141])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n141_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.1 (apart4).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n141_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.1 (apart14).2.2.2 (ha) (apart12).2.2.2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n141_o2 a jx jy (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n141_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1 (ha) (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n141_o4 a jx jy (apart14).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart13).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n141_o5 a jx jy (apart14).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.2 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n141_o6 a jx jy (apart12).2.2.2 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n141_o7 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1 (apart15).2.1 (ha))

theorem affine_beta_nonnegative142 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known142 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known142, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty142 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known142 a) (1 : Int) (0 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n142_empty a ((by simpa only [KnownContains, affine_beta_known142, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window142 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known142 a)) B) : QueryWindow h (1 : Int) (0 : Int) := by
  have top0 := known_top_below state (affine_beta_nonnegative142 a ha) (t := (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known142])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n142_height a h ((by omega)) (top0)

theorem affine_beta_complete142 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (0 : Int))
    (separated : ∀ u, u ∈ affine_beta_known142 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches142 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart6 := separated (Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known142])
  have apart7 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known142])
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known142])
  have apart12 := separated (Cross.mk a (1 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known142])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n142_o0 a jx jy (ha) (apart12).2.1 (apart7).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart6).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n142_o1 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1 (apart7).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n142_o2 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.2.1 (apart6).1 (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n142_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).1 (apart8).2.2.1 (apart7).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n142_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart7).1 (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n142_o5 a jx jy (ha) (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart8).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n142_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart7).2.2.1 (ha) (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n142_o7 a jx jy (apart12).2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart6).1)

theorem affine_beta_nonnegative143 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known143 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known143, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty143 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known143 a) (1 : Int) (0 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n143_empty a ((by simpa only [KnownContains, affine_beta_known143, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window143 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known143 a)) B) : QueryWindow h (1 : Int) (0 : Int) := by
  have top0 := known_top_below state (affine_beta_nonnegative143 a ha) (t := (Cross.mk (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known143])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n143_height a h (top0) ((by omega))

theorem affine_beta_complete143 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (0 : Int))
    (separated : ∀ u, u ∈ affine_beta_known143 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches143 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart5 := separated (Cross.mk (0 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known143])
  have apart6 := separated (Cross.mk (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known143])
  have apart7 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known143])
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known143])
  have apart12 := separated (Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known143])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n143_o0 a jx jy (apart8).1 (apart6).1 (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n143_o1 a jx jy (apart7).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (0 : Int) a (1 : Int)) (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n143_o2 a jx jy (ha) (apart6).1 (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (knownCells (affine_beta_known144 a)), by simp [affine_beta_branches143], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n143_o3 a jx jy (apart8).2.2.1 (apart7).2.2.1 (apart12).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n143_o4 a jx jy (ha) (apart12).2.2.1 (apart5).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n143_o5 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1 (ha) (apart8).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n143_o6 a jx jy (ha) (apart7).2.2.1 (apart5).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n143_o7 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart6).1 (apart12).1 (apart8).2.2.1)

theorem affine_beta_nonnegative144 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known144 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known144, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty144 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known144 a) (0 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n144_empty a (ha) ((by simpa only [KnownContains, affine_beta_known144, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window144 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known144 a)) B) : QueryWindow h (0 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative144 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known144])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n144_height a h (top2) ((by omega))

theorem affine_beta_complete144 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (0 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known144 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches144 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known144])
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known144])
  have apart3 := separated (Cross.mk (-1 : Int) (3 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known144])
  have apart12 := separated (Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known144])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n144_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.1 (apart2).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n144_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart2).1 (ha) (apart12).2.2.1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known149 a)), by simp [affine_beta_branches144], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n144_o2 a jx jy (apart3).1 (ha) (apart1).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n144_o3 a jx jy (apart12).2.2.1 (apart3).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (1 : Int) (1 : Int) a) (Cross.mk (0 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n144_o4 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (apart12).2.2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (knownCells (affine_beta_known145 a)), by simp [affine_beta_branches144], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n144_o5 a jx jy (apart2).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1 (apart12).1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n144_o6 a jx jy (apart12).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart2).1 ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known148 a)), by simp [affine_beta_branches144], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n144_o7 a jx jy (apart2).1 (apart12).2.1 (apart3).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))

theorem affine_beta_nonnegative145 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known145 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known145, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty145 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known145 a) (1 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n145_empty a ((by simpa only [KnownContains, affine_beta_known145, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window145 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known145 a)) B) : QueryWindow h (1 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative145 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known145])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n145_height a h ((by omega)) (top2)

theorem affine_beta_complete145 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known145 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches145 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart12 := separated (Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known145])
  have apart13 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known145])
  have apart14 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_beta_known145])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n145_o0 a jx jy (apart12).2.1 (ha) (apart14).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) (1 : Int) (0 : Int) a) (Cross.mk (1 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n145_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1 (ha) ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent))
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (knownCells (affine_beta_known147 a)), by simp [affine_beta_branches145], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n145_o2 a jx jy (apart14).2.1 (apart12).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n145_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1 (apart12).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n145_o4 a jx jy (apart13).2.2.1 (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n145_o5 a jx jy (apart12).2.1 (ha) (apart12).1 (apart14).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (1 : Int) a (0 : Int) (1 : Int)) (Cross.mk (1 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact CornerAffineArithmetic.beta_n145_o6 a jx jy ((by simpa only [Same,eq_comm,or_assoc,and_assoc] using absent)) (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1
    have m0 := alternatives
    exact ⟨Branch.mk (Cross.mk (1 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (knownCells (affine_beta_known146 a)), by simp [affine_beta_branches145], (same_eq m0).symm⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n145_o7 a jx jy (apart12).2.1 (apart14).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))

theorem affine_beta_nonnegative146 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known146 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known146, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty146 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known146 a) (2 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n146_empty a (ha) ((by simpa only [KnownContains, affine_beta_known146, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window146 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known146 a)) B) : QueryWindow h (2 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative146 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known146])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n146_height a h ((by omega)) (top2)

theorem affine_beta_complete146 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known146 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches146 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known146])
  have apart8 := separated (Cross.mk (2 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known146])
  have apart12 := separated (Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known146])
  have apart13 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known146])
  have apart15 := separated (Cross.mk (1 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known146])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n146_o0 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1 (ha) (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n146_o1 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart8).2.2.1 (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n146_o2 a jx jy (apart12).2.2.1 (ha) (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n146_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1 (ha) (apart15).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n146_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart13).2.2.1 (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n146_o5 a jx jy (apart12).2.1 (ha) (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart2).1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n146_o6 a jx jy (ha) (apart15).2.2.1 (apart8).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n146_o7 a jx jy (apart12).2.1 (apart15).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart2).1 (ha))

theorem affine_beta_nonnegative147 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known147 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known147, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty147 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known147 a) (2 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n147_empty a ((by simpa only [KnownContains, affine_beta_known147, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed)) (ha)

theorem affine_beta_window147 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known147 a)) B) : QueryWindow h (2 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative147 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known147])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n147_height a h (top2) ((by omega))

theorem affine_beta_complete147 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (2 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known147 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches147 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart1 := separated (Cross.mk (-1 : Int) (1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known147])
  have apart12 := separated (Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known147])
  have apart13 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known147])
  have apart14 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (0 : Int) (1 : Int) (1 : Int) a) (by simp [affine_beta_known147])
  have apart15 := separated (Cross.mk (1 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known147])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n147_o0 a jx jy (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n147_o1 a jx jy (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n147_o2 a jx jy (apart12).2.1 (ha) (apart14).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n147_o3 a jx jy (ha) (apart15).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n147_o4 a jx jy (apart13).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n147_o5 a jx jy (apart12).2.1 (apart1).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart15).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n147_o6 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart15).2.2.1 (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n147_o7 a jx jy (apart15).2.1 (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))

theorem affine_beta_nonnegative148 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known148 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known148, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty148 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known148 a) (1 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n148_empty a (ha) ((by simpa only [KnownContains, affine_beta_known148, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window148 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known148 a)) B) : QueryWindow h (1 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative148 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known148])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n148_height a h ((by omega)) (top2)

theorem affine_beta_complete148 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known148 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches148 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known148])
  have apart7 := separated (Cross.mk (1 : Int) (-1 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known148])
  have apart12 := separated (Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known148])
  have apart13 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known148])
  have apart14 := separated (Cross.mk (0 : Int) (3 : Int) (1 : Int) a (0 : Int) (1 : Int)) (by simp [affine_beta_known148])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n148_o0 a jx jy (apart2).1 (ha) (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n148_o1 a jx jy (ha) (apart14).2.2.1 (apart7).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n148_o2 a jx jy (apart12).2.2.1 (ha) (apart14).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n148_o3 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.2.1 (apart14).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n148_o4 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1 (apart13).2.2.1 (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n148_o5 a jx jy (ha) (apart12).2.1 (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n148_o6 a jx jy (apart7).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart14).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n148_o7 a jx jy (apart12).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart2).1 (apart14).2.2.1)

theorem affine_beta_nonnegative149 (a : Int) (ha : 6≤a) :
    ∀ t, t ∈ affine_beta_known149 a → Nonnegative t := by
  intro t mem
  simp only [affine_beta_known149, List.mem_cons, List.not_mem_nil, or_false] at mem
  rcases mem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  all_goals dsimp [Nonnegative]; omega

theorem affine_beta_empty149 (a : Int) (ha : 6≤a) : ¬KnownContains (affine_beta_known149 a) (1 : Int) (2 : Int) := by
  intro claimed
  exact CornerAffineArithmetic.beta_n149_empty a (ha) ((by simpa only [KnownContains, affine_beta_known149, List.mem_cons, List.not_mem_nil, or_false, or_and_right, exists_or, exists_eq_left, Contains, or_assoc, and_assoc] using claimed))

theorem affine_beta_window149 (a : Int) (ha : 6≤a) (world : Cross → Prop) (h : Int)
    (B : Int → Int → Prop) (state : State world h (knownCells (affine_beta_known149 a)) B) : QueryWindow h (1 : Int) (2 : Int) := by
  have top2 := known_top_below state (affine_beta_nonnegative149 a ha) (t := (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int))) (by simp [affine_beta_known149])
  refine ⟨by decide,by decide,by decide,?_⟩
  apply Classical.byContradiction
  intro notBelow
  exact CornerAffineArithmetic.beta_n149_height a h (top2) ((by omega))

theorem affine_beta_complete149 (a : Int) (ha : 6≤a) (t : Cross)
    (copy : Copy a 1 1 0 t) (hit : Contains t (1 : Int) (2 : Int))
    (separated : ∀ u, u ∈ affine_beta_known149 a → Apart t u) :
    ∃ branch, branch ∈ affine_beta_branches149 a ∧ branch.tile=t := by
  rcases t with ⟨jx,jy,e,n,w,s⟩
  have apart2 := separated (Cross.mk (-1 : Int) (2 : Int) (0 : Int) (0 : Int) (0 : Int) (0 : Int)) (by simp [affine_beta_known149])
  have apart12 := separated (Cross.mk a (1 : Int) (1 : Int) (1 : Int) a (0 : Int)) (by simp [affine_beta_known149])
  have apart13 := separated (Cross.mk ((1 : Int) + a) (0 : Int) (1 : Int) (0 : Int) a (1 : Int)) (by simp [affine_beta_known149])
  have apart14 := separated (Cross.mk (0 : Int) ((2 : Int) + a) (1 : Int) (1 : Int) (0 : Int) a) (by simp [affine_beta_known149])
  rcases copy with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n149_o0 a jx jy (ha) (apart14).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n149_o1 a jx jy (apart14).1 (ha) (apart12).2.2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n149_o2 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart14).2.1 (apart12).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n149_o3 a jx jy (apart12).2.2.1 (ha) (apart14).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n149_o4 a jx jy (apart13).2.2.1 (apart14).2.1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha))
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n149_o5 a jx jy (apart2).1 (ha) (apart12).1 ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n149_o6 a jx jy ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (ha) (apart12).2.2.1 (apart14).2.2.1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact False.elim (CornerAffineArithmetic.beta_n149_o7 a jx jy (ha) ((by simpa only [Contains,or_assoc,and_assoc] using hit)) (apart12).2.1 (apart14).2.1)

end CornerCertificate

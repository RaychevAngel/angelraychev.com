import LQuadrantHpOptimizedUnequalMixedNonexceptionDeltaTwoPrunedGeometry

namespace PolyominoFormal.LHalfPlaneMixedMotif
open CrossUnits LRegion

/-- The mixed first row forced by arm difference two has a finite obstruction.
Every tile is retained in full, including cells beyond the queried pocket. -/
theorem mixed_impossible {a b : Int}
    (ha : 5≤a) (hb : 3≤b) (hab : b<a) (delta : a=b+2)
    (nonexception : a≠5 ∨ b≠3) (T : Tiling a b 0 0 HalfPlane)
    (h0 : T.world ⟨-1,0,0,b,a,0⟩) (h1 : T.world ⟨0,0,a,b,0,0⟩)
    (h2 : T.world ⟨2*a+1,0,0,b,a,0⟩) (h3 : T.world ⟨2*a+2,0,a,b,0,0⟩)
    (hU : T.world ⟨1,1,a,b,0,0⟩) (hS : T.world ⟨2*a,1,0,a,b,0⟩) : False := by
  apply HP_optimized_unequal_mixed_nonexception_delta_two_pruned_anchored_obstruction
    a b (by omega) hb hab ha delta nonexception T h0 h1 ?_ ?_ hU hS
  · simpa only [Int.add_comm] using h2
  · simpa only [Int.add_comm] using h3

#print axioms mixed_impossible
end PolyominoFormal.LHalfPlaneMixedMotif

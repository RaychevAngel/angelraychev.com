import THalfPlaneGaps

namespace PolyominoFormal.THalfPlaneDeepGaps
open CrossUnits CornerCertificate THalfPlaneStarters THalfPlaneGaps

theorem starter_column {a b c p h y : Int}
    (ha : 1≤a) (hb : 1≤b) (hc : 1≤c) {t : Cross}
    (st : Starter a b c p h t) (hy : h≤y)
    (barTop : y≤h+a+c) (stemTop : y≤h+b) : Contains t p y := by
  rcases st with rfl | rfl | rfl | rfl | rfl | rfl
  all_goals right
  all_goals dsimp
  all_goals omega

theorem right_v_collides {a b c L R p h r : Int} {region B : Region}
    (ha : c≤a) (hc : 1≤c) (hb : a+c≤b) (hr : r=a ∨ r=c)
    (hp0 : L≤p) (hp1 : p≤R) (T : Tiling a b c 0 region)
    (closed : TileClosed T.world B) (empty : ¬B p h)
    (wall : ∀ y, h≤y → y≤h+a → B (R+1) y)
    (choose : ∀ x, L≤x → x≤R → ∃ t, T.world t ∧ Starter a b c x h t)
    (anchor : T.world ⟨p,h+r,b,a+c-r,0,r⟩) : False := by
  have base : Contains ⟨p,h+r,b,a+c-r,0,r⟩ p h := by right; dsimp; omega
  have stem : Contains ⟨p,h+r,b,a+c-r,0,r⟩ (p+1) (h+r) := by left; dsimp; omega
  by_cases edge : p=R
  · have blocked : B (p+1) (h+r) := by rw [edge]; exact wall _ (by omega) (by omega)
    exact avoid_closed closed anchor base empty blocked stem
  · obtain ⟨u,hu,su⟩ := choose (p+1) (by omega) (by omega)
    have hit := starter_column (y:=h+r) (by omega) (by omega) hc su (by omega) (by omega) (by omega)
    have eq := T.disjoint _ u (p+1) (h+r) anchor hu stem hit
    have xp : u.x=p+1 := by rcases su with rfl | rfl | rfl | rfl | rfl | rfl <;> rfl
    have heq := congrArg Cross.x eq
    dsimp at heq
    omega

theorem left_v_collides {a b c L R p h r : Int} {region B : Region}
    (ha : c≤a) (hc : 1≤c) (hb : a+c≤b) (hr : r=a ∨ r=c)
    (hp0 : L≤p) (hp1 : p≤R) (T : Tiling a b c 0 region)
    (closed : TileClosed T.world B) (empty : ¬B p h)
    (wall : ∀ y, h≤y → y≤h+a → B (L-1) y)
    (choose : ∀ x, L≤x → x≤R → ∃ t, T.world t ∧ Starter a b c x h t)
    (anchor : T.world ⟨p,h+r,0,a+c-r,b,r⟩) : False := by
  have base : Contains ⟨p,h+r,0,a+c-r,b,r⟩ p h := by right; dsimp; omega
  have stem : Contains ⟨p,h+r,0,a+c-r,b,r⟩ (p-1) (h+r) := by left; dsimp; omega
  by_cases edge : p=L
  · have blocked : B (p-1) (h+r) := by rw [edge]; exact wall _ (by omega) (by omega)
    exact avoid_closed closed anchor base empty blocked stem
  · obtain ⟨u,hu,su⟩ := choose (p-1) (by omega) (by omega)
    have hit := starter_column (y:=h+r) (by omega) (by omega) hc su (by omega) (by omega) (by omega)
    have eq := T.disjoint _ u (p-1) (h+r) anchor hu stem hit
    have xp : u.x=p-1 := by rcases su with rfl | rfl | rfl | rfl | rfl | rfl <;> rfl
    have heq := congrArg Cross.x eq
    dsimp at heq
    omega

theorem blocked_deep_run {a b c L R h : Int} {region : Region}
    (ha : c≤a) (hc : 1≤c) (longStem : a+c≤b)
    (two : L+1≤R) (shortRun : R-L<a+c)
    (T : Tiling a b c 0 region) (B : Region) (closed : TileClosed T.world B)
    (inside : ∀ x, L≤x → x≤R → region x h)
    (empty : ∀ x, L≤x → x≤R → ¬B x h)
    (floor : ∀ x, L≤x → x≤R → B x (h-1))
    (left : ∀ y, h≤y → y≤h+a → B (L-1) y)
    (right : ∀ y, h≤y → y≤h+a → B (R+1) y) : False := by
  have choose : ∀ p, L≤p → p≤R → ∃ t, T.world t ∧ Starter a b c p h t := by
    intro p hp0 hp1
    obtain ⟨t,ht,hit⟩ := T.cover p h (inside p hp0 hp1)
    have avoid : ∀ {x y}, B x y → ¬Contains t x y :=
      fun blocked => avoid_closed closed ht hit (empty p hp0 hp1) blocked
    refine ⟨t,ht,short_run_forms (by omega) (by omega) hc shortRun hp0 hp1 (T.copies t ht) hit
      (avoid (left h (by omega) (by omega))) (avoid (right h (by omega) (by omega)))
      (avoid (floor p hp0 hp1)) ?_⟩
    intro hx0 hx1
    exact avoid (floor t.x hx0 hx1)
  have chooseS : ∀ p, L≤p → p≤R → ∃ t, T.world t ∧
      (t=⟨p,h+b,a,0,c,b⟩ ∨ t=⟨p,h+b,c,0,a,b⟩) := by
    intro p hp0 hp1
    obtain ⟨t,ht,st⟩ := choose p hp0 hp1
    rcases st with rfl | rfl | rfl | rfl | rfl | rfl
    · exact False.elim (right_v_collides ha hc longStem (Or.inl rfl) hp0 hp1 T closed
        (empty p hp0 hp1) right choose (by simpa only [show a+c-a=c by omega] using ht))
    · exact False.elim (right_v_collides ha hc longStem (Or.inr rfl) hp0 hp1 T closed
        (empty p hp0 hp1) right choose (by simpa only [show a+c-c=a by omega] using ht))
    · exact False.elim (left_v_collides ha hc longStem (Or.inl rfl) hp0 hp1 T closed
        (empty p hp0 hp1) left choose (by simpa only [show a+c-a=c by omega] using ht))
    · exact False.elim (left_v_collides ha hc longStem (Or.inr rfl) hp0 hp1 T closed
        (empty p hp0 hp1) left choose (by simpa only [show a+c-c=a by omega] using ht))
    · exact ⟨_,ht,Or.inl rfl⟩
    · exact ⟨_,ht,Or.inr rfl⟩
  obtain ⟨t,ht,st⟩ := chooseS L (by omega) (by omega)
  obtain ⟨u,hu,su⟩ := chooseS (L+1) (by omega) (by omega)
  have thit : Contains t (L+1) (h+b) := by rcases st with rfl | rfl <;> left <;> dsimp <;> omega
  have uhit : Contains u (L+1) (h+b) := by rcases su with rfl | rfl <;> left <;> dsimp <;> omega
  have eq := T.disjoint t u (L+1) (h+b) ht hu thit uhit
  have tx : t.x=L := by rcases st with rfl | rfl <;> rfl
  have ux : u.x=L+1 := by rcases su with rfl | rfl <;> rfl
  have heq := congrArg Cross.x eq
  omega

theorem no_deep_horizontal_pair {a b c p r s : Int}
    (ha : c≤a) (hc : 1≤c) (long : a+c≤b)
    (hr : r=a ∨ r=c) (hs : s=a ∨ s=c) (descending : s≤r)
    (T : Tiling a b c 0 HalfPlane)
    (first : T.world ⟨p+r,0,a+c-r,b,r,0⟩)
    (second : T.world ⟨p+(a+c+1)+s,0,a+c-s,b,s,0⟩) : False := by
  let t : Cross := ⟨p+r,0,a+c-r,b,r,0⟩
  let u : Cross := ⟨p+(a+c+1)+s,0,a+c-s,b,s,0⟩
  let B : Region := fun x y => Contains t x y ∨ Contains u x y
  apply blocked_deep_run (L:=p+r+1) (R:=p+(a+c+1)+s-1) (h:=1)
    ha hc long (by omega) (by omega) T B (pair_closed T first second)
  · intro x hx0 hx1
    exact show (0:Int)≤1 by omega
  · intro x hx0 hx1
    dsimp [B,t,u,Contains]
    omega
  · intro x hx0 hx1
    dsimp [B,t,u,Contains]
    omega
  · intro y hy0 hy1
    dsimp [B,t,u,Contains]
    omega
  · intro y hy0 hy1
    dsimp [B,t,u,Contains]
    omega

theorem all_horizontal_long_impossible {a b c : Int}
    (ha : c≤a) (hc : 1≤c) (long : a+c≤b)
    (T : Tiling a b c 0 HalfPlane) (cover : HorizontalCover T) : False := by
  obtain ⟨p,r,hr,first,_,_⟩ := cover 0
  obtain ⟨s,hs,second⟩ := next_horizontal ha hc (by omega) hr T cover first
  by_cases desc : s≤r
  · exact no_deep_horizontal_pair ha hc long hr hs desc T first second
  · obtain ⟨q,hq,third⟩ := next_horizontal ha hc (by omega) hs T cover second
    have desc2 : q≤s := by omega
    exact no_deep_horizontal_pair ha hc long hs hq desc2 T second third

#print axioms blocked_deep_run
#print axioms all_horizontal_long_impossible
end PolyominoFormal.THalfPlaneDeepGaps

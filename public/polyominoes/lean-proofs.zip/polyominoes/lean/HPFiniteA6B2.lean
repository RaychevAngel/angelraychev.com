import HPFiniteA6B2Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
namespace THalfPlaneFinite
open CrossUnits PolyominoFormal

theorem hp6_2_node1567 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1567 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1567 ((8 : Int),(1 : Int)) hp6_2_branches1567 hp6_2_evidence1567 hp6_2_check1567 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1567,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1566 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1566 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1566 ((8 : Int),(1 : Int)) hp6_2_branches1566 hp6_2_evidence1566 hp6_2_check1566 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1566,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1565 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1565 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1565 ((8 : Int),(1 : Int)) hp6_2_branches1565 hp6_2_evidence1565 hp6_2_check1565 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1565,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1564 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1564 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1564 ((9 : Int),(1 : Int)) hp6_2_branches1564 hp6_2_evidence1564 hp6_2_check1564 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1564,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1563 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1563 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1563 ((9 : Int),(1 : Int)) hp6_2_branches1563 hp6_2_evidence1563 hp6_2_check1563 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1563,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1562 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1562 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1562 ((8 : Int),(1 : Int)) hp6_2_branches1562 hp6_2_evidence1562 hp6_2_check1562 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1562,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1563 T childKnown
  · exact hp6_2_node1564 T childKnown
theorem hp6_2_node1561 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1561 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1561 ((8 : Int),(1 : Int)) hp6_2_branches1561 hp6_2_evidence1561 hp6_2_check1561 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1561,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1560 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1560 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1560 ((7 : Int),(1 : Int)) hp6_2_branches1560 hp6_2_evidence1560 hp6_2_check1560 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1560,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node1561 T childKnown
  · exact hp6_2_node1562 T childKnown
  · exact hp6_2_node1565 T childKnown
  · exact hp6_2_node1566 T childKnown
  · exact hp6_2_node1567 T childKnown
theorem hp6_2_node1559 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1559 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1559 ((8 : Int),(1 : Int)) hp6_2_branches1559 hp6_2_evidence1559 hp6_2_check1559 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1559,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1558 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1558 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1558 ((8 : Int),(1 : Int)) hp6_2_branches1558 hp6_2_evidence1558 hp6_2_check1558 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1558,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1557 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1557 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1557 ((0 : Int),(2 : Int)) hp6_2_branches1557 hp6_2_evidence1557 hp6_2_check1557 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1557,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1556 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1556 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1556 ((4 : Int),(1 : Int)) hp6_2_branches1556 hp6_2_evidence1556 hp6_2_check1556 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1556,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1557 T childKnown
theorem hp6_2_node1555 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1555 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1555 ((11 : Int),(2 : Int)) hp6_2_branches1555 hp6_2_evidence1555 hp6_2_check1555 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1555,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1554 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1554 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1554 ((10 : Int),(2 : Int)) hp6_2_branches1554 hp6_2_evidence1554 hp6_2_check1554 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1554,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1555 T childKnown
theorem hp6_2_node1553 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1553 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1553 ((18 : Int),(1 : Int)) hp6_2_branches1553 hp6_2_evidence1553 hp6_2_check1553 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1553,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1552 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1552 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1552 ((12 : Int),(2 : Int)) hp6_2_branches1552 hp6_2_evidence1552 hp6_2_check1552 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1552,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1553 T childKnown
theorem hp6_2_node1551 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1551 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1551 ((16 : Int),(0 : Int)) hp6_2_branches1551 hp6_2_evidence1551 hp6_2_check1551 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1551,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1552 T childKnown
theorem hp6_2_node1550 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1550 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1550 ((10 : Int),(2 : Int)) hp6_2_branches1550 hp6_2_evidence1550 hp6_2_check1550 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1550,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1551 T childKnown
theorem hp6_2_node1549 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1549 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1549 ((11 : Int),(2 : Int)) hp6_2_branches1549 hp6_2_evidence1549 hp6_2_check1549 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1549,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1548 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1548 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1548 ((11 : Int),(1 : Int)) hp6_2_branches1548 hp6_2_evidence1548 hp6_2_check1548 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1548,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1549 T childKnown
theorem hp6_2_node1547 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1547 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1547 ((10 : Int),(1 : Int)) hp6_2_branches1547 hp6_2_evidence1547 hp6_2_check1547 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1547,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1548 T childKnown
  · exact hp6_2_node1550 T childKnown
  · exact hp6_2_node1554 T childKnown
theorem hp6_2_node1546 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1546 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1546 ((11 : Int),(2 : Int)) hp6_2_branches1546 hp6_2_evidence1546 hp6_2_check1546 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1546,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1545 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1545 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1545 ((10 : Int),(2 : Int)) hp6_2_branches1545 hp6_2_evidence1545 hp6_2_check1545 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1545,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1546 T childKnown
theorem hp6_2_node1544 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1544 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1544 ((18 : Int),(1 : Int)) hp6_2_branches1544 hp6_2_evidence1544 hp6_2_check1544 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1544,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1543 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1543 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1543 ((12 : Int),(2 : Int)) hp6_2_branches1543 hp6_2_evidence1543 hp6_2_check1543 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1543,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1544 T childKnown
theorem hp6_2_node1542 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1542 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1542 ((16 : Int),(0 : Int)) hp6_2_branches1542 hp6_2_evidence1542 hp6_2_check1542 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1542,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1543 T childKnown
theorem hp6_2_node1541 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1541 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1541 ((10 : Int),(2 : Int)) hp6_2_branches1541 hp6_2_evidence1541 hp6_2_check1541 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1541,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1542 T childKnown
theorem hp6_2_node1540 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1540 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1540 ((11 : Int),(2 : Int)) hp6_2_branches1540 hp6_2_evidence1540 hp6_2_check1540 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1540,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1539 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1539 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1539 ((11 : Int),(1 : Int)) hp6_2_branches1539 hp6_2_evidence1539 hp6_2_check1539 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1539,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1540 T childKnown
theorem hp6_2_node1538 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1538 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1538 ((10 : Int),(1 : Int)) hp6_2_branches1538 hp6_2_evidence1538 hp6_2_check1538 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1538,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1539 T childKnown
  · exact hp6_2_node1541 T childKnown
  · exact hp6_2_node1545 T childKnown
theorem hp6_2_node1537 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1537 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1537 ((3 : Int),(2 : Int)) hp6_2_branches1537 hp6_2_evidence1537 hp6_2_check1537 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1537,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1538 T childKnown
  · exact hp6_2_node1547 T childKnown
theorem hp6_2_node1536 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1536 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1536 ((5 : Int),(2 : Int)) hp6_2_branches1536 hp6_2_evidence1536 hp6_2_check1536 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1536,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1537 T childKnown
theorem hp6_2_node1535 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1535 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1535 ((0 : Int),(2 : Int)) hp6_2_branches1535 hp6_2_evidence1535 hp6_2_check1535 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1535,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1534 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1534 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1534 ((5 : Int),(2 : Int)) hp6_2_branches1534 hp6_2_evidence1534 hp6_2_check1534 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1534,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1535 T childKnown
theorem hp6_2_node1533 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1533 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1533 ((5 : Int),(1 : Int)) hp6_2_branches1533 hp6_2_evidence1533 hp6_2_check1533 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1533,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1534 T childKnown
  · exact hp6_2_node1536 T childKnown
  · exact hp6_2_node1556 T childKnown
theorem hp6_2_node1532 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1532 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1532 ((8 : Int),(1 : Int)) hp6_2_branches1532 hp6_2_evidence1532 hp6_2_check1532 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1532,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1533 T childKnown
theorem hp6_2_node1531 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1531 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1531 ((8 : Int),(1 : Int)) hp6_2_branches1531 hp6_2_evidence1531 hp6_2_check1531 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1531,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1530 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1530 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1530 ((7 : Int),(1 : Int)) hp6_2_branches1530 hp6_2_evidence1530 hp6_2_check1530 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1530,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node1531 T childKnown
  · exact hp6_2_node1532 T childKnown
  · exact hp6_2_node1558 T childKnown
  · exact hp6_2_node1559 T childKnown
theorem hp6_2_node1529 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1529 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1529 ((9 : Int),(1 : Int)) hp6_2_branches1529 hp6_2_evidence1529 hp6_2_check1529 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1529,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1528 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1528 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1528 ((9 : Int),(1 : Int)) hp6_2_branches1528 hp6_2_evidence1528 hp6_2_check1528 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1528,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1527 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1527 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1527 ((9 : Int),(0 : Int)) hp6_2_branches1527 hp6_2_evidence1527 hp6_2_check1527 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1527,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1528 T childKnown
  · exact hp6_2_node1529 T childKnown
theorem hp6_2_node1526 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1526 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1526 ((7 : Int),(1 : Int)) hp6_2_branches1526 hp6_2_evidence1526 hp6_2_check1526 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1526,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1527 T childKnown
theorem hp6_2_node1525 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1525 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1525 ((0 : Int),(2 : Int)) hp6_2_branches1525 hp6_2_evidence1525 hp6_2_check1525 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1525,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1524 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1524 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1524 ((4 : Int),(1 : Int)) hp6_2_branches1524 hp6_2_evidence1524 hp6_2_check1524 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1524,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1525 T childKnown
theorem hp6_2_node1523 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1523 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1523 ((13 : Int),(1 : Int)) hp6_2_branches1523 hp6_2_evidence1523 hp6_2_check1523 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1523,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1522 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1522 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1522 ((13 : Int),(1 : Int)) hp6_2_branches1522 hp6_2_evidence1522 hp6_2_check1522 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1522,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1521 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1521 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1521 ((12 : Int),(1 : Int)) hp6_2_branches1521 hp6_2_evidence1521 hp6_2_check1521 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1521,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1522 T childKnown
  · exact hp6_2_node1523 T childKnown
theorem hp6_2_node1520 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1520 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1520 ((11 : Int),(1 : Int)) hp6_2_branches1520 hp6_2_evidence1520 hp6_2_check1520 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1520,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1519 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1519 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1519 ((10 : Int),(2 : Int)) hp6_2_branches1519 hp6_2_evidence1519 hp6_2_check1519 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1519,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1520 T childKnown
theorem hp6_2_node1518 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1518 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1518 ((11 : Int),(1 : Int)) hp6_2_branches1518 hp6_2_evidence1518 hp6_2_check1518 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1518,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1517 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1517 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1517 ((9 : Int),(2 : Int)) hp6_2_branches1517 hp6_2_evidence1517 hp6_2_check1517 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1517,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1518 T childKnown
  · exact hp6_2_node1519 T childKnown
  · exact hp6_2_node1521 T childKnown
theorem hp6_2_node1516 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1516 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1516 ((13 : Int),(1 : Int)) hp6_2_branches1516 hp6_2_evidence1516 hp6_2_check1516 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1516,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1515 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1515 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1515 ((13 : Int),(1 : Int)) hp6_2_branches1515 hp6_2_evidence1515 hp6_2_check1515 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1515,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1514 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1514 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1514 ((12 : Int),(1 : Int)) hp6_2_branches1514 hp6_2_evidence1514 hp6_2_check1514 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1514,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1515 T childKnown
  · exact hp6_2_node1516 T childKnown
theorem hp6_2_node1513 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1513 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1513 ((11 : Int),(1 : Int)) hp6_2_branches1513 hp6_2_evidence1513 hp6_2_check1513 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1513,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1512 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1512 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1512 ((10 : Int),(2 : Int)) hp6_2_branches1512 hp6_2_evidence1512 hp6_2_check1512 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1512,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1513 T childKnown
theorem hp6_2_node1511 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1511 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1511 ((11 : Int),(1 : Int)) hp6_2_branches1511 hp6_2_evidence1511 hp6_2_check1511 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1511,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1510 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1510 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1510 ((9 : Int),(2 : Int)) hp6_2_branches1510 hp6_2_evidence1510 hp6_2_check1510 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1510,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1511 T childKnown
  · exact hp6_2_node1512 T childKnown
  · exact hp6_2_node1514 T childKnown
theorem hp6_2_node1509 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1509 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1509 ((3 : Int),(2 : Int)) hp6_2_branches1509 hp6_2_evidence1509 hp6_2_check1509 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1509,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1510 T childKnown
  · exact hp6_2_node1517 T childKnown
theorem hp6_2_node1508 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1508 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1508 ((5 : Int),(2 : Int)) hp6_2_branches1508 hp6_2_evidence1508 hp6_2_check1508 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1508,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1509 T childKnown
theorem hp6_2_node1507 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1507 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1507 ((0 : Int),(2 : Int)) hp6_2_branches1507 hp6_2_evidence1507 hp6_2_check1507 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1507,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1506 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1506 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1506 ((5 : Int),(2 : Int)) hp6_2_branches1506 hp6_2_evidence1506 hp6_2_check1506 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1506,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1507 T childKnown
theorem hp6_2_node1505 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1505 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1505 ((5 : Int),(1 : Int)) hp6_2_branches1505 hp6_2_evidence1505 hp6_2_check1505 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1505,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1506 T childKnown
  · exact hp6_2_node1508 T childKnown
  · exact hp6_2_node1524 T childKnown
theorem hp6_2_node1504 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1504 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1504 ((9 : Int),(0 : Int)) hp6_2_branches1504 hp6_2_evidence1504 hp6_2_check1504 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1504,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1505 T childKnown
theorem hp6_2_node1503 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1503 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1503 ((7 : Int),(1 : Int)) hp6_2_branches1503 hp6_2_evidence1503 hp6_2_check1503 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1503,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1504 T childKnown
theorem hp6_2_node1502 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1502 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1502 ((7 : Int),(1 : Int)) hp6_2_branches1502 hp6_2_evidence1502 hp6_2_check1502 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1502,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1501 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1501 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1501 ((7 : Int),(1 : Int)) hp6_2_branches1501 hp6_2_evidence1501 hp6_2_check1501 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1501,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1500 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1500 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1500 ((8 : Int),(0 : Int)) hp6_2_branches1500 hp6_2_evidence1500 hp6_2_check1500 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1500,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node1501 T childKnown
  · exact hp6_2_node1502 T childKnown
  · exact hp6_2_node1503 T childKnown
  · exact hp6_2_node1526 T childKnown
  · exact hp6_2_node1530 T childKnown
  · exact hp6_2_node1560 T childKnown
theorem hp6_2_node1499 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1499 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1499 ((11 : Int),(1 : Int)) hp6_2_branches1499 hp6_2_evidence1499 hp6_2_check1499 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1499,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1498 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1498 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1498 ((11 : Int),(1 : Int)) hp6_2_branches1498 hp6_2_evidence1498 hp6_2_check1498 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1498,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1497 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1497 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1497 ((9 : Int),(2 : Int)) hp6_2_branches1497 hp6_2_evidence1497 hp6_2_check1497 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1497,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1496 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1496 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1496 ((9 : Int),(2 : Int)) hp6_2_branches1496 hp6_2_evidence1496 hp6_2_check1496 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1496,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1495 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1495 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1495 ((10 : Int),(1 : Int)) hp6_2_branches1495 hp6_2_evidence1495 hp6_2_check1495 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1495,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node1496 T childKnown
  · exact hp6_2_node1497 T childKnown
  · exact hp6_2_node1498 T childKnown
  · exact hp6_2_node1499 T childKnown
theorem hp6_2_node1494 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1494 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1494 ((8 : Int),(0 : Int)) hp6_2_branches1494 hp6_2_evidence1494 hp6_2_check1494 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1494,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1495 T childKnown
theorem hp6_2_node1493 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1493 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1493 ((10 : Int),(1 : Int)) hp6_2_branches1493 hp6_2_evidence1493 hp6_2_check1493 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1493,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1492 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1492 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1492 ((10 : Int),(1 : Int)) hp6_2_branches1492 hp6_2_evidence1492 hp6_2_check1492 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1492,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1491 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1491 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1491 ((10 : Int),(1 : Int)) hp6_2_branches1491 hp6_2_evidence1491 hp6_2_check1491 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1491,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1490 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1490 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1490 ((5 : Int),(2 : Int)) hp6_2_branches1490 hp6_2_evidence1490 hp6_2_check1490 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1490,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1491 T childKnown
theorem hp6_2_node1489 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1489 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1489 ((4 : Int),(2 : Int)) hp6_2_branches1489 hp6_2_evidence1489 hp6_2_check1489 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1489,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1490 T childKnown
  · exact hp6_2_node1492 T childKnown
  · exact hp6_2_node1493 T childKnown
theorem hp6_2_node1488 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1488 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1488 ((10 : Int),(1 : Int)) hp6_2_branches1488 hp6_2_evidence1488 hp6_2_check1488 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1488,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1487 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1487 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1487 ((4 : Int),(2 : Int)) hp6_2_branches1487 hp6_2_evidence1487 hp6_2_check1487 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1487,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1488 T childKnown
theorem hp6_2_node1486 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1486 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1486 ((0 : Int),(2 : Int)) hp6_2_branches1486 hp6_2_evidence1486 hp6_2_check1486 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1486,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1485 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1485 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1485 ((10 : Int),(1 : Int)) hp6_2_branches1485 hp6_2_evidence1485 hp6_2_check1485 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1485,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1484 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1484 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1484 ((10 : Int),(1 : Int)) hp6_2_branches1484 hp6_2_evidence1484 hp6_2_check1484 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1484,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1483 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1483 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1483 ((10 : Int),(1 : Int)) hp6_2_branches1483 hp6_2_evidence1483 hp6_2_check1483 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1483,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1482 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1482 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1482 ((10 : Int),(1 : Int)) hp6_2_branches1482 hp6_2_evidence1482 hp6_2_check1482 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1482,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1481 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1481 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1481 ((5 : Int),(2 : Int)) hp6_2_branches1481 hp6_2_evidence1481 hp6_2_check1481 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1481,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1482 T childKnown
  · exact hp6_2_node1483 T childKnown
theorem hp6_2_node1480 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1480 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1480 ((10 : Int),(1 : Int)) hp6_2_branches1480 hp6_2_evidence1480 hp6_2_check1480 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1480,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1479 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1479 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1479 ((5 : Int),(2 : Int)) hp6_2_branches1479 hp6_2_evidence1479 hp6_2_check1479 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1479,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1480 T childKnown
theorem hp6_2_node1478 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1478 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1478 ((10 : Int),(1 : Int)) hp6_2_branches1478 hp6_2_evidence1478 hp6_2_check1478 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1478,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1477 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1477 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1477 ((5 : Int),(2 : Int)) hp6_2_branches1477 hp6_2_evidence1477 hp6_2_check1477 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1477,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1478 T childKnown
theorem hp6_2_node1476 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1476 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1476 ((4 : Int),(2 : Int)) hp6_2_branches1476 hp6_2_evidence1476 hp6_2_check1476 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1476,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node1477 T childKnown
  · exact hp6_2_node1479 T childKnown
  · exact hp6_2_node1481 T childKnown
  · exact hp6_2_node1484 T childKnown
  · exact hp6_2_node1485 T childKnown
theorem hp6_2_node1475 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1475 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1475 ((10 : Int),(1 : Int)) hp6_2_branches1475 hp6_2_evidence1475 hp6_2_check1475 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1475,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1474 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1474 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1474 ((10 : Int),(1 : Int)) hp6_2_branches1474 hp6_2_evidence1474 hp6_2_check1474 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1474,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1473 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1473 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1473 ((10 : Int),(1 : Int)) hp6_2_branches1473 hp6_2_evidence1473 hp6_2_check1473 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1473,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1472 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1472 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1472 ((10 : Int),(1 : Int)) hp6_2_branches1472 hp6_2_evidence1472 hp6_2_check1472 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1472,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1471 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1471 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1471 ((5 : Int),(2 : Int)) hp6_2_branches1471 hp6_2_evidence1471 hp6_2_check1471 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1471,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1472 T childKnown
  · exact hp6_2_node1473 T childKnown
theorem hp6_2_node1470 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1470 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1470 ((10 : Int),(1 : Int)) hp6_2_branches1470 hp6_2_evidence1470 hp6_2_check1470 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1470,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1469 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1469 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1469 ((5 : Int),(2 : Int)) hp6_2_branches1469 hp6_2_evidence1469 hp6_2_check1469 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1469,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1470 T childKnown
theorem hp6_2_node1468 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1468 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1468 ((10 : Int),(1 : Int)) hp6_2_branches1468 hp6_2_evidence1468 hp6_2_check1468 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1468,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1467 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1467 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1467 ((5 : Int),(2 : Int)) hp6_2_branches1467 hp6_2_evidence1467 hp6_2_check1467 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1467,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1468 T childKnown
theorem hp6_2_node1466 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1466 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1466 ((4 : Int),(2 : Int)) hp6_2_branches1466 hp6_2_evidence1466 hp6_2_check1466 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1466,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node1467 T childKnown
  · exact hp6_2_node1469 T childKnown
  · exact hp6_2_node1471 T childKnown
  · exact hp6_2_node1474 T childKnown
  · exact hp6_2_node1475 T childKnown
theorem hp6_2_node1465 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1465 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1465 ((0 : Int),(2 : Int)) hp6_2_branches1465 hp6_2_evidence1465 hp6_2_check1465 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1465,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1466 T childKnown
theorem hp6_2_node1464 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1464 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1464 ((10 : Int),(1 : Int)) hp6_2_branches1464 hp6_2_evidence1464 hp6_2_check1464 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1464,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1463 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1463 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1463 ((10 : Int),(1 : Int)) hp6_2_branches1463 hp6_2_evidence1463 hp6_2_check1463 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1463,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1462 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1462 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1462 ((10 : Int),(1 : Int)) hp6_2_branches1462 hp6_2_evidence1462 hp6_2_check1462 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1462,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1461 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1461 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1461 ((10 : Int),(1 : Int)) hp6_2_branches1461 hp6_2_evidence1461 hp6_2_check1461 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1461,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1460 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1460 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1460 ((5 : Int),(2 : Int)) hp6_2_branches1460 hp6_2_evidence1460 hp6_2_check1460 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1460,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1461 T childKnown
  · exact hp6_2_node1462 T childKnown
theorem hp6_2_node1459 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1459 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1459 ((10 : Int),(1 : Int)) hp6_2_branches1459 hp6_2_evidence1459 hp6_2_check1459 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1459,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1458 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1458 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1458 ((5 : Int),(2 : Int)) hp6_2_branches1458 hp6_2_evidence1458 hp6_2_check1458 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1458,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1459 T childKnown
theorem hp6_2_node1457 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1457 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1457 ((10 : Int),(1 : Int)) hp6_2_branches1457 hp6_2_evidence1457 hp6_2_check1457 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1457,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1456 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1456 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1456 ((5 : Int),(2 : Int)) hp6_2_branches1456 hp6_2_evidence1456 hp6_2_check1456 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1456,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1457 T childKnown
theorem hp6_2_node1455 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1455 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1455 ((4 : Int),(2 : Int)) hp6_2_branches1455 hp6_2_evidence1455 hp6_2_check1455 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1455,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node1456 T childKnown
  · exact hp6_2_node1458 T childKnown
  · exact hp6_2_node1460 T childKnown
  · exact hp6_2_node1463 T childKnown
  · exact hp6_2_node1464 T childKnown
theorem hp6_2_node1454 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1454 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1454 ((0 : Int),(2 : Int)) hp6_2_branches1454 hp6_2_evidence1454 hp6_2_check1454 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1454,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1455 T childKnown
theorem hp6_2_node1453 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1453 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1453 ((0 : Int),(1 : Int)) hp6_2_branches1453 hp6_2_evidence1453 hp6_2_check1453 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1453,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node1454 T childKnown
  · exact hp6_2_node1465 T childKnown
  · exact hp6_2_node1476 T childKnown
  · exact hp6_2_node1486 T childKnown
theorem hp6_2_node1452 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1452 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1452 ((0 : Int),(2 : Int)) hp6_2_branches1452 hp6_2_evidence1452 hp6_2_check1452 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1452,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1451 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1451 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1451 ((0 : Int),(2 : Int)) hp6_2_branches1451 hp6_2_evidence1451 hp6_2_check1451 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1451,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1450 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1450 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1450 ((0 : Int),(2 : Int)) hp6_2_branches1450 hp6_2_evidence1450 hp6_2_check1450 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1450,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1449 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1449 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1449 ((0 : Int),(1 : Int)) hp6_2_branches1449 hp6_2_evidence1449 hp6_2_check1449 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1449,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1450 T childKnown
  · exact hp6_2_node1451 T childKnown
  · exact hp6_2_node1452 T childKnown
theorem hp6_2_node1448 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1448 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1448 ((10 : Int),(1 : Int)) hp6_2_branches1448 hp6_2_evidence1448 hp6_2_check1448 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1448,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1447 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1447 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1447 ((10 : Int),(1 : Int)) hp6_2_branches1447 hp6_2_evidence1447 hp6_2_check1447 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1447,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1446 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1446 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1446 ((10 : Int),(1 : Int)) hp6_2_branches1446 hp6_2_evidence1446 hp6_2_check1446 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1446,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1445 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1445 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1445 ((10 : Int),(1 : Int)) hp6_2_branches1445 hp6_2_evidence1445 hp6_2_check1445 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1445,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1444 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1444 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1444 ((5 : Int),(2 : Int)) hp6_2_branches1444 hp6_2_evidence1444 hp6_2_check1444 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1444,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1445 T childKnown
  · exact hp6_2_node1446 T childKnown
theorem hp6_2_node1443 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1443 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1443 ((10 : Int),(1 : Int)) hp6_2_branches1443 hp6_2_evidence1443 hp6_2_check1443 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1443,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1442 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1442 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1442 ((5 : Int),(2 : Int)) hp6_2_branches1442 hp6_2_evidence1442 hp6_2_check1442 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1442,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1443 T childKnown
theorem hp6_2_node1441 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1441 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1441 ((10 : Int),(1 : Int)) hp6_2_branches1441 hp6_2_evidence1441 hp6_2_check1441 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1441,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1440 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1440 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1440 ((10 : Int),(1 : Int)) hp6_2_branches1440 hp6_2_evidence1440 hp6_2_check1440 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1440,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1439 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1439 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1439 ((10 : Int),(1 : Int)) hp6_2_branches1439 hp6_2_evidence1439 hp6_2_check1439 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1439,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1438 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1438 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1438 ((10 : Int),(1 : Int)) hp6_2_branches1438 hp6_2_evidence1438 hp6_2_check1438 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1438,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1437 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1437 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1437 ((6 : Int),(2 : Int)) hp6_2_branches1437 hp6_2_evidence1437 hp6_2_check1437 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1437,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1438 T childKnown
  · exact hp6_2_node1439 T childKnown
theorem hp6_2_node1436 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1436 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1436 ((10 : Int),(1 : Int)) hp6_2_branches1436 hp6_2_evidence1436 hp6_2_check1436 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1436,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1435 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1435 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1435 ((6 : Int),(2 : Int)) hp6_2_branches1435 hp6_2_evidence1435 hp6_2_check1435 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1435,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1436 T childKnown
theorem hp6_2_node1434 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1434 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1434 ((5 : Int),(2 : Int)) hp6_2_branches1434 hp6_2_evidence1434 hp6_2_check1434 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1434,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node1435 T childKnown
  · exact hp6_2_node1437 T childKnown
  · exact hp6_2_node1440 T childKnown
  · exact hp6_2_node1441 T childKnown
theorem hp6_2_node1433 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1433 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1433 ((4 : Int),(2 : Int)) hp6_2_branches1433 hp6_2_evidence1433 hp6_2_check1433 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1433,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node1434 T childKnown
  · exact hp6_2_node1442 T childKnown
  · exact hp6_2_node1444 T childKnown
  · exact hp6_2_node1447 T childKnown
  · exact hp6_2_node1448 T childKnown
theorem hp6_2_node1432 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1432 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1432 ((0 : Int),(2 : Int)) hp6_2_branches1432 hp6_2_evidence1432 hp6_2_check1432 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1432,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1431 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1431 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1431 ((0 : Int),(2 : Int)) hp6_2_branches1431 hp6_2_evidence1431 hp6_2_check1431 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1431,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1430 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1430 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1430 ((0 : Int),(1 : Int)) hp6_2_branches1430 hp6_2_evidence1430 hp6_2_check1430 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1430,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1431 T childKnown
  · exact hp6_2_node1432 T childKnown
  · exact hp6_2_node1433 T childKnown
theorem hp6_2_node1429 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1429 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1429 ((2 : Int),(2 : Int)) hp6_2_branches1429 hp6_2_evidence1429 hp6_2_check1429 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1429,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node1430 T childKnown
  · exact hp6_2_node1449 T childKnown
  · exact hp6_2_node1453 T childKnown
  · exact hp6_2_node1487 T childKnown
  · exact hp6_2_node1489 T childKnown
theorem hp6_2_node1428 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1428 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1428 ((8 : Int),(0 : Int)) hp6_2_branches1428 hp6_2_evidence1428 hp6_2_check1428 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1428,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1429 T childKnown
theorem hp6_2_node1427 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1427 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1427 ((3 : Int),(2 : Int)) hp6_2_branches1427 hp6_2_evidence1427 hp6_2_check1427 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1427,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1426 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1426 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1426 ((3 : Int),(2 : Int)) hp6_2_branches1426 hp6_2_evidence1426 hp6_2_check1426 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1426,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1425 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1425 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1425 ((3 : Int),(1 : Int)) hp6_2_branches1425 hp6_2_evidence1425 hp6_2_check1425 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1425,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1426 T childKnown
  · exact hp6_2_node1427 T childKnown
theorem hp6_2_node1424 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1424 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1424 ((8 : Int),(2 : Int)) hp6_2_branches1424 hp6_2_evidence1424 hp6_2_check1424 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1424,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1423 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1423 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1423 ((6 : Int),(2 : Int)) hp6_2_branches1423 hp6_2_evidence1423 hp6_2_check1423 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1423,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1422 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1422 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1422 ((5 : Int),(2 : Int)) hp6_2_branches1422 hp6_2_evidence1422 hp6_2_check1422 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1422,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1421 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1421 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1421 ((5 : Int),(2 : Int)) hp6_2_branches1421 hp6_2_evidence1421 hp6_2_check1421 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1421,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1420 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1420 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1420 ((7 : Int),(2 : Int)) hp6_2_branches1420 hp6_2_evidence1420 hp6_2_check1420 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1420,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node1421 T childKnown
  · exact hp6_2_node1422 T childKnown
  · exact hp6_2_node1423 T childKnown
  · exact hp6_2_node1424 T childKnown
theorem hp6_2_node1419 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1419 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1419 ((8 : Int),(0 : Int)) hp6_2_branches1419 hp6_2_evidence1419 hp6_2_check1419 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1419,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1420 T childKnown
theorem hp6_2_node1418 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1418 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1418 ((3 : Int),(1 : Int)) hp6_2_branches1418 hp6_2_evidence1418 hp6_2_check1418 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1418,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1419 T childKnown
theorem hp6_2_node1417 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1417 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1417 ((3 : Int),(2 : Int)) hp6_2_branches1417 hp6_2_evidence1417 hp6_2_check1417 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1417,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1416 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1416 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1416 ((3 : Int),(1 : Int)) hp6_2_branches1416 hp6_2_evidence1416 hp6_2_check1416 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1416,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1417 T childKnown
theorem hp6_2_node1415 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1415 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1415 ((0 : Int),(2 : Int)) hp6_2_branches1415 hp6_2_evidence1415 hp6_2_check1415 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1415,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1414 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1414 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1414 ((4 : Int),(2 : Int)) hp6_2_branches1414 hp6_2_evidence1414 hp6_2_check1414 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1414,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1413 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1413 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1413 ((4 : Int),(2 : Int)) hp6_2_branches1413 hp6_2_evidence1413 hp6_2_check1413 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1413,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1412 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1412 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1412 ((3 : Int),(2 : Int)) hp6_2_branches1412 hp6_2_evidence1412 hp6_2_check1412 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1412,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1413 T childKnown
  · exact hp6_2_node1414 T childKnown
theorem hp6_2_node1411 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1411 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1411 ((8 : Int),(0 : Int)) hp6_2_branches1411 hp6_2_evidence1411 hp6_2_check1411 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1411,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1412 T childKnown
theorem hp6_2_node1410 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1410 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1410 ((11 : Int),(1 : Int)) hp6_2_branches1410 hp6_2_evidence1410 hp6_2_check1410 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1410,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1409 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1409 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1409 ((11 : Int),(1 : Int)) hp6_2_branches1409 hp6_2_evidence1409 hp6_2_check1409 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1409,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1408 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1408 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1408 ((11 : Int),(1 : Int)) hp6_2_branches1408 hp6_2_evidence1408 hp6_2_check1408 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1408,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1407 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1407 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1407 ((6 : Int),(2 : Int)) hp6_2_branches1407 hp6_2_evidence1407 hp6_2_check1407 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1407,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1408 T childKnown
theorem hp6_2_node1406 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1406 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1406 ((5 : Int),(2 : Int)) hp6_2_branches1406 hp6_2_evidence1406 hp6_2_check1406 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1406,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1407 T childKnown
  · exact hp6_2_node1409 T childKnown
  · exact hp6_2_node1410 T childKnown
theorem hp6_2_node1405 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1405 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1405 ((8 : Int),(0 : Int)) hp6_2_branches1405 hp6_2_evidence1405 hp6_2_check1405 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1405,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1406 T childKnown
theorem hp6_2_node1404 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1404 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1404 ((3 : Int),(2 : Int)) hp6_2_branches1404 hp6_2_evidence1404 hp6_2_check1404 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1404,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1405 T childKnown
theorem hp6_2_node1403 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1403 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1403 ((4 : Int),(2 : Int)) hp6_2_branches1403 hp6_2_evidence1403 hp6_2_check1403 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1403,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1402 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1402 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1402 ((4 : Int),(2 : Int)) hp6_2_branches1402 hp6_2_evidence1402 hp6_2_check1402 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1402,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1401 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1401 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1401 ((4 : Int),(1 : Int)) hp6_2_branches1401 hp6_2_evidence1401 hp6_2_check1401 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1401,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1402 T childKnown
  · exact hp6_2_node1403 T childKnown
theorem hp6_2_node1400 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1400 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1400 ((13 : Int),(1 : Int)) hp6_2_branches1400 hp6_2_evidence1400 hp6_2_check1400 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1400,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1399 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1399 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1399 ((11 : Int),(2 : Int)) hp6_2_branches1399 hp6_2_evidence1399 hp6_2_check1399 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1399,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1398 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1398 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1398 ((11 : Int),(2 : Int)) hp6_2_branches1398 hp6_2_evidence1398 hp6_2_check1398 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1398,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1397 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1397 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1397 ((12 : Int),(1 : Int)) hp6_2_branches1397 hp6_2_evidence1397 hp6_2_check1397 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1397,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1398 T childKnown
  · exact hp6_2_node1399 T childKnown
  · exact hp6_2_node1400 T childKnown
theorem hp6_2_node1396 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1396 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1396 ((8 : Int),(0 : Int)) hp6_2_branches1396 hp6_2_evidence1396 hp6_2_check1396 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1396,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1397 T childKnown
theorem hp6_2_node1395 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1395 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1395 ((4 : Int),(1 : Int)) hp6_2_branches1395 hp6_2_evidence1395 hp6_2_check1395 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1395,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1396 T childKnown
theorem hp6_2_node1394 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1394 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1394 ((3 : Int),(1 : Int)) hp6_2_branches1394 hp6_2_evidence1394 hp6_2_check1394 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1394,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node1395 T childKnown
  · exact hp6_2_node1401 T childKnown
  · exact hp6_2_node1404 T childKnown
  · exact hp6_2_node1411 T childKnown
theorem hp6_2_node1393 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1393 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1393 ((4 : Int),(2 : Int)) hp6_2_branches1393 hp6_2_evidence1393 hp6_2_check1393 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1393,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1392 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1392 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1392 ((4 : Int),(2 : Int)) hp6_2_branches1392 hp6_2_evidence1392 hp6_2_check1392 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1392,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1391 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1391 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1391 ((3 : Int),(2 : Int)) hp6_2_branches1391 hp6_2_evidence1391 hp6_2_check1391 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1391,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1392 T childKnown
  · exact hp6_2_node1393 T childKnown
theorem hp6_2_node1390 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1390 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1390 ((8 : Int),(0 : Int)) hp6_2_branches1390 hp6_2_evidence1390 hp6_2_check1390 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1390,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1391 T childKnown
theorem hp6_2_node1389 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1389 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1389 ((11 : Int),(1 : Int)) hp6_2_branches1389 hp6_2_evidence1389 hp6_2_check1389 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1389,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1388 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1388 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1388 ((11 : Int),(1 : Int)) hp6_2_branches1388 hp6_2_evidence1388 hp6_2_check1388 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1388,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1387 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1387 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1387 ((11 : Int),(1 : Int)) hp6_2_branches1387 hp6_2_evidence1387 hp6_2_check1387 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1387,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1386 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1386 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1386 ((6 : Int),(2 : Int)) hp6_2_branches1386 hp6_2_evidence1386 hp6_2_check1386 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1386,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1387 T childKnown
theorem hp6_2_node1385 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1385 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1385 ((5 : Int),(2 : Int)) hp6_2_branches1385 hp6_2_evidence1385 hp6_2_check1385 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1385,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1386 T childKnown
  · exact hp6_2_node1388 T childKnown
  · exact hp6_2_node1389 T childKnown
theorem hp6_2_node1384 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1384 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1384 ((8 : Int),(0 : Int)) hp6_2_branches1384 hp6_2_evidence1384 hp6_2_check1384 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1384,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1385 T childKnown
theorem hp6_2_node1383 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1383 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1383 ((3 : Int),(2 : Int)) hp6_2_branches1383 hp6_2_evidence1383 hp6_2_check1383 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1383,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1384 T childKnown
theorem hp6_2_node1382 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1382 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1382 ((4 : Int),(2 : Int)) hp6_2_branches1382 hp6_2_evidence1382 hp6_2_check1382 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1382,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1381 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1381 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1381 ((4 : Int),(2 : Int)) hp6_2_branches1381 hp6_2_evidence1381 hp6_2_check1381 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1381,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1380 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1380 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1380 ((4 : Int),(1 : Int)) hp6_2_branches1380 hp6_2_evidence1380 hp6_2_check1380 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1380,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1381 T childKnown
  · exact hp6_2_node1382 T childKnown
theorem hp6_2_node1379 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1379 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1379 ((13 : Int),(1 : Int)) hp6_2_branches1379 hp6_2_evidence1379 hp6_2_check1379 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1379,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1378 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1378 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1378 ((11 : Int),(2 : Int)) hp6_2_branches1378 hp6_2_evidence1378 hp6_2_check1378 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1378,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1377 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1377 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1377 ((11 : Int),(2 : Int)) hp6_2_branches1377 hp6_2_evidence1377 hp6_2_check1377 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1377,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1376 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1376 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1376 ((12 : Int),(1 : Int)) hp6_2_branches1376 hp6_2_evidence1376 hp6_2_check1376 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1376,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1377 T childKnown
  · exact hp6_2_node1378 T childKnown
  · exact hp6_2_node1379 T childKnown
theorem hp6_2_node1375 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1375 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1375 ((8 : Int),(0 : Int)) hp6_2_branches1375 hp6_2_evidence1375 hp6_2_check1375 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1375,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1376 T childKnown
theorem hp6_2_node1374 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1374 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1374 ((4 : Int),(1 : Int)) hp6_2_branches1374 hp6_2_evidence1374 hp6_2_check1374 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1374,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1375 T childKnown
theorem hp6_2_node1373 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1373 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1373 ((3 : Int),(1 : Int)) hp6_2_branches1373 hp6_2_evidence1373 hp6_2_check1373 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1373,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node1374 T childKnown
  · exact hp6_2_node1380 T childKnown
  · exact hp6_2_node1383 T childKnown
  · exact hp6_2_node1390 T childKnown
theorem hp6_2_node1372 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1372 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1372 ((0 : Int),(2 : Int)) hp6_2_branches1372 hp6_2_evidence1372 hp6_2_check1372 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1372,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1373 T childKnown
theorem hp6_2_node1371 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1371 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1371 ((4 : Int),(2 : Int)) hp6_2_branches1371 hp6_2_evidence1371 hp6_2_check1371 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1371,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1370 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1370 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1370 ((4 : Int),(2 : Int)) hp6_2_branches1370 hp6_2_evidence1370 hp6_2_check1370 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1370,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1369 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1369 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1369 ((3 : Int),(2 : Int)) hp6_2_branches1369 hp6_2_evidence1369 hp6_2_check1369 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1369,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1370 T childKnown
  · exact hp6_2_node1371 T childKnown
theorem hp6_2_node1368 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1368 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1368 ((8 : Int),(0 : Int)) hp6_2_branches1368 hp6_2_evidence1368 hp6_2_check1368 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1368,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1369 T childKnown
theorem hp6_2_node1367 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1367 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1367 ((11 : Int),(1 : Int)) hp6_2_branches1367 hp6_2_evidence1367 hp6_2_check1367 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1367,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1366 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1366 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1366 ((11 : Int),(1 : Int)) hp6_2_branches1366 hp6_2_evidence1366 hp6_2_check1366 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1366,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1365 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1365 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1365 ((11 : Int),(1 : Int)) hp6_2_branches1365 hp6_2_evidence1365 hp6_2_check1365 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1365,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1364 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1364 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1364 ((6 : Int),(2 : Int)) hp6_2_branches1364 hp6_2_evidence1364 hp6_2_check1364 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1364,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1365 T childKnown
theorem hp6_2_node1363 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1363 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1363 ((5 : Int),(2 : Int)) hp6_2_branches1363 hp6_2_evidence1363 hp6_2_check1363 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1363,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1364 T childKnown
  · exact hp6_2_node1366 T childKnown
  · exact hp6_2_node1367 T childKnown
theorem hp6_2_node1362 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1362 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1362 ((8 : Int),(0 : Int)) hp6_2_branches1362 hp6_2_evidence1362 hp6_2_check1362 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1362,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1363 T childKnown
theorem hp6_2_node1361 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1361 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1361 ((3 : Int),(2 : Int)) hp6_2_branches1361 hp6_2_evidence1361 hp6_2_check1361 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1361,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1362 T childKnown
theorem hp6_2_node1360 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1360 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1360 ((4 : Int),(2 : Int)) hp6_2_branches1360 hp6_2_evidence1360 hp6_2_check1360 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1360,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1359 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1359 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1359 ((4 : Int),(2 : Int)) hp6_2_branches1359 hp6_2_evidence1359 hp6_2_check1359 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1359,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1358 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1358 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1358 ((4 : Int),(1 : Int)) hp6_2_branches1358 hp6_2_evidence1358 hp6_2_check1358 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1358,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1359 T childKnown
  · exact hp6_2_node1360 T childKnown
theorem hp6_2_node1357 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1357 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1357 ((13 : Int),(1 : Int)) hp6_2_branches1357 hp6_2_evidence1357 hp6_2_check1357 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1357,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1356 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1356 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1356 ((11 : Int),(2 : Int)) hp6_2_branches1356 hp6_2_evidence1356 hp6_2_check1356 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1356,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1355 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1355 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1355 ((11 : Int),(2 : Int)) hp6_2_branches1355 hp6_2_evidence1355 hp6_2_check1355 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1355,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1354 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1354 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1354 ((12 : Int),(1 : Int)) hp6_2_branches1354 hp6_2_evidence1354 hp6_2_check1354 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1354,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1355 T childKnown
  · exact hp6_2_node1356 T childKnown
  · exact hp6_2_node1357 T childKnown
theorem hp6_2_node1353 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1353 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1353 ((8 : Int),(0 : Int)) hp6_2_branches1353 hp6_2_evidence1353 hp6_2_check1353 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1353,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1354 T childKnown
theorem hp6_2_node1352 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1352 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1352 ((4 : Int),(1 : Int)) hp6_2_branches1352 hp6_2_evidence1352 hp6_2_check1352 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1352,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1353 T childKnown
theorem hp6_2_node1351 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1351 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1351 ((3 : Int),(1 : Int)) hp6_2_branches1351 hp6_2_evidence1351 hp6_2_check1351 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1351,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node1352 T childKnown
  · exact hp6_2_node1358 T childKnown
  · exact hp6_2_node1361 T childKnown
  · exact hp6_2_node1368 T childKnown
theorem hp6_2_node1350 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1350 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1350 ((0 : Int),(2 : Int)) hp6_2_branches1350 hp6_2_evidence1350 hp6_2_check1350 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1350,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1351 T childKnown
theorem hp6_2_node1349 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1349 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1349 ((0 : Int),(1 : Int)) hp6_2_branches1349 hp6_2_evidence1349 hp6_2_check1349 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1349,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node1350 T childKnown
  · exact hp6_2_node1372 T childKnown
  · exact hp6_2_node1394 T childKnown
  · exact hp6_2_node1415 T childKnown
theorem hp6_2_node1348 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1348 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1348 ((0 : Int),(2 : Int)) hp6_2_branches1348 hp6_2_evidence1348 hp6_2_check1348 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1348,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1347 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1347 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1347 ((0 : Int),(1 : Int)) hp6_2_branches1347 hp6_2_evidence1347 hp6_2_check1347 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1347,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1348 T childKnown
theorem hp6_2_node1346 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1346 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1346 ((2 : Int),(1 : Int)) hp6_2_branches1346 hp6_2_evidence1346 hp6_2_check1346 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1346,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node1347 T childKnown
  · exact hp6_2_node1349 T childKnown
  · exact hp6_2_node1416 T childKnown
  · exact hp6_2_node1418 T childKnown
  · exact hp6_2_node1425 T childKnown
  · exact hp6_2_node1428 T childKnown
  · exact hp6_2_node1494 T childKnown
theorem hp6_2_node1345 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1345 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1345 ((1 : Int),(1 : Int)) hp6_2_branches1345 hp6_2_evidence1345 hp6_2_check1345 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1345,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1344 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1344 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1344 ((1 : Int),(1 : Int)) hp6_2_branches1344 hp6_2_evidence1344 hp6_2_check1344 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1344,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1343 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1343 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1343 ((1 : Int),(0 : Int)) hp6_2_branches1343 hp6_2_evidence1343 hp6_2_check1343 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1343,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1344 T childKnown
  · exact hp6_2_node1345 T childKnown
theorem hp6_2_node1342 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1342 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1342 ((5 : Int),(1 : Int)) hp6_2_branches1342 hp6_2_evidence1342 hp6_2_check1342 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1342,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1341 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1341 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1341 ((5 : Int),(1 : Int)) hp6_2_branches1341 hp6_2_evidence1341 hp6_2_check1341 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1341,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1340 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1340 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1340 ((4 : Int),(1 : Int)) hp6_2_branches1340 hp6_2_evidence1340 hp6_2_check1340 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1340,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1341 T childKnown
  · exact hp6_2_node1342 T childKnown
theorem hp6_2_node1339 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1339 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1339 ((3 : Int),(1 : Int)) hp6_2_branches1339 hp6_2_evidence1339 hp6_2_check1339 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1339,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1338 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1338 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1338 ((2 : Int),(2 : Int)) hp6_2_branches1338 hp6_2_evidence1338 hp6_2_check1338 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1338,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1339 T childKnown
theorem hp6_2_node1337 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1337 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1337 ((3 : Int),(1 : Int)) hp6_2_branches1337 hp6_2_evidence1337 hp6_2_check1337 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1337,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1336 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1336 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1336 ((3 : Int),(1 : Int)) hp6_2_branches1336 hp6_2_evidence1336 hp6_2_check1336 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1336,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1335 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1335 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1335 ((3 : Int),(1 : Int)) hp6_2_branches1335 hp6_2_evidence1335 hp6_2_check1335 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1335,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1334 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1334 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1334 ((3 : Int),(1 : Int)) hp6_2_branches1334 hp6_2_evidence1334 hp6_2_check1334 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1334,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1333 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1333 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1333 ((2 : Int),(2 : Int)) hp6_2_branches1333 hp6_2_evidence1333 hp6_2_check1333 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1333,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1334 T childKnown
  · exact hp6_2_node1335 T childKnown
  · exact hp6_2_node1336 T childKnown
theorem hp6_2_node1332 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1332 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1332 ((1 : Int),(2 : Int)) hp6_2_branches1332 hp6_2_evidence1332 hp6_2_check1332 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1332,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node1333 T childKnown
  · exact hp6_2_node1337 T childKnown
  · exact hp6_2_node1338 T childKnown
  · exact hp6_2_node1340 T childKnown
theorem hp6_2_node1331 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1331 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1331 ((1 : Int),(0 : Int)) hp6_2_branches1331 hp6_2_evidence1331 hp6_2_check1331 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1331,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1332 T childKnown
theorem hp6_2_node1330 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1330 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1330 ((1 : Int),(1 : Int)) hp6_2_branches1330 hp6_2_evidence1330 hp6_2_check1330 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1330,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1329 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1329 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1329 ((1 : Int),(0 : Int)) hp6_2_branches1329 hp6_2_evidence1329 hp6_2_check1329 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1329,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1330 T childKnown
theorem hp6_2_node1328 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1328 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1328 ((7 : Int),(1 : Int)) hp6_2_branches1328 hp6_2_evidence1328 hp6_2_check1328 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1328,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1327 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1327 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1327 ((7 : Int),(1 : Int)) hp6_2_branches1327 hp6_2_evidence1327 hp6_2_check1327 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1327,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1326 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1326 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1326 ((7 : Int),(1 : Int)) hp6_2_branches1326 hp6_2_evidence1326 hp6_2_check1326 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1326,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1325 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1325 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1325 ((8 : Int),(1 : Int)) hp6_2_branches1325 hp6_2_evidence1325 hp6_2_check1325 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1325,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1324 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1324 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1324 ((8 : Int),(1 : Int)) hp6_2_branches1324 hp6_2_evidence1324 hp6_2_check1324 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1324,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1323 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1323 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1323 ((7 : Int),(1 : Int)) hp6_2_branches1323 hp6_2_evidence1323 hp6_2_check1323 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1323,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1324 T childKnown
  · exact hp6_2_node1325 T childKnown
theorem hp6_2_node1322 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1322 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1322 ((7 : Int),(1 : Int)) hp6_2_branches1322 hp6_2_evidence1322 hp6_2_check1322 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1322,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1321 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1321 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1321 ((6 : Int),(1 : Int)) hp6_2_branches1321 hp6_2_evidence1321 hp6_2_check1321 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1321,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node1322 T childKnown
  · exact hp6_2_node1323 T childKnown
  · exact hp6_2_node1326 T childKnown
  · exact hp6_2_node1327 T childKnown
  · exact hp6_2_node1328 T childKnown
theorem hp6_2_node1320 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1320 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1320 ((7 : Int),(1 : Int)) hp6_2_branches1320 hp6_2_evidence1320 hp6_2_check1320 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1320,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1319 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1319 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1319 ((7 : Int),(1 : Int)) hp6_2_branches1319 hp6_2_evidence1319 hp6_2_check1319 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1319,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1318 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1318 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1318 ((0 : Int),(2 : Int)) hp6_2_branches1318 hp6_2_evidence1318 hp6_2_check1318 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1318,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1317 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1317 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1317 ((3 : Int),(1 : Int)) hp6_2_branches1317 hp6_2_evidence1317 hp6_2_check1317 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1317,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1318 T childKnown
theorem hp6_2_node1316 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1316 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1316 ((10 : Int),(2 : Int)) hp6_2_branches1316 hp6_2_evidence1316 hp6_2_check1316 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1316,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1315 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1315 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1315 ((9 : Int),(2 : Int)) hp6_2_branches1315 hp6_2_evidence1315 hp6_2_check1315 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1315,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1316 T childKnown
theorem hp6_2_node1314 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1314 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1314 ((17 : Int),(1 : Int)) hp6_2_branches1314 hp6_2_evidence1314 hp6_2_check1314 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1314,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1313 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1313 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1313 ((11 : Int),(2 : Int)) hp6_2_branches1313 hp6_2_evidence1313 hp6_2_check1313 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1313,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1314 T childKnown
theorem hp6_2_node1312 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1312 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1312 ((15 : Int),(0 : Int)) hp6_2_branches1312 hp6_2_evidence1312 hp6_2_check1312 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1312,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1313 T childKnown
theorem hp6_2_node1311 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1311 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1311 ((9 : Int),(2 : Int)) hp6_2_branches1311 hp6_2_evidence1311 hp6_2_check1311 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1311,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1312 T childKnown
theorem hp6_2_node1310 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1310 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1310 ((10 : Int),(2 : Int)) hp6_2_branches1310 hp6_2_evidence1310 hp6_2_check1310 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1310,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1309 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1309 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1309 ((10 : Int),(1 : Int)) hp6_2_branches1309 hp6_2_evidence1309 hp6_2_check1309 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1309,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1310 T childKnown
theorem hp6_2_node1308 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1308 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1308 ((9 : Int),(1 : Int)) hp6_2_branches1308 hp6_2_evidence1308 hp6_2_check1308 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1308,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1309 T childKnown
  · exact hp6_2_node1311 T childKnown
  · exact hp6_2_node1315 T childKnown
theorem hp6_2_node1307 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1307 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1307 ((10 : Int),(2 : Int)) hp6_2_branches1307 hp6_2_evidence1307 hp6_2_check1307 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1307,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1306 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1306 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1306 ((9 : Int),(2 : Int)) hp6_2_branches1306 hp6_2_evidence1306 hp6_2_check1306 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1306,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1307 T childKnown
theorem hp6_2_node1305 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1305 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1305 ((17 : Int),(1 : Int)) hp6_2_branches1305 hp6_2_evidence1305 hp6_2_check1305 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1305,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1304 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1304 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1304 ((11 : Int),(2 : Int)) hp6_2_branches1304 hp6_2_evidence1304 hp6_2_check1304 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1304,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1305 T childKnown
theorem hp6_2_node1303 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1303 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1303 ((15 : Int),(0 : Int)) hp6_2_branches1303 hp6_2_evidence1303 hp6_2_check1303 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1303,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1304 T childKnown
theorem hp6_2_node1302 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1302 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1302 ((9 : Int),(2 : Int)) hp6_2_branches1302 hp6_2_evidence1302 hp6_2_check1302 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1302,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1303 T childKnown
theorem hp6_2_node1301 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1301 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1301 ((10 : Int),(2 : Int)) hp6_2_branches1301 hp6_2_evidence1301 hp6_2_check1301 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1301,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1300 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1300 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1300 ((10 : Int),(1 : Int)) hp6_2_branches1300 hp6_2_evidence1300 hp6_2_check1300 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1300,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1301 T childKnown
theorem hp6_2_node1299 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1299 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1299 ((9 : Int),(1 : Int)) hp6_2_branches1299 hp6_2_evidence1299 hp6_2_check1299 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1299,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1300 T childKnown
  · exact hp6_2_node1302 T childKnown
  · exact hp6_2_node1306 T childKnown
theorem hp6_2_node1298 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1298 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1298 ((2 : Int),(2 : Int)) hp6_2_branches1298 hp6_2_evidence1298 hp6_2_check1298 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1298,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1299 T childKnown
  · exact hp6_2_node1308 T childKnown
theorem hp6_2_node1297 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1297 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1297 ((4 : Int),(2 : Int)) hp6_2_branches1297 hp6_2_evidence1297 hp6_2_check1297 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1297,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1298 T childKnown
theorem hp6_2_node1296 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1296 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1296 ((0 : Int),(2 : Int)) hp6_2_branches1296 hp6_2_evidence1296 hp6_2_check1296 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1296,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1295 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1295 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1295 ((4 : Int),(2 : Int)) hp6_2_branches1295 hp6_2_evidence1295 hp6_2_check1295 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1295,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1296 T childKnown
theorem hp6_2_node1294 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1294 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1294 ((4 : Int),(1 : Int)) hp6_2_branches1294 hp6_2_evidence1294 hp6_2_check1294 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1294,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1295 T childKnown
  · exact hp6_2_node1297 T childKnown
  · exact hp6_2_node1317 T childKnown
theorem hp6_2_node1293 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1293 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1293 ((7 : Int),(1 : Int)) hp6_2_branches1293 hp6_2_evidence1293 hp6_2_check1293 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1293,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1294 T childKnown
theorem hp6_2_node1292 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1292 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1292 ((7 : Int),(1 : Int)) hp6_2_branches1292 hp6_2_evidence1292 hp6_2_check1292 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1292,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1291 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1291 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1291 ((6 : Int),(1 : Int)) hp6_2_branches1291 hp6_2_evidence1291 hp6_2_check1291 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1291,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node1292 T childKnown
  · exact hp6_2_node1293 T childKnown
  · exact hp6_2_node1319 T childKnown
  · exact hp6_2_node1320 T childKnown
theorem hp6_2_node1290 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1290 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1290 ((8 : Int),(1 : Int)) hp6_2_branches1290 hp6_2_evidence1290 hp6_2_check1290 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1290,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1289 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1289 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1289 ((8 : Int),(1 : Int)) hp6_2_branches1289 hp6_2_evidence1289 hp6_2_check1289 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1289,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1288 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1288 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1288 ((8 : Int),(0 : Int)) hp6_2_branches1288 hp6_2_evidence1288 hp6_2_check1288 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1288,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1289 T childKnown
  · exact hp6_2_node1290 T childKnown
theorem hp6_2_node1287 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1287 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1287 ((6 : Int),(1 : Int)) hp6_2_branches1287 hp6_2_evidence1287 hp6_2_check1287 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1287,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1288 T childKnown
theorem hp6_2_node1286 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1286 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1286 ((0 : Int),(2 : Int)) hp6_2_branches1286 hp6_2_evidence1286 hp6_2_check1286 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1286,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1285 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1285 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1285 ((3 : Int),(1 : Int)) hp6_2_branches1285 hp6_2_evidence1285 hp6_2_check1285 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1285,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1286 T childKnown
theorem hp6_2_node1284 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1284 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1284 ((12 : Int),(1 : Int)) hp6_2_branches1284 hp6_2_evidence1284 hp6_2_check1284 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1284,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1283 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1283 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1283 ((12 : Int),(1 : Int)) hp6_2_branches1283 hp6_2_evidence1283 hp6_2_check1283 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1283,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1282 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1282 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1282 ((11 : Int),(1 : Int)) hp6_2_branches1282 hp6_2_evidence1282 hp6_2_check1282 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1282,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1283 T childKnown
  · exact hp6_2_node1284 T childKnown
theorem hp6_2_node1281 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1281 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1281 ((10 : Int),(1 : Int)) hp6_2_branches1281 hp6_2_evidence1281 hp6_2_check1281 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1281,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1280 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1280 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1280 ((9 : Int),(2 : Int)) hp6_2_branches1280 hp6_2_evidence1280 hp6_2_check1280 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1280,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1281 T childKnown
theorem hp6_2_node1279 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1279 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1279 ((10 : Int),(1 : Int)) hp6_2_branches1279 hp6_2_evidence1279 hp6_2_check1279 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1279,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1278 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1278 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1278 ((8 : Int),(2 : Int)) hp6_2_branches1278 hp6_2_evidence1278 hp6_2_check1278 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1278,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1279 T childKnown
  · exact hp6_2_node1280 T childKnown
  · exact hp6_2_node1282 T childKnown
theorem hp6_2_node1277 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1277 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1277 ((12 : Int),(1 : Int)) hp6_2_branches1277 hp6_2_evidence1277 hp6_2_check1277 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1277,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1276 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1276 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1276 ((12 : Int),(1 : Int)) hp6_2_branches1276 hp6_2_evidence1276 hp6_2_check1276 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1276,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1275 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1275 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1275 ((11 : Int),(1 : Int)) hp6_2_branches1275 hp6_2_evidence1275 hp6_2_check1275 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1275,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1276 T childKnown
  · exact hp6_2_node1277 T childKnown
theorem hp6_2_node1274 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1274 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1274 ((10 : Int),(1 : Int)) hp6_2_branches1274 hp6_2_evidence1274 hp6_2_check1274 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1274,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1273 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1273 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1273 ((9 : Int),(2 : Int)) hp6_2_branches1273 hp6_2_evidence1273 hp6_2_check1273 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1273,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1274 T childKnown
theorem hp6_2_node1272 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1272 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1272 ((10 : Int),(1 : Int)) hp6_2_branches1272 hp6_2_evidence1272 hp6_2_check1272 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1272,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1271 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1271 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1271 ((8 : Int),(2 : Int)) hp6_2_branches1271 hp6_2_evidence1271 hp6_2_check1271 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1271,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1272 T childKnown
  · exact hp6_2_node1273 T childKnown
  · exact hp6_2_node1275 T childKnown
theorem hp6_2_node1270 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1270 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1270 ((2 : Int),(2 : Int)) hp6_2_branches1270 hp6_2_evidence1270 hp6_2_check1270 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1270,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1271 T childKnown
  · exact hp6_2_node1278 T childKnown
theorem hp6_2_node1269 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1269 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1269 ((4 : Int),(2 : Int)) hp6_2_branches1269 hp6_2_evidence1269 hp6_2_check1269 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1269,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1270 T childKnown
theorem hp6_2_node1268 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1268 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1268 ((0 : Int),(2 : Int)) hp6_2_branches1268 hp6_2_evidence1268 hp6_2_check1268 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1268,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1267 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1267 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1267 ((4 : Int),(2 : Int)) hp6_2_branches1267 hp6_2_evidence1267 hp6_2_check1267 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1267,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1268 T childKnown
theorem hp6_2_node1266 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1266 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1266 ((4 : Int),(1 : Int)) hp6_2_branches1266 hp6_2_evidence1266 hp6_2_check1266 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1266,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1267 T childKnown
  · exact hp6_2_node1269 T childKnown
  · exact hp6_2_node1285 T childKnown
theorem hp6_2_node1265 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1265 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1265 ((8 : Int),(0 : Int)) hp6_2_branches1265 hp6_2_evidence1265 hp6_2_check1265 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1265,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1266 T childKnown
theorem hp6_2_node1264 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1264 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1264 ((6 : Int),(1 : Int)) hp6_2_branches1264 hp6_2_evidence1264 hp6_2_check1264 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1264,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1265 T childKnown
theorem hp6_2_node1263 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1263 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1263 ((6 : Int),(1 : Int)) hp6_2_branches1263 hp6_2_evidence1263 hp6_2_check1263 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1263,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1262 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1262 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1262 ((6 : Int),(1 : Int)) hp6_2_branches1262 hp6_2_evidence1262 hp6_2_check1262 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1262,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1261 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1261 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1261 ((7 : Int),(0 : Int)) hp6_2_branches1261 hp6_2_evidence1261 hp6_2_check1261 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1261,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node1262 T childKnown
  · exact hp6_2_node1263 T childKnown
  · exact hp6_2_node1264 T childKnown
  · exact hp6_2_node1287 T childKnown
  · exact hp6_2_node1291 T childKnown
  · exact hp6_2_node1321 T childKnown
theorem hp6_2_node1260 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1260 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1260 ((10 : Int),(1 : Int)) hp6_2_branches1260 hp6_2_evidence1260 hp6_2_check1260 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1260,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1259 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1259 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1259 ((10 : Int),(1 : Int)) hp6_2_branches1259 hp6_2_evidence1259 hp6_2_check1259 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1259,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1258 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1258 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1258 ((8 : Int),(2 : Int)) hp6_2_branches1258 hp6_2_evidence1258 hp6_2_check1258 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1258,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1257 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1257 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1257 ((8 : Int),(2 : Int)) hp6_2_branches1257 hp6_2_evidence1257 hp6_2_check1257 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1257,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1256 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1256 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1256 ((9 : Int),(1 : Int)) hp6_2_branches1256 hp6_2_evidence1256 hp6_2_check1256 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1256,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node1257 T childKnown
  · exact hp6_2_node1258 T childKnown
  · exact hp6_2_node1259 T childKnown
  · exact hp6_2_node1260 T childKnown
theorem hp6_2_node1255 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1255 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1255 ((7 : Int),(0 : Int)) hp6_2_branches1255 hp6_2_evidence1255 hp6_2_check1255 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1255,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1256 T childKnown
theorem hp6_2_node1254 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1254 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1254 ((9 : Int),(1 : Int)) hp6_2_branches1254 hp6_2_evidence1254 hp6_2_check1254 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1254,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1253 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1253 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1253 ((9 : Int),(1 : Int)) hp6_2_branches1253 hp6_2_evidence1253 hp6_2_check1253 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1253,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1252 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1252 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1252 ((9 : Int),(1 : Int)) hp6_2_branches1252 hp6_2_evidence1252 hp6_2_check1252 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1252,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1251 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1251 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1251 ((4 : Int),(2 : Int)) hp6_2_branches1251 hp6_2_evidence1251 hp6_2_check1251 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1251,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1252 T childKnown
theorem hp6_2_node1250 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1250 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1250 ((3 : Int),(2 : Int)) hp6_2_branches1250 hp6_2_evidence1250 hp6_2_check1250 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1250,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1251 T childKnown
  · exact hp6_2_node1253 T childKnown
  · exact hp6_2_node1254 T childKnown
theorem hp6_2_node1249 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1249 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1249 ((9 : Int),(1 : Int)) hp6_2_branches1249 hp6_2_evidence1249 hp6_2_check1249 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1249,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1248 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1248 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1248 ((3 : Int),(2 : Int)) hp6_2_branches1248 hp6_2_evidence1248 hp6_2_check1248 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1248,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1249 T childKnown
theorem hp6_2_node1247 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1247 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1247 ((9 : Int),(1 : Int)) hp6_2_branches1247 hp6_2_evidence1247 hp6_2_check1247 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1247,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1246 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1246 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1246 ((9 : Int),(1 : Int)) hp6_2_branches1246 hp6_2_evidence1246 hp6_2_check1246 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1246,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1245 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1245 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1245 ((9 : Int),(1 : Int)) hp6_2_branches1245 hp6_2_evidence1245 hp6_2_check1245 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1245,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1244 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1244 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1244 ((9 : Int),(1 : Int)) hp6_2_branches1244 hp6_2_evidence1244 hp6_2_check1244 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1244,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1243 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1243 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1243 ((4 : Int),(2 : Int)) hp6_2_branches1243 hp6_2_evidence1243 hp6_2_check1243 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1243,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1244 T childKnown
  · exact hp6_2_node1245 T childKnown
theorem hp6_2_node1242 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1242 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1242 ((9 : Int),(1 : Int)) hp6_2_branches1242 hp6_2_evidence1242 hp6_2_check1242 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1242,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1241 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1241 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1241 ((4 : Int),(2 : Int)) hp6_2_branches1241 hp6_2_evidence1241 hp6_2_check1241 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1241,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1242 T childKnown
theorem hp6_2_node1240 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1240 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1240 ((9 : Int),(1 : Int)) hp6_2_branches1240 hp6_2_evidence1240 hp6_2_check1240 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1240,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1239 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1239 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1239 ((4 : Int),(2 : Int)) hp6_2_branches1239 hp6_2_evidence1239 hp6_2_check1239 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1239,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1240 T childKnown
theorem hp6_2_node1238 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1238 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1238 ((3 : Int),(2 : Int)) hp6_2_branches1238 hp6_2_evidence1238 hp6_2_check1238 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1238,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node1239 T childKnown
  · exact hp6_2_node1241 T childKnown
  · exact hp6_2_node1243 T childKnown
  · exact hp6_2_node1246 T childKnown
  · exact hp6_2_node1247 T childKnown
theorem hp6_2_node1237 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1237 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1237 ((9 : Int),(1 : Int)) hp6_2_branches1237 hp6_2_evidence1237 hp6_2_check1237 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1237,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1236 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1236 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1236 ((9 : Int),(1 : Int)) hp6_2_branches1236 hp6_2_evidence1236 hp6_2_check1236 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1236,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1235 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1235 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1235 ((9 : Int),(1 : Int)) hp6_2_branches1235 hp6_2_evidence1235 hp6_2_check1235 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1235,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1234 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1234 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1234 ((9 : Int),(1 : Int)) hp6_2_branches1234 hp6_2_evidence1234 hp6_2_check1234 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1234,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1233 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1233 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1233 ((4 : Int),(2 : Int)) hp6_2_branches1233 hp6_2_evidence1233 hp6_2_check1233 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1233,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1234 T childKnown
  · exact hp6_2_node1235 T childKnown
theorem hp6_2_node1232 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1232 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1232 ((9 : Int),(1 : Int)) hp6_2_branches1232 hp6_2_evidence1232 hp6_2_check1232 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1232,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1231 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1231 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1231 ((4 : Int),(2 : Int)) hp6_2_branches1231 hp6_2_evidence1231 hp6_2_check1231 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1231,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1232 T childKnown
theorem hp6_2_node1230 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1230 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1230 ((9 : Int),(1 : Int)) hp6_2_branches1230 hp6_2_evidence1230 hp6_2_check1230 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1230,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1229 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1229 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1229 ((4 : Int),(2 : Int)) hp6_2_branches1229 hp6_2_evidence1229 hp6_2_check1229 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1229,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1230 T childKnown
theorem hp6_2_node1228 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1228 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1228 ((3 : Int),(2 : Int)) hp6_2_branches1228 hp6_2_evidence1228 hp6_2_check1228 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1228,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node1229 T childKnown
  · exact hp6_2_node1231 T childKnown
  · exact hp6_2_node1233 T childKnown
  · exact hp6_2_node1236 T childKnown
  · exact hp6_2_node1237 T childKnown
theorem hp6_2_node1227 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1227 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1227 ((9 : Int),(1 : Int)) hp6_2_branches1227 hp6_2_evidence1227 hp6_2_check1227 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1227,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1226 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1226 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1226 ((9 : Int),(1 : Int)) hp6_2_branches1226 hp6_2_evidence1226 hp6_2_check1226 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1226,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1225 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1225 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1225 ((9 : Int),(1 : Int)) hp6_2_branches1225 hp6_2_evidence1225 hp6_2_check1225 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1225,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1224 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1224 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1224 ((9 : Int),(1 : Int)) hp6_2_branches1224 hp6_2_evidence1224 hp6_2_check1224 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1224,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1223 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1223 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1223 ((4 : Int),(2 : Int)) hp6_2_branches1223 hp6_2_evidence1223 hp6_2_check1223 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1223,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1224 T childKnown
  · exact hp6_2_node1225 T childKnown
theorem hp6_2_node1222 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1222 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1222 ((9 : Int),(1 : Int)) hp6_2_branches1222 hp6_2_evidence1222 hp6_2_check1222 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1222,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1221 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1221 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1221 ((4 : Int),(2 : Int)) hp6_2_branches1221 hp6_2_evidence1221 hp6_2_check1221 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1221,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1222 T childKnown
theorem hp6_2_node1220 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1220 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1220 ((9 : Int),(1 : Int)) hp6_2_branches1220 hp6_2_evidence1220 hp6_2_check1220 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1220,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1219 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1219 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1219 ((9 : Int),(1 : Int)) hp6_2_branches1219 hp6_2_evidence1219 hp6_2_check1219 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1219,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1218 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1218 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1218 ((9 : Int),(1 : Int)) hp6_2_branches1218 hp6_2_evidence1218 hp6_2_check1218 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1218,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1217 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1217 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1217 ((9 : Int),(1 : Int)) hp6_2_branches1217 hp6_2_evidence1217 hp6_2_check1217 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1217,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1216 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1216 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1216 ((5 : Int),(2 : Int)) hp6_2_branches1216 hp6_2_evidence1216 hp6_2_check1216 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1216,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1217 T childKnown
  · exact hp6_2_node1218 T childKnown
theorem hp6_2_node1215 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1215 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1215 ((9 : Int),(1 : Int)) hp6_2_branches1215 hp6_2_evidence1215 hp6_2_check1215 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1215,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1214 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1214 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1214 ((5 : Int),(2 : Int)) hp6_2_branches1214 hp6_2_evidence1214 hp6_2_check1214 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1214,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1215 T childKnown
theorem hp6_2_node1213 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1213 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1213 ((4 : Int),(2 : Int)) hp6_2_branches1213 hp6_2_evidence1213 hp6_2_check1213 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1213,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node1214 T childKnown
  · exact hp6_2_node1216 T childKnown
  · exact hp6_2_node1219 T childKnown
  · exact hp6_2_node1220 T childKnown
theorem hp6_2_node1212 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1212 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1212 ((3 : Int),(2 : Int)) hp6_2_branches1212 hp6_2_evidence1212 hp6_2_check1212 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1212,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node1213 T childKnown
  · exact hp6_2_node1221 T childKnown
  · exact hp6_2_node1223 T childKnown
  · exact hp6_2_node1226 T childKnown
  · exact hp6_2_node1227 T childKnown
theorem hp6_2_node1211 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1211 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1211 ((1 : Int),(2 : Int)) hp6_2_branches1211 hp6_2_evidence1211 hp6_2_check1211 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1211,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node1212 T childKnown
  · exact hp6_2_node1228 T childKnown
  · exact hp6_2_node1238 T childKnown
  · exact hp6_2_node1248 T childKnown
  · exact hp6_2_node1250 T childKnown
theorem hp6_2_node1210 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1210 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1210 ((7 : Int),(0 : Int)) hp6_2_branches1210 hp6_2_evidence1210 hp6_2_check1210 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1210,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1211 T childKnown
theorem hp6_2_node1209 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1209 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1209 ((2 : Int),(2 : Int)) hp6_2_branches1209 hp6_2_evidence1209 hp6_2_check1209 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1209,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1208 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1208 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1208 ((2 : Int),(2 : Int)) hp6_2_branches1208 hp6_2_evidence1208 hp6_2_check1208 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1208,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1207 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1207 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1207 ((2 : Int),(1 : Int)) hp6_2_branches1207 hp6_2_evidence1207 hp6_2_check1207 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1207,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1208 T childKnown
  · exact hp6_2_node1209 T childKnown
theorem hp6_2_node1206 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1206 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1206 ((7 : Int),(2 : Int)) hp6_2_branches1206 hp6_2_evidence1206 hp6_2_check1206 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1206,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1205 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1205 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1205 ((5 : Int),(2 : Int)) hp6_2_branches1205 hp6_2_evidence1205 hp6_2_check1205 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1205,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1204 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1204 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1204 ((4 : Int),(2 : Int)) hp6_2_branches1204 hp6_2_evidence1204 hp6_2_check1204 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1204,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1203 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1203 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1203 ((4 : Int),(2 : Int)) hp6_2_branches1203 hp6_2_evidence1203 hp6_2_check1203 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1203,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1202 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1202 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1202 ((6 : Int),(2 : Int)) hp6_2_branches1202 hp6_2_evidence1202 hp6_2_check1202 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1202,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node1203 T childKnown
  · exact hp6_2_node1204 T childKnown
  · exact hp6_2_node1205 T childKnown
  · exact hp6_2_node1206 T childKnown
theorem hp6_2_node1201 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1201 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1201 ((7 : Int),(0 : Int)) hp6_2_branches1201 hp6_2_evidence1201 hp6_2_check1201 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1201,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1202 T childKnown
theorem hp6_2_node1200 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1200 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1200 ((2 : Int),(1 : Int)) hp6_2_branches1200 hp6_2_evidence1200 hp6_2_check1200 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1200,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1201 T childKnown
theorem hp6_2_node1199 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1199 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1199 ((2 : Int),(2 : Int)) hp6_2_branches1199 hp6_2_evidence1199 hp6_2_check1199 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1199,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1198 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1198 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1198 ((2 : Int),(1 : Int)) hp6_2_branches1198 hp6_2_evidence1198 hp6_2_check1198 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1198,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1199 T childKnown
theorem hp6_2_node1197 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1197 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1197 ((3 : Int),(2 : Int)) hp6_2_branches1197 hp6_2_evidence1197 hp6_2_check1197 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1197,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1196 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1196 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1196 ((3 : Int),(2 : Int)) hp6_2_branches1196 hp6_2_evidence1196 hp6_2_check1196 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1196,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1195 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1195 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1195 ((2 : Int),(2 : Int)) hp6_2_branches1195 hp6_2_evidence1195 hp6_2_check1195 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1195,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1196 T childKnown
  · exact hp6_2_node1197 T childKnown
theorem hp6_2_node1194 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1194 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1194 ((7 : Int),(0 : Int)) hp6_2_branches1194 hp6_2_evidence1194 hp6_2_check1194 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1194,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1195 T childKnown
theorem hp6_2_node1193 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1193 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1193 ((10 : Int),(1 : Int)) hp6_2_branches1193 hp6_2_evidence1193 hp6_2_check1193 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1193,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1192 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1192 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1192 ((10 : Int),(1 : Int)) hp6_2_branches1192 hp6_2_evidence1192 hp6_2_check1192 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1192,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1191 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1191 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1191 ((10 : Int),(1 : Int)) hp6_2_branches1191 hp6_2_evidence1191 hp6_2_check1191 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1191,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1190 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1190 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1190 ((5 : Int),(2 : Int)) hp6_2_branches1190 hp6_2_evidence1190 hp6_2_check1190 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1190,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1191 T childKnown
theorem hp6_2_node1189 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1189 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1189 ((4 : Int),(2 : Int)) hp6_2_branches1189 hp6_2_evidence1189 hp6_2_check1189 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1189,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1190 T childKnown
  · exact hp6_2_node1192 T childKnown
  · exact hp6_2_node1193 T childKnown
theorem hp6_2_node1188 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1188 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1188 ((7 : Int),(0 : Int)) hp6_2_branches1188 hp6_2_evidence1188 hp6_2_check1188 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1188,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1189 T childKnown
theorem hp6_2_node1187 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1187 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1187 ((2 : Int),(2 : Int)) hp6_2_branches1187 hp6_2_evidence1187 hp6_2_check1187 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1187,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1188 T childKnown
theorem hp6_2_node1186 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1186 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1186 ((3 : Int),(2 : Int)) hp6_2_branches1186 hp6_2_evidence1186 hp6_2_check1186 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1186,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1185 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1185 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1185 ((3 : Int),(2 : Int)) hp6_2_branches1185 hp6_2_evidence1185 hp6_2_check1185 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1185,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1184 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1184 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1184 ((3 : Int),(1 : Int)) hp6_2_branches1184 hp6_2_evidence1184 hp6_2_check1184 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1184,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1185 T childKnown
  · exact hp6_2_node1186 T childKnown
theorem hp6_2_node1183 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1183 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1183 ((12 : Int),(1 : Int)) hp6_2_branches1183 hp6_2_evidence1183 hp6_2_check1183 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1183,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1182 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1182 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1182 ((10 : Int),(2 : Int)) hp6_2_branches1182 hp6_2_evidence1182 hp6_2_check1182 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1182,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1181 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1181 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1181 ((10 : Int),(2 : Int)) hp6_2_branches1181 hp6_2_evidence1181 hp6_2_check1181 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1181,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1180 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1180 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1180 ((11 : Int),(1 : Int)) hp6_2_branches1180 hp6_2_evidence1180 hp6_2_check1180 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1180,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1181 T childKnown
  · exact hp6_2_node1182 T childKnown
  · exact hp6_2_node1183 T childKnown
theorem hp6_2_node1179 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1179 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1179 ((7 : Int),(0 : Int)) hp6_2_branches1179 hp6_2_evidence1179 hp6_2_check1179 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1179,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1180 T childKnown
theorem hp6_2_node1178 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1178 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1178 ((3 : Int),(1 : Int)) hp6_2_branches1178 hp6_2_evidence1178 hp6_2_check1178 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1178,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1179 T childKnown
theorem hp6_2_node1177 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1177 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1177 ((2 : Int),(1 : Int)) hp6_2_branches1177 hp6_2_evidence1177 hp6_2_check1177 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1177,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node1178 T childKnown
  · exact hp6_2_node1184 T childKnown
  · exact hp6_2_node1187 T childKnown
  · exact hp6_2_node1194 T childKnown
theorem hp6_2_node1176 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1176 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1176 ((2 : Int),(2 : Int)) hp6_2_branches1176 hp6_2_evidence1176 hp6_2_check1176 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1176,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1175 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1175 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1175 ((2 : Int),(2 : Int)) hp6_2_branches1175 hp6_2_evidence1175 hp6_2_check1175 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1175,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1174 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1174 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1174 ((2 : Int),(1 : Int)) hp6_2_branches1174 hp6_2_evidence1174 hp6_2_check1174 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1174,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1175 T childKnown
  · exact hp6_2_node1176 T childKnown
theorem hp6_2_node1173 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1173 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1173 ((1 : Int),(1 : Int)) hp6_2_branches1173 hp6_2_evidence1173 hp6_2_check1173 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1173,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node1174 T childKnown
  · exact hp6_2_node1177 T childKnown
  · exact hp6_2_node1198 T childKnown
  · exact hp6_2_node1200 T childKnown
  · exact hp6_2_node1207 T childKnown
  · exact hp6_2_node1210 T childKnown
  · exact hp6_2_node1255 T childKnown
theorem hp6_2_node1172 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1172 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1172 ((2 : Int),(1 : Int)) hp6_2_branches1172 hp6_2_evidence1172 hp6_2_check1172 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1172,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1171 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1171 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1171 ((2 : Int),(1 : Int)) hp6_2_branches1171 hp6_2_evidence1171 hp6_2_check1171 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1171,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1170 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1170 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1170 ((1 : Int),(1 : Int)) hp6_2_branches1170 hp6_2_evidence1170 hp6_2_check1170 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1170,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1171 T childKnown
  · exact hp6_2_node1172 T childKnown
theorem hp6_2_node1169 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1169 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1169 ((4 : Int),(2 : Int)) hp6_2_branches1169 hp6_2_evidence1169 hp6_2_check1169 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1169,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1168 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1168 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1168 ((3 : Int),(2 : Int)) hp6_2_branches1168 hp6_2_evidence1168 hp6_2_check1168 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1168,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1169 T childKnown
theorem hp6_2_node1167 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1167 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1167 ((11 : Int),(1 : Int)) hp6_2_branches1167 hp6_2_evidence1167 hp6_2_check1167 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1167,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1166 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1166 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1166 ((5 : Int),(2 : Int)) hp6_2_branches1166 hp6_2_evidence1166 hp6_2_check1166 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1166,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1167 T childKnown
theorem hp6_2_node1165 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1165 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1165 ((9 : Int),(0 : Int)) hp6_2_branches1165 hp6_2_evidence1165 hp6_2_check1165 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1165,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1166 T childKnown
theorem hp6_2_node1164 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1164 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1164 ((3 : Int),(2 : Int)) hp6_2_branches1164 hp6_2_evidence1164 hp6_2_check1164 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1164,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1165 T childKnown
theorem hp6_2_node1163 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1163 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1163 ((4 : Int),(2 : Int)) hp6_2_branches1163 hp6_2_evidence1163 hp6_2_check1163 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1163,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1162 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1162 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1162 ((4 : Int),(1 : Int)) hp6_2_branches1162 hp6_2_evidence1162 hp6_2_check1162 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1162,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1163 T childKnown
theorem hp6_2_node1161 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1161 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1161 ((3 : Int),(1 : Int)) hp6_2_branches1161 hp6_2_evidence1161 hp6_2_check1161 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1161,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1162 T childKnown
  · exact hp6_2_node1164 T childKnown
  · exact hp6_2_node1168 T childKnown
theorem hp6_2_node1160 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1160 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1160 ((1 : Int),(1 : Int)) hp6_2_branches1160 hp6_2_evidence1160 hp6_2_check1160 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1160,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1161 T childKnown
theorem hp6_2_node1159 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1159 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1159 ((2 : Int),(1 : Int)) hp6_2_branches1159 hp6_2_evidence1159 hp6_2_check1159 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1159,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1158 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1158 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1158 ((2 : Int),(1 : Int)) hp6_2_branches1158 hp6_2_evidence1158 hp6_2_check1158 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1158,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1157 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1157 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1157 ((2 : Int),(0 : Int)) hp6_2_branches1157 hp6_2_evidence1157 hp6_2_check1157 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1157,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1158 T childKnown
  · exact hp6_2_node1159 T childKnown
theorem hp6_2_node1156 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1156 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1156 ((6 : Int),(1 : Int)) hp6_2_branches1156 hp6_2_evidence1156 hp6_2_check1156 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1156,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1155 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1155 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1155 ((6 : Int),(1 : Int)) hp6_2_branches1155 hp6_2_evidence1155 hp6_2_check1155 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1155,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1154 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1154 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1154 ((5 : Int),(1 : Int)) hp6_2_branches1154 hp6_2_evidence1154 hp6_2_check1154 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1154,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1155 T childKnown
  · exact hp6_2_node1156 T childKnown
theorem hp6_2_node1153 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1153 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1153 ((4 : Int),(1 : Int)) hp6_2_branches1153 hp6_2_evidence1153 hp6_2_check1153 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1153,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1152 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1152 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1152 ((3 : Int),(2 : Int)) hp6_2_branches1152 hp6_2_evidence1152 hp6_2_check1152 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1152,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1153 T childKnown
theorem hp6_2_node1151 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1151 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1151 ((4 : Int),(1 : Int)) hp6_2_branches1151 hp6_2_evidence1151 hp6_2_check1151 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1151,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1150 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1150 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1150 ((4 : Int),(1 : Int)) hp6_2_branches1150 hp6_2_evidence1150 hp6_2_check1150 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1150,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1149 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1149 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1149 ((4 : Int),(1 : Int)) hp6_2_branches1149 hp6_2_evidence1149 hp6_2_check1149 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1149,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1148 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1148 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1148 ((4 : Int),(1 : Int)) hp6_2_branches1148 hp6_2_evidence1148 hp6_2_check1148 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1148,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1147 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1147 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1147 ((3 : Int),(2 : Int)) hp6_2_branches1147 hp6_2_evidence1147 hp6_2_check1147 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1147,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1148 T childKnown
  · exact hp6_2_node1149 T childKnown
  · exact hp6_2_node1150 T childKnown
theorem hp6_2_node1146 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1146 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1146 ((2 : Int),(2 : Int)) hp6_2_branches1146 hp6_2_evidence1146 hp6_2_check1146 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1146,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node1147 T childKnown
  · exact hp6_2_node1151 T childKnown
  · exact hp6_2_node1152 T childKnown
  · exact hp6_2_node1154 T childKnown
theorem hp6_2_node1145 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1145 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1145 ((2 : Int),(0 : Int)) hp6_2_branches1145 hp6_2_evidence1145 hp6_2_check1145 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1145,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1146 T childKnown
theorem hp6_2_node1144 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1144 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1144 ((1 : Int),(0 : Int)) hp6_2_branches1144 hp6_2_evidence1144 hp6_2_check1144 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1144,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node1145 T childKnown
  · exact hp6_2_node1157 T childKnown
  · exact hp6_2_node1160 T childKnown
  · exact hp6_2_node1170 T childKnown
theorem hp6_2_node1143 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1143 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1143 ((2 : Int),(1 : Int)) hp6_2_branches1143 hp6_2_evidence1143 hp6_2_check1143 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1143,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1142 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1142 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1142 ((2 : Int),(1 : Int)) hp6_2_branches1142 hp6_2_evidence1142 hp6_2_check1142 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1142,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1141 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1141 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1141 ((1 : Int),(1 : Int)) hp6_2_branches1141 hp6_2_evidence1141 hp6_2_check1141 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1141,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1142 T childKnown
  · exact hp6_2_node1143 T childKnown
theorem hp6_2_node1140 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1140 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1140 ((4 : Int),(2 : Int)) hp6_2_branches1140 hp6_2_evidence1140 hp6_2_check1140 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1140,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1139 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1139 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1139 ((3 : Int),(2 : Int)) hp6_2_branches1139 hp6_2_evidence1139 hp6_2_check1139 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1139,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1140 T childKnown
theorem hp6_2_node1138 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1138 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1138 ((11 : Int),(1 : Int)) hp6_2_branches1138 hp6_2_evidence1138 hp6_2_check1138 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1138,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1137 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1137 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1137 ((5 : Int),(2 : Int)) hp6_2_branches1137 hp6_2_evidence1137 hp6_2_check1137 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1137,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1138 T childKnown
theorem hp6_2_node1136 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1136 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1136 ((9 : Int),(0 : Int)) hp6_2_branches1136 hp6_2_evidence1136 hp6_2_check1136 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1136,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1137 T childKnown
theorem hp6_2_node1135 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1135 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1135 ((3 : Int),(2 : Int)) hp6_2_branches1135 hp6_2_evidence1135 hp6_2_check1135 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1135,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1136 T childKnown
theorem hp6_2_node1134 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1134 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1134 ((4 : Int),(2 : Int)) hp6_2_branches1134 hp6_2_evidence1134 hp6_2_check1134 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1134,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1133 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1133 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1133 ((4 : Int),(1 : Int)) hp6_2_branches1133 hp6_2_evidence1133 hp6_2_check1133 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1133,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1134 T childKnown
theorem hp6_2_node1132 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1132 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1132 ((3 : Int),(1 : Int)) hp6_2_branches1132 hp6_2_evidence1132 hp6_2_check1132 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1132,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1133 T childKnown
  · exact hp6_2_node1135 T childKnown
  · exact hp6_2_node1139 T childKnown
theorem hp6_2_node1131 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1131 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1131 ((1 : Int),(1 : Int)) hp6_2_branches1131 hp6_2_evidence1131 hp6_2_check1131 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1131,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1132 T childKnown
theorem hp6_2_node1130 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1130 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1130 ((2 : Int),(1 : Int)) hp6_2_branches1130 hp6_2_evidence1130 hp6_2_check1130 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1130,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1129 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1129 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1129 ((2 : Int),(1 : Int)) hp6_2_branches1129 hp6_2_evidence1129 hp6_2_check1129 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1129,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1128 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1128 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1128 ((2 : Int),(0 : Int)) hp6_2_branches1128 hp6_2_evidence1128 hp6_2_check1128 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1128,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1129 T childKnown
  · exact hp6_2_node1130 T childKnown
theorem hp6_2_node1127 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1127 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1127 ((6 : Int),(1 : Int)) hp6_2_branches1127 hp6_2_evidence1127 hp6_2_check1127 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1127,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1126 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1126 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1126 ((6 : Int),(1 : Int)) hp6_2_branches1126 hp6_2_evidence1126 hp6_2_check1126 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1126,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1125 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1125 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1125 ((5 : Int),(1 : Int)) hp6_2_branches1125 hp6_2_evidence1125 hp6_2_check1125 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1125,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1126 T childKnown
  · exact hp6_2_node1127 T childKnown
theorem hp6_2_node1124 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1124 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1124 ((4 : Int),(1 : Int)) hp6_2_branches1124 hp6_2_evidence1124 hp6_2_check1124 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1124,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1123 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1123 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1123 ((3 : Int),(2 : Int)) hp6_2_branches1123 hp6_2_evidence1123 hp6_2_check1123 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1123,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1124 T childKnown
theorem hp6_2_node1122 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1122 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1122 ((4 : Int),(1 : Int)) hp6_2_branches1122 hp6_2_evidence1122 hp6_2_check1122 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1122,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1121 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1121 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1121 ((4 : Int),(1 : Int)) hp6_2_branches1121 hp6_2_evidence1121 hp6_2_check1121 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1121,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1120 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1120 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1120 ((4 : Int),(1 : Int)) hp6_2_branches1120 hp6_2_evidence1120 hp6_2_check1120 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1120,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1119 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1119 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1119 ((4 : Int),(1 : Int)) hp6_2_branches1119 hp6_2_evidence1119 hp6_2_check1119 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1119,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1118 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1118 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1118 ((3 : Int),(2 : Int)) hp6_2_branches1118 hp6_2_evidence1118 hp6_2_check1118 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1118,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1119 T childKnown
  · exact hp6_2_node1120 T childKnown
  · exact hp6_2_node1121 T childKnown
theorem hp6_2_node1117 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1117 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1117 ((2 : Int),(2 : Int)) hp6_2_branches1117 hp6_2_evidence1117 hp6_2_check1117 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1117,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node1118 T childKnown
  · exact hp6_2_node1122 T childKnown
  · exact hp6_2_node1123 T childKnown
  · exact hp6_2_node1125 T childKnown
theorem hp6_2_node1116 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1116 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1116 ((2 : Int),(0 : Int)) hp6_2_branches1116 hp6_2_evidence1116 hp6_2_check1116 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1116,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1117 T childKnown
theorem hp6_2_node1115 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1115 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1115 ((1 : Int),(0 : Int)) hp6_2_branches1115 hp6_2_evidence1115 hp6_2_check1115 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1115,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node1116 T childKnown
  · exact hp6_2_node1128 T childKnown
  · exact hp6_2_node1131 T childKnown
  · exact hp6_2_node1141 T childKnown
theorem hp6_2_node1114 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1114 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1114 ((6 : Int),(1 : Int)) hp6_2_branches1114 hp6_2_evidence1114 hp6_2_check1114 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1114,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1113 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1113 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1113 ((6 : Int),(1 : Int)) hp6_2_branches1113 hp6_2_evidence1113 hp6_2_check1113 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1113,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1112 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1112 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1112 ((6 : Int),(1 : Int)) hp6_2_branches1112 hp6_2_evidence1112 hp6_2_check1112 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1112,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1111 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1111 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1111 ((7 : Int),(1 : Int)) hp6_2_branches1111 hp6_2_evidence1111 hp6_2_check1111 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1111,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1110 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1110 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1110 ((7 : Int),(1 : Int)) hp6_2_branches1110 hp6_2_evidence1110 hp6_2_check1110 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1110,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1109 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1109 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1109 ((6 : Int),(1 : Int)) hp6_2_branches1109 hp6_2_evidence1109 hp6_2_check1109 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1109,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1110 T childKnown
  · exact hp6_2_node1111 T childKnown
theorem hp6_2_node1108 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1108 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1108 ((6 : Int),(1 : Int)) hp6_2_branches1108 hp6_2_evidence1108 hp6_2_check1108 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1108,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1107 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1107 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1107 ((5 : Int),(1 : Int)) hp6_2_branches1107 hp6_2_evidence1107 hp6_2_check1107 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1107,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node1108 T childKnown
  · exact hp6_2_node1109 T childKnown
  · exact hp6_2_node1112 T childKnown
  · exact hp6_2_node1113 T childKnown
  · exact hp6_2_node1114 T childKnown
theorem hp6_2_node1106 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1106 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1106 ((6 : Int),(1 : Int)) hp6_2_branches1106 hp6_2_evidence1106 hp6_2_check1106 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1106,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1105 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1105 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1105 ((6 : Int),(1 : Int)) hp6_2_branches1105 hp6_2_evidence1105 hp6_2_check1105 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1105,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1104 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1104 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1104 ((0 : Int),(2 : Int)) hp6_2_branches1104 hp6_2_evidence1104 hp6_2_check1104 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1104,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1103 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1103 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1103 ((2 : Int),(1 : Int)) hp6_2_branches1103 hp6_2_evidence1103 hp6_2_check1103 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1103,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1104 T childKnown
theorem hp6_2_node1102 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1102 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1102 ((9 : Int),(2 : Int)) hp6_2_branches1102 hp6_2_evidence1102 hp6_2_check1102 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1102,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1101 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1101 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1101 ((8 : Int),(2 : Int)) hp6_2_branches1101 hp6_2_evidence1101 hp6_2_check1101 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1101,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1102 T childKnown
theorem hp6_2_node1100 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1100 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1100 ((16 : Int),(1 : Int)) hp6_2_branches1100 hp6_2_evidence1100 hp6_2_check1100 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1100,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1099 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1099 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1099 ((10 : Int),(2 : Int)) hp6_2_branches1099 hp6_2_evidence1099 hp6_2_check1099 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1099,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1100 T childKnown
theorem hp6_2_node1098 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1098 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1098 ((14 : Int),(0 : Int)) hp6_2_branches1098 hp6_2_evidence1098 hp6_2_check1098 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1098,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1099 T childKnown
theorem hp6_2_node1097 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1097 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1097 ((8 : Int),(2 : Int)) hp6_2_branches1097 hp6_2_evidence1097 hp6_2_check1097 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1097,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1098 T childKnown
theorem hp6_2_node1096 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1096 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1096 ((9 : Int),(2 : Int)) hp6_2_branches1096 hp6_2_evidence1096 hp6_2_check1096 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1096,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1095 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1095 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1095 ((9 : Int),(1 : Int)) hp6_2_branches1095 hp6_2_evidence1095 hp6_2_check1095 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1095,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1096 T childKnown
theorem hp6_2_node1094 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1094 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1094 ((8 : Int),(1 : Int)) hp6_2_branches1094 hp6_2_evidence1094 hp6_2_check1094 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1094,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1095 T childKnown
  · exact hp6_2_node1097 T childKnown
  · exact hp6_2_node1101 T childKnown
theorem hp6_2_node1093 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1093 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1093 ((9 : Int),(2 : Int)) hp6_2_branches1093 hp6_2_evidence1093 hp6_2_check1093 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1093,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1092 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1092 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1092 ((8 : Int),(2 : Int)) hp6_2_branches1092 hp6_2_evidence1092 hp6_2_check1092 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1092,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1093 T childKnown
theorem hp6_2_node1091 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1091 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1091 ((16 : Int),(1 : Int)) hp6_2_branches1091 hp6_2_evidence1091 hp6_2_check1091 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1091,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1090 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1090 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1090 ((10 : Int),(2 : Int)) hp6_2_branches1090 hp6_2_evidence1090 hp6_2_check1090 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1090,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1091 T childKnown
theorem hp6_2_node1089 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1089 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1089 ((14 : Int),(0 : Int)) hp6_2_branches1089 hp6_2_evidence1089 hp6_2_check1089 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1089,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1090 T childKnown
theorem hp6_2_node1088 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1088 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1088 ((8 : Int),(2 : Int)) hp6_2_branches1088 hp6_2_evidence1088 hp6_2_check1088 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1088,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1089 T childKnown
theorem hp6_2_node1087 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1087 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1087 ((9 : Int),(2 : Int)) hp6_2_branches1087 hp6_2_evidence1087 hp6_2_check1087 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1087,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1086 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1086 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1086 ((9 : Int),(1 : Int)) hp6_2_branches1086 hp6_2_evidence1086 hp6_2_check1086 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1086,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1087 T childKnown
theorem hp6_2_node1085 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1085 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1085 ((8 : Int),(1 : Int)) hp6_2_branches1085 hp6_2_evidence1085 hp6_2_check1085 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1085,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1086 T childKnown
  · exact hp6_2_node1088 T childKnown
  · exact hp6_2_node1092 T childKnown
theorem hp6_2_node1084 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1084 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1084 ((1 : Int),(2 : Int)) hp6_2_branches1084 hp6_2_evidence1084 hp6_2_check1084 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1084,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1085 T childKnown
  · exact hp6_2_node1094 T childKnown
theorem hp6_2_node1083 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1083 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1083 ((3 : Int),(2 : Int)) hp6_2_branches1083 hp6_2_evidence1083 hp6_2_check1083 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1083,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1084 T childKnown
theorem hp6_2_node1082 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1082 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1082 ((0 : Int),(2 : Int)) hp6_2_branches1082 hp6_2_evidence1082 hp6_2_check1082 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1082,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1081 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1081 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1081 ((3 : Int),(2 : Int)) hp6_2_branches1081 hp6_2_evidence1081 hp6_2_check1081 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1081,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1082 T childKnown
theorem hp6_2_node1080 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1080 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1080 ((3 : Int),(1 : Int)) hp6_2_branches1080 hp6_2_evidence1080 hp6_2_check1080 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1080,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1081 T childKnown
  · exact hp6_2_node1083 T childKnown
  · exact hp6_2_node1103 T childKnown
theorem hp6_2_node1079 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1079 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1079 ((6 : Int),(1 : Int)) hp6_2_branches1079 hp6_2_evidence1079 hp6_2_check1079 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1079,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1080 T childKnown
theorem hp6_2_node1078 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1078 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1078 ((6 : Int),(1 : Int)) hp6_2_branches1078 hp6_2_evidence1078 hp6_2_check1078 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1078,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1077 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1077 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1077 ((5 : Int),(1 : Int)) hp6_2_branches1077 hp6_2_evidence1077 hp6_2_check1077 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1077,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node1078 T childKnown
  · exact hp6_2_node1079 T childKnown
  · exact hp6_2_node1105 T childKnown
  · exact hp6_2_node1106 T childKnown
theorem hp6_2_node1076 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1076 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1076 ((7 : Int),(1 : Int)) hp6_2_branches1076 hp6_2_evidence1076 hp6_2_check1076 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1076,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1075 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1075 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1075 ((7 : Int),(1 : Int)) hp6_2_branches1075 hp6_2_evidence1075 hp6_2_check1075 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1075,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1074 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1074 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1074 ((7 : Int),(0 : Int)) hp6_2_branches1074 hp6_2_evidence1074 hp6_2_check1074 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1074,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1075 T childKnown
  · exact hp6_2_node1076 T childKnown
theorem hp6_2_node1073 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1073 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1073 ((5 : Int),(1 : Int)) hp6_2_branches1073 hp6_2_evidence1073 hp6_2_check1073 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1073,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1074 T childKnown
theorem hp6_2_node1072 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1072 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1072 ((0 : Int),(2 : Int)) hp6_2_branches1072 hp6_2_evidence1072 hp6_2_check1072 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1072,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1071 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1071 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1071 ((2 : Int),(1 : Int)) hp6_2_branches1071 hp6_2_evidence1071 hp6_2_check1071 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1071,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1072 T childKnown
theorem hp6_2_node1070 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1070 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1070 ((11 : Int),(1 : Int)) hp6_2_branches1070 hp6_2_evidence1070 hp6_2_check1070 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1070,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1069 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1069 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1069 ((11 : Int),(1 : Int)) hp6_2_branches1069 hp6_2_evidence1069 hp6_2_check1069 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1069,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1068 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1068 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1068 ((10 : Int),(1 : Int)) hp6_2_branches1068 hp6_2_evidence1068 hp6_2_check1068 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1068,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1069 T childKnown
  · exact hp6_2_node1070 T childKnown
theorem hp6_2_node1067 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1067 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1067 ((9 : Int),(1 : Int)) hp6_2_branches1067 hp6_2_evidence1067 hp6_2_check1067 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1067,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1066 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1066 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1066 ((8 : Int),(2 : Int)) hp6_2_branches1066 hp6_2_evidence1066 hp6_2_check1066 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1066,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1067 T childKnown
theorem hp6_2_node1065 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1065 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1065 ((9 : Int),(1 : Int)) hp6_2_branches1065 hp6_2_evidence1065 hp6_2_check1065 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1065,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1064 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1064 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1064 ((7 : Int),(2 : Int)) hp6_2_branches1064 hp6_2_evidence1064 hp6_2_check1064 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1064,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1065 T childKnown
  · exact hp6_2_node1066 T childKnown
  · exact hp6_2_node1068 T childKnown
theorem hp6_2_node1063 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1063 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1063 ((11 : Int),(1 : Int)) hp6_2_branches1063 hp6_2_evidence1063 hp6_2_check1063 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1063,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1062 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1062 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1062 ((11 : Int),(1 : Int)) hp6_2_branches1062 hp6_2_evidence1062 hp6_2_check1062 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1062,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1061 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1061 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1061 ((10 : Int),(1 : Int)) hp6_2_branches1061 hp6_2_evidence1061 hp6_2_check1061 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1061,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1062 T childKnown
  · exact hp6_2_node1063 T childKnown
theorem hp6_2_node1060 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1060 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1060 ((9 : Int),(1 : Int)) hp6_2_branches1060 hp6_2_evidence1060 hp6_2_check1060 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1060,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1059 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1059 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1059 ((8 : Int),(2 : Int)) hp6_2_branches1059 hp6_2_evidence1059 hp6_2_check1059 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1059,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1060 T childKnown
theorem hp6_2_node1058 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1058 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1058 ((9 : Int),(1 : Int)) hp6_2_branches1058 hp6_2_evidence1058 hp6_2_check1058 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1058,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1057 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1057 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1057 ((7 : Int),(2 : Int)) hp6_2_branches1057 hp6_2_evidence1057 hp6_2_check1057 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1057,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1058 T childKnown
  · exact hp6_2_node1059 T childKnown
  · exact hp6_2_node1061 T childKnown
theorem hp6_2_node1056 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1056 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1056 ((1 : Int),(2 : Int)) hp6_2_branches1056 hp6_2_evidence1056 hp6_2_check1056 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1056,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1057 T childKnown
  · exact hp6_2_node1064 T childKnown
theorem hp6_2_node1055 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1055 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1055 ((3 : Int),(2 : Int)) hp6_2_branches1055 hp6_2_evidence1055 hp6_2_check1055 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1055,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1056 T childKnown
theorem hp6_2_node1054 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1054 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1054 ((0 : Int),(2 : Int)) hp6_2_branches1054 hp6_2_evidence1054 hp6_2_check1054 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1054,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1053 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1053 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1053 ((3 : Int),(2 : Int)) hp6_2_branches1053 hp6_2_evidence1053 hp6_2_check1053 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1053,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1054 T childKnown
theorem hp6_2_node1052 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1052 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1052 ((3 : Int),(1 : Int)) hp6_2_branches1052 hp6_2_evidence1052 hp6_2_check1052 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1052,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1053 T childKnown
  · exact hp6_2_node1055 T childKnown
  · exact hp6_2_node1071 T childKnown
theorem hp6_2_node1051 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1051 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1051 ((7 : Int),(0 : Int)) hp6_2_branches1051 hp6_2_evidence1051 hp6_2_check1051 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1051,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1052 T childKnown
theorem hp6_2_node1050 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1050 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1050 ((5 : Int),(1 : Int)) hp6_2_branches1050 hp6_2_evidence1050 hp6_2_check1050 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1050,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1051 T childKnown
theorem hp6_2_node1049 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1049 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1049 ((5 : Int),(1 : Int)) hp6_2_branches1049 hp6_2_evidence1049 hp6_2_check1049 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1049,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1048 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1048 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1048 ((5 : Int),(1 : Int)) hp6_2_branches1048 hp6_2_evidence1048 hp6_2_check1048 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1048,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1047 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1047 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1047 ((6 : Int),(0 : Int)) hp6_2_branches1047 hp6_2_evidence1047 hp6_2_check1047 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1047,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node1048 T childKnown
  · exact hp6_2_node1049 T childKnown
  · exact hp6_2_node1050 T childKnown
  · exact hp6_2_node1073 T childKnown
  · exact hp6_2_node1077 T childKnown
  · exact hp6_2_node1107 T childKnown
theorem hp6_2_node1046 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1046 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1046 ((9 : Int),(1 : Int)) hp6_2_branches1046 hp6_2_evidence1046 hp6_2_check1046 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1046,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1045 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1045 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1045 ((9 : Int),(1 : Int)) hp6_2_branches1045 hp6_2_evidence1045 hp6_2_check1045 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1045,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1044 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1044 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1044 ((7 : Int),(2 : Int)) hp6_2_branches1044 hp6_2_evidence1044 hp6_2_check1044 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1044,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1043 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1043 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1043 ((7 : Int),(2 : Int)) hp6_2_branches1043 hp6_2_evidence1043 hp6_2_check1043 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1043,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1042 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1042 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1042 ((8 : Int),(1 : Int)) hp6_2_branches1042 hp6_2_evidence1042 hp6_2_check1042 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1042,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node1043 T childKnown
  · exact hp6_2_node1044 T childKnown
  · exact hp6_2_node1045 T childKnown
  · exact hp6_2_node1046 T childKnown
theorem hp6_2_node1041 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1041 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1041 ((6 : Int),(0 : Int)) hp6_2_branches1041 hp6_2_evidence1041 hp6_2_check1041 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1041,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1042 T childKnown
theorem hp6_2_node1040 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1040 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1040 ((8 : Int),(1 : Int)) hp6_2_branches1040 hp6_2_evidence1040 hp6_2_check1040 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1040,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1039 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1039 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1039 ((8 : Int),(1 : Int)) hp6_2_branches1039 hp6_2_evidence1039 hp6_2_check1039 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1039,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1038 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1038 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1038 ((8 : Int),(1 : Int)) hp6_2_branches1038 hp6_2_evidence1038 hp6_2_check1038 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1038,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1037 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1037 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1037 ((3 : Int),(2 : Int)) hp6_2_branches1037 hp6_2_evidence1037 hp6_2_check1037 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1037,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1038 T childKnown
theorem hp6_2_node1036 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1036 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1036 ((2 : Int),(2 : Int)) hp6_2_branches1036 hp6_2_evidence1036 hp6_2_check1036 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1036,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node1037 T childKnown
  · exact hp6_2_node1039 T childKnown
  · exact hp6_2_node1040 T childKnown
theorem hp6_2_node1035 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1035 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1035 ((8 : Int),(1 : Int)) hp6_2_branches1035 hp6_2_evidence1035 hp6_2_check1035 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1035,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1034 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1034 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1034 ((2 : Int),(2 : Int)) hp6_2_branches1034 hp6_2_evidence1034 hp6_2_check1034 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1034,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1035 T childKnown
theorem hp6_2_node1033 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1033 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1033 ((8 : Int),(1 : Int)) hp6_2_branches1033 hp6_2_evidence1033 hp6_2_check1033 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1033,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1032 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1032 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1032 ((8 : Int),(1 : Int)) hp6_2_branches1032 hp6_2_evidence1032 hp6_2_check1032 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1032,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1031 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1031 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1031 ((8 : Int),(1 : Int)) hp6_2_branches1031 hp6_2_evidence1031 hp6_2_check1031 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1031,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1030 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1030 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1030 ((8 : Int),(1 : Int)) hp6_2_branches1030 hp6_2_evidence1030 hp6_2_check1030 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1030,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1029 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1029 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1029 ((3 : Int),(2 : Int)) hp6_2_branches1029 hp6_2_evidence1029 hp6_2_check1029 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1029,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1030 T childKnown
  · exact hp6_2_node1031 T childKnown
theorem hp6_2_node1028 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1028 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1028 ((8 : Int),(1 : Int)) hp6_2_branches1028 hp6_2_evidence1028 hp6_2_check1028 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1028,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1027 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1027 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1027 ((3 : Int),(2 : Int)) hp6_2_branches1027 hp6_2_evidence1027 hp6_2_check1027 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1027,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1028 T childKnown
theorem hp6_2_node1026 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1026 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1026 ((8 : Int),(1 : Int)) hp6_2_branches1026 hp6_2_evidence1026 hp6_2_check1026 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1026,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1025 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1025 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1025 ((3 : Int),(2 : Int)) hp6_2_branches1025 hp6_2_evidence1025 hp6_2_check1025 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1025,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1026 T childKnown
theorem hp6_2_node1024 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1024 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1024 ((2 : Int),(2 : Int)) hp6_2_branches1024 hp6_2_evidence1024 hp6_2_check1024 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1024,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node1025 T childKnown
  · exact hp6_2_node1027 T childKnown
  · exact hp6_2_node1029 T childKnown
  · exact hp6_2_node1032 T childKnown
  · exact hp6_2_node1033 T childKnown
theorem hp6_2_node1023 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1023 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1023 ((8 : Int),(1 : Int)) hp6_2_branches1023 hp6_2_evidence1023 hp6_2_check1023 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1023,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1022 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1022 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1022 ((8 : Int),(1 : Int)) hp6_2_branches1022 hp6_2_evidence1022 hp6_2_check1022 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1022,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1021 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1021 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1021 ((8 : Int),(1 : Int)) hp6_2_branches1021 hp6_2_evidence1021 hp6_2_check1021 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1021,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1020 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1020 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1020 ((8 : Int),(1 : Int)) hp6_2_branches1020 hp6_2_evidence1020 hp6_2_check1020 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1020,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1019 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1019 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1019 ((3 : Int),(2 : Int)) hp6_2_branches1019 hp6_2_evidence1019 hp6_2_check1019 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1019,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1020 T childKnown
  · exact hp6_2_node1021 T childKnown
theorem hp6_2_node1018 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1018 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1018 ((8 : Int),(1 : Int)) hp6_2_branches1018 hp6_2_evidence1018 hp6_2_check1018 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1018,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1017 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1017 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1017 ((3 : Int),(2 : Int)) hp6_2_branches1017 hp6_2_evidence1017 hp6_2_check1017 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1017,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1018 T childKnown
theorem hp6_2_node1016 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1016 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1016 ((8 : Int),(1 : Int)) hp6_2_branches1016 hp6_2_evidence1016 hp6_2_check1016 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1016,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1015 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1015 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1015 ((3 : Int),(2 : Int)) hp6_2_branches1015 hp6_2_evidence1015 hp6_2_check1015 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1015,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1016 T childKnown
theorem hp6_2_node1014 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1014 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1014 ((2 : Int),(2 : Int)) hp6_2_branches1014 hp6_2_evidence1014 hp6_2_check1014 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1014,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node1015 T childKnown
  · exact hp6_2_node1017 T childKnown
  · exact hp6_2_node1019 T childKnown
  · exact hp6_2_node1022 T childKnown
  · exact hp6_2_node1023 T childKnown
theorem hp6_2_node1013 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1013 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1013 ((8 : Int),(1 : Int)) hp6_2_branches1013 hp6_2_evidence1013 hp6_2_check1013 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1013,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1012 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1012 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1012 ((8 : Int),(1 : Int)) hp6_2_branches1012 hp6_2_evidence1012 hp6_2_check1012 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1012,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1011 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1011 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1011 ((8 : Int),(1 : Int)) hp6_2_branches1011 hp6_2_evidence1011 hp6_2_check1011 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1011,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1010 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1010 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1010 ((8 : Int),(1 : Int)) hp6_2_branches1010 hp6_2_evidence1010 hp6_2_check1010 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1010,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1009 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1009 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1009 ((3 : Int),(2 : Int)) hp6_2_branches1009 hp6_2_evidence1009 hp6_2_check1009 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1009,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1010 T childKnown
  · exact hp6_2_node1011 T childKnown
theorem hp6_2_node1008 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1008 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1008 ((8 : Int),(1 : Int)) hp6_2_branches1008 hp6_2_evidence1008 hp6_2_check1008 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1008,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1007 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1007 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1007 ((3 : Int),(2 : Int)) hp6_2_branches1007 hp6_2_evidence1007 hp6_2_check1007 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1007,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1008 T childKnown
theorem hp6_2_node1006 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1006 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1006 ((8 : Int),(1 : Int)) hp6_2_branches1006 hp6_2_evidence1006 hp6_2_check1006 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1006,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1005 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1005 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1005 ((8 : Int),(1 : Int)) hp6_2_branches1005 hp6_2_evidence1005 hp6_2_check1005 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1005,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1004 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1004 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1004 ((8 : Int),(1 : Int)) hp6_2_branches1004 hp6_2_evidence1004 hp6_2_check1004 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1004,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1003 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1003 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1003 ((8 : Int),(1 : Int)) hp6_2_branches1003 hp6_2_evidence1003 hp6_2_check1003 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1003,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1002 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1002 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1002 ((4 : Int),(2 : Int)) hp6_2_branches1002 hp6_2_evidence1002 hp6_2_check1002 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1002,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node1003 T childKnown
  · exact hp6_2_node1004 T childKnown
theorem hp6_2_node1001 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1001 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1001 ((8 : Int),(1 : Int)) hp6_2_branches1001 hp6_2_evidence1001 hp6_2_check1001 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1001,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1000 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1000 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1000 ((4 : Int),(2 : Int)) hp6_2_branches1000 hp6_2_evidence1000 hp6_2_check1000 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1000,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node1001 T childKnown
theorem hp6_2_node999 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected999 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected999 ((3 : Int),(2 : Int)) hp6_2_branches999 hp6_2_evidence999 hp6_2_check999 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches999,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node1000 T childKnown
  · exact hp6_2_node1002 T childKnown
  · exact hp6_2_node1005 T childKnown
  · exact hp6_2_node1006 T childKnown
theorem hp6_2_node998 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected998 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected998 ((2 : Int),(2 : Int)) hp6_2_branches998 hp6_2_evidence998 hp6_2_check998 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches998,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node999 T childKnown
  · exact hp6_2_node1007 T childKnown
  · exact hp6_2_node1009 T childKnown
  · exact hp6_2_node1012 T childKnown
  · exact hp6_2_node1013 T childKnown
theorem hp6_2_node997 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected997 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected997 ((0 : Int),(2 : Int)) hp6_2_branches997 hp6_2_evidence997 hp6_2_check997 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches997,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node998 T childKnown
  · exact hp6_2_node1014 T childKnown
  · exact hp6_2_node1024 T childKnown
  · exact hp6_2_node1034 T childKnown
  · exact hp6_2_node1036 T childKnown
theorem hp6_2_node996 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected996 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected996 ((6 : Int),(0 : Int)) hp6_2_branches996 hp6_2_evidence996 hp6_2_check996 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches996,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node997 T childKnown
theorem hp6_2_node995 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected995 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected995 ((1 : Int),(2 : Int)) hp6_2_branches995 hp6_2_evidence995 hp6_2_check995 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches995,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node994 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected994 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected994 ((1 : Int),(2 : Int)) hp6_2_branches994 hp6_2_evidence994 hp6_2_check994 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches994,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node993 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected993 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected993 ((1 : Int),(1 : Int)) hp6_2_branches993 hp6_2_evidence993 hp6_2_check993 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches993,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node994 T childKnown
  · exact hp6_2_node995 T childKnown
theorem hp6_2_node992 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected992 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected992 ((6 : Int),(2 : Int)) hp6_2_branches992 hp6_2_evidence992 hp6_2_check992 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches992,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node991 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected991 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected991 ((4 : Int),(2 : Int)) hp6_2_branches991 hp6_2_evidence991 hp6_2_check991 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches991,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node990 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected990 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected990 ((3 : Int),(2 : Int)) hp6_2_branches990 hp6_2_evidence990 hp6_2_check990 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches990,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node989 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected989 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected989 ((3 : Int),(2 : Int)) hp6_2_branches989 hp6_2_evidence989 hp6_2_check989 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches989,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node988 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected988 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected988 ((5 : Int),(2 : Int)) hp6_2_branches988 hp6_2_evidence988 hp6_2_check988 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches988,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node989 T childKnown
  · exact hp6_2_node990 T childKnown
  · exact hp6_2_node991 T childKnown
  · exact hp6_2_node992 T childKnown
theorem hp6_2_node987 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected987 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected987 ((6 : Int),(0 : Int)) hp6_2_branches987 hp6_2_evidence987 hp6_2_check987 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches987,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node988 T childKnown
theorem hp6_2_node986 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected986 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected986 ((1 : Int),(1 : Int)) hp6_2_branches986 hp6_2_evidence986 hp6_2_check986 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches986,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node987 T childKnown
theorem hp6_2_node985 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected985 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected985 ((1 : Int),(2 : Int)) hp6_2_branches985 hp6_2_evidence985 hp6_2_check985 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches985,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node984 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected984 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected984 ((1 : Int),(1 : Int)) hp6_2_branches984 hp6_2_evidence984 hp6_2_check984 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches984,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node985 T childKnown
theorem hp6_2_node983 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected983 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected983 ((2 : Int),(2 : Int)) hp6_2_branches983 hp6_2_evidence983 hp6_2_check983 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches983,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node982 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected982 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected982 ((2 : Int),(2 : Int)) hp6_2_branches982 hp6_2_evidence982 hp6_2_check982 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches982,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node981 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected981 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected981 ((1 : Int),(2 : Int)) hp6_2_branches981 hp6_2_evidence981 hp6_2_check981 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches981,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node982 T childKnown
  · exact hp6_2_node983 T childKnown
theorem hp6_2_node980 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected980 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected980 ((6 : Int),(0 : Int)) hp6_2_branches980 hp6_2_evidence980 hp6_2_check980 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches980,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node981 T childKnown
theorem hp6_2_node979 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected979 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected979 ((9 : Int),(1 : Int)) hp6_2_branches979 hp6_2_evidence979 hp6_2_check979 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches979,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node978 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected978 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected978 ((9 : Int),(1 : Int)) hp6_2_branches978 hp6_2_evidence978 hp6_2_check978 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches978,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node977 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected977 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected977 ((9 : Int),(1 : Int)) hp6_2_branches977 hp6_2_evidence977 hp6_2_check977 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches977,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node976 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected976 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected976 ((4 : Int),(2 : Int)) hp6_2_branches976 hp6_2_evidence976 hp6_2_check976 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches976,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node977 T childKnown
theorem hp6_2_node975 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected975 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected975 ((3 : Int),(2 : Int)) hp6_2_branches975 hp6_2_evidence975 hp6_2_check975 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches975,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node976 T childKnown
  · exact hp6_2_node978 T childKnown
  · exact hp6_2_node979 T childKnown
theorem hp6_2_node974 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected974 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected974 ((6 : Int),(0 : Int)) hp6_2_branches974 hp6_2_evidence974 hp6_2_check974 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches974,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node975 T childKnown
theorem hp6_2_node973 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected973 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected973 ((1 : Int),(2 : Int)) hp6_2_branches973 hp6_2_evidence973 hp6_2_check973 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches973,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node974 T childKnown
theorem hp6_2_node972 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected972 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected972 ((2 : Int),(2 : Int)) hp6_2_branches972 hp6_2_evidence972 hp6_2_check972 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches972,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node971 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected971 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected971 ((2 : Int),(2 : Int)) hp6_2_branches971 hp6_2_evidence971 hp6_2_check971 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches971,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node970 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected970 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected970 ((2 : Int),(1 : Int)) hp6_2_branches970 hp6_2_evidence970 hp6_2_check970 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches970,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node971 T childKnown
  · exact hp6_2_node972 T childKnown
theorem hp6_2_node969 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected969 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected969 ((11 : Int),(1 : Int)) hp6_2_branches969 hp6_2_evidence969 hp6_2_check969 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches969,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node968 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected968 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected968 ((9 : Int),(2 : Int)) hp6_2_branches968 hp6_2_evidence968 hp6_2_check968 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches968,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node967 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected967 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected967 ((9 : Int),(2 : Int)) hp6_2_branches967 hp6_2_evidence967 hp6_2_check967 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches967,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node966 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected966 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected966 ((10 : Int),(1 : Int)) hp6_2_branches966 hp6_2_evidence966 hp6_2_check966 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches966,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node967 T childKnown
  · exact hp6_2_node968 T childKnown
  · exact hp6_2_node969 T childKnown
theorem hp6_2_node965 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected965 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected965 ((6 : Int),(0 : Int)) hp6_2_branches965 hp6_2_evidence965 hp6_2_check965 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches965,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node966 T childKnown
theorem hp6_2_node964 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected964 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected964 ((2 : Int),(1 : Int)) hp6_2_branches964 hp6_2_evidence964 hp6_2_check964 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches964,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node965 T childKnown
theorem hp6_2_node963 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected963 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected963 ((1 : Int),(1 : Int)) hp6_2_branches963 hp6_2_evidence963 hp6_2_check963 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches963,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node964 T childKnown
  · exact hp6_2_node970 T childKnown
  · exact hp6_2_node973 T childKnown
  · exact hp6_2_node980 T childKnown
theorem hp6_2_node962 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected962 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected962 ((1 : Int),(2 : Int)) hp6_2_branches962 hp6_2_evidence962 hp6_2_check962 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches962,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node961 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected961 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected961 ((1 : Int),(2 : Int)) hp6_2_branches961 hp6_2_evidence961 hp6_2_check961 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches961,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node960 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected960 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected960 ((1 : Int),(1 : Int)) hp6_2_branches960 hp6_2_evidence960 hp6_2_check960 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches960,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node961 T childKnown
  · exact hp6_2_node962 T childKnown
theorem hp6_2_node959 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected959 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected959 ((0 : Int),(1 : Int)) hp6_2_branches959 hp6_2_evidence959 hp6_2_check959 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches959,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node960 T childKnown
  · exact hp6_2_node963 T childKnown
  · exact hp6_2_node984 T childKnown
  · exact hp6_2_node986 T childKnown
  · exact hp6_2_node993 T childKnown
  · exact hp6_2_node996 T childKnown
  · exact hp6_2_node1041 T childKnown
theorem hp6_2_node958 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected958 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected958 ((5 : Int),(1 : Int)) hp6_2_branches958 hp6_2_evidence958 hp6_2_check958 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches958,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node957 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected957 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected957 ((5 : Int),(1 : Int)) hp6_2_branches957 hp6_2_evidence957 hp6_2_check957 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches957,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node956 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected956 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected956 ((5 : Int),(1 : Int)) hp6_2_branches956 hp6_2_evidence956 hp6_2_check956 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches956,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node955 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected955 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected955 ((6 : Int),(1 : Int)) hp6_2_branches955 hp6_2_evidence955 hp6_2_check955 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches955,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node954 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected954 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected954 ((6 : Int),(1 : Int)) hp6_2_branches954 hp6_2_evidence954 hp6_2_check954 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches954,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node953 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected953 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected953 ((5 : Int),(1 : Int)) hp6_2_branches953 hp6_2_evidence953 hp6_2_check953 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches953,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node954 T childKnown
  · exact hp6_2_node955 T childKnown
theorem hp6_2_node952 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected952 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected952 ((5 : Int),(1 : Int)) hp6_2_branches952 hp6_2_evidence952 hp6_2_check952 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches952,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node951 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected951 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected951 ((4 : Int),(1 : Int)) hp6_2_branches951 hp6_2_evidence951 hp6_2_check951 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches951,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node952 T childKnown
  · exact hp6_2_node953 T childKnown
  · exact hp6_2_node956 T childKnown
  · exact hp6_2_node957 T childKnown
  · exact hp6_2_node958 T childKnown
theorem hp6_2_node950 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected950 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected950 ((5 : Int),(1 : Int)) hp6_2_branches950 hp6_2_evidence950 hp6_2_check950 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches950,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node949 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected949 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected949 ((5 : Int),(1 : Int)) hp6_2_branches949 hp6_2_evidence949 hp6_2_check949 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches949,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node948 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected948 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected948 ((0 : Int),(2 : Int)) hp6_2_branches948 hp6_2_evidence948 hp6_2_check948 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches948,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node947 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected947 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected947 ((1 : Int),(1 : Int)) hp6_2_branches947 hp6_2_evidence947 hp6_2_check947 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches947,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node948 T childKnown
theorem hp6_2_node946 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected946 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected946 ((8 : Int),(2 : Int)) hp6_2_branches946 hp6_2_evidence946 hp6_2_check946 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches946,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node945 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected945 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected945 ((7 : Int),(2 : Int)) hp6_2_branches945 hp6_2_evidence945 hp6_2_check945 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches945,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node946 T childKnown
theorem hp6_2_node944 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected944 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected944 ((15 : Int),(1 : Int)) hp6_2_branches944 hp6_2_evidence944 hp6_2_check944 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches944,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node943 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected943 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected943 ((9 : Int),(2 : Int)) hp6_2_branches943 hp6_2_evidence943 hp6_2_check943 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches943,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node944 T childKnown
theorem hp6_2_node942 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected942 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected942 ((13 : Int),(0 : Int)) hp6_2_branches942 hp6_2_evidence942 hp6_2_check942 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches942,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node943 T childKnown
theorem hp6_2_node941 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected941 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected941 ((7 : Int),(2 : Int)) hp6_2_branches941 hp6_2_evidence941 hp6_2_check941 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches941,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node942 T childKnown
theorem hp6_2_node940 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected940 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected940 ((8 : Int),(2 : Int)) hp6_2_branches940 hp6_2_evidence940 hp6_2_check940 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches940,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node939 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected939 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected939 ((8 : Int),(1 : Int)) hp6_2_branches939 hp6_2_evidence939 hp6_2_check939 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches939,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node940 T childKnown
theorem hp6_2_node938 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected938 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected938 ((7 : Int),(1 : Int)) hp6_2_branches938 hp6_2_evidence938 hp6_2_check938 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches938,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node939 T childKnown
  · exact hp6_2_node941 T childKnown
  · exact hp6_2_node945 T childKnown
theorem hp6_2_node937 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected937 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected937 ((8 : Int),(2 : Int)) hp6_2_branches937 hp6_2_evidence937 hp6_2_check937 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches937,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node936 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected936 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected936 ((7 : Int),(2 : Int)) hp6_2_branches936 hp6_2_evidence936 hp6_2_check936 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches936,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node937 T childKnown
theorem hp6_2_node935 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected935 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected935 ((15 : Int),(1 : Int)) hp6_2_branches935 hp6_2_evidence935 hp6_2_check935 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches935,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node934 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected934 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected934 ((9 : Int),(2 : Int)) hp6_2_branches934 hp6_2_evidence934 hp6_2_check934 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches934,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node935 T childKnown
theorem hp6_2_node933 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected933 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected933 ((13 : Int),(0 : Int)) hp6_2_branches933 hp6_2_evidence933 hp6_2_check933 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches933,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node934 T childKnown
theorem hp6_2_node932 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected932 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected932 ((7 : Int),(2 : Int)) hp6_2_branches932 hp6_2_evidence932 hp6_2_check932 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches932,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node933 T childKnown
theorem hp6_2_node931 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected931 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected931 ((8 : Int),(2 : Int)) hp6_2_branches931 hp6_2_evidence931 hp6_2_check931 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches931,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node930 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected930 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected930 ((8 : Int),(1 : Int)) hp6_2_branches930 hp6_2_evidence930 hp6_2_check930 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches930,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node931 T childKnown
theorem hp6_2_node929 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected929 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected929 ((7 : Int),(1 : Int)) hp6_2_branches929 hp6_2_evidence929 hp6_2_check929 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches929,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node930 T childKnown
  · exact hp6_2_node932 T childKnown
  · exact hp6_2_node936 T childKnown
theorem hp6_2_node928 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected928 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected928 ((0 : Int),(2 : Int)) hp6_2_branches928 hp6_2_evidence928 hp6_2_check928 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches928,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node929 T childKnown
  · exact hp6_2_node938 T childKnown
theorem hp6_2_node927 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected927 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected927 ((2 : Int),(2 : Int)) hp6_2_branches927 hp6_2_evidence927 hp6_2_check927 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches927,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node928 T childKnown
theorem hp6_2_node926 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected926 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected926 ((0 : Int),(2 : Int)) hp6_2_branches926 hp6_2_evidence926 hp6_2_check926 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches926,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node925 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected925 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected925 ((2 : Int),(2 : Int)) hp6_2_branches925 hp6_2_evidence925 hp6_2_check925 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches925,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node926 T childKnown
theorem hp6_2_node924 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected924 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected924 ((2 : Int),(1 : Int)) hp6_2_branches924 hp6_2_evidence924 hp6_2_check924 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches924,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node925 T childKnown
  · exact hp6_2_node927 T childKnown
  · exact hp6_2_node947 T childKnown
theorem hp6_2_node923 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected923 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected923 ((5 : Int),(1 : Int)) hp6_2_branches923 hp6_2_evidence923 hp6_2_check923 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches923,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node924 T childKnown
theorem hp6_2_node922 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected922 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected922 ((5 : Int),(1 : Int)) hp6_2_branches922 hp6_2_evidence922 hp6_2_check922 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches922,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node921 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected921 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected921 ((4 : Int),(1 : Int)) hp6_2_branches921 hp6_2_evidence921 hp6_2_check921 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches921,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node922 T childKnown
  · exact hp6_2_node923 T childKnown
  · exact hp6_2_node949 T childKnown
  · exact hp6_2_node950 T childKnown
theorem hp6_2_node920 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected920 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected920 ((6 : Int),(1 : Int)) hp6_2_branches920 hp6_2_evidence920 hp6_2_check920 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches920,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node919 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected919 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected919 ((6 : Int),(1 : Int)) hp6_2_branches919 hp6_2_evidence919 hp6_2_check919 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches919,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node918 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected918 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected918 ((6 : Int),(0 : Int)) hp6_2_branches918 hp6_2_evidence918 hp6_2_check918 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches918,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node919 T childKnown
  · exact hp6_2_node920 T childKnown
theorem hp6_2_node917 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected917 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected917 ((4 : Int),(1 : Int)) hp6_2_branches917 hp6_2_evidence917 hp6_2_check917 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches917,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node918 T childKnown
theorem hp6_2_node916 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected916 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected916 ((0 : Int),(2 : Int)) hp6_2_branches916 hp6_2_evidence916 hp6_2_check916 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches916,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node915 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected915 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected915 ((1 : Int),(1 : Int)) hp6_2_branches915 hp6_2_evidence915 hp6_2_check915 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches915,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node916 T childKnown
theorem hp6_2_node914 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected914 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected914 ((10 : Int),(1 : Int)) hp6_2_branches914 hp6_2_evidence914 hp6_2_check914 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches914,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node913 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected913 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected913 ((10 : Int),(1 : Int)) hp6_2_branches913 hp6_2_evidence913 hp6_2_check913 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches913,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node912 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected912 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected912 ((9 : Int),(1 : Int)) hp6_2_branches912 hp6_2_evidence912 hp6_2_check912 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches912,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node913 T childKnown
  · exact hp6_2_node914 T childKnown
theorem hp6_2_node911 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected911 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected911 ((8 : Int),(1 : Int)) hp6_2_branches911 hp6_2_evidence911 hp6_2_check911 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches911,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node910 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected910 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected910 ((7 : Int),(2 : Int)) hp6_2_branches910 hp6_2_evidence910 hp6_2_check910 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches910,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node911 T childKnown
theorem hp6_2_node909 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected909 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected909 ((8 : Int),(1 : Int)) hp6_2_branches909 hp6_2_evidence909 hp6_2_check909 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches909,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node908 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected908 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected908 ((6 : Int),(2 : Int)) hp6_2_branches908 hp6_2_evidence908 hp6_2_check908 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches908,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node909 T childKnown
  · exact hp6_2_node910 T childKnown
  · exact hp6_2_node912 T childKnown
theorem hp6_2_node907 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected907 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected907 ((10 : Int),(1 : Int)) hp6_2_branches907 hp6_2_evidence907 hp6_2_check907 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches907,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node906 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected906 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected906 ((10 : Int),(1 : Int)) hp6_2_branches906 hp6_2_evidence906 hp6_2_check906 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches906,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node905 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected905 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected905 ((9 : Int),(1 : Int)) hp6_2_branches905 hp6_2_evidence905 hp6_2_check905 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches905,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node906 T childKnown
  · exact hp6_2_node907 T childKnown
theorem hp6_2_node904 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected904 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected904 ((8 : Int),(1 : Int)) hp6_2_branches904 hp6_2_evidence904 hp6_2_check904 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches904,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node903 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected903 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected903 ((7 : Int),(2 : Int)) hp6_2_branches903 hp6_2_evidence903 hp6_2_check903 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches903,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node904 T childKnown
theorem hp6_2_node902 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected902 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected902 ((8 : Int),(1 : Int)) hp6_2_branches902 hp6_2_evidence902 hp6_2_check902 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches902,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node901 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected901 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected901 ((6 : Int),(2 : Int)) hp6_2_branches901 hp6_2_evidence901 hp6_2_check901 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches901,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node902 T childKnown
  · exact hp6_2_node903 T childKnown
  · exact hp6_2_node905 T childKnown
theorem hp6_2_node900 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected900 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected900 ((0 : Int),(2 : Int)) hp6_2_branches900 hp6_2_evidence900 hp6_2_check900 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches900,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node901 T childKnown
  · exact hp6_2_node908 T childKnown
theorem hp6_2_node899 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected899 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected899 ((2 : Int),(2 : Int)) hp6_2_branches899 hp6_2_evidence899 hp6_2_check899 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches899,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node900 T childKnown
theorem hp6_2_node898 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected898 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected898 ((0 : Int),(2 : Int)) hp6_2_branches898 hp6_2_evidence898 hp6_2_check898 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches898,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node897 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected897 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected897 ((2 : Int),(2 : Int)) hp6_2_branches897 hp6_2_evidence897 hp6_2_check897 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches897,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node898 T childKnown
theorem hp6_2_node896 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected896 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected896 ((2 : Int),(1 : Int)) hp6_2_branches896 hp6_2_evidence896 hp6_2_check896 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches896,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node897 T childKnown
  · exact hp6_2_node899 T childKnown
  · exact hp6_2_node915 T childKnown
theorem hp6_2_node895 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected895 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected895 ((6 : Int),(0 : Int)) hp6_2_branches895 hp6_2_evidence895 hp6_2_check895 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches895,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node896 T childKnown
theorem hp6_2_node894 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected894 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected894 ((4 : Int),(1 : Int)) hp6_2_branches894 hp6_2_evidence894 hp6_2_check894 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches894,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node895 T childKnown
theorem hp6_2_node893 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected893 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected893 ((4 : Int),(1 : Int)) hp6_2_branches893 hp6_2_evidence893 hp6_2_check893 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches893,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node892 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected892 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected892 ((4 : Int),(1 : Int)) hp6_2_branches892 hp6_2_evidence892 hp6_2_check892 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches892,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node891 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected891 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected891 ((5 : Int),(0 : Int)) hp6_2_branches891 hp6_2_evidence891 hp6_2_check891 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches891,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node892 T childKnown
  · exact hp6_2_node893 T childKnown
  · exact hp6_2_node894 T childKnown
  · exact hp6_2_node917 T childKnown
  · exact hp6_2_node921 T childKnown
  · exact hp6_2_node951 T childKnown
theorem hp6_2_node890 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected890 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected890 ((13 : Int),(1 : Int)) hp6_2_branches890 hp6_2_evidence890 hp6_2_check890 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches890,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node889 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected889 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected889 ((13 : Int),(1 : Int)) hp6_2_branches889 hp6_2_evidence889 hp6_2_check889 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches889,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node888 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected888 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected888 ((13 : Int),(1 : Int)) hp6_2_branches888 hp6_2_evidence888 hp6_2_check888 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches888,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node887 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected887 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected887 ((14 : Int),(1 : Int)) hp6_2_branches887 hp6_2_evidence887 hp6_2_check887 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches887,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node886 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected886 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected886 ((14 : Int),(1 : Int)) hp6_2_branches886 hp6_2_evidence886 hp6_2_check886 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches886,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node885 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected885 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected885 ((13 : Int),(1 : Int)) hp6_2_branches885 hp6_2_evidence885 hp6_2_check885 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches885,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node886 T childKnown
  · exact hp6_2_node887 T childKnown
theorem hp6_2_node884 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected884 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected884 ((13 : Int),(1 : Int)) hp6_2_branches884 hp6_2_evidence884 hp6_2_check884 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches884,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node883 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected883 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected883 ((12 : Int),(1 : Int)) hp6_2_branches883 hp6_2_evidence883 hp6_2_check883 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches883,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node884 T childKnown
  · exact hp6_2_node885 T childKnown
  · exact hp6_2_node888 T childKnown
  · exact hp6_2_node889 T childKnown
  · exact hp6_2_node890 T childKnown
theorem hp6_2_node882 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected882 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected882 ((13 : Int),(1 : Int)) hp6_2_branches882 hp6_2_evidence882 hp6_2_check882 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches882,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node881 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected881 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected881 ((13 : Int),(1 : Int)) hp6_2_branches881 hp6_2_evidence881 hp6_2_check881 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches881,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node880 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected880 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected880 ((4 : Int),(2 : Int)) hp6_2_branches880 hp6_2_evidence880 hp6_2_check880 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches880,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node879 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected879 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected879 ((9 : Int),(1 : Int)) hp6_2_branches879 hp6_2_evidence879 hp6_2_check879 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches879,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node880 T childKnown
theorem hp6_2_node878 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected878 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected878 ((1 : Int),(1 : Int)) hp6_2_branches878 hp6_2_evidence878 hp6_2_check878 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches878,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node877 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected877 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected877 ((8 : Int),(2 : Int)) hp6_2_branches877 hp6_2_evidence877 hp6_2_check877 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches877,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node878 T childKnown
theorem hp6_2_node876 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected876 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected876 ((10 : Int),(2 : Int)) hp6_2_branches876 hp6_2_evidence876 hp6_2_check876 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches876,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node877 T childKnown
theorem hp6_2_node875 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected875 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected875 ((5 : Int),(2 : Int)) hp6_2_branches875 hp6_2_evidence875 hp6_2_check875 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches875,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node874 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected874 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected874 ((10 : Int),(2 : Int)) hp6_2_branches874 hp6_2_evidence874 hp6_2_check874 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches874,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node875 T childKnown
theorem hp6_2_node873 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected873 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected873 ((10 : Int),(1 : Int)) hp6_2_branches873 hp6_2_evidence873 hp6_2_check873 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches873,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node874 T childKnown
  · exact hp6_2_node876 T childKnown
  · exact hp6_2_node879 T childKnown
theorem hp6_2_node872 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected872 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected872 ((13 : Int),(1 : Int)) hp6_2_branches872 hp6_2_evidence872 hp6_2_check872 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches872,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node873 T childKnown
theorem hp6_2_node871 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected871 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected871 ((13 : Int),(1 : Int)) hp6_2_branches871 hp6_2_evidence871 hp6_2_check871 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches871,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node870 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected870 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected870 ((12 : Int),(1 : Int)) hp6_2_branches870 hp6_2_evidence870 hp6_2_check870 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches870,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node871 T childKnown
  · exact hp6_2_node872 T childKnown
  · exact hp6_2_node881 T childKnown
  · exact hp6_2_node882 T childKnown
theorem hp6_2_node869 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected869 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected869 ((14 : Int),(1 : Int)) hp6_2_branches869 hp6_2_evidence869 hp6_2_check869 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches869,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node868 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected868 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected868 ((14 : Int),(1 : Int)) hp6_2_branches868 hp6_2_evidence868 hp6_2_check868 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches868,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node867 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected867 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected867 ((14 : Int),(0 : Int)) hp6_2_branches867 hp6_2_evidence867 hp6_2_check867 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches867,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node868 T childKnown
  · exact hp6_2_node869 T childKnown
theorem hp6_2_node866 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected866 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected866 ((12 : Int),(1 : Int)) hp6_2_branches866 hp6_2_evidence866 hp6_2_check866 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches866,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node867 T childKnown
theorem hp6_2_node865 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected865 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected865 ((4 : Int),(2 : Int)) hp6_2_branches865 hp6_2_evidence865 hp6_2_check865 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches865,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node864 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected864 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected864 ((9 : Int),(1 : Int)) hp6_2_branches864 hp6_2_evidence864 hp6_2_check864 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches864,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node865 T childKnown
theorem hp6_2_node863 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected863 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected863 ((1 : Int),(1 : Int)) hp6_2_branches863 hp6_2_evidence863 hp6_2_check863 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches863,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node862 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected862 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected862 ((8 : Int),(2 : Int)) hp6_2_branches862 hp6_2_evidence862 hp6_2_check862 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches862,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node863 T childKnown
theorem hp6_2_node861 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected861 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected861 ((10 : Int),(2 : Int)) hp6_2_branches861 hp6_2_evidence861 hp6_2_check861 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches861,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node862 T childKnown
theorem hp6_2_node860 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected860 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected860 ((5 : Int),(2 : Int)) hp6_2_branches860 hp6_2_evidence860 hp6_2_check860 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches860,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node859 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected859 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected859 ((10 : Int),(2 : Int)) hp6_2_branches859 hp6_2_evidence859 hp6_2_check859 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches859,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node860 T childKnown
theorem hp6_2_node858 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected858 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected858 ((10 : Int),(1 : Int)) hp6_2_branches858 hp6_2_evidence858 hp6_2_check858 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches858,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node859 T childKnown
  · exact hp6_2_node861 T childKnown
  · exact hp6_2_node864 T childKnown
theorem hp6_2_node857 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected857 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected857 ((14 : Int),(0 : Int)) hp6_2_branches857 hp6_2_evidence857 hp6_2_check857 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches857,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node858 T childKnown
theorem hp6_2_node856 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected856 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected856 ((12 : Int),(1 : Int)) hp6_2_branches856 hp6_2_evidence856 hp6_2_check856 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches856,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node857 T childKnown
theorem hp6_2_node855 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected855 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected855 ((12 : Int),(1 : Int)) hp6_2_branches855 hp6_2_evidence855 hp6_2_check855 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches855,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node854 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected854 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected854 ((12 : Int),(1 : Int)) hp6_2_branches854 hp6_2_evidence854 hp6_2_check854 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches854,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node853 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected853 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected853 ((13 : Int),(0 : Int)) hp6_2_branches853 hp6_2_evidence853 hp6_2_check853 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches853,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node854 T childKnown
  · exact hp6_2_node855 T childKnown
  · exact hp6_2_node856 T childKnown
  · exact hp6_2_node866 T childKnown
  · exact hp6_2_node870 T childKnown
  · exact hp6_2_node883 T childKnown
theorem hp6_2_node852 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected852 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected852 ((1 : Int),(1 : Int)) hp6_2_branches852 hp6_2_evidence852 hp6_2_check852 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches852,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node851 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected851 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected851 ((1 : Int),(1 : Int)) hp6_2_branches851 hp6_2_evidence851 hp6_2_check851 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches851,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node850 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected850 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected850 ((1 : Int),(1 : Int)) hp6_2_branches850 hp6_2_evidence850 hp6_2_check850 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches850,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node849 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected849 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected849 ((2 : Int),(1 : Int)) hp6_2_branches849 hp6_2_evidence849 hp6_2_check849 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches849,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node848 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected848 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected848 ((2 : Int),(1 : Int)) hp6_2_branches848 hp6_2_evidence848 hp6_2_check848 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches848,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node847 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected847 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected847 ((1 : Int),(1 : Int)) hp6_2_branches847 hp6_2_evidence847 hp6_2_check847 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches847,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node848 T childKnown
  · exact hp6_2_node849 T childKnown
theorem hp6_2_node846 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected846 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected846 ((1 : Int),(1 : Int)) hp6_2_branches846 hp6_2_evidence846 hp6_2_check846 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches846,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node845 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected845 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected845 ((0 : Int),(1 : Int)) hp6_2_branches845 hp6_2_evidence845 hp6_2_check845 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches845,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node846 T childKnown
  · exact hp6_2_node847 T childKnown
  · exact hp6_2_node850 T childKnown
  · exact hp6_2_node851 T childKnown
  · exact hp6_2_node852 T childKnown
theorem hp6_2_node844 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected844 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected844 ((3 : Int),(1 : Int)) hp6_2_branches844 hp6_2_evidence844 hp6_2_check844 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches844,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node843 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected843 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected843 ((2 : Int),(1 : Int)) hp6_2_branches843 hp6_2_evidence843 hp6_2_check843 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches843,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node842 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected842 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected842 ((4 : Int),(1 : Int)) hp6_2_branches842 hp6_2_evidence842 hp6_2_check842 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches842,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node843 T childKnown
  · exact hp6_2_node844 T childKnown
theorem hp6_2_node841 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected841 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected841 ((3 : Int),(1 : Int)) hp6_2_branches841 hp6_2_evidence841 hp6_2_check841 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches841,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node840 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected840 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected840 ((2 : Int),(1 : Int)) hp6_2_branches840 hp6_2_evidence840 hp6_2_check840 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches840,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node839 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected839 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected839 ((4 : Int),(1 : Int)) hp6_2_branches839 hp6_2_evidence839 hp6_2_check839 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches839,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node840 T childKnown
  · exact hp6_2_node841 T childKnown
theorem hp6_2_node838 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected838 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected838 ((6 : Int),(0 : Int)) hp6_2_branches838 hp6_2_evidence838 hp6_2_check838 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches838,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node839 T childKnown
theorem hp6_2_node837 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected837 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected837 ((4 : Int),(1 : Int)) hp6_2_branches837 hp6_2_evidence837 hp6_2_check837 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches837,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node836 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected836 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected836 ((4 : Int),(1 : Int)) hp6_2_branches836 hp6_2_evidence836 hp6_2_check836 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches836,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node835 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected835 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected835 ((1 : Int),(1 : Int)) hp6_2_branches835 hp6_2_evidence835 hp6_2_check835 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches835,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node834 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected834 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected834 ((1 : Int),(1 : Int)) hp6_2_branches834 hp6_2_evidence834 hp6_2_check834 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches834,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node833 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected833 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected833 ((2 : Int),(1 : Int)) hp6_2_branches833 hp6_2_evidence833 hp6_2_check833 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches833,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node832 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected832 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected832 ((2 : Int),(1 : Int)) hp6_2_branches832 hp6_2_evidence832 hp6_2_check832 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches832,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node831 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected831 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected831 ((1 : Int),(1 : Int)) hp6_2_branches831 hp6_2_evidence831 hp6_2_check831 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches831,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node832 T childKnown
  · exact hp6_2_node833 T childKnown
theorem hp6_2_node830 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected830 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected830 ((1 : Int),(1 : Int)) hp6_2_branches830 hp6_2_evidence830 hp6_2_check830 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches830,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node829 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected829 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected829 ((0 : Int),(1 : Int)) hp6_2_branches829 hp6_2_evidence829 hp6_2_check829 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches829,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node830 T childKnown
  · exact hp6_2_node831 T childKnown
  · exact hp6_2_node834 T childKnown
  · exact hp6_2_node835 T childKnown
theorem hp6_2_node828 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected828 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected828 ((0 : Int),(1 : Int)) hp6_2_branches828 hp6_2_evidence828 hp6_2_check828 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches828,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node827 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected827 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected827 ((5 : Int),(0 : Int)) hp6_2_branches827 hp6_2_evidence827 hp6_2_check827 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches827,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node828 T childKnown
  · exact hp6_2_node829 T childKnown
  · exact hp6_2_node836 T childKnown
  · exact hp6_2_node837 T childKnown
  · exact hp6_2_node838 T childKnown
  · exact hp6_2_node842 T childKnown
  · exact hp6_2_node845 T childKnown
  · exact hp6_2_node853 T childKnown
theorem hp6_2_node826 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected826 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected826 ((4 : Int),(1 : Int)) hp6_2_branches826 hp6_2_evidence826 hp6_2_check826 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches826,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node825 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected825 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected825 ((4 : Int),(1 : Int)) hp6_2_branches825 hp6_2_evidence825 hp6_2_check825 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches825,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node824 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected824 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected824 ((4 : Int),(1 : Int)) hp6_2_branches824 hp6_2_evidence824 hp6_2_check824 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches824,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node823 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected823 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected823 ((5 : Int),(1 : Int)) hp6_2_branches823 hp6_2_evidence823 hp6_2_check823 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches823,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node822 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected822 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected822 ((5 : Int),(1 : Int)) hp6_2_branches822 hp6_2_evidence822 hp6_2_check822 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches822,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node821 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected821 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected821 ((4 : Int),(1 : Int)) hp6_2_branches821 hp6_2_evidence821 hp6_2_check821 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches821,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node822 T childKnown
  · exact hp6_2_node823 T childKnown
theorem hp6_2_node820 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected820 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected820 ((4 : Int),(1 : Int)) hp6_2_branches820 hp6_2_evidence820 hp6_2_check820 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches820,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node819 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected819 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected819 ((3 : Int),(1 : Int)) hp6_2_branches819 hp6_2_evidence819 hp6_2_check819 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches819,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node820 T childKnown
  · exact hp6_2_node821 T childKnown
  · exact hp6_2_node824 T childKnown
  · exact hp6_2_node825 T childKnown
  · exact hp6_2_node826 T childKnown
theorem hp6_2_node818 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected818 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected818 ((4 : Int),(1 : Int)) hp6_2_branches818 hp6_2_evidence818 hp6_2_check818 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches818,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node817 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected817 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected817 ((4 : Int),(1 : Int)) hp6_2_branches817 hp6_2_evidence817 hp6_2_check817 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches817,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node816 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected816 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected816 ((0 : Int),(2 : Int)) hp6_2_branches816 hp6_2_evidence816 hp6_2_check816 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches816,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node815 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected815 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected815 ((0 : Int),(1 : Int)) hp6_2_branches815 hp6_2_evidence815 hp6_2_check815 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches815,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node816 T childKnown
theorem hp6_2_node814 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected814 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected814 ((7 : Int),(2 : Int)) hp6_2_branches814 hp6_2_evidence814 hp6_2_check814 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches814,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node813 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected813 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected813 ((6 : Int),(2 : Int)) hp6_2_branches813 hp6_2_evidence813 hp6_2_check813 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches813,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node814 T childKnown
theorem hp6_2_node812 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected812 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected812 ((14 : Int),(1 : Int)) hp6_2_branches812 hp6_2_evidence812 hp6_2_check812 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches812,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node811 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected811 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected811 ((8 : Int),(2 : Int)) hp6_2_branches811 hp6_2_evidence811 hp6_2_check811 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches811,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node812 T childKnown
theorem hp6_2_node810 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected810 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected810 ((12 : Int),(0 : Int)) hp6_2_branches810 hp6_2_evidence810 hp6_2_check810 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches810,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node811 T childKnown
theorem hp6_2_node809 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected809 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected809 ((6 : Int),(2 : Int)) hp6_2_branches809 hp6_2_evidence809 hp6_2_check809 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches809,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node810 T childKnown
theorem hp6_2_node808 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected808 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected808 ((7 : Int),(2 : Int)) hp6_2_branches808 hp6_2_evidence808 hp6_2_check808 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches808,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node807 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected807 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected807 ((7 : Int),(1 : Int)) hp6_2_branches807 hp6_2_evidence807 hp6_2_check807 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches807,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node808 T childKnown
theorem hp6_2_node806 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected806 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected806 ((6 : Int),(1 : Int)) hp6_2_branches806 hp6_2_evidence806 hp6_2_check806 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches806,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node807 T childKnown
  · exact hp6_2_node809 T childKnown
  · exact hp6_2_node813 T childKnown
theorem hp6_2_node805 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected805 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected805 ((1 : Int),(2 : Int)) hp6_2_branches805 hp6_2_evidence805 hp6_2_check805 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches805,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node806 T childKnown
theorem hp6_2_node804 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected804 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected804 ((0 : Int),(2 : Int)) hp6_2_branches804 hp6_2_evidence804 hp6_2_check804 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches804,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node803 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected803 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected803 ((1 : Int),(2 : Int)) hp6_2_branches803 hp6_2_evidence803 hp6_2_check803 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches803,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node804 T childKnown
theorem hp6_2_node802 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected802 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected802 ((1 : Int),(1 : Int)) hp6_2_branches802 hp6_2_evidence802 hp6_2_check802 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches802,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node803 T childKnown
  · exact hp6_2_node805 T childKnown
  · exact hp6_2_node815 T childKnown
theorem hp6_2_node801 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected801 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected801 ((4 : Int),(1 : Int)) hp6_2_branches801 hp6_2_evidence801 hp6_2_check801 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches801,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node802 T childKnown
theorem hp6_2_node800 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected800 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected800 ((4 : Int),(1 : Int)) hp6_2_branches800 hp6_2_evidence800 hp6_2_check800 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches800,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node799 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected799 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected799 ((3 : Int),(1 : Int)) hp6_2_branches799 hp6_2_evidence799 hp6_2_check799 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches799,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node800 T childKnown
  · exact hp6_2_node801 T childKnown
  · exact hp6_2_node817 T childKnown
  · exact hp6_2_node818 T childKnown
theorem hp6_2_node798 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected798 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected798 ((5 : Int),(1 : Int)) hp6_2_branches798 hp6_2_evidence798 hp6_2_check798 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches798,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node797 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected797 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected797 ((5 : Int),(1 : Int)) hp6_2_branches797 hp6_2_evidence797 hp6_2_check797 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches797,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node796 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected796 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected796 ((5 : Int),(0 : Int)) hp6_2_branches796 hp6_2_evidence796 hp6_2_check796 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches796,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node797 T childKnown
  · exact hp6_2_node798 T childKnown
theorem hp6_2_node795 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected795 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected795 ((3 : Int),(1 : Int)) hp6_2_branches795 hp6_2_evidence795 hp6_2_check795 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches795,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node796 T childKnown
theorem hp6_2_node794 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected794 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected794 ((0 : Int),(2 : Int)) hp6_2_branches794 hp6_2_evidence794 hp6_2_check794 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches794,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node793 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected793 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected793 ((0 : Int),(1 : Int)) hp6_2_branches793 hp6_2_evidence793 hp6_2_check793 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches793,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node794 T childKnown
theorem hp6_2_node792 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected792 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected792 ((9 : Int),(1 : Int)) hp6_2_branches792 hp6_2_evidence792 hp6_2_check792 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches792,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node791 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected791 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected791 ((9 : Int),(1 : Int)) hp6_2_branches791 hp6_2_evidence791 hp6_2_check791 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches791,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node790 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected790 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected790 ((8 : Int),(1 : Int)) hp6_2_branches790 hp6_2_evidence790 hp6_2_check790 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches790,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node791 T childKnown
  · exact hp6_2_node792 T childKnown
theorem hp6_2_node789 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected789 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected789 ((7 : Int),(1 : Int)) hp6_2_branches789 hp6_2_evidence789 hp6_2_check789 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches789,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node788 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected788 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected788 ((6 : Int),(2 : Int)) hp6_2_branches788 hp6_2_evidence788 hp6_2_check788 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches788,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node789 T childKnown
theorem hp6_2_node787 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected787 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected787 ((7 : Int),(1 : Int)) hp6_2_branches787 hp6_2_evidence787 hp6_2_check787 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches787,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node786 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected786 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected786 ((5 : Int),(2 : Int)) hp6_2_branches786 hp6_2_evidence786 hp6_2_check786 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches786,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node787 T childKnown
  · exact hp6_2_node788 T childKnown
  · exact hp6_2_node790 T childKnown
theorem hp6_2_node785 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected785 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected785 ((1 : Int),(2 : Int)) hp6_2_branches785 hp6_2_evidence785 hp6_2_check785 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches785,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node786 T childKnown
theorem hp6_2_node784 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected784 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected784 ((0 : Int),(2 : Int)) hp6_2_branches784 hp6_2_evidence784 hp6_2_check784 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches784,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node783 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected783 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected783 ((1 : Int),(2 : Int)) hp6_2_branches783 hp6_2_evidence783 hp6_2_check783 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches783,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node784 T childKnown
theorem hp6_2_node782 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected782 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected782 ((1 : Int),(1 : Int)) hp6_2_branches782 hp6_2_evidence782 hp6_2_check782 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches782,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node783 T childKnown
  · exact hp6_2_node785 T childKnown
  · exact hp6_2_node793 T childKnown
theorem hp6_2_node781 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected781 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected781 ((5 : Int),(0 : Int)) hp6_2_branches781 hp6_2_evidence781 hp6_2_check781 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches781,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node782 T childKnown
theorem hp6_2_node780 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected780 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected780 ((3 : Int),(1 : Int)) hp6_2_branches780 hp6_2_evidence780 hp6_2_check780 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches780,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node781 T childKnown
theorem hp6_2_node779 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected779 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected779 ((3 : Int),(1 : Int)) hp6_2_branches779 hp6_2_evidence779 hp6_2_check779 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches779,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node778 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected778 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected778 ((3 : Int),(1 : Int)) hp6_2_branches778 hp6_2_evidence778 hp6_2_check778 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches778,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node777 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected777 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected777 ((4 : Int),(0 : Int)) hp6_2_branches777 hp6_2_evidence777 hp6_2_check777 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches777,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node778 T childKnown
  · exact hp6_2_node779 T childKnown
  · exact hp6_2_node780 T childKnown
  · exact hp6_2_node795 T childKnown
  · exact hp6_2_node799 T childKnown
  · exact hp6_2_node819 T childKnown
theorem hp6_2_node776 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected776 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected776 ((12 : Int),(1 : Int)) hp6_2_branches776 hp6_2_evidence776 hp6_2_check776 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches776,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node775 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected775 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected775 ((12 : Int),(1 : Int)) hp6_2_branches775 hp6_2_evidence775 hp6_2_check775 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches775,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node774 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected774 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected774 ((12 : Int),(1 : Int)) hp6_2_branches774 hp6_2_evidence774 hp6_2_check774 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches774,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node773 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected773 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected773 ((13 : Int),(1 : Int)) hp6_2_branches773 hp6_2_evidence773 hp6_2_check773 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches773,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node772 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected772 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected772 ((13 : Int),(1 : Int)) hp6_2_branches772 hp6_2_evidence772 hp6_2_check772 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches772,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node771 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected771 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected771 ((12 : Int),(1 : Int)) hp6_2_branches771 hp6_2_evidence771 hp6_2_check771 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches771,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node772 T childKnown
  · exact hp6_2_node773 T childKnown
theorem hp6_2_node770 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected770 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected770 ((12 : Int),(1 : Int)) hp6_2_branches770 hp6_2_evidence770 hp6_2_check770 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches770,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node769 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected769 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected769 ((11 : Int),(1 : Int)) hp6_2_branches769 hp6_2_evidence769 hp6_2_check769 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches769,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node770 T childKnown
  · exact hp6_2_node771 T childKnown
  · exact hp6_2_node774 T childKnown
  · exact hp6_2_node775 T childKnown
  · exact hp6_2_node776 T childKnown
theorem hp6_2_node768 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected768 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected768 ((12 : Int),(1 : Int)) hp6_2_branches768 hp6_2_evidence768 hp6_2_check768 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches768,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node767 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected767 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected767 ((12 : Int),(1 : Int)) hp6_2_branches767 hp6_2_evidence767 hp6_2_check767 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches767,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node766 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected766 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected766 ((3 : Int),(2 : Int)) hp6_2_branches766 hp6_2_evidence766 hp6_2_check766 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches766,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node765 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected765 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected765 ((8 : Int),(1 : Int)) hp6_2_branches765 hp6_2_evidence765 hp6_2_check765 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches765,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node766 T childKnown
theorem hp6_2_node764 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected764 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected764 ((0 : Int),(1 : Int)) hp6_2_branches764 hp6_2_evidence764 hp6_2_check764 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches764,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node763 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected763 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected763 ((7 : Int),(2 : Int)) hp6_2_branches763 hp6_2_evidence763 hp6_2_check763 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches763,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node764 T childKnown
theorem hp6_2_node762 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected762 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected762 ((9 : Int),(2 : Int)) hp6_2_branches762 hp6_2_evidence762 hp6_2_check762 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches762,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node763 T childKnown
theorem hp6_2_node761 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected761 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected761 ((4 : Int),(2 : Int)) hp6_2_branches761 hp6_2_evidence761 hp6_2_check761 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches761,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node760 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected760 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected760 ((9 : Int),(2 : Int)) hp6_2_branches760 hp6_2_evidence760 hp6_2_check760 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches760,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node761 T childKnown
theorem hp6_2_node759 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected759 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected759 ((9 : Int),(1 : Int)) hp6_2_branches759 hp6_2_evidence759 hp6_2_check759 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches759,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node760 T childKnown
  · exact hp6_2_node762 T childKnown
  · exact hp6_2_node765 T childKnown
theorem hp6_2_node758 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected758 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected758 ((12 : Int),(1 : Int)) hp6_2_branches758 hp6_2_evidence758 hp6_2_check758 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches758,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node759 T childKnown
theorem hp6_2_node757 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected757 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected757 ((12 : Int),(1 : Int)) hp6_2_branches757 hp6_2_evidence757 hp6_2_check757 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches757,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node756 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected756 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected756 ((11 : Int),(1 : Int)) hp6_2_branches756 hp6_2_evidence756 hp6_2_check756 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches756,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node757 T childKnown
  · exact hp6_2_node758 T childKnown
  · exact hp6_2_node767 T childKnown
  · exact hp6_2_node768 T childKnown
theorem hp6_2_node755 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected755 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected755 ((13 : Int),(1 : Int)) hp6_2_branches755 hp6_2_evidence755 hp6_2_check755 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches755,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node754 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected754 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected754 ((13 : Int),(1 : Int)) hp6_2_branches754 hp6_2_evidence754 hp6_2_check754 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches754,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node753 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected753 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected753 ((13 : Int),(0 : Int)) hp6_2_branches753 hp6_2_evidence753 hp6_2_check753 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches753,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node754 T childKnown
  · exact hp6_2_node755 T childKnown
theorem hp6_2_node752 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected752 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected752 ((11 : Int),(1 : Int)) hp6_2_branches752 hp6_2_evidence752 hp6_2_check752 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches752,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node753 T childKnown
theorem hp6_2_node751 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected751 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected751 ((3 : Int),(2 : Int)) hp6_2_branches751 hp6_2_evidence751 hp6_2_check751 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches751,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node750 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected750 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected750 ((8 : Int),(1 : Int)) hp6_2_branches750 hp6_2_evidence750 hp6_2_check750 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches750,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node751 T childKnown
theorem hp6_2_node749 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected749 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected749 ((0 : Int),(1 : Int)) hp6_2_branches749 hp6_2_evidence749 hp6_2_check749 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches749,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node748 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected748 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected748 ((7 : Int),(2 : Int)) hp6_2_branches748 hp6_2_evidence748 hp6_2_check748 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches748,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node749 T childKnown
theorem hp6_2_node747 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected747 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected747 ((9 : Int),(2 : Int)) hp6_2_branches747 hp6_2_evidence747 hp6_2_check747 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches747,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node748 T childKnown
theorem hp6_2_node746 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected746 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected746 ((4 : Int),(2 : Int)) hp6_2_branches746 hp6_2_evidence746 hp6_2_check746 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches746,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node745 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected745 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected745 ((9 : Int),(2 : Int)) hp6_2_branches745 hp6_2_evidence745 hp6_2_check745 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches745,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node746 T childKnown
theorem hp6_2_node744 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected744 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected744 ((9 : Int),(1 : Int)) hp6_2_branches744 hp6_2_evidence744 hp6_2_check744 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches744,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node745 T childKnown
  · exact hp6_2_node747 T childKnown
  · exact hp6_2_node750 T childKnown
theorem hp6_2_node743 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected743 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected743 ((13 : Int),(0 : Int)) hp6_2_branches743 hp6_2_evidence743 hp6_2_check743 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches743,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node744 T childKnown
theorem hp6_2_node742 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected742 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected742 ((11 : Int),(1 : Int)) hp6_2_branches742 hp6_2_evidence742 hp6_2_check742 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches742,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node743 T childKnown
theorem hp6_2_node741 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected741 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected741 ((11 : Int),(1 : Int)) hp6_2_branches741 hp6_2_evidence741 hp6_2_check741 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches741,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node740 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected740 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected740 ((11 : Int),(1 : Int)) hp6_2_branches740 hp6_2_evidence740 hp6_2_check740 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches740,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node739 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected739 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected739 ((12 : Int),(0 : Int)) hp6_2_branches739 hp6_2_evidence739 hp6_2_check739 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches739,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node740 T childKnown
  · exact hp6_2_node741 T childKnown
  · exact hp6_2_node742 T childKnown
  · exact hp6_2_node752 T childKnown
  · exact hp6_2_node756 T childKnown
  · exact hp6_2_node769 T childKnown
theorem hp6_2_node738 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected738 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected738 ((4 : Int),(1 : Int)) hp6_2_branches738 hp6_2_evidence738 hp6_2_check738 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches738,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node737 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected737 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected737 ((2 : Int),(1 : Int)) hp6_2_branches737 hp6_2_evidence737 hp6_2_check737 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches737,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node736 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected736 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected736 ((2 : Int),(1 : Int)) hp6_2_branches736 hp6_2_evidence736 hp6_2_check736 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches736,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node735 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected735 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected735 ((1 : Int),(1 : Int)) hp6_2_branches735 hp6_2_evidence735 hp6_2_check735 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches735,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node734 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected734 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected734 ((0 : Int),(1 : Int)) hp6_2_branches734 hp6_2_evidence734 hp6_2_check734 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches734,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node733 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected733 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected733 ((3 : Int),(1 : Int)) hp6_2_branches733 hp6_2_evidence733 hp6_2_check733 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches733,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node734 T childKnown
  · exact hp6_2_node735 T childKnown
  · exact hp6_2_node736 T childKnown
  · exact hp6_2_node737 T childKnown
  · exact hp6_2_node738 T childKnown
theorem hp6_2_node732 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected732 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected732 ((2 : Int),(1 : Int)) hp6_2_branches732 hp6_2_evidence732 hp6_2_check732 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches732,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node731 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected731 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected731 ((1 : Int),(1 : Int)) hp6_2_branches731 hp6_2_evidence731 hp6_2_check731 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches731,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node730 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected730 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected730 ((3 : Int),(1 : Int)) hp6_2_branches730 hp6_2_evidence730 hp6_2_check730 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches730,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node731 T childKnown
  · exact hp6_2_node732 T childKnown
theorem hp6_2_node729 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected729 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected729 ((2 : Int),(1 : Int)) hp6_2_branches729 hp6_2_evidence729 hp6_2_check729 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches729,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node728 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected728 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected728 ((1 : Int),(1 : Int)) hp6_2_branches728 hp6_2_evidence728 hp6_2_check728 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches728,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node727 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected727 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected727 ((3 : Int),(1 : Int)) hp6_2_branches727 hp6_2_evidence727 hp6_2_check727 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches727,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node728 T childKnown
  · exact hp6_2_node729 T childKnown
theorem hp6_2_node726 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected726 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected726 ((5 : Int),(0 : Int)) hp6_2_branches726 hp6_2_evidence726 hp6_2_check726 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches726,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node727 T childKnown
theorem hp6_2_node725 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected725 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected725 ((3 : Int),(1 : Int)) hp6_2_branches725 hp6_2_evidence725 hp6_2_check725 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches725,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node724 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected724 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected724 ((3 : Int),(1 : Int)) hp6_2_branches724 hp6_2_evidence724 hp6_2_check724 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches724,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node723 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected723 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected723 ((0 : Int),(1 : Int)) hp6_2_branches723 hp6_2_evidence723 hp6_2_check723 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches723,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node722 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected722 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected722 ((0 : Int),(1 : Int)) hp6_2_branches722 hp6_2_evidence722 hp6_2_check722 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches722,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node721 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected721 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected721 ((0 : Int),(1 : Int)) hp6_2_branches721 hp6_2_evidence721 hp6_2_check721 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches721,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node720 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected720 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected720 ((1 : Int),(1 : Int)) hp6_2_branches720 hp6_2_evidence720 hp6_2_check720 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches720,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node721 T childKnown
  · exact hp6_2_node722 T childKnown
  · exact hp6_2_node723 T childKnown
theorem hp6_2_node719 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected719 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected719 ((0 : Int),(1 : Int)) hp6_2_branches719 hp6_2_evidence719 hp6_2_check719 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches719,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node718 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected718 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected718 ((1 : Int),(1 : Int)) hp6_2_branches718 hp6_2_evidence718 hp6_2_check718 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches718,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node719 T childKnown
theorem hp6_2_node717 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected717 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected717 ((1 : Int),(1 : Int)) hp6_2_branches717 hp6_2_evidence717 hp6_2_check717 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches717,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node716 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected716 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected716 ((6 : Int),(1 : Int)) hp6_2_branches716 hp6_2_evidence716 hp6_2_check716 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches716,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node715 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected715 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected715 ((6 : Int),(1 : Int)) hp6_2_branches715 hp6_2_evidence715 hp6_2_check715 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches715,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node714 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected714 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected714 ((5 : Int),(1 : Int)) hp6_2_branches714 hp6_2_evidence714 hp6_2_check714 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches714,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node715 T childKnown
  · exact hp6_2_node716 T childKnown
theorem hp6_2_node713 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected713 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected713 ((8 : Int),(2 : Int)) hp6_2_branches713 hp6_2_evidence713 hp6_2_check713 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches713,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node712 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected712 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected712 ((7 : Int),(2 : Int)) hp6_2_branches712 hp6_2_evidence712 hp6_2_check712 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches712,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node713 T childKnown
theorem hp6_2_node711 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected711 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected711 ((15 : Int),(1 : Int)) hp6_2_branches711 hp6_2_evidence711 hp6_2_check711 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches711,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node710 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected710 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected710 ((9 : Int),(2 : Int)) hp6_2_branches710 hp6_2_evidence710 hp6_2_check710 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches710,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node711 T childKnown
theorem hp6_2_node709 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected709 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected709 ((13 : Int),(0 : Int)) hp6_2_branches709 hp6_2_evidence709 hp6_2_check709 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches709,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node710 T childKnown
theorem hp6_2_node708 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected708 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected708 ((7 : Int),(2 : Int)) hp6_2_branches708 hp6_2_evidence708 hp6_2_check708 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches708,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node709 T childKnown
theorem hp6_2_node707 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected707 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected707 ((8 : Int),(2 : Int)) hp6_2_branches707 hp6_2_evidence707 hp6_2_check707 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches707,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node706 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected706 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected706 ((8 : Int),(1 : Int)) hp6_2_branches706 hp6_2_evidence706 hp6_2_check706 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches706,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node707 T childKnown
theorem hp6_2_node705 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected705 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected705 ((7 : Int),(1 : Int)) hp6_2_branches705 hp6_2_evidence705 hp6_2_check705 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches705,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node706 T childKnown
  · exact hp6_2_node708 T childKnown
  · exact hp6_2_node712 T childKnown
theorem hp6_2_node704 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected704 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected704 ((5 : Int),(1 : Int)) hp6_2_branches704 hp6_2_evidence704 hp6_2_check704 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches704,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node705 T childKnown
theorem hp6_2_node703 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected703 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected703 ((6 : Int),(1 : Int)) hp6_2_branches703 hp6_2_evidence703 hp6_2_check703 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches703,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node702 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected702 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected702 ((6 : Int),(1 : Int)) hp6_2_branches702 hp6_2_evidence702 hp6_2_check702 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches702,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node701 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected701 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected701 ((6 : Int),(0 : Int)) hp6_2_branches701 hp6_2_evidence701 hp6_2_check701 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches701,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node702 T childKnown
  · exact hp6_2_node703 T childKnown
theorem hp6_2_node700 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected700 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected700 ((10 : Int),(1 : Int)) hp6_2_branches700 hp6_2_evidence700 hp6_2_check700 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches700,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node699 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected699 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected699 ((10 : Int),(1 : Int)) hp6_2_branches699 hp6_2_evidence699 hp6_2_check699 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches699,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node698 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected698 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected698 ((9 : Int),(1 : Int)) hp6_2_branches698 hp6_2_evidence698 hp6_2_check698 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches698,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node699 T childKnown
  · exact hp6_2_node700 T childKnown
theorem hp6_2_node697 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected697 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected697 ((8 : Int),(1 : Int)) hp6_2_branches697 hp6_2_evidence697 hp6_2_check697 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches697,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node696 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected696 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected696 ((7 : Int),(2 : Int)) hp6_2_branches696 hp6_2_evidence696 hp6_2_check696 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches696,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node697 T childKnown
theorem hp6_2_node695 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected695 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected695 ((8 : Int),(1 : Int)) hp6_2_branches695 hp6_2_evidence695 hp6_2_check695 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches695,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node694 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected694 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected694 ((8 : Int),(1 : Int)) hp6_2_branches694 hp6_2_evidence694 hp6_2_check694 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches694,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node693 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected693 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected693 ((8 : Int),(1 : Int)) hp6_2_branches693 hp6_2_evidence693 hp6_2_check693 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches693,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node692 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected692 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected692 ((8 : Int),(1 : Int)) hp6_2_branches692 hp6_2_evidence692 hp6_2_check692 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches692,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node691 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected691 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected691 ((7 : Int),(2 : Int)) hp6_2_branches691 hp6_2_evidence691 hp6_2_check691 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches691,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node692 T childKnown
  · exact hp6_2_node693 T childKnown
  · exact hp6_2_node694 T childKnown
theorem hp6_2_node690 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected690 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected690 ((6 : Int),(2 : Int)) hp6_2_branches690 hp6_2_evidence690 hp6_2_check690 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches690,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node691 T childKnown
  · exact hp6_2_node695 T childKnown
  · exact hp6_2_node696 T childKnown
  · exact hp6_2_node698 T childKnown
theorem hp6_2_node689 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected689 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected689 ((6 : Int),(0 : Int)) hp6_2_branches689 hp6_2_evidence689 hp6_2_check689 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches689,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node690 T childKnown
theorem hp6_2_node688 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected688 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected688 ((5 : Int),(0 : Int)) hp6_2_branches688 hp6_2_evidence688 hp6_2_check688 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches688,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node689 T childKnown
  · exact hp6_2_node701 T childKnown
  · exact hp6_2_node704 T childKnown
  · exact hp6_2_node714 T childKnown
theorem hp6_2_node687 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected687 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected687 ((6 : Int),(1 : Int)) hp6_2_branches687 hp6_2_evidence687 hp6_2_check687 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches687,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node686 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected686 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected686 ((6 : Int),(1 : Int)) hp6_2_branches686 hp6_2_evidence686 hp6_2_check686 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches686,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node685 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected685 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected685 ((5 : Int),(1 : Int)) hp6_2_branches685 hp6_2_evidence685 hp6_2_check685 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches685,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node686 T childKnown
  · exact hp6_2_node687 T childKnown
theorem hp6_2_node684 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected684 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected684 ((8 : Int),(2 : Int)) hp6_2_branches684 hp6_2_evidence684 hp6_2_check684 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches684,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node683 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected683 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected683 ((7 : Int),(2 : Int)) hp6_2_branches683 hp6_2_evidence683 hp6_2_check683 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches683,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node684 T childKnown
theorem hp6_2_node682 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected682 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected682 ((15 : Int),(1 : Int)) hp6_2_branches682 hp6_2_evidence682 hp6_2_check682 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches682,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node681 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected681 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected681 ((9 : Int),(2 : Int)) hp6_2_branches681 hp6_2_evidence681 hp6_2_check681 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches681,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node682 T childKnown
theorem hp6_2_node680 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected680 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected680 ((13 : Int),(0 : Int)) hp6_2_branches680 hp6_2_evidence680 hp6_2_check680 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches680,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node681 T childKnown
theorem hp6_2_node679 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected679 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected679 ((7 : Int),(2 : Int)) hp6_2_branches679 hp6_2_evidence679 hp6_2_check679 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches679,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node680 T childKnown
theorem hp6_2_node678 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected678 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected678 ((8 : Int),(2 : Int)) hp6_2_branches678 hp6_2_evidence678 hp6_2_check678 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches678,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node677 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected677 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected677 ((8 : Int),(1 : Int)) hp6_2_branches677 hp6_2_evidence677 hp6_2_check677 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches677,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node678 T childKnown
theorem hp6_2_node676 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected676 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected676 ((7 : Int),(1 : Int)) hp6_2_branches676 hp6_2_evidence676 hp6_2_check676 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches676,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node677 T childKnown
  · exact hp6_2_node679 T childKnown
  · exact hp6_2_node683 T childKnown
theorem hp6_2_node675 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected675 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected675 ((5 : Int),(1 : Int)) hp6_2_branches675 hp6_2_evidence675 hp6_2_check675 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches675,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node676 T childKnown
theorem hp6_2_node674 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected674 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected674 ((6 : Int),(1 : Int)) hp6_2_branches674 hp6_2_evidence674 hp6_2_check674 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches674,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node673 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected673 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected673 ((6 : Int),(1 : Int)) hp6_2_branches673 hp6_2_evidence673 hp6_2_check673 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches673,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node672 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected672 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected672 ((6 : Int),(0 : Int)) hp6_2_branches672 hp6_2_evidence672 hp6_2_check672 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches672,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node673 T childKnown
  · exact hp6_2_node674 T childKnown
theorem hp6_2_node671 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected671 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected671 ((10 : Int),(1 : Int)) hp6_2_branches671 hp6_2_evidence671 hp6_2_check671 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches671,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node670 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected670 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected670 ((10 : Int),(1 : Int)) hp6_2_branches670 hp6_2_evidence670 hp6_2_check670 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches670,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node669 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected669 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected669 ((9 : Int),(1 : Int)) hp6_2_branches669 hp6_2_evidence669 hp6_2_check669 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches669,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node670 T childKnown
  · exact hp6_2_node671 T childKnown
theorem hp6_2_node668 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected668 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected668 ((8 : Int),(1 : Int)) hp6_2_branches668 hp6_2_evidence668 hp6_2_check668 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches668,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node667 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected667 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected667 ((7 : Int),(2 : Int)) hp6_2_branches667 hp6_2_evidence667 hp6_2_check667 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches667,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node668 T childKnown
theorem hp6_2_node666 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected666 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected666 ((8 : Int),(1 : Int)) hp6_2_branches666 hp6_2_evidence666 hp6_2_check666 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches666,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node665 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected665 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected665 ((8 : Int),(1 : Int)) hp6_2_branches665 hp6_2_evidence665 hp6_2_check665 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches665,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node664 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected664 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected664 ((8 : Int),(1 : Int)) hp6_2_branches664 hp6_2_evidence664 hp6_2_check664 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches664,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node663 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected663 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected663 ((8 : Int),(1 : Int)) hp6_2_branches663 hp6_2_evidence663 hp6_2_check663 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches663,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node662 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected662 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected662 ((7 : Int),(2 : Int)) hp6_2_branches662 hp6_2_evidence662 hp6_2_check662 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches662,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node663 T childKnown
  · exact hp6_2_node664 T childKnown
  · exact hp6_2_node665 T childKnown
theorem hp6_2_node661 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected661 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected661 ((6 : Int),(2 : Int)) hp6_2_branches661 hp6_2_evidence661 hp6_2_check661 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches661,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node662 T childKnown
  · exact hp6_2_node666 T childKnown
  · exact hp6_2_node667 T childKnown
  · exact hp6_2_node669 T childKnown
theorem hp6_2_node660 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected660 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected660 ((6 : Int),(0 : Int)) hp6_2_branches660 hp6_2_evidence660 hp6_2_check660 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches660,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node661 T childKnown
theorem hp6_2_node659 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected659 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected659 ((5 : Int),(0 : Int)) hp6_2_branches659 hp6_2_evidence659 hp6_2_check659 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches659,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node660 T childKnown
  · exact hp6_2_node672 T childKnown
  · exact hp6_2_node675 T childKnown
  · exact hp6_2_node685 T childKnown
theorem hp6_2_node658 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected658 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected658 ((0 : Int),(1 : Int)) hp6_2_branches658 hp6_2_evidence658 hp6_2_check658 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches658,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node659 T childKnown
  · exact hp6_2_node688 T childKnown
theorem hp6_2_node657 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected657 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected657 ((3 : Int),(2 : Int)) hp6_2_branches657 hp6_2_evidence657 hp6_2_check657 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches657,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node658 T childKnown
  · exact hp6_2_node717 T childKnown
  · exact hp6_2_node718 T childKnown
  · exact hp6_2_node720 T childKnown
theorem hp6_2_node656 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected656 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected656 ((0 : Int),(1 : Int)) hp6_2_branches656 hp6_2_evidence656 hp6_2_check656 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches656,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node655 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected655 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected655 ((4 : Int),(0 : Int)) hp6_2_branches655 hp6_2_evidence655 hp6_2_check655 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches655,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node656 T childKnown
  · exact hp6_2_node657 T childKnown
  · exact hp6_2_node724 T childKnown
  · exact hp6_2_node725 T childKnown
  · exact hp6_2_node726 T childKnown
  · exact hp6_2_node730 T childKnown
  · exact hp6_2_node733 T childKnown
  · exact hp6_2_node739 T childKnown
theorem hp6_2_node654 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected654 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected654 ((3 : Int),(1 : Int)) hp6_2_branches654 hp6_2_evidence654 hp6_2_check654 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches654,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node653 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected653 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected653 ((3 : Int),(1 : Int)) hp6_2_branches653 hp6_2_evidence653 hp6_2_check653 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches653,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node652 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected652 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected652 ((3 : Int),(1 : Int)) hp6_2_branches652 hp6_2_evidence652 hp6_2_check652 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches652,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node651 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected651 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected651 ((4 : Int),(1 : Int)) hp6_2_branches651 hp6_2_evidence651 hp6_2_check651 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches651,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node650 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected650 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected650 ((4 : Int),(1 : Int)) hp6_2_branches650 hp6_2_evidence650 hp6_2_check650 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches650,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node649 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected649 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected649 ((3 : Int),(1 : Int)) hp6_2_branches649 hp6_2_evidence649 hp6_2_check649 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches649,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node650 T childKnown
  · exact hp6_2_node651 T childKnown
theorem hp6_2_node648 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected648 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected648 ((3 : Int),(1 : Int)) hp6_2_branches648 hp6_2_evidence648 hp6_2_check648 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches648,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node647 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected647 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected647 ((2 : Int),(1 : Int)) hp6_2_branches647 hp6_2_evidence647 hp6_2_check647 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches647,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node648 T childKnown
  · exact hp6_2_node649 T childKnown
  · exact hp6_2_node652 T childKnown
  · exact hp6_2_node653 T childKnown
  · exact hp6_2_node654 T childKnown
theorem hp6_2_node646 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected646 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected646 ((3 : Int),(1 : Int)) hp6_2_branches646 hp6_2_evidence646 hp6_2_check646 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches646,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node645 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected645 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected645 ((3 : Int),(1 : Int)) hp6_2_branches645 hp6_2_evidence645 hp6_2_check645 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches645,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node644 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected644 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected644 ((6 : Int),(2 : Int)) hp6_2_branches644 hp6_2_evidence644 hp6_2_check644 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches644,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node643 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected643 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected643 ((5 : Int),(2 : Int)) hp6_2_branches643 hp6_2_evidence643 hp6_2_check643 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches643,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node644 T childKnown
theorem hp6_2_node642 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected642 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected642 ((13 : Int),(1 : Int)) hp6_2_branches642 hp6_2_evidence642 hp6_2_check642 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches642,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node641 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected641 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected641 ((7 : Int),(2 : Int)) hp6_2_branches641 hp6_2_evidence641 hp6_2_check641 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches641,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node642 T childKnown
theorem hp6_2_node640 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected640 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected640 ((11 : Int),(0 : Int)) hp6_2_branches640 hp6_2_evidence640 hp6_2_check640 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches640,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node641 T childKnown
theorem hp6_2_node639 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected639 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected639 ((5 : Int),(2 : Int)) hp6_2_branches639 hp6_2_evidence639 hp6_2_check639 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches639,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node640 T childKnown
theorem hp6_2_node638 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected638 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected638 ((6 : Int),(2 : Int)) hp6_2_branches638 hp6_2_evidence638 hp6_2_check638 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches638,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node637 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected637 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected637 ((6 : Int),(1 : Int)) hp6_2_branches637 hp6_2_evidence637 hp6_2_check637 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches637,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node638 T childKnown
theorem hp6_2_node636 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected636 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected636 ((5 : Int),(1 : Int)) hp6_2_branches636 hp6_2_evidence636 hp6_2_check636 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches636,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node637 T childKnown
  · exact hp6_2_node639 T childKnown
  · exact hp6_2_node643 T childKnown
theorem hp6_2_node635 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected635 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected635 ((6 : Int),(2 : Int)) hp6_2_branches635 hp6_2_evidence635 hp6_2_check635 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches635,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node634 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected634 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected634 ((5 : Int),(2 : Int)) hp6_2_branches634 hp6_2_evidence634 hp6_2_check634 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches634,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node635 T childKnown
theorem hp6_2_node633 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected633 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected633 ((13 : Int),(1 : Int)) hp6_2_branches633 hp6_2_evidence633 hp6_2_check633 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches633,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node632 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected632 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected632 ((7 : Int),(2 : Int)) hp6_2_branches632 hp6_2_evidence632 hp6_2_check632 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches632,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node633 T childKnown
theorem hp6_2_node631 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected631 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected631 ((11 : Int),(0 : Int)) hp6_2_branches631 hp6_2_evidence631 hp6_2_check631 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches631,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node632 T childKnown
theorem hp6_2_node630 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected630 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected630 ((5 : Int),(2 : Int)) hp6_2_branches630 hp6_2_evidence630 hp6_2_check630 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches630,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node631 T childKnown
theorem hp6_2_node629 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected629 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected629 ((6 : Int),(2 : Int)) hp6_2_branches629 hp6_2_evidence629 hp6_2_check629 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches629,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node628 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected628 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected628 ((6 : Int),(1 : Int)) hp6_2_branches628 hp6_2_evidence628 hp6_2_check628 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches628,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node629 T childKnown
theorem hp6_2_node627 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected627 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected627 ((5 : Int),(1 : Int)) hp6_2_branches627 hp6_2_evidence627 hp6_2_check627 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches627,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node628 T childKnown
  · exact hp6_2_node630 T childKnown
  · exact hp6_2_node634 T childKnown
theorem hp6_2_node626 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected626 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected626 ((0 : Int),(2 : Int)) hp6_2_branches626 hp6_2_evidence626 hp6_2_check626 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches626,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node627 T childKnown
theorem hp6_2_node625 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected625 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected625 ((6 : Int),(2 : Int)) hp6_2_branches625 hp6_2_evidence625 hp6_2_check625 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches625,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node624 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected624 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected624 ((5 : Int),(2 : Int)) hp6_2_branches624 hp6_2_evidence624 hp6_2_check624 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches624,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node625 T childKnown
theorem hp6_2_node623 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected623 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected623 ((13 : Int),(1 : Int)) hp6_2_branches623 hp6_2_evidence623 hp6_2_check623 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches623,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node622 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected622 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected622 ((7 : Int),(2 : Int)) hp6_2_branches622 hp6_2_evidence622 hp6_2_check622 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches622,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node623 T childKnown
theorem hp6_2_node621 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected621 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected621 ((11 : Int),(0 : Int)) hp6_2_branches621 hp6_2_evidence621 hp6_2_check621 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches621,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node622 T childKnown
theorem hp6_2_node620 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected620 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected620 ((5 : Int),(2 : Int)) hp6_2_branches620 hp6_2_evidence620 hp6_2_check620 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches620,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node621 T childKnown
theorem hp6_2_node619 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected619 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected619 ((6 : Int),(2 : Int)) hp6_2_branches619 hp6_2_evidence619 hp6_2_check619 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches619,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node618 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected618 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected618 ((6 : Int),(1 : Int)) hp6_2_branches618 hp6_2_evidence618 hp6_2_check618 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches618,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node619 T childKnown
theorem hp6_2_node617 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected617 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected617 ((5 : Int),(1 : Int)) hp6_2_branches617 hp6_2_evidence617 hp6_2_check617 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches617,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node618 T childKnown
  · exact hp6_2_node620 T childKnown
  · exact hp6_2_node624 T childKnown
theorem hp6_2_node616 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected616 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected616 ((0 : Int),(2 : Int)) hp6_2_branches616 hp6_2_evidence616 hp6_2_check616 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches616,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node617 T childKnown
theorem hp6_2_node615 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected615 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected615 ((0 : Int),(1 : Int)) hp6_2_branches615 hp6_2_evidence615 hp6_2_check615 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches615,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node616 T childKnown
  · exact hp6_2_node626 T childKnown
  · exact hp6_2_node636 T childKnown
theorem hp6_2_node614 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected614 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected614 ((3 : Int),(1 : Int)) hp6_2_branches614 hp6_2_evidence614 hp6_2_check614 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches614,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node615 T childKnown
theorem hp6_2_node613 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected613 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected613 ((3 : Int),(1 : Int)) hp6_2_branches613 hp6_2_evidence613 hp6_2_check613 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches613,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node612 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected612 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected612 ((2 : Int),(1 : Int)) hp6_2_branches612 hp6_2_evidence612 hp6_2_check612 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches612,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node613 T childKnown
  · exact hp6_2_node614 T childKnown
  · exact hp6_2_node645 T childKnown
  · exact hp6_2_node646 T childKnown
theorem hp6_2_node611 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected611 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected611 ((4 : Int),(1 : Int)) hp6_2_branches611 hp6_2_evidence611 hp6_2_check611 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches611,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node610 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected610 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected610 ((4 : Int),(1 : Int)) hp6_2_branches610 hp6_2_evidence610 hp6_2_check610 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches610,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node609 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected609 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected609 ((4 : Int),(0 : Int)) hp6_2_branches609 hp6_2_evidence609 hp6_2_check609 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches609,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node610 T childKnown
  · exact hp6_2_node611 T childKnown
theorem hp6_2_node608 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected608 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected608 ((2 : Int),(1 : Int)) hp6_2_branches608 hp6_2_evidence608 hp6_2_check608 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches608,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node609 T childKnown
theorem hp6_2_node607 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected607 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected607 ((8 : Int),(1 : Int)) hp6_2_branches607 hp6_2_evidence607 hp6_2_check607 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches607,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node606 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected606 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected606 ((8 : Int),(1 : Int)) hp6_2_branches606 hp6_2_evidence606 hp6_2_check606 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches606,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node605 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected605 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected605 ((7 : Int),(1 : Int)) hp6_2_branches605 hp6_2_evidence605 hp6_2_check605 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches605,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node606 T childKnown
  · exact hp6_2_node607 T childKnown
theorem hp6_2_node604 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected604 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected604 ((6 : Int),(1 : Int)) hp6_2_branches604 hp6_2_evidence604 hp6_2_check604 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches604,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node603 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected603 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected603 ((5 : Int),(2 : Int)) hp6_2_branches603 hp6_2_evidence603 hp6_2_check603 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches603,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node604 T childKnown
theorem hp6_2_node602 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected602 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected602 ((6 : Int),(1 : Int)) hp6_2_branches602 hp6_2_evidence602 hp6_2_check602 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches602,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node601 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected601 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected601 ((4 : Int),(2 : Int)) hp6_2_branches601 hp6_2_evidence601 hp6_2_check601 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches601,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node602 T childKnown
  · exact hp6_2_node603 T childKnown
  · exact hp6_2_node605 T childKnown
theorem hp6_2_node600 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected600 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected600 ((8 : Int),(1 : Int)) hp6_2_branches600 hp6_2_evidence600 hp6_2_check600 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches600,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node599 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected599 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected599 ((8 : Int),(1 : Int)) hp6_2_branches599 hp6_2_evidence599 hp6_2_check599 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches599,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node598 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected598 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected598 ((7 : Int),(1 : Int)) hp6_2_branches598 hp6_2_evidence598 hp6_2_check598 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches598,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node599 T childKnown
  · exact hp6_2_node600 T childKnown
theorem hp6_2_node597 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected597 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected597 ((6 : Int),(1 : Int)) hp6_2_branches597 hp6_2_evidence597 hp6_2_check597 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches597,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node596 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected596 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected596 ((5 : Int),(2 : Int)) hp6_2_branches596 hp6_2_evidence596 hp6_2_check596 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches596,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node597 T childKnown
theorem hp6_2_node595 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected595 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected595 ((6 : Int),(1 : Int)) hp6_2_branches595 hp6_2_evidence595 hp6_2_check595 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches595,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node594 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected594 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected594 ((4 : Int),(2 : Int)) hp6_2_branches594 hp6_2_evidence594 hp6_2_check594 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches594,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node595 T childKnown
  · exact hp6_2_node596 T childKnown
  · exact hp6_2_node598 T childKnown
theorem hp6_2_node593 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected593 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected593 ((0 : Int),(2 : Int)) hp6_2_branches593 hp6_2_evidence593 hp6_2_check593 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches593,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node594 T childKnown
theorem hp6_2_node592 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected592 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected592 ((8 : Int),(1 : Int)) hp6_2_branches592 hp6_2_evidence592 hp6_2_check592 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches592,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node591 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected591 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected591 ((8 : Int),(1 : Int)) hp6_2_branches591 hp6_2_evidence591 hp6_2_check591 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches591,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node590 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected590 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected590 ((7 : Int),(1 : Int)) hp6_2_branches590 hp6_2_evidence590 hp6_2_check590 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches590,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node591 T childKnown
  · exact hp6_2_node592 T childKnown
theorem hp6_2_node589 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected589 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected589 ((6 : Int),(1 : Int)) hp6_2_branches589 hp6_2_evidence589 hp6_2_check589 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches589,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node588 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected588 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected588 ((5 : Int),(2 : Int)) hp6_2_branches588 hp6_2_evidence588 hp6_2_check588 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches588,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node589 T childKnown
theorem hp6_2_node587 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected587 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected587 ((6 : Int),(1 : Int)) hp6_2_branches587 hp6_2_evidence587 hp6_2_check587 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches587,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node586 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected586 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected586 ((4 : Int),(2 : Int)) hp6_2_branches586 hp6_2_evidence586 hp6_2_check586 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches586,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node587 T childKnown
  · exact hp6_2_node588 T childKnown
  · exact hp6_2_node590 T childKnown
theorem hp6_2_node585 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected585 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected585 ((0 : Int),(2 : Int)) hp6_2_branches585 hp6_2_evidence585 hp6_2_check585 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches585,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node586 T childKnown
theorem hp6_2_node584 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected584 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected584 ((0 : Int),(1 : Int)) hp6_2_branches584 hp6_2_evidence584 hp6_2_check584 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches584,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node585 T childKnown
  · exact hp6_2_node593 T childKnown
  · exact hp6_2_node601 T childKnown
theorem hp6_2_node583 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected583 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected583 ((4 : Int),(0 : Int)) hp6_2_branches583 hp6_2_evidence583 hp6_2_check583 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches583,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node584 T childKnown
theorem hp6_2_node582 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected582 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected582 ((2 : Int),(1 : Int)) hp6_2_branches582 hp6_2_evidence582 hp6_2_check582 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches582,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node583 T childKnown
theorem hp6_2_node581 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected581 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected581 ((2 : Int),(1 : Int)) hp6_2_branches581 hp6_2_evidence581 hp6_2_check581 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches581,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node580 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected580 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected580 ((2 : Int),(1 : Int)) hp6_2_branches580 hp6_2_evidence580 hp6_2_check580 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches580,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node579 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected579 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected579 ((3 : Int),(0 : Int)) hp6_2_branches579 hp6_2_evidence579 hp6_2_check579 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches579,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node580 T childKnown
  · exact hp6_2_node581 T childKnown
  · exact hp6_2_node582 T childKnown
  · exact hp6_2_node608 T childKnown
  · exact hp6_2_node612 T childKnown
  · exact hp6_2_node647 T childKnown
theorem hp6_2_node578 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected578 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected578 ((11 : Int),(1 : Int)) hp6_2_branches578 hp6_2_evidence578 hp6_2_check578 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches578,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node577 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected577 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected577 ((11 : Int),(1 : Int)) hp6_2_branches577 hp6_2_evidence577 hp6_2_check577 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches577,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node576 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected576 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected576 ((11 : Int),(1 : Int)) hp6_2_branches576 hp6_2_evidence576 hp6_2_check576 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches576,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node575 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected575 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected575 ((12 : Int),(1 : Int)) hp6_2_branches575 hp6_2_evidence575 hp6_2_check575 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches575,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node574 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected574 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected574 ((12 : Int),(1 : Int)) hp6_2_branches574 hp6_2_evidence574 hp6_2_check574 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches574,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node573 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected573 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected573 ((11 : Int),(1 : Int)) hp6_2_branches573 hp6_2_evidence573 hp6_2_check573 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches573,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node574 T childKnown
  · exact hp6_2_node575 T childKnown
theorem hp6_2_node572 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected572 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected572 ((11 : Int),(1 : Int)) hp6_2_branches572 hp6_2_evidence572 hp6_2_check572 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches572,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node571 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected571 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected571 ((10 : Int),(1 : Int)) hp6_2_branches571 hp6_2_evidence571 hp6_2_check571 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches571,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node572 T childKnown
  · exact hp6_2_node573 T childKnown
  · exact hp6_2_node576 T childKnown
  · exact hp6_2_node577 T childKnown
  · exact hp6_2_node578 T childKnown
theorem hp6_2_node570 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected570 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected570 ((11 : Int),(1 : Int)) hp6_2_branches570 hp6_2_evidence570 hp6_2_check570 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches570,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node569 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected569 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected569 ((11 : Int),(1 : Int)) hp6_2_branches569 hp6_2_evidence569 hp6_2_check569 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches569,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node568 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected568 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected568 ((2 : Int),(2 : Int)) hp6_2_branches568 hp6_2_evidence568 hp6_2_check568 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches568,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node567 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected567 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected567 ((7 : Int),(1 : Int)) hp6_2_branches567 hp6_2_evidence567 hp6_2_check567 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches567,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node568 T childKnown
theorem hp6_2_node566 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected566 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected566 ((0 : Int),(1 : Int)) hp6_2_branches566 hp6_2_evidence566 hp6_2_check566 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches566,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node565 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected565 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected565 ((6 : Int),(2 : Int)) hp6_2_branches565 hp6_2_evidence565 hp6_2_check565 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches565,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node566 T childKnown
theorem hp6_2_node564 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected564 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected564 ((8 : Int),(2 : Int)) hp6_2_branches564 hp6_2_evidence564 hp6_2_check564 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches564,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node565 T childKnown
theorem hp6_2_node563 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected563 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected563 ((3 : Int),(2 : Int)) hp6_2_branches563 hp6_2_evidence563 hp6_2_check563 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches563,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node562 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected562 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected562 ((8 : Int),(2 : Int)) hp6_2_branches562 hp6_2_evidence562 hp6_2_check562 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches562,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node563 T childKnown
theorem hp6_2_node561 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected561 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected561 ((8 : Int),(1 : Int)) hp6_2_branches561 hp6_2_evidence561 hp6_2_check561 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches561,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node562 T childKnown
  · exact hp6_2_node564 T childKnown
  · exact hp6_2_node567 T childKnown
theorem hp6_2_node560 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected560 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected560 ((11 : Int),(1 : Int)) hp6_2_branches560 hp6_2_evidence560 hp6_2_check560 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches560,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node561 T childKnown
theorem hp6_2_node559 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected559 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected559 ((11 : Int),(1 : Int)) hp6_2_branches559 hp6_2_evidence559 hp6_2_check559 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches559,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node558 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected558 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected558 ((10 : Int),(1 : Int)) hp6_2_branches558 hp6_2_evidence558 hp6_2_check558 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches558,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node559 T childKnown
  · exact hp6_2_node560 T childKnown
  · exact hp6_2_node569 T childKnown
  · exact hp6_2_node570 T childKnown
theorem hp6_2_node557 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected557 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected557 ((12 : Int),(1 : Int)) hp6_2_branches557 hp6_2_evidence557 hp6_2_check557 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches557,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node556 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected556 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected556 ((12 : Int),(1 : Int)) hp6_2_branches556 hp6_2_evidence556 hp6_2_check556 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches556,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node555 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected555 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected555 ((12 : Int),(0 : Int)) hp6_2_branches555 hp6_2_evidence555 hp6_2_check555 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches555,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node556 T childKnown
  · exact hp6_2_node557 T childKnown
theorem hp6_2_node554 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected554 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected554 ((10 : Int),(1 : Int)) hp6_2_branches554 hp6_2_evidence554 hp6_2_check554 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches554,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node555 T childKnown
theorem hp6_2_node553 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected553 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected553 ((2 : Int),(2 : Int)) hp6_2_branches553 hp6_2_evidence553 hp6_2_check553 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches553,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node552 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected552 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected552 ((7 : Int),(1 : Int)) hp6_2_branches552 hp6_2_evidence552 hp6_2_check552 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches552,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node553 T childKnown
theorem hp6_2_node551 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected551 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected551 ((0 : Int),(1 : Int)) hp6_2_branches551 hp6_2_evidence551 hp6_2_check551 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches551,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node550 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected550 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected550 ((6 : Int),(2 : Int)) hp6_2_branches550 hp6_2_evidence550 hp6_2_check550 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches550,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node551 T childKnown
theorem hp6_2_node549 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected549 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected549 ((8 : Int),(2 : Int)) hp6_2_branches549 hp6_2_evidence549 hp6_2_check549 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches549,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node550 T childKnown
theorem hp6_2_node548 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected548 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected548 ((3 : Int),(2 : Int)) hp6_2_branches548 hp6_2_evidence548 hp6_2_check548 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches548,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node547 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected547 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected547 ((8 : Int),(2 : Int)) hp6_2_branches547 hp6_2_evidence547 hp6_2_check547 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches547,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node548 T childKnown
theorem hp6_2_node546 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected546 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected546 ((8 : Int),(1 : Int)) hp6_2_branches546 hp6_2_evidence546 hp6_2_check546 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches546,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node547 T childKnown
  · exact hp6_2_node549 T childKnown
  · exact hp6_2_node552 T childKnown
theorem hp6_2_node545 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected545 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected545 ((12 : Int),(0 : Int)) hp6_2_branches545 hp6_2_evidence545 hp6_2_check545 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches545,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node546 T childKnown
theorem hp6_2_node544 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected544 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected544 ((10 : Int),(1 : Int)) hp6_2_branches544 hp6_2_evidence544 hp6_2_check544 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches544,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node545 T childKnown
theorem hp6_2_node543 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected543 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected543 ((10 : Int),(1 : Int)) hp6_2_branches543 hp6_2_evidence543 hp6_2_check543 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches543,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node542 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected542 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected542 ((10 : Int),(1 : Int)) hp6_2_branches542 hp6_2_evidence542 hp6_2_check542 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches542,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node541 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected541 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected541 ((11 : Int),(0 : Int)) hp6_2_branches541 hp6_2_evidence541 hp6_2_check541 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches541,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node542 T childKnown
  · exact hp6_2_node543 T childKnown
  · exact hp6_2_node544 T childKnown
  · exact hp6_2_node554 T childKnown
  · exact hp6_2_node558 T childKnown
  · exact hp6_2_node571 T childKnown
theorem hp6_2_node540 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected540 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected540 ((3 : Int),(1 : Int)) hp6_2_branches540 hp6_2_evidence540 hp6_2_check540 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches540,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node539 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected539 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected539 ((1 : Int),(1 : Int)) hp6_2_branches539 hp6_2_evidence539 hp6_2_check539 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches539,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node538 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected538 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected538 ((1 : Int),(1 : Int)) hp6_2_branches538 hp6_2_evidence538 hp6_2_check538 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches538,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node537 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected537 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected537 ((0 : Int),(1 : Int)) hp6_2_branches537 hp6_2_evidence537 hp6_2_check537 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches537,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node536 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected536 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected536 ((0 : Int),(1 : Int)) hp6_2_branches536 hp6_2_evidence536 hp6_2_check536 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches536,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node535 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected535 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected535 ((2 : Int),(1 : Int)) hp6_2_branches535 hp6_2_evidence535 hp6_2_check535 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches535,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node536 T childKnown
  · exact hp6_2_node537 T childKnown
  · exact hp6_2_node538 T childKnown
  · exact hp6_2_node539 T childKnown
  · exact hp6_2_node540 T childKnown
theorem hp6_2_node534 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected534 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected534 ((1 : Int),(1 : Int)) hp6_2_branches534 hp6_2_evidence534 hp6_2_check534 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches534,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node533 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected533 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected533 ((0 : Int),(1 : Int)) hp6_2_branches533 hp6_2_evidence533 hp6_2_check533 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches533,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node532 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected532 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected532 ((2 : Int),(1 : Int)) hp6_2_branches532 hp6_2_evidence532 hp6_2_check532 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches532,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node533 T childKnown
  · exact hp6_2_node534 T childKnown
theorem hp6_2_node531 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected531 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected531 ((1 : Int),(1 : Int)) hp6_2_branches531 hp6_2_evidence531 hp6_2_check531 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches531,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node530 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected530 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected530 ((0 : Int),(1 : Int)) hp6_2_branches530 hp6_2_evidence530 hp6_2_check530 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches530,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node529 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected529 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected529 ((2 : Int),(1 : Int)) hp6_2_branches529 hp6_2_evidence529 hp6_2_check529 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches529,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node530 T childKnown
  · exact hp6_2_node531 T childKnown
theorem hp6_2_node528 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected528 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected528 ((4 : Int),(0 : Int)) hp6_2_branches528 hp6_2_evidence528 hp6_2_check528 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches528,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node529 T childKnown
theorem hp6_2_node527 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected527 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected527 ((2 : Int),(1 : Int)) hp6_2_branches527 hp6_2_evidence527 hp6_2_check527 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches527,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node526 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected526 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected526 ((2 : Int),(1 : Int)) hp6_2_branches526 hp6_2_evidence526 hp6_2_check526 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches526,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node525 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected525 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected525 ((1 : Int),(2 : Int)) hp6_2_branches525 hp6_2_evidence525 hp6_2_check525 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches525,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node524 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected524 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected524 ((1 : Int),(2 : Int)) hp6_2_branches524 hp6_2_evidence524 hp6_2_check524 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches524,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node523 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected523 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected523 ((1 : Int),(2 : Int)) hp6_2_branches523 hp6_2_evidence523 hp6_2_check523 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches523,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node522 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected522 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected522 ((0 : Int),(1 : Int)) hp6_2_branches522 hp6_2_evidence522 hp6_2_check522 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches522,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node523 T childKnown
  · exact hp6_2_node524 T childKnown
  · exact hp6_2_node525 T childKnown
theorem hp6_2_node521 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected521 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected521 ((1 : Int),(2 : Int)) hp6_2_branches521 hp6_2_evidence521 hp6_2_check521 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches521,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node520 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected520 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected520 ((0 : Int),(1 : Int)) hp6_2_branches520 hp6_2_evidence520 hp6_2_check520 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches520,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node521 T childKnown
theorem hp6_2_node519 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected519 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected519 ((0 : Int),(1 : Int)) hp6_2_branches519 hp6_2_evidence519 hp6_2_check519 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches519,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node518 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected518 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected518 ((5 : Int),(1 : Int)) hp6_2_branches518 hp6_2_evidence518 hp6_2_check518 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches518,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node517 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected517 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected517 ((5 : Int),(1 : Int)) hp6_2_branches517 hp6_2_evidence517 hp6_2_check517 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches517,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node516 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected516 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected516 ((4 : Int),(1 : Int)) hp6_2_branches516 hp6_2_evidence516 hp6_2_check516 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches516,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node517 T childKnown
  · exact hp6_2_node518 T childKnown
theorem hp6_2_node515 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected515 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected515 ((7 : Int),(2 : Int)) hp6_2_branches515 hp6_2_evidence515 hp6_2_check515 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches515,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node514 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected514 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected514 ((6 : Int),(2 : Int)) hp6_2_branches514 hp6_2_evidence514 hp6_2_check514 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches514,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node515 T childKnown
theorem hp6_2_node513 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected513 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected513 ((14 : Int),(1 : Int)) hp6_2_branches513 hp6_2_evidence513 hp6_2_check513 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches513,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node512 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected512 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected512 ((8 : Int),(2 : Int)) hp6_2_branches512 hp6_2_evidence512 hp6_2_check512 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches512,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node513 T childKnown
theorem hp6_2_node511 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected511 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected511 ((12 : Int),(0 : Int)) hp6_2_branches511 hp6_2_evidence511 hp6_2_check511 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches511,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node512 T childKnown
theorem hp6_2_node510 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected510 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected510 ((6 : Int),(2 : Int)) hp6_2_branches510 hp6_2_evidence510 hp6_2_check510 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches510,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node511 T childKnown
theorem hp6_2_node509 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected509 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected509 ((7 : Int),(2 : Int)) hp6_2_branches509 hp6_2_evidence509 hp6_2_check509 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches509,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node508 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected508 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected508 ((7 : Int),(1 : Int)) hp6_2_branches508 hp6_2_evidence508 hp6_2_check508 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches508,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node509 T childKnown
theorem hp6_2_node507 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected507 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected507 ((6 : Int),(1 : Int)) hp6_2_branches507 hp6_2_evidence507 hp6_2_check507 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches507,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node508 T childKnown
  · exact hp6_2_node510 T childKnown
  · exact hp6_2_node514 T childKnown
theorem hp6_2_node506 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected506 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected506 ((4 : Int),(1 : Int)) hp6_2_branches506 hp6_2_evidence506 hp6_2_check506 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches506,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node507 T childKnown
theorem hp6_2_node505 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected505 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected505 ((5 : Int),(1 : Int)) hp6_2_branches505 hp6_2_evidence505 hp6_2_check505 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches505,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node504 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected504 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected504 ((5 : Int),(1 : Int)) hp6_2_branches504 hp6_2_evidence504 hp6_2_check504 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches504,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node503 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected503 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected503 ((5 : Int),(0 : Int)) hp6_2_branches503 hp6_2_evidence503 hp6_2_check503 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches503,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node504 T childKnown
  · exact hp6_2_node505 T childKnown
theorem hp6_2_node502 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected502 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected502 ((9 : Int),(1 : Int)) hp6_2_branches502 hp6_2_evidence502 hp6_2_check502 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches502,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node501 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected501 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected501 ((9 : Int),(1 : Int)) hp6_2_branches501 hp6_2_evidence501 hp6_2_check501 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches501,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node500 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected500 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected500 ((8 : Int),(1 : Int)) hp6_2_branches500 hp6_2_evidence500 hp6_2_check500 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches500,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node501 T childKnown
  · exact hp6_2_node502 T childKnown
theorem hp6_2_node499 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected499 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected499 ((7 : Int),(1 : Int)) hp6_2_branches499 hp6_2_evidence499 hp6_2_check499 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches499,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node498 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected498 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected498 ((6 : Int),(2 : Int)) hp6_2_branches498 hp6_2_evidence498 hp6_2_check498 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches498,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node499 T childKnown
theorem hp6_2_node497 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected497 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected497 ((7 : Int),(1 : Int)) hp6_2_branches497 hp6_2_evidence497 hp6_2_check497 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches497,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node496 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected496 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected496 ((7 : Int),(1 : Int)) hp6_2_branches496 hp6_2_evidence496 hp6_2_check496 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches496,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node495 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected495 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected495 ((7 : Int),(1 : Int)) hp6_2_branches495 hp6_2_evidence495 hp6_2_check495 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches495,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node494 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected494 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected494 ((7 : Int),(1 : Int)) hp6_2_branches494 hp6_2_evidence494 hp6_2_check494 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches494,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node493 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected493 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected493 ((6 : Int),(2 : Int)) hp6_2_branches493 hp6_2_evidence493 hp6_2_check493 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches493,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node494 T childKnown
  · exact hp6_2_node495 T childKnown
  · exact hp6_2_node496 T childKnown
theorem hp6_2_node492 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected492 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected492 ((5 : Int),(2 : Int)) hp6_2_branches492 hp6_2_evidence492 hp6_2_check492 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches492,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node493 T childKnown
  · exact hp6_2_node497 T childKnown
  · exact hp6_2_node498 T childKnown
  · exact hp6_2_node500 T childKnown
theorem hp6_2_node491 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected491 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected491 ((5 : Int),(0 : Int)) hp6_2_branches491 hp6_2_evidence491 hp6_2_check491 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches491,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node492 T childKnown
theorem hp6_2_node490 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected490 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected490 ((4 : Int),(0 : Int)) hp6_2_branches490 hp6_2_evidence490 hp6_2_check490 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches490,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node491 T childKnown
  · exact hp6_2_node503 T childKnown
  · exact hp6_2_node506 T childKnown
  · exact hp6_2_node516 T childKnown
theorem hp6_2_node489 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected489 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected489 ((2 : Int),(2 : Int)) hp6_2_branches489 hp6_2_evidence489 hp6_2_check489 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches489,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node490 T childKnown
  · exact hp6_2_node519 T childKnown
  · exact hp6_2_node520 T childKnown
  · exact hp6_2_node522 T childKnown
theorem hp6_2_node488 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected488 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected488 ((0 : Int),(1 : Int)) hp6_2_branches488 hp6_2_evidence488 hp6_2_check488 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches488,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node487 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected487 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected487 ((3 : Int),(0 : Int)) hp6_2_branches487 hp6_2_evidence487 hp6_2_check487 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches487,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node488 T childKnown
  · exact hp6_2_node489 T childKnown
  · exact hp6_2_node526 T childKnown
  · exact hp6_2_node527 T childKnown
  · exact hp6_2_node528 T childKnown
  · exact hp6_2_node532 T childKnown
  · exact hp6_2_node535 T childKnown
  · exact hp6_2_node541 T childKnown
theorem hp6_2_node486 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected486 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected486 ((1 : Int),(1 : Int)) hp6_2_branches486 hp6_2_evidence486 hp6_2_check486 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches486,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node485 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected485 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected485 ((1 : Int),(1 : Int)) hp6_2_branches485 hp6_2_evidence485 hp6_2_check485 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches485,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node484 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected484 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected484 ((1 : Int),(0 : Int)) hp6_2_branches484 hp6_2_evidence484 hp6_2_check484 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches484,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node485 T childKnown
  · exact hp6_2_node486 T childKnown
theorem hp6_2_node483 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected483 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected483 ((2 : Int),(1 : Int)) hp6_2_branches483 hp6_2_evidence483 hp6_2_check483 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches483,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node482 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected482 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected482 ((2 : Int),(1 : Int)) hp6_2_branches482 hp6_2_evidence482 hp6_2_check482 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches482,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node481 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected481 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected481 ((2 : Int),(1 : Int)) hp6_2_branches481 hp6_2_evidence481 hp6_2_check481 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches481,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node480 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected480 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected480 ((3 : Int),(1 : Int)) hp6_2_branches480 hp6_2_evidence480 hp6_2_check480 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches480,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node479 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected479 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected479 ((3 : Int),(1 : Int)) hp6_2_branches479 hp6_2_evidence479 hp6_2_check479 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches479,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node478 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected478 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected478 ((2 : Int),(1 : Int)) hp6_2_branches478 hp6_2_evidence478 hp6_2_check478 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches478,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node479 T childKnown
  · exact hp6_2_node480 T childKnown
theorem hp6_2_node477 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected477 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected477 ((2 : Int),(1 : Int)) hp6_2_branches477 hp6_2_evidence477 hp6_2_check477 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches477,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node476 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected476 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected476 ((1 : Int),(1 : Int)) hp6_2_branches476 hp6_2_evidence476 hp6_2_check476 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches476,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node477 T childKnown
  · exact hp6_2_node478 T childKnown
  · exact hp6_2_node481 T childKnown
  · exact hp6_2_node482 T childKnown
  · exact hp6_2_node483 T childKnown
theorem hp6_2_node475 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected475 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected475 ((2 : Int),(1 : Int)) hp6_2_branches475 hp6_2_evidence475 hp6_2_check475 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches475,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node474 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected474 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected474 ((2 : Int),(1 : Int)) hp6_2_branches474 hp6_2_evidence474 hp6_2_check474 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches474,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node473 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected473 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected473 ((5 : Int),(2 : Int)) hp6_2_branches473 hp6_2_evidence473 hp6_2_check473 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches473,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node472 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected472 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected472 ((4 : Int),(2 : Int)) hp6_2_branches472 hp6_2_evidence472 hp6_2_check472 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches472,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node473 T childKnown
theorem hp6_2_node471 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected471 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected471 ((12 : Int),(1 : Int)) hp6_2_branches471 hp6_2_evidence471 hp6_2_check471 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches471,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node470 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected470 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected470 ((6 : Int),(2 : Int)) hp6_2_branches470 hp6_2_evidence470 hp6_2_check470 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches470,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node471 T childKnown
theorem hp6_2_node469 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected469 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected469 ((10 : Int),(0 : Int)) hp6_2_branches469 hp6_2_evidence469 hp6_2_check469 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches469,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node470 T childKnown
theorem hp6_2_node468 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected468 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected468 ((4 : Int),(2 : Int)) hp6_2_branches468 hp6_2_evidence468 hp6_2_check468 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches468,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node469 T childKnown
theorem hp6_2_node467 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected467 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected467 ((5 : Int),(2 : Int)) hp6_2_branches467 hp6_2_evidence467 hp6_2_check467 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches467,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node466 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected466 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected466 ((5 : Int),(1 : Int)) hp6_2_branches466 hp6_2_evidence466 hp6_2_check466 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches466,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node467 T childKnown
theorem hp6_2_node465 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected465 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected465 ((4 : Int),(1 : Int)) hp6_2_branches465 hp6_2_evidence465 hp6_2_check465 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches465,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node466 T childKnown
  · exact hp6_2_node468 T childKnown
  · exact hp6_2_node472 T childKnown
theorem hp6_2_node464 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected464 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected464 ((2 : Int),(1 : Int)) hp6_2_branches464 hp6_2_evidence464 hp6_2_check464 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches464,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node465 T childKnown
theorem hp6_2_node463 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected463 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected463 ((2 : Int),(1 : Int)) hp6_2_branches463 hp6_2_evidence463 hp6_2_check463 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches463,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node462 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected462 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected462 ((1 : Int),(1 : Int)) hp6_2_branches462 hp6_2_evidence462 hp6_2_check462 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches462,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node463 T childKnown
  · exact hp6_2_node464 T childKnown
  · exact hp6_2_node474 T childKnown
  · exact hp6_2_node475 T childKnown
theorem hp6_2_node461 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected461 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected461 ((3 : Int),(1 : Int)) hp6_2_branches461 hp6_2_evidence461 hp6_2_check461 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches461,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node460 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected460 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected460 ((3 : Int),(1 : Int)) hp6_2_branches460 hp6_2_evidence460 hp6_2_check460 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches460,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node459 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected459 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected459 ((3 : Int),(0 : Int)) hp6_2_branches459 hp6_2_evidence459 hp6_2_check459 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches459,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node460 T childKnown
  · exact hp6_2_node461 T childKnown
theorem hp6_2_node458 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected458 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected458 ((1 : Int),(1 : Int)) hp6_2_branches458 hp6_2_evidence458 hp6_2_check458 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches458,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node459 T childKnown
theorem hp6_2_node457 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected457 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected457 ((7 : Int),(1 : Int)) hp6_2_branches457 hp6_2_evidence457 hp6_2_check457 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches457,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node456 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected456 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected456 ((7 : Int),(1 : Int)) hp6_2_branches456 hp6_2_evidence456 hp6_2_check456 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches456,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node455 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected455 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected455 ((6 : Int),(1 : Int)) hp6_2_branches455 hp6_2_evidence455 hp6_2_check455 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches455,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node456 T childKnown
  · exact hp6_2_node457 T childKnown
theorem hp6_2_node454 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected454 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected454 ((5 : Int),(1 : Int)) hp6_2_branches454 hp6_2_evidence454 hp6_2_check454 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches454,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node453 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected453 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected453 ((4 : Int),(2 : Int)) hp6_2_branches453 hp6_2_evidence453 hp6_2_check453 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches453,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node454 T childKnown
theorem hp6_2_node452 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected452 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected452 ((5 : Int),(1 : Int)) hp6_2_branches452 hp6_2_evidence452 hp6_2_check452 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches452,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node451 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected451 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected451 ((3 : Int),(2 : Int)) hp6_2_branches451 hp6_2_evidence451 hp6_2_check451 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches451,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node452 T childKnown
  · exact hp6_2_node453 T childKnown
  · exact hp6_2_node455 T childKnown
theorem hp6_2_node450 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected450 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected450 ((3 : Int),(0 : Int)) hp6_2_branches450 hp6_2_evidence450 hp6_2_check450 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches450,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node451 T childKnown
theorem hp6_2_node449 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected449 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected449 ((1 : Int),(1 : Int)) hp6_2_branches449 hp6_2_evidence449 hp6_2_check449 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches449,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node450 T childKnown
theorem hp6_2_node448 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected448 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected448 ((1 : Int),(1 : Int)) hp6_2_branches448 hp6_2_evidence448 hp6_2_check448 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches448,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node447 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected447 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected447 ((1 : Int),(1 : Int)) hp6_2_branches447 hp6_2_evidence447 hp6_2_check447 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches447,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node446 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected446 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected446 ((2 : Int),(0 : Int)) hp6_2_branches446 hp6_2_evidence446 hp6_2_check446 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches446,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node447 T childKnown
  · exact hp6_2_node448 T childKnown
  · exact hp6_2_node449 T childKnown
  · exact hp6_2_node458 T childKnown
  · exact hp6_2_node462 T childKnown
  · exact hp6_2_node476 T childKnown
theorem hp6_2_node445 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected445 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected445 ((10 : Int),(1 : Int)) hp6_2_branches445 hp6_2_evidence445 hp6_2_check445 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches445,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node444 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected444 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected444 ((10 : Int),(1 : Int)) hp6_2_branches444 hp6_2_evidence444 hp6_2_check444 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches444,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node443 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected443 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected443 ((10 : Int),(1 : Int)) hp6_2_branches443 hp6_2_evidence443 hp6_2_check443 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches443,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node442 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected442 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected442 ((11 : Int),(1 : Int)) hp6_2_branches442 hp6_2_evidence442 hp6_2_check442 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches442,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node441 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected441 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected441 ((11 : Int),(1 : Int)) hp6_2_branches441 hp6_2_evidence441 hp6_2_check441 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches441,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node440 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected440 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected440 ((10 : Int),(1 : Int)) hp6_2_branches440 hp6_2_evidence440 hp6_2_check440 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches440,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node441 T childKnown
  · exact hp6_2_node442 T childKnown
theorem hp6_2_node439 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected439 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected439 ((10 : Int),(1 : Int)) hp6_2_branches439 hp6_2_evidence439 hp6_2_check439 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches439,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node438 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected438 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected438 ((9 : Int),(1 : Int)) hp6_2_branches438 hp6_2_evidence438 hp6_2_check438 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches438,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node439 T childKnown
  · exact hp6_2_node440 T childKnown
  · exact hp6_2_node443 T childKnown
  · exact hp6_2_node444 T childKnown
  · exact hp6_2_node445 T childKnown
theorem hp6_2_node437 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected437 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected437 ((10 : Int),(1 : Int)) hp6_2_branches437 hp6_2_evidence437 hp6_2_check437 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches437,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node436 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected436 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected436 ((10 : Int),(1 : Int)) hp6_2_branches436 hp6_2_evidence436 hp6_2_check436 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches436,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node435 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected435 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected435 ((1 : Int),(2 : Int)) hp6_2_branches435 hp6_2_evidence435 hp6_2_check435 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches435,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node434 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected434 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected434 ((6 : Int),(1 : Int)) hp6_2_branches434 hp6_2_evidence434 hp6_2_check434 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches434,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node435 T childKnown
theorem hp6_2_node433 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected433 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected433 ((13 : Int),(2 : Int)) hp6_2_branches433 hp6_2_evidence433 hp6_2_check433 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches433,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node432 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected432 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected432 ((12 : Int),(2 : Int)) hp6_2_branches432 hp6_2_evidence432 hp6_2_check432 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches432,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node433 T childKnown
theorem hp6_2_node431 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected431 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected431 ((20 : Int),(1 : Int)) hp6_2_branches431 hp6_2_evidence431 hp6_2_check431 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches431,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node430 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected430 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected430 ((14 : Int),(2 : Int)) hp6_2_branches430 hp6_2_evidence430 hp6_2_check430 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches430,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node431 T childKnown
theorem hp6_2_node429 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected429 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected429 ((18 : Int),(0 : Int)) hp6_2_branches429 hp6_2_evidence429 hp6_2_check429 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches429,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node430 T childKnown
theorem hp6_2_node428 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected428 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected428 ((12 : Int),(2 : Int)) hp6_2_branches428 hp6_2_evidence428 hp6_2_check428 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches428,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node429 T childKnown
theorem hp6_2_node427 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected427 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected427 ((13 : Int),(2 : Int)) hp6_2_branches427 hp6_2_evidence427 hp6_2_check427 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches427,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node426 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected426 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected426 ((13 : Int),(1 : Int)) hp6_2_branches426 hp6_2_evidence426 hp6_2_check426 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches426,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node427 T childKnown
theorem hp6_2_node425 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected425 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected425 ((12 : Int),(1 : Int)) hp6_2_branches425 hp6_2_evidence425 hp6_2_check425 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches425,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node426 T childKnown
  · exact hp6_2_node428 T childKnown
  · exact hp6_2_node432 T childKnown
theorem hp6_2_node424 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected424 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected424 ((5 : Int),(2 : Int)) hp6_2_branches424 hp6_2_evidence424 hp6_2_check424 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches424,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node425 T childKnown
theorem hp6_2_node423 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected423 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected423 ((7 : Int),(2 : Int)) hp6_2_branches423 hp6_2_evidence423 hp6_2_check423 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches423,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node424 T childKnown
theorem hp6_2_node422 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected422 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected422 ((2 : Int),(2 : Int)) hp6_2_branches422 hp6_2_evidence422 hp6_2_check422 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches422,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node421 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected421 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected421 ((7 : Int),(2 : Int)) hp6_2_branches421 hp6_2_evidence421 hp6_2_check421 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches421,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node422 T childKnown
theorem hp6_2_node420 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected420 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected420 ((7 : Int),(1 : Int)) hp6_2_branches420 hp6_2_evidence420 hp6_2_check420 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches420,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node421 T childKnown
  · exact hp6_2_node423 T childKnown
  · exact hp6_2_node434 T childKnown
theorem hp6_2_node419 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected419 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected419 ((10 : Int),(1 : Int)) hp6_2_branches419 hp6_2_evidence419 hp6_2_check419 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches419,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node420 T childKnown
theorem hp6_2_node418 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected418 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected418 ((10 : Int),(1 : Int)) hp6_2_branches418 hp6_2_evidence418 hp6_2_check418 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches418,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node417 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected417 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected417 ((9 : Int),(1 : Int)) hp6_2_branches417 hp6_2_evidence417 hp6_2_check417 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches417,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node418 T childKnown
  · exact hp6_2_node419 T childKnown
  · exact hp6_2_node436 T childKnown
  · exact hp6_2_node437 T childKnown
theorem hp6_2_node416 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected416 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected416 ((11 : Int),(1 : Int)) hp6_2_branches416 hp6_2_evidence416 hp6_2_check416 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches416,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node415 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected415 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected415 ((11 : Int),(1 : Int)) hp6_2_branches415 hp6_2_evidence415 hp6_2_check415 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches415,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node414 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected414 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected414 ((11 : Int),(0 : Int)) hp6_2_branches414 hp6_2_evidence414 hp6_2_check414 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches414,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node415 T childKnown
  · exact hp6_2_node416 T childKnown
theorem hp6_2_node413 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected413 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected413 ((9 : Int),(1 : Int)) hp6_2_branches413 hp6_2_evidence413 hp6_2_check413 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches413,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node414 T childKnown
theorem hp6_2_node412 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected412 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected412 ((1 : Int),(2 : Int)) hp6_2_branches412 hp6_2_evidence412 hp6_2_check412 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches412,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node411 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected411 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected411 ((6 : Int),(1 : Int)) hp6_2_branches411 hp6_2_evidence411 hp6_2_check411 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches411,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node412 T childKnown
theorem hp6_2_node410 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected410 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected410 ((15 : Int),(1 : Int)) hp6_2_branches410 hp6_2_evidence410 hp6_2_check410 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches410,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node409 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected409 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected409 ((15 : Int),(1 : Int)) hp6_2_branches409 hp6_2_evidence409 hp6_2_check409 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches409,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node408 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected408 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected408 ((14 : Int),(1 : Int)) hp6_2_branches408 hp6_2_evidence408 hp6_2_check408 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches408,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node409 T childKnown
  · exact hp6_2_node410 T childKnown
theorem hp6_2_node407 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected407 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected407 ((13 : Int),(1 : Int)) hp6_2_branches407 hp6_2_evidence407 hp6_2_check407 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches407,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node406 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected406 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected406 ((12 : Int),(2 : Int)) hp6_2_branches406 hp6_2_evidence406 hp6_2_check406 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches406,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node407 T childKnown
theorem hp6_2_node405 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected405 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected405 ((13 : Int),(1 : Int)) hp6_2_branches405 hp6_2_evidence405 hp6_2_check405 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches405,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node404 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected404 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected404 ((11 : Int),(2 : Int)) hp6_2_branches404 hp6_2_evidence404 hp6_2_check404 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches404,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node405 T childKnown
  · exact hp6_2_node406 T childKnown
  · exact hp6_2_node408 T childKnown
theorem hp6_2_node403 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected403 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected403 ((5 : Int),(2 : Int)) hp6_2_branches403 hp6_2_evidence403 hp6_2_check403 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches403,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node404 T childKnown
theorem hp6_2_node402 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected402 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected402 ((7 : Int),(2 : Int)) hp6_2_branches402 hp6_2_evidence402 hp6_2_check402 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches402,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node403 T childKnown
theorem hp6_2_node401 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected401 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected401 ((2 : Int),(2 : Int)) hp6_2_branches401 hp6_2_evidence401 hp6_2_check401 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches401,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node400 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected400 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected400 ((7 : Int),(2 : Int)) hp6_2_branches400 hp6_2_evidence400 hp6_2_check400 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches400,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node401 T childKnown
theorem hp6_2_node399 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected399 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected399 ((7 : Int),(1 : Int)) hp6_2_branches399 hp6_2_evidence399 hp6_2_check399 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches399,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node400 T childKnown
  · exact hp6_2_node402 T childKnown
  · exact hp6_2_node411 T childKnown
theorem hp6_2_node398 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected398 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected398 ((11 : Int),(0 : Int)) hp6_2_branches398 hp6_2_evidence398 hp6_2_check398 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches398,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node399 T childKnown
theorem hp6_2_node397 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected397 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected397 ((9 : Int),(1 : Int)) hp6_2_branches397 hp6_2_evidence397 hp6_2_check397 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches397,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node398 T childKnown
theorem hp6_2_node396 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected396 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected396 ((9 : Int),(1 : Int)) hp6_2_branches396 hp6_2_evidence396 hp6_2_check396 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches396,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node395 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected395 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected395 ((9 : Int),(1 : Int)) hp6_2_branches395 hp6_2_evidence395 hp6_2_check395 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches395,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node394 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected394 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected394 ((10 : Int),(0 : Int)) hp6_2_branches394 hp6_2_evidence394 hp6_2_check394 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches394,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node395 T childKnown
  · exact hp6_2_node396 T childKnown
  · exact hp6_2_node397 T childKnown
  · exact hp6_2_node413 T childKnown
  · exact hp6_2_node417 T childKnown
  · exact hp6_2_node438 T childKnown
theorem hp6_2_node393 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected393 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected393 ((2 : Int),(1 : Int)) hp6_2_branches393 hp6_2_evidence393 hp6_2_check393 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches393,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node392 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected392 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected392 ((0 : Int),(1 : Int)) hp6_2_branches392 hp6_2_evidence392 hp6_2_check392 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches392,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node391 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected391 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected391 ((0 : Int),(1 : Int)) hp6_2_branches391 hp6_2_evidence391 hp6_2_check391 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches391,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node390 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected390 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected390 ((0 : Int),(1 : Int)) hp6_2_branches390 hp6_2_evidence390 hp6_2_check390 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches390,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node389 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected389 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected389 ((0 : Int),(1 : Int)) hp6_2_branches389 hp6_2_evidence389 hp6_2_check389 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches389,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node388 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected388 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected388 ((1 : Int),(1 : Int)) hp6_2_branches388 hp6_2_evidence388 hp6_2_check388 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches388,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node389 T childKnown
  · exact hp6_2_node390 T childKnown
  · exact hp6_2_node391 T childKnown
  · exact hp6_2_node392 T childKnown
  · exact hp6_2_node393 T childKnown
theorem hp6_2_node387 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected387 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected387 ((0 : Int),(1 : Int)) hp6_2_branches387 hp6_2_evidence387 hp6_2_check387 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches387,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node386 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected386 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected386 ((0 : Int),(1 : Int)) hp6_2_branches386 hp6_2_evidence386 hp6_2_check386 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches386,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node385 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected385 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected385 ((1 : Int),(1 : Int)) hp6_2_branches385 hp6_2_evidence385 hp6_2_check385 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches385,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node386 T childKnown
  · exact hp6_2_node387 T childKnown
theorem hp6_2_node384 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected384 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected384 ((0 : Int),(1 : Int)) hp6_2_branches384 hp6_2_evidence384 hp6_2_check384 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches384,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node383 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected383 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected383 ((0 : Int),(1 : Int)) hp6_2_branches383 hp6_2_evidence383 hp6_2_check383 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches383,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node382 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected382 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected382 ((1 : Int),(1 : Int)) hp6_2_branches382 hp6_2_evidence382 hp6_2_check382 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches382,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node383 T childKnown
  · exact hp6_2_node384 T childKnown
theorem hp6_2_node381 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected381 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected381 ((3 : Int),(0 : Int)) hp6_2_branches381 hp6_2_evidence381 hp6_2_check381 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches381,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node382 T childKnown
theorem hp6_2_node380 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected380 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected380 ((1 : Int),(1 : Int)) hp6_2_branches380 hp6_2_evidence380 hp6_2_check380 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches380,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node379 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected379 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected379 ((1 : Int),(1 : Int)) hp6_2_branches379 hp6_2_evidence379 hp6_2_check379 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches379,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node378 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected378 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected378 ((3 : Int),(1 : Int)) hp6_2_branches378 hp6_2_evidence378 hp6_2_check378 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches378,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node377 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected377 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected377 ((3 : Int),(1 : Int)) hp6_2_branches377 hp6_2_evidence377 hp6_2_check377 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches377,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node376 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected376 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected376 ((4 : Int),(1 : Int)) hp6_2_branches376 hp6_2_evidence376 hp6_2_check376 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches376,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node375 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected375 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected375 ((4 : Int),(1 : Int)) hp6_2_branches375 hp6_2_evidence375 hp6_2_check375 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches375,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node374 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected374 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected374 ((4 : Int),(0 : Int)) hp6_2_branches374 hp6_2_evidence374 hp6_2_check374 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches374,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node375 T childKnown
  · exact hp6_2_node376 T childKnown
theorem hp6_2_node373 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected373 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected373 ((8 : Int),(1 : Int)) hp6_2_branches373 hp6_2_evidence373 hp6_2_check373 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches373,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node372 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected372 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected372 ((8 : Int),(1 : Int)) hp6_2_branches372 hp6_2_evidence372 hp6_2_check372 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches372,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node371 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected371 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected371 ((7 : Int),(1 : Int)) hp6_2_branches371 hp6_2_evidence371 hp6_2_check371 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches371,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node372 T childKnown
  · exact hp6_2_node373 T childKnown
theorem hp6_2_node370 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected370 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected370 ((6 : Int),(1 : Int)) hp6_2_branches370 hp6_2_evidence370 hp6_2_check370 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches370,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node369 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected369 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected369 ((5 : Int),(2 : Int)) hp6_2_branches369 hp6_2_evidence369 hp6_2_check369 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches369,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node370 T childKnown
theorem hp6_2_node368 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected368 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected368 ((6 : Int),(1 : Int)) hp6_2_branches368 hp6_2_evidence368 hp6_2_check368 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches368,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node367 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected367 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected367 ((4 : Int),(2 : Int)) hp6_2_branches367 hp6_2_evidence367 hp6_2_check367 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches367,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node368 T childKnown
  · exact hp6_2_node369 T childKnown
  · exact hp6_2_node371 T childKnown
theorem hp6_2_node366 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected366 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected366 ((4 : Int),(0 : Int)) hp6_2_branches366 hp6_2_evidence366 hp6_2_check366 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches366,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node367 T childKnown
theorem hp6_2_node365 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected365 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected365 ((3 : Int),(0 : Int)) hp6_2_branches365 hp6_2_evidence365 hp6_2_check365 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches365,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node366 T childKnown
  · exact hp6_2_node374 T childKnown
  · exact hp6_2_node377 T childKnown
  · exact hp6_2_node378 T childKnown
theorem hp6_2_node364 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected364 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected364 ((3 : Int),(1 : Int)) hp6_2_branches364 hp6_2_evidence364 hp6_2_check364 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches364,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node363 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected363 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected363 ((3 : Int),(1 : Int)) hp6_2_branches363 hp6_2_evidence363 hp6_2_check363 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches363,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node362 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected362 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected362 ((4 : Int),(1 : Int)) hp6_2_branches362 hp6_2_evidence362 hp6_2_check362 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches362,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node361 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected361 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected361 ((4 : Int),(1 : Int)) hp6_2_branches361 hp6_2_evidence361 hp6_2_check361 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches361,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node360 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected360 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected360 ((4 : Int),(0 : Int)) hp6_2_branches360 hp6_2_evidence360 hp6_2_check360 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches360,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node361 T childKnown
  · exact hp6_2_node362 T childKnown
theorem hp6_2_node359 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected359 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected359 ((8 : Int),(1 : Int)) hp6_2_branches359 hp6_2_evidence359 hp6_2_check359 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches359,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node358 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected358 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected358 ((8 : Int),(1 : Int)) hp6_2_branches358 hp6_2_evidence358 hp6_2_check358 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches358,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node357 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected357 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected357 ((7 : Int),(1 : Int)) hp6_2_branches357 hp6_2_evidence357 hp6_2_check357 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches357,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node358 T childKnown
  · exact hp6_2_node359 T childKnown
theorem hp6_2_node356 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected356 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected356 ((6 : Int),(1 : Int)) hp6_2_branches356 hp6_2_evidence356 hp6_2_check356 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches356,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node355 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected355 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected355 ((5 : Int),(2 : Int)) hp6_2_branches355 hp6_2_evidence355 hp6_2_check355 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches355,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node356 T childKnown
theorem hp6_2_node354 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected354 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected354 ((6 : Int),(1 : Int)) hp6_2_branches354 hp6_2_evidence354 hp6_2_check354 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches354,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node353 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected353 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected353 ((4 : Int),(2 : Int)) hp6_2_branches353 hp6_2_evidence353 hp6_2_check353 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches353,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node354 T childKnown
  · exact hp6_2_node355 T childKnown
  · exact hp6_2_node357 T childKnown
theorem hp6_2_node352 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected352 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected352 ((4 : Int),(0 : Int)) hp6_2_branches352 hp6_2_evidence352 hp6_2_check352 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches352,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node353 T childKnown
theorem hp6_2_node351 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected351 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected351 ((3 : Int),(0 : Int)) hp6_2_branches351 hp6_2_evidence351 hp6_2_check351 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches351,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node352 T childKnown
  · exact hp6_2_node360 T childKnown
  · exact hp6_2_node363 T childKnown
  · exact hp6_2_node364 T childKnown
theorem hp6_2_node350 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected350 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected350 ((3 : Int),(1 : Int)) hp6_2_branches350 hp6_2_evidence350 hp6_2_check350 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches350,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node349 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected349 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected349 ((3 : Int),(1 : Int)) hp6_2_branches349 hp6_2_evidence349 hp6_2_check349 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches349,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node348 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected348 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected348 ((4 : Int),(1 : Int)) hp6_2_branches348 hp6_2_evidence348 hp6_2_check348 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches348,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node347 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected347 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected347 ((4 : Int),(1 : Int)) hp6_2_branches347 hp6_2_evidence347 hp6_2_check347 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches347,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node346 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected346 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected346 ((4 : Int),(0 : Int)) hp6_2_branches346 hp6_2_evidence346 hp6_2_check346 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches346,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node347 T childKnown
  · exact hp6_2_node348 T childKnown
theorem hp6_2_node345 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected345 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected345 ((8 : Int),(1 : Int)) hp6_2_branches345 hp6_2_evidence345 hp6_2_check345 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches345,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node344 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected344 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected344 ((8 : Int),(1 : Int)) hp6_2_branches344 hp6_2_evidence344 hp6_2_check344 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches344,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node343 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected343 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected343 ((7 : Int),(1 : Int)) hp6_2_branches343 hp6_2_evidence343 hp6_2_check343 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches343,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node344 T childKnown
  · exact hp6_2_node345 T childKnown
theorem hp6_2_node342 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected342 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected342 ((6 : Int),(1 : Int)) hp6_2_branches342 hp6_2_evidence342 hp6_2_check342 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches342,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node341 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected341 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected341 ((5 : Int),(2 : Int)) hp6_2_branches341 hp6_2_evidence341 hp6_2_check341 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches341,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node342 T childKnown
theorem hp6_2_node340 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected340 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected340 ((6 : Int),(1 : Int)) hp6_2_branches340 hp6_2_evidence340 hp6_2_check340 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches340,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node339 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected339 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected339 ((4 : Int),(2 : Int)) hp6_2_branches339 hp6_2_evidence339 hp6_2_check339 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches339,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node340 T childKnown
  · exact hp6_2_node341 T childKnown
  · exact hp6_2_node343 T childKnown
theorem hp6_2_node338 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected338 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected338 ((4 : Int),(0 : Int)) hp6_2_branches338 hp6_2_evidence338 hp6_2_check338 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches338,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node339 T childKnown
theorem hp6_2_node337 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected337 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected337 ((3 : Int),(0 : Int)) hp6_2_branches337 hp6_2_evidence337 hp6_2_check337 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches337,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node338 T childKnown
  · exact hp6_2_node346 T childKnown
  · exact hp6_2_node349 T childKnown
  · exact hp6_2_node350 T childKnown
theorem hp6_2_node336 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected336 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected336 ((0 : Int),(2 : Int)) hp6_2_branches336 hp6_2_evidence336 hp6_2_check336 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches336,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node337 T childKnown
  · exact hp6_2_node351 T childKnown
  · exact hp6_2_node365 T childKnown
theorem hp6_2_node335 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected335 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected335 ((4 : Int),(1 : Int)) hp6_2_branches335 hp6_2_evidence335 hp6_2_check335 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches335,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node334 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected334 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected334 ((4 : Int),(1 : Int)) hp6_2_branches334 hp6_2_evidence334 hp6_2_check334 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches334,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node333 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected333 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected333 ((3 : Int),(1 : Int)) hp6_2_branches333 hp6_2_evidence333 hp6_2_check333 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches333,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node334 T childKnown
  · exact hp6_2_node335 T childKnown
theorem hp6_2_node332 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected332 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected332 ((6 : Int),(2 : Int)) hp6_2_branches332 hp6_2_evidence332 hp6_2_check332 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches332,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node331 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected331 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected331 ((5 : Int),(2 : Int)) hp6_2_branches331 hp6_2_evidence331 hp6_2_check331 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches331,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node332 T childKnown
theorem hp6_2_node330 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected330 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected330 ((13 : Int),(1 : Int)) hp6_2_branches330 hp6_2_evidence330 hp6_2_check330 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches330,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node329 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected329 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected329 ((7 : Int),(2 : Int)) hp6_2_branches329 hp6_2_evidence329 hp6_2_check329 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches329,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node330 T childKnown
theorem hp6_2_node328 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected328 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected328 ((11 : Int),(0 : Int)) hp6_2_branches328 hp6_2_evidence328 hp6_2_check328 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches328,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node329 T childKnown
theorem hp6_2_node327 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected327 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected327 ((5 : Int),(2 : Int)) hp6_2_branches327 hp6_2_evidence327 hp6_2_check327 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches327,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node328 T childKnown
theorem hp6_2_node326 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected326 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected326 ((6 : Int),(2 : Int)) hp6_2_branches326 hp6_2_evidence326 hp6_2_check326 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches326,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node325 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected325 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected325 ((6 : Int),(1 : Int)) hp6_2_branches325 hp6_2_evidence325 hp6_2_check325 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches325,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node326 T childKnown
theorem hp6_2_node324 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected324 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected324 ((5 : Int),(1 : Int)) hp6_2_branches324 hp6_2_evidence324 hp6_2_check324 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches324,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node325 T childKnown
  · exact hp6_2_node327 T childKnown
  · exact hp6_2_node331 T childKnown
theorem hp6_2_node323 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected323 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected323 ((3 : Int),(1 : Int)) hp6_2_branches323 hp6_2_evidence323 hp6_2_check323 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches323,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node324 T childKnown
theorem hp6_2_node322 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected322 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected322 ((4 : Int),(1 : Int)) hp6_2_branches322 hp6_2_evidence322 hp6_2_check322 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches322,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node321 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected321 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected321 ((4 : Int),(1 : Int)) hp6_2_branches321 hp6_2_evidence321 hp6_2_check321 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches321,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node320 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected320 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected320 ((4 : Int),(0 : Int)) hp6_2_branches320 hp6_2_evidence320 hp6_2_check320 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches320,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node321 T childKnown
  · exact hp6_2_node322 T childKnown
theorem hp6_2_node319 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected319 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected319 ((8 : Int),(1 : Int)) hp6_2_branches319 hp6_2_evidence319 hp6_2_check319 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches319,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node318 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected318 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected318 ((8 : Int),(1 : Int)) hp6_2_branches318 hp6_2_evidence318 hp6_2_check318 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches318,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node317 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected317 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected317 ((7 : Int),(1 : Int)) hp6_2_branches317 hp6_2_evidence317 hp6_2_check317 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches317,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node318 T childKnown
  · exact hp6_2_node319 T childKnown
theorem hp6_2_node316 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected316 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected316 ((6 : Int),(1 : Int)) hp6_2_branches316 hp6_2_evidence316 hp6_2_check316 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches316,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node315 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected315 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected315 ((5 : Int),(2 : Int)) hp6_2_branches315 hp6_2_evidence315 hp6_2_check315 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches315,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node316 T childKnown
theorem hp6_2_node314 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected314 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected314 ((6 : Int),(1 : Int)) hp6_2_branches314 hp6_2_evidence314 hp6_2_check314 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches314,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node313 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected313 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected313 ((6 : Int),(1 : Int)) hp6_2_branches313 hp6_2_evidence313 hp6_2_check313 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches313,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node312 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected312 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected312 ((6 : Int),(1 : Int)) hp6_2_branches312 hp6_2_evidence312 hp6_2_check312 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches312,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node311 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected311 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected311 ((6 : Int),(1 : Int)) hp6_2_branches311 hp6_2_evidence311 hp6_2_check311 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches311,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node310 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected310 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected310 ((5 : Int),(2 : Int)) hp6_2_branches310 hp6_2_evidence310 hp6_2_check310 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches310,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node311 T childKnown
  · exact hp6_2_node312 T childKnown
  · exact hp6_2_node313 T childKnown
theorem hp6_2_node309 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected309 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected309 ((4 : Int),(2 : Int)) hp6_2_branches309 hp6_2_evidence309 hp6_2_check309 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches309,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node310 T childKnown
  · exact hp6_2_node314 T childKnown
  · exact hp6_2_node315 T childKnown
  · exact hp6_2_node317 T childKnown
theorem hp6_2_node308 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected308 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected308 ((4 : Int),(0 : Int)) hp6_2_branches308 hp6_2_evidence308 hp6_2_check308 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches308,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node309 T childKnown
theorem hp6_2_node307 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected307 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected307 ((3 : Int),(0 : Int)) hp6_2_branches307 hp6_2_evidence307 hp6_2_check307 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches307,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node308 T childKnown
  · exact hp6_2_node320 T childKnown
  · exact hp6_2_node323 T childKnown
  · exact hp6_2_node333 T childKnown
theorem hp6_2_node306 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected306 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected306 ((0 : Int),(2 : Int)) hp6_2_branches306 hp6_2_evidence306 hp6_2_check306 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches306,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node307 T childKnown
theorem hp6_2_node305 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected305 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected305 ((4 : Int),(1 : Int)) hp6_2_branches305 hp6_2_evidence305 hp6_2_check305 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches305,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node304 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected304 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected304 ((4 : Int),(1 : Int)) hp6_2_branches304 hp6_2_evidence304 hp6_2_check304 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches304,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node303 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected303 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected303 ((3 : Int),(1 : Int)) hp6_2_branches303 hp6_2_evidence303 hp6_2_check303 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches303,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node304 T childKnown
  · exact hp6_2_node305 T childKnown
theorem hp6_2_node302 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected302 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected302 ((6 : Int),(2 : Int)) hp6_2_branches302 hp6_2_evidence302 hp6_2_check302 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches302,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node301 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected301 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected301 ((5 : Int),(2 : Int)) hp6_2_branches301 hp6_2_evidence301 hp6_2_check301 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches301,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node302 T childKnown
theorem hp6_2_node300 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected300 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected300 ((13 : Int),(1 : Int)) hp6_2_branches300 hp6_2_evidence300 hp6_2_check300 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches300,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node299 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected299 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected299 ((7 : Int),(2 : Int)) hp6_2_branches299 hp6_2_evidence299 hp6_2_check299 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches299,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node300 T childKnown
theorem hp6_2_node298 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected298 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected298 ((11 : Int),(0 : Int)) hp6_2_branches298 hp6_2_evidence298 hp6_2_check298 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches298,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node299 T childKnown
theorem hp6_2_node297 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected297 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected297 ((5 : Int),(2 : Int)) hp6_2_branches297 hp6_2_evidence297 hp6_2_check297 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches297,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node298 T childKnown
theorem hp6_2_node296 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected296 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected296 ((6 : Int),(2 : Int)) hp6_2_branches296 hp6_2_evidence296 hp6_2_check296 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches296,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node295 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected295 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected295 ((6 : Int),(1 : Int)) hp6_2_branches295 hp6_2_evidence295 hp6_2_check295 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches295,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node296 T childKnown
theorem hp6_2_node294 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected294 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected294 ((5 : Int),(1 : Int)) hp6_2_branches294 hp6_2_evidence294 hp6_2_check294 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches294,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node295 T childKnown
  · exact hp6_2_node297 T childKnown
  · exact hp6_2_node301 T childKnown
theorem hp6_2_node293 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected293 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected293 ((3 : Int),(1 : Int)) hp6_2_branches293 hp6_2_evidence293 hp6_2_check293 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches293,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node294 T childKnown
theorem hp6_2_node292 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected292 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected292 ((4 : Int),(1 : Int)) hp6_2_branches292 hp6_2_evidence292 hp6_2_check292 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches292,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node291 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected291 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected291 ((4 : Int),(1 : Int)) hp6_2_branches291 hp6_2_evidence291 hp6_2_check291 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches291,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node290 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected290 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected290 ((4 : Int),(0 : Int)) hp6_2_branches290 hp6_2_evidence290 hp6_2_check290 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches290,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node291 T childKnown
  · exact hp6_2_node292 T childKnown
theorem hp6_2_node289 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected289 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected289 ((8 : Int),(1 : Int)) hp6_2_branches289 hp6_2_evidence289 hp6_2_check289 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches289,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node288 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected288 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected288 ((8 : Int),(1 : Int)) hp6_2_branches288 hp6_2_evidence288 hp6_2_check288 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches288,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node287 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected287 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected287 ((7 : Int),(1 : Int)) hp6_2_branches287 hp6_2_evidence287 hp6_2_check287 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches287,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node288 T childKnown
  · exact hp6_2_node289 T childKnown
theorem hp6_2_node286 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected286 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected286 ((6 : Int),(1 : Int)) hp6_2_branches286 hp6_2_evidence286 hp6_2_check286 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches286,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node285 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected285 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected285 ((5 : Int),(2 : Int)) hp6_2_branches285 hp6_2_evidence285 hp6_2_check285 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches285,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node286 T childKnown
theorem hp6_2_node284 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected284 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected284 ((6 : Int),(1 : Int)) hp6_2_branches284 hp6_2_evidence284 hp6_2_check284 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches284,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node283 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected283 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected283 ((6 : Int),(1 : Int)) hp6_2_branches283 hp6_2_evidence283 hp6_2_check283 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches283,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node282 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected282 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected282 ((6 : Int),(1 : Int)) hp6_2_branches282 hp6_2_evidence282 hp6_2_check282 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches282,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node281 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected281 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected281 ((6 : Int),(1 : Int)) hp6_2_branches281 hp6_2_evidence281 hp6_2_check281 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches281,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node280 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected280 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected280 ((5 : Int),(2 : Int)) hp6_2_branches280 hp6_2_evidence280 hp6_2_check280 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches280,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node281 T childKnown
  · exact hp6_2_node282 T childKnown
  · exact hp6_2_node283 T childKnown
theorem hp6_2_node279 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected279 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected279 ((4 : Int),(2 : Int)) hp6_2_branches279 hp6_2_evidence279 hp6_2_check279 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches279,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node280 T childKnown
  · exact hp6_2_node284 T childKnown
  · exact hp6_2_node285 T childKnown
  · exact hp6_2_node287 T childKnown
theorem hp6_2_node278 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected278 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected278 ((4 : Int),(0 : Int)) hp6_2_branches278 hp6_2_evidence278 hp6_2_check278 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches278,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node279 T childKnown
theorem hp6_2_node277 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected277 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected277 ((3 : Int),(0 : Int)) hp6_2_branches277 hp6_2_evidence277 hp6_2_check277 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches277,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node278 T childKnown
  · exact hp6_2_node290 T childKnown
  · exact hp6_2_node293 T childKnown
  · exact hp6_2_node303 T childKnown
theorem hp6_2_node276 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected276 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected276 ((0 : Int),(2 : Int)) hp6_2_branches276 hp6_2_evidence276 hp6_2_check276 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches276,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node277 T childKnown
theorem hp6_2_node275 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected275 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected275 ((4 : Int),(1 : Int)) hp6_2_branches275 hp6_2_evidence275 hp6_2_check275 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches275,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node274 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected274 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected274 ((4 : Int),(1 : Int)) hp6_2_branches274 hp6_2_evidence274 hp6_2_check274 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches274,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node273 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected273 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected273 ((3 : Int),(1 : Int)) hp6_2_branches273 hp6_2_evidence273 hp6_2_check273 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches273,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node274 T childKnown
  · exact hp6_2_node275 T childKnown
theorem hp6_2_node272 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected272 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected272 ((6 : Int),(2 : Int)) hp6_2_branches272 hp6_2_evidence272 hp6_2_check272 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches272,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node271 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected271 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected271 ((5 : Int),(2 : Int)) hp6_2_branches271 hp6_2_evidence271 hp6_2_check271 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches271,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node272 T childKnown
theorem hp6_2_node270 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected270 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected270 ((13 : Int),(1 : Int)) hp6_2_branches270 hp6_2_evidence270 hp6_2_check270 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches270,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node269 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected269 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected269 ((7 : Int),(2 : Int)) hp6_2_branches269 hp6_2_evidence269 hp6_2_check269 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches269,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node270 T childKnown
theorem hp6_2_node268 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected268 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected268 ((11 : Int),(0 : Int)) hp6_2_branches268 hp6_2_evidence268 hp6_2_check268 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches268,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node269 T childKnown
theorem hp6_2_node267 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected267 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected267 ((5 : Int),(2 : Int)) hp6_2_branches267 hp6_2_evidence267 hp6_2_check267 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches267,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node268 T childKnown
theorem hp6_2_node266 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected266 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected266 ((6 : Int),(2 : Int)) hp6_2_branches266 hp6_2_evidence266 hp6_2_check266 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches266,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node265 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected265 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected265 ((6 : Int),(1 : Int)) hp6_2_branches265 hp6_2_evidence265 hp6_2_check265 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches265,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node266 T childKnown
theorem hp6_2_node264 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected264 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected264 ((5 : Int),(1 : Int)) hp6_2_branches264 hp6_2_evidence264 hp6_2_check264 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches264,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node265 T childKnown
  · exact hp6_2_node267 T childKnown
  · exact hp6_2_node271 T childKnown
theorem hp6_2_node263 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected263 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected263 ((3 : Int),(1 : Int)) hp6_2_branches263 hp6_2_evidence263 hp6_2_check263 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches263,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node264 T childKnown
theorem hp6_2_node262 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected262 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected262 ((4 : Int),(1 : Int)) hp6_2_branches262 hp6_2_evidence262 hp6_2_check262 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches262,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node261 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected261 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected261 ((4 : Int),(1 : Int)) hp6_2_branches261 hp6_2_evidence261 hp6_2_check261 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches261,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node260 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected260 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected260 ((4 : Int),(0 : Int)) hp6_2_branches260 hp6_2_evidence260 hp6_2_check260 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches260,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node261 T childKnown
  · exact hp6_2_node262 T childKnown
theorem hp6_2_node259 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected259 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected259 ((8 : Int),(1 : Int)) hp6_2_branches259 hp6_2_evidence259 hp6_2_check259 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches259,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node258 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected258 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected258 ((8 : Int),(1 : Int)) hp6_2_branches258 hp6_2_evidence258 hp6_2_check258 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches258,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node257 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected257 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected257 ((7 : Int),(1 : Int)) hp6_2_branches257 hp6_2_evidence257 hp6_2_check257 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches257,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node258 T childKnown
  · exact hp6_2_node259 T childKnown
theorem hp6_2_node256 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected256 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected256 ((6 : Int),(1 : Int)) hp6_2_branches256 hp6_2_evidence256 hp6_2_check256 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches256,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node255 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected255 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected255 ((5 : Int),(2 : Int)) hp6_2_branches255 hp6_2_evidence255 hp6_2_check255 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches255,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node256 T childKnown
theorem hp6_2_node254 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected254 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected254 ((6 : Int),(1 : Int)) hp6_2_branches254 hp6_2_evidence254 hp6_2_check254 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches254,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node253 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected253 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected253 ((6 : Int),(1 : Int)) hp6_2_branches253 hp6_2_evidence253 hp6_2_check253 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches253,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node252 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected252 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected252 ((6 : Int),(1 : Int)) hp6_2_branches252 hp6_2_evidence252 hp6_2_check252 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches252,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node251 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected251 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected251 ((6 : Int),(1 : Int)) hp6_2_branches251 hp6_2_evidence251 hp6_2_check251 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches251,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node250 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected250 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected250 ((5 : Int),(2 : Int)) hp6_2_branches250 hp6_2_evidence250 hp6_2_check250 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches250,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node251 T childKnown
  · exact hp6_2_node252 T childKnown
  · exact hp6_2_node253 T childKnown
theorem hp6_2_node249 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected249 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected249 ((4 : Int),(2 : Int)) hp6_2_branches249 hp6_2_evidence249 hp6_2_check249 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches249,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node250 T childKnown
  · exact hp6_2_node254 T childKnown
  · exact hp6_2_node255 T childKnown
  · exact hp6_2_node257 T childKnown
theorem hp6_2_node248 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected248 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected248 ((4 : Int),(0 : Int)) hp6_2_branches248 hp6_2_evidence248 hp6_2_check248 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches248,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node249 T childKnown
theorem hp6_2_node247 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected247 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected247 ((3 : Int),(0 : Int)) hp6_2_branches247 hp6_2_evidence247 hp6_2_check247 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches247,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node248 T childKnown
  · exact hp6_2_node260 T childKnown
  · exact hp6_2_node263 T childKnown
  · exact hp6_2_node273 T childKnown
theorem hp6_2_node246 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected246 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected246 ((1 : Int),(2 : Int)) hp6_2_branches246 hp6_2_evidence246 hp6_2_check246 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches246,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node247 T childKnown
  · exact hp6_2_node276 T childKnown
  · exact hp6_2_node306 T childKnown
  · exact hp6_2_node336 T childKnown
theorem hp6_2_node245 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected245 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected245 ((0 : Int),(1 : Int)) hp6_2_branches245 hp6_2_evidence245 hp6_2_check245 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches245,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node244 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected244 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected244 ((2 : Int),(0 : Int)) hp6_2_branches244 hp6_2_evidence244 hp6_2_check244 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches244,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node245 T childKnown
  · exact hp6_2_node246 T childKnown
  · exact hp6_2_node379 T childKnown
  · exact hp6_2_node380 T childKnown
  · exact hp6_2_node381 T childKnown
  · exact hp6_2_node385 T childKnown
  · exact hp6_2_node388 T childKnown
  · exact hp6_2_node394 T childKnown
theorem hp6_2_node243 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected243 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected243 ((1 : Int),(1 : Int)) hp6_2_branches243 hp6_2_evidence243 hp6_2_check243 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches243,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node242 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected242 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected242 ((1 : Int),(1 : Int)) hp6_2_branches242 hp6_2_evidence242 hp6_2_check242 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches242,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node241 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected241 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected241 ((1 : Int),(1 : Int)) hp6_2_branches241 hp6_2_evidence241 hp6_2_check241 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches241,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node240 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected240 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected240 ((2 : Int),(1 : Int)) hp6_2_branches240 hp6_2_evidence240 hp6_2_check240 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches240,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node239 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected239 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected239 ((2 : Int),(1 : Int)) hp6_2_branches239 hp6_2_evidence239 hp6_2_check239 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches239,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node238 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected238 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected238 ((1 : Int),(1 : Int)) hp6_2_branches238 hp6_2_evidence238 hp6_2_check238 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches238,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node239 T childKnown
  · exact hp6_2_node240 T childKnown
theorem hp6_2_node237 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected237 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected237 ((1 : Int),(1 : Int)) hp6_2_branches237 hp6_2_evidence237 hp6_2_check237 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches237,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node236 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected236 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected236 ((0 : Int),(1 : Int)) hp6_2_branches236 hp6_2_evidence236 hp6_2_check236 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches236,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node237 T childKnown
  · exact hp6_2_node238 T childKnown
  · exact hp6_2_node241 T childKnown
  · exact hp6_2_node242 T childKnown
  · exact hp6_2_node243 T childKnown
theorem hp6_2_node235 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected235 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected235 ((1 : Int),(1 : Int)) hp6_2_branches235 hp6_2_evidence235 hp6_2_check235 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches235,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node234 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected234 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected234 ((1 : Int),(1 : Int)) hp6_2_branches234 hp6_2_evidence234 hp6_2_check234 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches234,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node233 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected233 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected233 ((4 : Int),(2 : Int)) hp6_2_branches233 hp6_2_evidence233 hp6_2_check233 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches233,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node232 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected232 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected232 ((3 : Int),(2 : Int)) hp6_2_branches232 hp6_2_evidence232 hp6_2_check232 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches232,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node233 T childKnown
theorem hp6_2_node231 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected231 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected231 ((11 : Int),(1 : Int)) hp6_2_branches231 hp6_2_evidence231 hp6_2_check231 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches231,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node230 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected230 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected230 ((5 : Int),(2 : Int)) hp6_2_branches230 hp6_2_evidence230 hp6_2_check230 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches230,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node231 T childKnown
theorem hp6_2_node229 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected229 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected229 ((9 : Int),(0 : Int)) hp6_2_branches229 hp6_2_evidence229 hp6_2_check229 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches229,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node230 T childKnown
theorem hp6_2_node228 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected228 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected228 ((3 : Int),(2 : Int)) hp6_2_branches228 hp6_2_evidence228 hp6_2_check228 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches228,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node229 T childKnown
theorem hp6_2_node227 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected227 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected227 ((4 : Int),(2 : Int)) hp6_2_branches227 hp6_2_evidence227 hp6_2_check227 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches227,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node226 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected226 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected226 ((4 : Int),(1 : Int)) hp6_2_branches226 hp6_2_evidence226 hp6_2_check226 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches226,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node227 T childKnown
theorem hp6_2_node225 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected225 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected225 ((3 : Int),(1 : Int)) hp6_2_branches225 hp6_2_evidence225 hp6_2_check225 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches225,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node226 T childKnown
  · exact hp6_2_node228 T childKnown
  · exact hp6_2_node232 T childKnown
theorem hp6_2_node224 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected224 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected224 ((1 : Int),(1 : Int)) hp6_2_branches224 hp6_2_evidence224 hp6_2_check224 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches224,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node225 T childKnown
theorem hp6_2_node223 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected223 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected223 ((1 : Int),(1 : Int)) hp6_2_branches223 hp6_2_evidence223 hp6_2_check223 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches223,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node222 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected222 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected222 ((0 : Int),(1 : Int)) hp6_2_branches222 hp6_2_evidence222 hp6_2_check222 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches222,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node223 T childKnown
  · exact hp6_2_node224 T childKnown
  · exact hp6_2_node234 T childKnown
  · exact hp6_2_node235 T childKnown
theorem hp6_2_node221 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected221 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected221 ((2 : Int),(1 : Int)) hp6_2_branches221 hp6_2_evidence221 hp6_2_check221 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches221,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node220 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected220 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected220 ((2 : Int),(1 : Int)) hp6_2_branches220 hp6_2_evidence220 hp6_2_check220 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches220,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node219 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected219 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected219 ((2 : Int),(0 : Int)) hp6_2_branches219 hp6_2_evidence219 hp6_2_check219 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches219,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node220 T childKnown
  · exact hp6_2_node221 T childKnown
theorem hp6_2_node218 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected218 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected218 ((0 : Int),(1 : Int)) hp6_2_branches218 hp6_2_evidence218 hp6_2_check218 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches218,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node219 T childKnown
theorem hp6_2_node217 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected217 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected217 ((6 : Int),(1 : Int)) hp6_2_branches217 hp6_2_evidence217 hp6_2_check217 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches217,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node216 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected216 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected216 ((6 : Int),(1 : Int)) hp6_2_branches216 hp6_2_evidence216 hp6_2_check216 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches216,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node215 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected215 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected215 ((5 : Int),(1 : Int)) hp6_2_branches215 hp6_2_evidence215 hp6_2_check215 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches215,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node216 T childKnown
  · exact hp6_2_node217 T childKnown
theorem hp6_2_node214 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected214 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected214 ((4 : Int),(1 : Int)) hp6_2_branches214 hp6_2_evidence214 hp6_2_check214 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches214,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node213 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected213 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected213 ((3 : Int),(2 : Int)) hp6_2_branches213 hp6_2_evidence213 hp6_2_check213 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches213,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node214 T childKnown
theorem hp6_2_node212 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected212 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected212 ((4 : Int),(1 : Int)) hp6_2_branches212 hp6_2_evidence212 hp6_2_check212 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches212,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node211 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected211 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected211 ((2 : Int),(2 : Int)) hp6_2_branches211 hp6_2_evidence211 hp6_2_check211 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches211,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node212 T childKnown
  · exact hp6_2_node213 T childKnown
  · exact hp6_2_node215 T childKnown
theorem hp6_2_node210 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected210 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected210 ((2 : Int),(0 : Int)) hp6_2_branches210 hp6_2_evidence210 hp6_2_check210 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches210,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node211 T childKnown
theorem hp6_2_node209 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected209 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected209 ((0 : Int),(1 : Int)) hp6_2_branches209 hp6_2_evidence209 hp6_2_check209 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches209,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node210 T childKnown
theorem hp6_2_node208 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected208 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected208 ((0 : Int),(1 : Int)) hp6_2_branches208 hp6_2_evidence208 hp6_2_check208 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches208,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node207 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected207 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected207 ((0 : Int),(1 : Int)) hp6_2_branches207 hp6_2_evidence207 hp6_2_check207 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches207,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node206 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected206 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected206 ((1 : Int),(0 : Int)) hp6_2_branches206 hp6_2_evidence206 hp6_2_check206 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches206,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node207 T childKnown
  · exact hp6_2_node208 T childKnown
  · exact hp6_2_node209 T childKnown
  · exact hp6_2_node218 T childKnown
  · exact hp6_2_node222 T childKnown
  · exact hp6_2_node236 T childKnown
theorem hp6_2_node205 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected205 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected205 ((9 : Int),(1 : Int)) hp6_2_branches205 hp6_2_evidence205 hp6_2_check205 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches205,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node204 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected204 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected204 ((9 : Int),(1 : Int)) hp6_2_branches204 hp6_2_evidence204 hp6_2_check204 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches204,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node203 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected203 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected203 ((9 : Int),(1 : Int)) hp6_2_branches203 hp6_2_evidence203 hp6_2_check203 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches203,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node202 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected202 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected202 ((10 : Int),(1 : Int)) hp6_2_branches202 hp6_2_evidence202 hp6_2_check202 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches202,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node201 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected201 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected201 ((10 : Int),(1 : Int)) hp6_2_branches201 hp6_2_evidence201 hp6_2_check201 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches201,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node200 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected200 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected200 ((9 : Int),(1 : Int)) hp6_2_branches200 hp6_2_evidence200 hp6_2_check200 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches200,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node201 T childKnown
  · exact hp6_2_node202 T childKnown
theorem hp6_2_node199 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected199 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected199 ((9 : Int),(1 : Int)) hp6_2_branches199 hp6_2_evidence199 hp6_2_check199 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches199,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node198 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected198 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected198 ((8 : Int),(1 : Int)) hp6_2_branches198 hp6_2_evidence198 hp6_2_check198 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches198,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node199 T childKnown
  · exact hp6_2_node200 T childKnown
  · exact hp6_2_node203 T childKnown
  · exact hp6_2_node204 T childKnown
  · exact hp6_2_node205 T childKnown
theorem hp6_2_node197 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected197 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected197 ((9 : Int),(1 : Int)) hp6_2_branches197 hp6_2_evidence197 hp6_2_check197 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches197,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node196 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected196 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected196 ((9 : Int),(1 : Int)) hp6_2_branches196 hp6_2_evidence196 hp6_2_check196 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches196,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node195 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected195 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected195 ((0 : Int),(2 : Int)) hp6_2_branches195 hp6_2_evidence195 hp6_2_check195 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches195,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node194 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected194 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected194 ((5 : Int),(1 : Int)) hp6_2_branches194 hp6_2_evidence194 hp6_2_check194 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches194,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node195 T childKnown
theorem hp6_2_node193 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected193 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected193 ((12 : Int),(2 : Int)) hp6_2_branches193 hp6_2_evidence193 hp6_2_check193 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches193,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node192 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected192 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected192 ((11 : Int),(2 : Int)) hp6_2_branches192 hp6_2_evidence192 hp6_2_check192 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches192,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node193 T childKnown
theorem hp6_2_node191 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected191 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected191 ((19 : Int),(1 : Int)) hp6_2_branches191 hp6_2_evidence191 hp6_2_check191 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches191,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node190 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected190 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected190 ((13 : Int),(2 : Int)) hp6_2_branches190 hp6_2_evidence190 hp6_2_check190 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches190,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node191 T childKnown
theorem hp6_2_node189 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected189 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected189 ((17 : Int),(0 : Int)) hp6_2_branches189 hp6_2_evidence189 hp6_2_check189 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches189,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node190 T childKnown
theorem hp6_2_node188 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected188 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected188 ((11 : Int),(2 : Int)) hp6_2_branches188 hp6_2_evidence188 hp6_2_check188 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches188,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node189 T childKnown
theorem hp6_2_node187 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected187 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected187 ((12 : Int),(2 : Int)) hp6_2_branches187 hp6_2_evidence187 hp6_2_check187 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches187,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node186 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected186 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected186 ((12 : Int),(1 : Int)) hp6_2_branches186 hp6_2_evidence186 hp6_2_check186 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches186,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node187 T childKnown
theorem hp6_2_node185 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected185 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected185 ((11 : Int),(1 : Int)) hp6_2_branches185 hp6_2_evidence185 hp6_2_check185 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches185,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node186 T childKnown
  · exact hp6_2_node188 T childKnown
  · exact hp6_2_node192 T childKnown
theorem hp6_2_node184 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected184 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected184 ((4 : Int),(2 : Int)) hp6_2_branches184 hp6_2_evidence184 hp6_2_check184 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches184,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node185 T childKnown
theorem hp6_2_node183 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected183 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected183 ((6 : Int),(2 : Int)) hp6_2_branches183 hp6_2_evidence183 hp6_2_check183 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches183,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node184 T childKnown
theorem hp6_2_node182 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected182 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected182 ((1 : Int),(2 : Int)) hp6_2_branches182 hp6_2_evidence182 hp6_2_check182 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches182,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node181 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected181 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected181 ((6 : Int),(2 : Int)) hp6_2_branches181 hp6_2_evidence181 hp6_2_check181 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches181,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node182 T childKnown
theorem hp6_2_node180 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected180 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected180 ((6 : Int),(1 : Int)) hp6_2_branches180 hp6_2_evidence180 hp6_2_check180 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches180,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node181 T childKnown
  · exact hp6_2_node183 T childKnown
  · exact hp6_2_node194 T childKnown
theorem hp6_2_node179 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected179 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected179 ((9 : Int),(1 : Int)) hp6_2_branches179 hp6_2_evidence179 hp6_2_check179 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches179,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node180 T childKnown
theorem hp6_2_node178 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected178 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected178 ((9 : Int),(1 : Int)) hp6_2_branches178 hp6_2_evidence178 hp6_2_check178 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches178,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node177 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected177 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected177 ((8 : Int),(1 : Int)) hp6_2_branches177 hp6_2_evidence177 hp6_2_check177 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches177,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node178 T childKnown
  · exact hp6_2_node179 T childKnown
  · exact hp6_2_node196 T childKnown
  · exact hp6_2_node197 T childKnown
theorem hp6_2_node176 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected176 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected176 ((10 : Int),(1 : Int)) hp6_2_branches176 hp6_2_evidence176 hp6_2_check176 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches176,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node175 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected175 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected175 ((10 : Int),(1 : Int)) hp6_2_branches175 hp6_2_evidence175 hp6_2_check175 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches175,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node174 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected174 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected174 ((10 : Int),(0 : Int)) hp6_2_branches174 hp6_2_evidence174 hp6_2_check174 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches174,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node175 T childKnown
  · exact hp6_2_node176 T childKnown
theorem hp6_2_node173 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected173 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected173 ((8 : Int),(1 : Int)) hp6_2_branches173 hp6_2_evidence173 hp6_2_check173 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches173,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node174 T childKnown
theorem hp6_2_node172 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected172 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected172 ((0 : Int),(2 : Int)) hp6_2_branches172 hp6_2_evidence172 hp6_2_check172 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches172,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node171 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected171 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected171 ((5 : Int),(1 : Int)) hp6_2_branches171 hp6_2_evidence171 hp6_2_check171 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches171,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node172 T childKnown
theorem hp6_2_node170 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected170 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected170 ((14 : Int),(1 : Int)) hp6_2_branches170 hp6_2_evidence170 hp6_2_check170 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches170,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node169 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected169 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected169 ((14 : Int),(1 : Int)) hp6_2_branches169 hp6_2_evidence169 hp6_2_check169 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches169,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node168 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected168 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected168 ((13 : Int),(1 : Int)) hp6_2_branches168 hp6_2_evidence168 hp6_2_check168 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches168,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node169 T childKnown
  · exact hp6_2_node170 T childKnown
theorem hp6_2_node167 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected167 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected167 ((12 : Int),(1 : Int)) hp6_2_branches167 hp6_2_evidence167 hp6_2_check167 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches167,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node166 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected166 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected166 ((11 : Int),(2 : Int)) hp6_2_branches166 hp6_2_evidence166 hp6_2_check166 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches166,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node167 T childKnown
theorem hp6_2_node165 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected165 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected165 ((12 : Int),(1 : Int)) hp6_2_branches165 hp6_2_evidence165 hp6_2_check165 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches165,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node164 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected164 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected164 ((10 : Int),(2 : Int)) hp6_2_branches164 hp6_2_evidence164 hp6_2_check164 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches164,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node165 T childKnown
  · exact hp6_2_node166 T childKnown
  · exact hp6_2_node168 T childKnown
theorem hp6_2_node163 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected163 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected163 ((4 : Int),(2 : Int)) hp6_2_branches163 hp6_2_evidence163 hp6_2_check163 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches163,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node164 T childKnown
theorem hp6_2_node162 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected162 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected162 ((6 : Int),(2 : Int)) hp6_2_branches162 hp6_2_evidence162 hp6_2_check162 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches162,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node163 T childKnown
theorem hp6_2_node161 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected161 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected161 ((1 : Int),(2 : Int)) hp6_2_branches161 hp6_2_evidence161 hp6_2_check161 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches161,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node160 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected160 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected160 ((6 : Int),(2 : Int)) hp6_2_branches160 hp6_2_evidence160 hp6_2_check160 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches160,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node161 T childKnown
theorem hp6_2_node159 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected159 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected159 ((6 : Int),(1 : Int)) hp6_2_branches159 hp6_2_evidence159 hp6_2_check159 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches159,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node160 T childKnown
  · exact hp6_2_node162 T childKnown
  · exact hp6_2_node171 T childKnown
theorem hp6_2_node158 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected158 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected158 ((10 : Int),(0 : Int)) hp6_2_branches158 hp6_2_evidence158 hp6_2_check158 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches158,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node159 T childKnown
theorem hp6_2_node157 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected157 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected157 ((8 : Int),(1 : Int)) hp6_2_branches157 hp6_2_evidence157 hp6_2_check157 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches157,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node158 T childKnown
theorem hp6_2_node156 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected156 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected156 ((8 : Int),(1 : Int)) hp6_2_branches156 hp6_2_evidence156 hp6_2_check156 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches156,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node155 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected155 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected155 ((8 : Int),(1 : Int)) hp6_2_branches155 hp6_2_evidence155 hp6_2_check155 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches155,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node154 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected154 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected154 ((9 : Int),(0 : Int)) hp6_2_branches154 hp6_2_evidence154 hp6_2_check154 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches154,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node155 T childKnown
  · exact hp6_2_node156 T childKnown
  · exact hp6_2_node157 T childKnown
  · exact hp6_2_node173 T childKnown
  · exact hp6_2_node177 T childKnown
  · exact hp6_2_node198 T childKnown
theorem hp6_2_node153 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected153 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected153 ((1 : Int),(1 : Int)) hp6_2_branches153 hp6_2_evidence153 hp6_2_check153 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches153,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node152 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected152 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected152 ((1 : Int),(1 : Int)) hp6_2_branches152 hp6_2_evidence152 hp6_2_check152 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches152,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node151 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected151 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected151 ((4 : Int),(2 : Int)) hp6_2_branches151 hp6_2_evidence151 hp6_2_check151 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches151,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node150 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected150 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected150 ((3 : Int),(2 : Int)) hp6_2_branches150 hp6_2_evidence150 hp6_2_check150 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches150,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node151 T childKnown
theorem hp6_2_node149 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected149 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected149 ((11 : Int),(1 : Int)) hp6_2_branches149 hp6_2_evidence149 hp6_2_check149 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches149,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node148 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected148 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected148 ((5 : Int),(2 : Int)) hp6_2_branches148 hp6_2_evidence148 hp6_2_check148 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches148,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node149 T childKnown
theorem hp6_2_node147 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected147 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected147 ((9 : Int),(0 : Int)) hp6_2_branches147 hp6_2_evidence147 hp6_2_check147 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches147,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node148 T childKnown
theorem hp6_2_node146 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected146 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected146 ((3 : Int),(2 : Int)) hp6_2_branches146 hp6_2_evidence146 hp6_2_check146 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches146,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node147 T childKnown
theorem hp6_2_node145 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected145 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected145 ((4 : Int),(2 : Int)) hp6_2_branches145 hp6_2_evidence145 hp6_2_check145 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches145,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node144 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected144 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected144 ((4 : Int),(1 : Int)) hp6_2_branches144 hp6_2_evidence144 hp6_2_check144 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches144,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node145 T childKnown
theorem hp6_2_node143 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected143 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected143 ((3 : Int),(1 : Int)) hp6_2_branches143 hp6_2_evidence143 hp6_2_check143 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches143,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node144 T childKnown
  · exact hp6_2_node146 T childKnown
  · exact hp6_2_node150 T childKnown
theorem hp6_2_node142 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected142 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected142 ((1 : Int),(1 : Int)) hp6_2_branches142 hp6_2_evidence142 hp6_2_check142 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches142,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node143 T childKnown
theorem hp6_2_node141 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected141 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected141 ((4 : Int),(2 : Int)) hp6_2_branches141 hp6_2_evidence141 hp6_2_check141 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches141,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node140 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected140 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected140 ((3 : Int),(2 : Int)) hp6_2_branches140 hp6_2_evidence140 hp6_2_check140 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches140,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node141 T childKnown
theorem hp6_2_node139 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected139 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected139 ((11 : Int),(1 : Int)) hp6_2_branches139 hp6_2_evidence139 hp6_2_check139 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches139,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node138 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected138 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected138 ((5 : Int),(2 : Int)) hp6_2_branches138 hp6_2_evidence138 hp6_2_check138 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches138,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node139 T childKnown
theorem hp6_2_node137 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected137 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected137 ((9 : Int),(0 : Int)) hp6_2_branches137 hp6_2_evidence137 hp6_2_check137 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches137,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node138 T childKnown
theorem hp6_2_node136 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected136 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected136 ((3 : Int),(2 : Int)) hp6_2_branches136 hp6_2_evidence136 hp6_2_check136 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches136,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node137 T childKnown
theorem hp6_2_node135 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected135 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected135 ((4 : Int),(2 : Int)) hp6_2_branches135 hp6_2_evidence135 hp6_2_check135 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches135,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node134 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected134 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected134 ((4 : Int),(1 : Int)) hp6_2_branches134 hp6_2_evidence134 hp6_2_check134 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches134,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node135 T childKnown
theorem hp6_2_node133 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected133 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected133 ((3 : Int),(1 : Int)) hp6_2_branches133 hp6_2_evidence133 hp6_2_check133 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches133,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node134 T childKnown
  · exact hp6_2_node136 T childKnown
  · exact hp6_2_node140 T childKnown
theorem hp6_2_node132 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected132 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected132 ((1 : Int),(1 : Int)) hp6_2_branches132 hp6_2_evidence132 hp6_2_check132 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches132,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node133 T childKnown
theorem hp6_2_node131 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected131 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected131 ((1 : Int),(1 : Int)) hp6_2_branches131 hp6_2_evidence131 hp6_2_check131 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches131,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node130 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected130 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected130 ((0 : Int),(1 : Int)) hp6_2_branches130 hp6_2_evidence130 hp6_2_check130 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches130,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node131 T childKnown
  · exact hp6_2_node132 T childKnown
  · exact hp6_2_node142 T childKnown
  · exact hp6_2_node152 T childKnown
  · exact hp6_2_node153 T childKnown
theorem hp6_2_node129 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected129 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected129 ((2 : Int),(1 : Int)) hp6_2_branches129 hp6_2_evidence129 hp6_2_check129 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches129,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node128 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected128 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected128 ((2 : Int),(1 : Int)) hp6_2_branches128 hp6_2_evidence128 hp6_2_check128 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches128,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node127 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected127 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected127 ((2 : Int),(0 : Int)) hp6_2_branches127 hp6_2_evidence127 hp6_2_check127 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches127,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node128 T childKnown
  · exact hp6_2_node129 T childKnown
theorem hp6_2_node126 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected126 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected126 ((2 : Int),(1 : Int)) hp6_2_branches126 hp6_2_evidence126 hp6_2_check126 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches126,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node125 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected125 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected125 ((2 : Int),(1 : Int)) hp6_2_branches125 hp6_2_evidence125 hp6_2_check125 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches125,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node124 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected124 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected124 ((2 : Int),(0 : Int)) hp6_2_branches124 hp6_2_evidence124 hp6_2_check124 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches124,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node125 T childKnown
  · exact hp6_2_node126 T childKnown
theorem hp6_2_node123 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected123 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected123 ((0 : Int),(1 : Int)) hp6_2_branches123 hp6_2_evidence123 hp6_2_check123 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches123,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node124 T childKnown
  · exact hp6_2_node127 T childKnown
theorem hp6_2_node122 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected122 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected122 ((6 : Int),(1 : Int)) hp6_2_branches122 hp6_2_evidence122 hp6_2_check122 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches122,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node121 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected121 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected121 ((6 : Int),(1 : Int)) hp6_2_branches121 hp6_2_evidence121 hp6_2_check121 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches121,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node120 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected120 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected120 ((5 : Int),(1 : Int)) hp6_2_branches120 hp6_2_evidence120 hp6_2_check120 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches120,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node121 T childKnown
  · exact hp6_2_node122 T childKnown
theorem hp6_2_node119 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected119 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected119 ((4 : Int),(1 : Int)) hp6_2_branches119 hp6_2_evidence119 hp6_2_check119 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches119,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node118 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected118 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected118 ((3 : Int),(2 : Int)) hp6_2_branches118 hp6_2_evidence118 hp6_2_check118 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches118,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node119 T childKnown
theorem hp6_2_node117 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected117 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected117 ((4 : Int),(1 : Int)) hp6_2_branches117 hp6_2_evidence117 hp6_2_check117 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches117,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node116 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected116 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected116 ((2 : Int),(2 : Int)) hp6_2_branches116 hp6_2_evidence116 hp6_2_check116 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches116,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node117 T childKnown
  · exact hp6_2_node118 T childKnown
  · exact hp6_2_node120 T childKnown
theorem hp6_2_node115 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected115 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected115 ((6 : Int),(1 : Int)) hp6_2_branches115 hp6_2_evidence115 hp6_2_check115 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches115,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node114 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected114 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected114 ((6 : Int),(1 : Int)) hp6_2_branches114 hp6_2_evidence114 hp6_2_check114 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches114,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node113 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected113 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected113 ((5 : Int),(1 : Int)) hp6_2_branches113 hp6_2_evidence113 hp6_2_check113 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches113,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node114 T childKnown
  · exact hp6_2_node115 T childKnown
theorem hp6_2_node112 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected112 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected112 ((4 : Int),(1 : Int)) hp6_2_branches112 hp6_2_evidence112 hp6_2_check112 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches112,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node111 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected111 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected111 ((3 : Int),(2 : Int)) hp6_2_branches111 hp6_2_evidence111 hp6_2_check111 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches111,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node112 T childKnown
theorem hp6_2_node110 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected110 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected110 ((4 : Int),(1 : Int)) hp6_2_branches110 hp6_2_evidence110 hp6_2_check110 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches110,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node109 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected109 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected109 ((2 : Int),(2 : Int)) hp6_2_branches109 hp6_2_evidence109 hp6_2_check109 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches109,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node110 T childKnown
  · exact hp6_2_node111 T childKnown
  · exact hp6_2_node113 T childKnown
theorem hp6_2_node108 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected108 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected108 ((0 : Int),(1 : Int)) hp6_2_branches108 hp6_2_evidence108 hp6_2_check108 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches108,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node109 T childKnown
  · exact hp6_2_node116 T childKnown
theorem hp6_2_node107 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected107 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected107 ((2 : Int),(0 : Int)) hp6_2_branches107 hp6_2_evidence107 hp6_2_check107 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches107,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node108 T childKnown
theorem hp6_2_node106 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected106 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected106 ((0 : Int),(1 : Int)) hp6_2_branches106 hp6_2_evidence106 hp6_2_check106 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches106,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node105 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected105 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected105 ((0 : Int),(1 : Int)) hp6_2_branches105 hp6_2_evidence105 hp6_2_check105 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches105,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node104 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected104 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected104 ((2 : Int),(1 : Int)) hp6_2_branches104 hp6_2_evidence104 hp6_2_check104 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches104,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node103 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected103 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected103 ((2 : Int),(1 : Int)) hp6_2_branches103 hp6_2_evidence103 hp6_2_check103 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches103,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node102 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected102 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected102 ((3 : Int),(1 : Int)) hp6_2_branches102 hp6_2_evidence102 hp6_2_check102 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches102,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node101 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected101 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected101 ((3 : Int),(1 : Int)) hp6_2_branches101 hp6_2_evidence101 hp6_2_check101 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches101,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node100 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected100 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected100 ((3 : Int),(0 : Int)) hp6_2_branches100 hp6_2_evidence100 hp6_2_check100 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches100,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node101 T childKnown
  · exact hp6_2_node102 T childKnown
theorem hp6_2_node99 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected99 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected99 ((7 : Int),(1 : Int)) hp6_2_branches99 hp6_2_evidence99 hp6_2_check99 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches99,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node98 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected98 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected98 ((7 : Int),(1 : Int)) hp6_2_branches98 hp6_2_evidence98 hp6_2_check98 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches98,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node97 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected97 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected97 ((6 : Int),(1 : Int)) hp6_2_branches97 hp6_2_evidence97 hp6_2_check97 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches97,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node98 T childKnown
  · exact hp6_2_node99 T childKnown
theorem hp6_2_node96 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected96 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected96 ((5 : Int),(1 : Int)) hp6_2_branches96 hp6_2_evidence96 hp6_2_check96 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches96,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node95 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected95 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected95 ((4 : Int),(2 : Int)) hp6_2_branches95 hp6_2_evidence95 hp6_2_check95 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches95,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node96 T childKnown
theorem hp6_2_node94 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected94 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected94 ((5 : Int),(1 : Int)) hp6_2_branches94 hp6_2_evidence94 hp6_2_check94 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches94,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node93 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected93 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected93 ((3 : Int),(2 : Int)) hp6_2_branches93 hp6_2_evidence93 hp6_2_check93 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches93,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node94 T childKnown
  · exact hp6_2_node95 T childKnown
  · exact hp6_2_node97 T childKnown
theorem hp6_2_node92 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected92 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected92 ((3 : Int),(0 : Int)) hp6_2_branches92 hp6_2_evidence92 hp6_2_check92 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches92,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node93 T childKnown
theorem hp6_2_node91 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected91 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected91 ((2 : Int),(0 : Int)) hp6_2_branches91 hp6_2_evidence91 hp6_2_check91 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches91,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node92 T childKnown
  · exact hp6_2_node100 T childKnown
  · exact hp6_2_node103 T childKnown
  · exact hp6_2_node104 T childKnown
theorem hp6_2_node90 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected90 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected90 ((3 : Int),(1 : Int)) hp6_2_branches90 hp6_2_evidence90 hp6_2_check90 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches90,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node89 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected89 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected89 ((3 : Int),(1 : Int)) hp6_2_branches89 hp6_2_evidence89 hp6_2_check89 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches89,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node88 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected88 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected88 ((2 : Int),(1 : Int)) hp6_2_branches88 hp6_2_evidence88 hp6_2_check88 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches88,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node89 T childKnown
  · exact hp6_2_node90 T childKnown
theorem hp6_2_node87 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected87 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected87 ((5 : Int),(2 : Int)) hp6_2_branches87 hp6_2_evidence87 hp6_2_check87 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches87,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node86 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected86 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected86 ((4 : Int),(2 : Int)) hp6_2_branches86 hp6_2_evidence86 hp6_2_check86 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches86,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node87 T childKnown
theorem hp6_2_node85 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected85 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected85 ((12 : Int),(1 : Int)) hp6_2_branches85 hp6_2_evidence85 hp6_2_check85 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches85,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node84 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected84 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected84 ((6 : Int),(2 : Int)) hp6_2_branches84 hp6_2_evidence84 hp6_2_check84 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches84,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node85 T childKnown
theorem hp6_2_node83 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected83 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected83 ((10 : Int),(0 : Int)) hp6_2_branches83 hp6_2_evidence83 hp6_2_check83 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches83,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node84 T childKnown
theorem hp6_2_node82 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected82 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected82 ((4 : Int),(2 : Int)) hp6_2_branches82 hp6_2_evidence82 hp6_2_check82 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches82,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node83 T childKnown
theorem hp6_2_node81 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected81 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected81 ((5 : Int),(2 : Int)) hp6_2_branches81 hp6_2_evidence81 hp6_2_check81 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches81,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node80 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected80 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected80 ((5 : Int),(1 : Int)) hp6_2_branches80 hp6_2_evidence80 hp6_2_check80 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches80,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node81 T childKnown
theorem hp6_2_node79 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected79 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected79 ((4 : Int),(1 : Int)) hp6_2_branches79 hp6_2_evidence79 hp6_2_check79 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches79,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node80 T childKnown
  · exact hp6_2_node82 T childKnown
  · exact hp6_2_node86 T childKnown
theorem hp6_2_node78 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected78 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected78 ((2 : Int),(1 : Int)) hp6_2_branches78 hp6_2_evidence78 hp6_2_check78 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches78,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node79 T childKnown
theorem hp6_2_node77 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected77 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected77 ((3 : Int),(1 : Int)) hp6_2_branches77 hp6_2_evidence77 hp6_2_check77 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches77,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node76 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected76 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected76 ((3 : Int),(1 : Int)) hp6_2_branches76 hp6_2_evidence76 hp6_2_check76 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches76,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node75 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected75 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected75 ((3 : Int),(0 : Int)) hp6_2_branches75 hp6_2_evidence75 hp6_2_check75 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches75,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node76 T childKnown
  · exact hp6_2_node77 T childKnown
theorem hp6_2_node74 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected74 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected74 ((7 : Int),(1 : Int)) hp6_2_branches74 hp6_2_evidence74 hp6_2_check74 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches74,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node73 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected73 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected73 ((7 : Int),(1 : Int)) hp6_2_branches73 hp6_2_evidence73 hp6_2_check73 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches73,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node72 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected72 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected72 ((6 : Int),(1 : Int)) hp6_2_branches72 hp6_2_evidence72 hp6_2_check72 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches72,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node73 T childKnown
  · exact hp6_2_node74 T childKnown
theorem hp6_2_node71 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected71 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected71 ((5 : Int),(1 : Int)) hp6_2_branches71 hp6_2_evidence71 hp6_2_check71 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches71,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node70 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected70 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected70 ((4 : Int),(2 : Int)) hp6_2_branches70 hp6_2_evidence70 hp6_2_check70 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches70,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node71 T childKnown
theorem hp6_2_node69 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected69 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected69 ((5 : Int),(1 : Int)) hp6_2_branches69 hp6_2_evidence69 hp6_2_check69 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches69,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node68 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected68 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected68 ((5 : Int),(1 : Int)) hp6_2_branches68 hp6_2_evidence68 hp6_2_check68 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches68,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node67 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected67 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected67 ((5 : Int),(1 : Int)) hp6_2_branches67 hp6_2_evidence67 hp6_2_check67 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches67,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node66 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected66 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected66 ((5 : Int),(1 : Int)) hp6_2_branches66 hp6_2_evidence66 hp6_2_check66 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches66,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node65 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected65 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected65 ((4 : Int),(2 : Int)) hp6_2_branches65 hp6_2_evidence65 hp6_2_check65 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches65,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node66 T childKnown
  · exact hp6_2_node67 T childKnown
  · exact hp6_2_node68 T childKnown
theorem hp6_2_node64 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected64 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected64 ((3 : Int),(2 : Int)) hp6_2_branches64 hp6_2_evidence64 hp6_2_check64 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches64,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node65 T childKnown
  · exact hp6_2_node69 T childKnown
  · exact hp6_2_node70 T childKnown
  · exact hp6_2_node72 T childKnown
theorem hp6_2_node63 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected63 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected63 ((3 : Int),(0 : Int)) hp6_2_branches63 hp6_2_evidence63 hp6_2_check63 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches63,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node64 T childKnown
theorem hp6_2_node62 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected62 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected62 ((2 : Int),(0 : Int)) hp6_2_branches62 hp6_2_evidence62 hp6_2_check62 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches62,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node63 T childKnown
  · exact hp6_2_node75 T childKnown
  · exact hp6_2_node78 T childKnown
  · exact hp6_2_node88 T childKnown
theorem hp6_2_node61 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected61 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected61 ((3 : Int),(1 : Int)) hp6_2_branches61 hp6_2_evidence61 hp6_2_check61 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches61,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node60 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected60 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected60 ((3 : Int),(1 : Int)) hp6_2_branches60 hp6_2_evidence60 hp6_2_check60 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches60,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node59 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected59 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected59 ((2 : Int),(1 : Int)) hp6_2_branches59 hp6_2_evidence59 hp6_2_check59 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches59,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node60 T childKnown
  · exact hp6_2_node61 T childKnown
theorem hp6_2_node58 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected58 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected58 ((5 : Int),(2 : Int)) hp6_2_branches58 hp6_2_evidence58 hp6_2_check58 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches58,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node57 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected57 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected57 ((4 : Int),(2 : Int)) hp6_2_branches57 hp6_2_evidence57 hp6_2_check57 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches57,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node58 T childKnown
theorem hp6_2_node56 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected56 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected56 ((12 : Int),(1 : Int)) hp6_2_branches56 hp6_2_evidence56 hp6_2_check56 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches56,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node55 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected55 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected55 ((6 : Int),(2 : Int)) hp6_2_branches55 hp6_2_evidence55 hp6_2_check55 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches55,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node56 T childKnown
theorem hp6_2_node54 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected54 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected54 ((10 : Int),(0 : Int)) hp6_2_branches54 hp6_2_evidence54 hp6_2_check54 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches54,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node55 T childKnown
theorem hp6_2_node53 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected53 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected53 ((4 : Int),(2 : Int)) hp6_2_branches53 hp6_2_evidence53 hp6_2_check53 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches53,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node54 T childKnown
theorem hp6_2_node52 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected52 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected52 ((5 : Int),(2 : Int)) hp6_2_branches52 hp6_2_evidence52 hp6_2_check52 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches52,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node51 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected51 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected51 ((5 : Int),(1 : Int)) hp6_2_branches51 hp6_2_evidence51 hp6_2_check51 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches51,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node52 T childKnown
theorem hp6_2_node50 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected50 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected50 ((4 : Int),(1 : Int)) hp6_2_branches50 hp6_2_evidence50 hp6_2_check50 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches50,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node51 T childKnown
  · exact hp6_2_node53 T childKnown
  · exact hp6_2_node57 T childKnown
theorem hp6_2_node49 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected49 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected49 ((2 : Int),(1 : Int)) hp6_2_branches49 hp6_2_evidence49 hp6_2_check49 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches49,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node50 T childKnown
theorem hp6_2_node48 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected48 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected48 ((3 : Int),(1 : Int)) hp6_2_branches48 hp6_2_evidence48 hp6_2_check48 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches48,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node47 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected47 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected47 ((3 : Int),(1 : Int)) hp6_2_branches47 hp6_2_evidence47 hp6_2_check47 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches47,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node46 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected46 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected46 ((3 : Int),(0 : Int)) hp6_2_branches46 hp6_2_evidence46 hp6_2_check46 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches46,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node47 T childKnown
  · exact hp6_2_node48 T childKnown
theorem hp6_2_node45 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected45 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected45 ((7 : Int),(1 : Int)) hp6_2_branches45 hp6_2_evidence45 hp6_2_check45 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches45,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node44 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected44 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected44 ((7 : Int),(1 : Int)) hp6_2_branches44 hp6_2_evidence44 hp6_2_check44 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches44,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node43 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected43 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected43 ((6 : Int),(1 : Int)) hp6_2_branches43 hp6_2_evidence43 hp6_2_check43 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches43,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node44 T childKnown
  · exact hp6_2_node45 T childKnown
theorem hp6_2_node42 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected42 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected42 ((5 : Int),(1 : Int)) hp6_2_branches42 hp6_2_evidence42 hp6_2_check42 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches42,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node41 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected41 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected41 ((4 : Int),(2 : Int)) hp6_2_branches41 hp6_2_evidence41 hp6_2_check41 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches41,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node42 T childKnown
theorem hp6_2_node40 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected40 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected40 ((5 : Int),(1 : Int)) hp6_2_branches40 hp6_2_evidence40 hp6_2_check40 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches40,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node39 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected39 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected39 ((5 : Int),(1 : Int)) hp6_2_branches39 hp6_2_evidence39 hp6_2_check39 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches39,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node38 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected38 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected38 ((5 : Int),(1 : Int)) hp6_2_branches38 hp6_2_evidence38 hp6_2_check38 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches38,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node37 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected37 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected37 ((5 : Int),(1 : Int)) hp6_2_branches37 hp6_2_evidence37 hp6_2_check37 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches37,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node36 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected36 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected36 ((4 : Int),(2 : Int)) hp6_2_branches36 hp6_2_evidence36 hp6_2_check36 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches36,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node37 T childKnown
  · exact hp6_2_node38 T childKnown
  · exact hp6_2_node39 T childKnown
theorem hp6_2_node35 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected35 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected35 ((3 : Int),(2 : Int)) hp6_2_branches35 hp6_2_evidence35 hp6_2_check35 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches35,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node36 T childKnown
  · exact hp6_2_node40 T childKnown
  · exact hp6_2_node41 T childKnown
  · exact hp6_2_node43 T childKnown
theorem hp6_2_node34 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected34 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected34 ((3 : Int),(0 : Int)) hp6_2_branches34 hp6_2_evidence34 hp6_2_check34 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches34,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node35 T childKnown
theorem hp6_2_node33 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected33 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected33 ((2 : Int),(0 : Int)) hp6_2_branches33 hp6_2_evidence33 hp6_2_check33 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches33,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node34 T childKnown
  · exact hp6_2_node46 T childKnown
  · exact hp6_2_node49 T childKnown
  · exact hp6_2_node59 T childKnown
theorem hp6_2_node32 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected32 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected32 ((3 : Int),(1 : Int)) hp6_2_branches32 hp6_2_evidence32 hp6_2_check32 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches32,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node31 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected31 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected31 ((3 : Int),(1 : Int)) hp6_2_branches31 hp6_2_evidence31 hp6_2_check31 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches31,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node30 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected30 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected30 ((2 : Int),(1 : Int)) hp6_2_branches30 hp6_2_evidence30 hp6_2_check30 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches30,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node31 T childKnown
  · exact hp6_2_node32 T childKnown
theorem hp6_2_node29 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected29 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected29 ((5 : Int),(2 : Int)) hp6_2_branches29 hp6_2_evidence29 hp6_2_check29 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches29,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node28 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected28 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected28 ((4 : Int),(2 : Int)) hp6_2_branches28 hp6_2_evidence28 hp6_2_check28 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches28,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node29 T childKnown
theorem hp6_2_node27 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected27 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected27 ((12 : Int),(1 : Int)) hp6_2_branches27 hp6_2_evidence27 hp6_2_check27 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches27,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node26 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected26 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected26 ((6 : Int),(2 : Int)) hp6_2_branches26 hp6_2_evidence26 hp6_2_check26 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches26,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node27 T childKnown
theorem hp6_2_node25 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected25 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected25 ((10 : Int),(0 : Int)) hp6_2_branches25 hp6_2_evidence25 hp6_2_check25 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches25,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node26 T childKnown
theorem hp6_2_node24 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected24 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected24 ((4 : Int),(2 : Int)) hp6_2_branches24 hp6_2_evidence24 hp6_2_check24 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches24,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node25 T childKnown
theorem hp6_2_node23 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected23 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected23 ((5 : Int),(2 : Int)) hp6_2_branches23 hp6_2_evidence23 hp6_2_check23 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches23,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node22 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected22 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected22 ((5 : Int),(1 : Int)) hp6_2_branches22 hp6_2_evidence22 hp6_2_check22 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches22,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node23 T childKnown
theorem hp6_2_node21 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected21 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected21 ((4 : Int),(1 : Int)) hp6_2_branches21 hp6_2_evidence21 hp6_2_check21 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches21,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node22 T childKnown
  · exact hp6_2_node24 T childKnown
  · exact hp6_2_node28 T childKnown
theorem hp6_2_node20 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected20 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected20 ((2 : Int),(1 : Int)) hp6_2_branches20 hp6_2_evidence20 hp6_2_check20 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches20,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node21 T childKnown
theorem hp6_2_node19 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected19 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected19 ((3 : Int),(1 : Int)) hp6_2_branches19 hp6_2_evidence19 hp6_2_check19 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches19,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node18 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected18 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected18 ((3 : Int),(1 : Int)) hp6_2_branches18 hp6_2_evidence18 hp6_2_check18 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches18,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node17 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected17 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected17 ((3 : Int),(0 : Int)) hp6_2_branches17 hp6_2_evidence17 hp6_2_check17 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches17,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node18 T childKnown
  · exact hp6_2_node19 T childKnown
theorem hp6_2_node16 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected16 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected16 ((7 : Int),(1 : Int)) hp6_2_branches16 hp6_2_evidence16 hp6_2_check16 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches16,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node15 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected15 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected15 ((7 : Int),(1 : Int)) hp6_2_branches15 hp6_2_evidence15 hp6_2_check15 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches15,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node14 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected14 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected14 ((6 : Int),(1 : Int)) hp6_2_branches14 hp6_2_evidence14 hp6_2_check14 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches14,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp6_2_node15 T childKnown
  · exact hp6_2_node16 T childKnown
theorem hp6_2_node13 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected13 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected13 ((5 : Int),(1 : Int)) hp6_2_branches13 hp6_2_evidence13 hp6_2_check13 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches13,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node12 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected12 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected12 ((4 : Int),(2 : Int)) hp6_2_branches12 hp6_2_evidence12 hp6_2_check12 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches12,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node13 T childKnown
theorem hp6_2_node11 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected11 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected11 ((5 : Int),(1 : Int)) hp6_2_branches11 hp6_2_evidence11 hp6_2_check11 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches11,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node10 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected10 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected10 ((5 : Int),(1 : Int)) hp6_2_branches10 hp6_2_evidence10 hp6_2_check10 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches10,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node9 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected9 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected9 ((5 : Int),(1 : Int)) hp6_2_branches9 hp6_2_evidence9 hp6_2_check9 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches9,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node8 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected8 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected8 ((5 : Int),(1 : Int)) hp6_2_branches8 hp6_2_evidence8 hp6_2_check8 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches8,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node7 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected7 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected7 ((4 : Int),(2 : Int)) hp6_2_branches7 hp6_2_evidence7 hp6_2_check7 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches7,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp6_2_node8 T childKnown
  · exact hp6_2_node9 T childKnown
  · exact hp6_2_node10 T childKnown
theorem hp6_2_node6 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected6 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected6 ((3 : Int),(2 : Int)) hp6_2_branches6 hp6_2_evidence6 hp6_2_check6 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches6,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node7 T childKnown
  · exact hp6_2_node11 T childKnown
  · exact hp6_2_node12 T childKnown
  · exact hp6_2_node14 T childKnown
theorem hp6_2_node5 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected5 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected5 ((3 : Int),(0 : Int)) hp6_2_branches5 hp6_2_evidence5 hp6_2_check5 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches5,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp6_2_node6 T childKnown
theorem hp6_2_node4 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected4 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected4 ((2 : Int),(0 : Int)) hp6_2_branches4 hp6_2_evidence4 hp6_2_check4 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches4,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node5 T childKnown
  · exact hp6_2_node17 T childKnown
  · exact hp6_2_node20 T childKnown
  · exact hp6_2_node30 T childKnown
theorem hp6_2_node3 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected3 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected3 ((0 : Int),(2 : Int)) hp6_2_branches3 hp6_2_evidence3 hp6_2_check3 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches3,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp6_2_node4 T childKnown
  · exact hp6_2_node33 T childKnown
  · exact hp6_2_node62 T childKnown
  · exact hp6_2_node91 T childKnown
theorem hp6_2_node2 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected2 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected2 ((0 : Int),(1 : Int)) hp6_2_branches2 hp6_2_evidence2 hp6_2_check2 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches2,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp6_2_node1 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected1 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected1 ((1 : Int),(0 : Int)) hp6_2_branches1 hp6_2_evidence1 hp6_2_check1 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches1,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node2 T childKnown
  · exact hp6_2_node3 T childKnown
  · exact hp6_2_node105 T childKnown
  · exact hp6_2_node106 T childKnown
  · exact hp6_2_node107 T childKnown
  · exact hp6_2_node123 T childKnown
  · exact hp6_2_node130 T childKnown
  · exact hp6_2_node154 T childKnown
theorem hp6_2_node0 (T : Tiling (6 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp6_2_selected0 → T.world s) : False := by
  apply replay_step (6 : Int) (2 : Int) (by decide) (by decide) T hp6_2_selected0 ((0 : Int),(0 : Int)) hp6_2_branches0 hp6_2_evidence0 hp6_2_check0 ?_ known
  intro t member childKnown
  simp only [hp6_2_branches0,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp6_2_node1 T childKnown
  · exact hp6_2_node206 T childKnown
  · exact hp6_2_node244 T childKnown
  · exact hp6_2_node446 T childKnown
  · exact hp6_2_node484 T childKnown
  · exact hp6_2_node487 T childKnown
  · exact hp6_2_node579 T childKnown
  · exact hp6_2_node655 T childKnown
  · exact hp6_2_node777 T childKnown
  · exact hp6_2_node827 T childKnown
  · exact hp6_2_node891 T childKnown
  · exact hp6_2_node959 T childKnown
  · exact hp6_2_node1047 T childKnown
  · exact hp6_2_node1115 T childKnown
  · exact hp6_2_node1144 T childKnown
  · exact hp6_2_node1173 T childKnown
  · exact hp6_2_node1261 T childKnown
  · exact hp6_2_node1329 T childKnown
  · exact hp6_2_node1331 T childKnown
  · exact hp6_2_node1343 T childKnown
  · exact hp6_2_node1346 T childKnown
  · exact hp6_2_node1500 T childKnown

theorem hp6_2_no_half_plane : ¬Tiles (6 : Int) (2 : Int) 1 0 HalfPlane := by
  rintro ⟨T⟩
  exact hp6_2_node0 T (by simp [hp6_2_selected0])
#print axioms hp6_2_no_half_plane

end THalfPlaneFinite

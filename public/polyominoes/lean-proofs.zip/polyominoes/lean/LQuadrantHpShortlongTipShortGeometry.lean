import LQuadrantHpShortlongTipShortArithmetic
import TilingCore
import TPlaneGeometry
import TilingSymmetry
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PolyominoFormal.LRegion
open CrossUnits
def HP_shortlong_tip_short_M (a b : Int) : Int := 2*(a+b+1)
def HP_shortlong_tip_short_Box (a b x y : Int) : Prop := -HP_shortlong_tip_short_M a b ≤ x ∧ 0≤y ∧ x≤HP_shortlong_tip_short_M a b ∧ y≤HP_shortlong_tip_short_M a b
def HP_shortlong_tip_short_Inside (t : Cross) : Prop := 0≤t.y-t.south

theorem HP_shortlong_tip_short_node001 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (2 : Int)))
    (hshort : (b = (2 : Int)))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_shortlong_tip_short_Inside t)
    (cover : ∀ x y, HP_shortlong_tip_short_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) b a (0 : Int) (0 : Int) b))
    (ht1 : world (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) b a (0 : Int) (0 : Int) b) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) b a (0 : Int) (0 : Int) b) ht0
  have in1 := inside (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht1
  have support : HP_shortlong_tip_short_Box a b (1 : Int) ((-2 : Int) + b) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_shortlong_tip_short_n001_point a b (hlong) ((by simpa only [HP_shortlong_tip_short_Box,HP_shortlong_tip_short_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) b a (0 : Int) (0 : Int) b) (1 : Int) ((-2 : Int) + b) ∨ Contains (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) (1 : Int) ((-2 : Int) + b)) := by
    intro occupied
    exact LRegionArithmetic.HP_shortlong_tip_short_n001_empty a b ((by simpa only [Contains] using occupied)) (hshort)
  obtain ⟨t,ht,hit⟩ := cover (1 : Int) ((-2 : Int) + b) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) b a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (0 : Int) b a (0 : Int) (0 : Int) b) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_shortlong_tip_short_n001_o0 a b jx jy (hshort) (hlong) (insideT) (sep0).2.1 (hit) (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_shortlong_tip_short_n001_o1 a b jx jy (sep0).2.2.1 (insideT) (hit) (hlong) (hshort)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_shortlong_tip_short_n001_o2 a b jx jy (insideT) (sep0).2.2.1 (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_shortlong_tip_short_n001_o3 a b jx jy (hlong) (hit) (hshort) (sep0).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_shortlong_tip_short_n001_o4 a b jx jy (hit) (hshort) (insideT) (hlong) (sep0).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_shortlong_tip_short_n001_o5 a b jx jy (hshort) (sep1).2.2.1 (hit) (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_shortlong_tip_short_n001_o6 a b jx jy (insideT) (hshort) (hlong) (sep0).2.1 (sep1).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_shortlong_tip_short_n001_o7 a b jx jy (sep0).2.2.1 (insideT) (hit) (hlong)

theorem HP_shortlong_tip_short_node000 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (2 : Int)))
    (hshort : (b = (2 : Int)))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_shortlong_tip_short_Inside t)
    (cover : ∀ x y, HP_shortlong_tip_short_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) b a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) b a (0 : Int) (0 : Int) b) ht0
  have support : HP_shortlong_tip_short_Box a b (1 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_shortlong_tip_short_n000_point a b (hlong) (hb) ((by simpa only [HP_shortlong_tip_short_Box,HP_shortlong_tip_short_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) b a (0 : Int) (0 : Int) b) (1 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_shortlong_tip_short_n000_empty a b (hb) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (1 : Int) (1 : Int) support
  have insideT := inside t ht
  have sep0 : Apart t (Cross.mk (0 : Int) b a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (0 : Int) b a (0 : Int) (0 : Int) b) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty hit)
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_shortlong_tip_short_n000_o0 a b jx jy (hb) (hlong) (insideT) (hit) (sep0).2.1 (sep0).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_shortlong_tip_short_n000_o1 a b jx jy (hshort) (hlong) (insideT) (hit) (sep0).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_shortlong_tip_short_n000_o2 a b jx jy (insideT) (hlong) (hb) (hit) (sep0).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_shortlong_tip_short_n000_o3 a b jx jy (insideT) (hshort) (hit) (hlong) (sep0).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_shortlong_tip_short_n000_o4 a b jx jy (sep0).2.2.1 (insideT) (hshort) (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + a) (1 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_shortlong_tip_short_n000_o5 a b jx jy (insideT) ((by simpa only [Same,eq_comm] using absent)) (sep0).2.1 (hb) (hlong) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0
    exact HP_shortlong_tip_short_node001 a b ha hb hshort hlong world copies inside cover separate ht0 ht (apart_sym sep0)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_shortlong_tip_short_n000_o6 a b jx jy (insideT) (sep0).2.1 (sep0).2.2.1 (hshort) (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_shortlong_tip_short_n000_o7 a b jx jy (hb) (insideT) (hlong) (sep0).2.2.1 (hit)

theorem HP_shortlong_tip_short_bounded_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (2 : Int)))
    (hshort : (b = (2 : Int)))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_shortlong_tip_short_Inside t)
    (cover : ∀ x y, HP_shortlong_tip_short_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (disjoint : ∀ t u x y, world t → world u → Contains t x y → Contains u x y → t=u)
    (anchor : world (Cross.mk (0 : Int) b a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have sep : ∀ t u, world t → world u → t=u ∨ Apart t u := by
    intro t u ht hu
    by_cases eq : t=u
    · exact Or.inl eq
    · right
      apply TPlane.apart_of_no_common_nonnegative t u
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies t ht)
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies u hu)
      · intro x y hx hy; exact eq (disjoint t u x y ht hu hx hy)
  exact HP_shortlong_tip_short_node000 a b ha hb hshort hlong world copies inside cover sep anchor

theorem HP_shortlong_tip_short_anchored_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (2 : Int)))
    (hshort : (b = (2 : Int)))
    (hlong : (a ≥ (5 : Int)))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor : T.world (Cross.mk (0 : Int) b a (0 : Int) (0 : Int) b)) : False := by
  apply HP_shortlong_tip_short_bounded_obstruction a b ha hb hshort hlong T.world T.copies ?_ ?_ T.disjoint anchor
  · intro t ht
    have nn := TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (T.copies t ht)
    exact T.inside t ht t.x (t.y-t.south) (by
      unfold Contains; unfold TPlane.Nonnegative at nn; right; omega)
  · intro x y h; exact T.cover x y h.2.1
theorem HP_shortlong_tip_short_no_shifted_anchor (a b p : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (2 : Int)))
    (hshort : (b = (2 : Int)))
    (hlong : (a ≥ (5 : Int)))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor : T.world (shift p 0 (Cross.mk (0 : Int) b a (0 : Int) (0 : Int) b))) : False := by
  let U : Tiling a b 0 0 HalfPlane :=
    (T.translate (-p) 0).congr (by intro x y; simp only [HalfPlane,Int.sub_zero])
  apply HP_shortlong_tip_short_anchored_obstruction a b ha hb hshort hlong U
  refine ⟨_,anchor,?_⟩
  apply same_eq
  unfold Same shift; dsimp
  exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
#print axioms HP_shortlong_tip_short_no_shifted_anchor
#print axioms HP_shortlong_tip_short_bounded_obstruction
end PolyominoFormal.LRegion

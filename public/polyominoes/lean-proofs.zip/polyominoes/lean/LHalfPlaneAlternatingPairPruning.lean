import LHalfPlaneSameBars

namespace PolyominoFormal.LRegion
open CrossUnits

def ForbiddenSameBoundaryBars (a b : Int) (t u : Cross) : Prop :=
  t.y=0 ∧ u.y=0 ∧ t.north=b ∧ u.north=b ∧ t.south=0 ∧ u.south=0 ∧
  (u.x=t.x+a+1 ∨ t.x=u.x+a+1) ∧
  ((t.east=a ∧ t.west=0 ∧ u.east=a ∧ u.west=0) ∨
   (t.east=0 ∧ t.west=a ∧ u.east=0 ∧ u.west=a))

theorem avoid_same_boundary_bars (a b : Int) (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (T : Tiling a b 0 0 HalfPlane) :
    ∀t u,T.world t → T.world u → ¬ForbiddenSameBoundaryBars a b t u := by
  rintro ⟨p,y,e,n,w,s⟩ ⟨q,z,f,m,v,r⟩ ht hu
    ⟨hy,hz,hn,hm,hs,hr,distance,arms⟩
  dsimp only at hy hz hn hm hs hr distance arms
  subst y; subst z; subst n; subst m; subst s; subst r
  rcases arms with ⟨he,hw,hf,hv⟩ | ⟨he,hw,hf,hv⟩
  · subst e; subst w; subst f; subst v
    rcases distance with eq | eq
    · subst q; exact same_long_bars_impossible a b p ha hb hab T ht hu
    · subst p; exact same_long_bars_impossible a b q ha hb hab T hu ht
  · subst e; subst w; subst f; subst v
    rcases distance with eq | eq
    · subst q; exact same_long_bars_left_impossible a b p ha hb hab T ht hu
    · subst p; exact same_long_bars_left_impossible a b q ha hb hab T hu ht

#print axioms avoid_same_boundary_bars
end PolyominoFormal.LRegion

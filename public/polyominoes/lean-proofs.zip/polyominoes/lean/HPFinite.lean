import HPFiniteA2B2
import HPFiniteA3B2
import HPFiniteA3B3
import HPFiniteA4B2
import HPFiniteA4B3
import HPFiniteA4B4
import HPFiniteA5B2
import HPFiniteA5B3
import HPFiniteA5B4
import HPFiniteA5B5
import HPFiniteA6B2
import HPFiniteA6B3
import HPFiniteA6B4
import HPFiniteA6B5
import HPFiniteA6B6

set_option maxHeartbeats 2000000
namespace THalfPlaneFinite
open PolyominoFormal

theorem finite_no_half_plane (a b : Int) (bounds : 2≤b ∧ b≤a ∧ a≤6) :
    ¬Tiles a b 1 0 HalfPlane := by
  have aa : a=2 ∨ a=3 ∨ a=4 ∨ a=5 ∨ a=6 := by omega
  rcases aa with rfl | rfl | rfl | rfl | rfl
  · have bb : b=2 := by omega
    subst b
    exact hp2_2_no_half_plane
  · have bb : b=2 ∨ b=3 := by omega
    rcases bb with rfl | rfl
    · exact hp3_2_no_half_plane
    · exact hp3_3_no_half_plane
  · have bb : b=2 ∨ b=3 ∨ b=4 := by omega
    rcases bb with rfl | rfl | rfl
    · exact hp4_2_no_half_plane
    · exact hp4_3_no_half_plane
    · exact hp4_4_no_half_plane
  · have bb : b=2 ∨ b=3 ∨ b=4 ∨ b=5 := by omega
    rcases bb with rfl | rfl | rfl | rfl
    · exact hp5_2_no_half_plane
    · exact hp5_3_no_half_plane
    · exact hp5_4_no_half_plane
    · exact hp5_5_no_half_plane
  · have bb : b=2 ∨ b=3 ∨ b=4 ∨ b=5 ∨ b=6 := by omega
    rcases bb with rfl | rfl | rfl | rfl | rfl
    · exact hp6_2_no_half_plane
    · exact hp6_3_no_half_plane
    · exact hp6_4_no_half_plane
    · exact hp6_5_no_half_plane
    · exact hp6_6_no_half_plane

#print axioms finite_no_half_plane

end THalfPlaneFinite

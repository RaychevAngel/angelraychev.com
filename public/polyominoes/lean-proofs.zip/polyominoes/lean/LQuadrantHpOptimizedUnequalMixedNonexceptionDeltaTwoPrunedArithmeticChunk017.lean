import LQuadrantHpOptimizedUnequalMixedNonexceptionDeltaTwoPrunedArithmeticDefs
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace LRegionArithmetic

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n477_run_four (a b : Int)
    (h0 : (¬ ((5 : Int) ≤ ((4 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n477_run_short (a b : Int)
    (h0 : (¬ ((((4 : Int) + b) - (5 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n477_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n477_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3503 a b) ∨ (fact_366edf150095_3452 a b) ∨ (fact_366edf150095_5779 a b) ∨ (fact_366edf150095_5787 a b) ∨ (fact_366edf150095_3460 a b) ∨ (fact_366edf150095_3698 a b) ∨ (fact_366edf150095_3917 a b) ∨ (fact_366edf150095_3970 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_366edf150095_3707 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n477_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4125 a b) ∨ (fact_366edf150095_3720 a b) ∨ (fact_366edf150095_5871 a b) ∨ (fact_366edf150095_5954 a b) ∨ (fact_366edf150095_3801 a b) ∨ (fact_366edf150095_4234 a b) ∨ (fact_366edf150095_4633 a b) ∨ (fact_366edf150095_4775 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ (fact_366edf150095_4386 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n477_run_tall (a b : Int)
    (h0 : (¬ (((((5 : Int) + (3 : Int)) ≤ ((4 : Int) + b)) ∧ ((fact_366edf150095_7383 a b) ∨ (fact_366edf150095_7445 a b))) ∨ ((((5 : Int) + (2 : Int)) ≤ ((4 : Int) + b)) ∧ (fact_366edf150095_7383 a b) ∧ (fact_366edf150095_7445 a b)) ∨ (((5 : Int) + (4 : Int)) ≤ ((4 : Int) + b)) ∨ ((((4 : Int) + b) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7383 a b) ∧ (fact_366edf150095_7445 a b) ∧ (((fact_366edf150095_4158 a b) ∨ (fact_366edf150095_3753 a b) ∨ (fact_366edf150095_5904 a b) ∨ (fact_366edf150095_5987 a b) ∨ (fact_366edf150095_3834 a b) ∨ (fact_366edf150095_4267 a b) ∨ (fact_366edf150095_4650 a b) ∨ (fact_366edf150095_4789 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (fact_366edf150095_4388 a b)) ∨ ((fact_366edf150095_5142 a b) ∨ (fact_366edf150095_4436 a b) ∨ (fact_366edf150095_6361 a b) ∨ (fact_366edf150095_6449 a b) ∨ (fact_366edf150095_4520 a b) ∨ (fact_366edf150095_5270 a b) ∨ (fact_366edf150095_5447 a b) ∨ (fact_366edf150095_5533 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + b) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (fact_366edf150095_5399 a b)))) ∨ ((fact_366edf150095_7383 a b) ∧ (fact_366edf150095_7445 a b) ∧ ((fact_366edf150095_4158 a b) ∨ (fact_366edf150095_3753 a b) ∨ (fact_366edf150095_5904 a b) ∨ (fact_366edf150095_5987 a b) ∨ (fact_366edf150095_3834 a b) ∨ (fact_366edf150095_4267 a b) ∨ (fact_366edf150095_4650 a b) ∨ (fact_366edf150095_4789 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (fact_366edf150095_4388 a b)) ∧ ((fact_366edf150095_5142 a b) ∨ (fact_366edf150095_4436 a b) ∨ (fact_366edf150095_6361 a b) ∨ (fact_366edf150095_6449 a b) ∨ (fact_366edf150095_4520 a b) ∨ (fact_366edf150095_5270 a b) ∨ (fact_366edf150095_5447 a b) ∨ (fact_366edf150095_5533 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((((4 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (((4 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((4 : Int) + b) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (fact_366edf150095_5399 a b))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n477_run_empty (a b run_x : Int)
    (h0 : (run_x ≤ ((4 : Int) + b)))
    (h1 : ((fact_366edf150095_2376 a b run_x) ∨ (fact_366edf150095_2311 a b run_x) ∨ (fact_366edf150095_3519 a b run_x) ∨ (fact_366edf150095_3534 a b run_x) ∨ (fact_366edf150095_2316 a b run_x) ∨ (fact_366edf150095_2958 a b run_x) ∨ (fact_366edf150095_2985 a b run_x) ∨ (fact_366edf150095_2996 a b run_x) ∨ (fact_366edf150095_2332 a b run_x) ∨ (fact_366edf150095_2972 a b run_x)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : ((5 : Int) ≤ run_x))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n477_run_floor (a b run_x : Int)
    (h0 : ((5 : Int) ≤ run_x))
    (h1 : (¬ ((fact_366edf150095_3350 a b run_x) ∨ (fact_366edf150095_3299 a b run_x) ∨ (fact_366edf150095_5214 a b run_x) ∨ (fact_366edf150095_5224 a b run_x) ∨ (fact_366edf150095_3309 a b run_x) ∨ (fact_366edf150095_3529 a b run_x) ∨ (fact_366edf150095_3565 a b run_x) ∨ (fact_366edf150095_3576 a b run_x) ∨ (fact_366edf150095_3332 a b run_x) ∨ (fact_366edf150095_3552 a b run_x))))
    (h2 : (run_x ≤ ((4 : Int) + b)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n478_point (a b : Int)
    (h0 : (¬ (((6 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((6 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n478_empty (a b : Int)
    (h0 : ((fact_366edf150095_2907 a b) ∨ (fact_366edf150095_2587 a b) ∨ (fact_366edf150095_4080 a b) ∨ (fact_366edf150095_4085 a b) ∨ (fact_366edf150095_2590 a b) ∨ (fact_366edf150095_3192 a b) ∨ (fact_366edf150095_3197 a b) ∨ (fact_366edf150095_3200 a b) ∨ ((((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ ((((6 : Int) ≥ ((5 : Int) - b)) ∧ ((6 : Int) ≤ ((5 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ (((5 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (5 : Int)) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n478_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h2 : (¬ ((((6 : Int) = jx) ∧ ((3 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : (((5 : Int) > (jx + a)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n478_o1 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (¬ ((((6 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h5 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n478_o2 (a b jx jy : Int)
    (h0 : ((((6 : Int) ≥ (jx - a)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (fact_366edf150095_2954 a b jy))
    (h4 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n478_o3 (a b jx jy : Int)
    (h0 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - b)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h2 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : ((((6 : Int) ≥ (jx - b)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (¬ (((jx = ((6 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n478_o4 (a b jx jy : Int)
    (h0 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((6 : Int) ≥ (jx - b)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n478_o5 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (¬ (((jx = ((6 : Int) + a)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((6 : Int) ≥ (jx - a)) ∧ ((6 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n478_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((5 : Int) > (jx + b)) ∨ ((5 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : (¬ ((((6 : Int) = jx) ∧ ((3 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n478_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (¬ ((((6 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h2 : ((((6 : Int) ≥ (jx - (0 : Int))) ∧ ((6 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((6 : Int) ≥ jx) ∧ ((6 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (fact_366edf150095_2955 a b jy))
    (h4 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n479_run_four (a b : Int)
    (h0 : (¬ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ ((-1 : Int) + ((2 : Int) * a)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n479_run_short (a b : Int)
    (h0 : (¬ ((((-1 : Int) + ((2 : Int) * a)) - ((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n479_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n479_run_left (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((1 : Int) + ((2 : Int) * a)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (¬ ((fact_366edf150095_6948 a b) ∨ (fact_366edf150095_6920 a b) ∨ (fact_366edf150095_7262 a b) ∨ (fact_366edf150095_7264 a b) ∨ (fact_366edf150095_6922 a b) ∨ (fact_366edf150095_6973 a b) ∨ (fact_366edf150095_6987 a b) ∨ (fact_366edf150095_6988 a b) ∨ (fact_366edf150095_6929 a b) ∨ (fact_366edf150095_6994 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ (((6 : Int) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((6 : Int) ≥ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + b)))))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h4
  clear h4
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n479_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5847 a b) ∨ (fact_366edf150095_5832 a b) ∨ (fact_366edf150095_6955 a b) ∨ (fact_366edf150095_6958 a b) ∨ (fact_366edf150095_5835 a b) ∨ (fact_366edf150095_6130 a b) ∨ (fact_366edf150095_6160 a b) ∨ (fact_366edf150095_6170 a b) ∨ (fact_366edf150095_5841 a b) ∨ (fact_366edf150095_6185 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ (((6 : Int) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((6 : Int) ≥ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n479_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ ((((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ ((fact_366edf150095_7816 a b) ∨ (fact_366edf150095_7702 a b))) ∨ (((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ (fact_366edf150095_7816 a b) ∧ (fact_366edf150095_7702 a b)) ∨ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∨ ((((-1 : Int) + ((2 : Int) * a)) = (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_366edf150095_7816 a b) ∧ (fact_366edf150095_7702 a b) ∧ (((fact_366edf150095_7021 a b) ∨ (fact_366edf150095_6977 a b) ∨ (fact_366edf150095_7279 a b) ∨ (fact_366edf150095_7283 a b) ∨ (fact_366edf150095_6981 a b) ∨ (fact_366edf150095_7093 a b) ∨ (fact_366edf150095_7152 a b) ∨ (fact_366edf150095_7158 a b) ∨ (fact_366edf150095_6990 a b) ∨ (fact_366edf150095_7166 a b) ∨ (fact_366edf150095_6996 a b)) ∨ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6698 a b) ∨ (fact_366edf150095_6171 a b) ∨ (fact_366edf150095_6727 a b) ∨ (fact_366edf150095_6187 a b)))) ∨ ((fact_366edf150095_7816 a b) ∧ (fact_366edf150095_7702 a b) ∧ ((fact_366edf150095_7021 a b) ∨ (fact_366edf150095_6977 a b) ∨ (fact_366edf150095_7279 a b) ∨ (fact_366edf150095_7283 a b) ∨ (fact_366edf150095_6981 a b) ∨ (fact_366edf150095_7093 a b) ∨ (fact_366edf150095_7152 a b) ∨ (fact_366edf150095_7158 a b) ∨ (fact_366edf150095_6990 a b) ∨ (fact_366edf150095_7166 a b) ∨ (fact_366edf150095_6996 a b)) ∧ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6698 a b) ∨ (fact_366edf150095_6171 a b) ∨ (fact_366edf150095_6727 a b) ∨ (fact_366edf150095_6187 a b))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n479_run_empty (a b run_x : Int)
    (h0 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((fact_366edf150095_2374 a b run_x) ∨ (fact_366edf150095_2309 a b run_x) ∨ (fact_366edf150095_3517 a b run_x) ∨ (fact_366edf150095_3532 a b run_x) ∨ (fact_366edf150095_2314 a b run_x) ∨ (fact_366edf150095_2956 a b run_x) ∨ (fact_366edf150095_2983 a b run_x) ∨ (fact_366edf150095_2994 a b run_x) ∨ (fact_366edf150095_2331 a b run_x) ∨ (fact_366edf150095_3017 a b run_x) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + b))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h6 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n479_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h1 : (¬ ((fact_366edf150095_3348 a b run_x) ∨ (fact_366edf150095_3297 a b run_x) ∨ (fact_366edf150095_5212 a b run_x) ∨ (fact_366edf150095_5222 a b run_x) ∨ (fact_366edf150095_3307 a b run_x) ∨ (fact_366edf150095_3527 a b run_x) ∨ (fact_366edf150095_3563 a b run_x) ∨ (fact_366edf150095_3575 a b run_x) ∨ (fact_366edf150095_3331 a b run_x) ∨ (fact_366edf150095_3601 a b run_x) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ ((3 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))))))
    (h2 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n480_point (a b : Int)
    (h0 : (¬ (((7 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((7 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n480_empty (a b : Int)
    (h0 : (((((7 : Int) ≥ ((-1 : Int) - a)) ∧ ((7 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ ((((7 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (0 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ ((((7 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((7 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((7 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((7 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ ((((7 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((7 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((7 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((7 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ ((((7 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (1 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ ((((7 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((7 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((7 : Int) ≥ ((2 : Int) * a)) ∧ ((7 : Int) ≤ ((2 : Int) * a)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + a)))) ∨ ((((7 : Int) ≥ ((2 : Int) - a)) ∧ ((7 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) + b)) ∧ ((3 : Int) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (2 : Int)) ∧ ((3 : Int) ≥ (((2 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ ((((7 : Int) ≥ ((3 : Int) - b)) ∧ ((7 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) + a)) ∧ ((3 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((7 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (4 : Int)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)))) ∨ ((((7 : Int) ≥ ((5 : Int) - b)) ∧ ((7 : Int) ≤ ((5 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ (((5 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (5 : Int)) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((7 : Int) ≥ ((6 : Int) - (0 : Int))) ∧ ((7 : Int) ≤ ((6 : Int) + b)) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ (((6 : Int) ≤ (7 : Int)) ∧ ((7 : Int) ≤ (6 : Int)) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n480_o0 (a b jx jy : Int)
    (h0 : (¬ ((((7 : Int) = jx) ∧ ((3 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((6 : Int) > (jx + a)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h5 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n480_o1 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h1 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - a))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n480_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((7 : Int) ≥ (jx - a)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jy)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - b))))
    (h6 : (fact_366edf150095_2954 a b jy))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n480_o3 (a b jx jy : Int)
    (h0 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((((7 : Int) ≥ (jx - b)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ (((jx = ((7 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (a = (b + (2 : Int))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n480_o4 (a b jx jy : Int)
    (h0 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((7 : Int) ≥ (jx - b)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n480_o5 (a b jx jy : Int)
    (h0 : (((6 : Int) > (jx + (0 : Int))) ∨ ((6 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : (¬ (((jx = ((7 : Int) + a)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((7 : Int) ≥ (jx - a)) ∧ ((7 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n480_o6 (a b jx jy : Int)
    (h0 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h3 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((jy + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h4 : (((6 : Int) > (jx + b)) ∨ ((6 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n480_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((((7 : Int) ≥ (jx - (0 : Int))) ∧ ((7 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((7 : Int) ≥ jx) ∧ ((7 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ ((((7 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h4 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h5 : (fact_366edf150095_2955 a b jy))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n481_run_four (a b : Int)
    (h0 : (¬ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ ((-1 : Int) + ((2 : Int) * a)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n481_run_short (a b : Int)
    (h0 : (¬ ((((-1 : Int) + ((2 : Int) * a)) - ((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n481_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n481_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_6948 a b) ∨ (fact_366edf150095_6920 a b) ∨ (fact_366edf150095_7262 a b) ∨ (fact_366edf150095_7264 a b) ∨ (fact_366edf150095_6922 a b) ∨ (fact_366edf150095_6973 a b) ∨ (fact_366edf150095_6987 a b) ∨ (fact_366edf150095_6988 a b) ∨ (fact_366edf150095_6929 a b) ∨ (fact_366edf150095_6994 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((2 : Int) ≥ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((3 : Int) + a))) ∨ (((6 : Int) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((6 : Int) ≥ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((2 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ (((7 : Int) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((7 : Int) ≥ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + b)))))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : ((((1 : Int) + ((2 : Int) * a)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n481_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_5847 a b) ∨ (fact_366edf150095_5832 a b) ∨ (fact_366edf150095_6955 a b) ∨ (fact_366edf150095_6958 a b) ∨ (fact_366edf150095_5835 a b) ∨ (fact_366edf150095_6130 a b) ∨ (fact_366edf150095_6160 a b) ∨ (fact_366edf150095_6170 a b) ∨ (fact_366edf150095_5841 a b) ∨ (fact_366edf150095_6185 a b) ∨ (fact_366edf150095_6189 a b) ∨ (((((7 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ (((7 : Int) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((7 : Int) ≥ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + b)))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n481_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ (((fact_366edf150095_7022 a b) ∨ (fact_366edf150095_6978 a b) ∨ (fact_366edf150095_7280 a b) ∨ (fact_366edf150095_7284 a b) ∨ (fact_366edf150095_6982 a b) ∨ (fact_366edf150095_7094 a b) ∨ (fact_366edf150095_7153 a b) ∨ (fact_366edf150095_7159 a b) ∨ (fact_366edf150095_6991 a b) ∨ (fact_366edf150095_7167 a b) ∨ (fact_366edf150095_7175 a b) ∨ (fact_366edf150095_7000 a b)) ∨ (fact_366edf150095_7768 a b))) ∨ (((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ ((fact_366edf150095_7022 a b) ∨ (fact_366edf150095_6978 a b) ∨ (fact_366edf150095_7280 a b) ∨ (fact_366edf150095_7284 a b) ∨ (fact_366edf150095_6982 a b) ∨ (fact_366edf150095_7094 a b) ∨ (fact_366edf150095_7153 a b) ∨ (fact_366edf150095_7159 a b) ∨ (fact_366edf150095_6991 a b) ∨ (fact_366edf150095_7167 a b) ∨ (fact_366edf150095_7175 a b) ∨ (fact_366edf150095_7000 a b)) ∧ (fact_366edf150095_7768 a b)) ∨ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∨ ((((-1 : Int) + ((2 : Int) * a)) = (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((fact_366edf150095_7022 a b) ∨ (fact_366edf150095_6978 a b) ∨ (fact_366edf150095_7280 a b) ∨ (fact_366edf150095_7284 a b) ∨ (fact_366edf150095_6982 a b) ∨ (fact_366edf150095_7094 a b) ∨ (fact_366edf150095_7153 a b) ∨ (fact_366edf150095_7159 a b) ∨ (fact_366edf150095_6991 a b) ∨ (fact_366edf150095_7167 a b) ∨ (fact_366edf150095_7175 a b) ∨ (fact_366edf150095_7000 a b)) ∧ (fact_366edf150095_7768 a b) ∧ (((fact_366edf150095_7021 a b) ∨ (fact_366edf150095_6977 a b) ∨ (fact_366edf150095_7279 a b) ∨ (fact_366edf150095_7283 a b) ∨ (fact_366edf150095_6981 a b) ∨ (fact_366edf150095_7093 a b) ∨ (fact_366edf150095_7152 a b) ∨ (fact_366edf150095_7158 a b) ∨ (fact_366edf150095_6990 a b) ∨ (fact_366edf150095_7166 a b) ∨ (fact_366edf150095_7174 a b) ∨ (((((7 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≤ ((2 : Int) + a)) ∧ ((3 : Int) ≥ ((2 : Int) + a))) ∨ (((7 : Int) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((7 : Int) ≥ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((3 : Int) + b))))) ∨ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6698 a b) ∨ (fact_366edf150095_6171 a b) ∨ (fact_366edf150095_6727 a b) ∨ (fact_366edf150095_6735 a b) ∨ (fact_366edf150095_6194 a b)))) ∨ (((fact_366edf150095_7022 a b) ∨ (fact_366edf150095_6978 a b) ∨ (fact_366edf150095_7280 a b) ∨ (fact_366edf150095_7284 a b) ∨ (fact_366edf150095_6982 a b) ∨ (fact_366edf150095_7094 a b) ∨ (fact_366edf150095_7153 a b) ∨ (fact_366edf150095_7159 a b) ∨ (fact_366edf150095_6991 a b) ∨ (fact_366edf150095_7167 a b) ∨ (fact_366edf150095_7175 a b) ∨ (fact_366edf150095_7000 a b)) ∧ (fact_366edf150095_7768 a b) ∧ ((fact_366edf150095_7021 a b) ∨ (fact_366edf150095_6977 a b) ∨ (fact_366edf150095_7279 a b) ∨ (fact_366edf150095_7283 a b) ∨ (fact_366edf150095_6981 a b) ∨ (fact_366edf150095_7093 a b) ∨ (fact_366edf150095_7152 a b) ∨ (fact_366edf150095_7158 a b) ∨ (fact_366edf150095_6990 a b) ∨ (fact_366edf150095_7166 a b) ∨ (fact_366edf150095_7174 a b) ∨ (((((7 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≤ ((2 : Int) + a)) ∧ ((3 : Int) ≥ ((2 : Int) + a))) ∨ (((7 : Int) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((7 : Int) ≥ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((3 : Int) + b))))) ∧ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6698 a b) ∨ (fact_366edf150095_6171 a b) ∨ (fact_366edf150095_6727 a b) ∨ (fact_366edf150095_6735 a b) ∨ (fact_366edf150095_6194 a b))))))
    (h2 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n481_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h2 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : ((fact_366edf150095_2374 a b run_x) ∨ (fact_366edf150095_2309 a b run_x) ∨ (fact_366edf150095_3517 a b run_x) ∨ (fact_366edf150095_3532 a b run_x) ∨ (fact_366edf150095_2314 a b run_x) ∨ (fact_366edf150095_2956 a b run_x) ∨ (fact_366edf150095_2983 a b run_x) ∨ (fact_366edf150095_2994 a b run_x) ∨ (fact_366edf150095_2331 a b run_x) ∨ (fact_366edf150095_3017 a b run_x) ∨ (fact_366edf150095_3021 a b run_x) ∨ (((((7 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ (((7 : Int) ≤ run_x) ∧ ((7 : Int) ≥ run_x) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + b))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n481_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3348 a b run_x) ∨ (fact_366edf150095_3297 a b run_x) ∨ (fact_366edf150095_5212 a b run_x) ∨ (fact_366edf150095_5222 a b run_x) ∨ (fact_366edf150095_3307 a b run_x) ∨ (fact_366edf150095_3527 a b run_x) ∨ (fact_366edf150095_3563 a b run_x) ∨ (fact_366edf150095_3575 a b run_x) ∨ (fact_366edf150095_3331 a b run_x) ∨ (fact_366edf150095_3601 a b run_x) ∨ (fact_366edf150095_3609 a b run_x) ∨ (((((7 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + a)) ∧ ((3 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((7 : Int) ≤ run_x) ∧ ((7 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))))))
    (h1 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h2 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n482_run_four (a b : Int)
    (h0 : (¬ ((7 : Int) ≤ ((6 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n482_run_short (a b : Int)
    (h0 : (¬ ((((6 : Int) + b) - (7 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n482_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n482_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((((-1 : Int) - a) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) + b)) ∧ ((4 : Int) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) + a)) ∧ ((4 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ (((((5 : Int) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((5 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((5 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((6 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((6 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((((7 : Int) + b) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ (((7 : Int) + b) + (0 : Int))) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ ((((7 : Int) + b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((7 : Int) + b)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n482_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((((-1 : Int) - a) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((-1 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) + b)) ∧ ((4 : Int) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((2 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (((((3 : Int) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) + a)) ∧ ((4 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ (((((5 : Int) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((5 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((6 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((6 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((((7 : Int) + b) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ (((7 : Int) + b) + (0 : Int))) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ ((((7 : Int) + b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((7 : Int) + b)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n482_run_tall (a b : Int)
    (h0 : (¬ (((((7 : Int) + (3 : Int)) ≤ ((6 : Int) + b)) ∧ ((fact_366edf150095_7595 a b) ∨ (fact_366edf150095_7654 a b))) ∨ ((((7 : Int) + (2 : Int)) ≤ ((6 : Int) + b)) ∧ (fact_366edf150095_7595 a b) ∧ (fact_366edf150095_7654 a b)) ∨ (((7 : Int) + (4 : Int)) ≤ ((6 : Int) + b)) ∨ ((((6 : Int) + b) = ((7 : Int) + (1 : Int))) ∧ (fact_366edf150095_7595 a b) ∧ (fact_366edf150095_7654 a b) ∧ (((fact_366edf150095_4185 a b) ∨ (fact_366edf150095_3780 a b) ∨ (fact_366edf150095_5931 a b) ∨ (fact_366edf150095_6014 a b) ∨ (fact_366edf150095_3861 a b) ∨ (fact_366edf150095_4294 a b) ∨ (fact_366edf150095_4669 a b) ∨ (((((3 : Int) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((4 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (fact_366edf150095_5036 a b) ∨ (fact_366edf150095_5051 a b) ∨ (fact_366edf150095_4404 a b)) ∨ ((fact_366edf150095_5156 a b) ∨ (fact_366edf150095_4450 a b) ∨ (fact_366edf150095_6375 a b) ∨ (fact_366edf150095_6463 a b) ∨ (fact_366edf150095_4534 a b) ∨ (fact_366edf150095_5284 a b) ∨ (fact_366edf150095_5456 a b) ∨ (((((3 : Int) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (fact_366edf150095_5696 a b) ∨ (fact_366edf150095_5719 a b) ∨ (fact_366edf150095_5418 a b)))) ∨ ((fact_366edf150095_7595 a b) ∧ (fact_366edf150095_7654 a b) ∧ ((fact_366edf150095_4185 a b) ∨ (fact_366edf150095_3780 a b) ∨ (fact_366edf150095_5931 a b) ∨ (fact_366edf150095_6014 a b) ∨ (fact_366edf150095_3861 a b) ∨ (fact_366edf150095_4294 a b) ∨ (fact_366edf150095_4669 a b) ∨ (((((3 : Int) - b) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((7 : Int) - (1 : Int))) ∧ (((7 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((4 : Int) ≤ ((7 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((7 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (fact_366edf150095_5036 a b) ∨ (fact_366edf150095_5051 a b) ∨ (fact_366edf150095_4404 a b)) ∧ ((fact_366edf150095_5156 a b) ∨ (fact_366edf150095_4450 a b) ∨ (fact_366edf150095_6375 a b) ∨ (fact_366edf150095_6463 a b) ∨ (fact_366edf150095_4534 a b) ∨ (fact_366edf150095_5284 a b) ∨ (fact_366edf150095_5456 a b) ∨ (((((3 : Int) - b) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((((6 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≤ ((4 : Int) + a)) ∧ ((2 : Int) ≥ ((4 : Int) + a))) ∨ (((4 : Int) ≤ (((6 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((6 : Int) + b) + (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + a)))) ∨ (fact_366edf150095_5696 a b) ∨ (fact_366edf150095_5719 a b) ∨ (fact_366edf150095_5418 a b))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a > b))
    (h3 : (a ≥ b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n482_run_empty (a b run_x : Int)
    (h0 : (run_x ≤ ((6 : Int) + b)))
    (h1 : ((7 : Int) ≤ run_x))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((fact_366edf150095_2376 a b run_x) ∨ (fact_366edf150095_2311 a b run_x) ∨ (fact_366edf150095_3519 a b run_x) ∨ (fact_366edf150095_3534 a b run_x) ∨ (fact_366edf150095_2316 a b run_x) ∨ (fact_366edf150095_2958 a b run_x) ∨ (fact_366edf150095_2985 a b run_x) ∨ (fact_366edf150095_2996 a b run_x) ∨ (fact_366edf150095_2332 a b run_x) ∨ (fact_366edf150095_3019 a b run_x) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + b)) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((((7 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((7 : Int) + b) + (0 : Int))) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ ((((7 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + b)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a))))))
    (h4 : ((((2 : Int) * a) < (((7 : Int) + b) - b)) ∨ ((((7 : Int) + b) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n482_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((6 : Int) + b)))
    (h1 : ((7 : Int) ≤ run_x))
    (h2 : (¬ ((fact_366edf150095_3350 a b run_x) ∨ (fact_366edf150095_3299 a b run_x) ∨ (fact_366edf150095_5214 a b run_x) ∨ (fact_366edf150095_5224 a b run_x) ∨ (fact_366edf150095_3309 a b run_x) ∨ (fact_366edf150095_3529 a b run_x) ∨ (fact_366edf150095_3565 a b run_x) ∨ (fact_366edf150095_3576 a b run_x) ∨ (fact_366edf150095_3332 a b run_x) ∨ (fact_366edf150095_3602 a b run_x) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + b)) ∧ (((3 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((((3 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((((7 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((7 : Int) + b) + (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ ((((7 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + b)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a)))))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n483_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ ((-1 : Int) + ((2 : Int) * a)))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n483_run_short (a b : Int)
    (h0 : (¬ ((((-1 : Int) + ((2 : Int) * a)) - ((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n483_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n483_run_left (a b : Int)
    (h0 : ((((1 : Int) + ((2 : Int) * a)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ ((fact_366edf150095_6948 a b) ∨ (fact_366edf150095_6920 a b) ∨ (fact_366edf150095_7262 a b) ∨ (fact_366edf150095_7264 a b) ∨ (fact_366edf150095_6922 a b) ∨ (fact_366edf150095_6973 a b) ∨ (fact_366edf150095_6987 a b) ∨ (fact_366edf150095_6988 a b) ∨ (fact_366edf150095_6929 a b) ∨ (fact_366edf150095_6994 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((2 : Int) ≥ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((3 : Int) + a))) ∨ (((6 : Int) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((6 : Int) ≥ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((2 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ ((((((7 : Int) + a) - a) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ ((((7 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + b)))))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n483_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_5847 a b) ∨ (fact_366edf150095_5832 a b) ∨ (fact_366edf150095_6955 a b) ∨ (fact_366edf150095_6958 a b) ∨ (fact_366edf150095_5835 a b) ∨ (fact_366edf150095_6130 a b) ∨ (fact_366edf150095_6160 a b) ∨ (fact_366edf150095_6170 a b) ∨ (fact_366edf150095_5841 a b) ∨ (fact_366edf150095_6185 a b) ∨ (fact_366edf150095_6189 a b) ∨ ((((((7 : Int) + a) - a) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ ((((7 : Int) + a) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + b)))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n483_run_tall (a b : Int)
    (h0 : (¬ ((((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ (((fact_366edf150095_7022 a b) ∨ (fact_366edf150095_6978 a b) ∨ (fact_366edf150095_7280 a b) ∨ (fact_366edf150095_7284 a b) ∨ (fact_366edf150095_6982 a b) ∨ (fact_366edf150095_7094 a b) ∨ (fact_366edf150095_7153 a b) ∨ (fact_366edf150095_7159 a b) ∨ (fact_366edf150095_6991 a b) ∨ (fact_366edf150095_7167 a b) ∨ (fact_366edf150095_7175 a b) ∨ (fact_366edf150095_7150 a b)) ∨ (fact_366edf150095_7782 a b))) ∨ (((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ ((fact_366edf150095_7022 a b) ∨ (fact_366edf150095_6978 a b) ∨ (fact_366edf150095_7280 a b) ∨ (fact_366edf150095_7284 a b) ∨ (fact_366edf150095_6982 a b) ∨ (fact_366edf150095_7094 a b) ∨ (fact_366edf150095_7153 a b) ∨ (fact_366edf150095_7159 a b) ∨ (fact_366edf150095_6991 a b) ∨ (fact_366edf150095_7167 a b) ∨ (fact_366edf150095_7175 a b) ∨ (fact_366edf150095_7150 a b)) ∧ (fact_366edf150095_7782 a b)) ∨ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∨ ((((-1 : Int) + ((2 : Int) * a)) = (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((fact_366edf150095_7022 a b) ∨ (fact_366edf150095_6978 a b) ∨ (fact_366edf150095_7280 a b) ∨ (fact_366edf150095_7284 a b) ∨ (fact_366edf150095_6982 a b) ∨ (fact_366edf150095_7094 a b) ∨ (fact_366edf150095_7153 a b) ∨ (fact_366edf150095_7159 a b) ∨ (fact_366edf150095_6991 a b) ∨ (fact_366edf150095_7167 a b) ∨ (fact_366edf150095_7175 a b) ∨ (fact_366edf150095_7150 a b)) ∧ (fact_366edf150095_7782 a b) ∧ (((fact_366edf150095_7021 a b) ∨ (fact_366edf150095_6977 a b) ∨ (fact_366edf150095_7279 a b) ∨ (fact_366edf150095_7283 a b) ∨ (fact_366edf150095_6981 a b) ∨ (fact_366edf150095_7093 a b) ∨ (fact_366edf150095_7152 a b) ∨ (fact_366edf150095_7158 a b) ∨ (fact_366edf150095_6990 a b) ∨ (fact_366edf150095_7166 a b) ∨ (fact_366edf150095_7174 a b) ∨ ((((((7 : Int) + a) - a) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)) ∧ ((3 : Int) ≥ ((2 : Int) + a))) ∨ ((((7 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((3 : Int) + b))))) ∨ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6698 a b) ∨ (fact_366edf150095_6171 a b) ∨ (fact_366edf150095_6727 a b) ∨ (fact_366edf150095_6735 a b) ∨ (fact_366edf150095_6673 a b)))) ∨ (((fact_366edf150095_7022 a b) ∨ (fact_366edf150095_6978 a b) ∨ (fact_366edf150095_7280 a b) ∨ (fact_366edf150095_7284 a b) ∨ (fact_366edf150095_6982 a b) ∨ (fact_366edf150095_7094 a b) ∨ (fact_366edf150095_7153 a b) ∨ (fact_366edf150095_7159 a b) ∨ (fact_366edf150095_6991 a b) ∨ (fact_366edf150095_7167 a b) ∨ (fact_366edf150095_7175 a b) ∨ (fact_366edf150095_7150 a b)) ∧ (fact_366edf150095_7782 a b) ∧ ((fact_366edf150095_7021 a b) ∨ (fact_366edf150095_6977 a b) ∨ (fact_366edf150095_7279 a b) ∨ (fact_366edf150095_7283 a b) ∨ (fact_366edf150095_6981 a b) ∨ (fact_366edf150095_7093 a b) ∨ (fact_366edf150095_7152 a b) ∨ (fact_366edf150095_7158 a b) ∨ (fact_366edf150095_6990 a b) ∨ (fact_366edf150095_7166 a b) ∨ (fact_366edf150095_7174 a b) ∨ ((((((7 : Int) + a) - a) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + a)) ∧ ((3 : Int) ≥ ((2 : Int) + a))) ∨ ((((7 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((3 : Int) + b))))) ∧ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6698 a b) ∨ (fact_366edf150095_6171 a b) ∨ (fact_366edf150095_6727 a b) ∨ (fact_366edf150095_6735 a b) ∨ (fact_366edf150095_6673 a b))))))
    (h1 : (a > b))
    (h2 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n483_run_empty (a b run_x : Int)
    (h0 : ((fact_366edf150095_2374 a b run_x) ∨ (fact_366edf150095_2309 a b run_x) ∨ (fact_366edf150095_3517 a b run_x) ∨ (fact_366edf150095_3532 a b run_x) ∨ (fact_366edf150095_2314 a b run_x) ∨ (fact_366edf150095_2956 a b run_x) ∨ (fact_366edf150095_2983 a b run_x) ∨ (fact_366edf150095_2994 a b run_x) ∨ (fact_366edf150095_2331 a b run_x) ∨ (fact_366edf150095_3017 a b run_x) ∨ (fact_366edf150095_3021 a b run_x) ∨ ((((((7 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ ((((7 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + b))))))
    (h1 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h2 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((2 : Int) * a) < (((7 : Int) + a) - a)) ∨ ((((7 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n483_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3348 a b run_x) ∨ (fact_366edf150095_3297 a b run_x) ∨ (fact_366edf150095_5212 a b run_x) ∨ (fact_366edf150095_5222 a b run_x) ∨ (fact_366edf150095_3307 a b run_x) ∨ (fact_366edf150095_3527 a b run_x) ∨ (fact_366edf150095_3563 a b run_x) ∨ (fact_366edf150095_3575 a b run_x) ∨ (fact_366edf150095_3331 a b run_x) ∨ (fact_366edf150095_3601 a b run_x) ∨ (fact_366edf150095_3609 a b run_x) ∨ ((((((7 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((7 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((7 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))))))
    (h1 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h2 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n484_run_four (a b : Int)
    (h0 : (¬ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ ((-1 : Int) + ((2 : Int) * a)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n484_run_short (a b : Int)
    (h0 : (¬ ((((-1 : Int) + ((2 : Int) * a)) - ((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n484_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n484_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_6948 a b) ∨ (fact_366edf150095_6920 a b) ∨ (fact_366edf150095_7262 a b) ∨ (fact_366edf150095_7264 a b) ∨ (fact_366edf150095_6922 a b) ∨ (fact_366edf150095_6973 a b) ∨ (fact_366edf150095_6987 a b) ∨ (fact_366edf150095_6988 a b) ∨ (fact_366edf150095_6929 a b) ∨ (fact_366edf150095_6994 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((6 : Int) + b)) ∧ ((2 : Int) ≥ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((3 : Int) + a))) ∨ (((6 : Int) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((6 : Int) ≥ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((2 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((7 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) + b)) ∧ ((2 : Int) ≤ ((3 : Int) + b))) ∨ (((7 : Int) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((7 : Int) ≥ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((2 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((2 : Int) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h1 : ((((1 : Int) + ((2 : Int) * a)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n484_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5847 a b) ∨ (fact_366edf150095_5832 a b) ∨ (fact_366edf150095_6955 a b) ∨ (fact_366edf150095_6958 a b) ∨ (fact_366edf150095_5835 a b) ∨ (fact_366edf150095_6130 a b) ∨ (fact_366edf150095_6160 a b) ∨ (fact_366edf150095_6170 a b) ∨ (fact_366edf150095_5841 a b) ∨ (fact_366edf150095_6185 a b) ∨ (fact_366edf150095_6189 a b) ∨ (((((7 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ ((7 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) + b)) ∧ ((2 : Int) ≤ ((3 : Int) + b))) ∨ (((7 : Int) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((7 : Int) ≥ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((2 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((2 : Int) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n484_run_tall (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((2 : Int) * a)) ∨ (((1 : Int) + a) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h2 : (¬ ((((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ (((fact_366edf150095_7022 a b) ∨ (fact_366edf150095_6978 a b) ∨ (fact_366edf150095_7280 a b) ∨ (fact_366edf150095_7284 a b) ∨ (fact_366edf150095_6982 a b) ∨ (fact_366edf150095_7094 a b) ∨ (fact_366edf150095_7153 a b) ∨ (fact_366edf150095_7159 a b) ∨ (fact_366edf150095_6991 a b) ∨ (fact_366edf150095_7167 a b) ∨ (fact_366edf150095_7175 a b) ∨ (fact_366edf150095_7178 a b)) ∨ (fact_366edf150095_7783 a b))) ∨ (((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ ((fact_366edf150095_7022 a b) ∨ (fact_366edf150095_6978 a b) ∨ (fact_366edf150095_7280 a b) ∨ (fact_366edf150095_7284 a b) ∨ (fact_366edf150095_6982 a b) ∨ (fact_366edf150095_7094 a b) ∨ (fact_366edf150095_7153 a b) ∨ (fact_366edf150095_7159 a b) ∨ (fact_366edf150095_6991 a b) ∨ (fact_366edf150095_7167 a b) ∨ (fact_366edf150095_7175 a b) ∨ (fact_366edf150095_7178 a b)) ∧ (fact_366edf150095_7783 a b)) ∨ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∨ ((((-1 : Int) + ((2 : Int) * a)) = (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((fact_366edf150095_7022 a b) ∨ (fact_366edf150095_6978 a b) ∨ (fact_366edf150095_7280 a b) ∨ (fact_366edf150095_7284 a b) ∨ (fact_366edf150095_6982 a b) ∨ (fact_366edf150095_7094 a b) ∨ (fact_366edf150095_7153 a b) ∨ (fact_366edf150095_7159 a b) ∨ (fact_366edf150095_6991 a b) ∨ (fact_366edf150095_7167 a b) ∨ (fact_366edf150095_7175 a b) ∨ (fact_366edf150095_7178 a b)) ∧ (fact_366edf150095_7783 a b) ∧ (((fact_366edf150095_7021 a b) ∨ (fact_366edf150095_6977 a b) ∨ (fact_366edf150095_7279 a b) ∨ (fact_366edf150095_7283 a b) ∨ (fact_366edf150095_6981 a b) ∨ (fact_366edf150095_7093 a b) ∨ (fact_366edf150095_7152 a b) ∨ (fact_366edf150095_7158 a b) ∨ (fact_366edf150095_6990 a b) ∨ (fact_366edf150095_7166 a b) ∨ (fact_366edf150095_7174 a b) ∨ (((((7 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ (((3 : Int) + b) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((3 : Int) + b))) ∨ (((7 : Int) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((7 : Int) ≥ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ (((3 : Int) + b) + (0 : Int)))))) ∨ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6698 a b) ∨ (fact_366edf150095_6171 a b) ∨ (fact_366edf150095_6727 a b) ∨ (fact_366edf150095_6735 a b) ∨ (fact_366edf150095_6742 a b)))) ∨ (((fact_366edf150095_7022 a b) ∨ (fact_366edf150095_6978 a b) ∨ (fact_366edf150095_7280 a b) ∨ (fact_366edf150095_7284 a b) ∨ (fact_366edf150095_6982 a b) ∨ (fact_366edf150095_7094 a b) ∨ (fact_366edf150095_7153 a b) ∨ (fact_366edf150095_7159 a b) ∨ (fact_366edf150095_6991 a b) ∨ (fact_366edf150095_7167 a b) ∨ (fact_366edf150095_7175 a b) ∨ (fact_366edf150095_7178 a b)) ∧ (fact_366edf150095_7783 a b) ∧ ((fact_366edf150095_7021 a b) ∨ (fact_366edf150095_6977 a b) ∨ (fact_366edf150095_7279 a b) ∨ (fact_366edf150095_7283 a b) ∨ (fact_366edf150095_6981 a b) ∨ (fact_366edf150095_7093 a b) ∨ (fact_366edf150095_7152 a b) ∨ (fact_366edf150095_7158 a b) ∨ (fact_366edf150095_6990 a b) ∨ (fact_366edf150095_7166 a b) ∨ (fact_366edf150095_7174 a b) ∨ (((((7 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((7 : Int) + a)) ∧ (((3 : Int) + b) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((3 : Int) + b))) ∨ (((7 : Int) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((7 : Int) ≥ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ (((3 : Int) + b) + (0 : Int)))))) ∧ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6698 a b) ∨ (fact_366edf150095_6171 a b) ∨ (fact_366edf150095_6727 a b) ∨ (fact_366edf150095_6735 a b) ∨ (fact_366edf150095_6742 a b))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a > b))
    (h7 : (a ≥ b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n484_run_empty (a b run_x : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((2 : Int) * a) < ((7 : Int) - (0 : Int))) ∨ (((7 : Int) + a) < ((2 : Int) * a)) ∨ (((1 : Int) + a) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h4 : ((fact_366edf150095_2374 a b run_x) ∨ (fact_366edf150095_2309 a b run_x) ∨ (fact_366edf150095_3517 a b run_x) ∨ (fact_366edf150095_3532 a b run_x) ∨ (fact_366edf150095_2314 a b run_x) ∨ (fact_366edf150095_2956 a b run_x) ∨ (fact_366edf150095_2983 a b run_x) ∨ (fact_366edf150095_2994 a b run_x) ∨ (fact_366edf150095_2331 a b run_x) ∨ (fact_366edf150095_3017 a b run_x) ∨ (fact_366edf150095_3021 a b run_x) ∨ (((((7 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) + b)) ∧ ((2 : Int) ≤ ((3 : Int) + b))) ∨ (((7 : Int) ≤ run_x) ∧ ((7 : Int) ≥ run_x) ∧ ((2 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((2 : Int) ≤ (((3 : Int) + b) + (0 : Int)))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n484_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h1 : (¬ ((fact_366edf150095_3348 a b run_x) ∨ (fact_366edf150095_3297 a b run_x) ∨ (fact_366edf150095_5212 a b run_x) ∨ (fact_366edf150095_5222 a b run_x) ∨ (fact_366edf150095_3307 a b run_x) ∨ (fact_366edf150095_3527 a b run_x) ∨ (fact_366edf150095_3563 a b run_x) ∨ (fact_366edf150095_3575 a b run_x) ∨ (fact_366edf150095_3331 a b run_x) ∨ (fact_366edf150095_3601 a b run_x) ∨ (fact_366edf150095_3609 a b run_x) ∨ (((((7 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((7 : Int) + a)) ∧ (((3 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((7 : Int) ≤ run_x) ∧ ((7 : Int) ≥ run_x) ∧ ((((3 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h2 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n485_run_four (a b : Int)
    (h0 : (¬ ((6 : Int) ≤ ((5 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n485_run_short (a b : Int)
    (h0 : (¬ ((((5 : Int) + b) - (6 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n485_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n485_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3505 a b) ∨ (fact_366edf150095_3454 a b) ∨ (fact_366edf150095_5781 a b) ∨ (fact_366edf150095_5789 a b) ∨ (fact_366edf150095_3462 a b) ∨ (fact_366edf150095_3700 a b) ∨ (fact_366edf150095_3918 a b) ∨ (fact_366edf150095_3972 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ (((((5 : Int) - b) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((5 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((5 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((5 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3709 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n485_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_4129 a b) ∨ (fact_366edf150095_3724 a b) ∨ (fact_366edf150095_5875 a b) ∨ (fact_366edf150095_5958 a b) ∨ (fact_366edf150095_3805 a b) ∨ (fact_366edf150095_4238 a b) ∨ (fact_366edf150095_4635 a b) ∨ (((((3 : Int) - b) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) + a)) ∧ ((4 : Int) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((3 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((4 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + a)))) ∨ (((((5 : Int) - b) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((((5 : Int) + b) + (1 : Int)) ≤ ((5 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((5 : Int) ≤ (((5 : Int) + b) + (1 : Int))) ∧ ((5 : Int) ≥ (((5 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4394 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n485_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (¬ (((((6 : Int) + (3 : Int)) ≤ ((5 : Int) + b)) ∧ ((fact_366edf150095_7483 a b) ∨ (fact_366edf150095_7556 a b))) ∨ ((((6 : Int) + (2 : Int)) ≤ ((5 : Int) + b)) ∧ (fact_366edf150095_7483 a b) ∧ (fact_366edf150095_7556 a b)) ∨ (((6 : Int) + (4 : Int)) ≤ ((5 : Int) + b)) ∨ ((((5 : Int) + b) = ((6 : Int) + (1 : Int))) ∧ (fact_366edf150095_7483 a b) ∧ (fact_366edf150095_7556 a b) ∧ (((fact_366edf150095_4173 a b) ∨ (fact_366edf150095_3768 a b) ∨ (fact_366edf150095_5919 a b) ∨ (fact_366edf150095_6002 a b) ∨ (fact_366edf150095_3849 a b) ∨ (fact_366edf150095_4282 a b) ∨ (fact_366edf150095_4661 a b) ∨ (fact_366edf150095_4812 a b) ∨ (fact_366edf150095_4004 a b) ∨ (fact_366edf150095_5029 a b) ∨ (fact_366edf150095_4396 a b)) ∨ ((fact_366edf150095_5151 a b) ∨ (fact_366edf150095_4445 a b) ∨ (fact_366edf150095_6370 a b) ∨ (fact_366edf150095_6458 a b) ∨ (fact_366edf150095_4529 a b) ∨ (fact_366edf150095_5279 a b) ∨ (fact_366edf150095_5452 a b) ∨ (fact_366edf150095_5544 a b) ∨ (fact_366edf150095_4864 a b) ∨ (fact_366edf150095_5692 a b) ∨ (fact_366edf150095_5410 a b)))) ∨ ((fact_366edf150095_7483 a b) ∧ (fact_366edf150095_7556 a b) ∧ ((fact_366edf150095_4173 a b) ∨ (fact_366edf150095_3768 a b) ∨ (fact_366edf150095_5919 a b) ∨ (fact_366edf150095_6002 a b) ∨ (fact_366edf150095_3849 a b) ∨ (fact_366edf150095_4282 a b) ∨ (fact_366edf150095_4661 a b) ∨ (fact_366edf150095_4812 a b) ∨ (fact_366edf150095_4004 a b) ∨ (fact_366edf150095_5029 a b) ∨ (fact_366edf150095_4396 a b)) ∧ ((fact_366edf150095_5151 a b) ∨ (fact_366edf150095_4445 a b) ∨ (fact_366edf150095_6370 a b) ∨ (fact_366edf150095_6458 a b) ∨ (fact_366edf150095_4529 a b) ∨ (fact_366edf150095_5279 a b) ∨ (fact_366edf150095_5452 a b) ∨ (fact_366edf150095_5544 a b) ∨ (fact_366edf150095_4864 a b) ∨ (fact_366edf150095_5692 a b) ∨ (fact_366edf150095_5410 a b))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n485_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((6 : Int) ≤ run_x))
    (h2 : (run_x ≤ ((5 : Int) + b)))
    (h3 : ((fact_366edf150095_2376 a b run_x) ∨ (fact_366edf150095_2311 a b run_x) ∨ (fact_366edf150095_3519 a b run_x) ∨ (fact_366edf150095_3534 a b run_x) ∨ (fact_366edf150095_2316 a b run_x) ∨ (fact_366edf150095_2958 a b run_x) ∨ (fact_366edf150095_2985 a b run_x) ∨ (fact_366edf150095_2996 a b run_x) ∨ (fact_366edf150095_2332 a b run_x) ∨ (fact_366edf150095_3019 a b run_x) ∨ (fact_366edf150095_2975 a b run_x)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n485_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3350 a b run_x) ∨ (fact_366edf150095_3299 a b run_x) ∨ (fact_366edf150095_5214 a b run_x) ∨ (fact_366edf150095_5224 a b run_x) ∨ (fact_366edf150095_3309 a b run_x) ∨ (fact_366edf150095_3529 a b run_x) ∨ (fact_366edf150095_3565 a b run_x) ∨ (fact_366edf150095_3576 a b run_x) ∨ (fact_366edf150095_3332 a b run_x) ∨ (fact_366edf150095_3602 a b run_x) ∨ (fact_366edf150095_3555 a b run_x))))
    (h1 : ((6 : Int) ≤ run_x))
    (h2 : (run_x ≤ ((5 : Int) + b)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n486_run_four (a b : Int)
    (h0 : (¬ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ ((-1 : Int) + ((2 : Int) * a)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n486_run_short (a b : Int)
    (h0 : (¬ ((((-1 : Int) + ((2 : Int) * a)) - ((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n486_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n486_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_6948 a b) ∨ (fact_366edf150095_6920 a b) ∨ (fact_366edf150095_7262 a b) ∨ (fact_366edf150095_7264 a b) ∨ (fact_366edf150095_6922 a b) ∨ (fact_366edf150095_6973 a b) ∨ (fact_366edf150095_6987 a b) ∨ (fact_366edf150095_6988 a b) ∨ (fact_366edf150095_6929 a b) ∨ (fact_366edf150095_6994 a b) ∨ ((((((6 : Int) + a) - a) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ (((6 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ ((((6 : Int) + a) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + b)))))))
    (h1 : ((((1 : Int) + ((2 : Int) * a)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n486_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_5847 a b) ∨ (fact_366edf150095_5832 a b) ∨ (fact_366edf150095_6955 a b) ∨ (fact_366edf150095_6958 a b) ∨ (fact_366edf150095_5835 a b) ∨ (fact_366edf150095_6130 a b) ∨ (fact_366edf150095_6160 a b) ∨ (fact_366edf150095_6170 a b) ∨ (fact_366edf150095_5841 a b) ∨ (fact_366edf150095_6185 a b) ∨ ((((((6 : Int) + a) - a) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ (((6 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ ((((6 : Int) + a) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + b)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n486_run_tall (a b : Int)
    (h0 : (¬ ((((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ ((fact_366edf150095_7822 a b) ∨ (fact_366edf150095_7711 a b))) ∨ (((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ (fact_366edf150095_7822 a b) ∧ (fact_366edf150095_7711 a b)) ∨ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∨ ((((-1 : Int) + ((2 : Int) * a)) = (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_366edf150095_7822 a b) ∧ (fact_366edf150095_7711 a b) ∧ (((fact_366edf150095_7021 a b) ∨ (fact_366edf150095_6977 a b) ∨ (fact_366edf150095_7279 a b) ∨ (fact_366edf150095_7283 a b) ∨ (fact_366edf150095_6981 a b) ∨ (fact_366edf150095_7093 a b) ∨ (fact_366edf150095_7152 a b) ∨ (fact_366edf150095_7158 a b) ∨ (fact_366edf150095_6990 a b) ∨ (fact_366edf150095_7166 a b) ∨ (fact_366edf150095_7146 a b)) ∨ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6698 a b) ∨ (fact_366edf150095_6171 a b) ∨ (fact_366edf150095_6727 a b) ∨ (fact_366edf150095_6671 a b)))) ∨ ((fact_366edf150095_7822 a b) ∧ (fact_366edf150095_7711 a b) ∧ ((fact_366edf150095_7021 a b) ∨ (fact_366edf150095_6977 a b) ∨ (fact_366edf150095_7279 a b) ∨ (fact_366edf150095_7283 a b) ∨ (fact_366edf150095_6981 a b) ∨ (fact_366edf150095_7093 a b) ∨ (fact_366edf150095_7152 a b) ∨ (fact_366edf150095_7158 a b) ∨ (fact_366edf150095_6990 a b) ∨ (fact_366edf150095_7166 a b) ∨ (fact_366edf150095_7146 a b)) ∧ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6698 a b) ∨ (fact_366edf150095_6171 a b) ∨ (fact_366edf150095_6727 a b) ∨ (fact_366edf150095_6671 a b))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n486_run_empty (a b run_x : Int)
    (h0 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h1 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h2 : ((((2 : Int) * a) < (((6 : Int) + a) - a)) ∨ ((((6 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((fact_366edf150095_2374 a b run_x) ∨ (fact_366edf150095_2309 a b run_x) ∨ (fact_366edf150095_3517 a b run_x) ∨ (fact_366edf150095_3532 a b run_x) ∨ (fact_366edf150095_2314 a b run_x) ∨ (fact_366edf150095_2956 a b run_x) ∨ (fact_366edf150095_2983 a b run_x) ∨ (fact_366edf150095_2994 a b run_x) ∨ (fact_366edf150095_2331 a b run_x) ∨ (fact_366edf150095_3017 a b run_x) ∨ ((((((6 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((6 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ ((((6 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + b))))))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n486_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3348 a b run_x) ∨ (fact_366edf150095_3297 a b run_x) ∨ (fact_366edf150095_5212 a b run_x) ∨ (fact_366edf150095_5222 a b run_x) ∨ (fact_366edf150095_3307 a b run_x) ∨ (fact_366edf150095_3527 a b run_x) ∨ (fact_366edf150095_3563 a b run_x) ∨ (fact_366edf150095_3575 a b run_x) ∨ (fact_366edf150095_3331 a b run_x) ∨ (fact_366edf150095_3601 a b run_x) ∨ ((((((6 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((6 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((6 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ (((3 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((3 : Int) + b)))))))
    (h1 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h2 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n487_point (a b : Int)
    (h0 : (fact_366edf150095_3 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n487_empty (a b : Int)
    (h0 : ((((2 : Int) + ((2 : Int) * a)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < ((2 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h1 : ((fact_366edf150095_3225 a b) ∨ (fact_366edf150095_3131 a b) ∨ (fact_366edf150095_4221 a b) ∨ (fact_366edf150095_4310 a b) ∨ (fact_366edf150095_3139 a b) ∨ (fact_366edf150095_3356 a b) ∨ (fact_366edf150095_3391 a b) ∨ (fact_366edf150095_3404 a b) ∨ (fact_366edf150095_3153 a b) ∨ (((((5 : Int) - b) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((5 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) + a)) ∧ ((2 : Int) ≤ ((3 : Int) + a))) ∨ (((5 : Int) ≤ ((5 : Int) + b)) ∧ ((5 : Int) ≥ ((5 : Int) + b)) ∧ ((2 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (((((6 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((6 : Int) + b)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ (((6 : Int) ≤ ((5 : Int) + b)) ∧ ((6 : Int) ≥ ((5 : Int) + b)) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + a))))))
    (h2 : ((((1 : Int) + ((2 : Int) * a)) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h3 : ((((1 : Int) + ((2 : Int) * a)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n487_o0 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1826 a b jx jy))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((jx + a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - (0 : Int))) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n487_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (fact_366edf150095_1833 a b jx jy))
    (h2 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n487_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_366edf150095_1853 a b jx jy))
    (h2 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n487_o3 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - b)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h3 : (((jx + (0 : Int)) < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (fact_366edf150095_1868 a b jx jy))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n487_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_366edf150095_1869 a b jx jy))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n487_o5 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - a)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_366edf150095_1852 a b jx jy))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (((jx + (0 : Int)) < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h7 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h8 : ((jx < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h9 : ((jx < ((2 : Int) * a)) ∨ (((2 : Int) * a) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h10 : (a = (b + (2 : Int))))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n487_o6 (a b jx jy : Int)
    (h0 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (fact_366edf150095_1832 a b jx jy))
    (h3 : ((jx < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n487_o7 (a b jx jy : Int)
    (h0 : ((jx < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (fact_366edf150095_1827 a b jx jy))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n488_run_four (a b : Int)
    (h0 : (¬ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ ((-1 : Int) + ((2 : Int) * a)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n488_run_short (a b : Int)
    (h0 : (¬ ((((-1 : Int) + ((2 : Int) * a)) - ((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n488_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n488_run_left (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((((1 : Int) + ((2 : Int) * a)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ ((fact_366edf150095_6948 a b) ∨ (fact_366edf150095_6920 a b) ∨ (fact_366edf150095_7262 a b) ∨ (fact_366edf150095_7264 a b) ∨ (fact_366edf150095_6922 a b) ∨ (fact_366edf150095_6973 a b) ∨ (fact_366edf150095_6987 a b) ∨ (fact_366edf150095_6988 a b) ∨ (fact_366edf150095_6929 a b) ∨ (fact_366edf150095_6994 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) + b)) ∧ ((2 : Int) ≤ ((3 : Int) + b))) ∨ (((6 : Int) ≤ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((6 : Int) ≥ (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((2 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((2 : Int) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n488_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_5847 a b) ∨ (fact_366edf150095_5832 a b) ∨ (fact_366edf150095_6955 a b) ∨ (fact_366edf150095_6958 a b) ∨ (fact_366edf150095_5835 a b) ∨ (fact_366edf150095_6130 a b) ∨ (fact_366edf150095_6160 a b) ∨ (fact_366edf150095_6170 a b) ∨ (fact_366edf150095_5841 a b) ∨ (fact_366edf150095_6185 a b) ∨ (((((6 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a)) + (1 : Int)) ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) + b)) ∧ ((2 : Int) ≤ ((3 : Int) + b))) ∨ (((6 : Int) ≤ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((6 : Int) ≥ (((-1 : Int) + ((2 : Int) * a)) + (1 : Int))) ∧ ((2 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((2 : Int) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n488_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ (((1 : Int) + a) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (¬ ((((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ ((fact_366edf150095_7823 a b) ∨ (fact_366edf150095_7712 a b))) ∨ (((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∧ (fact_366edf150095_7823 a b) ∧ (fact_366edf150095_7712 a b)) ∨ ((((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a))) ∨ ((((-1 : Int) + ((2 : Int) * a)) = (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_366edf150095_7823 a b) ∧ (fact_366edf150095_7712 a b) ∧ (((fact_366edf150095_7021 a b) ∨ (fact_366edf150095_6977 a b) ∨ (fact_366edf150095_7279 a b) ∨ (fact_366edf150095_7283 a b) ∨ (fact_366edf150095_6981 a b) ∨ (fact_366edf150095_7093 a b) ∨ (fact_366edf150095_7152 a b) ∨ (fact_366edf150095_7158 a b) ∨ (fact_366edf150095_6990 a b) ∨ (fact_366edf150095_7166 a b) ∨ (fact_366edf150095_7170 a b)) ∨ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6698 a b) ∨ (fact_366edf150095_6171 a b) ∨ (fact_366edf150095_6727 a b) ∨ (fact_366edf150095_6731 a b)))) ∨ ((fact_366edf150095_7823 a b) ∧ (fact_366edf150095_7712 a b) ∧ ((fact_366edf150095_7021 a b) ∨ (fact_366edf150095_6977 a b) ∨ (fact_366edf150095_7279 a b) ∨ (fact_366edf150095_7283 a b) ∨ (fact_366edf150095_6981 a b) ∨ (fact_366edf150095_7093 a b) ∨ (fact_366edf150095_7152 a b) ∨ (fact_366edf150095_7158 a b) ∨ (fact_366edf150095_6990 a b) ∨ (fact_366edf150095_7166 a b) ∨ (fact_366edf150095_7170 a b)) ∧ ((fact_366edf150095_6202 a b) ∨ (fact_366edf150095_6146 a b) ∨ (fact_366edf150095_7046 a b) ∨ (fact_366edf150095_7050 a b) ∨ (fact_366edf150095_6150 a b) ∨ (fact_366edf150095_6632 a b) ∨ (fact_366edf150095_6688 a b) ∨ (fact_366edf150095_6698 a b) ∨ (fact_366edf150095_6171 a b) ∨ (fact_366edf150095_6727 a b) ∨ (fact_366edf150095_6731 a b))))))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n488_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((fact_366edf150095_2374 a b run_x) ∨ (fact_366edf150095_2309 a b run_x) ∨ (fact_366edf150095_3517 a b run_x) ∨ (fact_366edf150095_3532 a b run_x) ∨ (fact_366edf150095_2314 a b run_x) ∨ (fact_366edf150095_2956 a b run_x) ∨ (fact_366edf150095_2983 a b run_x) ∨ (fact_366edf150095_2994 a b run_x) ∨ (fact_366edf150095_2331 a b run_x) ∨ (fact_366edf150095_3017 a b run_x) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) + b)) ∧ ((2 : Int) ≤ ((3 : Int) + b))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((2 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((2 : Int) ≤ (((3 : Int) + b) + (0 : Int)))))))
    (h2 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h3 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h4 : ((((2 : Int) * a) < ((6 : Int) - (0 : Int))) ∨ (((6 : Int) + a) < ((2 : Int) * a)) ∨ (((1 : Int) + a) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n488_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a))))
    (h1 : (¬ ((fact_366edf150095_3348 a b run_x) ∨ (fact_366edf150095_3297 a b run_x) ∨ (fact_366edf150095_5212 a b run_x) ∨ (fact_366edf150095_5222 a b run_x) ∨ (fact_366edf150095_3307 a b run_x) ∨ (fact_366edf150095_3527 a b run_x) ∨ (fact_366edf150095_3563 a b run_x) ∨ (fact_366edf150095_3575 a b run_x) ∨ (fact_366edf150095_3331 a b run_x) ∨ (fact_366edf150095_3601 a b run_x) ∨ (((((6 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((6 : Int) + a)) ∧ (((3 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((6 : Int) ≤ run_x) ∧ ((6 : Int) ≥ run_x) ∧ ((((3 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h2 : (((1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n489_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_366edf150095_3 a b))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n489_empty (a b : Int)
    (h0 : ((fact_366edf150095_3225 a b) ∨ (fact_366edf150095_3131 a b) ∨ (fact_366edf150095_4221 a b) ∨ (fact_366edf150095_4310 a b) ∨ (fact_366edf150095_3139 a b) ∨ (fact_366edf150095_3356 a b) ∨ (fact_366edf150095_3391 a b) ∨ (fact_366edf150095_3404 a b) ∨ (fact_366edf150095_3153 a b) ∨ ((((((5 : Int) + a) - a) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ (((5 : Int) + a) + (0 : Int))) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ ((((5 : Int) + a) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((5 : Int) + a)) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + b))))))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : ((((1 : Int) + ((2 : Int) * a)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((2 : Int) > ((0 : Int) + b)) ∨ ((2 : Int) < ((0 : Int) - (0 : Int)))))
    (h3 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((2 : Int) * a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < ((2 : Int) * a)) ∨ ((2 : Int) > ((1 : Int) + a)) ∨ ((2 : Int) < ((1 : Int) - (0 : Int)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n489_o0 (a b jx jy : Int)
    (h0 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (((jx + a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - (0 : Int))) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (fact_366edf150095_1826 a b jx jy))
    (h5 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n489_o1 (a b jx jy : Int)
    (h0 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (fact_366edf150095_1833 a b jx jy))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n489_o2 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h4 : (fact_366edf150095_1853 a b jx jy))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((4 : Int) > (jx + (0 : Int))) ∨ ((4 : Int) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + a) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n489_o3 (a b jx jy : Int)
    (h0 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h1 : (((jx + (0 : Int)) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - b)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h7 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h8 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + a) < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h9 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h10 : (fact_366edf150095_1868 a b jx jy))
    (h11 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + a) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - (0 : Int)))))
    (h12 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h13 : (a = (b + (2 : Int))))
    (h14 : (a ≥ b))
    (h15 : (b ≥ (3 : Int)))
    (h16 : (a > b))
    (h17 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n489_o4 (a b jx jy : Int)
    (h0 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h1 : (fact_366edf150095_1869 a b jx jy))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n489_o5 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (((2 : Int) > jx) ∨ ((2 : Int) < jx) ∨ ((jy + b) < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < (jy - (0 : Int)))))
    (h2 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - a)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h3 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((1 : Int) > jx) ∨ ((1 : Int) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h6 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (((jx + (0 : Int)) < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h9 : (((3 : Int) > jx) ∨ ((3 : Int) < jx) ∨ ((jy + b) < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h10 : (fact_366edf150095_1852 a b jx jy))
    (h11 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h12 : (((0 : Int) > jx) ∨ ((0 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h13 : (a = (b + (2 : Int))))
    (h14 : (b ≥ (3 : Int)))
    (h15 : (a ≥ b))
    (h16 : (a > b))
    (h17 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n489_o6 (a b jx jy : Int)
    (h0 : ((jx < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (fact_366edf150095_1832 a b jx jy))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n489_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((((2 : Int) * a) < (((5 : Int) + a) - a)) ∨ ((((5 : Int) + a) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (fact_366edf150095_1827 a b jx jy))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (((jx + a) < ((2 : Int) * a)) ∨ (((2 : Int) * a) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n490_point (a b : Int)
    (h0 : (fact_366edf150095_3 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n490_empty (a b : Int)
    (h0 : ((fact_366edf150095_3225 a b) ∨ (fact_366edf150095_3131 a b) ∨ (fact_366edf150095_4221 a b) ∨ (fact_366edf150095_4310 a b) ∨ (fact_366edf150095_3139 a b) ∨ (fact_366edf150095_3356 a b) ∨ (fact_366edf150095_3391 a b) ∨ (fact_366edf150095_3404 a b) ∨ (fact_366edf150095_3153 a b) ∨ (((((5 : Int) - (0 : Int)) ≤ ((5 : Int) + b)) ∧ (((5 : Int) + b) ≤ ((5 : Int) + b)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (3 : Int))) ∨ (((5 : Int) ≤ ((5 : Int) + b)) ∧ ((5 : Int) ≥ ((5 : Int) + b)) ∧ ((2 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) + a))))))
    (h1 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : ((((2 : Int) + ((2 : Int) * a)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((2 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((1 : Int) + ((2 : Int) * a)) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < ((1 : Int) + ((2 : Int) * a))) ∨ ((3 : Int) > ((0 : Int) + b)) ∨ ((3 : Int) < ((0 : Int) - (0 : Int)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n490_o0 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1826 a b jx jy))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((jx + a) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - (0 : Int))) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h3 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n490_o1 (a b jx jy : Int)
    (h0 : (fact_366edf150095_1833 a b jx jy))
    (h1 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n490_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h2 : (fact_366edf150095_1853 a b jx jy))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n490_o3 (a b jx jy : Int)
    (h0 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jx < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h3 : ((jx < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < jx) ∨ ((jy + a) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (fact_366edf150095_1868 a b jx jy))
    (h6 : ((jx < ((2 : Int) * a)) ∨ (((2 : Int) * a) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h9 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - b)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n490_o4 (a b jx jy : Int)
    (h0 : (((5 : Int) > (jx + (0 : Int))) ∨ ((5 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_366edf150095_1869 a b jx jy))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n490_o5 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((4 : Int) - (0 : Int))) ∨ (((4 : Int) + b) < (jx - a)) ∨ ((2 : Int) > jy) ∨ ((2 : Int) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_366edf150095_1852 a b jx jy))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((2 : Int) * a)) ∨ (((2 : Int) * a) < jx) ∨ ((jy + b) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h5 : ((jx < ((1 : Int) + ((2 : Int) * a))) ∨ (((1 : Int) + ((2 : Int) * a)) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h6 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h7 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (((jx + (0 : Int)) < ((2 : Int) + ((2 : Int) * a))) ∨ (((2 : Int) + ((2 : Int) * a)) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h10 : (b ≥ (3 : Int)))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    (h13 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n490_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h3 : (fact_366edf150095_1832 a b jx jy))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n490_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_366edf150095_1827 a b jx jy))
    (h3 : ((jx < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n491_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≤ a)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n491_run_short (a b : Int)
    (h0 : (¬ ((a - (3 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n491_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n491_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3511 a b) ∨ (fact_366edf150095_3481 a b) ∨ (fact_366edf150095_5816 a b) ∨ (fact_366edf150095_5818 a b) ∨ (fact_366edf150095_3483 a b) ∨ (fact_366edf150095_4083 a b) ∨ (fact_366edf150095_4093 a b) ∨ ((((6 : Int) ≥ ((3 : Int) - b)) ∧ ((6 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (fact_366edf150095_4094 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n491_run_right (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (¬ ((fact_366edf150095_3236 a b) ∨ (fact_366edf150095_3195 a b) ∨ (fact_366edf150095_5102 a b) ∨ (fact_366edf150095_5104 a b) ∨ (fact_366edf150095_3196 a b) ∨ (fact_366edf150095_3432 a b) ∨ (fact_366edf150095_3433 a b) ∨ ((((6 : Int) ≥ ((3 : Int) - b)) ∧ ((6 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (fact_366edf150095_3434 a b))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n491_run_tall (a b : Int)
    (h0 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_366edf150095_7390 a b) ∨ (fact_366edf150095_7351 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_366edf150095_7390 a b) ∧ (fact_366edf150095_7351 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_366edf150095_7390 a b) ∧ (fact_366edf150095_7351 a b) ∧ (((fact_366edf150095_4164 a b) ∨ (fact_366edf150095_3759 a b) ∨ (fact_366edf150095_5910 a b) ∨ (fact_366edf150095_5993 a b) ∨ (fact_366edf150095_3840 a b) ∨ (fact_366edf150095_4273 a b) ∨ (fact_366edf150095_4654 a b) ∨ (fact_366edf150095_4802 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (fact_366edf150095_4994 a b)) ∨ ((fact_366edf150095_3442 a b) ∨ (fact_366edf150095_3366 a b) ∨ (fact_366edf150095_5238 a b) ∨ (fact_366edf150095_5333 a b) ∨ (fact_366edf150095_3377 a b) ∨ (fact_366edf150095_3634 a b) ∨ (fact_366edf150095_3657 a b) ∨ (fact_366edf150095_3674 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (fact_366edf150095_3688 a b)))) ∨ ((fact_366edf150095_7390 a b) ∧ (fact_366edf150095_7351 a b) ∧ ((fact_366edf150095_4164 a b) ∨ (fact_366edf150095_3759 a b) ∨ (fact_366edf150095_5910 a b) ∨ (fact_366edf150095_5993 a b) ∨ (fact_366edf150095_3840 a b) ∨ (fact_366edf150095_4273 a b) ∨ (fact_366edf150095_4654 a b) ∨ (fact_366edf150095_4802 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (fact_366edf150095_4994 a b)) ∧ ((fact_366edf150095_3442 a b) ∨ (fact_366edf150095_3366 a b) ∨ (fact_366edf150095_5238 a b) ∨ (fact_366edf150095_5333 a b) ∨ (fact_366edf150095_3377 a b) ∨ (fact_366edf150095_3634 a b) ∨ (fact_366edf150095_3657 a b) ∨ (fact_366edf150095_3674 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) + a)) ∧ (((6 : Int) + a) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ (((4 : Int) ≤ ((6 : Int) + a)) ∧ ((4 : Int) ≥ ((6 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + a)))) ∨ (fact_366edf150095_3688 a b))))))
    (h1 : ((((2 : Int) * a) < ((5 : Int) - (0 : Int))) ∨ (((5 : Int) + a) < ((2 : Int) * a)) ∨ (((1 : Int) + a) < ((3 : Int) + b)) ∨ (((3 : Int) + b) < ((1 : Int) - (0 : Int)))))
    (h2 : (a > b))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n491_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : ((fact_366edf150095_2381 a b run_x) ∨ (fact_366edf150095_2347 a b run_x) ∨ (fact_366edf150095_3622 a b run_x) ∨ (fact_366edf150095_3623 a b run_x) ∨ (fact_366edf150095_2348 a b run_x) ∨ (fact_366edf150095_3045 a b run_x) ∨ (fact_366edf150095_3046 a b run_x) ∨ (fact_366edf150095_3047 a b run_x) ∨ ((((6 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((6 : Int) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ (6 : Int)) ∧ ((6 : Int) ≤ (4 : Int)) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ (fact_366edf150095_3050 a b run_x)))
    (h3 : (run_x ≤ a))
    (h4 : ((3 : Int) ≤ run_x))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n491_run_floor (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (run_x ≤ a))
    (h2 : ((3 : Int) ≤ run_x))
    (h3 : (¬ ((fact_366edf150095_3345 a b run_x) ∨ (fact_366edf150095_3294 a b run_x) ∨ (fact_366edf150095_5209 a b run_x) ∨ (fact_366edf150095_5219 a b run_x) ∨ (fact_366edf150095_3304 a b run_x) ∨ (fact_366edf150095_3524 a b run_x) ∨ (fact_366edf150095_3560 a b run_x) ∨ (fact_366edf150095_3572 a b run_x) ∨ (((((4 : Int) - (0 : Int)) ≤ ((6 : Int) - (1 : Int))) ∧ (((6 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((4 : Int) ≤ ((6 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((6 : Int) - (1 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a)))) ∨ (fact_366edf150095_3595 a b run_x))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n492_run_four (a b : Int)
    (h0 : (¬ ((2 : Int) ≤ ((1 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n492_run_short (a b : Int)
    (h0 : (¬ ((((1 : Int) + b) - (2 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n492_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n492_run_left (a b : Int)
    (h0 : (¬ (((((5 : Int) ≥ ((-1 : Int) - a)) ∧ ((5 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((5 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((5 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((5 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((5 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((5 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((5 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((5 : Int) ≥ ((2 : Int) * a)) ∧ ((5 : Int) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((5 : Int) ≥ ((2 : Int) - a)) ∧ ((5 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((3 : Int) - b)) ∧ ((5 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)) ∧ (((2 : Int) + b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((((2 : Int) + b) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n492_run_right (a b : Int)
    (h0 : (¬ (((((5 : Int) ≥ ((-1 : Int) - a)) ∧ ((5 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((-1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (-1 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((0 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (0 : Int)) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ (((1 : Int) + ((2 : Int) * a)) - a)) ∧ ((5 : Int) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((5 : Int) ≥ ((1 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ (((2 : Int) + ((2 : Int) * a)) - (0 : Int))) ∧ ((5 : Int) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((0 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((5 : Int) ≥ ((2 : Int) + ((2 : Int) * a))) ∧ ((5 : Int) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((5 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((1 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (1 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((5 : Int) ≥ (((2 : Int) * a) - b)) ∧ ((5 : Int) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((1 : Int) ≥ (((1 : Int) + b) + (1 : Int)))) ∨ (((5 : Int) ≥ ((2 : Int) * a)) ∧ ((5 : Int) ≤ ((2 : Int) * a)) ∧ (((1 : Int) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((5 : Int) ≥ ((2 : Int) - a)) ∧ ((5 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (2 : Int)) ∧ ((((2 : Int) + b) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((3 : Int) - b)) ∧ ((5 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)) ∧ (((2 : Int) + b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + b))) ∨ (((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((((2 : Int) + b) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n492_run_tall (a b : Int)
    (h0 : (¬ (((((2 : Int) + (3 : Int)) ≤ ((1 : Int) + b)) ∧ ((fact_366edf150095_7345 a b) ∨ (fact_366edf150095_7361 a b))) ∨ ((((2 : Int) + (2 : Int)) ≤ ((1 : Int) + b)) ∧ (fact_366edf150095_7345 a b) ∧ (fact_366edf150095_7361 a b)) ∨ (((2 : Int) + (4 : Int)) ≤ ((1 : Int) + b)) ∨ ((((1 : Int) + b) = ((2 : Int) + (1 : Int))) ∧ (fact_366edf150095_7345 a b) ∧ (fact_366edf150095_7361 a b) ∧ (((fact_366edf150095_4149 a b) ∨ (fact_366edf150095_3744 a b) ∨ (fact_366edf150095_5895 a b) ∨ (fact_366edf150095_5978 a b) ∨ (fact_366edf150095_3825 a b) ∨ (fact_366edf150095_4258 a b) ∨ (fact_366edf150095_4644 a b) ∨ (((((3 : Int) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4876 a b)) ∨ ((fact_366edf150095_5176 a b) ∨ (fact_366edf150095_4470 a b) ∨ (fact_366edf150095_6395 a b) ∨ (fact_366edf150095_6483 a b) ∨ (fact_366edf150095_4554 a b) ∨ (fact_366edf150095_5304 a b) ∨ (fact_366edf150095_5470 a b) ∨ (((((3 : Int) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5597 a b)))) ∨ ((fact_366edf150095_7345 a b) ∧ (fact_366edf150095_7361 a b) ∧ ((fact_366edf150095_4149 a b) ∨ (fact_366edf150095_3744 a b) ∨ (fact_366edf150095_5895 a b) ∨ (fact_366edf150095_5978 a b) ∨ (fact_366edf150095_3825 a b) ∨ (fact_366edf150095_4258 a b) ∨ (fact_366edf150095_4644 a b) ∨ (((((3 : Int) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4876 a b)) ∧ ((fact_366edf150095_5176 a b) ∨ (fact_366edf150095_4470 a b) ∨ (fact_366edf150095_6395 a b) ∨ (fact_366edf150095_6483 a b) ∨ (fact_366edf150095_4554 a b) ∨ (fact_366edf150095_5304 a b) ∨ (fact_366edf150095_5470 a b) ∨ (((((3 : Int) - b) ≤ ((5 : Int) + a)) ∧ (((5 : Int) + a) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) + a)) ∧ ((3 : Int) ≥ ((5 : Int) + a)) ∧ ((((2 : Int) + a) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_5597 a b))))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a > b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h6 : (a ≥ b))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    left
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n492_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((fact_366edf150095_2380 a b run_x) ∨ (fact_366edf150095_2344 a b run_x) ∨ (fact_366edf150095_3619 a b run_x) ∨ (fact_366edf150095_3620 a b run_x) ∨ (fact_366edf150095_2345 a b run_x) ∨ (fact_366edf150095_3040 a b run_x) ∨ (fact_366edf150095_3041 a b run_x) ∨ ((((5 : Int) ≥ ((3 : Int) - b)) ∧ ((5 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (3 : Int)) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ ((((5 : Int) ≥ ((4 : Int) - (0 : Int))) ∧ ((5 : Int) ≤ ((4 : Int) + a)) ∧ (((2 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b))) ∨ (((4 : Int) ≤ (5 : Int)) ∧ ((5 : Int) ≤ (4 : Int)) ∧ ((((2 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + b) + (0 : Int)))))))
    (h2 : (run_x ≤ ((1 : Int) + b)))
    (h3 : ((2 : Int) ≤ run_x))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n492_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3344 a b run_x) ∨ (fact_366edf150095_3293 a b run_x) ∨ (fact_366edf150095_5208 a b run_x) ∨ (fact_366edf150095_5218 a b run_x) ∨ (fact_366edf150095_3303 a b run_x) ∨ (fact_366edf150095_3523 a b run_x) ∨ (fact_366edf150095_3559 a b run_x) ∨ (((((3 : Int) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((2 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((2 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + a) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + a)) ∧ (((2 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((2 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((2 : Int) + b) + (0 : Int))))))))
    (h1 : (run_x ≤ ((1 : Int) + b)))
    (h2 : ((2 : Int) ≤ run_x))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n493_point (a b : Int)
    (h0 : (¬ (((3 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((3 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n493_empty (a b : Int)
    (h0 : ((fact_366edf150095_2892 a b) ∨ (fact_366edf150095_2569 a b) ∨ (fact_366edf150095_4056 a b) ∨ (fact_366edf150095_4057 a b) ∨ (fact_366edf150095_2570 a b) ∨ (fact_366edf150095_3165 a b) ∨ ((((3 : Int) ≥ ((2 : Int) - a)) ∧ ((3 : Int) ≤ ((2 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((2 : Int) + b)) ∧ ((3 : Int) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int)) ∧ ((3 : Int) ≥ (((2 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ ((((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a)) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n493_o0 (a b jx jy : Int)
    (h0 : (((jx + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h1 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < jy)))
    (h2 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h3 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n493_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h2 : (¬ ((((3 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h3 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n493_o2 (a b jx jy : Int)
    (h0 : (¬ ((((3 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - b))))
    (h3 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (fact_366edf150095_2954 a b jy))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n493_o3 (a b jx jy : Int)
    (h0 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < jy)))
    (h2 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (¬ (((jx = ((3 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n493_o4 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (¬ ((((3 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n493_o5 (a b jx jy : Int)
    (h0 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((3 : Int) + a)) ∨ (((3 : Int) + a) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h3 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h4 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n493_o6 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : (¬ ((((3 : Int) = jx) ∧ ((3 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h6 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < jy)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n493_o7 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (¬ ((((3 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h2 : (((jx + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_366edf150095_2955 a b jy))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n494_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((4 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n494_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((fact_366edf150095_2902 a b) ∨ (fact_366edf150095_2571 a b) ∨ (fact_366edf150095_4058 a b) ∨ (fact_366edf150095_4061 a b) ∨ (fact_366edf150095_2573 a b) ∨ (fact_366edf150095_3172 a b) ∨ (fact_366edf150095_3177 a b) ∨ (fact_366edf150095_3174 a b) ∨ ((((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int)))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n494_o0 (a b jx jy : Int)
    (h0 : (((jx + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n494_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((jx + b) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) + a)) ∨ (((3 : Int) + a) < jy)))
    (h4 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n494_o2 (a b jx jy : Int)
    (h0 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - b))))
    (h1 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : (fact_366edf150095_2954 a b jy))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n494_o3 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h2 : (¬ (((jx = ((4 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n494_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n494_o5 (a b jx jy : Int)
    (h0 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((jx + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h5 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n494_o6 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < jx) ∨ ((jy + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n494_o7 (a b jx jy : Int)
    (h0 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (((jx + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h3 : (¬ ((((4 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h4 : (fact_366edf150095_2955 a b jy))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n495_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)))))
    (h1 : ((((2 : Int) * a) < (((4 : Int) + b) - b)) ∨ ((((4 : Int) + b) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n495_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (4 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n495_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n495_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3500 a b) ∨ (fact_366edf150095_3449 a b) ∨ (fact_366edf150095_5776 a b) ∨ (fact_366edf150095_5784 a b) ∨ (fact_366edf150095_3457 a b) ∨ (fact_366edf150095_3695 a b) ∨ (fact_366edf150095_3915 a b) ∨ (fact_366edf150095_3703 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3705 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n495_run_right (a b : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (¬ ((fact_366edf150095_6962 a b) ∨ (fact_366edf150095_6950 a b) ∨ (fact_366edf150095_7267 a b) ∨ (fact_366edf150095_7269 a b) ∨ (fact_366edf150095_6952 a b) ∨ (fact_366edf150095_7008 a b) ∨ (fact_366edf150095_7038 a b) ∨ (fact_366edf150095_7018 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (fact_366edf150095_2534 a b)) ∨ (fact_366edf150095_7019 a b))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n495_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) ∧ ((fact_366edf150095_7396 a b) ∨ (fact_366edf150095_7750 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) ∧ (fact_366edf150095_7396 a b) ∧ (fact_366edf150095_7750 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) ∨ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) = ((4 : Int) + (1 : Int))) ∧ (fact_366edf150095_7396 a b) ∧ (fact_366edf150095_7750 a b) ∧ (((fact_366edf150095_4144 a b) ∨ (fact_366edf150095_3739 a b) ∨ (fact_366edf150095_5890 a b) ∨ (fact_366edf150095_5973 a b) ∨ (fact_366edf150095_3820 a b) ∨ (fact_366edf150095_4253 a b) ∨ (fact_366edf150095_4641 a b) ∨ (fact_366edf150095_4327 a b) ∨ (fact_366edf150095_4739 a b) ∨ (fact_366edf150095_4376 a b)) ∨ ((fact_366edf150095_7056 a b) ∨ (fact_366edf150095_7025 a b) ∨ (fact_366edf150095_7289 a b) ∨ (fact_366edf150095_7294 a b) ∨ (fact_366edf150095_7030 a b) ∨ (fact_366edf150095_7184 a b) ∨ (fact_366edf150095_7206 a b) ∨ (fact_366edf150095_7189 a b) ∨ (fact_366edf150095_7214 a b) ∨ (fact_366edf150095_7200 a b)))) ∨ ((fact_366edf150095_7396 a b) ∧ (fact_366edf150095_7750 a b) ∧ ((fact_366edf150095_4144 a b) ∨ (fact_366edf150095_3739 a b) ∨ (fact_366edf150095_5890 a b) ∨ (fact_366edf150095_5973 a b) ∨ (fact_366edf150095_3820 a b) ∨ (fact_366edf150095_4253 a b) ∨ (fact_366edf150095_4641 a b) ∨ (fact_366edf150095_4327 a b) ∨ (fact_366edf150095_4739 a b) ∨ (fact_366edf150095_4376 a b)) ∧ ((fact_366edf150095_7056 a b) ∨ (fact_366edf150095_7025 a b) ∨ (fact_366edf150095_7289 a b) ∨ (fact_366edf150095_7294 a b) ∨ (fact_366edf150095_7030 a b) ∨ (fact_366edf150095_7184 a b) ∨ (fact_366edf150095_7206 a b) ∨ (fact_366edf150095_7189 a b) ∨ (fact_366edf150095_7214 a b) ∨ (fact_366edf150095_7200 a b))))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    left
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n495_run_empty (a b run_x : Int)
    (h0 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((fact_366edf150095_2376 a b run_x) ∨ (fact_366edf150095_2311 a b run_x) ∨ (fact_366edf150095_3519 a b run_x) ∨ (fact_366edf150095_3534 a b run_x) ∨ (fact_366edf150095_2316 a b run_x) ∨ (fact_366edf150095_2958 a b run_x) ∨ (fact_366edf150095_2985 a b run_x) ∨ (fact_366edf150095_2963 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≥ ((3 : Int) + a)) ∧ ((4 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((4 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_2969 a b run_x)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((4 : Int) ≤ run_x))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n495_run_floor (a b run_x : Int)
    (h0 : ((4 : Int) ≤ run_x))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (¬ ((fact_366edf150095_3350 a b run_x) ∨ (fact_366edf150095_3299 a b run_x) ∨ (fact_366edf150095_5214 a b run_x) ∨ (fact_366edf150095_5224 a b run_x) ∨ (fact_366edf150095_3309 a b run_x) ∨ (fact_366edf150095_3529 a b run_x) ∨ (fact_366edf150095_3565 a b run_x) ∨ (fact_366edf150095_3543 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ (((3 : Int) + a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((((3 : Int) + a) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3549 a b run_x))))
    (h3 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n496_run_four (a b : Int)
    (h0 : (¬ ((5 : Int) ≤ ((2 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n496_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + a) - (5 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n496_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n496_run_left (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_366edf150095_3502 a b) ∨ (fact_366edf150095_3451 a b) ∨ (fact_366edf150095_5778 a b) ∨ (fact_366edf150095_5786 a b) ∨ (fact_366edf150095_3459 a b) ∨ (fact_366edf150095_3697 a b) ∨ (fact_366edf150095_3916 a b) ∨ (fact_366edf150095_3704 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3982 a b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n496_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4117 a b) ∨ (fact_366edf150095_3712 a b) ∨ (fact_366edf150095_5863 a b) ∨ (fact_366edf150095_5946 a b) ∨ (fact_366edf150095_3793 a b) ∨ (fact_366edf150095_4226 a b) ∨ (fact_366edf150095_4631 a b) ∨ (fact_366edf150095_4319 a b) ∨ (((((3 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_4837 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n496_run_tall (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((((5 : Int) + (3 : Int)) ≤ ((2 : Int) + a)) ∧ ((fact_366edf150095_7407 a b) ∨ (fact_366edf150095_7447 a b))) ∨ ((((5 : Int) + (2 : Int)) ≤ ((2 : Int) + a)) ∧ (fact_366edf150095_7407 a b) ∧ (fact_366edf150095_7447 a b)) ∨ (((5 : Int) + (4 : Int)) ≤ ((2 : Int) + a)) ∨ ((((2 : Int) + a) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7407 a b) ∧ (fact_366edf150095_7447 a b) ∧ (((fact_366edf150095_4156 a b) ∨ (fact_366edf150095_3751 a b) ∨ (fact_366edf150095_5902 a b) ∨ (fact_366edf150095_5985 a b) ∨ (fact_366edf150095_3832 a b) ∨ (fact_366edf150095_4265 a b) ∨ (fact_366edf150095_4648 a b) ∨ (fact_366edf150095_4335 a b) ∨ (fact_366edf150095_4754 a b) ∨ (fact_366edf150095_4883 a b)) ∨ ((fact_366edf150095_5118 a b) ∨ (fact_366edf150095_4412 a b) ∨ (fact_366edf150095_6337 a b) ∨ (fact_366edf150095_6425 a b) ∨ (fact_366edf150095_4496 a b) ∨ (fact_366edf150095_5246 a b) ∨ (fact_366edf150095_5432 a b) ∨ (fact_366edf150095_5345 a b) ∨ (fact_366edf150095_5498 a b) ∨ (fact_366edf150095_5569 a b)))) ∨ ((fact_366edf150095_7407 a b) ∧ (fact_366edf150095_7447 a b) ∧ ((fact_366edf150095_4156 a b) ∨ (fact_366edf150095_3751 a b) ∨ (fact_366edf150095_5902 a b) ∨ (fact_366edf150095_5985 a b) ∨ (fact_366edf150095_3832 a b) ∨ (fact_366edf150095_4265 a b) ∨ (fact_366edf150095_4648 a b) ∨ (fact_366edf150095_4335 a b) ∨ (fact_366edf150095_4754 a b) ∨ (fact_366edf150095_4883 a b)) ∧ ((fact_366edf150095_5118 a b) ∨ (fact_366edf150095_4412 a b) ∨ (fact_366edf150095_6337 a b) ∨ (fact_366edf150095_6425 a b) ∨ (fact_366edf150095_4496 a b) ∨ (fact_366edf150095_5246 a b) ∨ (fact_366edf150095_5432 a b) ∨ (fact_366edf150095_5345 a b) ∨ (fact_366edf150095_5498 a b) ∨ (fact_366edf150095_5569 a b))))))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n496_run_empty (a b run_x : Int)
    (h0 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2984 a b run_x) ∨ (fact_366edf150095_2962 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3003 a b run_x)))
    (h1 : ((5 : Int) ≤ run_x))
    (h2 : (run_x ≤ ((2 : Int) + a)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n496_run_floor (a b run_x : Int)
    (h0 : ((5 : Int) ≤ run_x))
    (h1 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3564 a b run_x) ∨ (fact_366edf150095_3542 a b run_x) ∨ (((((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ (((3 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((((3 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))) ∨ (fact_366edf150095_3585 a b run_x))))
    (h2 : (run_x ≤ ((2 : Int) + a)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n497_point (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((4 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n497_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((fact_366edf150095_2902 a b) ∨ (fact_366edf150095_2571 a b) ∨ (fact_366edf150095_4058 a b) ∨ (fact_366edf150095_4061 a b) ∨ (fact_366edf150095_2573 a b) ∨ (fact_366edf150095_3172 a b) ∨ (fact_366edf150095_3177 a b) ∨ (fact_366edf150095_3174 a b) ∨ ((((4 : Int) ≥ ((3 : Int) - a)) ∧ ((4 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (0 : Int)))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n497_o0 (a b jx jy : Int)
    (h0 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h3 : (((jx + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((3 : Int) > (jx + a)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + b) - b)) ∨ ((((3 : Int) + b) + (0 : Int)) < jy)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n497_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (¬ ((((4 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h2 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n497_o2 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (fact_366edf150095_2954 a b jy))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + b) - b)) ∨ ((((3 : Int) + b) + (0 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n497_o3 (a b jx jy : Int)
    (h0 : (¬ (((jx = ((4 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + b) - b)) ∨ ((((3 : Int) + b) + (0 : Int)) < jy)))
    (h2 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h3 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n497_o4 (a b jx jy : Int)
    (h0 : (¬ ((((4 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n497_o5 (a b jx jy : Int)
    (h0 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < jy)))
    (h3 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h4 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (((jx + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n497_o6 (a b jx jy : Int)
    (h0 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h1 : (¬ ((((4 : Int) = jx) ∧ ((3 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + b) - b)) ∨ ((((3 : Int) + b) + (0 : Int)) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n497_o7 (a b jx jy : Int)
    (h0 : ((jy - b) ≥ (0 : Int)))
    (h1 : (fact_366edf150095_2955 a b jy))
    (h2 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (¬ ((((4 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((jx + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n498_run_four (a b : Int)
    (h0 : (¬ ((5 : Int) ≤ ((2 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n498_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((2 : Int) + a) - (5 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n498_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n498_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3502 a b) ∨ (fact_366edf150095_3451 a b) ∨ (fact_366edf150095_5778 a b) ∨ (fact_366edf150095_5786 a b) ∨ (fact_366edf150095_3459 a b) ∨ (fact_366edf150095_3697 a b) ∨ (fact_366edf150095_3916 a b) ∨ (fact_366edf150095_3704 a b) ∨ (((((3 : Int) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n498_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4117 a b) ∨ (fact_366edf150095_3712 a b) ∨ (fact_366edf150095_5863 a b) ∨ (fact_366edf150095_5946 a b) ∨ (fact_366edf150095_3793 a b) ∨ (fact_366edf150095_4226 a b) ∨ (fact_366edf150095_4631 a b) ∨ (fact_366edf150095_4319 a b) ∨ (((((3 : Int) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int))))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n498_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((((5 : Int) + (3 : Int)) ≤ ((2 : Int) + a)) ∧ ((fact_366edf150095_7409 a b) ∨ (fact_366edf150095_7449 a b))) ∨ ((((5 : Int) + (2 : Int)) ≤ ((2 : Int) + a)) ∧ (fact_366edf150095_7409 a b) ∧ (fact_366edf150095_7449 a b)) ∨ (((5 : Int) + (4 : Int)) ≤ ((2 : Int) + a)) ∨ ((((2 : Int) + a) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7409 a b) ∧ (fact_366edf150095_7449 a b) ∧ (((fact_366edf150095_4156 a b) ∨ (fact_366edf150095_3751 a b) ∨ (fact_366edf150095_5902 a b) ∨ (fact_366edf150095_5985 a b) ∨ (fact_366edf150095_3832 a b) ∨ (fact_366edf150095_4265 a b) ∨ (fact_366edf150095_4648 a b) ∨ (fact_366edf150095_4335 a b) ∨ (fact_366edf150095_4771 a b) ∨ (fact_366edf150095_4888 a b)) ∨ ((fact_366edf150095_5118 a b) ∨ (fact_366edf150095_4412 a b) ∨ (fact_366edf150095_6337 a b) ∨ (fact_366edf150095_6425 a b) ∨ (fact_366edf150095_4496 a b) ∨ (fact_366edf150095_5246 a b) ∨ (fact_366edf150095_5432 a b) ∨ (fact_366edf150095_5345 a b) ∨ (fact_366edf150095_5510 a b) ∨ (fact_366edf150095_5573 a b)))) ∨ ((fact_366edf150095_7409 a b) ∧ (fact_366edf150095_7449 a b) ∧ ((fact_366edf150095_4156 a b) ∨ (fact_366edf150095_3751 a b) ∨ (fact_366edf150095_5902 a b) ∨ (fact_366edf150095_5985 a b) ∨ (fact_366edf150095_3832 a b) ∨ (fact_366edf150095_4265 a b) ∨ (fact_366edf150095_4648 a b) ∨ (fact_366edf150095_4335 a b) ∨ (fact_366edf150095_4771 a b) ∨ (fact_366edf150095_4888 a b)) ∧ ((fact_366edf150095_5118 a b) ∨ (fact_366edf150095_4412 a b) ∨ (fact_366edf150095_6337 a b) ∨ (fact_366edf150095_6425 a b) ∨ (fact_366edf150095_4496 a b) ∨ (fact_366edf150095_5246 a b) ∨ (fact_366edf150095_5432 a b) ∨ (fact_366edf150095_5345 a b) ∨ (fact_366edf150095_5510 a b) ∨ (fact_366edf150095_5573 a b))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (a ≥ b))
    (h5 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n498_run_empty (a b run_x : Int)
    (h0 : (run_x ≤ ((2 : Int) + a)))
    (h1 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2984 a b run_x) ∨ (fact_366edf150095_2962 a b run_x) ∨ (((((3 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((3 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_3004 a b run_x)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((5 : Int) ≤ run_x))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n498_run_floor (a b run_x : Int)
    (h0 : ((5 : Int) ≤ run_x))
    (h1 : (run_x ≤ ((2 : Int) + a)))
    (h2 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3564 a b run_x) ∨ (fact_366edf150095_3542 a b run_x) ∨ (((((3 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((((3 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_3586 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n499_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((2 : Int) * a) < (((4 : Int) + b) - b)) ∨ ((((4 : Int) + b) + (0 : Int)) < ((2 : Int) * a)) ∨ ((3 : Int) > ((1 : Int) + a)) ∨ ((3 : Int) < ((1 : Int) - (0 : Int)))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a = (b + (2 : Int))))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n499_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) - (4 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n499_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n499_run_left (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_366edf150095_3500 a b) ∨ (fact_366edf150095_3449 a b) ∨ (fact_366edf150095_5776 a b) ∨ (fact_366edf150095_5784 a b) ∨ (fact_366edf150095_3457 a b) ∨ (fact_366edf150095_3695 a b) ∨ (fact_366edf150095_3915 a b) ∨ (fact_366edf150095_3703 a b) ∨ (((((3 : Int) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_3705 a b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n499_run_right (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((fact_366edf150095_6962 a b) ∨ (fact_366edf150095_6950 a b) ∨ (fact_366edf150095_7267 a b) ∨ (fact_366edf150095_7269 a b) ∨ (fact_366edf150095_6952 a b) ∨ (fact_366edf150095_7008 a b) ∨ (fact_366edf150095_7038 a b) ∨ (fact_366edf150095_7018 a b) ∨ (((((3 : Int) - a) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_7019 a b))))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n499_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) ∧ ((fact_366edf150095_7397 a b) ∨ (fact_366edf150095_7751 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) ∧ (fact_366edf150095_7397 a b) ∧ (fact_366edf150095_7751 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))) ∨ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) = ((4 : Int) + (1 : Int))) ∧ (fact_366edf150095_7397 a b) ∧ (fact_366edf150095_7751 a b) ∧ (((fact_366edf150095_4144 a b) ∨ (fact_366edf150095_3739 a b) ∨ (fact_366edf150095_5890 a b) ∨ (fact_366edf150095_5973 a b) ∨ (fact_366edf150095_3820 a b) ∨ (fact_366edf150095_4253 a b) ∨ (fact_366edf150095_4641 a b) ∨ (fact_366edf150095_4327 a b) ∨ (((((3 : Int) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_4376 a b)) ∨ ((fact_366edf150095_7056 a b) ∨ (fact_366edf150095_7025 a b) ∨ (fact_366edf150095_7289 a b) ∨ (fact_366edf150095_7294 a b) ∨ (fact_366edf150095_7030 a b) ∨ (fact_366edf150095_7184 a b) ∨ (fact_366edf150095_7206 a b) ∨ (fact_366edf150095_7189 a b) ∨ (((((3 : Int) - a) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_7200 a b)))) ∨ ((fact_366edf150095_7397 a b) ∧ (fact_366edf150095_7751 a b) ∧ ((fact_366edf150095_4144 a b) ∨ (fact_366edf150095_3739 a b) ∨ (fact_366edf150095_5890 a b) ∨ (fact_366edf150095_5973 a b) ∨ (fact_366edf150095_3820 a b) ∨ (fact_366edf150095_4253 a b) ∨ (fact_366edf150095_4641 a b) ∨ (fact_366edf150095_4327 a b) ∨ (((((3 : Int) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_4376 a b)) ∧ ((fact_366edf150095_7056 a b) ∨ (fact_366edf150095_7025 a b) ∨ (fact_366edf150095_7289 a b) ∨ (fact_366edf150095_7294 a b) ∨ (fact_366edf150095_7030 a b) ∨ (fact_366edf150095_7184 a b) ∨ (fact_366edf150095_7206 a b) ∨ (fact_366edf150095_7189 a b) ∨ (((((3 : Int) - a) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≤ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((3 : Int) ≥ (((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b)) + (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_7200 a b))))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h7 : (a ≥ b))
    : False := by
  apply h5
  clear h5
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n499_run_empty (a b run_x : Int)
    (h0 : ((fact_366edf150095_2376 a b run_x) ∨ (fact_366edf150095_2311 a b run_x) ∨ (fact_366edf150095_3519 a b run_x) ∨ (fact_366edf150095_3534 a b run_x) ∨ (fact_366edf150095_2316 a b run_x) ∨ (fact_366edf150095_2958 a b run_x) ∨ (fact_366edf150095_2985 a b run_x) ∨ (fact_366edf150095_2963 a b run_x) ∨ (((((3 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((4 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_2969 a b run_x)))
    (h1 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : ((4 : Int) ≤ run_x))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n499_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3350 a b run_x) ∨ (fact_366edf150095_3299 a b run_x) ∨ (fact_366edf150095_5214 a b run_x) ∨ (fact_366edf150095_5224 a b run_x) ∨ (fact_366edf150095_3309 a b run_x) ∨ (fact_366edf150095_3529 a b run_x) ∨ (fact_366edf150095_3565 a b run_x) ∨ (fact_366edf150095_3543 a b run_x) ∨ (((((3 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((((3 : Int) + b) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_3549 a b run_x))))
    (h1 : ((4 : Int) ≤ run_x))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (run_x ≤ ((-1 : Int) + ((2 : Int) * a) + ((-1 : Int) * b))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n500_run_four (a b : Int)
    (h0 : (¬ ((5 : Int) ≤ ((2 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n500_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + a) - (5 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n500_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n500_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_366edf150095_3502 a b) ∨ (fact_366edf150095_3451 a b) ∨ (fact_366edf150095_5778 a b) ∨ (fact_366edf150095_5786 a b) ∨ (fact_366edf150095_3459 a b) ∨ (fact_366edf150095_3697 a b) ∨ (fact_366edf150095_3916 a b) ∨ (fact_366edf150095_3704 a b) ∨ (((((3 : Int) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (((((4 : Int) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int))))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n500_run_right (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_366edf150095_4117 a b) ∨ (fact_366edf150095_3712 a b) ∨ (fact_366edf150095_5863 a b) ∨ (fact_366edf150095_5946 a b) ∨ (fact_366edf150095_3793 a b) ∨ (fact_366edf150095_4226 a b) ∨ (fact_366edf150095_4631 a b) ∨ (fact_366edf150095_4319 a b) ∨ (((((3 : Int) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (((((4 : Int) - b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int))))))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n500_run_tall (a b : Int)
    (h0 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h4 : (¬ (((((5 : Int) + (3 : Int)) ≤ ((2 : Int) + a)) ∧ ((fact_366edf150095_7410 a b) ∨ (fact_366edf150095_7450 a b))) ∨ ((((5 : Int) + (2 : Int)) ≤ ((2 : Int) + a)) ∧ (fact_366edf150095_7410 a b) ∧ (fact_366edf150095_7450 a b)) ∨ (((5 : Int) + (4 : Int)) ≤ ((2 : Int) + a)) ∨ ((((2 : Int) + a) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7410 a b) ∧ (fact_366edf150095_7450 a b) ∧ (((fact_366edf150095_4156 a b) ∨ (fact_366edf150095_3751 a b) ∨ (fact_366edf150095_5902 a b) ∨ (fact_366edf150095_5985 a b) ∨ (fact_366edf150095_3832 a b) ∨ (fact_366edf150095_4265 a b) ∨ (fact_366edf150095_4648 a b) ∨ (fact_366edf150095_4335 a b) ∨ (fact_366edf150095_4771 a b) ∨ (((((4 : Int) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int)))))) ∨ ((fact_366edf150095_5118 a b) ∨ (fact_366edf150095_4412 a b) ∨ (fact_366edf150095_6337 a b) ∨ (fact_366edf150095_6425 a b) ∨ (fact_366edf150095_4496 a b) ∨ (fact_366edf150095_5246 a b) ∨ (fact_366edf150095_5432 a b) ∨ (fact_366edf150095_5345 a b) ∨ (fact_366edf150095_5510 a b) ∨ (((((4 : Int) - b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int)))))))) ∨ ((fact_366edf150095_7410 a b) ∧ (fact_366edf150095_7450 a b) ∧ ((fact_366edf150095_4156 a b) ∨ (fact_366edf150095_3751 a b) ∨ (fact_366edf150095_5902 a b) ∨ (fact_366edf150095_5985 a b) ∨ (fact_366edf150095_3832 a b) ∨ (fact_366edf150095_4265 a b) ∨ (fact_366edf150095_4648 a b) ∨ (fact_366edf150095_4335 a b) ∨ (fact_366edf150095_4771 a b) ∨ (((((4 : Int) - b) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int)))))) ∧ ((fact_366edf150095_5118 a b) ∨ (fact_366edf150095_4412 a b) ∨ (fact_366edf150095_6337 a b) ∨ (fact_366edf150095_6425 a b) ∨ (fact_366edf150095_4496 a b) ∨ (fact_366edf150095_5246 a b) ∨ (fact_366edf150095_5432 a b) ∨ (fact_366edf150095_5345 a b) ∨ (fact_366edf150095_5510 a b) ∨ (((((4 : Int) - b) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((3 : Int) + a) + (0 : Int))))))))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  apply h4
  clear h4
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n500_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((5 : Int) ≤ run_x))
    (h2 : (run_x ≤ ((2 : Int) + a)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2984 a b run_x) ∨ (fact_366edf150095_2962 a b run_x) ∨ (((((3 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((3 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (((((4 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int)))))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n500_run_floor (a b run_x : Int)
    (h0 : ((5 : Int) ≤ run_x))
    (h1 : (run_x ≤ ((2 : Int) + a)))
    (h2 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3564 a b run_x) ∨ (fact_366edf150095_3542 a b run_x) ∨ (((((3 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((((3 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (((((4 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + (0 : Int))) ∧ (((3 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((((3 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))))))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n501_run_four (a b : Int)
    (h0 : (¬ ((5 : Int) ≤ ((2 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n501_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((2 : Int) + a) - (5 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n501_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n501_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3503 a b) ∨ (fact_366edf150095_3452 a b) ∨ (fact_366edf150095_5779 a b) ∨ (fact_366edf150095_5787 a b) ∨ (fact_366edf150095_3460 a b) ∨ (fact_366edf150095_3698 a b) ∨ (fact_366edf150095_3917 a b) ∨ ((((((3 : Int) + a) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (((((3 : Int) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n501_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4118 a b) ∨ (fact_366edf150095_3713 a b) ∨ (fact_366edf150095_5864 a b) ∨ (fact_366edf150095_5947 a b) ∨ (fact_366edf150095_3794 a b) ∨ (fact_366edf150095_4227 a b) ∨ (((((2 : Int) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) + b)) ∧ ((4 : Int) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((2 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ ((((((3 : Int) + a) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (((((3 : Int) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n501_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h4 : (¬ (((((5 : Int) + (3 : Int)) ≤ ((2 : Int) + a)) ∧ ((fact_366edf150095_7379 a b) ∨ (fact_366edf150095_7434 a b))) ∨ ((((5 : Int) + (2 : Int)) ≤ ((2 : Int) + a)) ∧ (fact_366edf150095_7379 a b) ∧ (fact_366edf150095_7434 a b)) ∨ (((5 : Int) + (4 : Int)) ≤ ((2 : Int) + a)) ∨ ((((2 : Int) + a) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7379 a b) ∧ (fact_366edf150095_7434 a b) ∧ (((fact_366edf150095_4158 a b) ∨ (fact_366edf150095_3753 a b) ∨ (fact_366edf150095_5904 a b) ∨ (fact_366edf150095_5987 a b) ∨ (fact_366edf150095_3834 a b) ∨ (fact_366edf150095_4267 a b) ∨ (fact_366edf150095_4650 a b) ∨ (fact_366edf150095_4337 a b) ∨ (((((3 : Int) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_3984 a b)) ∨ ((fact_366edf150095_5120 a b) ∨ (fact_366edf150095_4414 a b) ∨ (fact_366edf150095_6339 a b) ∨ (fact_366edf150095_6427 a b) ∨ (fact_366edf150095_4498 a b) ∨ (fact_366edf150095_5248 a b) ∨ (fact_366edf150095_5434 a b) ∨ (fact_366edf150095_5347 a b) ∨ (((((3 : Int) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_4838 a b)))) ∨ ((fact_366edf150095_7379 a b) ∧ (fact_366edf150095_7434 a b) ∧ ((fact_366edf150095_4158 a b) ∨ (fact_366edf150095_3753 a b) ∨ (fact_366edf150095_5904 a b) ∨ (fact_366edf150095_5987 a b) ∨ (fact_366edf150095_3834 a b) ∨ (fact_366edf150095_4267 a b) ∨ (fact_366edf150095_4650 a b) ∨ (fact_366edf150095_4337 a b) ∨ (((((3 : Int) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_3984 a b)) ∧ ((fact_366edf150095_5120 a b) ∨ (fact_366edf150095_4414 a b) ∨ (fact_366edf150095_6339 a b) ∨ (fact_366edf150095_6427 a b) ∨ (fact_366edf150095_4498 a b) ∨ (fact_366edf150095_5248 a b) ∨ (fact_366edf150095_5434 a b) ∨ (fact_366edf150095_5347 a b) ∨ (((((3 : Int) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_4838 a b))))))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (a ≥ b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  apply h4
  clear h4
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n501_run_empty (a b run_x : Int)
    (h0 : ((5 : Int) ≤ run_x))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((fact_366edf150095_2376 a b run_x) ∨ (fact_366edf150095_2311 a b run_x) ∨ (fact_366edf150095_3519 a b run_x) ∨ (fact_366edf150095_3534 a b run_x) ∨ (fact_366edf150095_2316 a b run_x) ∨ (fact_366edf150095_2958 a b run_x) ∨ (fact_366edf150095_2985 a b run_x) ∨ (fact_366edf150095_2963 a b run_x) ∨ (((((3 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((3 : Int) + b)) ∧ ((4 : Int) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((4 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a))))))
    (h4 : (run_x ≤ ((2 : Int) + a)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n501_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((2 : Int) + a)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : ((5 : Int) ≤ run_x))
    (h3 : (¬ ((fact_366edf150095_3350 a b run_x) ∨ (fact_366edf150095_3299 a b run_x) ∨ (fact_366edf150095_5214 a b run_x) ∨ (fact_366edf150095_5224 a b run_x) ∨ (fact_366edf150095_3309 a b run_x) ∨ (fact_366edf150095_3529 a b run_x) ∨ (fact_366edf150095_3565 a b run_x) ∨ (fact_366edf150095_3543 a b run_x) ∨ (((((3 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((((3 : Int) + b) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (((((4 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ (((4 : Int) ≤ run_x) ∧ ((4 : Int) ≥ run_x) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a)))))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h3
  clear h3
  right
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n502_run_four (a b : Int)
    (h0 : (¬ ((5 : Int) ≤ ((2 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n502_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((2 : Int) + a) - (5 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n502_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n502_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3502 a b) ∨ (fact_366edf150095_3451 a b) ∨ (fact_366edf150095_5778 a b) ∨ (fact_366edf150095_5786 a b) ∨ (fact_366edf150095_3459 a b) ∨ (fact_366edf150095_3697 a b) ∨ (fact_366edf150095_3916 a b) ∨ (fact_366edf150095_3704 a b) ∨ (((((3 : Int) - a) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_3982 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n502_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4117 a b) ∨ (fact_366edf150095_3712 a b) ∨ (fact_366edf150095_5863 a b) ∨ (fact_366edf150095_5946 a b) ∨ (fact_366edf150095_3793 a b) ∨ (fact_366edf150095_4226 a b) ∨ (fact_366edf150095_4631 a b) ∨ (fact_366edf150095_4319 a b) ∨ (((((3 : Int) - a) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((3 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_4837 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n502_run_tall (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((((5 : Int) + (3 : Int)) ≤ ((2 : Int) + a)) ∧ ((fact_366edf150095_7408 a b) ∨ (fact_366edf150095_7448 a b))) ∨ ((((5 : Int) + (2 : Int)) ≤ ((2 : Int) + a)) ∧ (fact_366edf150095_7408 a b) ∧ (fact_366edf150095_7448 a b)) ∨ (((5 : Int) + (4 : Int)) ≤ ((2 : Int) + a)) ∨ ((((2 : Int) + a) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7408 a b) ∧ (fact_366edf150095_7448 a b) ∧ (((fact_366edf150095_4156 a b) ∨ (fact_366edf150095_3751 a b) ∨ (fact_366edf150095_5902 a b) ∨ (fact_366edf150095_5985 a b) ∨ (fact_366edf150095_3832 a b) ∨ (fact_366edf150095_4265 a b) ∨ (fact_366edf150095_4648 a b) ∨ (fact_366edf150095_4335 a b) ∨ (fact_366edf150095_4771 a b) ∨ (fact_366edf150095_4883 a b)) ∨ ((fact_366edf150095_5118 a b) ∨ (fact_366edf150095_4412 a b) ∨ (fact_366edf150095_6337 a b) ∨ (fact_366edf150095_6425 a b) ∨ (fact_366edf150095_4496 a b) ∨ (fact_366edf150095_5246 a b) ∨ (fact_366edf150095_5432 a b) ∨ (fact_366edf150095_5345 a b) ∨ (fact_366edf150095_5510 a b) ∨ (fact_366edf150095_5569 a b)))) ∨ ((fact_366edf150095_7408 a b) ∧ (fact_366edf150095_7448 a b) ∧ ((fact_366edf150095_4156 a b) ∨ (fact_366edf150095_3751 a b) ∨ (fact_366edf150095_5902 a b) ∨ (fact_366edf150095_5985 a b) ∨ (fact_366edf150095_3832 a b) ∨ (fact_366edf150095_4265 a b) ∨ (fact_366edf150095_4648 a b) ∨ (fact_366edf150095_4335 a b) ∨ (fact_366edf150095_4771 a b) ∨ (fact_366edf150095_4883 a b)) ∧ ((fact_366edf150095_5118 a b) ∨ (fact_366edf150095_4412 a b) ∨ (fact_366edf150095_6337 a b) ∨ (fact_366edf150095_6425 a b) ∨ (fact_366edf150095_4496 a b) ∨ (fact_366edf150095_5246 a b) ∨ (fact_366edf150095_5432 a b) ∨ (fact_366edf150095_5345 a b) ∨ (fact_366edf150095_5510 a b) ∨ (fact_366edf150095_5569 a b))))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    left
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n502_run_empty (a b run_x : Int)
    (h0 : ((5 : Int) ≤ run_x))
    (h1 : (run_x ≤ ((2 : Int) + a)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2984 a b run_x) ∨ (fact_366edf150095_2962 a b run_x) ∨ (((((3 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((3 : Int) ≥ (((3 : Int) + b) - b)) ∧ ((3 : Int) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_3003 a b run_x)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n502_run_floor (a b run_x : Int)
    (h0 : ((5 : Int) ≤ run_x))
    (h1 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3564 a b run_x) ∨ (fact_366edf150095_3542 a b run_x) ∨ (((((3 : Int) - a) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x) ∧ ((((3 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_3585 a b run_x))))
    (h2 : (run_x ≤ ((2 : Int) + a)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n503_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≤ a)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n503_run_short (a b : Int)
    (h0 : (¬ ((a - (3 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n503_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n503_run_left (a b : Int)
    (h0 : (¬ ((((((-1 : Int) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((-1 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) + b)) ∧ ((4 : Int) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ ((((((3 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ ((((((3 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n503_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (¬ ((((((-1 : Int) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (a + (1 : Int))) ∧ ((-1 : Int) ≥ (a + (1 : Int))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ (((((0 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((0 : Int) + a)) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (a + (1 : Int))) ∧ ((0 : Int) ≥ (a + (1 : Int))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((1 : Int) + ((2 : Int) * a)) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((1 : Int) + ((2 : Int) * a)) + (0 : Int))) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + ((2 : Int) * a)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * a)) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * a)) + a)) ∧ ((0 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (0 : Int))) ∨ ((((2 : Int) + ((2 : Int) * a)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * a))) ∧ ((4 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((0 : Int) + b)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + a)) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ ((((((2 : Int) * a) - b) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((2 : Int) * a) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) * a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) * a)) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + a)))) ∨ (((((2 : Int) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((2 : Int) + b)) ∧ ((4 : Int) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + b) - b)) ∧ ((4 : Int) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ ((((((3 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((3 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ ((((3 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + a)) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ ((((((3 : Int) + b) - b) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + b) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a)))))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n503_run_tall (a b : Int)
    (h0 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_366edf150095_7339 a b) ∨ (fact_366edf150095_7316 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_366edf150095_7339 a b) ∧ (fact_366edf150095_7316 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_366edf150095_7339 a b) ∧ (fact_366edf150095_7316 a b) ∧ (((fact_366edf150095_4136 a b) ∨ (fact_366edf150095_3731 a b) ∨ (fact_366edf150095_5882 a b) ∨ (fact_366edf150095_5965 a b) ∨ (fact_366edf150095_3812 a b) ∨ (fact_366edf150095_4245 a b) ∨ (((((2 : Int) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ ((((2 : Int) + b) - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_4321 a b) ∨ (fact_366edf150095_4345 a b)) ∨ ((fact_366edf150095_3446 a b) ∨ (fact_366edf150095_3370 a b) ∨ (fact_366edf150095_5242 a b) ∨ (fact_366edf150095_5337 a b) ∨ (fact_366edf150095_3381 a b) ∨ (fact_366edf150095_3638 a b) ∨ (((((2 : Int) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int))) ∧ ((((2 : Int) + b) - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_3643 a b) ∨ (fact_366edf150095_3646 a b)))) ∨ ((fact_366edf150095_7339 a b) ∧ (fact_366edf150095_7316 a b) ∧ ((fact_366edf150095_4136 a b) ∨ (fact_366edf150095_3731 a b) ∨ (fact_366edf150095_5882 a b) ∨ (fact_366edf150095_5965 a b) ∨ (fact_366edf150095_3812 a b) ∨ (fact_366edf150095_4245 a b) ∨ (((((2 : Int) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ ((((2 : Int) + b) - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_4321 a b) ∨ (fact_366edf150095_4345 a b)) ∧ ((fact_366edf150095_3446 a b) ∨ (fact_366edf150095_3370 a b) ∨ (fact_366edf150095_5242 a b) ∨ (fact_366edf150095_5337 a b) ∨ (fact_366edf150095_3381 a b) ∨ (fact_366edf150095_3638 a b) ∨ (((((2 : Int) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + (0 : Int))) ∧ (((2 : Int) + b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ ((2 : Int) + b))) ∨ (((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int))) ∧ ((((2 : Int) + b) - b) ≤ ((4 : Int) + a)) ∧ (((4 : Int) + a) ≤ (((2 : Int) + b) + (0 : Int))))) ∨ (fact_366edf150095_3643 a b) ∨ (fact_366edf150095_3646 a b))))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h6 : (a > b))
    (h7 : (a ≥ b))
    : False := by
  apply h2
  clear h2
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n503_run_empty (a b run_x : Int)
    (h0 : ((fact_366edf150095_2376 a b run_x) ∨ (fact_366edf150095_2311 a b run_x) ∨ (fact_366edf150095_3519 a b run_x) ∨ (fact_366edf150095_3534 a b run_x) ∨ (fact_366edf150095_2316 a b run_x) ∨ (fact_366edf150095_2958 a b run_x) ∨ (fact_366edf150095_2985 a b run_x) ∨ (fact_366edf150095_2963 a b run_x) ∨ ((((((3 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + (0 : Int))) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ ((((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a))))))
    (h1 : (run_x ≤ a))
    (h2 : ((3 : Int) ≤ run_x))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n503_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_366edf150095_3350 a b run_x) ∨ (fact_366edf150095_3299 a b run_x) ∨ (fact_366edf150095_5214 a b run_x) ∨ (fact_366edf150095_5224 a b run_x) ∨ (fact_366edf150095_3309 a b run_x) ∨ (fact_366edf150095_3529 a b run_x) ∨ (fact_366edf150095_3565 a b run_x) ∨ (fact_366edf150095_3543 a b run_x) ∨ ((((((3 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + (0 : Int))) ∧ ((3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((4 : Int) - (1 : Int)))) ∨ ((((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b)) ∧ (((3 : Int) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((3 : Int) + a)))))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : ((3 : Int) ≤ run_x))
    (h3 : (run_x ≤ a))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n504_point (a b : Int)
    (h0 : (¬ (((4 : Int) ≥ (-((9 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((4 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((9 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n504_empty (a b : Int)
    (h0 : ((fact_366edf150095_2902 a b) ∨ (fact_366edf150095_2571 a b) ∨ (fact_366edf150095_4058 a b) ∨ (fact_366edf150095_4061 a b) ∨ (fact_366edf150095_2573 a b) ∨ (fact_366edf150095_3172 a b) ∨ (fact_366edf150095_3177 a b) ∨ (fact_366edf150095_3174 a b) ∨ ((((4 : Int) ≥ ((3 : Int) - b)) ∧ ((4 : Int) ≤ ((3 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ (((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n504_o0 (a b jx jy : Int)
    (h0 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h2 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((jx + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n504_o1 (a b jx jy : Int)
    (h0 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (¬ ((((4 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    (h9 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n504_o2 (a b jx jy : Int)
    (h0 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (fact_366edf150095_2954 a b jy))
    (h2 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n504_o3 (a b jx jy : Int)
    (h0 : (¬ (((jx = ((4 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h3 : (((jx + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < (jx - b)) ∨ ((0 : Int) > jy) ∨ ((0 : Int) < jy)))
    (h4 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n504_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((3 : Int) > (jx + (0 : Int))) ∨ ((3 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((((4 : Int) ≥ (jx - b)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n504_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((jx + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h4 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : ((((4 : Int) ≥ (jx - a)) ∧ ((4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h6 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < (((2 : Int) + b) - b)) ∨ ((((2 : Int) + b) + (0 : Int)) < jy)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (a = (b + (2 : Int))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n504_o6 (a b jx jy : Int)
    (h0 : ((jx < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (¬ ((((4 : Int) = jx) ∧ ((3 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h4 : (((3 : Int) > (jx + b)) ∨ ((3 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n504_o7 (a b jx jy : Int)
    (h0 : (fact_366edf150095_2955 a b jy))
    (h1 : (¬ ((((4 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h2 : ((((4 : Int) ≥ (jx - (0 : Int))) ∧ ((4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((4 : Int) ≥ jx) ∧ ((4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (((jx + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    (h10 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n505_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((5 : Int) ≤ ((2 : Int) + a))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h1
  clear h1
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n505_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + a) - (5 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n505_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n505_run_left (a b : Int)
    (h0 : (¬ ((fact_366edf150095_3502 a b) ∨ (fact_366edf150095_3451 a b) ∨ (fact_366edf150095_5778 a b) ∨ (fact_366edf150095_5786 a b) ∨ (fact_366edf150095_3459 a b) ∨ (fact_366edf150095_3697 a b) ∨ (fact_366edf150095_3916 a b) ∨ (fact_366edf150095_3704 a b) ∨ (fact_366edf150095_3969 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ ((5 : Int) - (1 : Int))) ∧ (((5 : Int) - (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ ((5 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((5 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  right
  right
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n505_run_right (a b : Int)
    (h0 : (¬ ((fact_366edf150095_4117 a b) ∨ (fact_366edf150095_3712 a b) ∨ (fact_366edf150095_5863 a b) ∨ (fact_366edf150095_5946 a b) ∨ (fact_366edf150095_3793 a b) ∨ (fact_366edf150095_4226 a b) ∨ (fact_366edf150095_4631 a b) ∨ (fact_366edf150095_4319 a b) ∨ (fact_366edf150095_4774 a b) ∨ (((((4 : Int) - (0 : Int)) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((((2 : Int) + a) + (1 : Int)) ≤ ((4 : Int) + b)) ∧ ((3 : Int) ≥ ((3 : Int) + a)) ∧ ((3 : Int) ≤ ((3 : Int) + a))) ∨ (((4 : Int) ≤ (((2 : Int) + a) + (1 : Int))) ∧ ((4 : Int) ≥ (((2 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((3 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((3 : Int) + a) + (0 : Int))))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h0
  clear h0
  right
  right
  right
  right
  right
  right
  right
  left
  right
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n505_run_tall (a b : Int)
    (h0 : (¬ (((((5 : Int) + (3 : Int)) ≤ ((2 : Int) + a)) ∧ ((fact_366edf150095_7412 a b) ∨ (fact_366edf150095_7452 a b))) ∨ ((((5 : Int) + (2 : Int)) ≤ ((2 : Int) + a)) ∧ (fact_366edf150095_7412 a b) ∧ (fact_366edf150095_7452 a b)) ∨ (((5 : Int) + (4 : Int)) ≤ ((2 : Int) + a)) ∨ ((((2 : Int) + a) = ((5 : Int) + (1 : Int))) ∧ (fact_366edf150095_7412 a b) ∧ (fact_366edf150095_7452 a b) ∧ (((fact_366edf150095_4156 a b) ∨ (fact_366edf150095_3751 a b) ∨ (fact_366edf150095_5902 a b) ∨ (fact_366edf150095_5985 a b) ∨ (fact_366edf150095_3832 a b) ∨ (fact_366edf150095_4265 a b) ∨ (fact_366edf150095_4648 a b) ∨ (fact_366edf150095_4335 a b) ∨ (fact_366edf150095_4792 a b) ∨ (fact_366edf150095_4888 a b)) ∨ ((fact_366edf150095_5118 a b) ∨ (fact_366edf150095_4412 a b) ∨ (fact_366edf150095_6337 a b) ∨ (fact_366edf150095_6425 a b) ∨ (fact_366edf150095_4496 a b) ∨ (fact_366edf150095_5246 a b) ∨ (fact_366edf150095_5432 a b) ∨ (fact_366edf150095_5345 a b) ∨ (fact_366edf150095_5514 a b) ∨ (fact_366edf150095_5573 a b)))) ∨ ((fact_366edf150095_7412 a b) ∧ (fact_366edf150095_7452 a b) ∧ ((fact_366edf150095_4156 a b) ∨ (fact_366edf150095_3751 a b) ∨ (fact_366edf150095_5902 a b) ∨ (fact_366edf150095_5985 a b) ∨ (fact_366edf150095_3832 a b) ∨ (fact_366edf150095_4265 a b) ∨ (fact_366edf150095_4648 a b) ∨ (fact_366edf150095_4335 a b) ∨ (fact_366edf150095_4792 a b) ∨ (fact_366edf150095_4888 a b)) ∧ ((fact_366edf150095_5118 a b) ∨ (fact_366edf150095_4412 a b) ∨ (fact_366edf150095_6337 a b) ∨ (fact_366edf150095_6425 a b) ∨ (fact_366edf150095_4496 a b) ∨ (fact_366edf150095_5246 a b) ∨ (fact_366edf150095_5432 a b) ∨ (fact_366edf150095_5345 a b) ∨ (fact_366edf150095_5514 a b) ∨ (fact_366edf150095_5573 a b))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((1 : Int) + a) < (((2 : Int) * a) - b)) ∨ ((((2 : Int) * a) + (0 : Int)) < ((1 : Int) - (0 : Int))) ∨ ((1 : Int) < (1 : Int)) ∨ ((1 : Int) < (1 : Int))))
    (h3 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  apply h0
  clear h0
  left
  refine ⟨?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · left
    right
    right
    right
    right
    right
    right
    right
    right
    right
    right
    refine ⟨?_,?_,?_,?_⟩
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
    · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n505_run_empty (a b run_x : Int)
    (h0 : (run_x ≤ ((2 : Int) + a)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((5 : Int) ≤ run_x))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((fact_366edf150095_2375 a b run_x) ∨ (fact_366edf150095_2310 a b run_x) ∨ (fact_366edf150095_3518 a b run_x) ∨ (fact_366edf150095_3533 a b run_x) ∨ (fact_366edf150095_2315 a b run_x) ∨ (fact_366edf150095_2957 a b run_x) ∨ (fact_366edf150095_2984 a b run_x) ∨ (fact_366edf150095_2962 a b run_x) ∨ (fact_366edf150095_2995 a b run_x) ∨ (fact_366edf150095_3004 a b run_x)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  try subst b
  try subst a
  try simp only [eq_self_iff_true, Int.add_zero, Int.zero_add, Int.sub_zero, Int.sub_self, or_true, true_or, and_true, true_and, not_true_eq_false, not_false_eq_true, or_false, false_or, and_false, false_and] at *
  all_goals first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

theorem HP_optimized_unequal_mixed_nonexception_delta_two_pruned_n505_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((2 : Int) + a)))
    (h1 : ((5 : Int) ≤ run_x))
    (h2 : (¬ ((fact_366edf150095_3349 a b run_x) ∨ (fact_366edf150095_3298 a b run_x) ∨ (fact_366edf150095_5213 a b run_x) ∨ (fact_366edf150095_5223 a b run_x) ∨ (fact_366edf150095_3308 a b run_x) ∨ (fact_366edf150095_3528 a b run_x) ∨ (fact_366edf150095_3564 a b run_x) ∨ (fact_366edf150095_3542 a b run_x) ∨ (fact_366edf150095_3578 a b run_x) ∨ (fact_366edf150095_3586 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : ((¬ (a = (5 : Int))) ∨ (¬ (b = (3 : Int)))))
    : False := by
  apply h2
  clear h2
  right
  right
  right
  right
  right
  right
  right
  left
  left
  refine ⟨?_,?_,?_,?_⟩
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega
  · first | omega -splitDisjunctions | (apply le_antisymm <;> omega -splitDisjunctions) | omega

end LRegionArithmetic

import RepComposition
import FiniteCandidates
import PositiveHierarchy

namespace PolyominoFormal
open CrossUnits CoreBoundaryObstructions TilingCompactness

/-- Every enlarged zero-south cross lies in the quadrant when its
leftmost horizontal cell is placed at the origin. -/
theorem scaled_zero_south_inside {a b c K x y : Int}
    (ha : 0≤a) (hb : 0≤b) (hc : 0≤c) (hK : 0<K)
    (hit : ScaledCross a b c 0 K (x-c*K) y) : Quadrant x y := by
  have ck := Int.mul_nonneg hc (by omega : 0≤K)
  simp only [ScaledCross,Int.zero_mul,Int.neg_mul] at hit
  unfold Quadrant
  omega

theorem scaled_zero_south_square {a b c K x y : Int}
    (ha : 0≤a) (hc : 0≤c) (hK : 0<K)
    (hx : 0≤x ∧ x<K) (hy : 0≤y ∧ y<K) :
    ScaledCross a b c 0 K (x-c*K) y := by
  have ck := Int.mul_nonneg hc (by omega : 0≤K)
  have ak := Int.mul_nonneg ha (by omega : 0≤K)
  unfold ScaledCross
  left
  simp only [Int.add_mul,Int.one_mul,Int.neg_mul]
  omega

/-- For every cross with a zero south arm, an integer-scale rep dissection
implies a genuine whole-cell quadrant tiling. -/
theorem rep_zero_south_implies_quadrant {a b c : Int}
    (ha : 0≤a) (hb : 0≤b) (hc : 0≤c) (rep : RepTileable a b c 0) :
    Tiles a b c 0 Quadrant := by
  classical
  have large := rep_arbitrarily_large rep
  let K (n : Nat) : Int := Classical.choose (large n)
  have properties (n : Nat) := Classical.choose_spec (large n)
  have kTwo (n : Nat) : 2≤K n := (properties n).2.1
  let T (n : Nat) : Tiling a b c 0 (ScaledCross a b c 0 (K n)) :=
    Classical.choice (properties n).2.2
  let U (n : Nat) := (T n).translate (c*K n) 0
  apply world_limit ha hb hc (by omega) (fun n => (U n).world)
  · exact fun n t ht => (U n).copies t ht
  · intro n t ht x y hit
    apply scaled_zero_south_inside (K:=K n) ha hb hc (by have := kTwo n; omega)
    simpa using (U n).inside t ht x y hit
  · exact fun n t u x y ht hu h1 h2 => (U n).disjoint t u x y ht hu h1 h2
  · intro x y hxy
    refine ⟨(x+y+1).toNat,?_⟩
    intro n hn
    have nK : (n : Int)≤K n := (properties n).1
    have hK : 0<K n := by have := kTwo n; omega
    have hxK : x<K n := by unfold Quadrant at hxy; omega
    have hyK : y<K n := by unfold Quadrant at hxy; omega
    apply (U n).cover x y
    change ScaledCross a b c 0 (K n) (x-c*K n) (y-0)
    simp only [Int.sub_zero]
    exact scaled_zero_south_square ha hc hK ⟨hxy.1,hxK⟩ ⟨hxy.2,hyK⟩

theorem rep_zero_south_implies_halfplane {a b c : Int}
    (ha : 0≤a) (hb : 0≤b) (hc : 0≤c) (rep : RepTileable a b c 0) :
    Tiles a b c 0 HalfPlane :=
  PositiveHierarchy.quadrant_tiles_halfplane (rep_zero_south_implies_quadrant ha hb hc rep)

#print axioms rep_zero_south_implies_quadrant
end PolyominoFormal

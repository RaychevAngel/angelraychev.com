import LQuadrantHpAdjacentOuterShortPairPrunedGeometryDefs
import LQuadrantHpAdjacentOuterShortPairPrunedGeometryChunk000
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PolyominoFormal.LRegion
open CrossUnits

theorem HP_adjacent_outer_short_pair_pruned_node088 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk ((5 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap7_8 : Apart (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap8_9 : Apart (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk ((5 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht9
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk ((5 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht9
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht0 ht8
  have pairAllowed0_9 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht9
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht1 ht8
  have pairAllowed1_9 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht9
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht2 ht8
  have pairAllowed2_9 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht9
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht3 ht8
  have pairAllowed3_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht9
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht4 ht8
  have pairAllowed4_9 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4 ht9
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht5 ht8
  have pairAllowed5_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5 ht9
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht6 ht8
  have pairAllowed6_9 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6 ht9
  have pairAllowed7_8 := avoidPair (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht7 ht8
  have pairAllowed7_9 := avoidPair (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7 ht9
  have pairAllowed8_9 := avoidPair (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht8 ht9
  apply avoidRun [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a), (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((5 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a)] (5 : Int) ((4 : Int) + b) (4 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n088_run_four a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (ha) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n088_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n088_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n088_run_empty a b run_x (hlong) (ap7_9).2.1 ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hstrict) (hx0) (hx1) (hb) (ha) (hadjacent)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n088_run_floor a b run_x (hx0) (hx1) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n088_run_left a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n088_run_right a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n088_run_tall a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (hstrict) (ap5_9).2.2.2 (hb) (ha) (hadjacent)

theorem HP_adjacent_outer_short_pair_pruned_node089 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk ((5 : Int) + b) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap7_8 : Apart (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap8_9 : Apart (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk ((5 : Int) + b) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht9
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk ((5 : Int) + b) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht9
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht0 ht8
  have pairAllowed0_9 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht9
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht1 ht8
  have pairAllowed1_9 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht9
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht2 ht8
  have pairAllowed2_9 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht9
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht3 ht8
  have pairAllowed3_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht9
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht4 ht8
  have pairAllowed4_9 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht4 ht9
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht5 ht8
  have pairAllowed5_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht5 ht9
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht6 ht8
  have pairAllowed6_9 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht6 ht9
  have pairAllowed7_8 := avoidPair (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht7 ht8
  have pairAllowed7_9 := avoidPair (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht7 ht9
  have pairAllowed8_9 := avoidPair (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht8 ht9
  apply avoidRun [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a), (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((5 : Int) + b) ((3 : Int) + a) b (0 : Int) (0 : Int) a)] (5 : Int) ((4 : Int) + b) (4 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n089_run_four a b (hb) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n089_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n089_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n089_run_empty a b run_x (ap5_9).2.2.2 (hx1) (hx0) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (hstrict) (hb) (ha) (hadjacent)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n089_run_floor a b run_x (hx0) (hx1) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n089_run_left a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n089_run_right a b (hlong) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n089_run_tall a b (hb) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hstrict) (ha) (hlong) (hadjacent)

theorem HP_adjacent_outer_short_pair_pruned_node090 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk ((5 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap7_8 : Apart (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap8_9 : Apart (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk ((5 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht9
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk ((5 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht9
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht0 ht8
  have pairAllowed0_9 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht9
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht1 ht8
  have pairAllowed1_9 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht9
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht2 ht8
  have pairAllowed2_9 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht9
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht3 ht8
  have pairAllowed3_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht9
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht4 ht8
  have pairAllowed4_9 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht9
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht5 ht8
  have pairAllowed5_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht9
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht6 ht8
  have pairAllowed6_9 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6 ht9
  have pairAllowed7_8 := avoidPair (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht7 ht8
  have pairAllowed7_9 := avoidPair (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht7 ht9
  have pairAllowed8_9 := avoidPair (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht8 ht9
  apply avoidRun [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a), (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((5 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a)] (5 : Int) ((4 : Int) + b) (4 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n090_run_four a b (hb) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n090_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n090_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n090_run_empty a b run_x (hx1) (hb) (ap7_9).2.1 (hx0) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hstrict) (hlong) (ha) (hadjacent)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n090_run_floor a b run_x (hx1) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx0) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n090_run_left a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n090_run_right a b (hlong) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n090_run_tall a b (ap5_9).2.2.2 (hb) (hstrict) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hadjacent)

theorem HP_adjacent_outer_short_pair_pruned_node091 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk ((5 : Int) + b) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap7_8 : Apart (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap8_9 : Apart (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk ((5 : Int) + b) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht9
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk ((5 : Int) + b) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht9
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht0 ht8
  have pairAllowed0_9 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht9
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht1 ht8
  have pairAllowed1_9 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht9
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht2 ht8
  have pairAllowed2_9 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht9
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht3 ht8
  have pairAllowed3_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht9
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht4 ht8
  have pairAllowed4_9 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht9
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht5 ht8
  have pairAllowed5_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht9
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht6 ht8
  have pairAllowed6_9 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht6 ht9
  have pairAllowed7_8 := avoidPair (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht7 ht8
  have pairAllowed7_9 := avoidPair (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht7 ht9
  have pairAllowed8_9 := avoidPair (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht8 ht9
  apply avoidRun [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a), (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((5 : Int) + b) ((3 : Int) + a) (0 : Int) (0 : Int) b a)] (5 : Int) ((4 : Int) + b) (4 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n091_run_four a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (ha) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n091_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n091_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n091_run_empty a b run_x (hx0) (hx1) (hlong) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hadjacent) (hstrict) (ha) (hb)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n091_run_floor a b run_x (hx0) (hx1) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n091_run_left a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n091_run_right a b (hlong) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n091_run_tall a b (hb) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hstrict) (ha) (hlong) (hadjacent)

theorem HP_adjacent_outer_short_pair_pruned_node092 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk ((5 : Int) + b) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((5 : Int) + b) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap7_8 : Apart (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap8_9 : Apart (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk ((5 : Int) + b) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht9
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk ((5 : Int) + b) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht9
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht0 ht8
  have pairAllowed0_9 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht9
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht1 ht8
  have pairAllowed1_9 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht9
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht2 ht8
  have pairAllowed2_9 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht9
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht3 ht8
  have pairAllowed3_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht3 ht9
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht4 ht8
  have pairAllowed4_9 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht4 ht9
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht5 ht8
  have pairAllowed5_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht5 ht9
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht6 ht8
  have pairAllowed6_9 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((5 : Int) + b) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht6 ht9
  have pairAllowed7_8 := avoidPair (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht7 ht8
  have pairAllowed7_9 := avoidPair (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht7 ht9
  have pairAllowed8_9 := avoidPair (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht8 ht9
  apply avoidRun [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a), (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((5 : Int) + b) ((3 : Int) + b) a (0 : Int) (0 : Int) b)] (5 : Int) ((4 : Int) + b) (4 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n092_run_four a b (hb) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n092_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n092_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n092_run_empty a b run_x (hx0) (hb) (hstrict) (hlong) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx1) (ap5_9).2.2.2 (ha) (hadjacent)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n092_run_floor a b run_x (hx0) (hx1) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n092_run_left a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n092_run_right a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (ha) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n092_run_tall a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ap5_9).2.2.2 (hlong) (hstrict) (hb) (ha) (hadjacent)

theorem HP_adjacent_outer_short_pair_pruned_node075 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap7_8 : Apart (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht8
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht8
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht0 ht8
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht1 ht8
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht2 ht8
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht3 ht8
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht4 ht8
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht5 ht8
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht6 ht8
  have pairAllowed7_8 := avoidPair (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht7 ht8
  have support : HP_adjacent_outer_short_pair_pruned_Box a b ((5 : Int) + b) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n075_point a b (hlong) ((by simpa only [HP_adjacent_outer_short_pair_pruned_Box,HP_adjacent_outer_short_pair_pruned_M] using absent)) (hb) (ap5_7).2.2.1 (ha) (hstrict) (hadjacent)
  have empty : ¬(Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ((5 : Int) + b) (3 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ((5 : Int) + b) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ((5 : Int) + b) (3 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ((5 : Int) + b) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ((5 : Int) + b) (3 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ((5 : Int) + b) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ((5 : Int) + b) (3 : Int) ∨ Contains (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ((5 : Int) + b) (3 : Int) ∨ Contains (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ((5 : Int) + b) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n075_empty a b ((by simpa only [Contains] using occupied)) (hb) (hlong) (ap5_7).2.2.1 (ap2_8).2.2.1 (ap0_5).2.2.1 (hstrict) (ha) (hadjacent)
  obtain ⟨t,ht,hit⟩ := cover ((5 : Int) + b) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5
  have pairAllowed6 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht6
  have pairAllowed7 := avoidPair t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht7
  have pairAllowed8 := avoidPair t (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht ht8
  have sep0 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n075_o0 a b jx jy (sep5).2.1 (sep2).2.1 (ap5_7).2.2.1 (hadjacent) (hit) (sep8).1 (insideT) (hlong) (hstrict) (hb) (ha)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ∨ Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n075_o1 a b jx jy (insideT) (hit) (hb) ((by simpa only [Same,eq_comm] using absent)) (hlong) (sep5).2.1 (ap5_7).2.2.1 (ha) (hstrict) (hadjacent)
    rcases alternatives with matched | matched
    · have eq := same_eq matched
      rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8
      exact HP_adjacent_outer_short_pair_pruned_node088 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 (apart_sym sep4) ap5_6 ap5_7 ap5_8 (apart_sym sep5) ap6_7 ap6_8 (apart_sym sep6) ap7_8 (apart_sym sep7) (apart_sym sep8)
    · have eq := same_eq matched
      rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8
      exact HP_adjacent_outer_short_pair_pruned_node089 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 (apart_sym sep4) ap5_6 ap5_7 ap5_8 (apart_sym sep5) ap6_7 ap6_8 (apart_sym sep6) ap7_8 (apart_sym sep7) (apart_sym sep8)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n075_o2 a b jx jy (hb) (insideT) (ap5_7).2.2.1 (hit) (sep8).2.1 (hlong) (hstrict) (ha) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n075_o3 a b jx jy (ap5_7).2.2.1 (sep5).2.2.1 (hit) (insideT) (hb) (hlong) (sep8).1 (sep7).1 (sep5).2.1 (ha) (hstrict) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk ((5 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ∨ Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk ((5 : Int) + b) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n075_o4 a b jx jy (ap5_7).2.2.1 (hit) ((by simpa only [Same,eq_comm] using absent)) (sep5).2.2.1 (insideT) (hlong) (hb) (ha) (hstrict) (hadjacent)
    rcases alternatives with matched | matched
    · have eq := same_eq matched
      rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8
      exact HP_adjacent_outer_short_pair_pruned_node090 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 (apart_sym sep4) ap5_6 ap5_7 ap5_8 (apart_sym sep5) ap6_7 ap6_8 (apart_sym sep6) ap7_8 (apart_sym sep7) (apart_sym sep8)
    · have eq := same_eq matched
      rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8
      exact HP_adjacent_outer_short_pair_pruned_node091 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 (apart_sym sep4) ap5_6 ap5_7 ap5_8 (apart_sym sep5) ap6_7 ap6_8 (apart_sym sep6) ap7_8 (apart_sym sep7) (apart_sym sep8)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n075_o5 a b jx jy (sep8).1 (sep7).1 (hb) (insideT) (hit) (sep5).2.2.1 (sep8).2.1 (sep5).2.1 (hadjacent) (hlong) (hstrict) (ap5_7).2.2.1 (ha)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n075_o6 a b jx jy (insideT) (sep5).2.1 (hit) (hb) (sep5).2.2.1 ((by simpa only [HP_adjacent_outer_short_pair_pruned_ForbiddenPair, ForbiddenSameBoundaryBars, ForbiddenLongBoundaryCorner, LongBoundaryCorner, ForbiddenSameShortBars, ForbiddenOutwardLongBoundaryCorner, OutwardLongBoundaryCorner, ForbiddenShortUprightLong, ShortUprightLong, eq_comm] using pairAllowed8)) (ap5_7).2.2.1 (sep8).2.2.1 (hlong) (ha) (hstrict) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk ((5 : Int) + b) ((3 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n075_o7 a b jx jy (sep5).2.1 (hit) (hb) ((by simpa only [Same,eq_comm] using absent)) (insideT) (ap5_7).2.2.1 (hlong) (hstrict) (ha) (hadjacent)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8
    exact HP_adjacent_outer_short_pair_pruned_node092 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 (apart_sym sep4) ap5_6 ap5_7 ap5_8 (apart_sym sep5) ap6_7 ap6_8 (apart_sym sep6) ap7_8 (apart_sym sep7) (apart_sym sep8)

theorem HP_adjacent_outer_short_pair_pruned_node093 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap7_8 : Apart (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht8
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht8
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht8
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht8
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht8
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht3 ht8
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht4 ht8
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht5 ht8
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht6 ht8
  have pairAllowed7_8 := avoidPair (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht7 ht8
  apply avoidRunRight [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a), (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b)] (3 : Int) ((2 : Int) + b) (5 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n093_run_four a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (ha) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n093_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n093_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n093_run_empty a b run_x (hx0) (hlong) (hx1) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (ha) (hstrict) (hadjacent)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n093_run_floor a b run_x ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx0) (hx1) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n093_run_left a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n093_run_right a b (hlong) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n093_run_tall a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hstrict) (hb) (hlong) (ha) (hadjacent)

theorem HP_adjacent_outer_short_pair_pruned_node064 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht7
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht7
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht0 ht7
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht1 ht7
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht2 ht7
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3 ht7
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht4 ht7
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht5 ht7
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht6 ht7
  have support : HP_adjacent_outer_short_pair_pruned_Box a b (4 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n064_point a b ((by simpa only [HP_adjacent_outer_short_pair_pruned_Box,HP_adjacent_outer_short_pair_pruned_M] using absent)) (hb) (hlong) (ap5_7).2.2.1 (ha) (hstrict) (hadjacent)
  have empty : ¬(Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n064_empty a b ((by simpa only [Contains] using occupied)) (hlong) (hb) (ha) (hstrict) (hadjacent)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5
  have pairAllowed6 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht6
  have pairAllowed7 := avoidPair t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht7
  have sep0 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) a b (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n064_o0 a b jx jy (hlong) (sep7).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (hit) (insideT) (hb) (ap5_7).2.2.1 (sep7).2.1 (hadjacent) (ha) (hstrict)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_adjacent_outer_short_pair_pruned_node065 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n064_o1 a b jx jy (hlong) ((by simpa only [Same,eq_comm] using absent)) (insideT) (sep7).2.2.1 (hit) (ha) (hb) (hstrict) (hadjacent)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_adjacent_outer_short_pair_pruned_node066 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n064_o2 a b jx jy (sep6).2.1 (insideT) (hb) (hlong) (hstrict) (hit) (ap5_7).2.2.1 (ha) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n064_o3 a b jx jy (insideT) (hit) (sep1).2.1 ((by simpa only [Same,eq_comm] using absent)) (sep7).2.1 (hlong) (hadjacent) (ha) (hb) (hstrict)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_adjacent_outer_short_pair_pruned_node072 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n064_o4 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (sep6).2.1 (insideT) (hit) (hadjacent) (hlong) (ha) (hb) (hstrict)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_adjacent_outer_short_pair_pruned_node073 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n064_o5 a b jx jy (insideT) (hadjacent) (hlong) ((by simpa only [Same,eq_comm] using absent)) (sep1).2.1 (sep7).2.1 (hit) (ha) (hb) (hstrict)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_adjacent_outer_short_pair_pruned_node074 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (3 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n064_o6 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (insideT) (hit) (sep7).2.2.1 (sep7).2.1 (hadjacent) (hlong) (ha) (hb) (hstrict)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_adjacent_outer_short_pair_pruned_node075 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n064_o7 a b jx jy (ap5_7).2.2.1 (insideT) (hlong) (hit) (sep7).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (hb) (ha) (hstrict) (hadjacent)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_adjacent_outer_short_pair_pruned_node093 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)

theorem HP_adjacent_outer_short_pair_pruned_node096 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht8 : world (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk (5 : Int) (3 : Int) a b (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (5 : Int) (3 : Int) a b (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (5 : Int) (3 : Int) a b (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (5 : Int) (3 : Int) a b (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (5 : Int) (3 : Int) a b (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (5 : Int) (3 : Int) a b (0 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (5 : Int) (3 : Int) a b (0 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (5 : Int) (3 : Int) a b (0 : Int) (0 : Int)))
    (ap7_8 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (5 : Int) (3 : Int) a b (0 : Int) (0 : Int)))
    (ap8_9 : Apart (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (5 : Int) (3 : Int) a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have in8 := inside (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk (5 : Int) (3 : Int) a b (0 : Int) (0 : Int)) ht9
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have allowed8 := avoid (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk (5 : Int) (3 : Int) a b (0 : Int) (0 : Int)) ht9
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht0 ht8
  have pairAllowed0_9 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (5 : Int) (3 : Int) a b (0 : Int) (0 : Int)) ht0 ht9
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht1 ht8
  have pairAllowed1_9 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (5 : Int) (3 : Int) a b (0 : Int) (0 : Int)) ht1 ht9
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht2 ht8
  have pairAllowed2_9 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (5 : Int) (3 : Int) a b (0 : Int) (0 : Int)) ht2 ht9
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3 ht8
  have pairAllowed3_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (5 : Int) (3 : Int) a b (0 : Int) (0 : Int)) ht3 ht9
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht4 ht8
  have pairAllowed4_9 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (5 : Int) (3 : Int) a b (0 : Int) (0 : Int)) ht4 ht9
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht5 ht8
  have pairAllowed5_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (5 : Int) (3 : Int) a b (0 : Int) (0 : Int)) ht5 ht9
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht6 ht8
  have pairAllowed6_9 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (5 : Int) (3 : Int) a b (0 : Int) (0 : Int)) ht6 ht9
  have pairAllowed7_8 := avoidPair (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht7 ht8
  have pairAllowed7_9 := avoidPair (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (5 : Int) (3 : Int) a b (0 : Int) (0 : Int)) ht7 ht9
  have pairAllowed8_9 := avoidPair (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (5 : Int) (3 : Int) a b (0 : Int) (0 : Int)) ht8 ht9
  have support : HP_adjacent_outer_short_pair_pruned_Box a b (4 : Int) ((3 : Int) + b) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n096_point a b (hadjacent) (hlong) (hb) (ap7_9).2.1 (ha) (hstrict)
  have empty : ¬(Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (4 : Int) ((3 : Int) + b) ∨ Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) ((3 : Int) + b) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (4 : Int) ((3 : Int) + b) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) ((3 : Int) + b) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (4 : Int) ((3 : Int) + b) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (4 : Int) ((3 : Int) + b) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) ((3 : Int) + b) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) ((3 : Int) + b) ∨ Contains (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (4 : Int) ((3 : Int) + b) ∨ Contains (Cross.mk (5 : Int) (3 : Int) a b (0 : Int) (0 : Int)) (4 : Int) ((3 : Int) + b)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n096_empty a b (hlong) (ap0_5).2.2.1 ((by simpa only [Contains] using occupied)) (ap7_9).2.1 (hb) (ha) (hstrict) (hadjacent)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) ((3 : Int) + b) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5
  have pairAllowed6 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht6
  have pairAllowed7 := avoidPair t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht7
  have pairAllowed8 := avoidPair t (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht8
  have pairAllowed9 := avoidPair t (Cross.mk (5 : Int) (3 : Int) a b (0 : Int) (0 : Int)) ht ht9
  have sep0 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))
    · exact ap
  have sep9 : Apart t (Cross.mk (5 : Int) (3 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (5 : Int) (3 : Int) a b (0 : Int) (0 : Int)) ht ht9 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n096_o0 a b jx jy (ap7_9).2.1 (hadjacent) (hlong) (hb) (ha) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n096_o1 a b jx jy (hb) (ap7_9).2.1 (hadjacent) (hlong) (ha) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n096_o2 a b jx jy (ap7_9).2.1 (hadjacent) (hb) (hlong) (ha) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n096_o3 a b jx jy (hb) (hadjacent) (ap7_9).2.1 (hlong) (ha) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n096_o4 a b jx jy (hadjacent) (hb) (ap7_9).2.1 (hlong) (ha) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n096_o5 a b jx jy (ap7_9).2.1 (hlong) (hadjacent) (hb) (ha) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n096_o6 a b jx jy (ap7_9).2.1 (hb) (hadjacent) (hlong) (ha) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n096_o7 a b jx jy (hadjacent) (ap7_9).2.1 (hlong) (hb) (ha) (hstrict)

theorem HP_adjacent_outer_short_pair_pruned_node097 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht8 : world (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk ((5 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((5 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((5 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap7_8 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((5 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap8_9 : Apart (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have in8 := inside (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk ((5 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht9
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have allowed8 := avoid (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk ((5 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht9
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht0 ht8
  have pairAllowed0_9 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht0 ht9
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht1 ht8
  have pairAllowed1_9 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht1 ht9
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht2 ht8
  have pairAllowed2_9 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht2 ht9
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3 ht8
  have pairAllowed3_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht3 ht9
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht4 ht8
  have pairAllowed4_9 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht4 ht9
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht5 ht8
  have pairAllowed5_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((5 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht5 ht9
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht6 ht8
  have pairAllowed6_9 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((5 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht6 ht9
  have pairAllowed7_8 := avoidPair (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht7 ht8
  have pairAllowed7_9 := avoidPair (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((5 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht7 ht9
  have pairAllowed8_9 := avoidPair (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht8 ht9
  apply avoidRun [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a), (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a), (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((5 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int))] (5 : Int) ((4 : Int) + b) (4 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n097_run_four a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (ha) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n097_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n097_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n097_run_empty a b run_x (hstrict) (hx1) (hx0) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hadjacent) (hlong) (ha) (hb)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n097_run_floor a b run_x (hx0) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx1) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n097_run_left a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (ha) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n097_run_right a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n097_run_tall a b (ap5_9).2.2.1 (hstrict) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (hb) (ha) (hadjacent)

theorem HP_adjacent_outer_short_pair_pruned_node098 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht8 : world (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk ((5 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((5 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((5 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)))
    (ap7_8 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((5 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)))
    (ap8_9 : Apart (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have in8 := inside (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk ((5 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) ht9
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have allowed8 := avoid (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk ((5 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) ht9
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht0 ht8
  have pairAllowed0_9 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) ht0 ht9
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht1 ht8
  have pairAllowed1_9 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) ht1 ht9
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht2 ht8
  have pairAllowed2_9 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) ht2 ht9
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3 ht8
  have pairAllowed3_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) ht3 ht9
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht4 ht8
  have pairAllowed4_9 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) ht4 ht9
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht5 ht8
  have pairAllowed5_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((5 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) ht5 ht9
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht6 ht8
  have pairAllowed6_9 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((5 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) ht6 ht9
  have pairAllowed7_8 := avoidPair (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht7 ht8
  have pairAllowed7_9 := avoidPair (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((5 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) ht7 ht9
  have pairAllowed8_9 := avoidPair (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((5 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) ht8 ht9
  have support : HP_adjacent_outer_short_pair_pruned_Box a b ((5 : Int) + a) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n098_point a b ((by simpa only [HP_adjacent_outer_short_pair_pruned_Box,HP_adjacent_outer_short_pair_pruned_M] using absent)) (hstrict) (ap5_9).2.2.1 (hlong) (hb) (ha) (hadjacent)
  have empty : ¬(Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ((5 : Int) + a) (2 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ((5 : Int) + a) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ((5 : Int) + a) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ((5 : Int) + a) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ((5 : Int) + a) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ((5 : Int) + a) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ((5 : Int) + a) (2 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ((5 : Int) + a) (2 : Int) ∨ Contains (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ((5 : Int) + a) (2 : Int) ∨ Contains (Cross.mk ((5 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) ((5 : Int) + a) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n098_empty a b (ap5_9).2.2.1 (hb) (ha) (ap0_2).1 (hlong) ((by simpa only [Contains] using occupied)) (hstrict) (hadjacent)
  obtain ⟨t,ht,hit⟩ := cover ((5 : Int) + a) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5
  have pairAllowed6 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht6
  have pairAllowed7 := avoidPair t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht7
  have pairAllowed8 := avoidPair t (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht8
  have pairAllowed9 := avoidPair t (Cross.mk ((5 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) ht ht9
  have sep0 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))))
    · exact ap
  have sep9 : Apart t (Cross.mk ((5 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((5 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) ht ht9 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n098_o0 a b jx jy (ap5_9).2.2.1 (hstrict) (hit) (insideT) (sep9).2.2.1 (hlong) (hb) (ha) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n098_o1 a b jx jy (hstrict) (sep9).2.2.1 (hit) (insideT) (hb) (ap5_9).2.2.1 (hlong) (ha) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n098_o2 a b jx jy (hb) (sep9).2.2.1 (hstrict) (insideT) (hit) (ap5_9).2.2.1 (hlong) (ha) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n098_o3 a b jx jy (hstrict) (ap5_9).2.2.1 (sep8).1 (sep2).2.1 (sep5).2.2.1 (hb) (hadjacent) (hlong) (hit) (insideT) (ha)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n098_o4 a b jx jy (insideT) (hlong) (ap5_9).2.2.1 (hb) (sep9).2.2.1 (hit) (hstrict) (ha) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n098_o5 a b jx jy (hlong) (insideT) (sep3).2.1 (sep5).2.2.1 (ap5_9).2.2.1 (sep8).1 (hit) (hstrict) (hb) (ha) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n098_o6 a b jx jy (ap5_9).2.2.1 (hlong) (insideT) (sep8).2.2.1 (sep9).2.2.1 (hstrict) (hb) (hit) (ha) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n098_o7 a b jx jy (insideT) (hstrict) (hit) (sep9).2.1 (ap5_9).2.2.1 (hlong) (hb) (ha) (hadjacent)

theorem HP_adjacent_outer_short_pair_pruned_node099 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht8 : world (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ht9 : world (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap1_9 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap2_9 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap3_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap4_9 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap5_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap6_9 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap7_8 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap7_9 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap8_9 : Apart (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have in8 := inside (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht8
  have in9 := inside (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht9
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have allowed8 := avoid (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht9
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht0 ht8
  have pairAllowed0_9 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht9
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht1 ht8
  have pairAllowed1_9 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht9
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht2 ht8
  have pairAllowed2_9 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht9
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3 ht8
  have pairAllowed3_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht3 ht9
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht4 ht8
  have pairAllowed4_9 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht4 ht9
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht5 ht8
  have pairAllowed5_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht5 ht9
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht6 ht8
  have pairAllowed6_9 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht6 ht9
  have pairAllowed7_8 := avoidPair (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht7 ht8
  have pairAllowed7_9 := avoidPair (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht7 ht9
  have pairAllowed8_9 := avoidPair (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht8 ht9
  apply avoidRunRight [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a), (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a), (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b)] (3 : Int) ((2 : Int) + b) (6 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n099_run_four a b (hb) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n099_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n099_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n099_run_empty a b run_x (hadjacent) (ap7_9).2.1 (hlong) (hb) (ha) (hstrict)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n099_run_floor a b run_x (hx1) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx0) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n099_run_left a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n099_run_right a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n099_run_tall a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ap7_9).2.1 (hb) (hstrict) (ha) (hadjacent)

theorem HP_adjacent_outer_short_pair_pruned_node095 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht8 : world (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap7_8 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have in8 := inside (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht8
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have allowed8 := avoid (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht8
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht0 ht8
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht1 ht8
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht2 ht8
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3 ht8
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht4 ht8
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht5 ht8
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht6 ht8
  have pairAllowed7_8 := avoidPair (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht7 ht8
  have support : HP_adjacent_outer_short_pair_pruned_Box a b (5 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n095_point a b (hb) ((by simpa only [HP_adjacent_outer_short_pair_pruned_Box,HP_adjacent_outer_short_pair_pruned_M] using absent)) (ap5_8).2.2.1 (hlong) (ha) (hstrict) (hadjacent)
  have empty : ¬(Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (5 : Int) (3 : Int) ∨ Contains (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (5 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n095_empty a b ((by simpa only [Contains] using occupied)) (hlong) (hb) (ha) (hstrict) (hadjacent)
  obtain ⟨t,ht,hit⟩ := cover (5 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5
  have pairAllowed6 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht6
  have pairAllowed7 := avoidPair t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht7
  have pairAllowed8 := avoidPair t (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht8
  have sep0 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (5 : Int) (3 : Int) a b (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n095_o0 a b jx jy (insideT) (hit) (sep8).2.1 (ap5_8).2.2.1 (sep8).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (hlong) (hb) (ha) (hstrict) (hadjacent)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8
    exact HP_adjacent_outer_short_pair_pruned_node096 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 (apart_sym sep4) ap5_6 ap5_7 ap5_8 (apart_sym sep5) ap6_7 ap6_8 (apart_sym sep6) ap7_8 (apart_sym sep7) (apart_sym sep8)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n095_o1 a b jx jy (hit) (sep7).2.2.1 (hb) (insideT) (hlong) (ap5_8).2.2.1 (sep4).2.2.1 (ha) (hstrict) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n095_o2 a b jx jy (hb) (sep7).2.2.1 (hlong) (ap5_8).2.2.1 (hit) (sep4).2.1 (insideT) (ha) (hstrict) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((5 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n095_o3 a b jx jy (sep1).1 (hlong) (ap5_8).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (hb) (sep8).2.1 (insideT) (hit) (sep4).2.1 (ha) (hstrict) (hadjacent)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8
    exact HP_adjacent_outer_short_pair_pruned_node097 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 (apart_sym sep4) ap5_6 ap5_7 ap5_8 (apart_sym sep5) ap6_7 ap6_8 (apart_sym sep6) ap7_8 (apart_sym sep7) (apart_sym sep8)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n095_o4 a b jx jy (hb) (sep7).2.2.1 (ap5_8).2.2.1 (insideT) (hit) (hlong) (sep4).2.1 (ha) (hstrict) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((5 : Int) + a) (3 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n095_o5 a b jx jy (ap5_8).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (sep8).2.1 (hit) (insideT) (sep1).2.1 (hlong) (hb) (ha) (hstrict) (hadjacent)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8
    exact HP_adjacent_outer_short_pair_pruned_node098 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 (apart_sym sep4) ap5_6 ap5_7 ap5_8 (apart_sym sep5) ap6_7 ap6_8 (apart_sym sep6) ap7_8 (apart_sym sep7) (apart_sym sep8)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n095_o6 a b jx jy (sep8).2.1 (hit) (insideT) (sep8).2.2.1 (sep7).2.2.1 (hb) (ap5_8).2.2.1 (hlong) (ha) (hstrict) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (5 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n095_o7 a b jx jy (insideT) (ap5_8).2.2.1 (sep8).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (hit) (hlong) (hb) (ha) (hstrict) (hadjacent)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8
    exact HP_adjacent_outer_short_pair_pruned_node099 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 (apart_sym sep4) ap5_6 ap5_7 ap5_8 (apart_sym sep5) ap6_7 ap6_8 (apart_sym sep6) ap7_8 (apart_sym sep7) (apart_sym sep8)

theorem HP_adjacent_outer_short_pair_pruned_node100 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht8 : world (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap7_8 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have in8 := inside (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht8
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have allowed8 := avoid (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht8
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht0 ht8
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht1 ht8
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht2 ht8
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht3 ht8
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht4 ht8
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht5 ht8
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht6 ht8
  have pairAllowed7_8 := avoidPair (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht7 ht8
  apply avoidRun [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a), (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a), (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int))] (4 : Int) ((3 : Int) + b) (3 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n100_run_four a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (ha) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n100_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n100_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n100_run_empty a b run_x (hx1) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx0) (hadjacent) (hlong) (hstrict) (ha) (hb)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n100_run_floor a b run_x (hx0) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx1) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n100_run_left a b (hlong) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n100_run_right a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n100_run_tall a b (hb) (hstrict) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hlong) (hadjacent)

theorem HP_adjacent_outer_short_pair_pruned_node102 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht8 : world (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ht9 : world (Cross.mk ((4 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_9 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_9 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap3_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap4_9 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap5_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap6_9 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap7_8 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap7_9 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((4 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap8_9 : Apart (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have in8 := inside (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht8
  have in9 := inside (Cross.mk ((4 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht9
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have allowed8 := avoid (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk ((4 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht9
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht8
  have pairAllowed0_9 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht0 ht9
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht8
  have pairAllowed1_9 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht1 ht9
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht8
  have pairAllowed2_9 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht2 ht9
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3 ht8
  have pairAllowed3_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht3 ht9
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4 ht8
  have pairAllowed4_9 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht4 ht9
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht5 ht8
  have pairAllowed5_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht5 ht9
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht6 ht8
  have pairAllowed6_9 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht6 ht9
  have pairAllowed7_8 := avoidPair (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht7 ht8
  have pairAllowed7_9 := avoidPair (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((4 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht7 ht9
  have pairAllowed8_9 := avoidPair (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht8 ht9
  apply avoidRun [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a), (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a), (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((4 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int))] (4 : Int) ((3 : Int) + b) (4 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n102_run_four a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (ha) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n102_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n102_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n102_run_empty a b run_x (hstrict) (hx0) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx1) (hlong) (hadjacent) (ha) (hb)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n102_run_floor a b run_x (hx1) (hx0) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n102_run_left a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n102_run_right a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n102_run_tall a b (hstrict) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (hb) (ha) (hadjacent)

theorem HP_adjacent_outer_short_pair_pruned_node103 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht8 : world (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ht9 : world (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_9 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_9 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap3_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap4_9 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap5_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap6_9 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap7_8 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap7_9 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap8_9 : Apart (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have in8 := inside (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht8
  have in9 := inside (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht9
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have allowed8 := avoid (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht8
  have allowed9 := avoid (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht9
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht8
  have pairAllowed0_9 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht9
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht8
  have pairAllowed1_9 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht9
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht8
  have pairAllowed2_9 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht9
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3 ht8
  have pairAllowed3_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht3 ht9
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4 ht8
  have pairAllowed4_9 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht4 ht9
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht5 ht8
  have pairAllowed5_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht5 ht9
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht6 ht8
  have pairAllowed6_9 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht6 ht9
  have pairAllowed7_8 := avoidPair (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht7 ht8
  have pairAllowed7_9 := avoidPair (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht7 ht9
  have pairAllowed8_9 := avoidPair (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) ht8 ht9
  apply avoidRunRight [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a), (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a), (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b)] (3 : Int) ((2 : Int) + b) (5 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n103_run_four a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (ha) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n103_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n103_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n103_run_empty a b run_x (hlong) (ap7_9).2.1 (hadjacent) (hb) (ha) (hstrict)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n103_run_floor a b run_x (hx0) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx1) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n103_run_left a b (hlong) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n103_run_right a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n103_run_tall a b (hb) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hstrict) (ha) (hlong) (hadjacent)

theorem HP_adjacent_outer_short_pair_pruned_node101 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht8 : world (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap7_8 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have in8 := inside (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht8
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have allowed8 := avoid (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht8
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht8
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht8
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht8
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3 ht8
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4 ht8
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht5 ht8
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht6 ht8
  have pairAllowed7_8 := avoidPair (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht7 ht8
  have support : HP_adjacent_outer_short_pair_pruned_Box a b (4 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n101_point a b ((by simpa only [HP_adjacent_outer_short_pair_pruned_Box,HP_adjacent_outer_short_pair_pruned_M] using absent)) (hlong) (hb) (ap5_8).2.2.1 (ha) (hstrict) (hadjacent)
  have empty : ¬(Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n101_empty a b (hb) ((by simpa only [Contains] using occupied)) (hlong) (ha) (hstrict) (hadjacent)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5
  have pairAllowed6 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht6
  have pairAllowed7 := avoidPair t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht7
  have pairAllowed8 := avoidPair t (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht8
  have sep0 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n101_o0 a b jx jy (insideT) (ap5_8).2.2.1 (sep7).2.1 (sep8).2.2.1 (sep8).2.1 (hb) (hit) (hlong) (ha) (hstrict) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n101_o1 a b jx jy (insideT) (hlong) (sep7).2.2.1 (hit) (hb) (ap5_8).2.2.1 (sep4).2.2.1 (ha) (hstrict) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n101_o2 a b jx jy (ap5_8).2.2.1 (hlong) (hb) (hit) (sep4).2.1 (insideT) (sep7).2.2.1 (ha) (hstrict) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n101_o3 a b jx jy (hit) (hlong) (sep8).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (hb) (sep7).2.1 (ap5_8).2.2.1 (insideT) (ha) (hstrict) (hadjacent)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8
    exact HP_adjacent_outer_short_pair_pruned_node102 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 (apart_sym sep4) ap5_6 ap5_7 ap5_8 (apart_sym sep5) ap6_7 ap6_8 (apart_sym sep6) ap7_8 (apart_sym sep7) (apart_sym sep8)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n101_o4 a b jx jy (sep7).2.2.1 (ap5_8).2.2.1 (hit) (insideT) (sep4).2.1 (hlong) (hb) (ha) (hstrict) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n101_o5 a b jx jy (ap5_8).2.2.1 (sep8).2.2.2 (sep7).2.1 (hit) (insideT) (hlong) (sep0).2.1 (hb) (ha) (hstrict) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n101_o6 a b jx jy (sep7).2.2.1 (ap5_8).2.2.1 (sep7).2.1 (hlong) (hit) (sep4).2.2.1 (insideT) (hb) (ha) (hstrict) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (4 : Int) ((3 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n101_o7 a b jx jy (ap5_8).2.2.1 (sep8).2.1 ((by simpa only [Same,eq_comm] using absent)) (hit) (hlong) (hb) (insideT) (ha) (hstrict) (hadjacent)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8
    exact HP_adjacent_outer_short_pair_pruned_node103 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 (apart_sym sep4) ap5_6 ap5_7 ap5_8 (apart_sym sep5) ap6_7 ap6_8 (apart_sym sep6) ap7_8 (apart_sym sep7) (apart_sym sep8)

theorem HP_adjacent_outer_short_pair_pruned_node104 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht8 : world (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap7_8 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have in8 := inside (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht8
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have allowed8 := avoid (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht8
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht8
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht8
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht8
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3 ht8
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht4 ht8
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht5 ht8
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht6 ht8
  have pairAllowed7_8 := avoidPair (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht7 ht8
  apply avoidRunRight [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a), (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a), (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b)] (2 : Int) ((1 : Int) + b) (5 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n104_run_four a b (hb) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n104_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n104_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n104_run_empty a b run_x (hx0) (hb) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (hx1) (hstrict) (ha) (hadjacent)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n104_run_floor a b run_x (hx1) (hx0) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n104_run_left a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (ha) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n104_run_right a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n104_run_tall a b (hb) (hstrict) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hlong) (hadjacent)

theorem HP_adjacent_outer_short_pair_pruned_node094 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht7
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht7
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht7
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht7
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4 ht7
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5 ht7
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6 ht7
  have support : HP_adjacent_outer_short_pair_pruned_Box a b (4 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n094_point a b ((by simpa only [HP_adjacent_outer_short_pair_pruned_Box,HP_adjacent_outer_short_pair_pruned_M] using absent)) (hlong) (hb) (ha) (hstrict) (hadjacent)
  have empty : ¬(Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n094_empty a b (hb) ((by simpa only [Contains] using occupied)) (hlong) (ha) (hstrict) (hadjacent)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5
  have pairAllowed6 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht6
  have pairAllowed7 := avoidPair t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht7
  have sep0 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) (2 : Int) a b (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n094_o0 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (sep7).2.1 (insideT) (hb) (sep4).2.2.1 (hlong) (hadjacent) (hit) (ha) (hstrict)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_adjacent_outer_short_pair_pruned_node095 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n094_o1 a b jx jy (hlong) (insideT) (sep4).2.2.1 (hit) (hadjacent) (sep7).1 (ha) (hb) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n094_o2 a b jx jy (hit) (hlong) (sep4).2.1 (hb) (insideT) (hstrict) (ha) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n094_o3 a b jx jy (hit) (insideT) ((by simpa only [Same,eq_comm] using absent)) (sep7).2.1 (hlong) (sep1).2.1 (hadjacent) (ha) (hb) (hstrict)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_adjacent_outer_short_pair_pruned_node100 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n094_o4 a b jx jy (hit) (hlong) (sep7).2.1 (insideT) (hadjacent) (ha) (hb) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n094_o5 a b jx jy (insideT) (hb) (hadjacent) (hit) (sep4).2.2.1 (sep7).2.1 ((by simpa only [Same,eq_comm] using absent)) (hlong) (ha) (hstrict)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_adjacent_outer_short_pair_pruned_node101 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n094_o6 a b jx jy (sep7).2.2.1 (hit) (sep4).2.2.1 (sep7).2.1 (hadjacent) (hlong) (insideT) (ha) (hb) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (4 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n094_o7 a b jx jy (hb) (hit) (hlong) ((by simpa only [Same,eq_comm] using absent)) (hadjacent) (insideT) (sep4).2.2.1 (ha) (hstrict)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_adjacent_outer_short_pair_pruned_node104 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)

theorem HP_adjacent_outer_short_pair_pruned_node105 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht7
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht7
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht0 ht7
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht1 ht7
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht2 ht7
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht3 ht7
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht4 ht7
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht5 ht7
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht6 ht7
  apply avoidRun [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a), (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int))] (3 : Int) ((2 : Int) + b) (3 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n105_run_four a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (ha) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n105_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n105_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n105_run_empty a b run_x (hx0) (hx1) (hlong) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hadjacent) (hstrict) (ha) (hb)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n105_run_floor a b run_x ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx1) (hx0) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n105_run_left a b (hlong) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n105_run_right a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n105_run_tall a b (hb) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hstrict) (ha) (hlong) (hadjacent)

theorem HP_adjacent_outer_short_pair_pruned_node114 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ht8 : world (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht9 : world (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_9 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_9 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_9 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap5_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap6_9 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap7_8 : Apart (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap7_9 : Apart (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap8_9 : Apart (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht7
  have in8 := inside (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht8
  have in9 := inside (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht9
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht8
  have allowed9 := avoid (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht9
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht8
  have pairAllowed0_9 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht9
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht8
  have pairAllowed1_9 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht9
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht8
  have pairAllowed2_9 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht9
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht8
  have pairAllowed3_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht9
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4 ht8
  have pairAllowed4_9 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht4 ht9
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5 ht8
  have pairAllowed5_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht5 ht9
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6 ht8
  have pairAllowed6_9 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht6 ht9
  have pairAllowed7_8 := avoidPair (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7 ht8
  have pairAllowed7_9 := avoidPair (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht7 ht9
  have pairAllowed8_9 := avoidPair (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) ht8 ht9
  apply avoidRunDown [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a), (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a), (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a)] (5 : Int) ((3 : Int) + a) ((-2 : Int) + ((-1 : Int) * a))
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n114_run_four a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n114_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hadjacent) (ha) (hb) (hstrict) (hlong)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n114_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n114_run_empty a b run_x (hstrict) (ap0_2).1 (hx0) (hx1) (ha) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (hb) (hadjacent)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n114_run_floor a b run_x (hx1) (hx0) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hadjacent) (ha) (hb) (hstrict) (hlong)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n114_run_left a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n114_run_right a b (hb) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n114_run_tall a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (hb) (ha) (hstrict) (hadjacent)

theorem HP_adjacent_outer_short_pair_pruned_node115 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ht8 : world (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht9 : world (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_9 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_9 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_9 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap5_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap6_9 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap7_8 : Apart (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap7_9 : Apart (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    (ap8_9 : Apart (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht7
  have in8 := inside (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht8
  have in9 := inside (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht9
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht8
  have allowed9 := avoid (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht9
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht8
  have pairAllowed0_9 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht0 ht9
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht8
  have pairAllowed1_9 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht1 ht9
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht8
  have pairAllowed2_9 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht2 ht9
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht8
  have pairAllowed3_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht3 ht9
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4 ht8
  have pairAllowed4_9 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht4 ht9
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5 ht8
  have pairAllowed5_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht5 ht9
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6 ht8
  have pairAllowed6_9 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht6 ht9
  have pairAllowed7_8 := avoidPair (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7 ht8
  have pairAllowed7_9 := avoidPair (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht7 ht9
  have pairAllowed8_9 := avoidPair (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) ht8 ht9
  apply avoidRun [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a), (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a), (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int))] (3 : Int) ((2 : Int) + b) (4 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n115_run_four a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (ha) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n115_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n115_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n115_run_empty a b run_x (hstrict) (hadjacent) (hx0) (hlong) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx1) (ha) (hb)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n115_run_floor a b run_x (hx1) (hx0) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n115_run_left a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n115_run_right a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n115_run_tall a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (hb) (hstrict) (ha) (hadjacent)

theorem HP_adjacent_outer_short_pair_pruned_node116 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ht8 : world (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht9 : world (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_9 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_9 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_9 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap5_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap6_9 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap7_8 : Apart (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap7_9 : Apart (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap8_9 : Apart (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht7
  have in8 := inside (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht8
  have in9 := inside (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht9
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht8
  have allowed9 := avoid (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht9
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht8
  have pairAllowed0_9 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht9
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht8
  have pairAllowed1_9 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht9
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht8
  have pairAllowed2_9 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht9
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht8
  have pairAllowed3_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht9
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4 ht8
  have pairAllowed4_9 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht9
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5 ht8
  have pairAllowed5_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht9
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6 ht8
  have pairAllowed6_9 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht6 ht9
  have pairAllowed7_8 := avoidPair (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7 ht8
  have pairAllowed7_9 := avoidPair (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht7 ht9
  have pairAllowed8_9 := avoidPair (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) ht8 ht9
  apply avoidRun [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a), (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a), (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a)] (3 : Int) (3 : Int) (3 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n116_run_four a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n116_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (ha) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n116_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n116_run_empty a b run_x (ap5_7).2.2.1 (ap5_8).2.2.2 (hlong) (hb) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx0) (hx1) (ha) (hstrict) (hadjacent)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n116_run_floor a b run_x (hx0) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (hx1) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n116_run_left a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n116_run_right a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n116_run_tall a b (hb) (hstrict) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hlong) (hadjacent)

theorem HP_adjacent_outer_short_pair_pruned_node117 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ht8 : world (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht9 : world (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_9 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_9 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_9 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_9 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap5_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_9 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap6_9 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap7_8 : Apart (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap7_9 : Apart (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    (ap8_9 : Apart (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht7
  have in8 := inside (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht8
  have in9 := inside (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht9
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht8
  have allowed9 := avoid (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht9
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht8
  have pairAllowed0_9 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht0 ht9
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht8
  have pairAllowed1_9 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht1 ht9
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht8
  have pairAllowed2_9 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht2 ht9
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht8
  have pairAllowed3_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht3 ht9
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4 ht8
  have pairAllowed4_9 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht4 ht9
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5 ht8
  have pairAllowed5_9 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht5 ht9
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6 ht8
  have pairAllowed6_9 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht6 ht9
  have pairAllowed7_8 := avoidPair (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7 ht8
  have pairAllowed7_9 := avoidPair (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht7 ht9
  have pairAllowed8_9 := avoidPair (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) ht8 ht9
  apply avoidRun [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a), (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a), (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int))] (4 : Int) ((2 : Int) + a) (4 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n117_run_four a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n117_run_short a b (hadjacent) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n117_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n117_run_empty a b run_x (hx1) (hx0) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ap5_7).2.2.1 (ap5_8).2.2.2 (hlong) (hb) (ha) (hstrict) (hadjacent)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n117_run_floor a b run_x (hx0) (hx1) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hadjacent) (ha) (hb) (hstrict) (hlong)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n117_run_left a b (hlong) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n117_run_right a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (ha) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n117_run_tall a b (hstrict) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (hlong) (ha) (hadjacent)

theorem HP_adjacent_outer_short_pair_pruned_node113 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ht8 : world (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap5_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap7_8 : Apart (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht7
  have in8 := inside (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht8
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht8
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht8
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht8
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht8
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht8
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4 ht8
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5 ht8
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6 ht8
  have pairAllowed7_8 := avoidPair (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7 ht8
  have support : HP_adjacent_outer_short_pair_pruned_Box a b (4 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n113_point a b (ap5_8).2.2.2 ((by simpa only [HP_adjacent_outer_short_pair_pruned_Box,HP_adjacent_outer_short_pair_pruned_M] using absent)) (hb) (ap5_7).2.2.1 (hlong) (ha) (hstrict) (hadjacent)
  have empty : ¬(Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n113_empty a b (hb) ((by simpa only [Contains] using occupied)) (hlong) (ha) (hstrict) (hadjacent)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5
  have pairAllowed6 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht6
  have pairAllowed7 := avoidPair t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht7
  have pairAllowed8 := avoidPair t (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht8
  have sep0 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))))
    · exact ap
  have sep8 : Apart t (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht8 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n113_o0 a b jx jy (sep6).2.1 (ap5_7).2.2.1 (hit) (sep7).2.2.1 (ap5_8).2.2.2 (sep7).2.1 (insideT) (hlong) (hb) (ha) (hstrict) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (4 : Int) ((3 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n113_o1 a b jx jy (hlong) (sep7).2.2.1 (hit) (insideT) ((by simpa only [Same,eq_comm] using absent)) (ha) (hb) (hstrict) (hadjacent)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8
    exact HP_adjacent_outer_short_pair_pruned_node114 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 (apart_sym sep4) ap5_6 ap5_7 ap5_8 (apart_sym sep5) ap6_7 ap6_8 (apart_sym sep6) ap7_8 (apart_sym sep7) (apart_sym sep8)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n113_o2 a b jx jy (sep6).2.1 (hit) (ap5_8).2.2.2 (insideT) (hstrict) (ap5_7).2.2.1 (hlong) (hb) (ha) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) (3 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n113_o3 a b jx jy (sep1).2.1 (sep7).2.2.2 (hit) (sep6).2.1 (insideT) (ap5_7).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (hb) (ap5_8).2.2.2 (hadjacent) (hlong) (hstrict) (ha)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8
    exact HP_adjacent_outer_short_pair_pruned_node115 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 (apart_sym sep4) ap5_6 ap5_7 ap5_8 (apart_sym sep5) ap6_7 ap6_8 (apart_sym sep6) ap7_8 (apart_sym sep7) (apart_sym sep8)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (4 : Int) ((3 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n113_o4 a b jx jy (insideT) (hit) (ap5_8).2.2.2 ((by simpa only [Same,eq_comm] using absent)) (ap5_7).2.2.1 (hlong) (sep6).2.1 (hb) (ha) (hstrict) (hadjacent)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8
    exact HP_adjacent_outer_short_pair_pruned_node116 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 (apart_sym sep4) ap5_6 ap5_7 ap5_8 (apart_sym sep5) ap6_7 ap6_8 (apart_sym sep6) ap7_8 (apart_sym sep7) (apart_sym sep8)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n113_o5 a b jx jy (sep8).2.2.2 (sep6).2.1 (sep1).2.1 (hit) (sep7).2.2.2 (ap5_7).2.2.1 (insideT) (ap5_8).2.2.2 (hlong) (hb) (ha) (hstrict) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (3 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n113_o6 a b jx jy (sep7).2.1 (hadjacent) (hstrict) (hit) (hlong) (insideT) (sep6).2.1 ((by simpa only [Same,eq_comm] using absent)) (ap5_7).2.2.1 (hb) (ap5_8).2.2.2 (sep7).2.2.1 (ha)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7 sep8
    exact HP_adjacent_outer_short_pair_pruned_node117 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht8 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 ap0_8 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 ap1_8 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 ap2_8 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 ap3_8 (apart_sym sep3) ap4_5 ap4_6 ap4_7 ap4_8 (apart_sym sep4) ap5_6 ap5_7 ap5_8 (apart_sym sep5) ap6_7 ap6_8 (apart_sym sep6) ap7_8 (apart_sym sep7) (apart_sym sep8)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n113_o7 a b jx jy (ap5_8).2.2.2 (hb) (ap5_7).2.2.1 (sep8).2.1 (hit) (insideT) (hlong) (hstrict) (ha) (hadjacent)

theorem HP_adjacent_outer_short_pair_pruned_node118 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ht8 : world (Cross.mk ((4 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap5_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap7_8 : Apart (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht7
  have in8 := inside (Cross.mk ((4 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht8
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk ((4 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht8
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht8
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht8
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht8
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht8
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht8
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht8
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6 ht8
  have pairAllowed7_8 := avoidPair (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht7 ht8
  apply avoidRunLeft [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a), (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((4 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a)] (3 : Int) ((1 : Int) + a) ((-2 : Int) + ((-1 : Int) * a))
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n118_run_four a b (hlong) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n118_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hadjacent) (ha) (hb) (hstrict) (hlong)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n118_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n118_run_empty a b run_x ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (ap0_2).1 (hx1) (hb) (ap5_7).2.2.1 (hlong) (hx0) (hstrict) (hadjacent)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n118_run_floor a b run_x ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx1) (hadjacent) (hx0) (ha) (hb) (hstrict) (hlong)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n118_run_left a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n118_run_right a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (ha) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n118_run_tall a b (hlong) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (hstrict) (ha) (hadjacent)

theorem HP_adjacent_outer_short_pair_pruned_node106 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht7
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht7
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht7
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht7
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht7
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3 ht7
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4 ht7
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht5 ht7
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht6 ht7
  have support : HP_adjacent_outer_short_pair_pruned_Box a b ((4 : Int) + a) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n106_point a b (hlong) (ap5_7).2.2.1 ((by simpa only [HP_adjacent_outer_short_pair_pruned_Box,HP_adjacent_outer_short_pair_pruned_M] using absent)) (hb) (ha) (hstrict) (hadjacent)
  have empty : ¬(Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ((4 : Int) + a) (2 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ((4 : Int) + a) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ((4 : Int) + a) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ((4 : Int) + a) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ((4 : Int) + a) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ((4 : Int) + a) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ((4 : Int) + a) (2 : Int) ∨ Contains (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ((4 : Int) + a) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n106_empty a b (ap0_2).1 (hadjacent) (hlong) ((by simpa only [Contains] using occupied)) (ha) (hb) (hstrict)
  obtain ⟨t,ht,hit⟩ := cover ((4 : Int) + a) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5
  have pairAllowed6 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht6
  have pairAllowed7 := avoidPair t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht7
  have sep0 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n106_o0 a b jx jy (sep3).2.1 (ap5_7).2.2.1 (hadjacent) (hit) (hlong) (sep7).2.2.1 (insideT) (hb) (ha) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n106_o1 a b jx jy (sep5).2.1 ((by simpa only [Same,eq_comm] using absent)) (insideT) (hstrict) (hit) (hadjacent) (hlong) (ha) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_adjacent_outer_short_pair_pruned_node113 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n106_o2 a b jx jy (hit) (hb) (ap5_7).2.2.1 (hlong) (insideT) (sep7).2.1 (ha) (hstrict) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n106_o3 a b jx jy (sep7).1 (hit) (hstrict) (insideT) (sep5).2.2.1 (sep2).2.1 (hadjacent) (hlong) (ha) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n106_o4 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hstrict) (hlong) (insideT) (sep5).2.2.1 (hadjacent) (hit) (ha) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_adjacent_outer_short_pair_pruned_node118 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n106_o5 a b jx jy (sep4).2.2.1 (hb) (hit) (insideT) (sep1).2.2.2 (sep0).2.2.2 (ap5_7).2.2.1 (sep7).2.1 (sep2).2.1 (sep3).2.1 (hadjacent) (sep5).2.2.1 (hlong) (hstrict) (ha)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n106_o6 a b jx jy (hit) (insideT) (sep7).2.2.1 (hlong) (hstrict) (sep2).2.1 (hadjacent) (ha) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n106_o7 a b jx jy (insideT) (ap5_7).2.2.1 (hadjacent) (sep5).2.1 (hit) (hlong) (hstrict) (hb) (ha)

theorem HP_adjacent_outer_short_pair_pruned_node120 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap7_8 : Apart (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht8
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht8
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht8
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht8
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht8
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht8
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4 ht8
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5 ht8
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6 ht8
  have pairAllowed7_8 := avoidPair (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7 ht8
  apply avoidRun [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a), (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a)] ((5 : Int) + b) ((1 : Int) + ((2 : Int) * b)) (2 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n120_run_four a b (hlong) (hadjacent) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n120_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n120_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n120_run_empty a b run_x ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (hx0) (hx1) (hstrict) (ha) (hb) (hadjacent)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n120_run_floor a b run_x ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx1) (hx0) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n120_run_left a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n120_run_right a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n120_run_tall a b (hstrict) (hb) (ha) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (hadjacent)

theorem HP_adjacent_outer_short_pair_pruned_node121 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht8 : world (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_8 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_8 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_8 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap3_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap4_8 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap5_8 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap6_8 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap7_8 : Apart (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht7
  have in8 := inside (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht8
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht7
  have allowed8 := avoid (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht8
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht0 ht7
  have pairAllowed0_8 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht8
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht1 ht7
  have pairAllowed1_8 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht8
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2 ht7
  have pairAllowed2_8 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht8
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3 ht7
  have pairAllowed3_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht8
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht4 ht7
  have pairAllowed4_8 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht8
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht5 ht7
  have pairAllowed5_8 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht8
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht6 ht7
  have pairAllowed6_8 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6 ht8
  have pairAllowed7_8 := avoidPair (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht7 ht8
  apply avoidRun [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a), (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a)] (4 : Int) ((3 : Int) + b) (3 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n121_run_four a b (hb) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n121_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n121_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n121_run_empty a b run_x (hlong) (hadjacent) (hx0) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hstrict) (hx1) (ha) (hb)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n121_run_floor a b run_x (hx0) (hx1) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n121_run_left a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n121_run_right a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n121_run_tall a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hstrict) (hb) (ha) (hlong) (hadjacent)

theorem HP_adjacent_outer_short_pair_pruned_node119 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht7
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht7
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht0 ht7
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht1 ht7
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2 ht7
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3 ht7
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht4 ht7
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht5 ht7
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht6 ht7
  have support : HP_adjacent_outer_short_pair_pruned_Box a b ((4 : Int) + b) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n119_point a b ((by simpa only [HP_adjacent_outer_short_pair_pruned_Box,HP_adjacent_outer_short_pair_pruned_M] using absent)) (hlong) (hb) (ha) (hstrict) (hadjacent)
  have empty : ¬(Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ((4 : Int) + b) (2 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ((4 : Int) + b) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ((4 : Int) + b) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ((4 : Int) + b) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ((4 : Int) + b) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ((4 : Int) + b) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ((4 : Int) + b) (2 : Int) ∨ Contains (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ((4 : Int) + b) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n119_empty a b (hlong) (ap2_7).2.2.1 (ap0_5).2.2.1 ((by simpa only [Contains] using occupied)) (hstrict) (hb) (ha) (hadjacent)
  obtain ⟨t,ht,hit⟩ := cover ((4 : Int) + b) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5
  have pairAllowed6 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht6
  have pairAllowed7 := avoidPair t (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht7
  have sep0 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))))
    · exact ap
  have sep7 : Apart t (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht7 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n119_o0 a b jx jy (hlong) (hit) (hstrict) (insideT) (sep7).2.2.1 (sep5).2.1 (hadjacent) (hb) (sep5).2.2.1 (ha)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n119_o1 a b jx jy (hit) (hadjacent) (insideT) (hlong) (sep5).2.1 ((by simpa only [Same,eq_comm] using absent)) (ha) (hb) (hstrict)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_adjacent_outer_short_pair_pruned_node120 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n119_o2 a b jx jy (sep7).2.1 (hb) (hit) (insideT) (hlong) (hadjacent) (hstrict) (ha)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n119_o3 a b jx jy (sep5).2.2.1 (sep2).2.1 (hadjacent) (hlong) (hit) (sep7).1 (insideT) (hstrict) (ha) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n119_o4 a b jx jy (insideT) ((by simpa only [Same,eq_comm] using absent)) (hit) (hadjacent) (sep5).2.2.1 (hlong) (ha) (hb) (hstrict)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6 sep7
    exact HP_adjacent_outer_short_pair_pruned_node121 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht7 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 ap0_7 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 ap1_7 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 ap2_7 (apart_sym sep2) ap3_4 ap3_5 ap3_6 ap3_7 (apart_sym sep3) ap4_5 ap4_6 ap4_7 (apart_sym sep4) ap5_6 ap5_7 (apart_sym sep5) ap6_7 (apart_sym sep6) (apart_sym sep7)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n119_o5 a b jx jy (insideT) (sep7).2.1 (hb) (sep7).1 (sep2).2.1 (sep5).2.2.1 (hstrict) (hit) (hadjacent) (hlong) (ha)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n119_o6 a b jx jy (hit) (hadjacent) (sep5).2.1 (insideT) (hlong) (sep5).2.2.1 (sep7).2.2.1 (ha) (hb) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n119_o7 a b jx jy (sep5).2.1 (hb) (hit) (insideT) (hadjacent) (hlong) (hstrict) (ha)

theorem HP_adjacent_outer_short_pair_pruned_node122 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht7 : world (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap6_7 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have in7 := inside (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht7
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed7 := avoid (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht7
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht7
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht7
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht7
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3 ht7
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht4 ht7
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht5 ht7
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht6 ht7
  apply avoidRunRight [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a), (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b)] (2 : Int) a (4 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n122_run_four a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n122_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hadjacent) (ha) (hb) (hstrict) (hlong)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n122_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n122_run_empty a b run_x (hx1) (hlong) (hb) (hx0) (hadjacent) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hstrict)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n122_run_floor a b run_x (hadjacent) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx1) (hx0) (ha) (hb) (hstrict) (hlong)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n122_run_left a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (ha) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n122_run_right a b (hstrict) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hadjacent) (hlong) (ha) (hb)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n122_run_tall a b (hb) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hstrict) (hadjacent)

theorem HP_adjacent_outer_short_pair_pruned_node063 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht6
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht6
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht6
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht6
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht6
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht6
  have support : HP_adjacent_outer_short_pair_pruned_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n063_point a b (hlong) (hb) ((by simpa only [HP_adjacent_outer_short_pair_pruned_Box,HP_adjacent_outer_short_pair_pruned_M] using absent)) (ha) (hstrict) (hadjacent)
  have empty : ¬(Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n063_empty a b (hlong) ((by simpa only [Contains] using occupied)) (hb) (ha) (hstrict) (hadjacent)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5
  have pairAllowed6 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht6
  have sep0 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n063_o0 a b jx jy (hb) (hit) (sep4).2.2.1 (hadjacent) (sep6).2.1 ((by simpa only [Same,eq_comm] using absent)) (hlong) (insideT) (ha) (hstrict)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_adjacent_outer_short_pair_pruned_node064 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n063_o1 a b jx jy (sep4).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (insideT) (hlong) (hit) (hadjacent) (ha) (hb) (hstrict)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_adjacent_outer_short_pair_pruned_node094 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n063_o2 a b jx jy (hit) (hstrict) (sep4).2.1 (insideT) (hlong) (hb) (ha) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n063_o3 a b jx jy (sep6).2.1 (insideT) ((by simpa only [Same,eq_comm] using absent)) (sep1).2.1 (hit) (hadjacent) (hlong) (ha) (hb) (hstrict)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_adjacent_outer_short_pair_pruned_node105 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n063_o4 a b jx jy (hlong) (insideT) (sep6).2.1 (hadjacent) (hit) (ha) (hb) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n063_o5 a b jx jy (hadjacent) ((by simpa only [Same,eq_comm] using absent)) (sep1).2.1 (sep6).2.1 (hit) (insideT) (hlong) (ha) (hb) (hstrict)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_adjacent_outer_short_pair_pruned_node106 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n063_o6 a b jx jy (hadjacent) (sep6).2.1 ((by simpa only [Same,eq_comm] using absent)) (sep4).2.2.1 (hit) (hlong) (insideT) (ha) (hb) (hstrict)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_adjacent_outer_short_pair_pruned_node119 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n063_o7 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (insideT) (sep4).2.2.1 (hit) (hb) (hadjacent) (hlong) (ha) (hstrict)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_adjacent_outer_short_pair_pruned_node122 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)

theorem HP_adjacent_outer_short_pair_pruned_node124 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ht7 : world (Cross.mk ((3 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap6_7 : Apart (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht6
  have in7 := inside (Cross.mk ((3 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk ((3 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht7
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht7
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht7
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht7
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4 ht7
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5 ht7
  have pairAllowed6_7 := avoidPair (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6 ht7
  apply avoidRun [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((3 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a)] ((4 : Int) + a) ((1 : Int) + ((2 : Int) * b)) (2 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n124_run_four a b (hlong) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hadjacent) (ha) (hb) (hstrict)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n124_run_short a b (ha) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n124_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n124_run_empty a b run_x (hx1) (hx0) (hstrict) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hadjacent)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n124_run_floor a b run_x ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx1) (hx0) (hlong) (hb) (ha) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n124_run_left a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n124_run_right a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n124_run_tall a b (hlong) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hstrict) (ap5_6).2.2.1 (hb) (ha) (hadjacent)

theorem HP_adjacent_outer_short_pair_pruned_node125 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ht7 : world (Cross.mk ((3 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap6_7 : Apart (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht6
  have in7 := inside (Cross.mk ((3 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht7
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk ((3 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht7
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht7
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht7
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht7
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht7
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht7
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht7
  have pairAllowed6_7 := avoidPair (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6 ht7
  apply avoidRunLeft [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((3 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a)] (3 : Int) ((1 : Int) + a) ((-1 : Int) + ((-1 : Int) * a))
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n125_run_four a b (hlong) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n125_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hadjacent) (ha) (hb) (hstrict) (hlong)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n125_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n125_run_empty a b run_x (hstrict) (hb) (hx1) (ap0_2).1 (hx0) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ap5_6).2.2.1 (hlong) (ha) (hadjacent)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n125_run_floor a b run_x (hadjacent) (hx0) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx1) (ha) (hb) (hstrict) (hlong)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n125_run_left a b (hlong) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n125_run_right a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (ha) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n125_run_tall a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (hlong) (hstrict) (ha) (hadjacent)

theorem HP_adjacent_outer_short_pair_pruned_node123 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht6
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht6
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht6
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht6
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht6
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3 ht6
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4 ht6
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht5 ht6
  have support : HP_adjacent_outer_short_pair_pruned_Box a b ((3 : Int) + a) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n123_point a b ((by simpa only [HP_adjacent_outer_short_pair_pruned_Box,HP_adjacent_outer_short_pair_pruned_M] using absent)) (hlong) (hb) (ha) (hstrict) (hadjacent)
  have empty : ¬(Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ((3 : Int) + a) (2 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ((3 : Int) + a) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ((3 : Int) + a) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ((3 : Int) + a) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ((3 : Int) + a) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ((3 : Int) + a) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ((3 : Int) + a) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n123_empty a b (ap0_2).1 (hadjacent) (hlong) ((by simpa only [Contains] using occupied)) (ha) (hb) (hstrict)
  obtain ⟨t,ht,hit⟩ := cover ((3 : Int) + a) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5
  have pairAllowed6 := avoidPair t (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht6
  have sep0 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n123_o0 a b jx jy (insideT) (sep3).2.1 (hit) (hb) (sep6).2.2.1 (hadjacent) (hlong) (ha) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n123_o1 a b jx jy (insideT) (hit) (sep5).2.1 (hadjacent) (hlong) ((by simpa only [Same,eq_comm] using absent)) (hstrict) (ha) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_adjacent_outer_short_pair_pruned_node124 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n123_o2 a b jx jy (hb) (hit) (sep6).2.1 (insideT) (hlong) (ha) (hstrict) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n123_o3 a b jx jy (sep5).2.1 (sep6).1 (sep5).2.2.1 (insideT) (hstrict) (sep6).2.1 (hit) (hadjacent) (hlong) (ha) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + a) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n123_o4 a b jx jy (insideT) (sep5).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (hstrict) (hit) (hadjacent) (hlong) (ha) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_adjacent_outer_short_pair_pruned_node125 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n123_o5 a b jx jy (sep3).2.1 (sep6).2.1 (hit) (sep5).2.2.1 (insideT) (hadjacent) (hlong) (hstrict) (hb) (ha)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n123_o6 a b jx jy (sep6).2.2.1 (sep2).2.1 (insideT) (hstrict) (hadjacent) (hit) (hlong) (ha) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n123_o7 a b jx jy (hit) (insideT) (hlong) (hb) (hadjacent) (sep5).2.1 (hstrict) (ha)

theorem HP_adjacent_outer_short_pair_pruned_node127 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht7 : world (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap6_7 : Apart (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht7
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht7
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht7
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht7
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht7
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4 ht7
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht5 ht7
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht6 ht7
  apply avoidRun [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a)] ((4 : Int) + b) ((1 : Int) + ((2 : Int) * b)) (2 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n127_run_four a b (hb) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n127_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n127_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n127_run_empty a b run_x (hb) (hx1) (hx0) (hstrict) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hadjacent)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n127_run_floor a b run_x (hx0) (hx1) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n127_run_left a b (hlong) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n127_run_right a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n127_run_tall a b (hb) (hstrict) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hlong) (hadjacent)

theorem HP_adjacent_outer_short_pair_pruned_node128 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht7 : world (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_7 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_7 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_7 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap3_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap4_7 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap5_7 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap6_7 : Apart (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht6
  have in7 := inside (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht7
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht6
  have allowed7 := avoid (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht7
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht0 ht6
  have pairAllowed0_7 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht7
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht1 ht6
  have pairAllowed1_7 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht7
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2 ht6
  have pairAllowed2_7 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht7
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3 ht6
  have pairAllowed3_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht7
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht4 ht6
  have pairAllowed4_7 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht4 ht7
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht5 ht6
  have pairAllowed5_7 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht5 ht7
  have pairAllowed6_7 := avoidPair (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht6 ht7
  apply avoidRun [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a)] ((4 : Int) + b) ((1 : Int) + ((2 : Int) * b)) (2 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n128_run_four a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (ha) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n128_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n128_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n128_run_empty a b run_x (hx0) (hstrict) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (hx1) (ha) (hlong) (hadjacent)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n128_run_floor a b run_x (hx1) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hx0) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n128_run_left a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n128_run_right a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hlong) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n128_run_tall a b (hlong) (hstrict) (hadjacent) (ha) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb)

theorem HP_adjacent_outer_short_pair_pruned_node126 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht6
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht6
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht0 ht6
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht1 ht6
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2 ht6
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3 ht6
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht4 ht6
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht5 ht6
  have support : HP_adjacent_outer_short_pair_pruned_Box a b ((3 : Int) + b) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n126_point a b (hb) (hlong) ((by simpa only [HP_adjacent_outer_short_pair_pruned_Box,HP_adjacent_outer_short_pair_pruned_M] using absent)) (ha) (hstrict) (hadjacent)
  have empty : ¬(Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ((3 : Int) + b) (2 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ((3 : Int) + b) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ((3 : Int) + b) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ((3 : Int) + b) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ((3 : Int) + b) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ((3 : Int) + b) (2 : Int) ∨ Contains (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ((3 : Int) + b) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n126_empty a b (ap0_5).2.2.1 (hstrict) (hlong) ((by simpa only [Contains] using occupied)) (ap2_6).2.2.1 (hb) (ha) (hadjacent)
  obtain ⟨t,ht,hit⟩ := cover ((3 : Int) + b) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5
  have pairAllowed6 := avoidPair t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht6
  have sep0 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n126_o0 a b jx jy (hb) (sep3).2.1 (hadjacent) (sep6).2.2.1 (hlong) (hit) (hstrict) (insideT) (ha)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n126_o1 a b jx jy (sep5).2.1 (hadjacent) (hit) (insideT) (hlong) ((by simpa only [Same,eq_comm] using absent)) (ha) (hb) (hstrict)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_adjacent_outer_short_pair_pruned_node127 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n126_o2 a b jx jy (hit) (hlong) (hadjacent) (insideT) (hstrict) (sep6).2.1 (hb) (ha)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n126_o3 a b jx jy (hlong) (hadjacent) (insideT) (sep6).1 (sep2).2.2.2 (hit) (sep5).2.2.1 (hstrict) (ha) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + b) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n126_o4 a b jx jy (hadjacent) (sep5).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (insideT) (hlong) (hit) (ha) (hb) (hstrict)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5 sep6
    exact HP_adjacent_outer_short_pair_pruned_node128 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht6 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 ap0_6 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 ap1_6 (apart_sym sep1) ap2_3 ap2_4 ap2_5 ap2_6 (apart_sym sep2) ap3_4 ap3_5 ap3_6 (apart_sym sep3) ap4_5 ap4_6 (apart_sym sep4) ap5_6 (apart_sym sep5) (apart_sym sep6)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n126_o5 a b jx jy (hit) (sep2).2.1 (insideT) (sep6).1 (hb) (hlong) (hadjacent) (sep5).2.2.1 (hstrict) (ha)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n126_o6 a b jx jy (hit) (sep6).2.2.1 (sep5).2.2.1 (insideT) ((by simpa only [HP_adjacent_outer_short_pair_pruned_ForbiddenPair, ForbiddenSameBoundaryBars, ForbiddenLongBoundaryCorner, LongBoundaryCorner, ForbiddenSameShortBars, ForbiddenOutwardLongBoundaryCorner, OutwardLongBoundaryCorner, ForbiddenShortUprightLong, ShortUprightLong, eq_comm] using pairAllowed6)) (hadjacent) (hlong) (ha) (hb) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n126_o7 a b jx jy (hadjacent) (hstrict) (sep5).2.1 (hb) (insideT) (hit) (hlong) (ha)

theorem HP_adjacent_outer_short_pair_pruned_node129 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ht6 : world (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_6 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_6 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_6 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap5_6 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have in6 := inside (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht6
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed6 := avoid (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht6
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht6
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht6
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht6
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3 ht6
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht4 ht6
  have pairAllowed5_6 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht5 ht6
  apply avoidRunRight [(Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)), (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)), (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)), (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b)] (2 : Int) a (3 : Int)
  · intro t ht
    simp only [List.mem_cons, List.not_mem_nil, or_false] at ht
    rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals assumption
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n129_run_four a b (hlong) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n129_run_short a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hadjacent) (ha) (hb) (hstrict) (hlong)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n129_run_nonnegative a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hb) (hstrict) (hlong) (hadjacent)
  · intro run_x hx0 hx1
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n129_run_empty a b run_x (hx1) (hb) (hlong) (hx0) (hadjacent) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (ha) (hstrict)
  · intro run_x hx0 hx1
    apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n129_run_floor a b run_x ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hadjacent) (hx1) (hx0) (ha) (hb) (hstrict) (hlong)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n129_run_left a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (ha) (hstrict) (hlong) (hadjacent)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n129_run_right a b (hlong) (hstrict) ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hadjacent) (ha) (hb)
  · apply Classical.byContradiction
    intro negated
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n129_run_tall a b ((by simpa only [LRunCertificates.InTiles, List.mem_cons, List.not_mem_nil, or_false, exists_eq_or_imp, exists_eq_left, Contains] using negated)) (hb) (hlong) (ha) (hstrict) (hadjacent)

theorem HP_adjacent_outer_short_pair_pruned_node000 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (ht0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ht5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (ap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    (ap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have in1 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have in5 := inside (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed0 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed5 := avoid (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht5
  have pairAllowed0_1 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed1_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed4_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have support : HP_adjacent_outer_short_pair_pruned_Box a b (2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n000_point a b (hb) (hlong) ((by simpa only [HP_adjacent_outer_short_pair_pruned_Box,HP_adjacent_outer_short_pair_pruned_M] using absent)) (ha) (hstrict) (hadjacent)
  have empty : ¬(Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) (2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n000_empty a b ((by simpa only [Contains] using occupied)) (hb) (hlong) (ha) (hstrict) (hadjacent)
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5
  have sep0 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n000_o0 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hit) (insideT) (sep4).2.1 (sep4).2.2.1 (hadjacent) (hlong) (hb) (ha) (hstrict)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_adjacent_outer_short_pair_pruned_node001 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n000_o1 a b jx jy (hit) (sep4).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (hlong) (hadjacent) (insideT) (ha) (hb) (hstrict)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_adjacent_outer_short_pair_pruned_node050 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n000_o2 a b jx jy (sep4).2.1 (hb) (insideT) (hit) (hlong) (hstrict) (ha) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n000_o3 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (sep0).2.1 (hit) (sep4).2.1 (insideT) (hadjacent) (hlong) (ha) (hb) (hstrict)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_adjacent_outer_short_pair_pruned_node062 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n000_o4 a b jx jy (hadjacent) (insideT) (hit) (sep4).2.1 (hlong) ((by simpa only [Same,eq_comm] using absent)) (ha) (hb) (hstrict)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_adjacent_outer_short_pair_pruned_node063 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n000_o5 a b jx jy (hlong) (sep1).2.1 (sep4).2.1 (hadjacent) ((by simpa only [Same,eq_comm] using absent)) (insideT) (hit) (ha) (hb) (hstrict)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_adjacent_outer_short_pair_pruned_node123 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n000_o6 a b jx jy (sep4).2.1 (insideT) (sep4).2.2.1 (hit) (hadjacent) ((by simpa only [Same,eq_comm] using absent)) (hlong) (ha) (hb) (hstrict)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_adjacent_outer_short_pair_pruned_node126 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_outer_short_pair_pruned_n000_o7 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hb) (sep4).2.2.1 (hadjacent) (hlong) (insideT) (hit) (ha) (hstrict)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_adjacent_outer_short_pair_pruned_node129 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)

theorem HP_adjacent_outer_short_pair_pruned_bounded_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_outer_short_pair_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_outer_short_pair_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (disjoint : ∀ t u x y, world t → world u → Contains t x y → Contains u x y → t=u)
    (avoidRun : LRunCertificates.ExtendedRunObstruction a b world)
    (avoidRunDown : LRunCertificates.ExtendedDownRunObstruction a b world)
    (avoidRunRight : LRunCertificates.ExtendedRightRunObstruction a b world)
    (avoidRunLeft : LRunCertificates.ExtendedLeftRunObstruction a b world)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u)
    (anchor0 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (anchor1 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (anchor2 : world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (anchor3 : world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (anchor4 : world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (anchor5 : world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have sep : ∀ t u, world t → world u → t=u ∨ Apart t u := by
    intro t u ht hu
    by_cases eq : t=u
    · exact Or.inl eq
    · right
      apply TPlane.apart_of_no_common_nonnegative t u
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies t ht)
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies u hu)
      · intro x y hx hy; exact eq (disjoint t u x y ht hu hx hy)
  have rootap0_1 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) anchor0 anchor1 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap0_2 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases sep (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) anchor0 anchor2 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap0_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) anchor0 anchor3 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap0_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) anchor0 anchor4 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap0_5 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases sep (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) anchor0 anchor5 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap1_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases sep (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) anchor1 anchor2 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap1_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) anchor1 anchor3 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap1_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) anchor1 anchor4 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap1_5 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases sep (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) anchor1 anchor5 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) anchor2 anchor3 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) anchor2 anchor4 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases sep (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) anchor2 anchor5 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap3_4 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) anchor3 anchor4 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap3_5 : Apart (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases sep (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) anchor3 anchor5 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  have rootap4_5 : Apart (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) := by
    rcases sep (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)) anchor4 anchor5 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  exact HP_adjacent_outer_short_pair_pruned_node000 a b ha hb hstrict hlong hadjacent world copies inside cover sep avoidRun avoidRunDown avoidRunRight avoidRunLeft avoid avoidPair anchor0 anchor1 anchor2 anchor3 anchor4 anchor5 rootap0_1 rootap0_2 rootap0_3 rootap0_4 rootap0_5 rootap1_2 rootap1_3 rootap1_4 rootap1_5 rootap2_3 rootap2_4 rootap2_5 rootap3_4 rootap3_5 rootap4_5

theorem HP_adjacent_outer_short_pair_pruned_anchored_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor0 : T.world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (anchor1 : T.world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (anchor2 : T.world (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int)))
    (anchor3 : T.world (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int)))
    (anchor4 : T.world (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int)))
    (anchor5 : T.world (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  have avoid : ∀ t, T.world t → ¬ForbiddenBoundaryTip a b t := by
    exact unequal_avoid_boundary_tips a b (by omega) (by omega) (by omega) T
  have avoidPair : ∀t u,T.world t → T.world u → ¬HP_adjacent_outer_short_pair_pruned_ForbiddenPair a b t u := by
    intro t u ht hu bad
    rcases bad with bad | bad
    ·
      rcases bad with bad | bad
      ·
        rcases bad with bad | bad
        ·
          rcases bad with bad | bad
          ·
            exact avoid_same_boundary_bars a b (by omega) (by omega) (by omega) T t u ht hu bad
          ·
            exact avoid_long_boundary_corner a b (by omega) (by omega) (by omega) T t u ht hu bad
        ·
          exact avoid_same_short_bars a b (by omega) (by omega) T t u ht hu bad
      ·
        exact avoid_outward_long_boundary_corner a b (by omega) (by omega) (by omega) T t u ht hu bad
    ·
      exact avoid_short_upright_long a b (by omega) (by omega) (by omega) T t u ht hu bad
  apply HP_adjacent_outer_short_pair_pruned_bounded_obstruction a b ha hb hstrict hlong hadjacent T.world T.copies ?_ ?_ T.disjoint (LRunCertificates.tiling_extended_run_obstruction (by omega) (by omega) T) (LRunCertificates.tiling_extended_down_run_obstruction (by omega) (by omega) T) (LRunCertificates.tiling_extended_right_run_obstruction (by omega) (by omega) T) (LRunCertificates.tiling_extended_left_run_obstruction (by omega) (by omega) T) avoid avoidPair anchor0 anchor1 anchor2 anchor3 anchor4 anchor5
  · intro t ht
    have nn := TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (T.copies t ht)
    exact T.inside t ht t.x (t.y-t.south) (by
      unfold Contains; unfold TPlane.Nonnegative at nn; right; omega)
  · intro x y h; exact T.cover x y h.2.1
theorem HP_adjacent_outer_short_pair_pruned_no_shifted_anchor (a b p : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor0 : T.world (shift p 0 (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int))))
    (anchor1 : T.world (shift p 0 (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int))))
    (anchor2 : T.world (shift p 0 (Cross.mk ((1 : Int) + ((2 : Int) * a)) (0 : Int) (0 : Int) b a (0 : Int))))
    (anchor3 : T.world (shift p 0 (Cross.mk ((2 : Int) + ((2 : Int) * a)) (0 : Int) a b (0 : Int) (0 : Int))))
    (anchor4 : T.world (shift p 0 (Cross.mk (1 : Int) (1 : Int) b a (0 : Int) (0 : Int))))
    (anchor5 : T.world (shift p 0 (Cross.mk ((2 : Int) + ((2 : Int) * b)) (1 : Int) (0 : Int) a b (0 : Int))))
    : False := by
  let U : Tiling a b 0 0 HalfPlane :=
    (T.translate (-p) 0).congr (by intro x y; simp only [HalfPlane,Int.sub_zero])
  apply HP_adjacent_outer_short_pair_pruned_anchored_obstruction a b ha hb hstrict hlong hadjacent U
  · refine ⟨_,anchor0,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
  · refine ⟨_,anchor1,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
  · refine ⟨_,anchor2,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
  · refine ⟨_,anchor3,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
  · refine ⟨_,anchor4,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
  · refine ⟨_,anchor5,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
end PolyominoFormal.LRegion

import PositivePlaneUnit
import PositivePlaneTwo
import PositivePlaneExceptional
import PositiveCross
import TilingSymmetry
import CrossClassification

namespace PositiveTheorems
open CrossUnits PolyominoFormal

/-- Every stated positive T-plane family has an actual infinite plane tiling. -/
theorem t_plane_of_conditions (a b c : Int) (ha : c≤a) (hb : 1≤b) (hc : 1≤c)
    (h : c=1 ∨ b≤2 ∨ (c=2 ∧ b=a+3)) : Tiles a b c 0 Plane := by
  rcases h with rfl | h | ⟨rfl,rfl⟩
  · exact PositivePlaneUnit.tiles_plane a b ha hb
  · have hba : b=1 ∨ b=2 := by omega
    rcases hba with rfl | rfl
    · exact PositiveHierarchy.t_unit_stem_plane a c (by omega) hc
    · exact PositivePlaneTwo.tiles_plane a c (by omega) hc
  · exact PositivePlaneExceptional.tiles_plane a ha

/-- Either opposite pair of unit arms suffices; the other arms are arbitrary. -/
theorem cross_plane_of_opposite_units (a b c d : Int)
    (ha : 1≤a) (hb : 1≤b) (hc : 1≤c) (hd : 1≤d)
    (h : (a=1 ∧ c=1) ∨ (b=1 ∧ d=1)) : Tiles a b c d Plane := by
  rcases h with ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩
  · exact ⟨(PositiveCross.planeTiling d b hd hb).rotateParameters⟩
  · exact PositiveCross.tiles_plane a c ha hc

/-- Full plane classification of every cross with four positive arms. -/
theorem cross_plane_iff (a b c d : Int)
    (ha : 1≤a) (hb : 1≤b) (hc : 1≤c) (hd : 1≤d) :
    Tiles a b c d Plane ↔ (a=1 ∧ c=1) ∨ (b=1 ∧ d=1) :=
  ⟨CrossClassification.plane_requires_opposite_units ha hb hc hd,
   cross_plane_of_opposite_units a b c d ha hb hc hd⟩

/-- All positive lower levels of the two-unit T family, including a=4 and a=5. -/
theorem t_two_units_positive_profile (a : Int) (ha : 1≤a) :
    BentStripTileable a 1 1 0 ∧ Tiles a 1 1 0 Quadrant ∧
    StripTileable a 1 1 0 ∧ Tiles a 1 1 0 HalfPlane ∧ Tiles a 1 1 0 Plane :=
  ⟨PositiveConstructions.bent_tileable a ha,
   PositiveHierarchy.t_two_units_quadrant a ha,
   PositiveConstructions.strip_tileable a 1 ha (by omega),
   PositiveHierarchy.t_unit_stem_halfplane a 1 ha (by omega),
   PositiveHierarchy.t_unit_stem_plane a 1 ha (by omega)⟩

#print axioms t_plane_of_conditions
#print axioms cross_plane_of_opposite_units
#print axioms cross_plane_iff
#print axioms t_two_units_positive_profile
end PositiveTheorems
